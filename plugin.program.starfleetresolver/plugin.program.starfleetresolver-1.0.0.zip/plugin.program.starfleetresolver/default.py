# -*- coding: utf-8 -*-
"""Starfleet Resolver - the visible front door of script.module.starfleetresolve.

    plugin://plugin.program.starfleetresolver/                      menu
    ...?mode=pair&service=<id>   pair an account     ...?mode=reset&service=<id>   remove it
    ...?mode=import              import from the Starfleet plugin / ResolveURL
    ...?mode=test                type a link, see what it resolves to
    ...?mode=settings            the resolver module's own settings page
    ...?mode=about"""
import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
BASE = sys.argv[0] if sys.argv else 'plugin://plugin.program.starfleetresolver/'


def url(**kw):
    return BASE + '?' + urlencode(kw)


def notify(msg):
    xbmcgui.Dialog().notification('Starfleet Resolver', msg, xbmcgui.NOTIFICATION_INFO, 5000)


def menu():
    from starfleetresolve import debrid
    status = debrid.status()
    xbmcplugin.setPluginCategory(HANDLE, 'Starfleet Resolver')
    for sid, name, paired in debrid.services():
        if paired:
            who = (status.get(sid) or {}).get('user') or 'paired'
            li = xbmcgui.ListItem(label='[COLOR lime]Paired[/COLOR]  %s  (%s)  - select to remove' % (name, who))
            xbmcplugin.addDirectoryItem(HANDLE, url(mode='reset', service=sid), li, False)
        else:
            li = xbmcgui.ListItem(label='Pair %s' % name)
            xbmcplugin.addDirectoryItem(HANDLE, url(mode='pair', service=sid), li, False)
    for label, mode in (('Import accounts from the Starfleet plugin / ResolveURL', 'import'),
                        ('Test a link', 'test'),
                        ('Resolver settings', 'settings'),
                        ('About', 'about')):
        xbmcplugin.addDirectoryItem(HANDLE, url(mode=mode), xbmcgui.ListItem(label=label), False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def run(params):
    mode = params.get('mode', '')
    if not mode:
        return menu()
    from starfleetresolve import debrid
    import starfleetresolve as sfr
    names = {s[0]: s[1] for s in debrid.services()}
    sid = params.get('service', '')
    if mode == 'pair' and sid in names:
        notify('%s paired' % names[sid] if debrid.pair(sid) else '%s not paired' % names[sid])
    elif mode == 'reset' and sid in names:
        if xbmcgui.Dialog().yesno('Starfleet Resolver', 'Remove the %s account from the resolver?' % names[sid]):
            debrid.reset(sid)
            notify('%s removed' % names[sid])
    elif mode == 'import':
        from starfleetresolve.debrid import importer
        got = {}
        for fn in (importer.import_from_plugin, importer.import_from_resolveurl):
            got.update({k: v for k, v in fn().items() if v == 'imported'})
        notify('Imported: %s' % (', '.join(names[k] for k in got) or 'nothing new'))
    elif mode == 'test':
        link = xbmcgui.Dialog().input('Link to resolve', type=xbmcgui.INPUT_ALPHANUM)
        if link:
            out = sfr.resolve(link.strip())
            xbmcgui.Dialog().textviewer('Resolved' if out else 'Not resolved',
                                        (out or 'Nothing playable came back. Known host: %s' % (sfr.knows_host(link) or 'no')))
    elif mode == 'settings':
        import xbmcaddon
        xbmcaddon.Addon('script.module.starfleetresolve').openSettings()
    elif mode == 'about':
        kd = sfr.known_domains()
        xbmcgui.Dialog().ok('Starfleet Resolver', 'Version %s\nResolves %d host domains (%d are Starfleet\'s own)\nPaired debrid accounts: %s' % (
            sfr.__version__, len(kd), sum(1 for v in kd.values() if v == 'starfleet'),
            ', '.join(names[i] for i in debrid.authorized()) or 'none'))
    xbmc.executebuiltin('Container.Refresh')


if __name__ == '__main__':
    q = sys.argv[2].lstrip('?') if len(sys.argv) > 2 else ''
    run(dict(parse_qsl(q)))
