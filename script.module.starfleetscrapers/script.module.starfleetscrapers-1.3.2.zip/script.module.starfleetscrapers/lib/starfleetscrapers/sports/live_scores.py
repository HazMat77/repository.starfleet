# -*- coding: utf-8 -*-
"""Live scores and game status for the sports lists.

The event lists are cached for several minutes, so a score baked into a title goes stale. This module keeps the title plain and
attaches the current score, clock and state ('pre' / 'in' / 'post') to each event when a list is shown, from the leagues' own
public scoreboards (one request per sport, kept 20 seconds). An event is matched to a game by both teams' names and, when both
sides know it, by start time."""
import re
import threading
import time
import unicodedata

import requests
import xbmc

_API = 'https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard'
_BOARDS = {
    'nfl':    [('football', 'nfl')],
    'nba':    [('basketball', 'nba')],
    'mlb':    [('baseball', 'mlb')],
    'nhl':    [('hockey', 'nhl')],
    'cfb':    [('football', 'college-football')],
    'ncaab':  [('basketball', 'mens-college-basketball')],
    'cfl':    [('football', 'cfl')],
    'soccer': [('soccer', 'all')],
}
_TTL = 20
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
_cache = {}
_lock = threading.Lock()
_STOP = {'fc', 'cf', 'sc', 'ac', 'afc', 'club', 'de', 'the', 'of', 'and', 'st', 'cd', 'sd', 'ud', 'fk', 'sk', 'vs', 'v'}


def _tokens(text):
    t = unicodedata.normalize('NFKD', text or '')
    t = ''.join(c for c in t if not unicodedata.combining(c)).lower()
    return [w for w in re.findall(r'[a-z0-9]+', t) if w not in _STOP and not w.isdigit()]


def _ts(iso):
    try:
        import calendar
        return calendar.timegm(time.strptime(iso.replace('Z', '')[:16], '%Y-%m-%dT%H:%M'))
    except Exception:
        return 0


def _games(slug):
    """[{'home','away','hs','as','state','detail','start'}] for the sport, from the scoreboard (cached 20 s)."""
    boards = _BOARDS.get(slug)
    if not boards:
        return []
    now = time.time()
    with _lock:
        hit = _cache.get(slug)
        if hit and now - hit[0] < _TTL:
            return hit[1]
    out = []
    for sport, league in boards:
        try:
            r = requests.get(_API.format(sport=sport, league=league), headers={'User-Agent': _UA}, timeout=7)
            r.raise_for_status()
            data = r.json()
        except Exception as e:
            xbmc.log('[Starfleet/Scores] %s scoreboard: %s' % (slug, str(e)[:80]), xbmc.LOGWARNING)
            continue
        for ev in data.get('events', []):
            try:
                comp = (ev.get('competitions') or [{}])[0]
                cs = comp.get('competitors') or []
                home = next(c for c in cs if c.get('homeAway') == 'home')
                away = next(c for c in cs if c.get('homeAway') == 'away')
                st = ev.get('status', {}).get('type', {})
                state = st.get('state', 'pre')
                detail = st.get('shortDetail', '') or ''
                if state == 'pre':
                    detail = ''
                out.append({
                    'home': home['team']['displayName'], 'away': away['team']['displayName'],
                    'hs': str(home.get('score', '0')), 'as': str(away.get('score', '0')),
                    'state': state, 'detail': detail, 'start': _ts(ev.get('date', '')),
                })
            except Exception:
                continue
    with _lock:
        _cache[slug] = (now, out)
    return out


def _distinct(a, b):
    """Name tokens that belong to one team only ('lakers' / 'clippers' out of two 'Los Angeles' teams)."""
    sa, sb = set(a), set(b)
    da, db = sa - sb, sb - sa
    return (da or sa), (db or sb)


def _find(games, ev):
    title = ev.get('match_title') or ev.get('title') or ''
    toks = set(_tokens(title))
    if not toks:
        return None
    start = ev.get('start_ts') or 0
    for g in games:
        ha, aa = _distinct(_tokens(g['home']), _tokens(g['away']))
        if not (ha & toks and aa & toks):
            continue
        if start and g['start'] and abs(start - g['start']) > 36 * 3600:
            continue
        return g
    return None


def _line(ev, g):
    """'Away 8 - 9 Home' in the order the event title gives the teams."""
    title = ev.get('match_title') or ev.get('title') or ''
    if ' : ' in title:                           # 'England - Premier League : Team A vs Team B'
        title = title.split(' : ')[-1]
    parts = re.split(r'\s+(?:vs\.?|@|at|v)\s+', title, maxsplit=1)
    if len(parts) < 2:
        parts = re.split(r'\s+-\s+', title, maxsplit=1)
    first = set(_tokens(parts[0]))
    ha, aa = _distinct(_tokens(g['home']), _tokens(g['away']))
    if first & ha and not first & aa:
        return '%s %s - %s %s' % (g['home'], g['hs'], g['as'], g['away'])
    return '%s %s - %s %s' % (g['away'], g['as'], g['hs'], g['home'])


def attach(slug, events):
    """Copies of `events` with 'score_line', 'score_detail', 'game_state' added where a scoreboard game matches (and 'is_live'
    corrected from the scoreboard). Events without a match are returned as they were."""
    games = _games(slug)
    if not games:
        return events
    out = []
    for ev in events:
        g = _find(games, ev)
        if not g:
            out.append(ev)
            continue
        e = dict(ev)
        e['game_state'] = g['state']
        e['score_detail'] = g['detail']
        if g['state'] in ('in', 'post'):
            e['score_line'] = _line(ev, g)
        if g['state'] == 'in':
            e['is_live'] = True
        elif g['state'] == 'post':
            e['is_live'] = False
        if e.get('match_title'):                 # lists cached earlier may carry a score inside the title
            e['title'] = e['match_title']
        out.append(e)
    return out
