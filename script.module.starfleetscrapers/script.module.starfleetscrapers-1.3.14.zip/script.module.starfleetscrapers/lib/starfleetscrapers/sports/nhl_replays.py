# -*- coding: utf-8 -*-
"""NHL replays: full games plus short / long recaps, merged into one entry per game.

Sources
    hockeyreplays.com   Full game replays, one page per game (ok.ru / other hosts), listed by season:
                        /nhl-2026-27 and /nhl-2026-27?page2 ... (12 games a page, newest first).
    nhlrecaps.net       Spoiler-free recaps for the last ~14 days. Each game has a Short (about 5 min
                        recap) and a Long (about 10 min condensed game), both NHL Brightcove videos.
                        The Brightcove API also serves a plain MP4 rendition, which Kodi plays without
                        the HLS problems the NHL.com condensed games had.
    dtmts.com/nhl       Spoiler-free highlight video per game (a YouTube id) for the last few days, from
                        its /api/schedule/nhl JSON.

Public API (used by replay_sources.py)
    games()                    -> list of merged game dicts (see below)
    full_game_sources(url)     -> [{'label', 'url'}] for one hockeyreplays.com game page
    brightcove_mp4(video_id)   -> direct MP4 URL (HLS if no MP4 exists) or None

A game dict has: title, date_key (YYYY-MM-DD), date_label, thumb, abbr (frozenset of the two team codes)
and any of hr_url, nr_short, nr_long, dt_yt, dt_alt1, dt_alt2.
"""
import concurrent.futures as _cf
import datetime
import html as _html
import json
import re
import unicodedata

import requests
import xbmc

from starfleetscrapers.core import cache as _cache

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/126.0.0.0 Safari/537.36')
_HR = 'https://hockeyreplays.com'
_NR = 'https://nhlrecaps.net'
_DT = 'https://www.dtmts.com'

# newest season first; (slug, pages to read). The listing is 12 games a page.
_HR_SEASONS = (('nhl-2026-27', 6), ('nhl-2025-26', 3))

_TEAMS = {
    'ANA': ('Anaheim Ducks', 'ducks'), 'BOS': ('Boston Bruins', 'bruins'), 'BUF': ('Buffalo Sabres', 'sabres'),
    'CGY': ('Calgary Flames', 'flames'), 'CAR': ('Carolina Hurricanes', 'hurricanes'),
    'CHI': ('Chicago Blackhawks', 'blackhawks'), 'COL': ('Colorado Avalanche', 'avalanche'),
    'CBJ': ('Columbus Blue Jackets', 'jackets'), 'DAL': ('Dallas Stars', 'stars'),
    'DET': ('Detroit Red Wings', 'wings'), 'EDM': ('Edmonton Oilers', 'oilers'),
    'FLA': ('Florida Panthers', 'panthers'), 'LAK': ('Los Angeles Kings', 'kings'),
    'MIN': ('Minnesota Wild', 'wild'), 'MTL': ('Montreal Canadiens', 'canadiens'),
    'NSH': ('Nashville Predators', 'predators'), 'NJD': ('New Jersey Devils', 'devils'),
    'NYI': ('New York Islanders', 'islanders'), 'NYR': ('New York Rangers', 'rangers'),
    'OTT': ('Ottawa Senators', 'senators'), 'PHI': ('Philadelphia Flyers', 'flyers'),
    'PIT': ('Pittsburgh Penguins', 'penguins'), 'SJS': ('San Jose Sharks', 'sharks'),
    'SEA': ('Seattle Kraken', 'kraken'), 'STL': ('St. Louis Blues', 'blues'),
    'TBL': ('Tampa Bay Lightning', 'lightning'), 'TOR': ('Toronto Maple Leafs', 'leafs'),
    'UTA': ('Utah Mammoth', 'utah'), 'VAN': ('Vancouver Canucks', 'canucks'),
    'VGK': ('Vegas Golden Knights', 'knights'), 'WSH': ('Washington Capitals', 'capitals'),
    'WPG': ('Winnipeg Jets', 'jets'), 'ARI': ('Arizona Coyotes', 'coyotes'),
}
# the same club under other codes some sites use
_ABBR_ALIAS = {'NJ': 'NJD', 'NJY': 'NJD', 'TB': 'TBL', 'TBY': 'TBL', 'SJ': 'SJS', 'LA': 'LAK', 'LAK': 'LAK',
               'UTAH': 'UTA', 'VEG': 'VGK', 'WAS': 'WSH', 'MON': 'MTL', 'CLB': 'CBJ', 'NAS': 'NSH'}


def _abbr(code):
    c = (code or '').strip().upper()
    c = _ABBR_ALIAS.get(c, c)
    return c if c in _TEAMS else ''


def _abbr_from_name(name):
    t = unicodedata.normalize('NFKD', name or '').encode('ascii', 'ignore').decode().lower()
    for ab, (_full, nick) in _TEAMS.items():
        if nick in t:
            return ab
    return ''


def _get(url, timeout=15, referer=None):
    h = {'User-Agent': _UA, 'Accept': 'text/html,application/json,*/*;q=0.8'}
    if referer:
        h['Referer'] = referer
    r = requests.get(url, headers=h, timeout=timeout)
    r.raise_for_status()
    return r.text


def _label(date_key):
    try:
        return datetime.date.fromisoformat(date_key).strftime('%B %d, %Y')
    except Exception:
        return date_key


# ── hockeyreplays.com (full games) ───────────────────────────────────────────

_MONTHS = {m: i for i, m in enumerate(['january', 'february', 'march', 'april', 'may', 'june', 'july',
                                       'august', 'september', 'october', 'november', 'december'], 1)}
_RE_HR_LINK = re.compile(
    r'href="(?:https://hockeyreplays\.com)?(/[a-z0-9-]+-full-game-replay-([a-z]+)-(\d{1,2})-(\d{4}))"[^>]*>([^<]*)', re.I)
_RE_HR_IMG = re.compile(r'<img[^>]+src="(/_pu/[^"]+)"')


def _hr_page(season, page):
    url = '%s/%s' % (_HR, season) + ('' if page <= 1 else '?page%d' % page)
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/NHLReplays] hockeyreplays %s p%d: %s' % (season, page, e), xbmc.LOGINFO)
        return []
    out, seen = [], set()
    titles = {}
    for m in _RE_HR_LINK.finditer(html):
        text = _html.unescape(m.group(5)).strip()
        if ' @ ' in text:
            titles[m.group(1)] = text
    for m in _RE_HR_LINK.finditer(html):
        path, mon, day, year = m.group(1), m.group(2).lower(), int(m.group(3)), int(m.group(4))
        if path in seen or mon not in _MONTHS:
            continue
        title = titles.get(path)
        if not title:
            continue
        seen.add(path)
        mm = re.match(r'(.+?)\s@\s(.+?)\s+-\s+NHL', title)
        if not mm:
            continue
        away, home = _abbr_from_name(mm.group(1)), _abbr_from_name(mm.group(2))
        if not away or not home:
            continue
        try:
            dk = datetime.date(year, _MONTHS[mon], day).isoformat()
        except ValueError:
            continue
        img = _RE_HR_IMG.search(html[max(0, m.start() - 1500):m.start()])
        out.append({'date_key': dk, 'away': away, 'home': home, 'hr_url': _HR + path,
                    'thumb': (_HR + img.group(1)) if img else '', 'preseason': 'preseason' in title.lower()})
    return out


def _hr_games():
    jobs = [(s, p) for s, pages in _HR_SEASONS for p in range(1, pages + 1)]
    games = []
    with _cf.ThreadPoolExecutor(max_workers=6) as ex:
        for res in ex.map(lambda sp: _hr_page(*sp), jobs):
            games.extend(res)
    return games


def full_game_sources(url):
    """Watch links on one hockeyreplays.com game page: 'Server #1 (OK)' style buttons."""
    ck = 'nhlrep_hr_src_%s' % url[-70:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    try:
        html = _get(url, referer=_HR + '/')
    except Exception as e:
        xbmc.log('[Starfleet/NHLReplays] game page %s: %s' % (url[-50:], e), xbmc.LOGINFO)
        return []
    out, seen = [], set()
    # "Server #1 (OK)" caption, then the button's link
    for m in re.finditer(r'Server\s*#?\s*(\d+)\s*\(([^)<]+)\)(.{0,900}?)href="((?:https?:)?//[^"]+)"', html, re.S | re.I):
        num, host, link = m.group(1), _html.unescape(m.group(2)).strip(), _html.unescape(m.group(4))
        if link.startswith('//'):
            link = 'https:' + link
        if link in seen or re.search(r'czernik|hockeyreplays\.com|disclaimer', link):
            continue
        seen.add(link)
        out.append({'label': 'Full Game (%s, server %s)' % (host, num), 'url': link})
    if not out:                      # no captions: any ok.ru embed on the page
        for m in re.finditer(r'(?:https?:)?//(?:www\.)?ok\.ru/videoembed/(\d+)', html):
            link = 'https://ok.ru/videoembed/%s' % m.group(1)
            if link not in seen:
                seen.add(link)
                out.append({'label': 'Full Game (OK.ru)', 'url': link})
    _cache.set(ck, out or False, 30 * 60 if out else 5 * 60)
    return out


# ── nhlrecaps.net (short + long recaps, last ~14 days) ───────────────────────

_RE_NR_DATE = re.compile(r'<h3>(\d{4}-\d{2}-\d{2})</h3>')
_RE_NR_GAME = re.compile(r'<div class="wrap-video(?: wrap-no-video)?" data-gameid="(\d+)">(.*?)(?=<div class="wrap-video|</div></div><h3>|\Z)', re.S)
_RE_NR_TEAMS = re.compile(r'<p class="teams">.*?/([A-Z]{2,3})_logo\.svg"[^>]*>\s*([A-Z]{2,3})\s*@\s*([A-Z]{2,3}).*?/([A-Z]{2,3})_logo\.svg', re.S)
_RE_NR_VIDEO = re.compile(r'videoId=(\d+)[^"]*"[^>]*>.*?<div>\s*(Short|Long)\s*</div>', re.S | re.I)


def _nr_games():
    try:
        html = _get(_NR + '/')
    except Exception as e:
        xbmc.log('[Starfleet/NHLReplays] nhlrecaps: %s' % e, xbmc.LOGINFO)
        return []
    out = []
    marks = [(m.start(), m.group(1)) for m in _RE_NR_DATE.finditer(html)]
    for gm in _RE_NR_GAME.finditer(html):
        date = ''
        for pos, d in marks:
            if pos < gm.start():
                date = d
        gd = re.search(r'class="gamedate">(\d{4}-\d{2}-\d{2})<', gm.group(2))
        date = gd.group(1) if gd else date
        tm = _RE_NR_TEAMS.search(gm.group(2))
        if not date or not tm:
            continue
        away, home = _abbr(tm.group(2)), _abbr(tm.group(3))
        if not away or not home:
            continue
        vids = {k.lower(): v for v, k in _RE_NR_VIDEO.findall(gm.group(2))}
        if not vids:
            continue                         # not played yet
        img = re.search(r'<img src="(/cached/[^"]+\.jpg)"', gm.group(2))
        out.append({'date_key': date, 'away': away, 'home': home, 'nr_short': vids.get('short', ''),
                    'nr_long': vids.get('long', ''), 'thumb': (_NR + img.group(1)) if img else ''})
    return out


# ── dtmts.com (highlights, a YouTube id per game) ────────────────────────────

def _dt_games():
    try:
        data = json.loads(_get(_DT + '/api/schedule/nhl', referer=_DT + '/nhl'))
    except Exception as e:
        xbmc.log('[Starfleet/NHLReplays] dtmts: %s' % e, xbmc.LOGINFO)
        return []
    out = []
    for _day, games in (data or {}).items():
        for g in games or []:
            yt = g.get('youtubeId') or ''
            if not yt or 'offline' in yt:
                yt = ''
            alt1, alt2 = g.get('altVideoId1') or '', g.get('altVideoId2') or ''
            if not (yt or alt1 or alt2):
                continue
            away, home = _abbr((g.get('team1') or {}).get('abbreviation')), _abbr((g.get('team2') or {}).get('abbreviation'))
            dk = (g.get('officialDate') or g.get('date') or '')[:10]
            if away and home and dk:
                out.append({'date_key': dk, 'away': away, 'home': home, 'dt_yt': yt, 'dt_alt1': alt1, 'dt_alt2': alt2,
                            'alt1_name': ((g.get('Season') or {}).get('altVideo1Name') or 'Extended'),
                            'alt2_name': ((g.get('Season') or {}).get('altVideo2Name') or 'Condensed')})
    return out


# ── merge ────────────────────────────────────────────────────────────────────

def _find(games, date_key, pair):
    """The game with the same two clubs on that date, or the day before / after (sites differ on the
    date of late games)."""
    d0 = datetime.date.fromisoformat(date_key)
    for delta in (0, -1, 1):
        k = (d0 + datetime.timedelta(days=delta)).isoformat()
        g = games.get((k, pair))
        if g:
            return g
    return None


def games():
    ck = 'nhlrep_games_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    with _cf.ThreadPoolExecutor(max_workers=3) as ex:
        f_hr, f_nr, f_dt = ex.submit(_hr_games), ex.submit(_nr_games), ex.submit(_dt_games)
        hr, nr, dt = f_hr.result(), f_nr.result(), f_dt.result()
    merged = {}
    for src in (hr, nr, dt):
        for g in src:
            pair = frozenset((g['away'], g['home']))
            tgt = _find(merged, g['date_key'], pair)
            if tgt is None:
                tgt = {'date_key': g['date_key'], 'away': g['away'], 'home': g['home'], 'abbr': pair}
                merged[(g['date_key'], pair)] = tgt
            for k, v in g.items():
                if k in ('date_key', 'away', 'home') or not v:
                    continue
                if k == 'thumb' and tgt.get('thumb'):
                    continue
                tgt.setdefault(k, v)
    out = []
    for g in merged.values():
        g['title'] = '%s @ %s' % (_TEAMS[g['away']][0], _TEAMS[g['home']][0])
        g['date_label'] = _label(g['date_key'])
        out.append(g)
    out.sort(key=lambda g: (g['date_key'], g['title']), reverse=True)
    _cache.set(ck, out, 20 * 60)
    xbmc.log('[Starfleet/NHLReplays] %d games (full %d, recaps %d, dtmts %d)' % (len(out), len(hr), len(nr), len(dt)), xbmc.LOGINFO)
    return out


# ── Brightcove (NHL recaps) ──────────────────────────────────────────────────

_BC_ACCOUNT = '6415718365001'


def brightcove_mp4(video_id):
    """Direct MP4 for an NHL Brightcove video (HLS only if no MP4 rendition exists)."""
    ck = 'nhlrep_bc_%s' % video_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None
    try:
        from starfleetscrapers.sports import replay_sources as _rs
        pk = _rs._nhl_policy_key()
        if not pk:
            return None
        r = requests.get('https://edge.api.brightcove.com/playback/v1/accounts/%s/videos/%s' % (_BC_ACCOUNT, video_id),
                         headers={'Accept': 'application/json;pk=%s' % pk, 'User-Agent': _UA}, timeout=15)
        r.raise_for_status()
        sources = r.json().get('sources') or []
    except Exception as e:
        xbmc.log('[Starfleet/NHLReplays] brightcove %s: %s' % (video_id, e), xbmc.LOGINFO)
        return None
    mp4 = [s for s in sources if (s.get('container') or '').upper() == 'MP4' and (s.get('src') or '').startswith('https')]
    mp4.sort(key=lambda s: (s.get('height') or 0, s.get('size') or 0), reverse=True)
    url = mp4[0]['src'] if mp4 else ''
    if not url:
        hls = [s.get('src') for s in sources if 'mpegurl' in (s.get('type') or '').lower() and (s.get('src') or '').startswith('https')]
        url = hls[0] if hls else ''
    _cache.set(ck, url or False, 20 * 60)
    return url or None


def youtube_url(yt_id):
    return 'https://www.youtube.com/watch?v=%s' % yt_id
