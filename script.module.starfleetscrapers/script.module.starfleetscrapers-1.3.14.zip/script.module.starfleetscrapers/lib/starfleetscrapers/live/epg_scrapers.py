# -*- coding: utf-8 -*-
"""Programme guides built on demand, when the TV guide is set up or refreshed (no scraper-PC job, nothing hosted):

  inline_xmltv(source)   Plex / LG Channels / Pluto TV  - from each service's own API (live_sources.get_epg_entries)
  sinclair_xmltv()       nine Sinclair stations         - tvtv.us's grid API
  tva_xmltv()            TVA                            - the TV Passport grid TVA's cable guide is built on

Each returns XMLTV bytes (cached for three hours); b'' when nothing could be fetched."""
import datetime
import json
import re
import time
import xml.sax.saxutils as _sx
from concurrent.futures import ThreadPoolExecutor

import requests
import xbmc

from starfleetscrapers.core import cache as _cache

_TTL = 3 * 3600
_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')


def _esc(s):
    return _sx.escape(s or '')


def _xmltv_time(iso):
    """'2026-10-23T18:00:00Z' (or with milliseconds) -> '20261023180000 +0000'."""
    t = (iso or '').replace('Z', '').split('.')[0]
    try:
        return datetime.datetime.strptime(t, '%Y-%m-%dT%H:%M:%S').strftime('%Y%m%d%H%M%S') + ' +0000'
    except ValueError:
        try:
            return datetime.datetime.strptime(t, '%Y-%m-%dT%H:%M').strftime('%Y%m%d%H%M%S') + ' +0000'
        except ValueError:
            return ''


def _document(channels, programmes):
    """channels: [(id, display name)], programmes: [(start 'YYYYmmddHHMMSS +zzzz', stop, channel id, title, subtitle, description)]."""
    out = ['<?xml version="1.0" encoding="UTF-8"?>', '<tv generator-info-name="starfleet">']
    for cid, name in channels:
        out.append('  <channel id="%s"><display-name>%s</display-name></channel>' % (_esc(cid), _esc(name)))
    for start, stop, cid, title, sub, desc in programmes:
        out.append('  <programme start="%s" stop="%s" channel="%s">' % (start, stop, _esc(cid)))
        out.append('    <title>%s</title>' % _esc(title))
        if sub:
            out.append('    <sub-title>%s</sub-title>' % _esc(sub))
        if desc:
            out.append('    <desc>%s</desc>' % _esc(desc))
        out.append('  </programme>')
    out.append('</tv>')
    return ('\n'.join(out) + '\n').encode('utf-8')


def _cached(key, build):
    hit = _cache.get(key)
    if hit:
        return hit.encode('latin-1') if isinstance(hit, str) else hit
    data = build()
    if data:
        try:
            _cache.set(key, data.decode('utf-8'), _TTL)
        except Exception:
            pass
        return data
    return b''


# ── Plex / LG / Pluto ────────────────────────────────────────────────────

def inline_xmltv(source):
    from starfleetscrapers.live import live_sources as L

    def build():
        entries = L.get_epg_entries(source)
        if not entries:
            return b''
        names = {}
        try:
            fn = {'Plex': L.get_plex_channels, 'LG Channels': L.get_lg_channels, 'Pluto TV': L.get_pluto_channels}[source]
            names = {c['id']: c['title'] for c in fn()}
        except Exception:
            pass
        chans, progs = [], []
        for cid, rows in entries.items():
            chans.append((cid, names.get(cid, cid)))
            for r in rows:
                a, b = _xmltv_time(r.get('start')), _xmltv_time(r.get('stop'))
                if a and b:
                    progs.append((a, b, cid, r.get('title', ''), r.get('subtitle', ''), r.get('description', '')))
        return _document(chans, progs)

    data = _cached('epg_xml_v1_' + source, build)
    return data


# ── Sinclair stations (tvtv.us) ───────────────────────────────────────

# callsign -> (tvtv.us site id, XMLTV channel id the guide export expects)
SINCLAIR_STATIONS = {
    'KMPH': ('32699', 'KMPHTV261.us'), 'WJLA': ('19579', 'WJLATV71.us'), 'WWMT': ('34884', 'WWMT31.us'),
    'WPDE': ('34557', 'WPDETV151.us'), 'KRCR': ('34474', 'KRCRTV71.us'), 'KECI': ('35298', 'KECITV131.us'),
    'WCTI': ('31042', 'WCTITV121.us'), 'WJAC': ('34429', 'WJACTV61.us'), 'KOMO': ('19629', 'KOMOTV511.us'),
}
_TVTV_LINEUP = 'USA-NY71652-X'


def _tvtv_programs(site_id):
    start = datetime.datetime.utcnow().replace(microsecond=0)
    rows = []
    for day in range(2):
        d0 = start + datetime.timedelta(days=day)
        d1 = d0 + datetime.timedelta(days=1)
        url = 'https://www.tvtv.us/api/v1/lineup/%s/grid/%sZ/%sZ/%s' % (_TVTV_LINEUP, d0.isoformat(), d1.isoformat(), site_id)
        try:
            r = requests.get(url, headers={'Accept': '*/*', 'User-Agent': _UA}, timeout=20)
            r.raise_for_status()
            data = r.json()
            rows.extend(data[0] if data else [])
        except Exception as e:
            xbmc.log('[Starfleet/EPG] tvtv %s day %d: %s' % (site_id, day, e), xbmc.LOGWARNING)
    return rows


def sinclair_xmltv():
    def build():
        with ThreadPoolExecutor(max_workers=5) as pool:
            fetched = list(pool.map(lambda kv: (kv[0], kv[1], _tvtv_programs(kv[1][0])), SINCLAIR_STATIONS.items()))
        chans, progs = [], []
        for callsign, (_site, cid), items in fetched:
            chans.append((cid, callsign))
            for it in items:
                start, title = it.get('startTime', ''), it.get('title') or ''
                if not start or not title:
                    continue
                try:
                    a = datetime.datetime.strptime(start.replace('Z', ''), '%Y-%m-%dT%H:%M')
                except ValueError:
                    continue
                b = a + datetime.timedelta(minutes=int(it.get('duration') or 0))
                progs.append((a.strftime('%Y%m%d%H%M%S') + ' +0000', b.strftime('%Y%m%d%H%M%S') + ' +0000', cid, title,
                              it.get('subtitle') or '', ''))
        return _document(chans, progs) if progs else b''

    return _cached('epg_xml_v1_sinclair', build)


# ── TVA (TV Passport grid) ─────────────────────────────────────────────

_TVA_GRID = 'https://tvmds.tvpassport.com/tvmds/cogeco/grid_v3/grid.php'
_TVA_LINEUP = '5180D'
_TVA_CHANNELS = {'CFTM': ('TVA.ca', 'TVA')}          # TV Passport callsign -> (XMLTV id, name)
_MONTHS_FR = {'janvier': 1, 'fevrier': 2, 'février': 2, 'mars': 3, 'avril': 4, 'mai': 5, 'juin': 6, 'juillet': 7, 'aout': 8,
              'août': 8, 'septembre': 9, 'octobre': 10, 'novembre': 11, 'decembre': 12, 'décembre': 12}
_HDR_RE = re.compile(r'tvm_txt_timebar">([^<]+)<')
_CELL_RE = re.compile(r"data=[\"']col:(\d+);colspan:(\d+);[^\"']*[\"']\s*>\s*<p class=[\"']tvm_showname[\"']>([^<]*)</p>")
_ROW_MARK = '<!-- channel row -->'


def _tva_block(st_epoch):
    r = requests.get(_TVA_GRID, headers={'User-Agent': _UA}, timeout=25, params={
        'subid': 'tvpassport', 'lu': _TVA_LINEUP, 'wd': 1138, 'ht': 100000, 'mode': 'json', 'style': 'blue', 'wid': 'wh',
        'st': st_epoch, 'ch': 1, 'tz': 'EST5EDT', 'lang': 'fr-ca', 'items': 99999, 'filter': ''})
    r.raise_for_status()
    return (r.json() or {}).get('data', '') or ''


def _tva_programs(html, callsign):
    heads = _HDR_RE.findall(html)
    if len(heads) < 2:
        return []
    m = re.search(r'(\d{1,2})\s+([^\s,]+)\s*,?\s*(\d{4})', heads[0])
    t = re.match(r'(\d{1,2})h(\d{2})?', heads[1])
    month = _MONTHS_FR.get(m.group(2).lower()) if m else None
    if not (m and t and month):
        return []
    window = datetime.datetime(int(m.group(3)), month, int(m.group(1)), int(t.group(1)), int(t.group(2) or 0))
    idx = html.find('">' + callsign + '<')
    if idx == -1:
        return []
    row_start = html.rfind(_ROW_MARK, 0, idx)
    row_start = idx if row_start == -1 else row_start
    nxt = html.find(_ROW_MARK, idx)
    row = html[row_start: nxt if nxt != -1 else row_start + 8000]
    out = []
    for col_s, span_s, title in _CELL_RE.findall(row):
        title = title.strip()
        if not title or title == '\xa0' or int(col_s) < 1:
            continue
        a = window + datetime.timedelta(minutes=(int(col_s) - 1) * 30)
        out.append((a, a + datetime.timedelta(minutes=int(span_s) * 30), title))
    return out


def tva_xmltv():
    def build():
        now = int(time.time())
        with ThreadPoolExecutor(max_workers=4) as pool:
            def one(i):
                try:
                    return _tva_block(now + i * 21600)
                except Exception as e:
                    xbmc.log('[Starfleet/EPG] TVA block %d: %s' % (i, e), xbmc.LOGWARNING)
                    return ''
            blocks = list(pool.map(one, range(8)))
        chans, progs = [], []
        for callsign, (cid, name) in _TVA_CHANNELS.items():
            chans.append((cid, name))
            seen = set()
            for html in blocks:
                for a, b, title in _tva_programs(html, callsign) if html else []:
                    if (a, title) in seen:
                        continue
                    seen.add((a, title))
                    progs.append((a.strftime('%Y%m%d%H%M%S') + ' -0400', b.strftime('%Y%m%d%H%M%S') + ' -0400', cid, title, '', ''))
        return _document(chans, progs) if progs else b''

    return _cached('epg_xml_v1_tva', build)
