# -*- coding: utf-8 -*-
"""
resources/lib/embed_sources.py

Embed-provider scrapers using IMDB IDs — no debrid required.

Active source: RiveStream (scrapper.rivestream.app) — a TMDB-keyed JSON API
that returns direct HLS playlists.

Removed 2026-09-19 after re-probing every one live (per-site findings are in
the block above search_embed_providers()): vidsrc, vidsrcme, autoembed,
superembed (multiembed), 2embed, moviesapi, smashystream, ridomovies, flixon,
vidlink and moviebox. All were offline, behind a Cloudflare/JS wall, packed
into an encrypted browser-only payload, or (MovieBox) geo-blocked by IP.

Nothing in this file may return a bare embed PAGE url — Kodi cannot play a
webpage.
"""

import re
import xbmc

try:
    from starfleetscrapers.core import http as _req
except ImportError:
    _req = None

# Shared quality/fake-release filters — reused rather than reinvented so
# every provider in this file gets the same camrip/telesync/EZTV-fake
# rejection and resolution-tier normalization torrent_sources.py already
# maintains in one place.
try:
    from starfleetscrapers.debrid.torrent_sources import (
        _meets_quality as _tq_meets_quality,
        _extract_quality as _tq_extract_quality,
    )
except Exception:
    def _tq_meets_quality(text, media_type='movie'):
        return True

    def _tq_extract_quality(text):
        return ''

# Disguised-executable guard — a magnet/stream whose display name or URL
# ends in one of these is never legitimate video content regardless of any
# quality tag it also carries.
_BAD_EXT_RE = re.compile(
    r'\.(?:exe|zip|rar|bat|msi|dmg|apk|iso|7z|tar|gz)(?:[?#]|$)', re.IGNORECASE
)

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)
_HEADERS = {
    'User-Agent': _UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    # No 'br' (Brotli) — decoding it depends on an optional brotli/brotlicffi
    # package this environment doesn't have installed, so a Brotli-encoded
    # response (which any Cloudflare-fronted host serves whenever
    # Accept-Encoding allows it — confirmed live against
    # scrapper.rivestream.app while building search_rivestream below) came
    # back as raw compressed garbage instead of real JSON/HTML, with no
    # exception raised to make that obvious. Same fix already applied in
    # torrent_sources.py's own _BROWSER_HEADERS/_CF_HEADERS for the identical
    # reason. gzip/deflate are handled natively with no extra dependency.
    'Accept-Encoding': 'gzip, deflate',
}

_session = None


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=0, redirect=False)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get(url, timeout=10, referer='', allow_redirects=True):
    s = _sess()
    if not s:
        return ''
    try:
        headers = {}
        if referer:
            headers['Referer'] = referer
        r = s.get(url, headers=headers, timeout=timeout, allow_redirects=allow_redirects)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Embed] GET %s: %s' % (url[:60], e), xbmc.LOGINFO)
        return ''



# Known video host domains — these are playable via our resolvers or ResolveURL
_KNOWN_HOSTS = [
    'streamtape.', 'mixdrop.', 'doodstream.', 'dood.watch',
    'streamvid.', 'vidhide.', 'vidmoly.', 'voe.sx',
    'upstream.to', 'vidlox.', 'highstream.', 'filemoon.',
]


def _is_known_host(url):
    url_lower = url.lower()
    return any(h in url_lower for h in _KNOWN_HOSTS)


def _is_direct_stream(url):
    """True if the URL is a direct playable stream or a known resolvable host."""
    url_lower = url.lower()
    if any(ext in url_lower for ext in ('.m3u8', '.mp4', '.mkv')):
        return True
    return _is_known_host(url)


# ── RiveStream (scrapper.rivestream.app) ─────────────────────────────────────
# rivestream.app itself is a Next.js SPA (no server-rendered content at all)
# whose real media backend is a separate, keyless JSON API reverse-engineered
# from the site's own webpack bundle
# (/_next/static/chunks/pages/_app-*.js — search for "scrapper.rivestream.app"
# in it to re-derive these endpoint shapes if the site ever changes):
#   GET https://scrapper.rivestream.app/api/providers
#     -> {"data": ["primevids","flowcast","asiacloud","citadel","hindicast","guru","ophim"]}
#   GET https://scrapper.rivestream.app/api/provider?provider=<name>&id=<tmdb_id>
#       [&season=<n>&episode=<n>]
#     -> {"data": {"sources": [{"quality":..,"url":..,"source":..,"format":"hls"}], "captions": [...]}}
#          or {"data": null} / {"error": "..."} when that provider has nothing.
# No IMDB support — it's keyed on TMDB id, unlike every other provider in
# this file, so the imdb_id this function receives (kept for signature
# consistency with the rest of embed_sources.py) is resolved to a TMDB id
# via TMDB's own free /find endpoint first (same public TMDB app key already
# used for TMDB lookups elsewhere in this addon).
#
# Confirmed live 2026-08-16 against Inception (tmdb 27205), The Dark Knight
# (155), and Breaking Bad S1E1 (1396): 'citadel' reliably returns a real
# playable HLS manifest (verified with a direct GET on the returned .m3u8 —
# 200, Content-Type application/vnd.apple.mpegurl, real multi-segment
# playlist body) but is dub-only, one audio track per call, labelled in its
# own `quality` field (e.g. "720p (English)", "720p (Hindi)") rather than a
# separate language field. 'ophim' also reliably returns a real HLS manifest
# but is Vietnamese-subtitled only. The other five listed providers
# (primevids, flowcast, asiacloud, hindicast, guru) returned {"data": null}
# or a genuine {"error": "Internal Server Error"} for all three test titles
# above — kept in the provider list rather than dropped (a null/error result
# is just skipped, not fatal) since they read as region/genre-specific
# (hindicast, asiacloud) and may carry content citadel/ophim don't for a
# different title. No bad-extension-disguised filenames seen in any sample —
# every source URL across all three test titles was a clean .m3u8.
#
# Hotlink protection varies by provider: primevids' cdn1.1shows.app stream
# 403'd on a bare GET but returned 200 with Referer: https://www.rivestream.app/
# (confirmed live); citadel's img1.*.com host played fine either way. Rather
# than special-case per provider, every returned URL is pipe-tagged
# 'url|Referer=...' using this codebase's own established convention
# (mythav_sources.py/afdb_router.py/adult_streams.py all do the same) so
# Kodi's native player sends the right header regardless of which provider
# actually needed it.
_RIVESTREAM_API = 'https://scrapper.rivestream.app/api/provider'
_RIVESTREAM_REFERER = 'https://www.rivestream.app/'
# flowcast / hindicast / guru were dropped 2026-09-19: all three returned
# {"data": null} or a 500 for every title tried (Inception, The Dark Knight,
# Breaking Bad S1E1) and only cost a request each. asiacloud/ophim/primevids
# stay but most of what they return is a dead playlist — filtered by the
# liveness check in _rivestream_provider().
_RIVESTREAM_PROVIDERS = (
    'citadel', 'ophim', 'primevids', 'asiacloud',
)
# The site's own JS appends a ~3000s-bucketed cache-buster only for these two
# providers (see movieVideoProvider/tvVideoProvider in the bundle) — matched
# here for parity even though plain requests without it still succeeded live.
_RIVESTREAM_CB_PROVIDERS = ('primevids', 'citadel')
_RIVESTREAM_TMDB_KEY = '1865f43a0549ca50d341dd9ab8b29f49'


def _rivestream_tmdb_id(imdb_id):
    """Resolve an IMDB id to a TMDB movie/tv id via TMDB's free /find endpoint."""
    s = _sess()
    if not s:
        return None
    try:
        r = s.get(
            'https://api.themoviedb.org/3/find/%s' % imdb_id,
            params={'api_key': _RIVESTREAM_TMDB_KEY, 'external_source': 'imdb_id'},
            timeout=8
        )
        fd = r.json()
        hits = fd.get('movie_results') or fd.get('tv_results') or []
        if hits:
            return hits[0].get('id')
    except Exception as e:
        xbmc.log('[Starfleet/Embed] RiveStream TMDB find: %s' % e, xbmc.LOGINFO)
    return None


def _playlist_alive(url):
    """False only when the playlist answers 4xx/5xx with the Referer these
    hosts expect. These are plain HLS playlists, not one-shot signed URLs
    (citadel/primevids re-fetched repeatedly returned 200 each time), so the
    check doesn't consume them. Network errors/timeouts return True."""
    s = _sess()
    if not s:
        return True
    try:
        r = s.get(url, headers={'Referer': _RIVESTREAM_REFERER}, timeout=5, stream=True)
        code = r.status_code
        r.close()
        return code < 400
    except Exception:
        return True


def _rivestream_provider(provider, tmdb_id, media_type, season, episode):
    import json as _json
    import time as _time
    from urllib.parse import quote as _uq
    qs = 'provider=%s&id=%s' % (provider, tmdb_id)
    if media_type == 'tv' and season and episode:
        qs += '&season=%s&episode=%s' % (season, episode)
    if provider in _RIVESTREAM_CB_PROVIDERS:
        qs += '&cb=%d' % int(_time.time() // 3e6)
    url = '%s?%s' % (_RIVESTREAM_API, qs)
    try:
        # Confirmed live 2026-08-28: all 7 providers run in true parallel
        # (one worker each below), so the wall-clock cost of THIS function
        # is bounded by whichever single provider is slowest — and one
        # already-known-unreliable provider timing out at the full 10s here
        # (asiacloud, real "Connection aborted" timeout, not just an empty
        # response) was single-handedly stretching the whole RiveStream
        # call to ~10s even though the other 6 providers (citadel included)
        # had already returned real results in well under a second. Cut to
        # 5s — still generous for any provider that's actually responding,
        # just no longer lets one dead one hold the whole search hostage.
        raw = _get(url, timeout=5)
        if not raw:
            return []
        data = _json.loads(raw)
        payload = data.get('data') or {}
        sources = payload.get('sources') or []
        out = []
        # Confirmed live 2026-08-28: a provider's own 'source'/'quality'
        # fields don't always carry enough detail to tell 2+ real, distinct
        # entries apart (e.g. several alternate-mirror URLs all reported as
        # plain "Citadel"/"720p" with no language or CDN differentiator) —
        # a real user report of "shows fewer results" turned out to be
        # partly this: a picker full of identical-looking "RiveStream
        # [Citadel 720p]" rows reads as padding/duplicates even when the
        # underlying URLs are genuinely different options. Numbering repeat
        # labels (2), (3)... makes clear there's real variety here without
        # needing to know WHY the provider's own labeling collapsed them.
        _label_seen = {}
        for src in sources:
            stream_url = (src.get('url') or '').strip()
            if not stream_url.startswith('http'):
                continue
            if _BAD_EXT_RE.search(stream_url):
                continue
            if not _is_direct_stream(stream_url):
                continue
            quality = src.get('quality', '') or ''
            if not _tq_meets_quality(quality, media_type):
                continue
            norm_q = _tq_extract_quality(quality) or quality
            src_name = src.get('source') or provider.title()
            label = 'RiveStream [%s %s]' % (src_name, norm_q) if norm_q else 'RiveStream [%s]' % src_name
            _label_seen[label] = _label_seen.get(label, 0) + 1
            if _label_seen[label] > 1:
                label = '%s (%d)' % (label, _label_seen[label])
            # Pipe-tagged Referer — primevids' stream host 403s without one
            # (confirmed live); harmless for providers that don't need it.
            tagged_url = '%s|Referer=%s' % (stream_url, _uq(_RIVESTREAM_REFERER, safe=''))
            # Confirmed live 2026-09-19: ophim/primevids/asiacloud mostly hand
            # back playlists that 404 (5 of 6 for Inception), while citadel's
            # were 200 every time — a dead entry in the picker is worse than
            # none. Only a real HTTP error drops a link; a timeout keeps it.
            out.append({'label': label, 'url': tagged_url, '_raw': stream_url})
        if not out:
            return out
        # Checked concurrently so several sources from one provider cost one
        # round trip, not one each.
        from concurrent.futures import ThreadPoolExecutor
        pool = ThreadPoolExecutor(max_workers=len(out))
        try:
            alive = list(pool.map(lambda o: _playlist_alive(o['_raw']), out, timeout=8))
        except Exception:
            alive = [True] * len(out)
        finally:
            pool.shutdown(wait=False)
        kept = []
        for o, ok in zip(out, alive):
            if ok:
                kept.append({'label': o['label'], 'url': o['url']})
            else:
                xbmc.log('[Starfleet/Embed] RiveStream %s: dropping dead playlist' % provider,
                         xbmc.LOGINFO)
        return kept
    except Exception as e:
        xbmc.log('[Starfleet/Embed] RiveStream %s error: %s' % (provider, e), xbmc.LOGINFO)
        return []


def search_rivestream(imdb_id, media_type='movie', season=None, episode=None):
    """RiveStream (rivestream.app) — TMDB-keyed streaming backend hosted at
    scrapper.rivestream.app. See the block comment above for the
    reverse-engineered endpoint shapes and per-provider reliability notes."""
    if not imdb_id or media_type not in ('movie', 'tv'):
        return []
    try:
        tmdb_id = _rivestream_tmdb_id(imdb_id)
        if not tmdb_id:
            return []

        from concurrent.futures import ThreadPoolExecutor, as_completed
        results = []
        with ThreadPoolExecutor(max_workers=len(_RIVESTREAM_PROVIDERS)) as pool:
            futures = {
                pool.submit(_rivestream_provider, p, tmdb_id, media_type, season, episode): p
                for p in _RIVESTREAM_PROVIDERS
            }
            for future in as_completed(futures, timeout=15):
                try:
                    results.extend(future.result())
                except Exception:
                    continue

        xbmc.log('[Starfleet/Embed] RiveStream: %d results for %s (tmdb=%s)' % (
            len(results), imdb_id, tmdb_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] RiveStream error: %s' % e, xbmc.LOGINFO)
        return []


# ── Unified embed search ───────────────────────────────────────────────────────

def search_embed_providers(imdb_id, media_type='movie', season=None, episode=None,
                           title=None, year=None):
    """
    Search the active embed providers in parallel.
    Returns list of {'label': str, 'url': str}.
    Only runs for movie/tv — adult is handled separately.
    All returned URLs are direct HLS playlists that answered 200 — never bare
    embed page URLs. (title/year are accepted for signature compatibility.)

    Live re-audit 2026-09-19 of every provider that used to be in this file
    (Inception tt1375666 / TMDB 27205, Breaking Bad S1E1 as the TV check):
      - autoembed.co: 404.  vidsrc.xyz, moviesapi.club, embed.su, vidsrc.icu,
        2embed.org: no connection at all.
      - vidsrcme.ru / vidsrc.to / 2embed.cc / multiembed.mov: multi-hop
        chains ending in a click-to-load iframe, signed short-lived tokens or a
        base64 `play=` param on streamingnow.mov, plus an anti-devtools script
        — needs real browser JS from hop 2 on.
      - smashystream (-> anyembed.xyz SPA), ridomovies (503 behind
        Cloudflare), flixon.lol (-> webflixs.com SFlix clone).
      - vidlink.pro / vidfast / videasy: Next.js apps whose stream data comes
        from an encrypted API call — nothing extractable from the HTML.
      - MovieBox (aoneroom.com): our request signing is still accepted, but the
        API answers 403 "Service not available in current region" for every
        declared region (US/IN/NG/ID/GB/SG tried) — it's an IP-based block on
        their side, not something a client can work around.
    Added 2026-10-25: site_providers.py reads the backends of VixSrc and MovieNerds (movienerds.site / cineruv.website)
    directly. RiveStream still returns real playlists, and even it
    hands back several dead ones (ophim/primevids/asiacloud playlists mostly
    404) — see _rivestream_provider()'s liveness check.
    """
    if not imdb_id or media_type == 'adult':
        return []
    out = []
    from concurrent.futures import ThreadPoolExecutor

    def _sites():
        # the front-end sites' own backends (VixSrc and MovieNerds: see site_providers.py)
        from starfleetscrapers.movies import site_providers
        tmdb_id = _rivestream_tmdb_id(imdb_id)
        return site_providers.search_sites(tmdb_id, media_type, season, episode) if tmdb_id else []

    def _rive():
        return search_rivestream(imdb_id, media_type, season, episode)

    def _anime():
        # anime sites (AnimeParadise...): only asked for titles that are anime, see anime_providers.py
        from starfleetscrapers.movies import anime_providers
        tmdb_id = _rivestream_tmdb_id(imdb_id)
        return anime_providers.search_anime(tmdb_id, media_type, season, episode) if tmdb_id else []

    pool = ThreadPoolExecutor(max_workers=3)
    try:
        futs = [pool.submit(_sites), pool.submit(_rive), pool.submit(_anime)]
        for f in futs:
            try:
                out.extend(f.result(timeout=20) or [])
            except Exception as e:
                xbmc.log('[Starfleet/Embed] provider failed: %s' % e, xbmc.LOGINFO)
    finally:
        pool.shutdown(wait=False)
    try:                                   # the picture quality of the playlists that do not name it
        from starfleetscrapers.movies import free_quality as _fq
        out = _fq.annotate(out, budget=4.0, probe_hosters=False)
    except Exception as e:
        xbmc.log('[Starfleet/Embed] quality error: %s' % e, xbmc.LOGINFO)
    return out
