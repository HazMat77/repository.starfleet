# -*- coding: utf-8 -*-
"""
movies/free_quality.py

Puts the picture quality on the free sources, the way torrent rows already carry it: "... [1080p]".

A row that already names a quality (1080p, 720p, 4K, CAM ...) is left alone. For the rest:
  1. a direct HLS playlist: its master playlist lists the variants with their RESOLUTION - the largest is the quality;
  2. a hoster / player page: the free Starfleet Resolver opens it (a few seconds, only a handful of rows, never the hosts that
     answer a burst of requests with a captcha) and the playlist it returns is read the same way;
  3. anything else (a plain MP4 whose size is not known, a page that does not open) stays unlabelled - nothing is guessed.

Everything runs in parallel inside a small time budget; what is not known by then simply carries no tag. Answers are kept for ten
minutes. Rows are changed in place and returned.
"""
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urljoin

import xbmc

try:
    from starfleetscrapers.core import http as _req
except ImportError:
    _req = None

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/126.0.0.0 Safari/537.36')

# a quality already named in the label (same words the picker sorts by)
_NAMED = re.compile(r'(?<![A-Za-z0-9])(?:2160p?|4k|uhd|\d{3,4}p|hdcam|hdts|dvdscr|telesync|cam|hd)(?![A-Za-z0-9])', re.I)
# what a hoster page's title / file name says
_T_RES = re.compile(r'(?<![A-Za-z0-9])(2160p?|4k|uhd|1440p|1080[pi]?|720p?|576p|480p|360p|240p)(?![A-Za-z0-9])', re.I)
_T_CAM = re.compile(r'(?<![A-Za-z0-9])(hd-?cam|cam-?rip|cam|hdts|hd-?tc|telesync|telecine|dvdscr|screener)(?![A-Za-z0-9])', re.I)
_T_TITLE = re.compile(r'<title[^>]*>(.*?)</title>|property=["\']og:title["\'][^>]*content=["\']([^"\']+)|'
                      r'content=["\']([^"\']+)["\'][^>]*property=["\']og:title|<h1[^>]*>(.*?)</h1>', re.I | re.S)
_RES = re.compile(r'RESOLUTION=(\d+)x(\d+)', re.I)

# hosts that answer a burst of lookups with a captcha: never opened just to read a quality
_NO_PROBE = ('dood', 'd000d', 'd0000d', 'd0o0d', 'doply', 'playmogo', 'myvidplay', 'vide0.net', 'dsvplay', 'ds2play', 'd-s.io')

_CACHE = {}
_TTL = 600
_MAX_PROBES = 8          # hoster pages opened per search
_PER_HOST = 2


def _log(msg):
    xbmc.log('[Starfleet/Quality] %s' % msg, xbmc.LOGINFO)


def tier(width, height):
    """The quality name for a picture size (width counts too: a 1920x800 film is 1080p)."""
    def by_h(h):
        return 4 if h >= 2000 else 3 if h >= 1000 else 2 if h >= 700 else 1 if h >= 460 else 0
    def by_w(w):
        return 4 if w >= 3400 else 3 if w >= 1800 else 2 if w >= 1200 else 1 if w >= 800 else 0
    t = max(by_h(height or 0), by_w(width or 0))
    if t == 0:
        return '360p' if (height or 0) >= 300 else ('240p' if height else '')
    return ('480p', '720p', '1080p', '4K')[t - 1]


def _split_pipe(url):
    base, _, tail = url.partition('|')
    h = {}
    for kv in tail.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            from urllib.parse import unquote_plus
            h[k] = unquote_plus(v)
    return base, h


def _master_quality(url):
    """Quality named by the master playlist at `url` ('url|Header=..'), or ''."""
    if not _req:
        return ''
    base, h = _split_pipe(url)
    h.setdefault('User-Agent', _UA)
    try:
        r = _req.get(base, headers=h, timeout=6, stream=True)
        try:
            buf = b''
            for chunk in r.iter_content(8192):
                buf += chunk
                if len(buf) > 65536:
                    break
        finally:
            r.close()
        if r.status_code >= 400:
            return ''
        txt = buf.decode('utf-8', 'ignore')
    except Exception:
        return ''
    if not txt.startswith('#EXTM3U'):
        return ''
    best = (0, 0)
    for m in _RES.finditer(txt):
        w, hh = int(m.group(1)), int(m.group(2))
        if (hh, w) > (best[1], best[0]):
            best = (w, hh)
    if best[1]:
        return tier(*best)
    # a media playlist without variants: the first-level child names nothing, but some name the size in the segment path
    m = re.search(r'(?<![0-9])(2160|1440|1080|720|480|360)p?(?![0-9])', txt[:4000])
    return tier(0, int(m.group(1))) if m else ''


def _name_quality(text):
    m = _T_RES.search(text or '')
    if m:
        n = m.group(1).lower().rstrip('pi')
        return {'2160': '4K', '4k': '4K', 'uhd': '4K', '1440': '1080p', '1080': '1080p', '720': '720p', '576': '480p', '480': '480p',
                '360': '360p', '240': '240p'}.get(n, '')
    return 'CAM' if _T_CAM.search(text or '') else ''


def _page_quality(base):
    """Quality named in a hoster page's title / file name (most hosters show the release name), or ''."""
    if not _req:
        return ''
    try:
        r = _req.get(base, headers={'User-Agent': _UA}, timeout=4, stream=True)
        try:
            buf = b''
            for chunk in r.iter_content(8192):
                buf += chunk
                if len(buf) > 40000:
                    break
        finally:
            r.close()
        if r.status_code >= 400:
            return ''
        html = buf.decode('utf-8', 'ignore')
    except Exception:
        return ''
    names = ' '.join(next((g for g in m.groups() if g), '') for m in _T_TITLE.finditer(html))
    return _name_quality(names)


def _is_hls(base):
    return '.m3u8' in base.split('?')[0].lower() or '/playlist/' in base.lower() or 'master' in base.lower().split('?')[0]


def _probe(row, resolve):
    """(quality, row) for one row; '' when unknown."""
    url = row.get('url') or ''
    base = url.split('|')[0]
    if not base.startswith('http'):
        return ''
    hit = _CACHE.get(base)
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    q = ''
    if _is_hls(base):
        q = _master_quality(url)
    elif resolve:
        q = _page_quality(base)
    if not q and resolve and not _is_hls(base):
        try:
            import starfleetresolve as _sfr
            out = _sfr.resolve(base, use_resolveurl=False, debrid_links=False)
        except Exception:
            out = None
        if out and out.split('|')[0] != base and _is_hls(out.split('|')[0]):
            q = _master_quality(out)
    if len(_CACHE) > 400:
        _CACHE.clear()
    _CACHE[base] = (time.time(), q)
    return q


def annotate(rows, budget=6.0, probe_hosters=True):
    """Add " [quality]" to every row that has none and whose quality could be read inside `budget` seconds. Returns `rows`."""
    if not rows or not _req:
        return rows
    todo, per_host, probes = [], {}, 0
    for r in rows:
        if _NAMED.search(r.get('label', '') or ''):
            continue
        base = (r.get('url') or '').split('|')[0]
        if not base.startswith('http'):
            continue
        direct = _is_hls(base)
        if not direct:
            if not probe_hosters or probes >= _MAX_PROBES:
                continue
            host = re.sub(r'^https?://([^/]+).*$', r'\1', base).lower()
            if any(n in host for n in _NO_PROBE) or per_host.get(host, 0) >= _PER_HOST:
                continue
            per_host[host] = per_host.get(host, 0) + 1
            probes += 1
        todo.append(r)
    if not todo:
        return rows
    t0, got = time.time(), 0
    pool = ThreadPoolExecutor(max_workers=min(len(todo), 8))
    try:
        futs = {pool.submit(_probe, r, probe_hosters): r for r in todo}
        try:
            for f in as_completed(futs, timeout=budget):
                try:
                    q = f.result()
                except Exception:
                    continue
                if q:
                    r = futs[f]
                    r['label'] = '%s [%s]' % (r.get('label', ''), q)
                    got += 1
        except Exception:
            pass                           # budget used up: the rest stay unlabelled
    finally:
        pool.shutdown(wait=False)
    _log('%d of %d rows read in %.1fs' % (got, len(todo), time.time() - t0))
    return rows
