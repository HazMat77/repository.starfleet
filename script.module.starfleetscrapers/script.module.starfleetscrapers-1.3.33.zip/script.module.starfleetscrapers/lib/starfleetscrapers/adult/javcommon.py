# -*- coding: utf-8 -*-
"""Shared play-time step of the JAV sites: try the embed hosts a title offers side by side and keep the first one that gives
a stream that really plays. (The sites list 3-8 hosts; going through them one after another meant 20-35 s of waiting on dead or
slow ones.)"""
import xbmc

_MAX_HOSTS = 8
# hosts that have given a real stream, hosts that only hand out token pages (slow, often dead), everything else in between
_GOOD = ('mycloudz.', 'cloudwish.', 'dramiyos', 'vidhide', 'filelions', 'streamwish', 'mixdrop', 'doodstream', 'voe.')
_SLOW = ('javhdz.today', 'savedvids.com', 'turbonewvid', 'playmogo')


def _rank(url):
    u = url.lower()
    if any(h in u for h in _GOOD):
        return 0
    if any(h in u for h in _SLOW):
        return 2
    return 1


def _plays(url, referer=''):
    """True when the stream is a playlist (or file) that answers. Anything that cannot be checked counts as playing."""
    try:
        from starfleetresolve import common
    except Exception:
        return True
    base = url.split('|')[0].lower().split('?')[0]
    if not (base.endswith('.m3u8') or '/hls' in base or 'm3u8' in url.lower()):
        return True
    try:
        from urllib.parse import urlparse
        tries = [url]
        if '|' not in url:                                   # the player hosts check where the request comes from
            for ref in (referer, '%s://%s/' % (urlparse(referer).scheme or 'https', urlparse(referer).netloc)):
                if ref and ref.startswith('http'):
                    tries.append(common.with_headers(url, referer=ref))
        return any(common.playlist_ok(u, timeout=7) for u in tries)
    except Exception:
        return True


def first_playable(candidates, tag, timeout=40):
    """Resolve up to _MAX_HOSTS embed addresses at once; the first that yields a playable stream wins. '' when none does."""
    candidates = sorted([c for c in (candidates or []) if c], key=_rank)[:_MAX_HOSTS]
    if not candidates:
        return ''
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from starfleetscrapers.core import vidhide_bypass
    from starfleetscrapers import hooks as _hk
    _resolvers = _hk.resolvers()

    def one(url):
        direct = ''
        try:
            direct = vidhide_bypass.try_resolve(url) or ''
        except Exception:
            direct = ''
        if not direct:
            try:
                got = _resolvers.resolve(url)
                direct = got if got and got != url else ''
            except Exception as e:
                xbmc.log('[Starfleet/%s] resolver error for %s: %s' % (tag, url[:60], e), xbmc.LOGWARNING)
        if direct and _plays(direct, url):
            return direct
        return ''

    ex = ThreadPoolExecutor(max_workers=len(candidates))
    futs = {ex.submit(one, c): c for c in candidates}
    try:
        for fut in as_completed(futs, timeout=timeout):
            try:
                out = fut.result()
            except Exception:
                out = ''
            if out:
                xbmc.log('[Starfleet/%s] playable via %s' % (tag, futs[fut][:60]), xbmc.LOGINFO)
                return out
    except Exception:
        pass
    finally:
        ex.shutdown(wait=False)
    xbmc.log('[Starfleet/%s] no host gave a playable stream (%d tried)' % (tag, len(candidates)), xbmc.LOGWARNING)
    return ''


# ── the sites' own "Latest Updates" pages ────────────────────────────────────────────────────────────────────────────
#
# javseen.tv and javhd.today list every title in sitemaps, but those sitemaps were last written in March / September 2024: a
# listing built from them shows two-year-old titles as "New". The sites' own Latest Updates page (/recent/) is the real list; it
# fills itself from a JSON feed (the page address plus ?ajax=browse_videos) that carries the cards with their cover pictures and
# how long ago each title was added, so it needs neither a browser nor a detail page per title.

_AGO = {'second': 1, 'minute': 60, 'hour': 3600, 'day': 86400, 'week': 7 * 86400, 'month': 30 * 86400, 'year': 365 * 86400}


def ago_seconds(text):
    """'35 minutes ago' / 'an hour ago' / '3 days ago' -> seconds (0 when it is not a time ago)."""
    import re
    m = re.search(r'(\d+|an?)\s+(second|minute|hour|day|week|month|year)s?\s+ago', text or '', re.I)
    if not m:
        return 0
    n = 1 if m.group(1).lower() in ('a', 'an') else int(m.group(1))
    return n * _AGO[m.group(2).lower()]


def latest_updates(base, source, page=1, timeout=15):
    """The site's newest titles for one page: [{'id', 'slug', 'title', 'thumb', 'fanart', 'plot', 'added_ts', 'source'}], newest
    first ([] when the feed does not answer: the caller falls back to its sitemap)."""
    import html as _html
    import re
    import time
    from starfleetscrapers.core import http as requests
    path = '/recent/' + ('' if page <= 1 else '%d/' % page)
    try:
        r = requests.get(base + path + '?ajax=browse_videos', timeout=timeout, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
            'Referer': base + path, 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json'})
        html = (r.json() or {}).get('html') or ''
    except Exception as e:
        xbmc.log('[Starfleet/JAV] %s latest feed: %s' % (source, str(e)[:80]), xbmc.LOGINFO)
        return []
    now = int(time.time())
    out = []
    for m in re.finditer(r'<li id="video-(\d+)">(.*?)</li>', html, re.S):
        vid, card = m.group(1), m.group(2)
        href = re.search(r'href="/\d+/([^"/]+)/?"', card)
        if not href:
            continue
        title = re.search(r'class="video-title">(.*?)</span>', card, re.S)
        img = re.search(r'<img[^>]+src="([^"]+)"', card)
        ago = ago_seconds(re.sub(r'<[^>]+>', ' ', card))
        quality = re.search(r'video-overlay badge[^>]*>\s*([^<]+?)\s*<', card)
        released = re.search(r'<span class="left">\s*(\d{4}-\d\d-\d\d)', card)
        title = _html.unescape(re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', title.group(1))).strip()) if title else href.group(1)
        bits = []
        if ago:
            bits.append('Added %s' % re.search(r'(?:\d+|an?)\s+\w+\s+ago', re.sub(r'<[^>]+>', ' ', card), re.I).group(0))
        if quality:
            bits.append(re.sub(r'\s+', ' ', quality.group(1)))
        if released:
            bits.append('Released %s' % released.group(1))
        item = {'id': vid, 'slug': href.group(1), 'title': title, 'source': source,
                'added_ts': (now - ago) if ago else 0, 'plot': ' \u2022 '.join(bits)}
        if img:
            item['thumb'] = item['fanart'] = img.group(1)
        out.append(item)
    return out
