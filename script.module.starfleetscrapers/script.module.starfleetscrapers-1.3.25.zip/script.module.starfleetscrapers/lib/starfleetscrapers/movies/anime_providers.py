# -*- coding: utf-8 -*-
"""
movies/anime_providers.py

Anime streaming sites read through their own backends (the calls their web pages make), returning direct HLS playlists:

  AnimeParadise  animeparadise.moe: /search and /anime/<id>/episode on api.animeparadise.moe list the series and its episodes; the
                 watch page's own server action ("getEpisode", its id is read from the site's script) returns the episode's stream
                 address, which stream.animeparadise.moe turns into an HLS playlist (no headers needed).

Only run for titles that are anime (TMDB: animation, made in Japan), so other shows cost nothing. Keyed on the TMDB id the add-on
already has; every link is checked as a real playlist first.
"""
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmc

try:
    from starfleetscrapers.core import http as _req
except ImportError:
    _req = None

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/126.0.0.0 Safari/537.36')
_TMDB_KEY = '1865f43a0549ca50d341dd9ab8b29f49'
_TTL = 3600
_info_cache = {}
_action_cache = {}


def _log(msg):
    xbmc.log('[Starfleet/Anime] %s' % msg, xbmc.LOGINFO)


def _norm(t):
    return re.sub(r'[^a-z0-9]+', ' ', (t or '').lower()).strip()


def tmdb_info(tmdb_id, media_type):
    """{'names': [...], 'is_anime': bool, 'year': int} from TMDB (kept an hour)."""
    key = (tmdb_id, media_type)
    hit = _info_cache.get(key)
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    out = {'names': [], 'is_anime': False, 'year': 0}
    try:
        d = _req.get('https://api.themoviedb.org/3/%s/%s' % ('tv' if media_type == 'tv' else 'movie', tmdb_id),
                     params={'api_key': _TMDB_KEY}, timeout=8).json()
        names = [d.get('name') or d.get('title'), d.get('original_name') or d.get('original_title')]
        out['names'] = [n for n in dict.fromkeys(names) if n]
        genres = {g.get('id') for g in d.get('genres') or []}
        out['is_anime'] = 16 in genres and (d.get('original_language') == 'ja' or 'JP' in (d.get('origin_country') or []))
        out['year'] = int(((d.get('first_air_date') or d.get('release_date') or '0')[:4]) or 0)
        if out['is_anime']:
            out['names'] += [n for n in _anilist_names(out['names'][0], out['year'], media_type) if n not in out['names']]
    except Exception as e:
        _log('tmdb %s: %s' % (tmdb_id, str(e)[:80]))
    _info_cache[key] = (time.time(), out)
    return out


def _anilist_names(title, year, media_type):
    """English / romaji titles and synonyms of the series on AniList (the names anime sites list it under)."""
    q = ('query($s:String){Page(perPage:6){media(search:$s,type:ANIME,sort:SEARCH_MATCH){title{romaji english} synonyms seasonYear '
         'format}}}')
    try:
        media = _req.post('https://graphql.anilist.co', json={'query': q, 'variables': {'s': title}}, timeout=8).json()['data']['Page']['media']
    except Exception:
        return []
    if media_type == 'movie':
        media = [m for m in media if m.get('format') == 'MOVIE'] or media
    pick = next((m for m in media if year and m.get('seasonYear') == year), media[0] if media else None)
    if not pick:
        return []
    t = pick.get('title') or {}
    return [n for n in [t.get('english'), t.get('romaji')] + (pick.get('synonyms') or [])[:3] if n and n.isascii()]


def _alive(url, timeout=8):
    try:
        r = _req.get(url, headers={'User-Agent': _UA}, timeout=timeout, stream=True)
        try:
            head = next(r.iter_content(256), b'')
        finally:
            r.close()
        return r.status_code < 400 and head[:7] == b'#EXTM3U'
    except Exception:
        return False


# ── AnimeParadise ────────────────────────────────────────────────────────────

_AP = 'https://www.animeparadise.moe'
_AP_API = 'https://api.animeparadise.moe'
_AP_ACTION_FALLBACK = '60edb8d72ddf7f3fdfbfc1303642e4829b0825ddef'


def _ap_action_id(watch_url):
    """Id of the site's getEpisode server action: it changes with every deploy, so it is read from the watch page's scripts."""
    hit = _action_cache.get('ap')
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    found = _AP_ACTION_FALLBACK
    try:
        page = _req.get(watch_url, headers={'User-Agent': _UA}, timeout=10).text
        for src in re.findall(r'src="(/_next/static/chunks/[^"]+\.js)"', page):
            js = _req.get(_AP + src, headers={'User-Agent': _UA}, timeout=10).text
            m = re.search(r'createServerReference\)?\("([0-9a-f]{20,})"[^)]*?"getEpisode"', js)
            if m:
                found = m.group(1)
                break
    except Exception as e:
        _log('animeparadise action id: %s' % str(e)[:80])
    _action_cache['ap'] = (time.time(), found)
    return found


def _ap_pick(results, names, season, year):
    """The search hit that is this series (and this season: AnimeParadise lists each season as its own entry)."""
    import difflib
    wanted = [_norm(n) for n in names]
    best, best_score = None, 0
    for r in results:
        t = _norm(r.get('title'))
        for w in wanted:
            if not w:
                continue
            if season and season > 1:
                ok = t == w or re.search(r'(?:season|part|cour)\s*%d\b' % season, t) and t.startswith(w) \
                    or t.startswith(w) and re.search(r'\b%d\b|\b%s\b' % (season, ('ii', 'iii', 'iv', 'v', 'vi')[min(season, 6) - 2]), t[len(w):])
                score = 2 if ok else 0
            else:
                score = 3 if t == w else (2 if difflib.SequenceMatcher(None, t, w).ratio() >= 0.88 else
                                          (1 if t.startswith(w + ' ') and not re.search(r'season|part|movie|ova|special|shippuden|boruto', t[len(w):]) else 0))
            if score > best_score:
                best, best_score = r, score
    return best


def animeparadise(names, media_type, season=None, episode=None, year=0):
    if not names:
        return []
    h = {'User-Agent': _UA}
    results = []
    for q in names[:2]:
        d = _req.get(_AP_API + '/search', params={'q': q}, headers=h, timeout=8).json().get('data') or []
        results = d
        pick = _ap_pick(d, names, season if media_type == 'tv' else None, year)
        if pick:
            break
    else:
        pick = None
    if not pick:
        return []
    eps = _req.get('%s/anime/%s/episode' % (_AP_API, pick['_id']), headers=h, timeout=10).json().get('data') or []
    num = str(episode or 1) if media_type == 'tv' else '1'
    ep = next((e for e in eps if str(e.get('number')) == num), None)
    if not ep:
        return []
    watch = '%s/watch/%s?origin=%s' % (_AP, ep['uid'], pick['_id'])
    m = None
    for attempt in (0, 1):
        action = _action_cache.get('ap', (0, _AP_ACTION_FALLBACK))[1] if attempt == 0 else _ap_action_id(watch)
        hdr = {'User-Agent': _UA, 'Next-Action': action, 'Content-Type': 'text/plain;charset=UTF-8',
               'Accept': 'text/x-component', 'Referer': watch}
        body = _req.post(watch, headers=hdr, data='["%s","%s"]' % (ep['uid'], pick['_id']), timeout=12).text
        m = re.search(r'"streamLink":"([^"]+)"', body)
        if m:
            break
    if not m:
        return []
    url = 'https://stream.animeparadise.moe/m3u8?url=' + m.group(1)
    if not _alive(url):
        return []
    return [{'label': 'AnimeParadise [%s, sub]' % (pick.get('title') or names[0])[:40], 'url': url}]


PROVIDERS = (('animeparadise', animeparadise),)


def search_anime(tmdb_id, media_type='tv', season=None, episode=None, budget=14):
    """[{'label', 'url'}] from every anime site, only when the title is anime."""
    if not _req or not tmdb_id or media_type not in ('movie', 'tv'):
        return []
    info = tmdb_info(tmdb_id, media_type)
    if not info['is_anime']:
        return []
    out = []
    pool = ThreadPoolExecutor(max_workers=len(PROVIDERS))
    try:
        futs = {pool.submit(fn, info['names'], media_type, season, episode, info['year']): name for name, fn in PROVIDERS}
        try:
            for f in as_completed(futs, timeout=budget):
                try:
                    out.extend(f.result() or [])
                except Exception as e:
                    _log('%s: %s' % (futs[f], str(e)[:100]))
        except Exception:
            pass
    finally:
        pool.shutdown(wait=False)
    _log('%d link(s) for %s' % (len(out), info['names'][:1]))
    return out
