# -*- coding: utf-8 -*-
"""Free game replays from the *24all.ir family (nhl24all.ir, mlb24all.ir, nfl24all.ir, nba24all.ir).

The home page of each site embeds its whole catalogue (`var stateshot = {...};`). Finished games keep a
"free.vod.*" flavor; POST api.<domain>/api/v2/generate_stream_info answers with a plain HLS playlist.
Only the few most recent games carry a free replay, so this is a bonus source next to the others in the
Replay section: sources(sport, title) returns [] when the game has none.
"""
import json
import time
from concurrent.futures import ThreadPoolExecutor

from starfleetscrapers.core import http as requests
import xbmc

_DOMAINS = {'nhl': 'nhl24all.ir', 'mlb': 'mlb24all.ir', 'nfl': 'nfl24all.ir', 'nba': 'nba24all.ir'}
_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
_cache = {}


def _log(msg):
    xbmc.log('[Starfleet/Replay] ' + msg, xbmc.LOGINFO)


def _stateshot(domain):
    hit = _cache.get(domain)
    if hit and time.time() - hit[0] < 300:
        return hit[1]
    r = requests.get('https://%s/' % domain, headers={'User-Agent': _UA}, timeout=10)
    text = r.text
    marker = 'var stateshot = {'
    idx = text.find(marker)
    if idx == -1:
        return None
    start = idx + len(marker) - 1
    depth, in_str, esc = 0, False, False
    data = None
    for i in range(start, len(text)):
        c = text[i]
        if in_str:
            if esc:
                esc = False
            elif c == '\\':
                esc = True
            elif c == '"':
                in_str = False
        elif c == '"':
            in_str = True
        elif c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                try:
                    data = json.loads(text[start:i + 1])
                except ValueError:
                    data = None
                break
    if data:
        _cache[domain] = (time.time(), data)
    return data


def _names(teams, tid):
    t = teams.get(tid) or {}
    return [n.lower() for n in (t.get('name'), t.get('short_name')) if n]


def _generate(domain, media_event_id, flavor_id):
    for i in range(2):
        try:
            r = requests.post('https://api.%s/api/v2/generate_stream_info' % domain, timeout=8,
                              json={'media_event_id': media_event_id, 'flavor_id': flavor_id},
                              headers={'User-Agent': _UA, 'Origin': 'https://' + domain, 'Referer': 'https://%s/' % domain})
            d = r.json()
        except Exception:
            return None
        if d.get('url') and not d.get('wait'):
            return d['url']
        if i == 0:
            time.sleep(1.5)
    return None


def sources(sport, title):
    """[{'label', 'url'}] free replay streams for the finished game named by `title` ('Away @ Home', 'A vs B', ...)."""
    domain = _DOMAINS.get(sport)
    if not domain or not title:
        return []
    try:
        data = _stateshot(domain)
    except Exception as e:
        _log('%s replays: %s' % (domain, e))
        return []
    if not data:
        return []
    low = title.lower()
    teams = {t['id']: t for t in data.get('teams', [])}
    vod_flavor = {}
    for f in data.get('flavors', []):
        if f.get('id', '').startswith('free.') and 'vod' in f['id']:
            for me_id in f.get('media_event_ids', []):
                vod_flavor.setdefault(me_id, f['id'])
    if not vod_flavor:
        return []
    jobs = []
    for g in data.get('games', []):
        if g.get('status') != 'F':
            continue
        if not (any(n in low for n in _names(teams, g.get('away_team_id'))) and
                any(n in low for n in _names(teams, g.get('home_team_id')))):
            continue
        for me in data.get('media_events', []):
            if me.get('game_id') == g['id'] and me['id'] in vod_flavor:
                jobs.append((me, vod_flavor[me['id']]))
    if not jobs:
        return []
    with ThreadPoolExecutor(max_workers=min(4, len(jobs))) as ex:
        urls = list(ex.map(lambda j: _generate(domain, j[0]['id'], j[1]), jobs))
    out = []
    for (me, _fid), url in zip(jobs, urls):
        if url:
            out.append({'label': 'Full Game Replay - %s (%s)' % (me.get('title') or 'Stream', domain.split('.')[0].upper()),
                        'url': url})
    return out
