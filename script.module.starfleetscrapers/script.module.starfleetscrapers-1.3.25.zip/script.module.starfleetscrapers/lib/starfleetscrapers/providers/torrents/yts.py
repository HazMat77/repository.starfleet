# -*- coding: utf-8 -*-
"""Starfleet's yts source, for hosts that load a common-layout scraper module."""
from starfleetscrapers.compat.layout import make_source

source = make_source('yts')
