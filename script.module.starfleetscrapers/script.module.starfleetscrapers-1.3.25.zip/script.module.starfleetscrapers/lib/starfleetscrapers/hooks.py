# -*- coding: utf-8 -*-
"""Plug-in points for things only the host add-on has. The host registers factories once at start-up:

    hooks.register(resolvers=lambda: <object with resolve(url) and any_debrid_enabled()>,
                   hosted=lambda: <object with HostedMediaFile(url).valid_url()>,
                   scene_site_registry=lambda: {site key: {...}},
                   search_all_scrapers=lambda title, kind: [...])

Anything not registered falls back to Starfleet Resolver (when installed) or to an empty answer, so the module also
works with no host at all.
"""
_H = {}


def register(**factories):
    _H.update(factories)


class _DefaultResolvers(object):
    @staticmethod
    def resolve(url, *a, **k):
        try:
            import starfleetresolve
            return starfleetresolve.resolve(url) or url
        except Exception:
            return url

    @staticmethod
    def any_debrid_enabled():
        try:
            from starfleetresolve import debrid
            return bool(debrid.authorized())
        except Exception:
            return False


class _DefaultHosted(object):
    class HostedMediaFile(object):
        def __init__(self, url, *a, **k):
            self.url = url

        def valid_url(self):
            try:
                import starfleetresolve
                return bool(starfleetresolve.knows_host(self.url))
            except Exception:
                return False


def resolvers():
    f = _H.get('resolvers')
    return f() if f else _DefaultResolvers


def hosted():
    f = _H.get('hosted')
    return f() if f else _DefaultHosted


def scene_site_registry():
    f = _H.get('scene_site_registry')
    return f() if f else {}


def search_all_scrapers(title, kind=''):
    f = _H.get('search_all_scrapers')
    return f(title, kind) if f else []
