# -*- coding: utf-8 -*-
"""A JAV title is the same film on every JAV site, identified by its product code (SDJS-233, IPZZ-191...). When the site a title
was listed on has no host that plays, the same code is looked up on the other JAV sites and played from there.

resolve_by_code(slug_or_title, skip='javleak') -> a playable address, or ''."""
import re
import threading
import time

import xbmc

_CODE = re.compile(r'(?:^|[^a-z0-9])([a-z]{2,6})[-_ ]?(\d{2,5})(?:[^a-z0-9]|$)', re.IGNORECASE)
_state = threading.local()            # a lookup in progress: the sites it tries must not start lookups of their own


def code_of(text):
    """'sdjs-385-apology-...' / '[SDJS-385] Apology' -> 'sdjs-385' ('' when there is none)."""
    m = _CODE.search((text or '').lower())
    return '%s-%s' % (m.group(1), m.group(2)) if m else ''


def _find_in_sitemap(loader, code):
    for it in loader() or []:
        if code_of(it.get('slug', '')) == code:
            return it
    return None


def _try_mythav(code):
    from urllib.parse import quote
    from starfleetscrapers.adult import mythav
    html = mythav._get('%s/search/?s=%s' % (mythav.MYTHAV_BASE, quote(code)))
    for m in mythav._RE_LATEST_ITEM.finditer(html or ''):
        vid, slug, _title = m.groups()
        if code in slug.lower():
            return mythav.resolve_mythav_stream(vid, slug) or ''
    return ''


def _try_javhd(code):
    from starfleetscrapers.adult import javhd
    it = _find_in_sitemap(javhd._load_latest_all, code)
    return javhd.resolve_javhd_stream(it['id'], it['slug']) if it else ''


def _try_javseen(code):
    from starfleetscrapers.adult import javseen
    it = _find_in_sitemap(javseen._load_latest_all, code)
    return javseen.resolve_javseen_stream(it['id'], it['slug']) if it else ''


def _try_javleak(code):
    from starfleetscrapers.adult import javleak
    it = _find_in_sitemap(javleak._load_latest_all, code)
    return javleak.resolve_javleak_stream(it.get('id', ''), it['slug']) if it else ''


def _try_site(name):
    def fn(code):
        from starfleetscrapers.adult import javsites
        hit = javsites.search_by_code(name, code)
        return javsites.resolve(name, hit[0], hit[1]) if hit else ''
    return fn


_SITES = (('mythav', _try_mythav), ('javguru', _try_site('javguru')), ('javgiga', _try_site('javgiga')),
          ('jav7mm', _try_site('jav7mm')), ('javhd', _try_javhd), ('javseen', _try_javseen), ('javleak', _try_javleak))


def resolve_by_code(slug_or_title, skip=''):
    if getattr(_state, 'active', False):
        return ''
    code = code_of(slug_or_title)
    if not code:
        return ''
    _state.active = True
    started = time.time()
    try:
        for name, fn in _SITES:
            if name == skip:
                continue
            if time.time() - started > 40:                   # a viewer waits for this: stop after the first dead ends
                break
            try:
                url = fn(code)
            except Exception as e:
                xbmc.log('[Starfleet/JAV] %s lookup of %s failed: %s' % (name, code, e), xbmc.LOGWARNING)
                continue
            if url:
                xbmc.log('[Starfleet/JAV] %s played from %s' % (code, name), xbmc.LOGINFO)
                return url
    finally:
        _state.active = False
    return ''
