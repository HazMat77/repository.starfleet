# -*- coding: utf-8 -*-
"""More JAV streaming sites with the same three-function shape as javhd / javseen / javleak / mythav:

    browse_<site>_latest(page)        -> [{'id', 'slug', 'title', 'thumb', 'source'}...]
    get_<site>_detail(vid, slug)      -> {'fanart', 'description'}
    resolve_<site>_stream(vid, slug)  -> a playable address, or ''

Sites: jav.guru (javguru), javgiga.com (javgiga), 7mmtv.sx (jav7mm). Playback hands the embed hosts a title offers to
javcommon.first_playable() and, when none plays, to javcode (the same product code on the other JAV sites).

Not included: missav.ws (Cloudflare browser check), javmost.ws and bestjavporn.com (their players are AES-encrypted by scripts
that change; the same titles are reachable through the sites above by product code)."""
import base64
import html as _html
import re
from urllib.parse import quote_plus, urljoin

import xbmc

from starfleetscrapers import host as _sfhost
from starfleetscrapers.core import cache as _cache

try:
    from starfleetscrapers.debrid import torrent_sources as _ts
except Exception:                                   # pragma: no cover
    _ts = None

PAGE_TTL = 15 * 60
_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
}
_AD_HOSTS = ('mayzaent', 'whitetrafsa', 'realsrv', 'labadena', 'doubleclick', 'googletag', 'facebook', 'twitter', 'histats',
             'pemsrv', 'magsrv', 'exoclick', 'juicyads', 'cloudflare', 'gstatic', 'google', 'jquery', 'schema.org', 'w3.org',
             'gravatar', 'wp.com', 'sexjavhd.site', 'livexcams', '19sex.live')


def _get(url, referer='', timeout=12, session=None):
    try:
        s = session or (_ts._sess() if _ts else None)
        if s is None:
            from starfleetscrapers.core import http as requests
            s = requests
        h = dict(_HEADERS)
        if referer:
            h['Referer'] = referer
        r = s.get(url, headers=h, timeout=timeout, allow_redirects=True)
        if r.status_code != 200:
            return '', r.url
        return r.text, r.url
    except Exception as e:
        xbmc.log('[Starfleet/JAV] %s: %s' % (url[:60], e), xbmc.LOGINFO)
        return '', url


def _clean(t):
    t = re.sub(r'&quots\b', "'s", t or '')                        # 7mmtv writes an apostrophe-s as "&quots"
    t = re.sub(r'&quot(?!;)', '"', t)
    return re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', '', t))).strip()


def _is_ad(u):
    u = u.lower()
    return any(h in u for h in _AD_HOSTS)


def _first_page_items(parse_fn, urls, key):
    ck = '%s_%s' % (key, '|'.join(urls))
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    items = []
    for u in urls:
        html, _final = _get(u)
        if html:
            items += parse_fn(html)
    _cache.set(ck, items or False, PAGE_TTL)
    return items


# ── jav.guru ──────────────────────────────────────────────────────────────────

_GURU = 'https://jav.guru'
_RE_GURU = re.compile(r'<div class="imgg">\s*<a href="(https://jav\.guru/(\d+)/([^"/]+)/)">.*?<img\s+src="([^"]+)"\s+alt="([^"]*)"', re.S)


def _guru_parse(html):
    out, seen = [], set()
    for url, vid, slug, thumb, alt in _RE_GURU.findall(html):
        if vid in seen:
            continue
        seen.add(vid)
        out.append({'id': vid, 'slug': slug, 'title': _clean(alt) or slug, 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    return out


def _guru_candidates(vid, slug):
    url = '%s/%s/%s/' % (_GURU, vid, slug)
    html, _f = _get(url)
    if not html:
        return []
    out = []
    # every server button carries a base64 gateway address; the gateway page hides the real host behind three reversed hex parts
    for b in dict.fromkeys(re.findall(r'"iframe_url":"([A-Za-z0-9+/=]+)"', html)):
        try:
            gate = base64.b64decode(b + '=' * (-len(b) % 4)).decode('utf-8', 'ignore')
        except Exception:
            continue
        if not gate.startswith('http'):
            continue
        page, _final = _get(gate, referer=url)
        attrs = re.findall(r'data-[a-z0-9]{5}="([0-9a-f]+)"', page)
        base = re.search(r"base:\s*'([^']+)'", page)
        rtype = re.search(r"rtype:\s*'([^']+)'", page)
        if len(attrs) < 3 or not base or not rtype:
            continue
        real = '%s?%sr=%s' % (base.group(1), rtype.group(1), ''.join(attrs[:3])[::-1])
        _body, final = _get(real, referer=gate, timeout=10)           # redirects to the host's own embed page
        if final and final.startswith('http') and 'jav.guru' not in final:
            out.append(final)
    return out


# ── javgiga.com ───────────────────────────────────────────────────────────────

_GIGA = 'https://javgiga.com'
_RE_GIGA_ART = re.compile(r'<article\b(.*?)</article>', re.S)


def _giga_parse(html):
    out = []
    for body in _RE_GIGA_ART.findall(html):
        a = re.search(r'<a href="(https://javgiga\.com/([^"/]+)/)"[^>]*title="([^"]*)"', body)
        pid = re.search(r'data-post-id="(\d+)"', body)
        img = re.search(r'data-main-thumb="([^"]+)"', body) or re.search(r'<img[^>]+src="(https?://[^"]+)"', body)
        if not a:
            continue
        thumb = img.group(1) if img else ''
        out.append({'id': pid.group(1) if pid else '', 'slug': a.group(2), 'title': _clean(a.group(3)) or a.group(2), 'thumb': thumb,
                    'poster': thumb, 'fanart': thumb})
    return out


def _giga_candidates(vid, slug):
    url = '%s/%s/' % (_GIGA, slug)
    html, _f = _get(url)
    out = []
    for u in re.findall(r'<iframe[^>]+(?:src|data-src|data-lazy-src)="([^"]+)"', html or ''):
        if u.startswith('//'):
            u = 'https:' + u
        if u.startswith('http') and not _is_ad(u):
            out.append(u)
    return list(dict.fromkeys(out))


# ── 7mmtv.sx ──────────────────────────────────────────────────────────────────

_7MM = 'https://7mmtv.sx'
_RE_7MM = re.compile(r"<a\s+target=\"_top\"\s+href=\"(https://7mmtv\.sx/en/((?:un)?censored|amateurjav|amateur)_content/(\d+)/([^\"/]+)\.html)\"><img[^>]*data-src='([^']+)'[^>]*alt='([^']*)'")


def _7mm_parse(html):
    out, seen = [], set()
    for url, kind, vid, code, thumb, alt in _RE_7MM.findall(html):
        if (kind, vid) in seen:
            continue
        seen.add((kind, vid))
        out.append({'id': '%s:%s' % (kind, vid), 'slug': code, 'title': _clean(alt) or code, 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    return out


def _7mm_url(vid, slug):
    kind, _, num = (vid or '').partition(':')
    return '%s/en/%s_content/%s/%s.html' % (_7MM, kind or 'censored', num or vid, slug)


def _7mm_candidates(vid, slug):
    url = _7mm_url(vid, slug)
    html, _f = _get(url)
    out = []
    for u in re.findall(r'(https?://[^"\'\s<>]+/(?:v|e|embed|d)/[A-Za-z0-9_\-]{6,}[^"\'\s<>]*)', html or ''):
        if not _is_ad(u):
            out.append(u)
    for u in re.findall(r'<iframe[^>]+(?:src|data-src)="(https?://[^"]+)"', html or ''):
        if not _is_ad(u):
            out.append(u)
    return list(dict.fromkeys(out))


# ── site table and the shared functions ───────────────────────────────────────

SITES = {
    'javguru': {'label': 'jav.guru', 'parse': _guru_parse, 'candidates': _guru_candidates,
                'pages': lambda p: ['%s/' % _GURU if p <= 1 else '%s/page/%d/' % (_GURU, p)],
                'search': lambda q: '%s/?s=%s' % (_GURU, quote_plus(q)), 'detail': lambda v, s: '%s/%s/%s/' % (_GURU, v, s)},
    'javgiga': {'label': 'javgiga.com', 'parse': _giga_parse, 'candidates': _giga_candidates,
                'pages': lambda p: ['%s/' % _GIGA if p <= 1 else '%s/page/%d/' % (_GIGA, p)],
                'search': lambda q: '%s/?s=%s' % (_GIGA, quote_plus(q)), 'detail': lambda v, s: '%s/%s/' % (_GIGA, s)},
    'jav7mm': {'label': '7mmtv.sx', 'parse': _7mm_parse, 'candidates': _7mm_candidates,
               'pages': lambda p: ['%s/en/censored_list/all/%d.html' % (_7MM, max(p, 1)), '%s/en/uncensored_list/all/%d.html' % (_7MM, max(p, 1))],
               'search': lambda q: '%s/en/searchform_search/all/index.html?search_keyword=%s' % (_7MM, quote_plus(q)),
               'detail': _7mm_url},
}


def browse(site, page=1):
    cfg = SITES[site]
    items = _first_page_items(cfg['parse'], cfg['pages'](page), 'javsite_%s_p%d' % (site, page))
    for it in items:
        it['source'] = site
    return items


def detail(site, vid, slug):
    html, _f = _get(SITES[site]['detail'](vid, slug))
    if not html:
        return {}
    out = {}
    m = re.search(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', html, re.I)
    if m:
        out['fanart'] = m.group(1)
    m = re.search(r'<meta[^>]+(?:property="og:description"|name="description")[^>]+content="([^"]+)"', html, re.I)
    if m:
        out['description'] = _clean(m.group(1))
    return out


def search_by_code(site, code):
    """(vid, slug) of the title with this product code on `site`, or None."""
    from starfleetscrapers.adult import javcode
    cfg = SITES[site]
    html, _f = _get(cfg['search'](code))
    for it in cfg['parse'](html or ''):
        if javcode.code_of(it['slug']) == code or javcode.code_of(it['title']) == code:
            return it['id'], it['slug']
    return None


def resolve(site, vid, slug):
    from starfleetscrapers.adult import javcommon, javcode
    cands = SITES[site]['candidates'](vid, slug)
    got = javcommon.first_playable(cands, 'JAV-' + site) if cands else ''
    return got or javcode.resolve_by_code(slug, skip=site)


def _make(site):
    def b(page=1):
        return browse(site, page)

    def d(vid, slug):
        return detail(site, vid, slug)

    def r(vid, slug):
        return resolve(site, vid, slug)
    b.__name__, d.__name__, r.__name__ = 'browse_%s_latest' % site, 'get_%s_detail' % site, 'resolve_%s_stream' % site
    return b, d, r


for _site in SITES:
    _b, _d, _r = _make(_site)
    globals()['browse_%s_latest' % _site] = _b
    globals()['get_%s_detail' % _site] = _d
    globals()['resolve_%s_stream' % _site] = _r
