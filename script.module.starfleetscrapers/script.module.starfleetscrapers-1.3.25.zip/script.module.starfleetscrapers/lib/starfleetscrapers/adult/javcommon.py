# -*- coding: utf-8 -*-
"""Shared play-time step of the JAV sites: try the embed hosts a title offers side by side and keep the first one that gives
a stream that really plays. (The sites list 3-8 hosts; going through them one after another meant 20-35 s of waiting on dead or
slow ones.)"""
import xbmc

_MAX_HOSTS = 8
# hosts that have given a real stream, hosts that only hand out token pages (slow, often dead), everything else in between
_GOOD = ('mycloudz.', 'cloudwish.', 'dramiyos', 'vidhide', 'filelions', 'streamwish', 'mixdrop', 'doodstream', 'voe.')
_SLOW = ('javhdz.today', 'savedvids.com', 'turbonewvid', 'playmogo')


def _rank(url):
    u = url.lower()
    if any(h in u for h in _GOOD):
        return 0
    if any(h in u for h in _SLOW):
        return 2
    return 1


def _plays(url, referer=''):
    """True when the stream is a playlist (or file) that answers. Anything that cannot be checked counts as playing."""
    try:
        from starfleetresolve import common
    except Exception:
        return True
    base = url.split('|')[0].lower().split('?')[0]
    if not (base.endswith('.m3u8') or '/hls' in base or 'm3u8' in url.lower()):
        return True
    try:
        from urllib.parse import urlparse
        tries = [url]
        if '|' not in url:                                   # the player hosts check where the request comes from
            for ref in (referer, '%s://%s/' % (urlparse(referer).scheme or 'https', urlparse(referer).netloc)):
                if ref and ref.startswith('http'):
                    tries.append(common.with_headers(url, referer=ref))
        return any(common.playlist_ok(u, timeout=7) for u in tries)
    except Exception:
        return True


def first_playable(candidates, tag, timeout=40):
    """Resolve up to _MAX_HOSTS embed addresses at once; the first that yields a playable stream wins. '' when none does."""
    candidates = sorted([c for c in (candidates or []) if c], key=_rank)[:_MAX_HOSTS]
    if not candidates:
        return ''
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from starfleetscrapers.core import vidhide_bypass
    from starfleetscrapers import hooks as _hk
    _resolvers = _hk.resolvers()

    def one(url):
        direct = ''
        try:
            direct = vidhide_bypass.try_resolve(url) or ''
        except Exception:
            direct = ''
        if not direct:
            try:
                got = _resolvers.resolve(url)
                direct = got if got and got != url else ''
            except Exception as e:
                xbmc.log('[Starfleet/%s] resolver error for %s: %s' % (tag, url[:60], e), xbmc.LOGWARNING)
        if direct and _plays(direct, url):
            return direct
        return ''

    ex = ThreadPoolExecutor(max_workers=len(candidates))
    futs = {ex.submit(one, c): c for c in candidates}
    try:
        for fut in as_completed(futs, timeout=timeout):
            try:
                out = fut.result()
            except Exception:
                out = ''
            if out:
                xbmc.log('[Starfleet/%s] playable via %s' % (tag, futs[fut][:60]), xbmc.LOGINFO)
                return out
    except Exception:
        pass
    finally:
        ex.shutdown(wait=False)
    xbmc.log('[Starfleet/%s] no host gave a playable stream (%d tried)' % (tag, len(candidates)), xbmc.LOGWARNING)
    return ''
