# -*- coding: utf-8 -*-
"""Adapters between Starfleet Scrapers and other scraper modules.

layout.py       lets add-ons that load a scraper module the common way (they import the module's package,
             call sources(specified_folders=['torrents']) and run each provider's source().sources(data, hostDict))
             use Starfleet's torrent sources.
external.py  the other direction: runs any installed module that follows that convention (common-layout packs and
             the like) from inside Starfleet and merges what they find with Starfleet's own results.
"""
