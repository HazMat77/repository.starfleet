# -*- coding: utf-8 -*-
"""Starfleet's torrent sources, presented in the shape host add-ons that use a common-layout scraper module expect.

Such a host imports this package (starfleetscrapers), calls sources(specified_folders=['torrents']) and gets a list of
(provider name, source class). It then calls  source().sources(data, hostDict)  with
    data = {'title', 'year', 'imdb', 'aliases', 'premiered'}                                   for a movie
         = {'tvshowtitle', 'title' (episode title), 'year', 'imdb', 'season', 'episode', ...}  for an episode
and expects a list of dicts:
    {'provider', 'source': 'torrent', 'seeders', 'hash', 'name', 'name_info', 'quality', 'language', 'url' (magnet),
     'info', 'direct': False, 'debridonly': True, 'size' (float, GB)}
make_source(key) builds that class around one of Starfleet's search_<key> functions."""
import base64
import inspect
from concurrent.futures import ThreadPoolExecutor
import re
import threading
import time

# search functions that need an account, are adult-only or are not meant for a general movie/TV host
EXCLUDE = {'all', 'xxxclub', 'rintor', 'xxxtor', 'freejavtorrent', 'ijavtorrent', 'bitporn', 'sukebei_nyaa', 'podzemlje',
           'telegram_bot', 'torrenthunt_bot', 'publicdomaintorrents'}
# the fast, reliable core that is switched on out of the box (everything else is one tick away in the settings)
CORE = ('comet', 'torz', 'dmm', 'bitmagnet', 'torrentdownloads', 'anime')

_QUALITY = (('4K', ('2160', '216o', '4k', 'uhd')), ('1080p', ('1080', '1o8o', 'fhd')), ('720p', ('720', '72o')),
            ('SD', ('480', '576', '360', 'dvd', 'sd')))


def file_name(key):
    """Module file name for a provider key (a module name cannot start with a digit)."""
    return 'x' + key if key[0].isdigit() else key


def _quality(text):
    t = (text or '').lower()
    for label, keys in _QUALITY:
        if any(k in t for k in keys):
            return label
    if any(k in t for k in ('cam', 'telesync', 'hdts', 'tsrip')):
        return 'CAM'
    return 'SD'


def _gb(size):
    if isinstance(size, str) and size.strip().replace('.', '', 1).isdigit():
        size = float(size)
    if isinstance(size, (int, float)):
        return round(size / 1073741824.0, 2) if size > 1000 else float(size)
    m = re.search(r'([\d.,]+)\s*(TB|GB|GiB|MB|MiB)', str(size or ''), re.I)
    if not m:
        return 0
    v = float(m.group(1).replace(',', ''))
    u = m.group(2).lower()
    return round(v * 1024 if u == 'tb' else v if u in ('gb', 'gib') else v / 1024.0, 2)


def name_info(name):
    """The release name the way hosts read quality / HDR / codec tags from it: lower case, dot separated."""
    return '.' + re.sub(r'[^a-z0-9]+', '.', (name or '').lower()).strip('.') + '.'


# words that may follow a title in a release name without making it a different title ("Matrix Reloaded")
_TAGS = set('''2160p 1080p 720p 576p 480p 360p 4k uhd hd fhd sd bluray blu ray bdrip brrip bdremux remux webrip web dl webdl hdrip
    hdtv dvdrip dvd dvdscr cam ts tc hdcam x264 x265 h264 h265 hevc avc xvid divx hdr hdr10 dv dovi dolby vision proper repack
    extended unrated uncut imax remastered restored theatrical directors director cut final edition special collectors multi
    dual dubbed subbed subs english eng german french italian spanish latin russian hindi korean japanese chinese nf amzn dsnp
    hmax atvp max hulu pcok atmos truehd dts aac ac3 ddp ddp5 flac hybrid open matte'''.split())
_RE_YEAR = re.compile(r'(?<!\d)(19|20)\d{2}(?!\d)')
_RE_YEAR_RANGE = re.compile(r'(?<!\d)(19|20)\d{2}\s*[-–]\s*(19|20)\d{2}(?!\d)')
_RE_EP = re.compile(r's0*(\d{1,2})[\s._-]*e0*(\d{1,3})(?!\d)', re.IGNORECASE)
_RE_SEASONS = re.compile(r'\bs(?:easons?)?[\s._-]*0*(\d{1,2})(?:[\s._-]*(?:-|to|&|\+)[\s._-]*s?(?:easons?)?[\s._-]*0*(\d{1,2}))?(?!\d)',
                         re.IGNORECASE)
_RE_COMPLETE = re.compile(r'complete|collection|all[\s._-]*seasons|the[\s._-]*series|box[\s._-]*set|integral|anthology', re.IGNORECASE)
_RE_LEAD = re.compile(r'^(?:[\[(][^\])]*[\])][\s._-]*)+')


def _words(text):
    return re.sub(r'[^a-z0-9]+', ' ', (text or '').lower()).split()


def _phrase_kept(names, title, movie):
    """Indexes of the release names that carry the title: Starfleet's phrase matcher run once over the whole list (building its
    pattern per name made this the slowest step on a weak device)."""
    from starfleetscrapers.debrid import torrent_sources as ts
    if not title or not names:
        return set()
    kept = ts.filter_by_title_and_episode([{'title': n, '_i': i} for i, n in enumerate(names)], title, 'movie' if movie else 'tv')
    return {k['_i'] for k in kept}


def _title_ok(name, title, year, item_year, movie, phrase_ok=None):
    """The result is for this title: Starfleet's own phrase matcher (`phrase_ok` when the caller has already run it over the
    whole list), plus the movie rules (year, no sequel word, not a TV release or a multi-film collection)."""
    if phrase_ok is None:
        phrase_ok = bool(_phrase_kept([name], title, movie))
    if not phrase_ok:
        return False
    if not movie:
        return True
    if _RE_EP.search(name) or _RE_YEAR_RANGE.search(name):
        return False
    years = {m.group(0) for m in _RE_YEAR.finditer(name)} | ({str(item_year)} if item_year else set())
    try:
        want = int(year)
    except (TypeError, ValueError):
        want = 0
    if want and years and not any(abs(int(y) - want) <= 1 for y in years):
        return False
    t = _words(title)
    w = _words(_RE_LEAD.sub('', name))
    for i in range(len(w) - len(t) + 1):
        if w[i:i + len(t)] == t:
            nxt = w[i + len(t):i + len(t) + 1]
            if nxt and nxt[0].isalpha() and len(nxt[0]) > 2 and nxt[0] not in _TAGS:
                return False
            break
    return True


def pack_kind(name, season):
    """('', 0) for a single episode or an unrelated season; ('season', n) a pack of the wanted season;
    ('show', last season) a multi-season pack that includes it."""
    if _RE_EP.search(name) or re.search(r'\bepisodes?[\s._-]*0*\d', name, re.IGNORECASE):
        return '', 0
    spans = []
    for m in _RE_SEASONS.finditer(name):
        a = int(m.group(1))
        b = int(m.group(2)) if m.group(2) else a
        if 0 < a <= b < 100:
            spans.append((a, b))
    if spans:
        lo = min(a for a, _b in spans)
        hi = max(b for _a, b in spans)
        if hi > lo:
            return ('show', hi) if lo <= int(season) <= hi else ('', 0)
        return ('season', lo) if lo == int(season) else ('', 0)
    if _RE_COMPLETE.search(name):
        return 'show', 99
    return '', 0


def to_layout(item, provider):
    """One Starfleet result -> a common-layout source dict (or None when it has no usable hash)."""
    ih = (item.get('info_hash') or '').lower()
    magnet = item.get('magnet') or ''
    if not ih:
        m = re.search(r'btih:([0-9a-fA-F]{40}|[A-Za-z2-7]{32})', magnet)
        ih = m.group(1).lower() if m else ''
    if len(ih) == 32:                       # base32 info-hash -> the 40-character hex form hosts check against debrid
        try:
            ih = base64.b32decode(ih.upper()).hex()
        except Exception:
            ih = ''
    if len(ih) != 40:
        return None
    name = item.get('title') or ''
    size = _gb(item.get('size')) or _gb(name)
    try:
        seeders = int(item.get('seeds') or 0)
    except (TypeError, ValueError):
        seeders = 0
    quality = _quality(item.get('quality') or name)
    info = ' | '.join(x for x in ('%.2f GB' % size if size else '', item.get('quality') or '') if x)
    return {'provider': provider, 'source': 'torrent', 'seeders': seeders, 'hash': ih, 'name': name, 'name_info': name_info(name),
            'quality': quality, 'language': 'en', 'url': magnet or 'magnet:?xt=urn:btih:%s&dn=%s' % (ih, name),
            'info': info, 'direct': False, 'debridonly': True, 'size': size}


# API-style sources (one cheap call, the whole list comes back) are not capped; page-scraping sources are, because each
# extra result can cost another page request
API_LIMIT = 3000
SCRAPE_LIMIT = 60
# how long a host waits for one provider: an id-based aggregator answers from one request, a site scraper may need several pages
API_BUDGET = 8.0
SCRAPE_BUDGET = 5.0


def _call(fn, data, limit=None, pack=''):
    """Call a Starfleet search function the way its signature wants it. pack = 'season' / 'show' asks a name-search source
    for the pack instead of the one episode."""
    params = list(inspect.signature(fn).parameters)
    if limit is None:
        limit = API_LIMIT if ('imdb_id' in params and 'season' in params) or fn.__name__ in ('search_dmm', 'search_knaben', 'search_tpb') else SCRAPE_LIMIT
    try:
        from starfleetscrapers.core import device as _device
        limit = min(limit, _device.knob('per_source'))     # a weak device keeps fewer results per source
    except Exception:
        pass
    tv = 'tvshowtitle' in data
    title = data.get('tvshowtitle') if tv else data.get('title')
    year = data.get('year')
    imdb = data.get('imdb')
    season, episode = (int(data['season']), int(data['episode'])) if tv else (None, None)
    mt = 'tv' if tv else 'movie'
    if tv and pack == 'season':
        query = '%s S%02d' % (title, season)
    elif tv and pack == 'show':
        query = '%s complete series' % title
    else:
        query = '%s S%02dE%02d' % (title, season, episode) if tv else title
    args = []
    for p in params:
        if p == 'title':
            args.append(query)
        elif p == 'year':
            args.append(None if tv else year)
        elif p == 'imdb_id':
            args.append(imdb)
        elif p == 'season':
            args.append(season)
        elif p == 'episode':
            args.append(episode)
        elif p == 'media_type':
            args.append(mt)
        elif p in ('limit', 'max_per_source'):
            args.append(limit)
        elif p == 'category':
            args.append(205 if tv else 207)
        else:
            args.append(None)
    return fn(*args) or []


# a host asks one source for the episode and then, in a second call, for its packs: the id-based sources answer both from
# the same list, so the list is kept for a couple of minutes instead of being fetched twice
_RAW = {}
_RAW_LOCK = threading.Lock()
_RAW_TTL = 180


def _raw(key, fn, data, pack=''):
    id_based = 'imdb_id' in inspect.signature(fn).parameters
    ck = (key, data.get('imdb') or data.get('tvshowtitle') or data.get('title'), data.get('season'), data.get('episode'),
          '' if id_based else pack)
    now = time.time()
    with _RAW_LOCK:
        hit = _RAW.get(ck)
        if hit and now - hit[0] < _RAW_TTL:
            return hit[1]
    items = _call(fn, data, pack=pack)
    with _RAW_LOCK:
        for k in [k for k, v in _RAW.items() if now - v[0] >= _RAW_TTL]:
            _RAW.pop(k, None)
        _RAW[ck] = (now, items)
    return items


# YTS lists films only, EZTV episodes only
MOVIES_ONLY = {'yts'}
EPISODES_ONLY = {'eztv'}
# these number episodes in ways other than S01E01 (absolute numbers, bare numbers), so a missing marker is not a reject
LOOSE_EPISODES = {'anime', 'nyaa', 'animetosho', 'bitlord'}


def make_source(key):
    """The common-layout `source` class for Starfleet's search_<key>."""
    class source(object):
        priority = 1
        pack_capable = key not in MOVIES_ONLY
        hasMovies = key not in EPISODES_ONLY
        hasEpisodes = key not in MOVIES_ONLY
        language = ['en']

        def __init__(self):
            self.provider = key

        def _search(self, data, pack=''):
            from starfleetscrapers.debrid import torrent_sources as ts
            fn = getattr(ts, 'search_' + key, None)
            if fn is None or not data:
                return []
            if 'tvshowtitle' not in data and not (data.get('title') or data.get('imdb')):
                return []
            budget = API_BUDGET if 'imdb_id' in inspect.signature(fn).parameters else SCRAPE_BUDGET
            ex = ThreadPoolExecutor(max_workers=1)
            fut = ex.submit(_raw, key, fn, data, pack)
            ex.shutdown(wait=False)
            try:
                return fut.result(timeout=budget)
            except Exception:
                return []

        def sources(self, data, hostDict=None):
            tv = bool(data) and 'tvshowtitle' in data
            title = (data or {}).get('tvshowtitle' if tv else 'title')
            out, seen = [], set()
            laid = []
            for it in self._search(data):
                d = to_layout(it, key)
                if d and d['hash'] not in seen:
                    seen.add(d['hash'])
                    laid.append((it, d))
            kept = _phrase_kept([d['name'] for _it, d in laid], title, not tv)
            seen = set()
            for n, (it, d) in enumerate(laid):
                if not _title_ok(d['name'], title, (data or {}).get('year'), it.get('year'), not tv, phrase_ok=n in kept):
                    continue
                if tv:
                    try:
                        s, e = int(data['season']), int(data['episode'])
                    except (TypeError, ValueError):
                        continue
                    marks = _RE_EP.findall(d['name'])
                    if marks:
                        if not any(int(a) == s and int(b) == e for a, b in marks):
                            continue
                    elif key not in LOOSE_EPISODES or pack_kind(d['name'], s)[0]:
                        continue
                seen.add(d['hash'])
                out.append(d)
            return out

        def sources_packs(self, data, hostDict=None, search_series=False, total_seasons=None, bypass_filter=False):
            if not data or 'tvshowtitle' not in data:
                return []
            try:
                season = int(data['season'])
            except (TypeError, ValueError):
                return []
            want = 'show' if search_series else 'season'
            title = data.get('tvshowtitle')
            out, seen = [], set()
            laid, have = [], set()
            for it in self._search(data, want):
                d = to_layout(it, key)
                if d and d['hash'] not in have:
                    have.add(d['hash'])
                    laid.append((it, d))
            kept = _phrase_kept([d['name'] for _it, d in laid], title, False)
            for n, (it, d) in enumerate(laid):
                if d['hash'] in seen or not _title_ok(d['name'], title, None, None, False, phrase_ok=n in kept):
                    continue
                kind, last = pack_kind(d['name'], season)
                if kind != want:
                    continue
                d['package'] = kind
                if kind == 'season':
                    d['episode_start'], d['episode_end'] = 1, 9999
                else:
                    d['last_season'] = last
                seen.add(d['hash'])
                out.append(d)
            return out

    source.__name__ = 'source'
    return source



def available_keys():
    from starfleetscrapers.debrid import torrent_sources as ts
    return sorted(n[7:] for n in dir(ts) if n.startswith('search_') and n[7:] not in EXCLUDE and callable(getattr(ts, n)))
