# -*- coding: utf-8 -*-
"""Drop releases whose audio is a foreign dub (Russian first of all) from movie / TV results.

A release name tells which languages its audio carries, sometimes in words (RUSSIAN, GERMAN, TRUEFRENCH) and sometimes only in
the script it is written in (a Cyrillic title). Reading it takes three rules:

  * a language word / tag in the name marks the release as that language,
  * English (or MULTI) audio listed next to it rescues the release - "RUS.ENG", "Multi", "Dual Audio English" are all fine,
  * "<language> subs" / "eng subs" name a subtitle track, not audio, so they count for neither side.

Setting 'foreign_filter' (module setting read through the host add-on): '0' off, '1' Russian and Ukrainian only (the default),
'2' every dubbed language. Anime is never passed through this (its releases are matched by anime_sources).

keep(title) -> bool;   filter_results(results) -> the results that stay.
"""
import re

from starfleetscrapers import host as _sfhost

_CYRILLIC = re.compile(u'[Ѐ-ӿ]')

# audio languages that are never what an English viewer wants from a Western movie / series
# Russian / Ukrainian dub tags and release groups: a release carrying one of these has Russian audio
_RUSSIAN_STRONG = {'russian', 'rus', 'ukrainian', 'ukr', 'rusdub', 'lostfilm', 'newstudio', 'hdrezka', 'kubik', 'baibako',
                   'alexfilm', 'jaskier', 'amedia', 'kerob'}
_OTHER = {'german', 'deutsch', 'ger', 'french', 'truefrench', 'vff', 'vfq', 'vfi', 'italian', 'ita', 'spanish', 'castellano',
          'latino', 'polish', 'lektor', 'pldub', 'czech', 'turkish', 'portuguese', 'dublado', 'hungarian', 'hun', 'swedish',
          'norwegian', 'danish', 'finnish', 'dutch', 'greek', 'thai', 'arabic', 'hebrew', 'romanian', 'bulgarian', 'serbian',
          'croatian', 'ukrainiandub'}
_ENGLISH = {'eng', 'english', 'multi', 'multilang', 'multilingual', 'multiaudio', 'dualaudio'}

# "eng subs", "subs eng", "rus sub", "multi subs": a subtitle track, not an audio language
_SUB_AFTER = re.compile(r'\b([a-z]{2,10})[ ._+\-]*(?:sub|subs|subbed|subtitle|subtitles|hardsub|hc)\b')
_SUB_BEFORE = re.compile(r'\b(?:sub|subs|subbed|subtitle|subtitles|hardsub|hc)[ ._+\-:]*([a-z]{2,10})\b')


def _mode():
    try:
        v = (_sfhost.addon().getSetting('foreign_filter') or '').strip()
    except Exception:
        v = ''
    return v if v in ('0', '1', '2') else '1'


def mode():
    return _mode()


def _clean(name):
    low = (name or '').lower()
    low = re.sub(r'[\[\]\(\)\{\}_,;/|]+', ' ', low)
    return low


def keep(title, mode_value=None, ignore=()):
    m = mode_value if mode_value is not None else _mode()
    if m == '0' or not title:
        return True
    low = _clean(title)
    # drop subtitle mentions before looking for audio languages
    low = _SUB_AFTER.sub(' ', low)
    low = _SUB_BEFORE.sub(' ', low)
    tokens = set(re.findall(r'[a-z0-9]+', low)) - set(ignore)      # words of the searched title (Russian Doll) are not an audio tag
    # glued spellings: "dual audio" / "multi audio"
    if re.search(r'\bdual[ ._\-]?audio\b', low) or re.search(r'\bmulti[ ._\-]?(?:audio|lang\w*)\b', low):
        tokens.add('multi')
    if tokens & _ENGLISH:
        return True
    cyr = len(_CYRILLIC.findall(title))
    if cyr >= 3:
        return False
    if tokens & _RUSSIAN_STRONG:
        return False
    if m == '2':
        if tokens & _OTHER:
            return False
        if 'dub' in tokens and tokens & {'ru', 'pl', 'de', 'fr', 'es', 'it', 'pt', 'tr'}:
            return False
    elif 'dub' in tokens and 'ru' in tokens:
        return False
    return True


def filter_results(results, query_title=''):
    """The results whose release name does not carry foreign-dub audio (all of them when the filter is off).
    Words of the searched title itself are never taken as a language tag ("Russian Doll", "The German Doctor")."""
    m = _mode()
    if m == '0':
        return results
    ignore = set(re.findall(r'[a-z0-9]+', (query_title or '').lower()))
    return [r for r in results if keep(r.get('title') or r.get('name') or '', m, ignore)]
