# -*- coding: utf-8 -*-
"""What a release really is, read from its name: HDR / Dolby Vision / Atmos tags, and "4K" releases that are only upscaled.

annotate(rows) adds a short badge string to each stream row's label ("4K  DV · HDR10 · Atmos") and moves rows that are likely to
disappoint (an upscaled "4K", Dolby Vision only on a display that cannot show it) to the end. The viewer says whether the
display does Dolby Vision in the add-on settings (device_dv: 0 = unknown, 1 = yes, 2 = no); unknown changes nothing.
"""
import re
from urllib.parse import unquote

from starfleetscrapers import host as _host

_UPSCALE = re.compile(r'up[\s._-]?scal|\bupsc\b|a\.?i[\s._-]?(?:upscale|enhanc|remaster)|fake[\s._-]?4k|ai[\s._-]?restor', re.I)
_DV = re.compile(r'(?<![a-z0-9])(?:dolby[\s._-]?vision|dovi|dv)(?![a-z0-9])', re.I)
_HDR10P = re.compile(r'hdr[\s._-]?10[\s._-]?(?:\+|plus|p)(?![a-z0-9])', re.I)
_HDR10 = re.compile(r'hdr[\s._-]?10(?![\d+])', re.I)
_HDR = re.compile(r'(?<![a-z0-9])hdr(?![a-z0-9])', re.I)
_ATMOS = re.compile(r'atmos', re.I)
_TRUEHD = re.compile(r'true[\s._-]?hd', re.I)
_DTSX = re.compile(r'dts[\s._-]?x(?![a-z0-9])', re.I)
_DTSHD = re.compile(r'dts[\s._-]?hd', re.I)
_REMUX = re.compile(r'remux', re.I)
_4K = re.compile(r'2160p?|216o|(?<![a-z0-9])4k(?![a-z0-9])|uhd', re.I)


def parse(name):
    n = name or ''
    hdr = []
    dv = bool(_DV.search(n))
    if dv:
        hdr.append('DV')
    if _HDR10P.search(n):
        hdr.append('HDR10+')
    elif _HDR10.search(n):
        hdr.append('HDR10')
    elif _HDR.search(n):
        hdr.append('HDR')
    audio = []
    if _ATMOS.search(n):
        audio.append('Atmos')
    elif _TRUEHD.search(n):
        audio.append('TrueHD')
    elif _DTSX.search(n):
        audio.append('DTS:X')
    elif _DTSHD.search(n):
        audio.append('DTS-HD')
    return {'hdr': hdr, 'dv': dv, 'dv_only': dv and not any(h.startswith('HDR') for h in hdr), 'audio': audio,
            'remux': bool(_REMUX.search(n)), 'is4k': bool(_4K.search(n)), 'upscaled': bool(_UPSCALE.search(n))}


def _name(row):
    if row.get('name'):
        return row['name']
    url = row.get('url') or ''
    if url.startswith('magnet:'):
        m = re.search(r'[?&]dn=([^&]+)', url)
        if m:
            return unquote(m.group(1).replace('+', ' '))
    return ''


def _device_dv():
    try:
        return (_host.addon().getSetting('device_dv') or '0').strip()
    except Exception:
        return '0'


def annotate(rows):
    if not rows:
        return rows
    dv_support = _device_dv()
    flagged = set()
    for i, r in enumerate(rows):
        try:
            info = parse(_name(r))
        except Exception:
            continue
        badges = list(info['hdr']) + list(info['audio'])
        if info['remux']:
            badges.append('REMUX')
        if info['is4k'] and info['upscaled']:
            badges.append('upscaled?')
            flagged.add(i)
        if info['dv_only'] and dv_support == '2':
            badges.append('needs Dolby Vision display')
            flagged.add(i)
        if badges and isinstance(r.get('label'), str):
            r['label'] = '%s  %s' % (r['label'], ' · '.join(badges))
            r['badges'] = badges
    if flagged:
        rows = [r for i, r in enumerate(rows) if i not in flagged] + [r for i, r in enumerate(rows) if i in flagged]
    return rows
