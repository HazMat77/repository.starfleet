# -*- coding: utf-8 -*-
"""The host add-on seen from the scrapers.

The scrapers run inside some add-on (Starfleet, or any other that chooses to use this module). Everything they need from
that add-on goes through here, so none of them import a host's files directly:

    host.addon()               the add-on whose settings apply (the host's, else this module's own)
    host.profile()             the data folder (caches, cookies): the host's when there is one, else this module's own
    host.module(name)          a module the host provides (metadata, its debrid layer, ...), loaded when first used
    host.func(name, attr)      a function of such a module, resolved when called

A host registers itself once at start-up:  host.register(addon_id='plugin.video.xyz', package='xyz.lib')
With no host registered, host.module() gives an empty stand-in: asking it for something returns None / does nothing, so
a scraper that wants optional host features simply skips them.
"""
import importlib

import xbmcaddon
import xbmcvfs

from starfleetscrapers.core.env import ADDON as _OWN, PROFILE as _PROFILE

_host = {'addon_id': None, 'package': None}


def register(addon_id=None, package=None):
    _host['addon_id'] = addon_id or _host['addon_id']
    _host['package'] = package or _host['package']


def addon():
    if _host['addon_id']:
        try:
            return xbmcaddon.Addon(_host['addon_id'])
        except Exception:
            pass
    return _OWN


def profile():
    """The data folder to use: the host's own (so scrapers and host share one cache file), else this module's."""
    if _host['addon_id']:
        try:
            return xbmcvfs.translatePath(xbmcaddon.Addon(_host['addon_id']).getAddonInfo('profile'))
        except Exception:
            pass
    return _PROFILE


class _Missing(object):
    """Stand-in for a host module that is not there: every attribute is a function that returns None."""
    def __init__(self, name):
        self._name = name

    def __getattr__(self, attr):
        if attr.startswith('__'):
            raise AttributeError(attr)
        return lambda *a, **k: None

    def __bool__(self):
        return False


class _Lazy(object):
    """Loads the host module on first attribute access (the host may not be ready when a scraper is imported)."""
    def __init__(self, name):
        object.__setattr__(self, '_name', name)
        object.__setattr__(self, '_mod', None)

    def _load(self):
        mod = object.__getattribute__(self, '_mod')
        if mod is None:
            pkg = _host['package']
            try:
                mod = importlib.import_module('%s.%s' % (pkg, object.__getattribute__(self, '_name'))) if pkg else None
            except Exception:
                mod = None
            if mod is None:
                mod = _Missing(object.__getattribute__(self, '_name'))
            object.__setattr__(self, '_mod', mod)
        return mod

    def __getattr__(self, attr):
        return getattr(self._load(), attr)


def module(name):
    return _Lazy(name)


def func(name, attr):
    mod = _Lazy(name)

    def call(*a, **k):
        return getattr(mod, attr)(*a, **k)
    call.__name__ = attr
    return call
