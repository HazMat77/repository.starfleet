# -*- coding: utf-8 -*-
"""Adaptive-bitrate helpers for Replay playback.

What the replay hosts offer (checked live):
    OK.ru        five MP4 renditions (mobile 144p .. hd 720p) AND an HLS master (240p/360p/480p/720p).
    Dailymotion  an HLS master with several renditions (the player metadata API's "auto" entry).
    playmate.to  a single 1080p HLS variant (nothing to adapt).
    Brightcove   one 720p MP4 (NHL recaps).

So OK.ru and Dailymotion are played as HLS and inputstream.adaptive switches rendition on its own as the
connection changes. When HLS is not usable (setting off, or no HLS offered) a progressive file is chosen from
a quick bandwidth measurement, taking the highest rendition whose bitrate fits inside ~70 % of the measured
speed. The Replay quality setting caps the resolution in both cases.

Settings (resources/settings.xml)
    replay_quality    0 Auto, 1 up to 1080p, 2 up to 720p, 3 up to 480p, 4 up to 360p
    replay_adaptive   use HLS (adaptive) when the host offers it
"""
from starfleetscrapers import host as _sfhost
import re
import time
from urllib.parse import quote, urlparse, parse_qs, urljoin

from starfleetscrapers.core import http as requests
import xbmc

from starfleetscrapers.core import cache as _cache

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')

_CAPS = {0: 0, 1: 1080, 2: 720, 3: 480, 4: 360}
_OKRU_HEIGHT = {'mobile': 144, 'lowest': 240, 'low': 360, 'sd': 480, 'hd': 720, 'full': 1080}


def _setting(key, default=''):
    try:
        import xbmcaddon
        v = _sfhost.addon().getSetting(key)
        return v if v != '' else default
    except Exception:
        return default


def quality_cap():
    """Maximum height the user allows (0 = no limit)."""
    try:
        return _CAPS.get(int(_setting('replay_quality', '0')), 0)
    except ValueError:
        return 0


def adaptive_enabled():
    return _setting('replay_adaptive', 'true').lower() != 'false'


def chooser_properties(li):
    """inputstream.adaptive hints for an HLS ListItem: adapt on bandwidth, never above the chosen cap."""
    cap = quality_cap()
    try:
        li.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')
        if cap:
            li.setProperty('inputstream.adaptive.chooser_resolution_max', '%dp' % cap)
    except Exception:
        pass


# ── bandwidth ────────────────────────────────────────────────────────────────

def measure_kbps(url, headers=None, nbytes=700000):
    """Download speed from a short ranged GET against the stream's own host (kbit/s), cached 5 minutes."""
    host = urlparse(url).netloc
    ck = 'replay_bw_%s' % host
    cached = _cache.get(ck)
    if cached:
        return cached
    h = {'User-Agent': UA, 'Range': 'bytes=0-%d' % (nbytes - 1)}
    h.update(headers or {})
    try:
        t0 = time.time()
        r = requests.get(url, headers=h, timeout=(5, 12), stream=True)
        got = 0
        for chunk in r.iter_content(65536):
            got += len(chunk)
            if got >= nbytes or time.time() - t0 > 6:
                break
        r.close()
        dt = max(time.time() - t0, 0.05)
        kbps = int(got * 8 / 1000 / dt)
    except Exception as e:
        xbmc.log('[Starfleet/ReplayABR] bandwidth test failed: %s' % e, xbmc.LOGINFO)
        return 0
    if kbps:
        _cache.set(ck, kbps, 5 * 60)
    xbmc.log('[Starfleet/ReplayABR] measured %d kbit/s from %s' % (kbps, host), xbmc.LOGINFO)
    return kbps


def pick_progressive(options, kbps=0):
    """options: [(height, kbit/s needed, url)]. The highest rendition inside the cap whose bitrate fits ~70 % of
    the measured speed; the lowest one when nothing fits; the highest one when speed is unknown."""
    cap = quality_cap()
    opts = sorted([o for o in options if o[2]], key=lambda o: o[0])
    if not opts:
        return None
    if cap:
        capped = [o for o in opts if o[0] <= cap] or opts[:1]
    else:
        capped = opts
    if not kbps:
        return capped[-1]
    fit = [o for o in capped if o[1] and o[1] <= kbps * 0.7]
    return fit[-1] if fit else capped[0]


# ── HLS ──────────────────────────────────────────────────────────────────────

def hls_heights(master_url, headers=None):
    """Heights offered by an HLS master playlist (sorted), [] if it is not a master."""
    try:
        r = requests.get(master_url, headers=dict({'User-Agent': UA}, **(headers or {})), timeout=12)
        if r.status_code != 200 or 'EXT-X-STREAM-INF' not in r.text:
            return []
        return sorted({int(m) for m in re.findall(r'RESOLUTION=\d+x(\d+)', r.text)})
    except Exception:
        return []


# ── OK.ru ────────────────────────────────────────────────────────────────────

_RE_OKRU_ID = re.compile(r'(?:videoembed|video|live)/(\d+)')
OKRU_HDR = {'User-Agent': UA, 'Referer': 'https://ok.ru/', 'Origin': 'https://ok.ru'}


def okru_metadata(url):
    m = _RE_OKRU_ID.search(url)
    if not m:
        return None
    mid = m.group(1)
    try:
        r = requests.post('http://www.ok.ru/dk?cmd=videoPlayerMetadata', data={'mid': mid}, timeout=12,
                          headers={'User-Agent': UA, 'Referer': 'https://ok.ru/videoembed/%s' % mid, 'Origin': 'https://ok.ru'})
        r.raise_for_status()
        d = r.json()
        return None if 'error' in d else d
    except Exception as e:
        xbmc.log('[Starfleet/ReplayABR] ok.ru metadata: %s' % e, xbmc.LOGINFO)
        return None


def okru_hls(url):
    """(pipe-tagged HLS master URL, heights) or None."""
    d = okru_metadata(url)
    if not d or not d.get('hlsManifestUrl'):
        return None
    master = d['hlsManifestUrl']
    heights = hls_heights(master, OKRU_HDR)
    if len(heights) < 2:
        return None                      # a single rendition gains nothing from HLS
    tag = '|User-Agent=%s&Referer=%s&Origin=%s' % (quote(UA, safe=''), quote('https://ok.ru/', safe=''), quote('https://ok.ru', safe=''))
    return master + tag, heights


def okru_progressive_choice(videos, duration_s=0):
    """Name of the OK.ru rendition to download: bandwidth + cap aware. `videos` is metadata['videos']."""
    opts = []
    sample = None
    for v in videos:
        name, vu = v.get('name'), v.get('url')
        if not vu or name not in _OKRU_HEIGHT:
            continue
        sample = sample or vu
        opts.append((_OKRU_HEIGHT[name], 0, vu, name))
    if not opts:
        return None
    kbps = measure_kbps(sample, {'Referer': 'https://ok.ru/', 'Origin': 'https://ok.ru'}) if sample else 0
    if duration_s and kbps:
        sized = []
        for h, _b, vu, name in opts:
            try:
                rr = requests.get(vu, headers=dict(OKRU_HDR, Range='bytes=0-1'), timeout=8)
                total = int((rr.headers.get('content-range') or '/0').rsplit('/', 1)[-1] or 0)
            except Exception:
                total = 0
            sized.append((h, int(total * 8 / 1000 / duration_s) if total else 0, vu, name))
        opts = sized
    best = pick_progressive([(h, b, n) for h, b, _vu, n in opts], kbps)
    xbmc.log('[Starfleet/ReplayABR] ok.ru progressive: %s (measured %s kbit/s, cap %s)' % (best and best[2], kbps, quality_cap() or 'none'), xbmc.LOGINFO)
    return best[2] if best else None


# ── Dailymotion ──────────────────────────────────────────────────────────────

_RE_DM_ID = re.compile(r'(?:dailymotion\.com/(?:embed/)?video/|dai\.ly/|[?&]video=)([a-z0-9]+)', re.I)


def dailymotion_id(url):
    m = _RE_DM_ID.search(url or '')
    return m.group(1) if m else None


def dailymotion_hls(url):
    """(HLS master URL, heights) from Dailymotion's player metadata, or None."""
    vid = dailymotion_id(url)
    if not vid:
        return None
    try:
        r = requests.get('https://www.dailymotion.com/player/metadata/video/%s' % vid, timeout=15,
                         headers={'User-Agent': UA, 'Referer': 'https://www.dailymotion.com/'})
        r.raise_for_status()
        q = (r.json().get('qualities') or {})
        auto = (q.get('auto') or [{}])[0].get('url')
        if not auto:
            return None
        return auto, hls_heights(auto)
    except Exception as e:
        xbmc.log('[Starfleet/ReplayABR] dailymotion metadata %s: %s' % (vid, e), xbmc.LOGINFO)
        return None


def resolve(url):
    """Adaptive stream for hosts that offer one: (url, note) or (None, '') to let the normal resolvers run."""
    if not adaptive_enabled():
        return None, ''
    low = (url or '').lower()
    try:
        if 'ok.ru' in low or 'odnoklassniki.ru' in low:
            res = okru_hls(url)
            if res:
                return res[0], 'Adaptive %s' % _span(res[1])
        elif 'dailymotion.com' in low or 'dai.ly' in low:
            res = dailymotion_hls(url)
            if res:
                return res[0], 'Adaptive %s' % _span(res[1])
    except Exception as e:
        xbmc.log('[Starfleet/ReplayABR] resolve %s: %s' % (url[:60], e), xbmc.LOGINFO)
    return None, ''


def _span(heights):
    if not heights:
        return 'stream'
    cap = quality_cap()
    hs = [h for h in heights if not cap or h <= cap] or heights[:1]
    return '%dp-%dp' % (hs[0], hs[-1]) if hs[0] != hs[-1] else '%dp' % hs[0]
