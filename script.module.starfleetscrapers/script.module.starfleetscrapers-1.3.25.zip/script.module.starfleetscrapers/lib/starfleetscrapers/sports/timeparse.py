# -*- coding: utf-8 -*-
"""datetime.strptime without the standard library's _strptime.

Kodi's embedded Python on Android (Fire TV) can raise "'NoneType' object is not callable" from datetime.strptime, and the
sports code catches every parse failure as "no start time" - so every game then showed TBD on the Fire TV while the same
build showed times on Windows. This accepts the numeric / English-month formats the schedule parsers use and builds the
datetime directly; a text that does not fit raises ValueError, exactly like strptime."""
import datetime
import re

_MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december']
_TOKEN = {
    'Y': r'(?P<Y>\d{4})', 'm': r'(?P<m>\d{1,2})', 'd': r'(?P<d>\d{1,2})', 'H': r'(?P<H>\d{1,2})', 'M': r'(?P<M>\d{1,2})',
    'S': r'(?P<S>\d{1,2})', 'f': r'(?P<f>\d{1,6})', 'B': r'(?P<B>[A-Za-z]+)', 'b': r'(?P<B>[A-Za-z]{3,4})',
}
_cache = {}


def _regex(fmt):
    rx = _cache.get(fmt)
    if rx is None:
        out, i = [], 0
        while i < len(fmt):
            c = fmt[i]
            if c == '%' and i + 1 < len(fmt):
                tok = _TOKEN.get(fmt[i + 1])
                if tok is None:
                    raise ValueError('unsupported format %s' % fmt)
                out.append(tok)
                i += 2
            else:
                out.append(re.escape(c))
                i += 1
        rx = _cache[fmt] = re.compile(''.join(out))
    return rx


def strptime(text, fmt):
    m = _regex(fmt).fullmatch((text or '').strip())
    if not m:
        raise ValueError('time data %r does not match format %r' % (text, fmt))
    g = m.groupdict()
    month = int(g['m']) if g.get('m') else 1
    if g.get('B'):
        name = g['B'].lower()
        month = next((i for i, full in enumerate(_MONTHS, 1) if full == name or (len(name) >= 3 and full.startswith(name[:3]) and full.startswith(name))), 0)
        if not month:
            raise ValueError('unknown month %r' % g['B'])
    return datetime.datetime(int(g.get('Y') or 1900), month, int(g.get('d') or 1), int(g.get('H') or 0), int(g.get('M') or 0),
                             int(g.get('S') or 0), int((g.get('f') or '0').ljust(6, '0')))
