# -*- coding: utf-8 -*-
"""Startup service of the Starfleet Scrapers add-on. The scrapers need nothing running in the background, so this
returns at once; it exists so the add-on is declared the same way as other scraper modules."""
