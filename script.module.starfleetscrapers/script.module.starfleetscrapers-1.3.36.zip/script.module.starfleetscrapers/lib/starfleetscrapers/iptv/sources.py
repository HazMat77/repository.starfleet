# -*- coding: utf-8 -*-
"""
iptv/sources.py - the IPTV scraper: the viewer's own IPTV providers as SOURCES for a movie or an episode.

    search(title, year, media_type, season, episode)  -> [{'label', 'url', 'quality', 'provider'}]

For a title picked anywhere in Starfleet (TMDB metadata, Simkl / Trakt lists, watch history), every enabled provider's movies (or series) are looked
up by name. Only the categories left ON in "manage categories" are searched, so hiding a category takes it out of the sources as well. A show
is found by name, then its season / episode is picked; the stream address comes from the engine at once (a Stalker portal issues a fresh link
when asked). Because the result is an ordinary source for the TMDB title, playing it is tracked like any other (progress, watched, Simkl / Trakt).
"""
import re
import threading
import time
import unicodedata

from starfleetscrapers.iptv import catalog

_BRACKETS = re.compile(r'[\(\[\{<][^)\]\}>]*[\)\]\}>]')
_LANG_PREFIX = re.compile(r'^\s*(?:[|\[(]\s*[A-Za-z]{2,3}\s*[|\])]\s*|[A-Za-z]{2,3}\s*[-:|]\s+|\|[^|]{1,12}\|\s*)')
_NOISE = re.compile(r'\b(4k|uhd|fhd|hd|sd|hevc|x26[45]|h26[45]|2160p?|1080[pi]?|720p?|480p|bluray|brrip|bdrip|web-?dl|webrip|hdrip|multi|dual|'
                    r'vostfr|truefrench|multisub|subbed|dubbed|hdr10?|dolby|atmos|remux)\b', re.I)
_EP_TAG = re.compile(r'[\s\-:|]*\b(?:S\d{1,2}\s*E\d{1,3}|\d{1,2}x\d{1,3})\s*$', re.I)
_YEAR = re.compile(r'(?<!\d)((?:19|20)\d\d)(?!\d)')
_QUALITY = (('4K', re.compile(r'\b(4k|uhd|2160p?)\b', re.I)), ('1080p', re.compile(r'\b(fhd|1080[pi]?)\b', re.I)),
            ('720p', re.compile(r'\b720p?\b', re.I)), ('HD', re.compile(r'\bhd\b', re.I)))

_IDX = {}
_lock = threading.Lock()
_IDX_TTL = 1800
MAX_RESULTS = 8


def norm(title):
    """A title reduced for matching: no tags, language prefix, quality words, year, accents, "the", punctuation."""
    s = _BRACKETS.sub(' ', title or '')
    s = _LANG_PREFIX.sub('', s)
    s = _NOISE.sub(' ', s)
    s = _YEAR.sub(' ', s) if re.search(r'\s(?:19|20)\d\d\s*$', s + ' ') else s
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii').lower().replace('&', ' and ')
    s = re.sub(r'^\s*the\s+', '', s)
    return re.sub(r'[^a-z0-9]+', '', s)


def clean(title):
    """A provider title made fit for a TMDB search: tags, language prefix, quality words and a trailing year removed."""
    s = _BRACKETS.sub(' ', title or '')
    s = _LANG_PREFIX.sub('', s)
    s = _NOISE.sub(' ', s)
    s = re.sub(r'\s*(?:19|20)\d\d\s*$', '', s)
    return re.sub(r'\s+', ' ', s).strip(' -:|')


def show_title(title):
    """The show's own name: Starfleet passes an episode's title as 'FBI S09E04', which names no show on a provider."""
    return _EP_TAG.sub('', title or '').strip() or (title or '')


def year_of(title):
    m = re.search(r'[\(\[]((?:19|20)\d\d)[\)\]]', title or '') or re.search(r'(?<!\d)((?:19|20)\d\d)\s*$', title or '')
    return m.group(1) if m else ''


def quality_of(title):
    for label, rx in _QUALITY:
        if rx.search(title or ''):
            return label
    return ''


def _index(p, kind):
    """{normalised title: [rows]} over the provider's VISIBLE categories (manage categories), kept for a while."""
    pid = p['id']
    vis = frozenset(c['id'] for c in catalog.categories(pid, kind))
    key = (pid, kind)
    with _lock:
        ent = _IDX.get(key)
        if ent and ent[0] == vis and time.time() - ent[1] < _IDX_TTL:
            return ent[2]
    idx = {}
    for r in catalog.all_rows(pid, kind):
        if r.get('category_id') in vis:
            idx.setdefault(norm(r['title']), []).append(r)
    with _lock:
        _IDX[key] = (vis, time.time(), idx)
    return idx


def _year_ok(row_title, row_year, want):
    if not want:
        return True
    have = str(row_year or '') or year_of(row_title)
    if not have:
        return True
    try:
        return abs(int(have) - int(want)) <= 1
    except ValueError:
        return True


def _label(p, title, quality, extra=''):
    return '[IPTV] %s - %s%s%s' % (p.get('name') or 'IPTV', title, (' ' + extra) if extra else '', (' [%s]' % quality) if quality else '')


def search(title, year=None, media_type='movie', season=None, episode=None, limit=MAX_RESULTS, alt_titles=()):
    """Sources for one movie (media_type 'movie') or one episode ('tv' with season and episode) from the viewer's IPTV providers."""
    provs = catalog._enabled()
    if not provs or not title or media_type not in ('movie', 'tv'):
        return []
    if media_type == 'tv':
        title, alt_titles = show_title(title), [show_title(t) for t in alt_titles]
    wants = [n for n in dict.fromkeys([norm(title)] + [norm(t) for t in alt_titles]) if n]
    if not wants:
        return []
    kind = 'movie' if media_type == 'movie' else 'series'
    out = []
    for p in provs:
        try:
            idx = _index(p, kind)
        except Exception:
            continue
        rows = []
        for w in wants:
            rows += idx.get(w, [])
        if kind == 'series' and year:
            rows.sort(key=lambda r: 0 if _year_ok(r['title'], r.get('year'), year) else 1)
        seen = set()
        for r in rows:
            if r['id'] in seen:
                continue
            seen.add(r['id'])
            # A show is found by name and must have the episode, so the year only ranks it (a long-running show's start year and the year
            # Starfleet passes for an episode differ by many); a movie is a single title, so the year must fit.
            if kind == 'movie' and not _year_ok(r['title'], r.get('year'), year):
                continue
            try:
                if kind == 'movie':
                    url = catalog.kodi_url(catalog.resolve(p['id'], r))
                    out.append({'label': _label(p, r['title'], quality_of(r['title'])), 'url': url, 'quality': quality_of(r['title']),
                                'provider': p['id']})
                else:
                    ep = _find_episode(p, r, season, episode)
                    if ep:
                        url = catalog.kodi_url(catalog.resolve(p['id'], ep))
                        out.append({'label': _label(p, r['title'], quality_of(r['title']), 'S%02dE%02d' % (int(season), int(episode))), 'url': url,
                                    'quality': quality_of(r['title']), 'provider': p['id']})
            except Exception:
                continue
            if len(out) >= limit:
                return out
    return out


def _find_episode(p, show, season, episode):
    if season is None or episode is None:
        return None
    data = catalog.seasons(p['id'], show['id'])
    for e in data['seasons'].get(int(season), []):
        if int(e.get('episode') or 0) == int(episode):
            return e
    return None
