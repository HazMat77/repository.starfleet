# -*- coding: utf-8 -*-
"""IPTV engine: Xtream Codes, Stalker / Ministra and M3U providers, the XMLTV guide, and the manage-categories choices.
Use starfleetscrapers.iptv.catalog; configure(path) sets where the files live (the Android app calls it first)."""
from starfleetscrapers.iptv.store import configure   # noqa: F401
