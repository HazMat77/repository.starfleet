# -*- coding: utf-8 -*-
"""
iptv/m3u.py - M3U / M3U8 playlists (a web address or a local file).

Each #EXTINF entry becomes a channel; group-title names its category. A playlist mixes live channels, movies and series, so every entry is
classified:  /movie/ or /series/ in an Xtream-style address, then the words in the group (movie, film, vod, cinema -> movie; series, show,
season -> series), then a name like "Show Name S01E04" -> series, else live. Series entries are grouped into a show with seasons.
The playlist header's url-tvg / x-tvg-url names the guide.
"""
import os
import re
from urllib.parse import unquote

from starfleetscrapers.core import http as _http

_UA = 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'
_ATTR = re.compile(r'([A-Za-z0-9_-]+)="([^"]*)"')
_SXXEXX = re.compile(r'^(?P<show>.*?)[\s._-]*[Ss](?P<s>\d{1,2})[\s._-]*[Ee](?P<e>\d{1,3})\b[\s._-]*(?P<ep>.*)$')
_MOVIE_WORDS = re.compile(r'\b(movies?|films?|vod|cinema|cine|kino)\b', re.I)
_SERIES_WORDS = re.compile(r'\b(series|tv ?shows?|shows?|seasons?|serien|dizi)\b', re.I)
_VIDEO_EXT = ('.mp4', '.mkv', '.avi', '.mov', '.m4v', '.wmv', '.flv', '.webm')


def fetch(source, user_agent=None):
    """Playlist text from an address or a file path."""
    if os.path.isfile(source):
        with open(source, 'r', encoding='utf-8', errors='replace') as f:
            return f.read()
    r = _http.get(source, timeout=(10, 120), headers={'User-Agent': user_agent or _UA})
    r.raise_for_status()
    return r.content.decode('utf-8', 'replace')


def _split_extinf(line):
    """(attributes part, title) split at the first comma that is not inside quotes (a user-agent value contains commas)."""
    quoted = False
    for i, ch in enumerate(line):
        if ch == '"':
            quoted = not quoted
        elif ch == ',' and not quoted:
            return line[:i], line[i + 1:]
    return line, ''


def parse(text):
    """-> {'epg_url': str, 'entries': [ {title, url, group, logo, tvg_id, tvg_name, headers, kind, season, episode, show} ]}"""
    entries, epg_url = [], ''
    cur, headers = None, {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith('#EXTM3U'):
            a = dict(_ATTR.findall(line))
            epg_url = a.get('url-tvg') or a.get('x-tvg-url') or a.get('tvg-url') or ''
        elif line.startswith('#EXTINF'):
            head, name = _split_extinf(line)
            a = dict(_ATTR.findall(head))
            if a.get('http-user-agent'):
                headers['User-Agent'] = a['http-user-agent']
            if a.get('http-referrer') or a.get('http-referer'):
                headers['Referer'] = a.get('http-referrer') or a.get('http-referer')
            cur = {'title': (name.strip() or a.get('tvg-name') or '').strip(), 'group': (a.get('group-title') or '').strip(),
                   'logo': a.get('tvg-logo') or '', 'tvg_id': a.get('tvg-id') or '', 'tvg_name': a.get('tvg-name') or ''}
            # header lines (#EXTVLCOPT) may come before or after the #EXTINF line: whatever was collected since the last address stays
        elif line.startswith('#EXTVLCOPT:'):
            k, _, v = line[len('#EXTVLCOPT:'):].partition('=')
            k = k.strip().lower()
            if k == 'http-user-agent':
                headers['User-Agent'] = v.strip()
            elif k in ('http-referrer', 'http-referer'):
                headers['Referer'] = v.strip()
            elif k == 'http-origin':
                headers['Origin'] = v.strip()
        elif line.startswith('#KODIPROP:') or line.startswith('#EXTGRP:'):
            if line.startswith('#EXTGRP:') and cur is not None and not cur['group']:
                cur['group'] = line.split(':', 1)[1].strip()
        elif not line.startswith('#'):
            if cur is None:
                cur = {'title': unquote(line.rsplit('/', 1)[-1]), 'group': '', 'logo': '', 'tvg_id': '', 'tvg_name': ''}
            if '|' in line and 'User-Agent=' in line.split('|', 1)[1]:      # Kodi's url|Header=value form
                line, _, tail = line.partition('|')
                for kv in tail.split('&'):
                    k, _, v = kv.partition('=')
                    if k:
                        headers[k] = unquote(v)
            cur['url'] = line
            cur['headers'] = headers
            _classify(cur)
            entries.append(cur)
            cur, headers = None, {}
    return {'epg_url': epg_url, 'entries': entries}


def _classify(e):
    url, group, title = e['url'], e['group'], e['title']
    low = url.lower().split('?')[0]
    m = _SXXEXX.match(title)
    e.update(kind='live', season=0, episode=0, show='')
    if '/series/' in low:
        e['kind'] = 'series'
    elif '/movie/' in low:
        e['kind'] = 'movie'
    elif _SERIES_WORDS.search(group) and low.endswith(_VIDEO_EXT):
        e['kind'] = 'series'                  # a "Series" / "Movies" group of live .m3u8 / .ts addresses is a list of 24/7 channels, not films
    elif _MOVIE_WORDS.search(group) and low.endswith(_VIDEO_EXT):
        e['kind'] = 'movie'
    elif m and low.endswith(_VIDEO_EXT):
        e['kind'] = 'series'
    elif low.endswith(_VIDEO_EXT) and not low.endswith('.m3u8'):
        e['kind'] = 'movie'
    if e['kind'] == 'series' and m:
        e.update(show=m.group('show').strip() or title, season=int(m.group('s')), episode=int(m.group('e')),
                 title=(m.group('ep').strip() or title))
    elif e['kind'] == 'series':
        e['show'] = title


def categories(parsed, kind):
    seen, out = set(), []
    for e in parsed['entries']:
        if e['kind'] == kind:
            g = e['group'] or 'Uncategorised'
            if g not in seen:
                seen.add(g)
                out.append({'id': g, 'name': g})
    return out


def items(parsed, kind, category_id=None):
    out = []
    if kind == 'series':
        shows = {}
        for e in parsed['entries']:
            if e['kind'] != 'series' or (category_id is not None and (e['group'] or 'Uncategorised') != category_id):
                continue
            key = (e['group'], e['show'])
            if key not in shows:
                shows[key] = {'id': '%s|%s' % (e['group'], e['show']), 'kind': 'series', 'title': e['show'], 'poster': e['logo'],
                              'category_id': e['group'] or 'Uncategorised', 'ref': {'t': 'series', 'id': '%s|%s' % (e['group'], e['show'])}}
        return list(shows.values())
    for i, e in enumerate(parsed['entries']):
        if e['kind'] != kind or (category_id is not None and (e['group'] or 'Uncategorised') != category_id):
            continue
        out.append({'id': str(i), 'kind': kind, 'title': e['title'], 'poster': e['logo'], 'category_id': e['group'] or 'Uncategorised',
                    'epg_id': e['tvg_id'], 'epg_name': e['tvg_name'] or e['title'], 'num': i + 1,
                    'ref': {'t': kind, 'id': str(i)}})
    return out


def seasons(parsed, series_id):
    group, _, show = series_id.partition('|')
    seasons = {}
    for i, e in enumerate(parsed['entries']):
        if e['kind'] == 'series' and (e['group'] or '') == group and e['show'] == show:
            seasons.setdefault(e['season'] or 1, []).append({
                'id': str(i), 'kind': 'episode', 'season': e['season'] or 1, 'episode': e['episode'], 'title': e['title'],
                'poster': e['logo'], 'ref': {'t': 'episode', 'id': str(i)}})
    for rows in seasons.values():
        rows.sort(key=lambda x: x['episode'])
    return {'info': {'title': show}, 'seasons': dict(sorted(seasons.items()))}


def resolve(parsed, item):
    e = parsed['entries'][int(item['ref']['id'])]
    return {'url': e['url'], 'headers': e.get('headers') or {}}
