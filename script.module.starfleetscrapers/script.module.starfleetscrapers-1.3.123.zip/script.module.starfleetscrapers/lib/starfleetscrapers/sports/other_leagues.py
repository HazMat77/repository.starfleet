# -*- coding: utf-8 -*-
"""The "other leagues" game lists (hockey, basketball, baseball, rugby, boxing, golf, more, and the soccer leagues the schedule feeds lack),
team logos for them, and the streams of one such game.

    games(menu)                       -> [{id, title, league, kind, start_ts, live}]   (Strikeout, plus FawaNews channels for soccer / basketball)
    streams(href, sport, title, ts)   -> [{label, url, source}]                         (the players that really open first, then the generic search)
    logos(names, sport)               -> {team name: logo address or ''}                (ESPN's team search, kept on disk)

Used by the HazMat sports menu; Binge Hazmat Sports has its own copy of the same logic in binge_bridge.py.
"""
import json
import os
import re
import threading
import time
import unicodedata

_SLUG = {'hockey': 'nhl', 'basketball': 'nba', 'baseball': 'mlb', 'soccer': 'soccer', 'rugby': 'rugby', 'boxing': 'boxing', 'golf': 'golf', 'more': ''}


def _ascii(s):
    return unicodedata.normalize('NFKD', s or '').encode('ascii', 'ignore').decode('ascii')


# ── games ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

def games(menu):
    """The games of one menu; the soccer and basketball menus also list the FawaNews channels that are on the air (games no schedule has),
    each only when it is not already there."""
    from starfleetscrapers.sports import sports_pages_live as sp
    out = [{'id': e['href'], 'title': e['title'], 'league': e['league'], 'kind': e['kind'], 'start_ts': e['start_ts'], 'live': e['live']}
           for e in sp.so_games(menu)]
    if menu in ('soccer', 'basketball'):
        def keys(t):
            return [max((w for w in re.split(r'\s+', side.lower()) if len(w) >= 4), key=len, default=side.lower())
                    for side in re.split(r'\s+vs\.?\s+', t, maxsplit=1)]
        try:
            fawa = sp.fn_games(menu)
        except Exception:
            fawa = []
        for e in fawa:
            k = keys(e['title'])
            if any(all(x in g['title'].lower() for x in k) for g in out):
                continue
            out.append({'id': e['href'], 'title': e['title'], 'league': e['league'], 'kind': e['kind'], 'start_ts': e['start_ts'], 'live': True})
    return out


def streams(href, sport='', title='', start_ts=0):
    """The streams of one game of those lists: its verified players first, then whatever the other sources have for the same game."""
    from concurrent.futures import ThreadPoolExecutor
    from starfleetscrapers.sports import sports_pages_live as sp
    from starfleetscrapers.sports import sports_sources as ss

    def direct():
        if 'fawanews.sc' in href:
            r = sp._fn_stream(href)
            return [('FawaNews', r[1])] if r else []
        return sp.so_streams(href)

    def generic():
        slug = _SLUG.get(sport, sport)
        return ss.get_event_streams('', '', slug, _ascii(title), int(start_ts or 0)) or []
    out, seen = [], set()
    with ThreadPoolExecutor(max_workers=2) as ex:
        f1 = ex.submit(direct)
        f2 = ex.submit(generic) if title else None
        try:
            for lab, url in f1.result(timeout=40):
                if url not in seen:
                    seen.add(url)
                    out.append({'label': lab, 'url': url, 'source': 'FawaNews' if lab == 'FawaNews' else 'Strikeout'})
        except Exception:
            pass
        if f2 is not None:
            try:
                for s in f2.result(timeout=60):
                    u = s.get('url') or ''
                    if u and u not in seen and 'strikeout' not in ((s.get('source') or '') + (s.get('label') or '')).lower():
                        seen.add(u)
                        out.append({'label': s.get('label') or 'Stream', 'url': u, 'source': s.get('source') or ''})
            except Exception:
                pass
    return out


# ── logos ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

_LOGO_SPORT = {'soccer': ('soccer',), 'basketball': ('basketball',), 'hockey': ('hockey',), 'baseball': ('baseball',),
               'rugby': ('rugby', 'rugby union', 'rugby league'), 'football': ('football',), 'cricket': ('cricket',)}
_logos = {}
_lock = threading.Lock()
_loaded = [False]


def _path():
    base = ''
    try:
        from starfleetscrapers import host
        base = host.profile() or ''
    except Exception:
        pass
    base = os.environ.get('HAZMAT_FILES') or base or os.environ.get('STARFLEET_PROFILE') or ''
    return os.path.join(base, 'team_badges.json')


def _plain(s):
    return re.sub(r'[^a-z0-9]', '', _ascii(s).lower())


def _find(name, sport):
    import requests
    want = _LOGO_SPORT.get(sport, ())
    q = re.sub(r'\s+(W|U\d\d|II|B)$', '', name.strip())
    r = requests.get('https://site.web.api.espn.com/apis/common/v3/search', params={'query': q, 'limit': 8, 'type': 'team', 'mode': 'prefix'},
                     headers={'User-Agent': 'Mozilla/5.0'}, timeout=12)
    pn = _plain(q)
    best = ''
    for t in r.json().get('items') or []:
        if want and (t.get('sport') or '').lower().replace('-', ' ') not in want:
            continue
        pt = _plain(t.get('displayName') or '')
        if pt and (pt == pn or (len(pn) >= 5 and (pn in pt or pt in pn))):
            lg = t.get('logos') or []
            href = (lg[0].get('href') if lg else '') or ''
            if href:
                best = href
                break
    if best.startswith('https://a.espncdn.com/i/'):
        best = 'https://a.espncdn.com/combiner/i?img=' + best[len('https://a.espncdn.com'):] + '&w=96&h=96'
    return best


def logos(names, sport=''):
    """{name: logo address or ''}: names not looked up before are searched (up to 40 per call); every answer, even an empty one, is kept on disk
    (an empty one is tried again after a week)."""
    from concurrent.futures import ThreadPoolExecutor
    with _lock:
        if not _loaded[0]:
            _loaded[0] = True
            try:
                with open(_path(), encoding='utf-8') as f:
                    _logos.update(json.load(f))
            except Exception:
                pass
    now = int(time.time())
    out, todo = {}, []
    for n in [n for n in names if n]:
        v = _logos.get(sport + '|' + n)
        if v is not None and (v[0] or now - v[1] < 7 * 86400):
            out[n] = v[0]
        elif n not in todo:
            todo.append(n)

    def one(n):
        try:
            return n, _find(n, sport)
        except Exception:
            return n, None
    if todo:
        with ThreadPoolExecutor(max_workers=4) as ex:
            for n, b in ex.map(one, todo[:40]):
                if b is not None:
                    _logos[sport + '|' + n] = [b, now]
                    out[n] = b
        try:
            with open(_path(), 'w', encoding='utf-8') as f:
                json.dump(_logos, f)
        except Exception:
            pass
    return out
