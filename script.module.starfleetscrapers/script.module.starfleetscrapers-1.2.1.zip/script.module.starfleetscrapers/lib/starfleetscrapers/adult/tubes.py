# -*- coding: utf-8 -*-
"""Generic tube-site adapter for Adult > Scenes (sites added from a tube-site list).

A site is a small config row: where its listing lives and how it pages, which URL shape is a
video page, how its categories are laid out and how its search works. Listing cards are read
from "anchor containing an image" blocks whose path matches the video shape; the video page is
read for a direct mp4/m3u8 (<source>, og:video, JSON-LD, quoted URLs, or a dataEncodings JSON).

Only sites whose pages serve a plain, full-length stream without JavaScript are listed here.
"""
import html as _html
import json
import re
from urllib.parse import urljoin, urlparse, quote_plus

import xbmc

from starfleetscrapers.adult import streams as _as
from starfleetscrapers.core import cache as _cache


def _shape(path):
    path = re.sub(r'/\d+(?=/|$)', '/#', path.split('?')[0]).rstrip('/')
    parts = path.split('/')
    if len(parts) == 2 and len(parts[1]) >= 20 and parts[1].count('-') >= 3:
        return '/*slug'                      # video slug at the site root
    return '/'.join(parts[:-1]) + '/*' if len(parts) > 2 else (path or '/')


def _fmt(f, base, u, p):
    if callable(f):
        return f(u, p)
    return f.format(b=base, u=u, us=u.rstrip('/'), p=p, p0=p - 1)


TUBES = {
    'taxi69': dict(
        label='Taxi69', base='https://taxi69.com', latest='/', page='{u}?page={p}', vshape='/video/*',
        search='/search/{q}/'),
    'perfectgirls': dict(
        label='PerfectGirls', base='https://www.perfectgirls.xxx', latest='/', page='{u}{p}/', vshape='/video/*',
        search='/search/{q}/',
        cats=dict(index='/channels/', shape='/channels/*', page='{u}{p}/')),
    'damplips': dict(
        label='DampLips', base='https://www.damplips.com', latest='/', page='{u}page/{p}/', vshape='/p/*',
        search='/search/{q}/'),
    'theclassicporn': dict(
        label='TheClassicPorn', base='https://theclassicporn.com', latest='/', page='{u}?from={p}',
        vshape='/videos/#/*', search='/search/?q={q}'),
    'youjizz': dict(
        label='YouJizz', base='https://www.youjizz.com', latest='/newest-clips/1.html',
        page='{b}/newest-clips/{p}.html', vshape='/videos/*', search='/search/{q}-1.html',
        cats=dict(index='/tags/', shape='/categories/*',
                  page=lambda u, p: re.sub(r'-\d+\.html$', '-%d.html' % p, u))),
}

def _load_generated():
    """Rows found by probing the site list (resources/lib/tube_sites.json): same fields as TUBES."""
    try:
        import os
        p = os.path.join(os.path.dirname(__file__), 'tube_sites.json')
        with open(p, 'r', encoding='utf-8') as f:
            for key, row in json.load(f).items():
                if key not in TUBES:
                    TUBES[key] = row
    except Exception as e:
        xbmc.log('[Starfleet/Tubes] generated rows not loaded: %s' % e, xbmc.LOGWARNING)


_BAD = re.compile(r'categor|/cats?/|/tags?/|channel|pornstar|model|search|login|signup|/page|gay|trans|sitemap|webcam|premium|/out|/go/', re.I)


def _cards(site, html, page_url, vshape=None):
    cfg = TUBES[site]
    host = urlparse(cfg['base']).netloc.replace('www.', '')
    vs = vshape or cfg['vshape']
    films, seen = [], set()
    for m in re.finditer(r'<a\b([^>]*?)href="([^"#]+)"([^>]*)>(.{0,2500}?)</a>', html, re.S):
        pre, h, post, inner = m.groups()
        if '<img' not in inner:
            continue
        u = urljoin(page_url, _html.unescape(h))
        p = urlparse(u).path
        if urlparse(u).netloc.replace('www.', '') != host or _shape(p) != vs or u in seen:
            continue
        if cfg.get('vpat') and not re.search(cfg['vpat'], p):
            continue                      # same path shape as the video pages but not a video (walls, webcams ...)
        seen.add(u)
        title = ''
        for src in (pre + post, inner):
            tm = re.search(r'title="([^"]{4,200})"', src) or re.search(r'alt="([^"]{4,200})"', src)
            if tm:
                title = _html.unescape(tm.group(1)).strip()
                break
        if not title:
            title = re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', inner))).strip()[:120]
        slug = p.strip('/').replace('/', '_')
        title = title or slug.replace('-', ' ').replace('_', ' ').title()
        th = re.search(r'(?:data-webp|data-src|data-original|data-lazy-src|data-thumb|src)="((?:https?:)?//[^"]+\.(?:jpg|jpeg|png|webp)[^"]*'
                       r'|/[^"/][^"]*?\.(?:jpg|jpeg|png|webp)[^"]*)"', inner)
        thumb = _html.unescape(th.group(1)) if th else ''
        if thumb and not re.search(r'logo|sprite|blank|placeholder', thumb, re.I):
            thumb = urljoin(page_url, thumb)          # '//cdn/..' and site-relative '/media/thumbs/..' alike
        else:
            thumb = ''
        films.append({'slug': slug[-90:], 'url': u, 'title': _as._clean_title(title), 'title_norm': _as._norm_title(title),
                      'thumb': thumb, 'source': site, 'streams': []})
    return films


def latest(site, page=1):
    cfg = TUBES[site]
    ck = 'tube_%s_latest_%d' % (site, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    u0 = cfg['base'] + cfg['latest']
    url = u0 if page <= 1 else _fmt(cfg['page'], cfg['base'], u0, page)
    try:
        films = _cards(site, _as._get(url), url)
        _cache.set(ck, films, 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/%s] latest error: %s' % (site, e), xbmc.LOGWARNING)
        return []


def categories(site):
    cfg = TUBES[site].get('cats')
    if not cfg:
        return []
    ck = 'tubecat_%s_v1' % site
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    base = TUBES[site]['base']
    host = urlparse(base).netloc.replace('www.', '')
    cats, seen = [], set()
    try:
        html = _as._get(base + cfg['index'])
    except Exception as e:
        xbmc.log('[Starfleet/%s] categories error: %s' % (site, e), xbmc.LOGWARNING)
        return []
    for m in re.finditer(r'<a[^>]+href="([^"#]+)"[^>]*>(.*?)</a>', html, re.S):
        u = urljoin(base + cfg['index'], _html.unescape(m.group(1)))
        if urlparse(u).netloc.replace('www.', '') != host or _shape(urlparse(u).path) != cfg['shape'] or u in seen:
            continue
        inner = m.group(2)
        tm = re.search(r'title="([^"]+)"', m.group(0)) or re.search(r'alt="([^"]+)"', inner)
        name = _html.unescape(tm.group(1)).strip() if tm else re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', inner))).strip()
        name = re.sub(r'\s*\(?\d[\d.,]*\s*(?:videos?)?\)?$', '', name).strip()
        if not name or len(name) > 40 or name.lower() == 'all' or re.search(r'/abc(/|$)', u):
            continue
        seen.add(u)
        th = re.search(r'(?:data-src|data-original|src)="((?:https?:)?//[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"', inner)
        cats.append({'name': name, 'slug': u, 'count': 0, 'thumb': ('https:' + th.group(1)) if th and th.group(1).startswith('//') else (th.group(1) if th else '')})
    if cats:
        _cache.set(ck, cats, 24 * 3600)
    return cats


def category_movies(site, slug, page=1):
    cfg = TUBES[site]['cats']
    ck = 'tubecat_%s_%s_%d' % (site, re.sub(r'\W+', '_', slug)[-60:], page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = slug if page <= 1 else _fmt(cfg['page'], TUBES[site]['base'], slug, page)
    try:
        films = _cards(site, _as._get(url), url)
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/%s] category %s p%d: %s' % (site, slug, page, e), xbmc.LOGWARNING)
        return []


def search(site, query, page=1):
    cfg = TUBES[site]
    url = cfg['base'] + cfg['search'].format(q=quote_plus(query))
    if page > 1:
        url = _fmt(cfg.get('search_page', '{u}?page={p}'), cfg['base'], url, page)
    try:
        return _cards(site, _as._get(url), url)
    except Exception as e:
        xbmc.log('[Starfleet/%s] search error: %s' % (site, e), xbmc.LOGWARNING)
        return []


# ── video page -> streams ────────────────────────────────────────────────────

_QUALITIES = {240, 360, 480, 540, 576, 720, 1080, 1440, 2160}


def _quality(u):
    """Resolution from a file name like ..._720p.mp4 / ...-1280-720-1481-h264.mp4, else 0."""
    name = re.sub(r'[?&].*$', '', u).rstrip('/').rsplit('/', 1)[-1]
    for m in re.finditer(r'(?<!\d)(\d{3,4})p(?!\w)', name):
        if int(m.group(1)) in _QUALITIES:
            return int(m.group(1))
    m = re.search(r'-\d{3,4}-(\d{3,4})-\d+-h264', name)
    if m and int(m.group(1)) in _QUALITIES:
        return int(m.group(1))
    return 0


def _kvs_real_url(video_url, license_code):
    """Undo KVS's 'function/0/<url>' protection: the 32-char hash segment of the file path is
    shuffled by a seed derived from the page's license code; replay the swaps in reverse."""
    if not video_url.startswith('function/'):
        return video_url
    try:
        lc = license_code
        digits = lc.replace('$', '').replace('0', '1')
        half = len(digits) // 2
        a, b = int(digits[:half + 1]), int(digits[half:])
        s = str(abs(b - a) * 4)
        limit = 16 // 2 + 2
        seed = ''
        for i in range(half + 1):
            for j in range(1, 5):
                n = int(lc[i + j]) + int(s[i])
                if n >= limit:
                    n -= limit
                seed += str(n)
        parts = video_url.split('/')
        seg = parts[7]
        h, rest = list(seg[:32]), seg[32:]
        for k in range(len(h) - 1, -1, -1):
            e = k + sum(int(c) for c in seed[k:])
            e %= len(h)
            h[k], h[e] = h[e], h[k]
        parts[7] = ''.join(h) + rest
        url = '/'.join(parts[2:])
        return url
    except Exception:
        return ''


def _media(html, base):
    out = []
    lcm = re.search(r"license_code\s*:\s*['\"]([^'\"]+)", html)
    if lcm:
        for m in re.finditer(r"video_(?:alt_)?url\d?\s*:\s*['\"]([^'\"]+)", html):
            real = _kvs_real_url(m.group(1), lcm.group(1))
            if real:
                out.append(real)
    for m in re.finditer(r'<source[^>]+src=\\?["\']([^"\'\\]+)', html):
        out.append(m.group(1))
    for m in re.finditer(r'property=["\']og:video(?::secure_url|:url)?["\'][^>]*content=["\']([^"\']+)', html):
        out.append(m.group(1))
    for m in re.finditer(r'"contentUrl"\s*:\s*"([^"]+)"', html):
        out.append(m.group(1).replace('\\/', '/'))
    m = re.search(r'dataEncodings\s*=\s*(\[.*?\]);', html, re.S)
    if m:
        try:
            enc = json.loads(m.group(1))
            for e in sorted(enc, key=lambda x: -int(x.get('quality') or 0)):
                fn = (e.get('filename') or '').replace('\\/', '/')
                if fn and '_hls' not in fn and '.mp4' in fn:
                    out.append(fn)
        except Exception:
            pass
    for m in re.finditer(r'"filename"\s*:\s*"((?:https?:)?\\?/\\?/[^"]+?\.(?:mp4|m3u8)[^"]*)"', html):
        out.append(m.group(1).replace('\\/', '/'))
    for m in re.finditer(r'["\'](https?:\\?/\\?/[^"\'\s<>]+?\.(?:mp4|m3u8)[^"\'\s<>]*)', html):
        out.append(m.group(1).replace('\\/', '/'))
    # KVS sites that sign their files: the plain video_url 403s, the same URL with ?v-acctoken=... (written
    # elsewhere on the page) plays
    signed = []
    for u in out:
        m = re.search(re.escape(u.rstrip('/')) + r'/?\?v-acctoken=[^"' + "'" + r'\s<>]+', html)
        if m and '?' not in u:
            signed.append(_html.unescape(m.group(0)))
    out = signed + out
    res, seen = [], set()
    for u in out:
        u = _html.unescape(u)
        if u.startswith('//'):
            u = 'https:' + u
        elif u.startswith('/'):
            u = urljoin(base, u)
        if u.startswith('http') and u not in seen and not re.search(r'preview|trailer|/tmb/|thumb|/ads?/|download|\.gif|videoai', u, re.I):
            seen.add(u)
            res.append(u)
    return res


_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/126.0.0.0 Safari/537.36')    # some CDNs 403 the bare 'Mozilla/5.0'; the player is told to use this too


def _alive_ref(u, referers):
    """The first referer under which `u` really serves video ('' when none does)."""
    import requests as _rq      # plain requests: a dead CDN here must not mark the whole site down
    for ref in referers:
        try:
            r = _rq.get(u, headers={'User-Agent': _UA, 'Referer': ref, 'Range': 'bytes=0-1023'},
                        timeout=(4, 7), stream=True)
            try:
                head = next(r.iter_content(1024), b'')
            finally:
                r.close()
            ct = (r.headers.get('content-type') or '').lower()
            if r.status_code not in (200, 206) or 'text/html' in ct or ct.startswith('image'):
                continue
            if (b'#EXTM3U' in head[:64] or b'ftyp' in head[:16] or head[:1] == b'G' or head[:4] == b'\x1a\x45\xdf\xa3'
                    or ct.startswith('video') or 'mpegurl' in ct):
                return ref
        except Exception:
            continue
    return ''


def _alive(u, referer):
    return bool(_alive_ref(u, [referer]))


_HOST_RX = re.compile(
    _as._STREAM_HOST_RX.pattern + r'|pornhub|xvideos|xhamster|redtube|youporn|eporner|tnaflix|xnxx|spankbang|drtuber',
    re.IGNORECASE)


def _resolvable(u):
    """True when ResolveURL knows the host of `u` (falls back to the built-in host list)."""
    try:
        from starfleetscrapers import hooks as _hk; resolveurl = _hk.hosted()
        return bool(resolveurl.HostedMediaFile(u).valid_url())
    except Exception:
        return bool(_HOST_RX.search(u.split('/')[2]))


def _hosts_in(html, base):
    """Embedded players / links on hosts ResolveURL understands (ad iframes are ignored)."""
    out = []
    for m in re.finditer(r'<iframe[^>]+(?:data-src|src)=["\']([^"\']+)', html):
        hu = urljoin(base, _html.unescape(m.group(1)))
        if hu.startswith('http') and _resolvable(hu):
            out.append(hu)
    for m in re.finditer(r'href="(https?://[^"]+)"', html):
        hu = _html.unescape(m.group(1))
        if _HOST_RX.search(hu.split('/')[2]) and re.search(r'/(?:embed|e|v|d|f|watch|play)', hu) and _resolvable(hu):
            out.append(hu)
    return list(dict.fromkeys(out))


def _same_site_iframes(html, base):
    host = urlparse(base).netloc.replace('www.', '')
    out = []
    for m in re.finditer(r'<iframe[^>]+(?:data-src|src)=["\']([^"\']+)', html):
        u = urljoin(base, _html.unescape(m.group(1)))
        if u.startswith('http') and urlparse(u).netloc.replace('www.', '') == host and 'embed' in u:
            out.append(u)
    return out


def _collect(cfg, html, page_url, depth=0):
    """(direct streams, host streams) found on a video page; follows one same-site /embed/ hop."""
    urls = sorted(_media(html, page_url), key=lambda u: (-_quality(u), u))
    urls = [u for u in urls if not re.search(r'\.(?:jpe?g|png|webp|ico|svg|css|js)(?:\?|$)', u, re.I)][:8]
    embeds = [u for u in urls if '/embed' in u and urlparse(u).netloc == urlparse(page_url).netloc] + _same_site_iframes(html, page_url)
    urls = [u for u in urls if u not in embeds]
    refs = {}
    if urls:
        from concurrent.futures import ThreadPoolExecutor
        embeds_all = _same_site_iframes(html, page_url) + [h for h in re.findall(r'<iframe[^>]+(?:data-src|src)=["\']([^"\']+)', html)]

        def _probe(x):
            cands = [page_url, '%s://%s/' % (urlparse(x).scheme, urlparse(x).netloc)] + \
                    [urljoin(page_url, _html.unescape(e)) for e in embeds_all[:3]]
            return _alive_ref(x, list(dict.fromkeys(cands)))
        with ThreadPoolExecutor(max_workers=len(urls)) as ex:
            flags = list(ex.map(_probe, urls))
        refs = {u: f for u, f in zip(urls, flags) if f}
        urls = [u for u in urls if u in refs]
    direct = []
    for u in urls[:4]:
        q = _quality(u)
        direct.append({'label': '[%s] %s' % (cfg['label'], ('%dp' % q) if q else ('HLS' if '.m3u8' in u else 'MP4')),
                       'url': u, 'referer': refs.get(u) or page_url, 'ua': _UA})
    hosts = []
    if not direct:
        if cfg.get('hop_hosts') and depth < 3:
            # players that wrap the file in a chain of embed pages on other domains (listed per site)
            _cands = [m_.group(1) for m_ in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)', html)]
            _cands += re.findall(r'itemprop="embedUrl"[^>]*content="([^"]+)"', html)
            _cands += re.findall(r'property="og:video:url"[^>]*content="([^"]+)"', html)
            for _c in _cands:
                hu = urljoin(page_url, _html.unescape(_c))
                if any(urlparse(hu).netloc.endswith(_h) for _h in cfg['hop_hosts']):
                    try:
                        _r = _as._sess().get(hu, timeout=(5, 12), headers={'Referer': page_url, 'User-Agent': _UA})
                        _r.raise_for_status()
                        d2, h2 = _collect(cfg, _r.text, hu, depth + 1)
                    except Exception:
                        continue
                    if d2 or h2:
                        direct, hosts = d2, h2
                        break
        for hu in ([] if direct else _hosts_in(html, page_url)):
            if not _as._skip_locker_unless_debrid(hu):
                hosts.append({'label': '[%s] %s' % (cfg['label'], _as._host_label(hu)), 'url': hu})
        if not direct and not hosts and depth == 0:
            for e in embeds[:1]:
                try:
                    d2, h2 = _collect(cfg, _as._get(e, timeout=(5, 12)), e, 1)
                    direct, hosts = d2, h2
                except Exception:
                    pass
    return direct, hosts[:4]


def detail(site, slug, url):
    cfg = TUBES[site]
    if cfg.get('vrewrite'):                       # listing links that bounce through a redirect page
        url = re.sub(cfg['vrewrite'][0], cfg['vrewrite'][1], url, count=1)
    ck = 'tube_%s_detail_%s' % (site, slug[:70])
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _as._get(url, timeout=(5, 12))
        m = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.S | re.I)
        title = _html.unescape(re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', m.group(1)))).strip() if m else ''
        if not title:
            title = _as._og(html, 'title') or slug.replace('-', ' ').replace('_', ' ').title()
        direct, hosts = _collect(cfg, html, url)
        streams = direct or hosts
        film = {'id': '%s_%s' % (site, slug), 'slug': slug, 'title': _as._clean_title(title), 'title_norm': _as._norm_title(title),
                'thumb': _as._og(html, 'image'), 'description': '', 'url': url, 'source': site, 'streams': streams}
        if streams:
            _cache.set(ck, film, 20 * 60)       # these links are signed and expire
        return film
    except Exception as e:
        xbmc.log('[Starfleet/%s] detail error (%s): %s' % (site, slug, e), xbmc.LOGWARNING)
        return None


_load_generated()
