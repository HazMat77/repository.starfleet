"""Mirror domains of the live / sports sites: the same site (same pages, same API) under several addresses.

Each tuple lists addresses that were compared byte for byte and answer identically (checked 2026-11-07 against the FMHY live-TV and
live-sports lists). core.http.request tries the next address of a family when the one asked for cannot be reached or answers with a
server-side outage (502/503/504/52x), so a blocked or dead domain no longer takes the whole source with it. The address that worked
is remembered for a while so the next calls go straight to it.
"""
import time

FAMILIES = (
    ('api.ppv.st', 'api.ppv.tj', 'api.ppv.rw', 'api.ppv.ms', 'api.ppv.bi', 'api.ppvs.pk', 'api.ppv.ug'),
    ('ppv.st', 'ppv.tj', 'ppv.rw', 'ppv.ms', 'ppv.bi', 'ppvs.pk', 'ppv.ug'),
    ('tim-streams.com', 'timstreams.co.rw'),
    ('reedstreams.to', 'reedstreams.st'),
    ('ntv.st', 'ntv.cx', 'ntvs.cx', 'ntvstream.cx'),
    ('dlive.sx', 'dlhd.pk', 'dlhd.st', 'dlstreams.st', 'thedaddy.pk'),
    ('ondemand.st', 'ondemand.to', 'damitv.st'),
    ('strmfree.st', 'strmfree.pk', 'streamfree.top'),
    ('roxiestreams.info', 'roxiestreams.su', 'roxiestreams.biz'),
    ('livelive24.com', 'livelive24.st'),
    ('www.futbol-x.xyz', 'www.futbol-x.top'),
    ('www.rivestream.app', 'rivestream.ru'),
    ('daddylive.li', 'daddylive.app', 'daddylive.mov'),
    ('streamcorner.foo', 'streamcorner.cloud', 'streamcorner.fun', 'streamcorner.st'),
)

_INDEX = {h: f for f in FAMILIES for h in f}
_PREFER = {}                       # family -> (host that last worked, time)
_PREFER_SECS = 900


def siblings(host):
    """The other addresses of this host's family, the one that worked last first; [] when the host has no mirrors."""
    fam = _INDEX.get(host)
    if not fam:
        return []
    out = [h for h in fam if h != host]
    pref = _PREFER.get(fam)
    if pref and time.time() - pref[1] < _PREFER_SECS and pref[0] in out:
        out.remove(pref[0])
        out.insert(0, pref[0])
    return out


def worked(host):
    fam = _INDEX.get(host)
    if fam:
        _PREFER[fam] = (host, time.time())


def swap_headers(headers, old, new):
    """The request headers with the old address replaced by the new one (Referer / Origin / Host follow the mirror used)."""
    if not headers:
        return headers
    return {k: (v.replace(old, new) if isinstance(v, str) and old in v else v) for k, v in headers.items()}
