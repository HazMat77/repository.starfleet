# -*- coding: utf-8 -*-
"""
core/http.py - the one place the scrapers get an HTTP connection from.

    get / post / head / put / delete / request(...)   drop-in for requests.get / requests.post / ...
    session()                                          the shared session behind them
    new_session()                                      a session of its own with the same fast set-up (for code that wants cookies)

What it does that a bare requests.get() does not:

  * ONE TLS context for every connection. requests/urllib3 build a fresh context for each new connection and re-read the whole CA
    bundle into it (about 0.3 s of CPU on a PC, several times that on a Fire TV Stick). A search that opens dozens of connections paid
    that dozens of times. Certificates and host names are still checked.
  * Connections are kept and reused (keep-alive) by the thread that opened them, so a source asked twice (a title page, then its
    stream list) does not do a second TCP + TLS set-up.
  * Cookies live only for the length of one call (redirects inside a call still carry them, as with a bare requests.get()) and are
    dropped afterwards, so one site's cookies never reach another.
  * A host that cannot be reached at all (connect timeout, refused, no DNS) is skipped for three minutes after it failed three times in
    a row, so a dead site costs one short wait instead of a full timeout on every click. A host that answers slowly is never counted.

It is safe for add-ons that load this module: nothing global is patched. The module also stands in for `requests` where the scrapers
import it (`from starfleetscrapers.core import http as requests`): get / post / head / put / delete / request / Session are replaced,
everything else (exceptions, utils, adapters, codes...) is requests' own.
"""
import os
import ssl
import threading
import time
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter

from starfleetscrapers.core import mirrors as _mirrors
from starfleetscrapers.core import dns_fallback as _dns_fallback  # noqa: F401 - importing this installs its DNS cache (see that module); done
                                                                   # here, not just on a failure, so every platform gets it from the first request

_PLAIN = os.environ.get('STARFLEET_PLAIN_HTTP') == '1'     # switch the layer off (for comparing, or if it ever misbehaves)
_lock = threading.Lock()
_local = threading.local()
_ctx = None

_FAILS = 3                 # connection failures in a row before a host is skipped
_FAIL_WINDOW = 90          # ... within this many seconds
_DOWN_SECS = 180
_state = {}                # host -> [consecutive failures, first failure time, down until]

# Adaptive timeouts: how long each host usually takes to answer (smoothed), kept for this run. A host that has always answered within a
# second or two is not waited for the caller's full timeout (often 10-25 s): a dead-slow answer is given up on sooner, so a search
# is not held up by one stuck request. Never longer than the caller asked for, never shorter than _ADAPT_MIN, and stretched on a slow
# network or a low-end device, so a slow connection does not lose answers it would have got.
_ADAPT_MIN = 5.0
_ADAPT_SAMPLES = 3
_lat = {}                  # host -> [smoothed seconds to the first answer, samples]


def _note_latency(host, secs):
    if not host:
        return
    st = _lat.get(host)
    if st is None:
        if len(_lat) > 400:
            _lat.clear()
        _lat[host] = [secs, 1]
    else:
        st[0] = st[0] * 0.7 + secs * 0.3
        st[1] += 1


def _net_factor():
    """1.0 on a fast connection, more when the answers of the hosts used so far are slow in general (a slow network flag)."""
    vals = sorted(v[0] for v in list(_lat.values()) if v[1] >= _ADAPT_SAMPLES)
    if len(vals) < 4:
        return 1.0
    med = vals[len(vals) // 2]
    return 1.6 if med > 2.5 else (1.25 if med > 1.2 else 1.0)


def _tier_factor():
    try:
        from starfleetscrapers.core import device as _dev
        return {'low': 1.3, 'mid': 1.0, 'high': 1.0}.get(_dev.profile()['tier'], 1.0)
    except Exception:
        return 1.0


def _adaptive(host, timeout):
    """The timeout to use for this host: the caller's, or shorter when the host has proven to answer quickly."""
    if timeout is None:
        return timeout
    # a long timeout is asked for on purpose (an IPTV provider's whole series list, a playlist, a guide): never cut short
    try:
        if float(timeout[1] if isinstance(timeout, tuple) and len(timeout) == 2 else timeout) >= 30:
            return timeout
    except Exception:
        pass
    st = _lat.get(host)
    if not st or st[1] < _ADAPT_SAMPLES:
        return timeout
    lim = max(_ADAPT_MIN, st[0] * 4.0 + 2.0) * _net_factor() * _tier_factor()
    if isinstance(timeout, tuple) and len(timeout) == 2:
        c, r = timeout
        return (min(c, lim) if c else c, min(r, lim) if r else r)
    try:
        return min(float(timeout), lim)
    except Exception:
        return timeout


def _context():
    global _ctx
    if _ctx is None:
        with _lock:
            if _ctx is None:
                ctx = ssl.create_default_context()
                try:
                    ctx.load_verify_locations(cafile=requests.certs.where())
                except Exception:
                    pass
                _ctx = ctx
    return _ctx


class _FastAdapter(HTTPAdapter):
    def init_poolmanager(self, *a, **k):
        k['ssl_context'] = _context()
        super(_FastAdapter, self).init_poolmanager(*a, **k)

    def cert_verify(self, conn, url, verify, cert):
        conn.cert_reqs = 'CERT_REQUIRED' if url.lower().startswith('https') else 'CERT_NONE'
        conn.ca_certs = None                                 # the shared context already holds them: nothing is read again
        conn.ca_cert_dir = None


def _build():
    s = requests.Session()
    try:
        s.mount('https://', _FastAdapter(pool_connections=64, pool_maxsize=64, max_retries=0))
    except Exception:
        s.mount('https://', HTTPAdapter(pool_connections=64, pool_maxsize=64, max_retries=0))
    s.mount('http://', HTTPAdapter(pool_connections=64, pool_maxsize=64, max_retries=0))
    return s


def new_session():
    """A session of its own (it keeps cookies) with the shared TLS set-up."""
    return _build()


Session = new_session


def _plain_session():
    """For the rare call that turns certificate checking off (verify=False) or sends a client certificate: urllib3's own set-up."""
    s = getattr(_local, 'p', None)
    if s is None:
        s = _local.p = requests.Session()
    return s


def session():
    """This thread's session (one per thread: a requests session is not meant to be shared by threads that redirect at once)."""
    s = getattr(_local, 's', None)
    if s is None:
        s = _local.s = _build()
    return s


def _host(url):
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ''


def host_down(url):
    """True while a host is being skipped (see above)."""
    st = _state.get(_host(url))
    return bool(st and st[2] > time.time())


def _note(host, ok):
    if not host:
        return
    if ok:
        _state.pop(host, None)
        return
    now = time.time()
    st = _state.get(host)
    if not st or now - st[1] > _FAIL_WINDOW:
        st = [0, now, 0]
    st[0] += 1
    if st[0] >= _FAILS:
        st[2] = now + _DOWN_SECS
        st[0], st[1] = 0, now
    _state[host] = st
    if len(_state) > 400:
        for k in [k for k, v in _state.items() if v[2] < now and now - v[1] > _FAIL_WINDOW]:
            _state.pop(k, None)


_OUTAGE = (502, 503, 504, 520, 521, 522, 523, 524, 525, 526)


def request(method, url, **kw):
    if _PLAIN:
        return requests.request(method, url, **kw)
    host = _host(url)
    mirrors = _mirrors.siblings(host)
    if not mirrors:
        return _request_one(method, url, **kw)
    # a site with mirror addresses: when this one cannot be reached (or its server is down) the same call goes to the next address
    first = None
    try:
        r = _request_one(method, url, **kw)
        if r.status_code not in _OUTAGE:
            _mirrors.worked(host)
            return r
        first = r
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError):
        pass
    for alt in mirrors:
        if _state.get(alt, (0, 0, 0))[2] > time.time():
            continue
        kw2 = dict(kw)
        kw2['headers'] = _mirrors.swap_headers(kw.get('headers'), host, alt)
        try:
            r = _request_one(method, url.replace(host, alt, 1), **kw2)
        except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError):
            continue
        if r.status_code in _OUTAGE:
            continue
        _mirrors.worked(alt)
        return r
    if first is not None:
        return first
    raise requests.exceptions.ConnectionError('%s and its mirrors could not be reached' % host)


def _request_one(method, url, **kw):
    host = _host(url)
    if host_down(url):
        raise requests.exceptions.ConnectionError('%s was unreachable a moment ago (skipped for a few minutes)' % host)
    if 'proxies' not in kw:
        # a host an ISP block was found for goes through the viewer's verified US / Canadian proxy (nothing else ever does)
        from starfleetscrapers.core import block_guard as _bg
        _px = _bg.proxies_for(host)
        if _px:
            kw['proxies'] = _px
    s = _plain_session() if (kw.get('verify') is False or kw.get('cert')) else session()
    if kw.get('timeout') is not None and not kw.get('stream'):
        kw['timeout'] = _adaptive(host, kw['timeout'])
    t0 = time.time()
    try:
        try:
            r = s.request(method, url, **kw)
        except requests.exceptions.ConnectionError as e0:
            # the local resolver would not answer for this name: ask a public DNS-over-HTTPS resolver and try once more
            from starfleetscrapers.core import dns_fallback as _dnsf
            if not (_dnsf.is_dns_failure(e0) and _dnsf.override(host)):
                raise
            r = s.request(method, url, **kw)
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError) as e:
        # only a host that cannot be connected to counts: a TLS error or an interrupted transfer says nothing about it being down
        text = str(e)
        if not isinstance(e, requests.exceptions.SSLError) and 'Read timed out' not in text and 'RemoteDisconnected' not in text                 and 'Connection aborted' not in text:
            _note(host, False)
        raise
    finally:
        s.cookies.clear()                                    # cookies last for one call, as with a bare requests.get()
    _note(host, True)
    if r.status_code < 500:
        _note_latency(host, time.time() - t0)
    return r


def get(url, params=None, **kw):
    kw.setdefault('allow_redirects', True)
    return request('GET', url, params=params, **kw)


def post(url, data=None, json=None, **kw):
    return request('POST', url, data=data, json=json, **kw)


def head(url, **kw):
    kw.setdefault('allow_redirects', False)
    return request('HEAD', url, **kw)


def put(url, **kw):
    return request('PUT', url, **kw)


def delete(url, **kw):
    return request('DELETE', url, **kw)


# ---- sites that ask "are you human?" ------------------------------------------------------------------------------------------------------
#
# A few sites put a check in front of their pages (a checkbox such as "I am not a robot"). A person passes it once on the Verify screen of the
# Starfleet Helper (Android) or of the HazMat apps, and the cookie that earns - with the exact user agent it was issued to - is kept here, on
# this device, and replayed by the sources of that site. Nothing in this file answers a check; a person always does the click.
# The cookie belongs to the connection it was earned on, so each person verifies on their own device.
#
#   SITES                       the verifiable sites: key -> name, kind, page to verify, hosts, (category, key) of its source switch
#   set_clearance(key, cf, ua, cookie)   keep what the Verify screen earned (and switch the site's sources on)
#   clearance(key)              (cf_clearance, user agent) that works now, else ('', '')
#   cookies_for(url)            (cookies dict, user agent) for a host of a verified site, else ({}, '')
#   mark_bad(key)               the site refused the cookie (expired): the sources fall back and the Verify list asks for another check
#   status(key)                 'verified' | 'expired' | 'none', and when it was earned
SITES = {
    'extto': {'name': 'EXT.to', 'kind': 'Debrid', 'url': 'https://ext.to/browse/?q=test&cat=1', 'hosts': ('ext.to',), 'toggle': ('debrid', 'extto')},
    'bt4g': {'name': 'Bt4g', 'kind': 'Debrid', 'url': 'https://bt4gprx.com/search?q=test&category=all', 'hosts': ('bt4gprx.com',), 'toggle': ('debrid', 'bt4g')},
    '1337x': {'name': '1337x', 'kind': 'Debrid', 'url': 'https://www.1377x.to/srch?search=test', 'hosts': ('1377x.to', '1337xx.to', '1377x.is'), 'toggle': ('debrid', '1337x')},
    'sportsurge': {'name': 'SportSurge', 'kind': 'Sports', 'url': 'https://v2.sportsurge.net/', 'hosts': ('v2.sportsurge.net',), 'toggle': ('sports', 'sportsurge')},
}
_clear_lock = threading.Lock()
_clear_cache = {'mtime': -1.0, 'data': {}}


def _clear_path():
    try:
        from starfleetscrapers import host as _h
        return os.path.join(_h.profile(), 'site_clearance.json')
    except Exception:
        return ''


def _clear_load():
    """{key: {cf, cookie, ua, ts, bad}} from the profile folder (re-read when the file changes)."""
    import json
    p = _clear_path()
    try:
        m = os.path.getmtime(p) if p else -2.0
    except OSError:
        m = -2.0
    with _clear_lock:
        if m != _clear_cache['mtime']:
            data = {}
            if m >= 0:
                try:
                    with open(p, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                except Exception:
                    data = {}
            _clear_cache['mtime'] = m
            _clear_cache['data'] = data if isinstance(data, dict) else {}
        return _clear_cache['data']


def _clear_save(data):
    import json
    p = _clear_path()
    if not p:
        return
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        os.replace(tmp, p)
    except Exception:
        pass
    with _clear_lock:
        _clear_cache['mtime'] = -1.0


def set_clearance(key, cf, ua, cookie=''):
    """Keeps what the Verify screen earned for a site and switches the site's sources on."""
    if key not in SITES or not (cf or cookie):
        return False
    data = dict(_clear_load())
    data[key] = {'cf': cf or '', 'cookie': cookie or '', 'ua': ua or '', 'ts': int(time.time()), 'bad': 0, 'on': True}
    _clear_save(data)
    try:
        from starfleetscrapers.core import source_toggles as _st
        cat, k = SITES[key]['toggle']
        _st.set_on(cat, k, True)
    except Exception:
        pass
    return True


def site_on(category, key):
    """Whether the sources of a site this device verified are switched on (kept with the verification itself, so it holds even where the
    add-on settings cannot be written, such as while the settings screen is open). None when no site of that source is verified."""
    for k, s in SITES.items():
        if tuple(s['toggle']) == (category, key):
            d = _clear_load().get(k) or {}
            if d.get('cf') or d.get('cookie'):
                return bool(d.get('on', True))
    return None


def set_site_on(category, key, value):
    """The person switched a verified site's sources on or off: kept with its verification. False when that source is not a verified site."""
    for k, s in SITES.items():
        if tuple(s['toggle']) == (category, key):
            data = dict(_clear_load())
            if k in data:
                data[k] = dict(data[k], on=bool(value))
                _clear_save(data)
                return True
    return False


def clearance(key):
    d = _clear_load().get(key) or {}
    if d.get('bad') or not d.get('cf'):
        return ('', '')
    return (d.get('cf', ''), d.get('ua', ''))


def mark_bad(key):
    data = dict(_clear_load())
    if key in data and not data[key].get('bad'):
        data[key] = dict(data[key], bad=int(time.time()))
        _clear_save(data)


def forget(key):
    data = dict(_clear_load())
    if data.pop(key, None) is not None:
        _clear_save(data)


def status(key):
    d = _clear_load().get(key) or {}
    if not d.get('cf'):
        return ('none', 0)
    return ('expired' if d.get('bad') else 'verified', int(d.get('ts') or 0))


def cookies_for(url):
    """(cookies, user agent) for a page of a site the person verified on this device, else ({}, '')."""
    try:
        host = (urlparse(url).hostname or '').lower()
    except Exception:
        return ({}, '')
    for key, s in SITES.items():
        if any(host == h or host.endswith('.' + h) for h in s['hosts']):
            d = _clear_load().get(key) or {}
            if d.get('cf') and not d.get('bad'):
                return ({'cf_clearance': d['cf']}, d.get('ua', ''))
    return ({}, '')


def site_for(url):
    try:
        host = (urlparse(url).hostname or '').lower()
    except Exception:
        return ''
    for key, s in SITES.items():
        if any(host == h or host.endswith('.' + h) for h in s['hosts']):
            return key
    return ''


def __getattr__(name):
    """Anything not replaced above (exceptions, utils, adapters, codes, Response...) is requests' own."""
    return getattr(requests, name)
