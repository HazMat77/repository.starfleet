# -*- coding: utf-8 -*-
"""
Channel feeds: live TV channels that carry a game, offered as extra links in that game's list of streams.

A game's broadcast networks (the scoreboard's "TSN", "FOX", "beIN SPORTS"...) are matched against a list of live channels; each channel that
carries one of those networks becomes a link. There is no 24/7 channel list: a channel only shows up next to a game that is on it.

The list of channels ships with the module (chanfeeds_snapshot.json, every link checked when it was made) and renews itself in the background
every 12 hours from the feed it came from; the renewed list is kept in the profile folder and only replaces the shipped one when it is not smaller.

    streams_for(sport_slug, networks)   -> [{'label', 'url', 'quality', 'language', 'source'}]
"""
import base64
import json
import os
import re
import threading
import time

SOURCE = 'Channels'

_FEED = 'https://hellobaba.site/'
_REFRESH_EVERY = 12 * 3600
_lock = threading.Lock()
_items = None
_refreshing = False


# ---- which channels carry which network ------------------------------------------------------------------------------------------------

# (words in a broadcast name, words in the channel's own text). The channel text is "<group> <channel> <link name>".
_NETWORKS = [
    (r'\btsn\b|\btsn\s?[1-5]\b', r'\btsn'),
    (r'\bfox\b|\bfs[12]\b|fox sports', r'\bfox'),
    (r'\bcbs\b|golazo|paramount', r'\bcbs'),
    (r'\bnbc\b|peacock|cnbc|\busa network\b', r'nbc sports|nbcny|cnbc'),
    (r'bein', r'bein'),
    (r'tudn|univision|\bvix\b', r'tudn|vix'),
    (r'telemundo', r'telemundo'),
    (r'tnt sports', r'tnt'),
    (r'sky sports|\bsky\b', r'\bsky'),
    (r'premier sports', r'premier'),
    (r'mlb network|mlb\.tv|\bmlb tv\b', r'\bmlb'),
    (r'nba tv|league pass', r'\bnba'),
    (r'nfl network|nfl\+|redzone', r'\bnfl'),
    (r'tennis channel|\btennis\b', r'tennis'),
    (r'willow', r'willow'),
    (r'laliga|la liga', r'laliga'),
    (r'sportv|sport tv|premiere', r'sport ?tv|sportv|premiere'),
    (r'euro ?sport', r'euro ?sport'),
    (r'\bd ?sports\b|directv', r'\bd ?sports?'),
    (r'fancode', r'fancode'),
    (r'\bf1 tv\b|formula 1', r'\bf1\b|formula'),
    (r'motogp', r'motogp'),
    (r'\bufc\b', r'\bufc\b'),
    (r'\bwwe\b', r'\bwwe\b'),
    (r'\baew\b', r'\baew\b'),
]
_NETWORKS = [(re.compile(a, re.I), re.compile(b, re.I)) for a, b in _NETWORKS]

# sports that have a channel of their own: the channel is offered for every event of that sport
_SPORT_CHANNELS = {
    'f1': r'\bf1\b|formula|sky sports f1',
    'motogp': r'motogp',
    'ufc': r'\bufc\b',
    'mma': r'\bufc\b',
    'wwe': r'\bwwe\b|\baew\b',
    'tennis': r'tennis',
    'golf': r'\bgolf|dp tour',
}
_SPORT_CHANNELS = {k: re.compile(v, re.I) for k, v in _SPORT_CHANNELS.items()}

_MAX_PER_NETWORK = 6
_MAX_TOTAL = 14


def _text(it):
    return '%s %s %s' % (it.get('c', ''), it.get('n', ''), it.get('l', ''))


# ---- the list --------------------------------------------------------------------------------------------------------------------------

def _profile_dir():
    return os.environ.get('STARFLEET_PROFILE') or ''


def _cache_path():
    d = _profile_dir()
    return os.path.join(d, 'chanfeeds.json') if d else ''


def _load_file(path):
    try:
        with open(path, encoding='utf-8') as f:
            d = json.load(f)
        return d.get('ts', 0), d.get('items') or []
    except Exception:
        return 0, []


def _all():
    global _items
    with _lock:
        if _items is not None:
            return _items
        ts0, snap = _load_file(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'chanfeeds_snapshot.json'))
        if not snap:
            try:
                import pkgutil
                d = json.loads(pkgutil.get_data(__name__.rpartition('.')[0] or 'starfleetscrapers.sports', 'chanfeeds_snapshot.json').decode('utf-8'))
                ts0, snap = d.get('ts', 0), d.get('items') or []
            except Exception:
                pass
        items, ts = snap, ts0
        cp = _cache_path()
        if cp and os.path.isfile(cp):
            ts1, cached = _load_file(cp)
            if cached and len(cached) >= len(snap) * 0.8:
                items, ts = cached, ts1
        _items = items
    if time.time() - ts > _REFRESH_EVERY:
        _refresh_async()
    return _items


# ---- the matching ----------------------------------------------------------------------------------------------------------------------

def streams_for(sport_slug, networks):
    """Channels that carry a game of `sport_slug` shown on `networks` (a list of broadcast names, or one '|'-joined string)."""
    if isinstance(networks, str):
        networks = [n for n in networks.split('|') if n.strip()]
    nets = [n.strip() for n in (networks or []) if n and n.strip()]
    items = _all()
    if not items:
        return []
    picked, seen = [], set()

    def add(it, tag=''):
        u = it['u']
        if u in seen:
            return
        seen.add(u)
        if it.get('k'):
            sep = '&' if '|' in u else '|'
            u = u + sep + 'X-Starfleet-License-Type=clearkey&X-Starfleet-License-Key=' + it['k'].replace(':', '%3A')
        name = (it.get('l') or '').strip()
        if not name or re.match(r'link\s*\d*$', name, re.I):
            name = (it.get('n') or 'Channel').strip()
        name = re.sub(r'\s+', ' ', name)
        picked.append({'label': name + ' (live channel)', 'url': u, 'quality': 'HD' if re.search(r'fhd|hd', _text(it), re.I) else '', 'language': '', 'source': SOURCE})

    for words, chan in _NETWORKS:
        hit = [n for n in nets if words.search(n)]
        if not hit:
            continue
        # "TSN1" / "TSN 4" on the scoreboard: only that channel; plain "TSN": all of them
        digits = set(re.findall(r'(?:tsn|sky sports|bein sports|euro ?sport)\s?(\d)\b', ' '.join(hit).lower()))
        cands = [it for it in items if chan.search(_text(it))]
        if digits:
            narrowed = [it for it in cands if any(re.search(r'(?<![\d.])%s(?![\d])' % d, it.get('n', '') + ' ' + it.get('l', '')) for d in digits)]
            cands = narrowed or cands
        for it in cands[:_MAX_PER_NETWORK]:
            add(it)
    sc = _SPORT_CHANNELS.get((sport_slug or '').lower())
    if sc is not None:
        for it in [i for i in items if sc.search(_text(i))][:_MAX_PER_NETWORK]:
            add(it)
    return picked[:_MAX_TOTAL]


# ---- renewing the list -----------------------------------------------------------------------------------------------------------------

_KEY = b'l9K5bT5xC1wP7pK1'
_IV = b'k5K4nN7oU8hL6l19'


def _aes_decrypt(data):
    """AES-128-CBC with PKCS padding; pycryptodome when there is one, else the pure Python AES the resolvers carry."""
    data = data[:len(data) // 16 * 16]
    try:
        from Crypto.Cipher import AES
        p = AES.new(_KEY, AES.MODE_CBC, _IV).decrypt(data)
    except ImportError:
        try:                                    # on the phone / box: Java's own AES
            from java import jclass
            c = jclass('javax.crypto.Cipher').getInstance('AES/CBC/PKCS5Padding')
            c.init(2, jclass('javax.crypto.spec.SecretKeySpec')(_KEY, 'AES'), jclass('javax.crypto.spec.IvParameterSpec')(_IV))
            return bytes(b & 0xFF for b in c.doFinal(data))
        except ImportError:
            from starfleetresolve.ru.lib.jscrypto import pyaes
            dec = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(_KEY, _IV), padding=pyaes.PADDING_NONE)
            p = dec.feed(data) + dec.feed()
    return p[:-p[-1]] if p and 1 <= p[-1] <= 16 else p


def _fetch(path):
    import requests
    r = requests.get(_FEED + path, timeout=15, headers={'User-Agent': 'okhttp/4.12.0'})
    r.raise_for_status()
    raw = r.content.strip()
    return json.loads(_aes_decrypt(base64.b64decode(raw + b'=' * (-len(raw) % 4))).decode('utf-8', 'replace'))


def _alive(url):
    import requests
    try:
        r = requests.get(url.split('|')[0], timeout=7, stream=True, headers={'User-Agent': 'Mozilla/5.0'})
        if r.status_code != 200:
            return False
        head = next(r.iter_content(600), b'')
        r.close()
        return head[:7] == b'#EXTM3U' or b'<MPD' in head or head[:5] == b'<?xml'
    except Exception:
        return False


def _refresh_async():
    global _refreshing
    with _lock:
        if _refreshing or not _profile_dir():
            return
        _refreshing = True
    threading.Thread(target=_refresh, daemon=True, name='sf-chanfeeds').start()


def _refresh():
    global _items, _refreshing
    try:
        from concurrent.futures import ThreadPoolExecutor
        cats = []
        for e in _fetch('sports.txt'):
            c = e.get('cat')
            c = json.loads(c) if isinstance(c, str) else c
            if c and c.get('visible') and c.get('type') == 'custom' and c.get('api'):
                cats.append(c)
        want = re.compile('|'.join(w.pattern for _, w in _NETWORKS) + '|' + '|'.join(v.pattern for v in _SPORT_CHANNELS.values()), re.I)

        def channels(c):
            try:
                out = []
                for x in _fetch(c['api']):
                    ch = x.get('channel')
                    ch = json.loads(ch) if isinstance(ch, str) else ch
                    if ch and ch.get('visible', True) and ch.get('links') and want.search('%s %s' % (c.get('name', ''), ch.get('name', ''))):
                        out.append((c['name'].strip(), (ch.get('name') or '').strip(), ch['links']))
                return out
            except Exception:
                return []

        with ThreadPoolExecutor(max_workers=6) as ex:
            chans = [x for part in ex.map(channels, cats) for x in part]

            def links(t):
                try:
                    res = []
                    for l in _fetch(t[2]):
                        u = l.get('link') or ''
                        if not u.startswith('http') or not _alive(u):
                            continue
                        k = l.get('api') or ''
                        res.append({'c': t[0], 'n': t[1], 'l': (l.get('name') or '').strip(), 'u': u,
                                    'k': k if re.fullmatch(r'[0-9a-f]{32}:[0-9a-f]{32}', k) else ''})
                    return res
                except Exception:
                    return []
            found = [i for part in ex.map(links, chans) for i in part]
        seen, items = set(), []
        for i in found:
            if i['u'] not in seen:
                seen.add(i['u'])
                items.append(i)
        cur = _items or []
        if len(items) >= max(10, int(len(cur) * 0.6)):
            cp = _cache_path()
            tmp = cp + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump({'ts': int(time.time()), 'items': items}, f, ensure_ascii=False, separators=(',', ':'))
            os.replace(tmp, cp)
            with _lock:
                _items = items
        # (too few links back: the list that is there stays, and the next start asks again)
    except Exception:
        pass
    finally:
        _refreshing = False
