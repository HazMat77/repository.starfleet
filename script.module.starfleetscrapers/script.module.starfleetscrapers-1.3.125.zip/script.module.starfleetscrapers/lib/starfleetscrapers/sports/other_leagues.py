# -*- coding: utf-8 -*-
"""The "other leagues" game lists (hockey, basketball, baseball, rugby, boxing, golf, more, and the soccer leagues the schedule feeds lack),
team logos for them, and the streams of one such game.

    games(menu)                       -> [{id, title, league, kind, start_ts, live}]   (Strikeout, plus FawaNews channels for soccer / basketball)
    streams(href, sport, title, ts)   -> [{label, url, source}]                         (the players that really open first, then the generic search)
    logos(names, sport)               -> {team name: logo address or ''}                (ESPN's team search, kept on disk)

Used by the HazMat sports menu; Binge Hazmat Sports has its own copy of the same logic in binge_bridge.py.
"""
import json
import os
import re
import threading
import time
import unicodedata

_SLUG = {'hockey': 'nhl', 'basketball': 'nba', 'baseball': 'mlb', 'soccer': 'soccer', 'rugby': 'rugby', 'boxing': 'boxing', 'golf': 'golf', 'more': ''}


def _ascii(s):
    return unicodedata.normalize('NFKD', s or '').encode('ascii', 'ignore').decode('ascii')


# ── games ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

# The AHL's own schedule and live scores (the league's HockeyTech feed: no other schedule site lists the AHL). The games' streams are looked up by
# the teams' names when the game is on the air (onhockey.tv and the other hockey sites list it then).
_AHL_URL = ('https://lscluster.hockeytech.com/feed/index.php?feed=modulekit&view=scorebar&numberofdaysahead=3&numberofdaysback=0'
            '&key=ccb91f29d6744675&client_code=ahl&fmt=json&lang=en&league_id=4')
_AHL_LOGOS = {}
_ahl_cache = [0, []]


def _ahl_games():
    """[{id, title, league, kind, start_ts, live, home_score, away_score, detail}] of the AHL: games on now and the next three days (visitor vs home)."""
    if time.time() - _ahl_cache[0] < 40 and _ahl_cache[1]:
        return _ahl_cache[1]
    import requests
    from datetime import datetime
    d = requests.get(_AHL_URL, headers={'User-Agent': 'Mozilla/5.0'}, timeout=12).json()
    out = []
    for g in (d.get('SiteKit') or {}).get('Scorebar') or []:
        status = str(g.get('GameStatus') or '')
        if status not in ('1', '2'):
            continue                                    # finished, postponed or cancelled
        try:
            ts = int(datetime.fromisoformat(g['GameDateISO8601']).timestamp())
        except Exception:
            continue
        home, away = g.get('HomeLongName') or '', g.get('VisitorLongName') or ''
        if not home or not away:
            continue
        for name, tid in ((home, g.get('HomeID')), (away, g.get('VisitorID'))):
            if tid:
                _AHL_LOGOS[name] = 'https://assets.leaguestat.com/ahl/logos/50x50/%s.png' % tid
        live = status == '2'
        out.append({'id': 'ahl:' + str(g.get('ID')), 'title': '%s vs %s' % (away, home), 'league': 'AHL', 'kind': 'hockey', 'start_ts': ts, 'live': live,
                    'home_score': str(g.get('HomeGoals') or '0') if live else '', 'away_score': str(g.get('VisitorGoals') or '0') if live else '',
                    'detail': ('%s %s' % (g.get('PeriodNameShort') or '', g.get('GameClock') or '')).strip() if live else ''})
    _ahl_cache[0], _ahl_cache[1] = time.time(), out
    return out


def _nick(name):
    return re.sub(r'[^a-z]', '', _ascii(name).lower().split()[-1]) if name.strip() else ''


def games(menu):
    """The games of one menu; the soccer and basketball menus also list the FawaNews channels that are on the air (games no schedule has),
    each only when it is not already there. The hockey menu also lists the AHL."""
    from starfleetscrapers.sports import sports_pages_live as sp
    out = [{'id': e['href'], 'title': e['title'], 'league': e['league'], 'kind': e['kind'], 'start_ts': e['start_ts'], 'live': e['live']}
           for e in sp.so_games(menu)]
    if menu == 'hockey':
        try:
            have = [g['title'].lower() for g in out]
            for a in _ahl_games():
                sides = re.split(r'\s+vs\s+', a['title'])
                keys = [_nick(x) for x in sides]
                if any(all(k and k in t for k in keys) for t in have):
                    continue                            # a hockey site already lists this game (with its own streams)
                out.append(a)
        except Exception:
            pass
    if menu in ('soccer', 'basketball'):
        def keys(t):
            return [max((w for w in re.split(r'\s+', side.lower()) if len(w) >= 4), key=len, default=side.lower())
                    for side in re.split(r'\s+vs\.?\s+', t, maxsplit=1)]
        try:
            fawa = sp.fn_games(menu)
        except Exception:
            fawa = []
        for e in fawa:
            k = keys(e['title'])
            if any(all(x in g['title'].lower() for x in k) for g in out):
                continue
            out.append({'id': e['href'], 'title': e['title'], 'league': e['league'], 'kind': e['kind'], 'start_ts': e['start_ts'], 'live': True})
    return out


def streams(href, sport='', title='', start_ts=0):
    """The streams of one game of those lists: its verified players first, then whatever the other sources have for the same game."""
    from concurrent.futures import ThreadPoolExecutor
    from starfleetscrapers.sports import sports_pages_live as sp
    from starfleetscrapers.sports import sports_sources as ss

    def direct():
        if href.startswith('ahl:'):
            return []
        if 'fawanews.sc' in href:
            r = sp._fn_stream(href)
            return [('FawaNews', r[1])] if r else []
        return sp.so_streams(href)

    def generic():
        slug = 'hockey' if href.startswith('ahl:') else _SLUG.get(sport, sport)     # (the hockey slug asks every hockey site, the AHL's own among them)
        return ss.get_event_streams('', '', slug, _ascii(title), int(start_ts or 0)) or []
    out, seen = [], set()
    with ThreadPoolExecutor(max_workers=2) as ex:
        f1 = ex.submit(direct)
        f2 = ex.submit(generic) if title else None
        try:
            for lab, url in f1.result(timeout=40):
                if url not in seen:
                    seen.add(url)
                    out.append({'label': lab, 'url': url, 'source': 'FawaNews' if lab == 'FawaNews' else 'Strikeout'})
        except Exception:
            pass
        if f2 is not None:
            try:
                for s in f2.result(timeout=60):
                    u = s.get('url') or ''
                    if u and u not in seen and 'strikeout' not in ((s.get('source') or '') + (s.get('label') or '')).lower():
                        seen.add(u)
                        out.append({'label': s.get('label') or 'Stream', 'url': u, 'source': s.get('source') or ''})
            except Exception:
                pass
    return out


# ── logos ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

_LOGO_SPORT = {'soccer': ('soccer',), 'basketball': ('basketball',), 'hockey': ('hockey',), 'baseball': ('baseball',),
               'rugby': ('rugby', 'rugby union', 'rugby league'), 'football': ('football',), 'cricket': ('cricket',)}
_logos = {}
_lock = threading.Lock()
_loaded = [False]


def _path():
    base = ''
    try:
        from starfleetscrapers import host
        base = host.profile() or ''
    except Exception:
        pass
    base = os.environ.get('HAZMAT_FILES') or base or os.environ.get('STARFLEET_PROFILE') or ''
    return os.path.join(base, 'team_badges.json')


def _plain(s):
    return re.sub(r'[^a-z0-9]', '', _ascii(s).lower())


def _find(name, sport):
    import requests
    want = _LOGO_SPORT.get(sport, ())
    q = re.sub(r'\s+(W|U\d\d|II|B)$', '', name.strip())
    r = requests.get('https://site.web.api.espn.com/apis/common/v3/search', params={'query': q, 'limit': 8, 'type': 'team', 'mode': 'prefix'},
                     headers={'User-Agent': 'Mozilla/5.0'}, timeout=12)
    pn = _plain(q)
    best = ''
    for t in r.json().get('items') or []:
        if want and (t.get('sport') or '').lower().replace('-', ' ') not in want:
            continue
        pt = _plain(t.get('displayName') or '')
        if pt and (pt == pn or (len(pn) >= 5 and (pn in pt or pt in pn))):
            lg = t.get('logos') or []
            href = (lg[0].get('href') if lg else '') or ''
            if href:
                best = href
                break
    if best.startswith('https://a.espncdn.com/i/'):
        best = 'https://a.espncdn.com/combiner/i?img=' + best[len('https://a.espncdn.com'):] + '&w=96&h=96'
    return best


def logos(names, sport=''):
    """{name: logo address or ''}: names not looked up before are searched (up to 40 per call); every answer, even an empty one, is kept on disk
    (an empty one is tried again after a week)."""
    from concurrent.futures import ThreadPoolExecutor
    with _lock:
        if not _loaded[0]:
            _loaded[0] = True
            try:
                with open(_path(), encoding='utf-8') as f:
                    _logos.update(json.load(f))
            except Exception:
                pass
    now = int(time.time())
    out, todo = {}, []
    for n in [n for n in names if n]:
        if sport == 'hockey' and n in _AHL_LOGOS:
            out[n] = _AHL_LOGOS[n]
            continue
        v = _logos.get(sport + '|' + n)
        if v is not None and (v[0] or now - v[1] < 7 * 86400):
            out[n] = v[0]
        elif n not in todo:
            todo.append(n)

    def one(n):
        try:
            return n, _find(n, sport)
        except Exception:
            return n, None
    if todo:
        with ThreadPoolExecutor(max_workers=4) as ex:
            for n, b in ex.map(one, todo[:40]):
                if b is not None:
                    _logos[sport + '|' + n] = [b, now]
                    out[n] = b
        try:
            with open(_path(), 'w', encoding='utf-8') as f:
                json.dump(_logos, f)
        except Exception:
            pass
    return out
