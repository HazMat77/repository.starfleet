# -*- coding: utf-8 -*-
"""
resources/lib/sports_sources.py

Sports live-stream scraper.

Event sources (priority order):
  1. ESPN API          — NFL, NBA, MLB, NHL, CFB, NCAAB, CFL (official logos + scores)
  2. TheSportsDB       — UFC, Boxing, WWE (free tier, API key 3)
  3. istreameast.cx    — fallback / soccer / F1 / anything else (currently dead — fast-fails)
  4. streamseast.is    — supplementary (merged, deduplicated)
  5. methstreams.gs    — supplementary (merged, deduplicated)
  6. totalsportek24.is — multi-sport (soccer/NFL/NBA/NHL/MLB/UFC/boxing/F1/CFB/NCAAB/WWE)
  7. onhockey.tv       — NHL-specific supplementary

Stream sources (merged):
  1. streamseast.is    — iframe chain → embed player
  2. methstreams.gs    — supplementary stream source (JS-rendered, slug cross-ref)
  3. totalsportek24.is — multi-sport stream source
  4. onhockey.tv       — NHL-specific stream source (direct + cross-ref by title)

Also merged in via json_data.py (pre-scraped by a standalone orchestrator on
a dedicated PC, pushed to GitHub — see resources/lib/json_data.py's own
docstring): streameast.json, all24.json, daddylive.json, mut.json (mut.st/
MutStreams — added 2026-07-29, resolved via the same embed.st resolver
crackstreams' own standalone scraper used to use — see below), and
sportsbite.json (sportsbite.org — added 2026-07-29; its real backend is a
separate domain, api.watchfooty.st, found live by watching the page's own
network traffic; each match offers both a dead 'hd' source — chains to the
same WASM-blocked embedindia.st below — and a working 'delta' source).

Removed (dead as of 2026):
  - CrackStreams (all mirrors: mx, biz, app, crack.sx — all dead) — live
    in-addon scraping removed first, then its standalone-scraper JSON path
    (crackstreams.json via json_data.py) removed too 2026-08-02: confirmed
    live its current player mechanism pushes video through an opaque blob:
    URL with no plain, network-sniffable .m3u8 request at all (same
    obfuscation pattern as the daddylive adult-channels dead end) — the
    standalone scraper's own resolver could no longer capture anything
    real, confirmed by a live run producing zero events across every
    category.
  - roxiestreams.info (both the live _roxie_streams() scrape here and a
    2026-08-02 standalone-scraper attempt) — confirmed live its m3u8 CDN
    (a formaturamaxi.com.br host) sits behind genuine Cloudflare
    bot-protection that 403s every non-browser client tried (plain
    requests, cloudscraper), independently confirmed to also fail
    real Kodi playback — every link this site produces was found but
    never actually playable.
  - TotalSportek original (totalsportek.to/.com/.2 — all unreachable)
  - ppv.land / ppv.to (Cloudflare blocks plain requests, removed per user
    request). Also investigated: ppv.st/.cx/.is/.lc (all 4 domains are one
    shared backend/frontend) — real event data, but every embed goes
    through embedindia.st's own WASM anti-bot challenge that headless
    Chromium never gets past (confirmed live: zero stream requests ever
    fire) — not wired in anywhere, same class of dead end.
  - Sportsurge (dead code — _SPORTSURGE_BASES undefined, never called)
  - JustWatch Sports (dead code — never called)

Cache: event list 10 min (live data), stream list 5 min
"""

from starfleetscrapers import host as _sfhost
import re
import os
import base64
import datetime
import time
import json
import threading
import xbmc
from starfleetscrapers.sports.timeparse import strptime as _strp   # datetime.strptime fails inside Kodi on Android
import xbmcaddon
import xbmcvfs
from concurrent.futures import ThreadPoolExecutor, as_completed

ADDON    = _sfhost.addon()
_PROFILE = _sfhost.profile()

from starfleetscrapers.core import http as _req
from starfleetscrapers.core import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

ISE_BASE        = 'https://istreameast.st'   # 2026-11-21: the old .cx is gone; .st lists games as rows and each game page lists player pages
CRACK_BASE      = 'https://crackstreams.mx'
_CRACK_MIRRORS  = ['https://crackstreams.mx', 'https://crackstreams.biz',
                   'https://crackstreams.app', 'https://crack.sx']
METH_BASE       = 'https://methstreams.gs'
# crackstreams.mx serves the same events and the same player links as MethStreams (checked 2026-11-04: identical
# listings and allStreams), so it is the fallback when methstreams.gs does not answer
_METH_MIRRORS   = ('https://methstreams.gs', 'https://crackstreams.mx')
ROXIE_BASE      = 'https://roxiestreams.info'
SEAST_BASE      = 'https://streameasti.is'   # streamseast.is is dead (connect timeout) — site moved here
TSTEK_BASE      = 'https://totalsportek24.is'
ONHOCKEY_BASE   = 'https://onhockey.tv'

_session = None

# Set to True to use HTTP session. However it seems that timeout is sometimes ignored when session are used
#  so it is currently set to False
_use_session = False

from starfleetscrapers.core import net_guard as _net_guard


def _sess():
    global _session, _use_session
    if _use_session:
        if _session is None:
            _session = _req.Session()
            _session.headers.update(_HEADERS)
            a = _req.adapters.HTTPAdapter(
                pool_connections=24, pool_maxsize=6,
                # connect=0: a host that cannot be connected to is not retried (that tripled the
                # wait on every dead source); read errors still get their two retries
                max_retries=_req.adapters.Retry(total=2, connect=0, backoff_factor=0.5, redirect=False)
            )
            _session.mount('https://', a)
            _net_guard.guard(_session)
        return _session
    else:
        return _req


_cf_session = None

def _cf_sess():
    """Return a Cloudflare-bypass session: cloudscraper if available, else plain requests."""
    global _cf_session
    if _cf_session is None:
        # 1. Try cloudscraper (pip install cloudscraper — works on most platforms)
        try:
            import cloudscraper as _cs
            _cf_session = _cs.create_scraper(
                browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
            )
            _cf_session.headers.update(_HEADERS)
            _net_guard.guard(_cf_session)
            xbmc.log('[Starfleet/Sports] CF bypass: cloudscraper OK', xbmc.LOGINFO)
            return _cf_session
        except Exception:
            pass
        xbmc.log('[Starfleet/Sports] CF bypass unavailable, using plain session', xbmc.LOGWARNING)
        _cf_session = _sess()
    return _cf_session


def _get(url, timeout=12):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _get_json(url, timeout=10):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


_TSDB_BASE = 'https://www.thesportsdb.com/api/v1/json/123'


def get_venue_image(venue_id='', team_name=''):
    """
    Venue thumbnail/fanart for an event's backdrop, via TheSportsDB —
    verified live end-to-end: lookupvenue.php?id=<venue_id> when a venue id
    is already known (TSDB-sourced events carry idVenue directly); when it
    isn't (MLB/NBA/NHL's own "official" schedules only give a bare venue
    name string, not an id), falls back to searchteams.php?t=<team_name> to
    get that team's own idVenue, then the same venue lookup — TheSportsDB
    doesn't expose venue search by name on the free tier (confirmed empty
    response live), but every team record carries its home venue's id, so
    looking up by the home team's name works as a reliable equivalent.
    Cached 30 days since venue data is effectively static.
    """
    ck = 'tsdb_venue_%s_%s' % (venue_id, re.sub(r'[^a-z0-9]', '_', team_name.lower())[:60])
    cached = _cache.get(ck)
    if cached is not None:
        return cached or {}

    try:
        import urllib.parse as _up5
        vid = venue_id
        if not vid and team_name:
            data = _get_json('%s/searchteams.php?t=%s' % (_TSDB_BASE, _up5.quote(team_name)), timeout=8)
            teams = data.get('teams') or []
            vid = teams[0].get('idVenue', '') if teams else ''
        if not vid:
            _cache.set(ck, False, 7 * 24 * 3600)
            return {}

        vdata = _get_json('%s/lookupvenue.php?id=%s' % (_TSDB_BASE, vid), timeout=8)
        venues = vdata.get('venues') or []
        if not venues:
            _cache.set(ck, False, 7 * 24 * 3600)
            return {}

        v = venues[0]
        result = {'thumb': v.get('strThumb', ''), 'fanart': v.get('strFanart1') or v.get('strThumb', '')}
        if not result['thumb'] and not result['fanart']:
            _cache.set(ck, False, 7 * 24 * 3600)
            return {}
        _cache.set(ck, result, 30 * 24 * 3600)
        return result
    except Exception as e:
        xbmc.log('[Starfleet/Sports] get_venue_image(venue_id=%r, team_name=%r): %s'
                  % (venue_id, team_name, e), xbmc.LOGWARNING)
        return {}


_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()


def _ts_to_dt(date_str):
    """Parse ISO 8601 UTC date string to (unix_timestamp, display_string). Returns (0, '') on failure."""
    if not date_str:
        return 0, ''
    try:
        # Normalise: strip timezone marker and fractional seconds
        clean = date_str.strip()
        clean = clean.split('.')[0]          # drop .000
        clean = clean.rstrip('Z')            # drop trailing Z
        if '+' in clean:
            clean = clean.split('+')[0]      # drop +00:00
        # Try with seconds (19 chars) then without (16 chars)
        dt = None
        for fmt, n in (('%Y-%m-%dT%H:%M:%S', 19), ('%Y-%m-%dT%H:%M', 16)):
            try:
                dt = _strp(clean[:n], fmt)
                break
            except Exception:
                pass
        if dt is None:
            return 0, date_str
        ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
        return ts, dt.strftime('%b %d %H:%M UTC')
    except Exception:
        return 0, date_str


def _us_eastern_offset_seconds(d):
    """UTC offset (seconds) for US Eastern on date `d`, DST-aware via the
    standard 2007+ rule (2nd Sunday in March → 1st Sunday in November)."""
    march1 = datetime.date(d.year, 3, 1)
    dst_start = march1 + datetime.timedelta(days=(6 - march1.weekday()) % 7 + 7)
    nov1 = datetime.date(d.year, 11, 1)
    dst_end = nov1 + datetime.timedelta(days=(6 - nov1.weekday()) % 7)
    return -4 * 3600 if dst_start <= d < dst_end else -5 * 3600


_RE_SCORE = re.compile(r'\b\d+\s*[-:]\s*\d+\b')


def _strip_score(title):
    """Remove live score like '3 - 2' or '1:0' from a match title for cross-source matching."""
    return _RE_WS.sub(' ', _RE_SCORE.sub('', title)).strip(' -')


# NHL clubs by the short forms sites write: "Hurricanes vs Jets", "Carolina vs Winnipeg", "CAR vs WPG", "Canes @ Jets", "Habs"...
# id -> (nickname words and nicknames used alone, abbreviations)
_NHL_ALIASES = {
    'ana': ('ducks', 'ana'), 'bos': ('bruins', 'bos'), 'buf': ('sabres', 'buf'), 'cgy': ('flames', 'cgy cal'),
    'car': ('hurricanes canes', 'car'), 'chi': ('blackhawks hawks', 'chi'), 'col': ('avalanche avs', 'col'),
    'cbj': ('blue jackets jackets', 'cbj'), 'dal': ('stars', 'dal'), 'det': ('red wings wings', 'det'),
    'edm': ('oilers', 'edm'), 'fla': ('florida panthers panthers', 'fla'), 'lak': ('kings', 'lak la'), 'min': ('wild', 'min'),
    'mtl': ('canadiens habs', 'mtl mon'), 'nsh': ('predators preds', 'nsh nas'), 'njd': ('devils', 'njd nj'),
    'nyi': ('islanders isles', 'nyi'), 'nyr': ('rangers', 'nyr'), 'ott': ('senators sens', 'ott'),
    'phi': ('flyers', 'phi'), 'pit': ('penguins pens', 'pit'), 'sjs': ('sharks', 'sjs sj'), 'sea': ('kraken', 'sea'),
    'stl': ('blues', 'stl'), 'tbl': ('lightning bolts', 'tbl tb tam'), 'tor': ('maple leafs leafs', 'tor'),
    'uta': ('mammoth utah hockey club', 'uta'), 'van': ('canucks', 'van'), 'vgk': ('golden knights', 'vgk lv vegas'),
    'wsh': ('capitals caps', 'wsh was'), 'wpg': ('winnipeg jets jets', 'wpg'),
}
_NHL_TOKEN = {}
for _id, (_nicks, _abbr) in _NHL_ALIASES.items():
    for _a in _abbr.split():
        _NHL_TOKEN.setdefault(_a, _id)
_NHL_PHRASES = []           # (phrase, id), longest first, so "blue jackets" wins over "jackets"
for _id, (_nicks, _abbr) in _NHL_ALIASES.items():
    for _ph in re.findall(r"(?:golden knights|blue jackets|red wings|maple leafs|hockey club|winnipeg jets|florida panthers|[a-z]+)", _nicks):
        _NHL_PHRASES.append((_ph, _id))
_NHL_PHRASES.sort(key=lambda x: -len(x[0]))
_NHL_PHRASES = [(p_, i_) for p_, i_ in _NHL_PHRASES if p_ not in ('winnipeg', 'florida', 'club', 'hockey', 'utah')] + [('utah', 'uta')]


_NHL_CITIES = {
    'anaheim': 'ana', 'boston': 'bos', 'buffalo': 'buf', 'calgary': 'cgy', 'carolina': 'car', 'chicago': 'chi', 'colorado': 'col',
    'columbus': 'cbj', 'dallas': 'dal', 'detroit': 'det', 'edmonton': 'edm', 'florida': 'fla', 'los angeles': 'lak', 'minnesota': 'min',
    'montreal': 'mtl', 'nashville': 'nsh', 'new jersey': 'njd', 'ottawa': 'ott', 'philadelphia': 'phi', 'pittsburgh': 'pit',
    'san jose': 'sjs', 'seattle': 'sea', 'st louis': 'stl', 'saint louis': 'stl', 'tampa bay': 'tbl', 'tampa': 'tbl', 'toronto': 'tor',
    'utah': 'uta', 'vancouver': 'van', 'vegas': 'vgk', 'las vegas': 'vgk', 'washington': 'wsh', 'winnipeg': 'wpg',
}


def _nhl_teams(title):
    """The NHL clubs a title names by nickname or abbreviation (city alone is left to the word match): [ids] in order."""
    import unicodedata as _ud
    s = _ud.normalize('NFKD', _strip_score(title) or '').encode('ascii', 'ignore').decode().lower()
    s = re.sub(r"[^a-z0-9 ]+", ' ', s)
    s = ' ' + re.sub(r'\s+', ' ', s) + ' '
    found = []
    for ph, tid in _NHL_PHRASES:
        i = s.find(' ' + ph + ' ')
        if i >= 0:
            found.append((i, tid))
            s = s[:i + 1] + ' ' * len(ph) + s[i + 1 + len(ph):]
    # abbreviations: in capitals ("CAR vs WPG"), or in a title that is nothing but two short names ("car vs wpg") - in a longer lower-case
    # title "car" or "min" are ordinary words
    raw_t = title or ''
    for m in re.finditer(r'[A-Z]{2,3}', raw_t):
        tid = _NHL_TOKEN.get(m.group(0).lower())
        if tid:
            found.append((m.start(), tid))
    short = [w for w in re.split(r'[^A-Za-z]+', raw_t) if w and w.lower() not in ('vs', 'v', 'at')]
    if 2 <= len(short) <= 3 and all(len(w) <= 3 for w in short):
        for w in short:
            tid = _NHL_TOKEN.get(w.lower())
            if tid:
                found.append((raw_t.lower().find(w.lower()), tid))
    # a title that is nothing but two cities ("Carolina vs Winnipeg"). Only then: next to a nickname a city may belong to another sport's club.
    if not found:
        parts = [re.sub(r'[^a-z ]+', '', x.lower()).strip() for x in re.split(r'\s+(?:vs\.?|v|@|at|-)\s+', _strip_score(raw_t) or '') if x.strip()]
        if len(parts) == 2 and parts[0] in _NHL_CITIES and parts[1] in _NHL_CITIES and parts[0] != parts[1]:
            found = [(0, _NHL_CITIES[parts[0]]), (1, _NHL_CITIES[parts[1]])]
    found.sort()
    out = []
    for _i, tid in found:
        if tid not in out:
            out.append(tid)
    return out



def _title_score(title_a, title_b):
    """Return number of significant words (len>=3) from title_a that appear in title_b (case-insensitive).
    Uses >=3 so short but meaningful team name words (Sox, Mets, Cubs, Red, etc.) are counted.
    Two titles that name the same two NHL clubs in other forms ("Hurricanes vs Jets", "CAR vs WPG") count as a full match."""
    words_a = [w.lower() for w in re.split(r'\W+', _strip_score(title_a)) if len(w) >= 3]
    b_lower = _strip_score(title_b).lower()
    base = sum(1 for w in words_a if w in b_lower)
    if base < 4:
        try:
            ta, tb = _nhl_teams(title_a), _nhl_teams(title_b)
            if len(ta) >= 2 and len(tb) >= 2 and set(ta[:2]) == set(tb[:2]):
                return max(base, 4)
        except Exception:
            pass
    return base


def _titles_match(title_a, title_b, threshold=2):
    """Return True if at least `threshold` significant words from title_a appear in title_b."""
    return _title_score(title_a, title_b) >= threshold


# ── Sport categories ──────────────────────────────────────────────────────────

# Custom Starfleet-branded league icons (resources/skins/Default/media/sports/)
# — override the generic ESPN/TheSportsDB icon below for whichever slugs have
# one. Resolved to an absolute path (li.setArt()/ListItem accept a local
# filesystem path exactly like a URL — this is a different code path than the
# skin-XML relative "media/x.png" resolution that's confirmed broken
# elsewhere in this addon, so no Window Property workaround is needed here).
# Falls back to the original remote icon if the file is ever missing for any
# reason (e.g. a packaging mistake), so a bad path never blanks out an icon.
_SPORTS_ICON_DIR = os.path.join('resources', 'skins', 'Default', 'media', 'sports')

# Kodi caches every image it renders (Textures13.db) keyed by the exact path
# string, local files included — it does NOT compare file content/mtime, so
# overwriting an icon's PNG bytes at the same path is invisible to Kodi for
# any icon a device already rendered before the update (confirmed live: a
# full icon-set refresh shipped, but only sports the device had never
# browsed before picked up the new art — everything previously viewed kept
# showing the old cached bitmap indefinitely). Bumping this on every real
# icon-set change gives every file a brand-new path Kodi has never cached,
# which is a permanent, self-healing fix — no manual cache-clear step is
# ever needed again for icon updates specifically.
_ICON_SET_VERSION = 2


def _local_sport_icon(filename, fallback_url):
    try:
        addon_path = ADDON.getAddonInfo('path')
        base, ext = os.path.splitext(filename)
        versioned_filename = '%s_v%d%s' % (base, _ICON_SET_VERSION, ext)
        local_path = os.path.join(addon_path, _SPORTS_ICON_DIR, versioned_filename)
        if xbmcvfs.exists(local_path):
            return local_path
    except Exception as e:
        xbmc.log('[Starfleet/Sports] _local_sport_icon(%s): %s' % (filename, e), xbmc.LOGWARNING)
    return fallback_url


# Fallback icons (ESPN CDN / Wikipedia) used when TSDB API is unavailable
_CATEGORIES = [
    {'slug': 'soccer',   'label': 'Soccer',                    'tsdb': 'Soccer',              'icon': _local_sport_icon('soccer.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/fifa.png')},
    {'slug': 'nfl',      'label': 'NFL',                       'tsdb': 'American Football',   'icon': _local_sport_icon('nfl.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nfl.png')},
    {'slug': 'nba',      'label': 'NBA',                       'tsdb': 'Basketball',          'icon': _local_sport_icon('nba.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nba.png')},
    {'slug': 'mlb',      'label': 'MLB',                       'tsdb': 'Baseball',            'icon': _local_sport_icon('mlb.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/mlb.png')},
    {'slug': 'nhl',      'label': 'NHL',                       'tsdb': 'Ice Hockey',          'icon': _local_sport_icon('nhl.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png')},
    {'slug': 'ufc',      'label': 'UFC / MMA',                 'tsdb': 'Mixed Martial Arts',  'icon': _local_sport_icon('ufc.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ufc.png')},
    {'slug': 'boxing',   'label': 'Boxing',                    'tsdb': 'Boxing',              'icon': _local_sport_icon('boxing.png', 'https://www.thesportsdb.com/images/media/sport/thumb/boxing1519439649.jpg')},
    {'slug': 'tennis',   'label': 'Tennis',                    'tsdb': 'Tennis',              'icon': _local_sport_icon('tennis.png', 'https://www.thesportsdb.com/images/media/sport/thumb/asdh2v1548684497.jpg')},
    {'slug': 'rugby',    'label': 'Rugby',                     'tsdb': 'Rugby',               'icon': _local_sport_icon('rugby.png', 'https://www.thesportsdb.com/images/media/sport/thumb/vbki5v1547214439.jpg')},
    {'slug': 'cricket',  'label': 'Cricket',                   'tsdb': 'Cricket',             'icon': _local_sport_icon('cricket.png', 'https://www.thesportsdb.com/images/media/sport/thumb/cricket1519439826.jpg')},
    {'slug': 'f1',       'label': 'Formula 1',                 'tsdb': 'Motorsport',          'icon': _local_sport_icon('f1.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/f1.png')},
    {'slug': 'motogp',   'label': 'MotoGP',                    'tsdb': 'Motorsport',          'icon': _local_sport_icon('motogp.png', 'https://www.thesportsdb.com/images/media/sport/thumb/motorsport.jpg')},
    {'slug': 'golf',     'label': 'Golf',                      'tsdb': 'Golf',                'icon': _local_sport_icon('golf.png', 'https://www.thesportsdb.com/images/media/sport/thumb/golf1519439822.jpg')},
    {'slug': 'darts',    'label': 'Darts',                     'tsdb': 'Darts',               'icon': _local_sport_icon('darts.png', 'https://www.thesportsdb.com/images/media/sport/thumb/darts1519439673.jpg')},
    {'slug': 'snooker',  'label': 'Snooker',                   'tsdb': 'Snooker',             'icon': _local_sport_icon('snooker.png', 'https://www.thesportsdb.com/images/media/sport/thumb/snooker1519439836.jpg')},
    {'slug': 'handball', 'label': 'Handball',                  'tsdb': 'Handball',            'icon': _local_sport_icon('handball.png', 'https://www.thesportsdb.com/images/media/sport/thumb/handball1519439771.jpg')},
    {'slug': 'volleyball','label': 'Volleyball',               'tsdb': 'Volleyball',          'icon': _local_sport_icon('volleyball.png', 'https://www.thesportsdb.com/images/media/sport/thumb/volleyball1519439870.jpg')},
    {'slug': 'cycling',  'label': 'Cycling',                   'tsdb': 'Cycling',             'icon': _local_sport_icon('cycling.png', 'https://www.thesportsdb.com/images/media/sport/thumb/cycling1519439660.jpg')},
    {'slug': 'cfb',      'label': 'College Football (CFB)',     'tsdb': 'American Football',   'icon': _local_sport_icon('cfb.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaaf.png')},
    {'slug': 'ncaab',    'label': 'College Basketball (NCAAB)', 'tsdb': 'Basketball',          'icon': _local_sport_icon('ncaab.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaab.png')},
    {'slug': 'cfl',      'label': 'CFL',                        'tsdb': 'American Football',   'icon': _local_sport_icon('cfl.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/cfl.png')},
    {'slug': 'wnba',     'label': 'WNBA',                       'tsdb': 'Basketball',          'icon': _local_sport_icon('wnba.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/wnba.png')},
    {'slug': 'ncaaw',    'label': "College Basketball (Women's)", 'tsdb': 'Basketball',        'icon': _local_sport_icon('ncaaw.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaa.png')},
    {'slug': 'pwhl',     'label': 'PWHL',                       'tsdb': 'Ice Hockey',          'icon': _local_sport_icon('pwhl.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png')},
    {'slug': 'ncaah',    'label': 'College Hockey (NCAA)',      'tsdb': 'Ice Hockey',          'icon': _local_sport_icon('ncaah.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaa.png')},
    {'slug': 'wwe',      'label': 'WWE / Wrestling',            'tsdb': 'Wrestling',           'icon': _local_sport_icon('wwe.png', 'https://r2.thesportsdb.com/images/media/league/badge/r43xns1461424282.png')},
]

# Map slug → TSDB sport name for calendar lookups
_SLUG_TO_TSDB_SPORT = {c['slug']: c['tsdb'] for c in _CATEGORIES}
# slug -> the curated Starfleet sport icon (same one the sport picker itself
# uses) - fallback thumb for get_todays_sport_events below when an event has
# no team badge of its own (most non-official sources - livesites, hoofoot,
# tvnow, methstreams - don't carry one at all, confirmed live: 0/26 NBA and
# most soccer/NHL events on a real day had any badge, so Home's Soccer/
# NBA & NHL rows showed blank icons for nearly everything in them).
_CATEGORY_ICON = {c['slug']: c['icon'] for c in _CATEGORIES}

_TSDB_BASE       = 'https://www.thesportsdb.com/api/v1/json/123'
_TSDB_SPORTS_API = _TSDB_BASE + '/all_sports.php'
_TSDB_DAY_API    = _TSDB_BASE + '/eventsday.php'


def get_sport_categories():
    """Fetch ALL sports from TheSportsDB (cached 24h), merged with our ESPN-backed known sports.

    Cache key bumped to v4 — v3's cached blob was built with the old
    icon-priority bug still in place (TheSportsDB's own live sport thumbnail
    always won over our curated icon, burying the custom Starfleet-branded
    local icons under a generic stock photo — see the is_local_icon check
    below), so v3 needs one more forced rebuild too, same reasoning as the
    v2->v3 bump above."""
    ck = 'tsdb_sport_cats_v4'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    # Fetch TSDB sport list
    tsdb_sports = []
    try:
        data = _get_json(_TSDB_SPORTS_API, timeout=8)
        tsdb_sports = data.get('sports') or []
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB all_sports: %s' % e, xbmc.LOGWARNING)
    
    # Build lookup: tsdb_name → {icon, id}
    tsdb_by_name = {}
    for s in tsdb_sports:
        name = s.get('strSport', '').strip()
        if name:
            tsdb_by_name[name] = {
                'icon': s.get('strSportThumb', ''),
                'id':   s.get('idSport', ''),
            }
    
    result = []
    seen_tsdb = set()

    # 1. Known slugs first (preserves order + ESPN live-score support).
    # NOTE: several of these intentionally share the same 'tsdb' value
    # (NFL/CFB/CFL are all TheSportsDB's single "American Football" sport,
    # NBA/NCAAB share "Basketball") — that's fine and expected, each is
    # still its own real menu section. seen_tsdb below is ONLY to stop
    # loop 2 (raw TheSportsDB sport list) from adding a redundant generic
    # "American Football"/"Basketball" entry on top of these curated ones —
    # it must NOT skip entries in this curated loop itself. That exact
    # mistake (a bare tsdb_name-seen check gating this loop too) is what
    # silently dropped CFB and CFL from the Sports menu entirely: CFL's
    # own icon/section never appeared, and CFL games ended up folding into
    # whatever + NFL's "American Football" TheSportsDB/ESPN event fetch
    # returned instead, with no way to tell them apart — confirmed live.
    for cat in _CATEGORIES:
        tsdb_name = cat.get('tsdb', '')
        seen_tsdb.add(tsdb_name)
        tsdb_info = tsdb_by_name.get(tsdb_name, {})
        # A local file path (our custom Starfleet-branded icon) always wins
        # over TheSportsDB's own live sport thumbnail — that thumbnail is a
        # generic stock photo for the whole sport (e.g. a random soccer
        # match action shot, not a logo), never something we'd actually
        # want over deliberately-branded art. For every slug that still
        # only has the old generic ESPN/TheSportsDB fallback URL, keep the
        # original behavior of preferring TSDB's own (usually fresher)
        # icon, falling back to ours only when TSDB has none.
        is_local_icon = cat['icon'] and not cat['icon'].startswith('http')
        icon = cat['icon'] if is_local_icon else (tsdb_info.get('icon') or cat['icon'])
        result.append({
            'slug':       cat['slug'],
            'label':      cat['label'],
            'icon':       icon,
            'tsdb_sport': tsdb_name,
        })

    # 2. Remaining TSDB sports not yet in our list
    for s in tsdb_sports:
        name = s.get('strSport', '').strip()
        if not name or name in seen_tsdb:
            continue
        seen_tsdb.add(name)
        slug = re.sub(r'[^a-z0-9]+', '_', name.lower()).strip('_')
        icon = s.get('strSportThumb', '')
        result.append({
            'slug':       slug,
            'label':      name,
            'icon':       icon,
            'tsdb_sport': name,
        })

    if result:
        _cache.set(ck, result, 86400)
    else:
        # Complete fallback: static list only
        result = [
            {'slug': c['slug'], 'label': c['label'], 'icon': c['icon'], 'tsdb_sport': c.get('tsdb', '')}
            for c in _CATEGORIES
        ]
    return result


@_cache.coalesced
def _tsdb_calendar_events(tsdb_sport, date_str, max_items):
    """Fetch TheSportsDB events for a sport on date_str (YYYY-MM-DD). tsdb_sport is the TSDB sport name."""
    if not tsdb_sport:
        return []

    # TheSportsDB's free key ("3" in the URL) is a shared public test key with
    # a low, global rate limit — confirmed live: every non-big-4 sport (which
    # has no other official-API source and depends entirely on this call, 7x
    # per category for a week of dates) was getting 429 Too Many Requests on
    # every single date, every time, meaning these categories silently got 0
    # results from their primary source and fell back to weaker/dateless
    # supplementary scrapers. This had no caching at all, so browsing a
    # handful of niche sports back-to-back (exactly how this was found) kept
    # re-hitting the same throttled endpoint. Caching per (sport, date) cuts
    # our own repeat-request volume within a session/short window.
    ck = 'tsdb_cal_%s_%s' % (tsdb_sport, date_str)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    if _cache.get('tsdb_cal_429'):
        return []   # the shared key is being throttled right now - every other date would 429 too

    try:
        import urllib.parse as _urlparse
        url = '%s?d=%s&s=%s' % (_TSDB_DAY_API, date_str, _urlparse.quote(tsdb_sport))
        data = _get_json(url, timeout=8)
    except Exception as e:
        if '429' in str(e):
            _cache.set('tsdb_cal_429', True, 120)
        elif '403' in str(e):
            # refused outright (not just throttled): stop asking for half an hour, and say so once instead of once per sport and day
            if not _cache.get('tsdb_cal_429'):
                xbmc.log('[Starfleet/Sports] TSDB calendar refused (403); pausing it for 30 minutes', xbmc.LOGWARNING)
            _cache.set('tsdb_cal_429', True, 30 * 60)
        else:
            xbmc.log('[Starfleet/Sports] TSDB calendar (%s %s): %s' % (tsdb_sport, date_str, e), xbmc.LOGWARNING)
        # Short negative-cache so a 429 doesn't get re-hit seconds later by
        # the next category browsed in the same session — but short enough
        # to recover quickly once the shared key's rate limit window passes.
        _cache.set(ck, [], 2 * 60)
        return []

    events = []
    for ev in (data.get('events') or []):
        try:
            date_ev   = ev.get('dateEvent', '') or ''
            time_ev   = (ev.get('strTime') or '00:00:00')[:8]
            timestamp = ev.get('strTimestamp', '') or ''
            ts, dt_str = 0, ''
            if timestamp:
                ts_raw = timestamp.replace(' ', 'T') if 'T' not in timestamp else timestamp
                ts, dt_str = _ts_to_dt(ts_raw)
            if not ts and date_ev:
                try:
                    dt = _strp('%s %s' % (date_ev, time_ev), '%Y-%m-%d %H:%M:%S')
                    ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
                    dt_str = dt.strftime('%b %d %H:%M UTC')
                except Exception:
                    # Still show a date if we at least have one, even without a time
                    try:
                        dt = _strp(date_ev, '%Y-%m-%d')
                        ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
                        dt_str = dt.strftime('%b %d')
                    except Exception:
                        ts, dt_str = 0, date_ev
        except Exception:
            # One malformed record must not sink the rest of this day's events
            ts, dt_str, date_ev = 0, '', ev.get('dateEvent', '') or ''

        home  = ev.get('strHomeTeam', '')
        away  = ev.get('strAwayTeam', '')
        title = ('%s vs %s' % (home, away)) if (home and away) else ev.get('strEvent', '')
        logo  = (ev.get('strHomeTeamBadge') or ev.get('strThumb') or ev.get('strBanner') or '')

        events.append({
            'id':          str(ev.get('idEvent', '')),
            'slug':        str(ev.get('idEvent', '')),
            'path':        '',
            'title':       title,
            'match_title': title,
            'datetime':    dt_str,
            'league':      ev.get('strLeague', tsdb_sport),
            'logo':        logo,
            'home_badge':  ev.get('strHomeTeamBadge', ''),
            'away_badge':  ev.get('strAwayTeamBadge', ''),
            'is_live':     False,
            'start_ts':    ts,
            'venue':       ev.get('strVenue', ''),
            'venue_id':    str(ev.get('idVenue', '') or ''),
            'home_team':   ev.get('strHomeTeam', ''),
        })
        if len(events) >= max_items:
            break
    _cache.set(ck, events, 15 * 60)
    return events


def get_onhockey_events():
    """Return all onhockey.tv events with their league field populated, plus
    hockey games only the LiveSites providers list (deduped by title)."""
    events = _onhockey_events()
    try:
        extra = _livesites_events('hockey')
        if extra:
            events = _merge_events(events, extra)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] livesites hockey merge error: %s' % e, xbmc.LOGWARNING)
    return events


@_cache.coalesced
def _livesites_events(sport_slug):
    from starfleetscrapers.sports import sports_starfleet_live as _cw
    return _cw.events_for_slug(sport_slug)


def _livesites_streams(sport_slug, title, include_pages=True):
    from starfleetscrapers.sports import sports_starfleet_live as _cw
    if not title:
        return []
    return _cw.streams_by_title(sport_slug, title, include_pages)


# ── ESPN API ──────────────────────────────────────────────────────────────────

_ESPN_SPORTS = {
    'ufc':   ('mma',        'ufc'),       # one entry per card (event name carries the main event)
    'f1':    ('racing',     'f1'),        # one entry per race weekend
    'nfl':   ('football',   'nfl'),
    'nba':   ('basketball', 'nba'),
    'mlb':   ('baseball',   'mlb'),
    'nhl':   ('hockey',     'nhl'),
    'cfb':   ('football',   'college-football'),
    'ncaab': ('basketball', 'mens-college-basketball'),
    'cfl':   ('football',   'cfl'),
    'wnba':  ('basketball', 'wnba'),
    'ncaaw': ('basketball', 'womens-college-basketball'),
    'ncaah': ('hockey',     'mens-college-hockey'),
    'soccer': ('soccer',   'fifa.world'),   # FIFA World Cup 2026 (Jun–Jul 2026)
}
# Additional soccer leagues polled after the primary
_ESPN_SOCCER_EXTRA = ['eng.1', 'usa.1', 'uefa.champions', 'uefa.europa']
_ESPN_API = 'https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard'

# Groups of our sport slugs that all resolve to the SAME single TheSportsDB
# sport calendar (no separate TSDB sport exists per league) — used to strip
# out other leagues' games from TSDB-sourced events once merged in per
# sport_slug (see get_sport_events). NFL/CFB/CFL share "American Football"
# (confirmed live: CFL and European League of Football games leaked
# straight into NFL with no way to tell them apart). NBA/NCAAB share
# "Basketball" and F1/MotoGP share "Motorsport" the exact same way —
# confirmed live (NCAAB was showing random Australian NBL1/Canadian CEBL
# games) but never had an equivalent filter until now.
_AMFOOTBALL_LEAGUE_KEYWORDS = {
    'nfl':    ('nfl',),
    'cfl':    ('cfl',),
    'cfb':    ('ncaa', 'college'),
    'nba':    ('nba',),
    'ncaab':  ('ncaa', 'college'),
    'wnba':   ('wnba',),
    'ncaaw':  ('ncaa', 'college'),
    'ncaah':  ('ncaa', 'college'),
    'pwhl':   ('pwhl',),
    'f1':     ('formula 1', 'f1', 'grand prix'),
    'motogp': ('motogp', 'moto2', 'moto3'),
}


@_cache.coalesced
def _espn_events(sport_slug, max_items):
    if sport_slug not in _ESPN_SPORTS:
        return []
    sport, league = _ESPN_SPORTS[sport_slug]
    url = _ESPN_API.format(sport=sport, league=league)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ESPN API (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    # ESPN's undated scoreboard keeps showing the PREVIOUS day (all finished games) for hours after midnight, so on a morning with games
    # that evening the list was empty. The team sports also ask for today's and tomorrow's date (US Eastern, ESPN's own day) and merge them.
    all_events = list(data.get('events', []))
    if sport not in ('mma', 'racing'):
        try:
            import datetime as _dt
            try:
                from zoneinfo import ZoneInfo as _Zi
                now_et = _dt.datetime.now(_Zi('America/New_York'))
            except Exception:
                now_et = _dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None) - _dt.timedelta(hours=5)
            seen_ids = {e.get('id') for e in all_events}
            for add in (0, 1):
                day = (now_et + _dt.timedelta(days=add)).strftime('%Y%m%d')
                try:
                    extra = _get_json(url + '?dates=%s&limit=100' % day)
                except Exception:
                    continue
                for e in extra.get('events', []):
                    if e.get('id') not in seen_ids:
                        seen_ids.add(e.get('id'))
                        all_events.append(e)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] ESPN dated scoreboard (%s): %s' % (sport_slug, e), xbmc.LOGINFO)
    data = dict(data, events=all_events)

    events = []
    for ev in data.get('events', []):
        state   = ev.get('status', {}).get('type', {}).get('state', 'pre')
        is_live = (state == 'in')

        comp        = (ev.get('competitions') or [{}])[0]
        competitors = comp.get('competitors', [])
        venue       = comp.get('venue', {}).get('fullName', '')

        match_title = ev.get('name', ev.get('shortName', ''))
        if len(competitors) >= 2 and sport not in ('mma', 'racing'):
            teams  = [c.get('team', {}).get('displayName', '') for c in competitors]
            scores = [c.get('score', '') for c in competitors]
            match_title = ' vs '.join(teams)
            title_str   = match_title
            if is_live and all(scores):
                title_str = '%s %s - %s %s' % (teams[0], scores[0], scores[1], teams[1])
        else:
            title_str = match_title

        logo = ''
        if competitors:
            logo = competitors[0].get('team', {}).get('logo', '')
        if not logo and sport in ('mma', 'racing'):
            logo = ((ev.get('logos') or [{}])[0] or {}).get('href', '') or ((ev.get('league') or {}).get('logos') or [{}])[0].get('href', '')

        start_ts, datetime_str = _ts_to_dt(ev.get('date', ''))
        if sport in ('mma', 'racing') and state == 'post' and start_ts and start_ts < time.time() - 10 * 3600:
            continue                                     # ESPN keeps the last card / race on its scoreboard until the next one; a card that is over is gone

        events.append({
            'id':          ev.get('id', ''),
            'slug':        ev.get('id', ''),
            'path':        '',
            'title':       title_str,
            'match_title': match_title,
            'datetime':    datetime_str,
            'league':      sport_slug.upper(),
            'logo':        logo,
            'is_live':     is_live,
            'start_ts':    start_ts,
            'venue':       venue,
        })
        if len(events) >= max_items:
            break

    return events


# ── TheSportsDB (UFC / Boxing / WWE) ─────────────────────────────────────────

_TSDB_LEAGUES = {
    'ufc':    '4443',
    'boxing': '4414',
    'wwe':    '4412',
}
_TSDB_NEXT = 'https://www.thesportsdb.com/api/v1/json/123/eventsnextleague.php'


def _tsdb_events(sport_slug):
    league_id = _TSDB_LEAGUES.get(sport_slug)
    if not league_id:
        return []
    url = '%s?id=%s' % (_TSDB_NEXT, league_id)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in (data.get('events') or []):
        date_str = ev.get('dateEvent', '') or ''
        time_str = (ev.get('strTime') or '00:00:00')[:8]
        try:
            dt = _strp('%s %s' % (date_str, time_str), '%Y-%m-%d %H:%M:%S')
            start_ts  = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
            datetime_str = dt.strftime('%b %d %H:%M')
        except Exception:
            # Still show a date if we at least have one, even without a time
            try:
                dt = _strp(date_str, '%Y-%m-%d')
                start_ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
                datetime_str = dt.strftime('%b %d')
            except Exception:
                start_ts, datetime_str = 0, date_str

        title_str = ev.get('strEvent', ev.get('strFilename', ''))
        logo = ev.get('strThumb', '') or ev.get('strBanner', '') or ''

        events.append({
            'id':       str(ev.get('idEvent', '')),
            'slug':     str(ev.get('idEvent', '')),
            'path':     '',
            'title':    title_str,
            'datetime': datetime_str,
            'league':   ev.get('strLeague', sport_slug.upper()),
            'logo':     logo,
            'is_live':  False,
            'start_ts': start_ts,
        })

    return events


# ── istreameast.cx events (fallback) ─────────────────────────────────────────

_RE_ISE_CARD = re.compile(
    r'class="event-card"[^>]*onclick="window\.location\.href=[^\']*\'(/links/([^\']+))\''
    r'[^>]*data-event-id="(\d+)"[^>]*data-start-ts="(\d+)"',
    re.IGNORECASE | re.DOTALL
)
_RE_ISE_LOGO = re.compile(
    r'<img[^>]+src="(https://[^"]+thesportsdb[^"]+|https://[^"]+espncdn[^"]+)"[^>]*alt="([^"]*)"',
    re.IGNORECASE
)
_RE_ISE_TITLE    = re.compile(r'class="event-title"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_DATETIME = re.compile(r'class="event-datetime"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_LEAGUE   = re.compile(r'class="event-league"\s*>(.*?)</div>', re.IGNORECASE | re.DOTALL)
_RE_ISE_STATUS   = re.compile(r'class="event-status\s+([^"]+)"\s*>(.*?)</span>', re.IGNORECASE)


def _parse_ise_block(block):
    m_title = _RE_ISE_TITLE.search(block)
    m_dt    = _RE_ISE_DATETIME.search(block)
    m_lg    = _RE_ISE_LEAGUE.search(block)
    m_st    = _RE_ISE_STATUS.search(block)
    m_logo  = _RE_ISE_LOGO.search(block)

    title    = _clean(m_title.group(1)) if m_title else ''
    dt_str   = _clean(m_dt.group(1))   if m_dt    else ''
    league   = _clean(_RE_STRIP.sub(' ', m_lg.group(1))) if m_lg else ''
    league   = re.sub(r'\s+\d+\s+(?:hours?|minutes?)\s+from\s+now.*', '', league, flags=re.IGNORECASE).strip()
    status_class = m_st.group(1).strip() if m_st else 'upcoming'
    is_live  = 'live' in status_class.lower()
    logo_url = m_logo.group(1) if m_logo else ''
    return title, dt_str, league, logo_url, is_live


# 2026-11-21 layout: the home page lists games as <a class="lg-row" href="/Team-vs-Team/<id>"> with a sport tag, a title and a status; a game
# page lists its players as <a class="st-row" href="<player page>"> rows (a name, quality and language pills). The players are web pages.
_RE_ISE_ROW = re.compile(
    r'<a class="lg-row[^"]*"\s+href="(/[^"]+/(\d+))"[^>]*>\s*<span class="lg-tag">([^<]*)</span>\s*<span class="lg-title">([^<]*)</span>'
    r'\s*<span class="lg-status ([^"]*)">', re.S)
_RE_ISE_ST_ROW = re.compile(r'<a class="st-row"([^>]*)>(.*?)</a>', re.S)


def _ise_rows():
    """The home page's game rows (cached 5 min): [{path, id, tag, title, live}]."""
    ck = 'ise_rows_v2'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    rows = []
    try:
        import html as _html_ise
        page = _sess().get(ISE_BASE + '/home1', timeout=10, headers=_HEADERS).text
        for path, eid, tag, title, status in _RE_ISE_ROW.findall(page):
            rows.append({'path': path, 'id': eid, 'tag': _html_ise.unescape(tag).strip(), 'title': _html_ise.unescape(title).strip(),
                         'live': 's-live' in status})
    except Exception as e:
        xbmc.log('[Starfleet/Sports] istreameast rows error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, rows, 5 * 60 if rows else 60)
    return rows


def _ise_players(path):
    """One game page's player pages: [{name, url, hd, english}] (the site's own aggregator pages left out - they only list more links)."""
    ck = 'ise_players_%s' % path
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    out = []
    try:
        import html as _html_ise2
        import urllib.parse as _up_ise
        page = _sess().get(ISE_BASE + path, timeout=10, headers=_HEADERS).text
        for attrs, body in _RE_ISE_ST_ROW.findall(page):
            m = re.search(r'href="(https?://[^"]+)"', attrs)
            if not m:
                continue
            url = _html_ise2.unescape(m.group(1))
            host = _up_ise.urlparse(url).netloc.lower()
            if 'totalsportek' in host or ISE_BASE.split('//')[1] in host:
                continue
            nm = re.search(r'class="st-nm-t">([^<]+)', body)
            pills = [p.lower() for p in re.findall(r'title="([^"]+)"', body)]
            out.append({'name': _html_ise2.unescape(nm.group(1)).strip() if nm else host, 'url': url, 'host': host,
                        'hd': 'hd' in pills, 'english': 'english' in pills})
    except Exception as e:
        xbmc.log('[Starfleet/Sports] istreameast game page error (%s): %s' % (path, e), xbmc.LOGWARNING)
    _cache.set(ck, out, 5 * 60 if out else 60)
    return out


def _web_page_alive(url):
    """False when a web player page cannot give the app's web view anything: the page itself does not open, or it only frames a player on a host that
    does not answer (2026-11-21: the ripplestream / buffnetwork / apexztreams / sportylive family all frame dead *.cfd hosts, so the web view found nothing
    in 25 s). A page with no frame (a player built by its own script) is kept."""
    try:
        import urllib.parse as _up_wp
        r = _sess().get(url, timeout=6, headers=_HEADERS)
        if r.status_code >= 400:
            return False
        frames = re.findall(r'<iframe[^>]+src=["\']([^"\']+)', r.text or '', re.I)
        for f in frames[:2]:
            if f.startswith('//'):
                f = 'https:' + f
            f = _up_wp.urljoin(url, f)
            if not f.startswith('http') or any(b in f for b in ('doubleclick', 'googletagmanager', 'google.com', 'facebook')):
                continue
            try:
                _sess().get(f, timeout=5, headers=dict(_HEADERS, Referer=url), stream=True).close()
            except Exception:
                return False
            return True
        return True
    except Exception:
        return False


# Live-game web-player pages (StreamEast / iStreamEast / Falcon / SportSurge / live-site pages) are not offered: 2026-11-21 they were opened one by one
# and every one is a click-gated player (blank until a source button is pressed, which opens an ad popup), so the app's hidden web view never sees a
# playlist and the entry only ever showed "(web)" and failed. Switch on again only for a page type that is known to start by itself.
_LIVE_WEB_LINKS = False


def _alive_web_pages(entries, limit=4):
    """The entries (dicts with a 'url') whose page is worth handing to the web view, checked side by side, in their given order."""
    if not entries or not _LIVE_WEB_LINKS:
        return []
    from concurrent.futures import ThreadPoolExecutor as _TPE_wp
    ex = _TPE_wp(max_workers=min(len(entries), 8))
    try:
        flags = list(ex.map(lambda e: _web_page_alive(e['url']), entries))
    finally:
        ex.shutdown(wait=False)
    return [e for e, ok in zip(entries, flags) if ok][:limit]


def _ise_streams_by_title(event_title):
    """The player pages istreameast lists for a game found by its title, handed to the app's web view (it cannot read them itself)."""
    if not WEB_SNIFF or not event_title:
        return []
    best, best_score = None, 0
    for r in _ise_rows():
        score = _title_score(event_title, r['title'])
        if score > best_score:
            best_score, best = score, r
    if not best or best_score < 2:
        return []
    streams, seen = [], set()
    # English + HD first, one page per site, a handful only (every one costs the web view a page load)
    for p in sorted(_ise_players(best['path']), key=lambda p: (not p['english'], not p['hd'])):
        if p['host'] in seen:
            continue
        seen.add(p['host'])
        streams.append({'label': 'StreamEast %s (web)' % p['name'], 'url': p['url'], 'quality': 'HD' if p['hd'] else '', 'language': 'english' if p['english'] else '',
                        'source': 'StreamEast', 'web': True})
        if len(streams) >= 8:
            break
    streams = _alive_web_pages(streams, 4)
    for st in streams:
        WEB_URLS.add(st['url'])
    return streams


def _ise_events(sport_slug):
    # the new site lists games on its home page: keep the ones tagged with this sport
    _tags = {'soccer': ('SOCCER', 'FOOTBALL'), 'ufc': ('UFC', 'MMA'), 'cfb': ('NCAAF', 'CFB'), 'ncaab': ('NCAAB', 'CBB')}
    _want = _tags.get(sport_slug, (sport_slug.upper(),))
    _rows = [r for r in _ise_rows() if r['tag'].upper() in _want]
    if _rows:
        return [{'id': r['id'], 'slug': r['path'].strip('/').split('/')[0], 'path': r['path'], 'title': r['title'], 'datetime': '', 'league': r['tag'],
                 'logo': '', 'is_live': r['live'], 'start_ts': 0} for r in _rows]
    url = ISE_BASE + '/schedule/%s' % sport_slug
    on_homepage_fallback = False
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE schedule error (%s): %s' % (sport_slug, e), xbmc.LOGERROR)
        try:
            html = _get(ISE_BASE + '/')
            on_homepage_fallback = True
        except Exception:
            return []

    events = []
    seen   = set()

    for m in _RE_ISE_CARD.finditer(html):
        path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
        if event_id in seen:
            continue
        seen.add(event_id)
        block = html[m.end():m.end() + 900]
        title, dt_str, league, logo_url, is_live = _parse_ise_block(block)

        _soccer_words = ('football', 'soccer', 'fifa', 'premier', 'champions', 'mls', 'laliga', 'bundesliga', 'serie')
        if sport_slug == 'soccer':
            if league and not any(w in league.lower() for w in _soccer_words):
                continue
        elif sport_slug != 'nfl' and league and sport_slug.lower() not in league.lower():
            continue
        # The homepage fallback shows whatever's generically prominent on the
        # site (usually MLB), not anything scoped to sport_slug at all —
        # confirmed live: niche sports with no better source (snooker,
        # handball) were all showing the SAME leaked MLB games, because the
        # league-mismatch check above only rejects an event when `league` is
        # actually present, and homepage cards frequently parse with no
        # league at all. On this fallback specifically, require a positive
        # league match instead of just "not a mismatch" — no match, no keep.
        elif on_homepage_fallback:
            if sport_slug == 'soccer':
                if not (league and any(w in league.lower() for w in _soccer_words)):
                    continue
            elif not (league and sport_slug.lower() in league.lower()):
                continue

        events.append({
            'id':       event_id,
            'slug':     slug,
            'path':     path,
            'title':    title or slug.replace('-', ' ').title(),
            'datetime': dt_str,
            'league':   league,
            'logo':     logo_url,
            'is_live':  is_live,
            'start_ts': int(start_ts_str),
        })

    return events


# ── streamseast.cx events (supplementary) ────────────────────────────────────

_SEAST_SLUGS = {
    # site's own nav section slugs (confirmed against streameasti.is directly —
    # irregular pluralization, not a simple "+s" rule)
    'nfl': 'nfls', 'nba': 'nba', 'mlb': 'mlbs', 'nhl': 'nhl',
    'ufc': 'mma', 'boxing': 'boxing', 'soccer': 'soccers',
    'cfb': 'cfb', 'cfl': 'cfls', 'ncaab': 'ncaab', 'wwe': 'wwes',
}

# streameasti.is (formerly streamseast.is, which is now dead — connect
# timeout) uses /section/team-vs-team links — no numeric event id anymore.
_RE_SEAST_CARD = re.compile(
    r'href=["\'](/(?:nfls|nba|mlbs|nhl|mma|boxing|soccers|cfb|cfls|ncaab|wwes)/'
    r'([^"\'#\s/]+))["\']',
    re.IGNORECASE
)

# Game page embeds up to N alternate sources as "source-btn" buttons, each
# with a base64-encoded URL in a data-s attribute, activated by an onclick
# JS function that swaps the player iframe's src. The iframe's OWN src
# attribute is left empty until a button is clicked, so plain
# <iframe src="..."> scraping (the old approach) finds nothing — must read
# data-s off the source-btn elements specifically (the same data-s value is
# also duplicated onto the initial iframe tag itself for the default
# source, which has no "source-btn" class and must NOT be matched here to
# avoid a blank-labeled duplicate).
_RE_SEAST_SOURCE_BTN = re.compile(
    r'source-btn[^>]*data-s=["\']([A-Za-z0-9+/=]+)["\'][^>]*>\s*([^<]{1,40})',
    re.IGNORECASE
)


@_cache.coalesced
def _seast_events(sport_slug, max_items=20):
    slug = _SEAST_SLUGS.get(sport_slug)
    if not slug:
        return []
    url = SEAST_BASE + '/%s' % slug
    if _site_dead('seast'):
        return []
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast schedule error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        _park_site('seast')
        return []

    events = []
    seen   = set()

    _iter_cards = _RE_SEAST_CARD.finditer(html)
    for m in _iter_cards:
        path, ev_slug = m.group(1), m.group(2)
        if ev_slug in seen:
            continue
        seen.add(ev_slug)
        # Title from slug: "red-sox-vs-angels" → "Red Sox Vs Angels"
        title = ev_slug.replace('-', ' ').title()
        # Try to get live/score indicator from context. Widened from 300 to
        # 600 chars — confirmed live the card's own data-ts attribute (see
        # below) sits ~393 chars after the href on a real card, past the
        # old 300-char window entirely; 600 stays well short of bleeding
        # into the NEXT card's own data-ts (~840+ chars away).
        ctx = html[max(0, html.find(path) - 50):html.find(path) + 600]
        is_live = bool(re.search(r'(?:live|LIVE|in\s+progress|Top\s+\d|Bottom\s+\d|End\s+\d)', ctx))
        # Confirmed live: every match-row card carries a real start time via
        # <span class="badge ..." data-ts="1785796800">--</span> right after
        # the title — the page's own JS re-renders that span's text/class
        # client-side based on elapsed time (upcoming countdown -> "LIVE" ->
        # hidden), but the raw data-ts is always present server-side
        # regardless of live state. Was never captured at all before —
        # every StreamsEast event showed no date/time as a result.
        ts_m = re.search(r'data-ts=["\'](\d+)["\']', ctx)
        start_ts = int(ts_m.group(1)) if ts_m else 0
        events.append({
            'id':       'seast_' + ev_slug,
            'slug':     ev_slug,
            'path':     'streamseast:' + path,
            'title':    title,
            'match_title': title,
            'datetime': '',
            'league':   slug.upper(),
            'logo':     '',
            'is_live':  is_live,
            'start_ts': start_ts,
        })
        if len(events) >= max_items:
            break

    xbmc.log('[Starfleet/Sports] StreamsEast %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _seast_event_streams(event_path):
    """Fetch streamseast.is event page, follow iframe chain to get embeds/m3u8."""
    path = event_path.replace('streamseast:', '')
    url  = SEAST_BASE + path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=SEAST_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen    = set()
    from urllib.parse import urlparse as _up_seast

    _M3U8_PAT = re.compile(
        r'["\']?(https?://[^\s"\'<>{},\)]+\.m3u8[^\s"\'<>{},\)]*)["\']?', re.I)

    def _collect_m3u8(page_html, label='StreamsEast HD'):
        for m3 in _M3U8_PAT.finditer(page_html):
            u = m3.group(1)
            if u not in seen:
                seen.add(u)
                streams.append({'label': label, 'url': u, 'quality': 'HD',
                                'language': '', 'source': 'StreamsEast'})

    # Scan main event page for m3u8
    _collect_m3u8(html)

    # Primary source: "source-btn" elements with data-s (base64-encoded embed
    # URL), swapped into the player iframe by an onclick JS handler — this is
    # the site's actual current mechanism (its iframe's own src is always
    # empty in the raw HTML). These decode to embed pages (e.g.
    # embed.st/embed/...), not raw m3u8 — handed to the stream list as-is;
    # ResolveURL resolves them at play time, same as every other embed-host
    # stream in this addon.
    import base64 as _b64_seast
    _seast_link_n = 0
    for sm in _RE_SEAST_SOURCE_BTN.finditer(html):
        b64 = sm.group(1)
        try:
            pad = '=' * (-len(b64) % 4)
            decoded = _b64_seast.b64decode(b64 + pad).decode('utf-8', 'ignore')
        except Exception:
            continue
        if not decoded.startswith('http') or decoded in seen:
            continue
        seen.add(decoded)
        _seast_link_n += 1
        streams.append({
            'label': 'Link %d' % _seast_link_n,
            'url': decoded,
            'quality': '',
            'language': '',
            'source': 'StreamsEast',
        })

    # Follow iframes up to 2 levels deep to extract m3u8.
    # Do NOT add embed page URLs (e.g. embedindia.st/embed/..., methstreams.gs/) as
    # streams — those pages are JS-rendered and unplayable in Kodi's video player.
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
    for iframe_url in iframes[:4]:
        if not iframe_url.startswith('http'):
            continue
        try:
            _pp = _up_seast(iframe_url)
            if not _pp.path or _pp.path in ('', '/'):
                continue  # skip bare homepage URLs
        except Exception:
            pass
        try:
            iframe_html = _sess().get(iframe_url, timeout=8,
                                      headers=dict(_HEADERS, Referer=url)).text
        except Exception:
            continue
        _collect_m3u8(iframe_html)
        for inner_m in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)["\']', iframe_html, re.I):
            inner_url = inner_m.group(1)
            if not inner_url.startswith('http'):
                continue
            try:
                _p2 = _up_seast(inner_url)
                if not _p2.path or _p2.path in ('', '/'):
                    continue
            except Exception:
                pass
            try:
                inner2_html = _sess().get(inner_url, timeout=8,
                                          headers=dict(_HEADERS, Referer=iframe_url)).text
            except Exception:
                continue
            _collect_m3u8(inner2_html)

    # Fallback: structured stream table (step 1 of _extract_stream_links) — only if
    # no m3u8 found above. This handles sites that serve clean direct-stream URLs in
    # an HTML table (not JS-rendered embed pages).
    if not streams:
        for s in _extract_stream_links(html, 'streamseast.is', 'StreamsEast'):
            u = s['url']
            if u not in seen:
                seen.add(u)
                streams.append(s)

    xbmc.log('[Starfleet/Sports] StreamsEast streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# ── Official league schedule APIs ─────────────────────────────────────────────

_ESPN_LOGO = 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/{league}/500/{abbrev}.png'


def _espn_logo(league, abbrev):
    """Return ESPN CDN PNG logo URL — Kodi can't render SVG."""
    if not abbrev:
        return ''
    return _ESPN_LOGO.format(league=league, abbrev=abbrev.lower().replace(' ', ''))


def _pwhl_events(max_items):
    """PWHL schedule from the league's own stats feed (the games that are on now or still to come, soonest first)."""
    from starfleetscrapers.sports import live_scores as _ls
    events = []
    for g in sorted(_ls.pwhl_games(days_ahead=21), key=lambda x: x['start']):
        if g['state'] == 'post':
            continue
        match_title = '%s vs %s' % (g['away'], g['home'])
        events.append({
            'id': 'pwhl_%s' % g['id'], 'slug': 'pwhl_%s' % g['id'], 'path': '',
            'title': match_title, 'match_title': match_title, 'datetime': time.strftime('%b %d %H:%M UTC', time.gmtime(g['start'])),
            'league': 'PWHL', 'logo': '', 'home_badge': '', 'away_badge': '',
            'is_live': g['state'] == 'in', 'start_ts': g['start'], 'venue': '', 'home_team': g['home'],
        })
        if len(events) >= max_items:
            break
    xbmc.log('[Starfleet/Sports] PWHL official: %d events' % len(events), xbmc.LOGINFO)
    return events


@_cache.coalesced
def _nhl_official_events(max_items):
    """NHL schedule from api-web.nhle.com — returns next ~7 days."""
    today = datetime.date.today().strftime('%Y-%m-%d')
    try:
        data = _get_json('https://api-web.nhle.com/v1/schedule/%s' % today, timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] NHL official: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for week_day in (data.get('gameWeek') or []):
        for gm in (week_day.get('games') or []):
            state   = gm.get('gameState', 'FUT')
            is_live = state in ('LIVE', 'CRIT')
            if state in ('FINAL', 'OFF'):
                continue
            home = gm.get('homeTeam', {})
            away = gm.get('awayTeam', {})
            home_name = ('%s %s' % (home.get('placeName', {}).get('default', ''),
                                    home.get('commonName', {}).get('default', ''))).strip()
            away_name = ('%s %s' % (away.get('placeName', {}).get('default', ''),
                                    away.get('commonName', {}).get('default', ''))).strip()
            match_title = '%s vs %s' % (away_name, home_name)
            title = match_title
            if is_live:
                title = '%s %s - %s %s' % (away_name, away.get('score', 0),
                                            home.get('score', 0), home_name)
            ts, dt_str = _ts_to_dt(gm.get('startTimeUTC', ''))
            home_logo = _espn_logo('nhl', home.get('abbrev', ''))
            away_logo = _espn_logo('nhl', away.get('abbrev', ''))
            events.append({
                'id': str(gm.get('id', '')), 'slug': str(gm.get('id', '')), 'path': '',
                'title': title, 'match_title': match_title, 'datetime': dt_str,
                'league': 'NHL', 'logo': away_logo or home_logo,
                'home_badge': home_logo, 'away_badge': away_logo,
                'is_live': is_live, 'start_ts': ts,
                'venue': gm.get('venue', {}).get('default', ''),
                'home_team': home_name,
            })
            if len(events) >= max_items:
                break
    xbmc.log('[Starfleet/Sports] NHL official: %d events' % len(events), xbmc.LOGINFO)
    return events


@_cache.coalesced
def _nba_official_events(max_items):
    """NBA today's scoreboard from cdn.nba.com."""
    try:
        data = _get_json(
            'https://cdn.nba.com/static/json/liveData/scoreboard/todaysScoreboard_00.json',
            timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] NBA official: %s - using ESPN scoreboard' % e, xbmc.LOGWARNING)
        try:
            return _espn_events('nba', max_items)
        except Exception:
            return []
    events = []
    for gm in (data.get('scoreboard', {}).get('games') or []):
        status  = gm.get('gameStatus', 1)
        is_live = (status == 2)
        if status == 3:
            continue
        home = gm.get('homeTeam', {})
        away = gm.get('awayTeam', {})
        home_name = ('%s %s' % (home.get('teamCity', ''), home.get('teamName', ''))).strip()
        away_name = ('%s %s' % (away.get('teamCity', ''), away.get('teamName', ''))).strip()
        match_title = '%s vs %s' % (away_name, home_name)
        title = match_title
        if is_live:
            title = '%s %s - %s %s' % (away_name, away.get('score', 0),
                                        home.get('score', 0), home_name)
        ts, dt_str = _ts_to_dt(gm.get('gameDateTimeUTC', ''))
        home_logo = _espn_logo('nba', home.get('teamTricode', ''))
        away_logo = _espn_logo('nba', away.get('teamTricode', ''))
        events.append({
            'id': gm.get('gameId', ''), 'slug': gm.get('gameId', ''), 'path': '',
            'title': title, 'match_title': match_title, 'datetime': dt_str,
            'league': 'NBA', 'logo': away_logo or home_logo,
            'home_badge': home_logo, 'away_badge': away_logo,
            'is_live': is_live, 'start_ts': ts, 'venue': '',
            'home_team': home_name,
        })
        if len(events) >= max_items:
            break
    xbmc.log('[Starfleet/Sports] NBA official: %d events' % len(events), xbmc.LOGINFO)
    return events


@_cache.coalesced
def _mlb_official_events(max_items):
    """MLB schedule from statsapi.mlb.com — next 7 days."""
    today    = datetime.date.today()
    end_date = today + datetime.timedelta(days=6)
    url = ('https://statsapi.mlb.com/api/v1/schedule?sportId=1'
           '&startDate=%s&endDate=%s&hydrate=team,linescore'
           % (today.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')))
    try:
        data = _get_json(url, timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] MLB official: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for day in (data.get('dates') or []):
        for gm in (day.get('games') or []):
            abstract = gm.get('status', {}).get('abstractGameState', 'Preview')
            if abstract == 'Final':
                continue
            is_live   = (abstract == 'Live')
            home      = gm.get('teams', {}).get('home', {})
            away      = gm.get('teams', {}).get('away', {})
            home_name = home.get('team', {}).get('name', '')
            away_name = away.get('team', {}).get('name', '')
            match_title = '%s vs %s' % (away_name, home_name)
            title = match_title
            if is_live:
                title = '%s %s - %s %s' % (away_name, away.get('score', 0),
                                            home.get('score', 0), home_name)
            ts, dt_str = _ts_to_dt(gm.get('gameDate', ''))
            home_abbrev = home.get('team', {}).get('abbreviation', '')
            away_abbrev = away.get('team', {}).get('abbreviation', '')
            home_logo = _espn_logo('mlb', away_abbrev)
            away_logo = _espn_logo('mlb', home_abbrev)
            # Always use match_title (no score) as the event title so stream-site
            # title matching works regardless of live score updates.
            # Live score goes into plot so it still appears in the UI.
            plot = ('🔴 %s - %s (LIVE)' % (away.get('score', 0), home.get('score', 0))
                    if is_live else dt_str)
            events.append({
                'id': str(gm.get('gamePk', '')), 'slug': str(gm.get('gamePk', '')), 'path': '',
                'title': match_title, 'match_title': match_title, 'plot': plot, 'datetime': dt_str,
                'league': 'MLB', 'logo': away_logo or home_logo,
                'home_badge': home_logo, 'away_badge': away_logo,
                'is_live': is_live, 'start_ts': ts,
                'venue': gm.get('venue', {}).get('name', ''),
                'home_team': home_name,
            })
            if len(events) >= max_items:
                break
    xbmc.log('[Starfleet/Sports] MLB official: %d events' % len(events), xbmc.LOGINFO)
    return events


def get_todays_sport_events(sport_slug, tsdb_sport='', max_items=20):
    """Return today's events for a sport, formatted for home carousel items."""
    import time as _time
    events = get_sport_events(sport_slug, tsdb_sport=tsdb_sport, max_items=max_items)
    now    = _time.time()
    cutoff = now + 86400  # next 24 hours
    items  = []
    for ev in events:
        ts = ev.get('start_ts', 0)
        if not ev.get('is_live') and ts and ts > cutoff:
            continue  # skip games more than 24h away
        if sport_slug in ('ufc', 'boxing', 'f1', 'motogp') and not ev.get('is_live') and ts and ts < now - 10 * 3600:
            continue  # a fight night or race that started more than 10 hours ago is over: it leaves the widgets
        logo  = ev.get('home_badge') or ev.get('logo') or _CATEGORY_ICON.get(sport_slug, '')
        fanart = ev.get('away_badge') or ev.get('logo') or logo
        # For live games, title includes score ("Team A 2 - 1 Team B") which breaks
        # scraper title-matching. Use match_title ("Team A vs Team B") instead.
        display_title = ev.get('match_title') or ev.get('title', '')
        items.append({
            'id':          ev.get('id', ''),
            'title':       display_title,
            'thumb':       logo,
            'fanart':      fanart,
            'plot':        ev.get('league', '') + (' — 🔴 LIVE' if ev.get('is_live') else ''),
            'source':      'sports',
            'sport_slug':  sport_slug,
            'event_id':    ev.get('id', ''),
            'event_path':  ev.get('path', ''),
            'media_type':  'event',
        })
        if len(items) >= max_items:
            break
    return items


# ── Public event API ──────────────────────────────────────────────────────────

def _merge_events(primary, supplementary):
    """Merge supplementary events into primary, deduplicating by title similarity.
    If a duplicate is found but the primary event has no stream path, copy the
    supplementary event's path so streams are not lost (e.g. official MLB schedule
    events have path='' but streamseast/methstreams events carry the stream path).
    """
    merged = list(primary)
    primary_titles = [e['title'] for e in primary]

    for ev in supplementary:
        duplicate = False
        for i, pt in enumerate(primary_titles):
            if _titles_match(ev['title'], pt, threshold=2):
                duplicate = True
                # If primary has no stream path but supplementary does, copy it over
                if not merged[i].get('path') and ev.get('path'):
                    merged[i] = dict(merged[i])
                    merged[i]['path'] = ev['path']
                break
        if not duplicate:
            merged.append(ev)
            primary_titles.append(ev['title'])

    return merged


def with_live_scores(sport_slug, events):
    """`events` with the current score / clock / state attached (see live_scores). Never raises."""
    try:
        from starfleetscrapers.sports import live_scores as _ls
        return _ls.attach(sport_slug, events)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] live scores: %s' % e, xbmc.LOGWARNING)
        return events


_SWR_MAX_AGE = 45 * 60          # an old list is shown at once for this long while a new one is fetched behind it
_swr_running = set()
_swr_lock = threading.Lock()


def get_sport_events(sport_slug='nfl', tsdb_sport='', max_items=20):
    """The games of one sport. The list is cached for 10 minutes; after that, for 45 more minutes the last list is returned at once and
    a fresh one is fetched in the background, so opening a sport never waits on the providers except the first time."""
    ck = 'sport_ev4_%s' % sport_slug
    fresh = _cache.get(ck)
    if fresh is not None:
        return fresh
    old = _cache.get(ck + '_last')
    if isinstance(old, dict) and old.get('ev') and time.time() - old.get('t', 0) < _SWR_MAX_AGE:
        with _swr_lock:
            start = sport_slug not in _swr_running
            if start:
                _swr_running.add(sport_slug)
        if start:
            def refresh():
                try:
                    _sport_events_stored(sport_slug, tsdb_sport, max_items)
                except Exception as e:
                    xbmc.log('[Starfleet/Sports] background refresh of %s: %s' % (sport_slug, e), xbmc.LOGINFO)
                finally:
                    with _swr_lock:
                        _swr_running.discard(sport_slug)
            threading.Thread(target=refresh, daemon=True).start()
        return old['ev']
    return _sport_events_stored(sport_slug, tsdb_sport, max_items)


def _sport_events_stored(sport_slug, tsdb_sport, max_items):
    events = _get_sport_events_built(sport_slug, tsdb_sport, max_items)
    if events:
        _cache.set('sport_ev4_%s_last' % sport_slug, {'t': time.time(), 'ev': events}, 3 * 3600)
    return events


@_cache.coalesced
def _get_sport_events_built(sport_slug='nfl', tsdb_sport='', max_items=20):
    # tsdb_sport is the TheSportsDB sport name (e.g. 'Soccer', 'Ice Hockey')
    # Fall back to our static mapping if not provided
    if not tsdb_sport:
        tsdb_sport = _SLUG_TO_TSDB_SPORT.get(sport_slug, '')

    ck = 'sport_ev4_%s' % sport_slug   # v4: TSDB calendar as primary source
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    # No ESPN/TSDB/official-API path exists for this catch-all — it's built
    # entirely from bosscast/crickfree JSON leftovers not claimed by a named
    # sport, plus hoofoot.ru's own uncategorized Sport labels (Watersports,
    # Softball, Horse Racing, Other — none of which map to an existing slug).
    if sport_slug == 'other_international':
        from starfleetscrapers.live import json_data as _jd
        events = _jd.get_other_international_events()
        try:
            hoofoot_extra = _hoofoot_other_events()
            if hoofoot_extra:
                events = _merge_events(events, hoofoot_extra)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] hoofoot other_international error: %s' % e, xbmc.LOGWARNING)
        try:
            lsite_extra = _livesites_events('other_international')
            if lsite_extra:
                events = _merge_events(events, lsite_extra)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] livesites other_international error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, events, 10 * 60)
        return events

    events = []

    # Supplementary sources (SeaST, Methstreams, TVNow, live-site providers, HooFoot, OnHockey) do
    # not depend on phase 1's results, so they are started NOW and run beside it; they used to
    # start only after phase 1 and the ESPN/TSDB fallbacks, adding their full wait on top.
    supplementary_futures = {}
    ex = ThreadPoolExecutor(max_workers=8)
    _sup_t0 = time.time()
    supplementary_futures['seast'] = _sx_submit('seast', ex.submit, _seast_events, sport_slug, max_items)
    if sport_slug in _METH_LEAGUE_PATHS:
        supplementary_futures['meth'] = _sx_submit('meth', ex.submit, _meth_events, sport_slug, max_items)
    # _tstek_events (totalsportek24.is) submission removed 2026-08-03 —
    # that domain confirmed unreliable (per its own guard comment
    # below), superseded by totalsportek.json (json_data.py), scraped
    # standalone from totalsportek.press instead. _tstek_events()'s own
    # body left in place as unreferenced dead code, same treatment as
    # this file's other removed live-scrape sources.
    # onhockey covers ALL hockey leagues — run for any hockey sport slug
    _HOCKEY_SLUGS = {'nhl', 'ahl', 'khl', 'shl', 'ohl', 'whl', 'qmjhl',
                     'echl', 'ncaa-hockey', 'pwhl', 'iihf', 'hockey'}
    if sport_slug in _HOCKEY_SLUGS:
        def _onhockey_for_slug(slug=sport_slug):
            evs = _onhockey_events()
            # UPDATE 2026-09-05 — 'nhl' used to filter down to only
            # events _onhockey_league() detected as literally "NHL",
            # per direct request broadened to match 'hockey' below and
            # show every league onhockey.tv has. Confirmed live this
            # was hiding real, currently-live games (Liiga, Champions
            # League, Club Friendly, EHL Preseason, etc. all confirmed
            # live 2026-09-05, real teams/times/stream links) that
            # exist on the exact same schedule scrape this file already
            # runs for the NHL slug — outside NHL's own season, the
            # NHL-only filter left NOTHING but the NHL Network 24/7
            # channel entry, even though the underlying scrape and
            # per-event stream resolution both work fine for every
            # other league already (same _onhockey_streams() call
            # regardless of league).
            if slug in ('hockey', 'nhl'):
                return evs   # all leagues
            # filter to events whose detected league matches the slug
            slug_upper = slug.upper()
            return [e for e in evs if e.get('league', 'NHL').upper() == slug_upper]
        supplementary_futures['onhockey'] = _sx_submit('onhockey', ex.submit, _onhockey_for_slug)

    if sport_slug == 'hockey':
        # the NOJHL games (the league's own feed) join the Hockey list, so My Teams can follow its teams
        def _nojhl_events():
            from starfleetscrapers.sports import nojhl as _nj
            return _nj.events()
        supplementary_futures['nojhl'] = ex.submit(_nojhl_events)

    supplementary_futures['tvnow'] = _sx_submit('tvnow', ex.submit, _tvnow_events_for_sport, sport_slug)
    try:
        from starfleetscrapers.live import json_data as _jd0
        ex.submit(_jd0._fetch_all)        # warm the scraper-JSON cache beside phase 1, so the merge at the end finds it ready
    except Exception:
        pass
    supplementary_futures['livesites'] = _sx_submit('livesites', ex.submit, _livesites_events, sport_slug)

    if sport_slug in _HOOFOOT_SPORT_MAP.values():
        supplementary_futures['hoofoot'] = _sx_submit('hoofoot', ex.submit, _hoofoot_events, sport_slug, max_items)


    # ── Phase 1: official APIs + TSDB calendar all in parallel ───────────────
    _today = datetime.date.today()
    # big-4 already have an official feed for today, so the shared TSDB key only needs the next few days
    _ndays = 4 if sport_slug in ('nhl', 'nba', 'mlb', 'nfl') else 7
    _dates = [(_today + datetime.timedelta(days=d)).strftime('%Y-%m-%d') for d in range(_ndays)]
    _ph1_ex  = ThreadPoolExecutor(max_workers=12)
    _ph1_futs = {}

    # Official league APIs (primary source for big-4)
    if sport_slug == 'nhl':
        _ph1_futs['official'] = _ph1_ex.submit(_nhl_official_events, max_items)
    elif sport_slug == 'nba':
        _ph1_futs['official'] = _ph1_ex.submit(_nba_official_events, max_items)
    elif sport_slug == 'mlb':
        _ph1_futs['official'] = _ph1_ex.submit(_mlb_official_events, max_items)
    elif sport_slug == 'nfl':
        # NFL.com feeds from ESPN; ESPN scoreboard is the de-facto official source
        _ph1_futs['official'] = _ph1_ex.submit(_espn_events, 'nfl', max_items)
    elif sport_slug == 'pwhl':
        _ph1_futs['official'] = _ph1_ex.submit(_pwhl_events, max_items)

    # TSDB calendar covers all other sports + supplements the big-4
    for _d in _dates:
        _ph1_futs['tsdb_%s' % _d] = _ph1_ex.submit(_tsdb_calendar_events, tsdb_sport, _d, max_items)

    _ph1_ex.shutdown(wait=False)

    official_events = []
    _ph1_deadline = time.time() + 10   # shared: one slow calendar must not add its own 10s to the next
    for _key, _f in _ph1_futs.items():
        try:
            _evs = _f.result(timeout=max(0.05, _ph1_deadline - time.time()))
            if not _evs:
                continue
            if _key == 'official':
                official_events = _evs
            else:
                events = _merge_events(events, _evs)
        except Exception:
            pass

    # NFL, CFB, and CFL all share TheSportsDB's single "American Football"
    # sport calendar (there's no separate TSDB sport per league) — confirmed
    # live that this puts CFL games (and even European League of Football
    # games) directly into the NFL listing with no way to tell them apart,
    # since the TSDB-calendar merge above has no per-league awareness at
    # all. Each event does carry its real league name in strLeague though
    # (surfaced here as 'league'), so filter the TSDB-sourced events down to
    # ones that actually match the requested league before they ever reach
    # the official-events merge below. Official-API events (ESPN NFL
    # scoreboard etc.) are already pure for their sport_slug and skip this.
    if sport_slug in _AMFOOTBALL_LEAGUE_KEYWORDS:
        _kws = _AMFOOTBALL_LEAGUE_KEYWORDS[sport_slug]
        events = [
            e for e in events
            if any(kw in (e.get('league', '') or '').lower() for kw in _kws)
        ]

    # Official API result takes precedence: merge TSDB into official (not the other way)
    if official_events:
        events = _merge_events(official_events, events)
    xbmc.log('[Starfleet/Sports] %s: official=%d tsdb=%d' % (
        sport_slug, len(official_events), len(events) - len(official_events)), xbmc.LOGINFO)

    # ── ESPN: adds live scores on top for non-big-4 sports ───────────────────
    espn_found = False
    if sport_slug in _ESPN_SPORTS and sport_slug not in ('nhl', 'nba', 'mlb', 'nfl'):
        espn_evs = _espn_events(sport_slug, max_items)
        espn_found = len(espn_evs) > 0
        if espn_evs:
            events = _merge_events(events, espn_evs)
    
    # For soccer: also poll extra leagues (PL, MLS, UCL, UEL) in parallel
    if sport_slug == 'soccer':
        def _fetch_extra_league(xl):
            try:
                _xdata = _get_json(_ESPN_API.format(sport='soccer', league=xl))
                _xevs  = []
                for ev in _xdata.get('events', []):
                    _st   = ev.get('status', {}).get('type', {}).get('state', 'pre')
                    _comp = (ev.get('competitions') or [{}])[0]
                    _cmps = _comp.get('competitors', [])
                    if len(_cmps) >= 2:
                        _teams = [c.get('team', {}).get('displayName', '') for c in _cmps]
                        _title = ' vs '.join(_teams)
                    else:
                        _title = ev.get('name', ev.get('shortName', ''))
                    _logo = _cmps[0].get('team', {}).get('logo', '') if _cmps else ''
                    _ts, _dt = _ts_to_dt(ev.get('date', ''))
                    _xevs.append({'id': ev.get('id', ''), 'slug': ev.get('id', ''),
                                  'path': '', 'title': _title, 'datetime': _dt,
                                  'league': xl.upper(), 'logo': _logo,
                                  'is_live': (_st == 'in'), 'start_ts': _ts})
                return _xevs
            except Exception:
                return []
        _xl_ex   = ThreadPoolExecutor(max_workers=len(_ESPN_SOCCER_EXTRA))
        _xl_futs = {xl: _xl_ex.submit(_fetch_extra_league, xl) for xl in _ESPN_SOCCER_EXTRA}
        _xl_ex.shutdown(wait=False)
        for xl, fut in _xl_futs.items():
            try:
                _xevs = fut.result(timeout=5)
                if _xevs:
                    events = _merge_events(events, _xevs)
            except Exception:
                pass

    # TSDB league fallback for UFC/Boxing/WWE (next-event API, not calendar)
    if not events and sport_slug in _TSDB_LEAGUES:
        events = _tsdb_events(sport_slug)
    
    # ISE fallback only when everything above returned nothing
    if not events:
        events = _ise_events(sport_slug)
    
    try:
        # one shared 5s window for all of them (a fresh 5s per future let a slow one add up to
        # 5s each, one after the other)
        _sup_deadline = _sup_t0 + 4   # measured from when they were started, not from now
        for name, fut in supplementary_futures.items():
            try:
                extra = fut.result(timeout=max(0.05, _sup_deadline - time.time()))
                if extra:
                    # the NOJHL games are all different and share words (Lake, Soo, Rock...): the title-similarity merge would fold them into each other
                    events = events + list(extra) if name == 'nojhl' else _merge_events(events, extra)
                    xbmc.log('[Starfleet/Sports] %s merged %d events from %s' % (sport_slug, len(extra), name), xbmc.LOGINFO)
            except Exception as e:
                msg = str(e) or type(e).__name__
                xbmc.log('[Starfleet/Sports] supplementary events error (%s/%s): %s' % (sport_slug, name, msg), xbmc.LOGWARNING)
    finally:
        ex.shutdown(wait=False)  # don't block on any still-running futures

    # Fold in the pre-resolved scraper JSON — unions playable links from every
    # matching source into each event instead of leaving them as separate listings.
    from starfleetscrapers.live import json_data as _jd
    events = _jd.merge_json_events(events, sport_slug)

    if sport_slug in ('nhl', 'nba', 'mlb'):
        # These lists are that league only (the TSDB calendar and the all-league
        # scrapes mix in AHL/KHL/Liiga, EuroLeague, KBO/NPB...); the Hockey hub is
        # where every other hockey league lives.
        events = [e for e in events
                  if sport_slug in (e.get('league', '') or '').lower()
                  or sport_slug in (e.get('title', '') or '').lower()]

    events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def get_all_events():
    ck = 'sports_events_all'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(ISE_BASE + '/')
        events = []
        seen   = set()

        for m in _RE_ISE_CARD.finditer(html):
            path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[m.end():m.end() + 900]
            title, dt_str, league, logo_url, is_live = _parse_ise_block(block)
            events.append({
                'id':       event_id,
                'slug':     slug,
                'path':     path,
                'title':    title or slug.replace('-', ' ').title(),
                'datetime': dt_str,
                'league':   league,
                'logo':     logo_url,
                'is_live':  is_live,
                'start_ts': int(start_ts_str),
            })

        events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
        _cache.set(ck, events, 10 * 60)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] all events error: %s' % e, xbmc.LOGERROR)
        return []


# ── Stream links ──────────────────────────────────────────────────────────────

# Known streaming embed/player domains — used as fallback link detection
_STREAM_EMBED_DOMAINS = (
    '720pstream', 'livetv', 'streamtape', 'cloudy.pk', 'stopstream',
    'nbaat', 'vecloud', 'embedstream', 'nlstreams', 'theflixer',
    'sportshdlive', 'daddylive', 'sportsurge', 'buffstream', 'atdhe',
    'firstrowsports', 'livesport', 'sportsbay', 'streameast',
    'crackstreams', 'volokit', 'acestream',
)

# istreameast.cx stream table row — flexible: 3 or more TDs, last with <a href>
_RE_ISE_STREAM_ROW = re.compile(
    r'<tr[^>]*>\s*'
    r'<td[^>]*>(.*?)</td>\s*'          # col 1: streamer/name
    r'<td[^>]*>(.*?)</td>\s*'          # col 2: channel/quality
    r'(?:<td[^>]*>.*?</td>\s*)*'       # optional extra cols
    r'<td[^>]*><a[^>]+href="([^"#][^"]*)"[^>]*>',
    re.IGNORECASE | re.DOTALL
)

# Fallback: any external <a> with href on a stream page
_RE_EXT_LINK = re.compile(
    r'<a[^>]+href="(https?://([^/"]+)[^"]*)"[^>]*>([^<]{1,80})</a>',
    re.IGNORECASE
)
# Fallback: iframes with external src
_RE_IFRAME_SRC = re.compile(r'<iframe[^>]+src="(https?://[^"]+)"', re.IGNORECASE)


def _extract_stream_links(html, base_domain, source_label):
    """
    Try structured table parse first, then fall back to link/iframe extraction.
    Returns list of stream dicts.
    """
    streams = []

    # 1. Try structured table rows
    for m in _RE_ISE_STREAM_ROW.finditer(html):
        col1 = _clean(m.group(1))
        col2 = _clean(m.group(2))
        url  = m.group(3).strip()
        if not url or url == '#':
            continue
        label = ('%s %s' % (col1, col2)).strip() or source_label
        streams.append({
            'label':    label,
            'url':      url,
            'quality':  col2,
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 2. Fallback: iframes
    for m in _RE_IFRAME_SRC.finditer(html):
        src = m.group(1).strip()
        if base_domain and base_domain in src:
            continue
        try:
            from urllib.parse import urlparse as _up2
            _pp = _up2(src)
            if not _pp.path or _pp.path in ('', '/'):
                continue  # skip bare homepage URLs (e.g. methstreams.gs/)
        except Exception:
            pass
        streams.append({
            'label':    source_label + ' Embedded',
            'url':      src,
            'quality':  '',
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 3. Fallback: known stream embed domain links
    for m in _RE_EXT_LINK.finditer(html):
        href   = m.group(1).strip()
        domain = m.group(2).lower()
        text   = _clean(m.group(3))
        if base_domain and base_domain in domain:
            continue
        if any(d in domain for d in _STREAM_EMBED_DOMAINS):
            streams.append({
                'label':    text or (source_label + ' Stream'),
                'url':      href,
                'quality':  '',
                'language': '',
                'source':   source_label,
            })

    return streams


def _ise_event_streams(event_path, event_id=''):
    if not event_path.startswith('/links/'):
        out = []
        for p in _ise_players(event_path)[:8]:
            if WEB_SNIFF:
                out.append({'label': 'StreamEast %s (web)' % p['name'], 'url': p['url'], 'quality': 'HD' if p['hd'] else '', 'language': '', 'source': 'StreamEast', 'web': True})
        out = _alive_web_pages(out, 4)
        for st in out:
            WEB_URLS.add(st['url'])
        return out
    url = ISE_BASE + event_path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=ISE_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE stream page error (%s): %s' % (event_path, e), xbmc.LOGERROR)
        return []

    streams = _extract_stream_links(html, 'istreameast.cx', 'StreamEast')
    xbmc.log('[Starfleet/Sports] ISE streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# Roxiestreams
_ROXIE_SLUGS = {
    'nfl':    'nfl',
    'nba':    'nba',
    'mlb':    'mlb',
    'nhl':    'nhl',
    'ufc':    'fighting',
    'boxing': 'fighting',
    'soccer': 'soccer',
    'wwe':    'wwe',
    'cfb':    'ncaaf',
    'ncaab':  'ncaab',
    'f1':     'f1',
    'cfl':    'cfl',
}

# Match both absolute (https://roxiestreams.info/...) and relative (/...) event links
_RE_ROXIE_EVENT_LINK = re.compile(
    r'<a[^>]+href=["\'](?:https?://roxiestreams\.info)?(/[^"\'#\s]{3,80})["\'][^>]*>\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

_ROXIE_SKIP = frozenset((
    'home', 'menu', 'schedule', 'login', 'register', 'about', 'contact',
    'discord', 'multiview', 'stream request (discord)',
))
_ROXIE_NAV = frozenset((
    'soccer', 'nba', 'nfl', 'nhl', 'fighting', 'motorsports', 'wwe', 'f1',
    'cfl', 'ncaaf', 'ncaab', 'soccer (wc 2026)', 'roxiestreams', 'multiview (new)',
))


def _roxie_streams(sport_slug, event_title=''):
    slug = _ROXIE_SLUGS.get(sport_slug)
    if not slug:
        return []
    listing_url = ROXIE_BASE + '/' + slug
    try:
        html = _get(listing_url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Roxie (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    title_words = [w.lower() for w in re.split(r'\W+', event_title) if len(w) > 3] if event_title else []

    # Find the event page URL that best matches the title
    event_url = None
    best_score = 0
    for m in _RE_ROXIE_EVENT_LINK.finditer(html):
        link_path = m.group(1)
        row_text  = _clean(m.group(2))
        if not row_text or len(row_text) < 4:
            continue
        if row_text.lower() in _ROXIE_SKIP or row_text.lower() in _ROXIE_NAV:
            continue
        if title_words:
            row_lower = row_text.lower()
            score = sum(1 for w in title_words if w in row_lower)
            if score > best_score:
                best_score = score
                event_url = ROXIE_BASE + link_path
        elif event_url is None:
            event_url = ROXIE_BASE + link_path

    if not event_url or (title_words and best_score == 0):
        xbmc.log('[Starfleet/Sports] Roxie %s "%s": no matching event' % (sport_slug, event_title), xbmc.LOGINFO)
        return []

    # Fetch the event page and extract direct m3u8 URLs
    try:
        ev_html = _sess().get(event_url, timeout=10,
                              headers=dict(_HEADERS, Referer=listing_url)).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Roxie event page error (%s): %s' % (event_url, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen = set()
    for m3u8_m in re.finditer(
            r'["\']?(https?://[^\s"\'<>{},\)]+\.m3u8[^\s"\'<>{},\)]*)["\']?',
            ev_html, re.I):
        u = m3u8_m.group(1)
        if u not in seen:
            seen.add(u)
            streams.append({'label': 'Roxie HD', 'url': u, 'quality': 'HD',
                            'language': '', 'source': 'RoxieStreams'})

    # Fallback: known embed domains via _extract_stream_links
    extra = _extract_stream_links(ev_html, 'roxiestreams.info', 'RoxieStreams')
    for s in extra:
        if s['url'] not in seen:
            seen.add(s['url'])
            streams.append(s)

    xbmc.log('[Starfleet/Sports] Roxie %s "%s": %d streams' % (sport_slug, event_title, len(streams)), xbmc.LOGINFO)
    return streams


# ── TotalSportek24 (multi-sport) ─────────────────────────────────────────────

# Maps our internal slugs to TotalSportek24 URL path segments
_TSTEK_SLUGS = {
    'soccer':  'soccer-streams',
    'nfl':     'nfl-streams',
    'nba':     'nba-streams',
    'nhl':     'nhl-streams',
    'mlb':     'mlb-stream',
    'ufc':     'ufc-streams',
    'boxing':  'boxing-streams',
    'f1':      'f1-streams',
    'cfb':     'college-football-streams',
    'ncaab':   'college-basketball-streams',
    'wwe':     'wwe-streams',
    'tennis':  'tennis-streams',
    'rugby':   'rugby-streams',
    'cricket': 'cricket-streams',
    'motogp':  'motogp-streams',
}

# Event card: <a href="/game/..."><div>...<span>TIME UTC</span>...<div class="row my-auto">TITLE</div>...</div></a>
_RE_TSTEK_GAME_CARD = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/game/[^"#\s]{4,120})"[^>]*>'
    r'.*?<span>\s*(\d+:\d+\s*(?:am|pm)[^<]*?)\s*</span>'
    r'.*?<div[^>]+class="row[^"]*my-auto[^"]*"[^>]*>\s*([^<]{3,120}?)\s*</div>',
    re.IGNORECASE | re.DOTALL
)

# Fallback: plain text anchor (older page layout)
_RE_TSTEK_EVENT = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^"#\s]{4,120})"[^>]*>'
    r'\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

# Nav links used to discover which sport sections actually exist on the site
_RE_TSTEK_NAV = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^/"]+/?)"[^>]*>'
    r'\s*([^<]{2,40}?)\s*</a>',
    re.IGNORECASE
)

# Cache the scraped nav/sport-section map across calls
_tstek_sport_urls = {}   # slug → full URL to that sport's schedule page


def _tstek_discover():
    """
    Fetch TotalSportek24 homepage and build a map of sport-slug → URL.
    Caches the result in _tstek_sport_urls for the session.
    """
    global _tstek_sport_urls
    if _tstek_sport_urls:
        return _tstek_sport_urls

    ck = 'tstek_sport_urls'
    cached = _cache.get(ck)
    if cached:
        _tstek_sport_urls = cached
        return _tstek_sport_urls

    try:
        html = _sess().get(TSTEK_BASE + '/', timeout=5,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 homepage error: %s' % e, xbmc.LOGWARNING)
        return {}

    # Build reverse map: url-path-segment → our slug
    reverse = {v: k for k, v in _TSTEK_SLUGS.items()}
    result  = {}

    for m in _RE_TSTEK_NAV.finditer(html):
        href    = m.group(1).rstrip('/')
        segment = href.rstrip('/').rsplit('/', 1)[-1].lower()
        if segment in reverse:
            our_slug = reverse[segment]
            result[our_slug] = href
            xbmc.log('[Starfleet/Sports] TotalSportek24 found sport: %s → %s' % (our_slug, href), xbmc.LOGINFO)

    # Fallback: construct URLs from the known slug map for any missing sports
    for our_slug, tstek_slug in _TSTEK_SLUGS.items():
        if our_slug not in result:
            result[our_slug] = '%s/%s/' % (TSTEK_BASE, tstek_slug)

    _tstek_sport_urls = result
    _cache.set(ck, result, 60 * 60)  # cache 1 hour
    return result


def _tstek_events(sport_slug, max_items=20):
    """Scrape TotalSportek24 for events matching the given sport slug."""
    import calendar as _cal

    ck = 'sports_tstek_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    sport_url = '%s/%s' % (TSTEK_BASE, _TSTEK_SLUGS.get(sport_slug, sport_slug + '-streams'))
    try:
        html = _sess().get(sport_url, timeout=5,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 sport page error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    # Confirmed live: some of this site's per-sport URLs (cricket, wwe, rugby,
    # ncaab at the time of checking) now silently serve the site's generic
    # "all live games today" page instead of anything actually scoped to that
    # sport — every OTHER sport checked returned 6-27 /game/ links, these
    # returned 78-309, all clearly mismatched (F1/UFC/boxing titles showing
    # up labeled with whatever sport_slug was requested). max_items caps the
    # events list this function returns to ~20 either way, so a plausible vs.
    # polluted page can't be told apart from the final count — check the RAW
    # link count on the page before that cap ever applies.
    _raw_game_link_count = html.count('totalsportek24.is/game/')
    if _raw_game_link_count > 50:
        xbmc.log('[Starfleet/Sports] TotalSportek24 (%s): page has %d game links — '
                  'looks like the generic all-sports page, not scoped content, skipping' %
                  (sport_slug, _raw_game_link_count), xbmc.LOGWARNING)
        _cache.set(ck, [], 30 * 60)
        return []

    events = []
    seen   = set()
    now_utc = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
    
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')
    all_as = soup.find_all('a')
    for a in all_as:
        if a.has_attr('href') and a['href'].find('totalsportek24.is/game/') != -1:
            href = a['href']
            span = a.find('span')
            if span is not None:
                raw_time = span.text.strip()
                rows = a.find_all('div', class_='row')
                if len(rows) == 0:
                    continue
                title = ''
                for row in rows:
                    if len(title) == 0:
                        title = row.text.strip()
                    else:
                        title = title + ' - ' + row.text.strip()
                title = _clean(title)
                
                if not title or href in seen:
                    continue
                seen.add(href)

                # Parse UTC time into a timestamp (assume today or tomorrow)
                start_ts = 0
                try:
                    time_only = re.search(r'(\d+):(\d+)\s*(am|pm)', raw_time, re.I)
                    if time_only:
                        hh = int(time_only.group(1)) % 12
                        if time_only.group(3).lower() == 'pm':
                            hh += 12
                        mm = int(time_only.group(2))
                        dt_utc = now_utc.replace(hour=hh, minute=mm, second=0, microsecond=0)
                        # If time already passed today, assume it's tomorrow
                        if dt_utc < now_utc and (now_utc - dt_utc).seconds > 3600:
                            dt_utc = dt_utc + datetime.timedelta(days=1)
                        start_ts = int(_cal.timegm(dt_utc.timetuple()))
                except Exception:
                    pass

                # TotalSportek24's static HTML carries no live-status badge at all
                # (confirmed live — no "live"/LIVE markup anywhere on the page, it's
                # likely added client-side via JS). Hardcoding is_live=False here
                # meant a fight/game already underway never showed the LIVE tag.
                # Heuristic instead: if the parsed start time has already passed
                # but not too long ago, treat it as live — combat-sports cards
                # (boxing/UFC) commonly run 4+ hours including undercards.
                now_ts = int(time.time())
                is_live = bool(start_ts) and 0 <= (now_ts - start_ts) <= 5 * 3600

                events.append({
                    'id':       'tstek_' + re.sub(r'\W+', '_', href),
                    'slug':     href.replace(TSTEK_BASE, '').strip('/'),
                    'path':     'tstek:' + href,
                    'title':    title,
                    'datetime': raw_time,
                    'league':   sport_slug.upper(),
                    'logo':     '',
                    'is_live':  is_live,
                    'start_ts': start_ts or int(time.time()),
                })
                if len(events) >= max_items:
                    break     

    # Primary: new card layout with /game/ URLs, inline time and title
    if not events:
        _iter_cards = _RE_TSTEK_GAME_CARD.finditer(html)
        for m in _iter_cards:
            href     = m.group(1).strip()
            raw_time = m.group(2).strip()   # e.g. "01:00 am  UTC"
            title    = _clean(m.group(3))
            if not title or href in seen:
                continue
            seen.add(href)

            # Parse UTC time into a timestamp (assume today or tomorrow)
            start_ts = 0
            try:
                time_only = re.search(r'(\d+):(\d+)\s*(am|pm)', raw_time, re.I)
                if time_only:
                    hh = int(time_only.group(1)) % 12
                    if time_only.group(3).lower() == 'pm':
                        hh += 12
                    mm = int(time_only.group(2))
                    dt_utc = now_utc.replace(hour=hh, minute=mm, second=0, microsecond=0)
                    # If time already passed today, assume it's tomorrow
                    if dt_utc < now_utc and (now_utc - dt_utc).seconds > 3600:
                        dt_utc = dt_utc + datetime.timedelta(days=1)
                    start_ts = int(_cal.timegm(dt_utc.timetuple()))
            except Exception:
                pass

            events.append({
                'id':       'tstek_' + re.sub(r'\W+', '_', href),
                'slug':     href.replace(TSTEK_BASE, '').strip('/'),
                'path':     'tstek:' + href,
                'title':    title,
                'datetime': raw_time,
                'league':   sport_slug.upper(),
                'logo':     '',
                'is_live':  False,
                'start_ts': start_ts or int(time.time()),
            })
            if len(events) >= max_items:
                break

    # Fallback: older plain-text anchor layout
    if not events:
        tstek_seg  = _TSTEK_SLUGS.get(sport_slug, sport_slug)
        is_soccer  = (sport_slug == 'soccer')
        other_segs = set(_TSTEK_SLUGS.values()) - {tstek_seg}
        skip_words = {'schedule', 'fixtures', 'results', 'standings', 'news', 'about',
                      'contact', 'privacy', 'home', 'live', 'stream', 'watch', tstek_seg}
        _iter_events = _RE_TSTEK_EVENT.finditer(html)
        for m in _iter_events:
            href  = m.group(1).strip()
            title = _clean(m.group(2))
            if not title or len(title) < 5 or href in seen:
                continue
            path_parts = href.replace(TSTEK_BASE, '').strip('/').split('/')
            if is_soccer:
                if path_parts[0].lower() in other_segs:
                    continue
            else:
                if not path_parts or path_parts[0].lower() != tstek_seg.lower():
                    continue
            if title.lower() in skip_words:
                continue
            seen.add(href)
            events.append({
                'id':       'tstek_' + re.sub(r'\W+', '_', href),
                'slug':     href.replace(TSTEK_BASE, '').strip('/'),
                'path':     'tstek:' + href,
                'title':    title,
                'datetime': '',
                'league':   sport_slug.upper(),
                'logo':     '',
                'is_live':  False,
                'start_ts': int(time.time()),
            })
            if len(events) >= max_items:
                break

    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] TotalSportek24 %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _tstek_streams(event_path):
    """Scrape stream links from a TotalSportek24 event page."""
    url = event_path.replace('tstek:', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, 'totalsportek24.is', 'TotalSportek')
    xbmc.log('[Starfleet/Sports] TotalSportek24 streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _tstek_streams_by_title(sport_slug, event_title):
    """Cross-reference: find best TotalSportek24 event by title and scrape its streams."""
    try:
        evs = _tstek_events(sport_slug)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tstek_x events error: %s' % e, xbmc.LOGWARNING)
        return []
    best_path, best_score, best_title = None, 0, ''
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
            best_title = ev['title']
    xbmc.log('[Starfleet/Sports] tstek_x "%s" vs %d events: best="%s" score=%d path=%s'
             % (event_title, len(evs), best_title, best_score, best_path), xbmc.LOGINFO)
    if not best_path or best_score < 1:
        return []
    try:
        return _tstek_streams(best_path)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tstek_x streams error: %s' % e, xbmc.LOGWARNING)
        return []


# ── *24all.ir generic helpers ─────────────────────────────────────────────────

def _x24_events(domain, sport_label, path_prefix):
    """Generic scraper for *24all.ir sites (mlb24all.ir, nhl24all.ir, nfl24all.ir, nba24all.ir)."""
    base = 'https://' + domain
    pattern = re.compile(
        r'<a[^>]+href="(https?://' + re.escape(domain) + r'/[^"]+)"[^>]*>([^<]+)</a>',
        re.IGNORECASE
    )
    try:
        html = _sess().get(base + '/', timeout=12,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s fetch error: %s' % (domain, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()
    skip_words = ('home', 'schedule', 'about', 'contact', 'privacy', domain.split('.')[0])

    for m in pattern.finditer(html):
        path  = m.group(1).strip()
        title = _clean(m.group(2))
        if not title or len(title) < 4 or path in seen:
            continue
        if any(s in title.lower() for s in skip_words):
            continue
        seen.add(path)
        events.append({
            'id':       path_prefix + re.sub(r'\W+', '_', path),
            'slug':     re.sub(r'https?://' + re.escape(domain) + r'/', '', path).strip('/'),
            'path':     path_prefix + ':' + path,
            'title':    title,
            'datetime': '',
            'league':   sport_label,
            'logo':     '',
            'is_live':  True,
            'start_ts': 0,
        })

    xbmc.log('[Starfleet/Sports] %s: %d events' % (domain, len(events)), xbmc.LOGINFO)
    return events


def _x24_streams(event_path, path_prefix, domain, source_label):
    """Generic stream scraper for *24all.ir event pages."""
    url = event_path.replace(path_prefix + ':', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer='https://' + domain + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s stream page error (%s): %s' % (domain, event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, domain, source_label)

    # Also pick up any explicit watch/stream/live anchors not caught above
    extra_re = re.compile(
        r'<a[^>]+href="(https?://[^"]+)"[^>]*>(?:[^<]*(?:watch|stream|live)[^<]*)</a>',
        re.IGNORECASE
    )
    for m in extra_re.finditer(html):
        su = m.group(1).strip()
        if not su or domain in su:
            continue
        if not any(s['url'] == su for s in streams):
            streams.append({'label': source_label + ' Stream', 'url': su,
                            'quality': '', 'language': '', 'source': source_label})

    xbmc.log('[Starfleet/Sports] %s streams for %s: %d' % (domain, event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _x24_streams_by_title(event_title, domain, path_prefix, sport_label, source_label):
    """Cross-reference: find best matching event on *24all.ir and scrape its streams."""
    evs = _x24_events(domain, sport_label, path_prefix)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _x24_streams(best_path, path_prefix, domain, source_label)


# ── MethStreams (multi-sport, same slug structure as CrackStreams) ────────────

_METH_LEAGUE_PATHS = {
    'mlb':    '/league/mlbstreams',
    'nfl':    '/league/nflstreams',
    'nba':    '/league/nbastreams',
    'nhl':    '/league/nhlstreams',
    'ufc':    '/league/mmastreams',
    'boxing': '/league/boxingstreams',
    'soccer': '/league/soccerstreams',
    'wwe':    '/league/wwestreams',
    'ncaab':  '/league/ncaab',
    'cfb':    '/league/cfbstreams',
    'f1':     '/league/f1streams',
}

_RE_METH_STREAM_LINK = re.compile(
    r'href=["\'](/stream/([^"\'#\s]{4,80}))["\']', re.IGNORECASE
)

# Real per-event schedule: <h2>Saturday, July 25, 2026</h2> day header,
# followed by one <a class="card" href="/stream/slug">...card-title...
# Start time: H:MM AM/PM ET...</a> block per event. The listing-page HTML
# has this the whole time (confirmed live) — the plain-link-only regex
# above was throwing it away, which is why every event here showed no
# date/time and was hardcoded to a fake "always live" status instead.
_RE_METH_DAY_HEADER = re.compile(
    r'<h2>\s*[A-Za-z]+day,\s*([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})\s*</h2>'
)
_RE_METH_CARD = re.compile(
    r'<a class="card" href="(/stream/([^"#\s]{4,80}))">.*?'
    r'<div class="card-title">([^<]*)</div>.*?'
    r'Start time:\s*(\d{1,2}):(\d{2})\s*(AM|PM)\s*ET',
    re.IGNORECASE | re.DOTALL
)


@_cache.coalesced
def _meth_events(sport_slug, max_items=20):
    """Scrape MethStreams league page for event slugs."""
    import calendar as _cal
    path = _METH_LEAGUE_PATHS.get(sport_slug)
    if not path:
        return []
    ck = 'sports_meth_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    html = None
    for base in _METH_MIRRORS:
        try:
            html = _sess().get(base + path, timeout=10, headers=dict(_HEADERS, Referer=base + '/')).text
            if 'const allStreams' in html or '/stream/' in html:
                break
        except Exception as e:
            xbmc.log('[Starfleet/Sports] MethStreams %s (%s): %s' % (base, sport_slug, e), xbmc.LOGWARNING)
        html = None
    if not html:
        return []

    events = []
    seen = set()

    # Build day-header position → date lookup, so each card below can pick
    # up the date of the most recent header preceding it.
    day_headers = []  # list of (pos, date)
    for dm in _RE_METH_DAY_HEADER.finditer(html):
        try:
            month_name, day_num, year = dm.group(1), int(dm.group(2)), int(dm.group(3))
            d = _strp('%s %d %d' % (month_name, day_num, year), '%B %d %Y').date()
            day_headers.append((dm.start(), d))
        except Exception:
            continue

    def _date_for_pos(pos):
        best = None
        for hpos, d in day_headers:
            if hpos <= pos:
                best = d
            else:
                break
        return best

    now_ts = int(time.time())
    for cm in _RE_METH_CARD.finditer(html):
        link_path, game_slug, card_title = cm.group(1), cm.group(2), cm.group(3)
        if game_slug in seen:
            continue
        seen.add(game_slug)
        title = _clean(card_title) or game_slug.replace('-', ' ').title()

        start_ts = 0
        d = _date_for_pos(cm.start())
        if d is not None:
            try:
                hh, mm, ampm = int(cm.group(4)), int(cm.group(5)), cm.group(6).upper()
                if ampm == 'PM' and hh != 12:
                    hh += 12
                elif ampm == 'AM' and hh == 12:
                    hh = 0
                offset = _us_eastern_offset_seconds(d)
                start_ts = int(_cal.timegm(datetime.datetime(d.year, d.month, d.day, hh, mm).timetuple())) - offset
            except Exception:
                start_ts = 0

        # Site's own copy says links go live 1h before start; combat/multi-game
        # cards commonly run several hours — same live-window heuristic used
        # for TotalSportek24 above.
        is_live = bool(start_ts) and -3600 <= (now_ts - start_ts) <= 5 * 3600

        events.append({
            'id':       'meth_' + game_slug,
            'slug':     game_slug,
            'path':     'meth:' + METH_BASE + link_path,
            'title':    title,
            'datetime': '',
            'league':   sport_slug.upper(),
            'logo':     '',
            'is_live':  is_live,
            'start_ts': start_ts,
        })
        if len(events) >= max_items:
            break

    # Markup changed / nothing matched the dated-card pattern — fall back to
    # plain link scraping rather than silently returning zero events. No
    # date info available on this path, so leave start_ts/is_live honest
    # (0 / False) instead of the old hardcoded "always live right now".
    if not events:
        for m in _RE_METH_STREAM_LINK.finditer(html):
            link_path, game_slug = m.group(1), m.group(2)
            if game_slug in seen:
                continue
            seen.add(game_slug)
            events.append({
                'id':       'meth_' + game_slug,
                'slug':     game_slug,
                'path':     'meth:' + METH_BASE + link_path,
                'title':    game_slug.replace('-', ' ').title(),
                'datetime': '',
                'league':   sport_slug.upper(),
                'logo':     '',
                'is_live':  False,
                'start_ts': 0,
            })
            if len(events) >= max_items:
                break

    xbmc.log('[Starfleet/Sports] MethStreams %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    _cache.set(ck, events, 10 * 60)
    return events


def _remint_wrap(stream_url, page):
    """A resolved playlist address that holds a short-lived token ("/secure/<token>/...") gets the page it came from attached, so the relay can ask for a
    new token when the address went stale while the stream list was open (2026-11-21: a Meth link picked 3 minutes after the list opened answered 403)."""
    try:
        from starfleetscrapers.sports import sports_starfleet_live as _sl_rm
        return _sl_rm._with_remint(stream_url, {'url': page})
    except Exception:
        return stream_url


def _meth_event_streams(sport_slug, event_title=''):
    """Best-matching MethStreams event -> playable stream links.

    Its event page is 640KB of markup whose players are listed in a static
    `const allStreams = [{"label","type":"external","value":<embed url>}]` array.
    The embed hosts vary: measured 2026-09-26 across 30 events, 17 were
    embedindia.st (a JS/ad-network wrapper with no stream in the page), the rest
    flyembed.click, iframe.gs, trendy48.online, cdnlivetv.tv, embedsports.me and
    rockystream.st. Each embed is handed to the generic embed-chain resolver used
    by the live-site providers; only ones that come back as a real playlist are
    returned. (This used to return the event PAGE's own URL as a "stream", which
    can never play, so every MMA card showed a MethStreams link that failed.)"""
    evs = _meth_events(sport_slug)
    if not evs:
        return []
    best_slug, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_slug = ev['slug']
    if not best_slug or best_score < 2:
        return []
    embeds = []
    for base in _METH_MIRRORS:
        try:
            html_text = _get(base + '/stream/' + best_slug)
            m = re.search(r'const allStreams = (\[.*?\]);', html_text, re.S)
            embeds = json.loads(m.group(1)) if m else []
        except Exception:
            embeds = []
        if embeds:
            break
    embeds = [e for e in embeds if (e.get('value') or '').startswith('http')][:6]
    if not embeds:
        return []
    try:
        from starfleetscrapers.sports import sports_starfleet_live as _sl
    except Exception:
        return []
    out = []
    ex = ThreadPoolExecutor(max_workers=len(embeds))
    futs = {ex.submit(_sl.resolve_link, e['value']): e for e in embeds}
    ex.shutdown(wait=False)

    def _row(e):
        # the list holds the player page ('meth:<page>'); the playlist address is looked up again when the link is picked (see _meth_refresh)
        return {'label': 'MethStreams %s' % (e.get('label') or 'Link'), 'url': 'meth:' + e['value'],
                'quality': '', 'language': '', 'source': 'MethStreams'}
    try:
        for fut in as_completed(futs, timeout=8):
            try:
                url = fut.result()
            except Exception:
                url = None
            if url:
                out.append(_row(futs[fut]))
    except Exception:
        pass
    # a player page too slow to answer within the wait is still listed (a slow device would otherwise show no MethStreams at all)
    for fut, e in futs.items():
        if not fut.done():
            out.append(_row(e))
    return out


def _meth_refresh(meth_url):
    """'meth:<player page>' -> a fresh playlist address (its token lasts about a minute, so it is read again when the link is picked), or None."""
    try:
        page = meth_url[len('meth:'):]
        from starfleetscrapers.sports import sports_starfleet_live as _sl
        fresh = _sl.resolve_link(page)
        return _remint_wrap(fresh, page) if fresh else None
    except Exception as e:
        xbmc.log('[Starfleet/Sports] methstreams refresh: %s' % (e or type(e).__name__), xbmc.LOGINFO)
        return None


# ── *24all.ir (mlb24all.ir, nba24all.ir, nhl24all.ir, nfl24all.ir) ────────────
#
# These sites are now client-rendered Angular SPAs — the old anchor-scraping
# approach below (_x24_events/_x24_streams, still used by mlb66.ir) finds
# nothing on them any more since there's no per-game HTML to scrape.
#   POST https://api.<domain>/api/v2/generate_stream_info
#        {media_event_id, flavor_id} -> {url, wait} - a direct, playable HLS
#        master.m3u8 URL, no auth needed for "free.*" flavors (verified live
#        against mlb24all.ir with zero cookies/tokens). "premium.*" flavors
#        need an account token we don't have, so only free ones are tried.
#
# The catalogue itself (teams/games/media_events/flavors) used to be its own
# clean GET https://api.<domain>/api/v3/stateshot JSON endpoint — confirmed
# dead 2026-09-11 (real 404 "Get over it!" body across all 4 domains, not a
# connectivity issue; the API host itself is still alive, e.g. its bare root
# returns "potato"). Found live via a real browser's window.stateshot global
# that the site now embeds directly in the homepage's own server-rendered
# HTML as `var stateshot = {...};` (same exact shape as the old endpoint's
# response — teams/games/media_events/flavors/etc, confirmed identical keys)
# instead of serving it from a separate API path. _all24_stateshot() below
# now fetches the plain homepage and extracts that inline blob instead.

_ALL24_DOMAINS = {
    'mlb': 'mlb24all.ir',
    'nba': 'nba24all.ir',
    'nhl': 'nhl24all.ir',
    'nfl': 'nfl24all.ir',
}


def _extract_js_object(html_text, var_name):
    """Pull a `var <var_name> = {...};` JS object literal out of raw HTML and
    JSON-parse it. Walks brace depth manually (respecting string literals,
    so a '}' or '"' inside a quoted value can't end the scan early) rather
    than a regex — a non-greedy `.*?` regex would silently truncate at the
    FIRST inner '};' it finds (e.g. inside a nested sub-object or a string
    value containing that literal sequence), which is exactly the kind of
    subtle wrong-answer bug that's easy to miss in a quick live check
    against just one sample page."""
    marker = 'var %s = {' % var_name
    idx = html_text.find(marker)
    if idx == -1:
        return None
    start = idx + len(marker) - 1  # position of the opening '{'
    depth = 0
    in_string = False
    escape = False
    i = start
    while i < len(html_text):
        c = html_text[i]
        if in_string:
            if escape:
                escape = False
            elif c == '\\':
                escape = True
            elif c == '"':
                in_string = False
        else:
            if c == '"':
                in_string = True
            elif c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    end = i + 1
                    try:
                        return json.loads(html_text[start:end])
                    except Exception:
                        return None
        i += 1
    return None


def _all24_stateshot(sport_slug):
    domain = _ALL24_DOMAINS.get(sport_slug)
    if not domain:
        return None
    ck = 'all24_stateshot_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        r = _sess().get('https://%s/' % domain, timeout=10, headers=_HEADERS)
        data = _extract_js_object(r.text, 'stateshot')
        if not data:
            return None
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s stateshot error: %s' % (domain, e), xbmc.LOGWARNING)
        return None
    _cache.set(ck, data, 2 * 60)  # scores/live status move fast — keep this short
    return data


def _all24_find_game(data, event_title):
    """Match event_title against team name pairs, preferring a currently-live
    game, then the most recently finished one, then the soonest upcoming."""
    teams = {t['id']: t for t in data.get('teams', [])}
    title_l = (event_title or '').lower()

    def _names(tid):
        t = teams.get(tid) or {}
        return [n for n in (t.get('name'), t.get('short_name'), t.get('abbreviation')) if n]

    candidates = []
    for g in data.get('games', []):
        away_hit = any(n.lower() in title_l for n in _names(g.get('away_team_id')))
        home_hit = any(n.lower() in title_l for n in _names(g.get('home_team_id')))
        if away_hit and home_hit:
            candidates.append(g)
    if not candidates:
        return None

    status_rank = {'L': 0, 'W': 0, 'F': 1, 'S': 2}
    candidates.sort(key=lambda g: (status_rank.get(g.get('status'), 3), g.get('datetime') or ''))
    return candidates[0]


def _all24_generate_stream(domain, media_event_id, flavor_id, attempts=2):
    """POST /api/v2/generate_stream_info -> direct m3u8 URL, or None. A 'wait'
    response means the backend is still warming the stream up — retry briefly
    rather than giving up immediately (mirrors the site's own health-check
    retry behavior, seen in its JS)."""
    for i in range(attempts):
        try:
            r = _sess().post(
                'https://api.%s/api/v2/generate_stream_info' % domain,
                json={'media_event_id': media_event_id, 'flavor_id': flavor_id},
                timeout=8, headers=dict(_HEADERS, Origin='https://' + domain, Referer='https://' + domain + '/'))
            data = r.json()
        except Exception as e:
            xbmc.log('[Starfleet/Sports] %s generate_stream_info error: %s' % (domain, e), xbmc.LOGWARNING)
            return None
        if not data.get('wait') and data.get('url'):
            return data['url']
        if i < attempts - 1:
            time.sleep(1.5)
    return None


def _all24_streams_by_title(sport_slug, event_title):
    """Cross-reference: find the matching game on *24all.ir and resolve each
    of its free-flavor media events (e.g. ESPN Home/Away, Sportsnet) to a
    direct stream URL in parallel."""
    domain = _ALL24_DOMAINS.get(sport_slug)
    if not domain:
        return []
    data = _all24_stateshot(sport_slug)
    if not data:
        return []
    game = _all24_find_game(data, event_title)
    if not game:
        return []
    game_id = game['id']
    media_events = [m for m in data.get('media_events', []) if m.get('game_id') == game_id]
    if not media_events:
        return []

    free_flavor_ids = {f['id'] for f in data.get('flavors', [])
                       if f['id'].startswith('free.') and 'vod' not in f['id']}
    me_to_flavor = {}
    for f in data.get('flavors', []):
        if f['id'] not in free_flavor_ids:
            continue
        for me_id in f.get('media_event_ids', []):
            me_to_flavor.setdefault(me_id, f['id'])

    jobs = [(me, me_to_flavor[me['id']]) for me in media_events if me['id'] in me_to_flavor]
    if not jobs:
        return []

    results = [None] * len(jobs)
    with ThreadPoolExecutor(max_workers=len(jobs)) as ex:
        futs = {ex.submit(_all24_generate_stream, domain, me['id'], flavor_id): i
                for i, (me, flavor_id) in enumerate(jobs)}
        for fut in futs:
            i = futs[fut]
            try:
                results[i] = fut.result(timeout=10)
            except Exception as e:
                xbmc.log('[Starfleet/Sports] %s stream job error: %s' % (domain, e), xbmc.LOGWARNING)

    out = []
    for (me, _flavor_id), url in zip(jobs, results):
        if not url:
            continue
        out.append({
            'label': '%s (%s)' % (me.get('title') or 'Stream', me.get('provider') or domain),
            'url': url,
            'quality': '',
            'language': '',
            'source': domain.split('.')[0].upper(),
        })
    # the site hands out an address as soon as it is asked, even when its server cannot deliver the feed yet
    if out:
        with ThreadPoolExecutor(max_workers=len(out)) as aex:
            ok = list(aex.map(lambda o: _has_segments(o['url'], timeout=6), out))
        out = [o for o, good in zip(out, ok) if good]
    xbmc.log('[Starfleet/Sports] %s streams for "%s": %d' % (domain, event_title, len(out)), xbmc.LOGINFO)
    return out


# ── slapstreams.com (NHL, one page per team) ──────────────────────────────────
#
# Each team page (/<team>-live/) shows the team's current game ("Away @ Home") with buttons for the home
# and away broadcast feeds. A feed page (/stream/<name>.html) carries `var _d=[id,ts,token]`; GET
# /stream/check_stream.php?id&ts&pt answers {"url": "<tokenised HLS playlist>"} - plain HTTP, no headers
# needed to play it. LINK 3/LINK 4 are third-party iframes (kept only when streame.center, which has a
# resolver here). nhl-network-live is the same layout for the 24/7 NHL Network feed.

_SLAP_BASE = 'https://slapstreams.com'
_RE_SLAP_TEAM = re.compile(r'href="https://slapstreams\.com/([a-z0-9-]+)-live/"')
_RE_SLAP_BTN = re.compile(
    r'<a class="btn[^"]*" href="(https://slapstreams\.com/stream/[^"]+)"[^>]*>.*?&nbsp;([^<]+)</a>', re.S)
_RE_SLAP_D = re.compile(r"var _d=\[(\d+),'(\d+)','([0-9a-f]+)'\]")
_RE_SLAP_MATCHUP = re.compile(
    r'<h1 class="gametitle">.*?<span class="tm[^"]*">([^<]+)</span>.*?<span class="at">.*?'
    r'<span class="tm[^"]*">([^<]+)</span>', re.S)
_RE_SLAP_IFRAME = re.compile(r"<iframe[^>]+src='([^']+)'")


_SLAP_TEAMS = ('anaheim-ducks', 'boston-bruins', 'buffalo-sabres', 'calgary-flames', 'carolina-hurricanes',
               'chicago-blackhawks', 'colorado-avalanche', 'columbus-blue-jackets', 'dallas-stars',
               'detroit-red-wings', 'edmonton-oilers', 'florida-panthers', 'los-angeles-kings', 'minnesota-wild',
               'montreal-canadiens', 'nashville-predators', 'new-jersey-devils', 'new-york-islanders',
               'new-york-rangers', 'ottawa-senators', 'philadelphia-flyers', 'pittsburgh-penguins',
               'san-jose-sharks', 'seattle-kraken', 'st-louis-blues', 'tampa-bay-lightning',
               'toronto-maple-leafs', 'utah-hockey-club', 'vancouver-canucks', 'vegas-golden-knights',
               'washington-capitals', 'winnipeg-jets')


def _slap_team_slugs():
    # the 32 clubs are fixed; no request needed (a slow homepage fetch cost seconds before)
    return list(_SLAP_TEAMS)


def _slap_nickname(slug):
    # utah-hockey-club (the site's name) is the Utah Mammoth on the schedules; everyone else is the last word
    return 'utah' if slug.startswith('utah') else slug.split('-')[-1]


def _slap_alive(url):
    """True when the playlist (or its first variant) actually lists segments - an offline feed answers
    200 with an empty body."""
    try:
        r = _sess().get(url, timeout=6, headers=_HEADERS)
        txt = r.text or ''
        if r.status_code != 200 or '#EXTM3U' not in txt[:50]:
            return False
        if 'EXT-X-STREAM-INF' in txt:
            from urllib.parse import urljoin as _uj
            nxt = [l for l in txt.splitlines() if l and not l.startswith('#')]
            if not nxt:
                return False
            r = _sess().get(_uj(r.url, nxt[0]), timeout=6, headers=_HEADERS)
            txt = r.text or ''
        return r.status_code == 200 and '#EXTINF' in txt
    except Exception:
        return False


_SLAP_HEADERS = dict(_HEADERS, **{
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,application/json,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9'})


_SLAP_UAS = {
    'chrome-win': _HEADERS['User-Agent'],
    'chrome-android': ('Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) '
                       'Chrome/126.0.0.0 Mobile Safari/537.36'),
    'python': None,         # whatever requests sends by default
    'curl': 'curl/8.4.0',
}
_slap_variant = [None]      # the request style that last worked on this device
_slap_blocked_until = [0.0]  # the site answered every style with 403: leave it alone until then
_slap_env_logged = [False]


def _slap_log_env():
    if _slap_env_logged[0]:
        return
    _slap_env_logged[0] = True
    try:
        import ssl, sys as _sys, urllib3
        xbmc.log('[Starfleet/Sports] slapstreams env: python %s, %s, requests %s, urllib3 %s' % (
            _sys.version.split()[0], ssl.OPENSSL_VERSION, _req.__version__, urllib3.__version__), xbmc.LOGINFO)
    except Exception:
        pass


def _slap_try(variant, url, referer, params, timeout):
    """One request in one style: browser-like headers with a given User-Agent, or the Cloudflare session."""
    if variant == 'cloudscraper':
        hdr = dict(_SLAP_HEADERS)
        if referer:
            hdr['Referer'] = referer
        return _cf_sess().get(url, headers=hdr, params=params, timeout=timeout)
    if variant == 'urllib':
        import urllib.request as _ur, urllib.parse as _up
        full = url + (('&' if '?' in url else '?') + _up.urlencode(params) if params else '')
        rq = _ur.Request(full, headers={'User-Agent': _SLAP_UAS['chrome-win'], 'Accept': '*/*',
                                        'Referer': referer or _SLAP_BASE + '/'})
        with _ur.urlopen(rq, timeout=timeout) as resp:
            body = resp.read().decode('utf-8', 'replace')

            class _R(object):
                status_code = resp.status
                text = body
                def json(self_):
                    return json.loads(body)
            return _R()
    hdr = dict(_SLAP_HEADERS)
    if _SLAP_UAS.get(variant):
        hdr['User-Agent'] = _SLAP_UAS[variant]
    else:
        hdr.pop('User-Agent', None)
    if referer:
        hdr['Referer'] = referer
    return _sess().get(url, headers=hdr, params=params, timeout=timeout)


def _slap_fetch(url, want, referer=None, params=None, timeout=8):
    """GET that survives a site answering some devices differently (the Firestick got HTTP 403 with a
    2 KB block page while a PC got the real page). Tries the style that worked last time first, then the
    other request styles, and logs the status of every failure plus what the block page said."""
    _slap_log_env()
    if time.time() < _slap_blocked_until[0]:
        return None         # this address was just turned away: asking again only extends the block
    order = ['chrome-win', 'chrome-android', 'python', 'curl', 'urllib', 'cloudscraper']
    if _slap_variant[0] in order:
        order.remove(_slap_variant[0])
        order.insert(0, _slap_variant[0])
    fails = []
    for variant in order:
        try:
            r = _slap_try(variant, url, referer, params, timeout)
            if r.status_code == 429:
                time.sleep(1.5)
                r = _slap_try(variant, url, referer, params, timeout)
            if r.status_code == 200 and want in (r.text or ''):
                if _slap_variant[0] != variant:
                    xbmc.log('[Starfleet/Sports] slapstreams: request style "%s" works on this device' % variant, xbmc.LOGINFO)
                _slap_variant[0] = variant
                return r
            body = re.sub(r'<[^>]+>', ' ', re.sub(r'(?is)<(script|style).*?</\1>', ' ', r.text or ''))
            fails.append('%s=%s' % (variant, r.status_code))
            if variant == order[0]:
                xbmc.log('[Starfleet/Sports] slapstreams %s: HTTP %s, %d bytes: %s' % (
                    url[-40:], r.status_code, len(r.text or ''), re.sub(r'\s+', ' ', body).strip()[:300]),
                    xbmc.LOGINFO)
            if r.status_code not in (403, 503, 200):
                break
            if len(fails) >= 3 and all(f.endswith('=403') for f in fails):
                break       # a firewall block answers every style the same; more tries only add to it
        except Exception as e:
            fails.append('%s=%s' % (variant, type(e).__name__))
            if variant in ('urllib', 'cloudscraper'):
                xbmc.log('[Starfleet/Sports] slapstreams %s %s: %s' % (variant, url[-40:], e), xbmc.LOGINFO)
        if variant == 'curl' and all(f.split('=')[1] in ('403', '503') for f in fails):
            pass
    if len(fails) >= 3 and all(f.endswith('=403') for f in fails):
        _slap_blocked_until[0] = time.time() + 10 * 60
    xbmc.log('[Starfleet/Sports] slapstreams %s unusable: %s' % (url[-40:], ', '.join(fails)), xbmc.LOGINFO)
    return None


def _slap_resolve_embed(url):
    """A SlapStreams LINK 3/4 player address -> playable playlist (pipe headers), or None when the feed is not live."""
    try:
        from starfleetscrapers.sports import sports_pages_live as _sp
        from starfleetscrapers.sports import sports_starfleet_live as _cw
        res = _sp.resolve_page(url)
        if not res:
            return None
        kind, val = res
        if kind == 'embed':
            return _cw.resolve_link(val)
        return val if _cw._still_alive(val) else None
    except Exception as e:
        xbmc.log('[Starfleet/Sports] slapstreams embed %s: %s' % (url[-40:], e or type(e).__name__), xbmc.LOGINFO)
        return None


def _slap_page_buttons(page_slug):
    """([(feed page, button label)], page html) of one slapstreams team page: one request, nothing is checked yet."""
    page_url = '%s/%s-live/' % (_SLAP_BASE, page_slug)
    pr = _slap_fetch(page_url, 'class="btn', timeout=10)
    page = pr.text if pr is not None else ''
    buttons, seen_pages = [], set()
    for href, label in _RE_SLAP_BTN.findall(page):
        if href not in seen_pages:
            seen_pages.add(href)
            buttons.append((href, _clean(label) or 'Feed'))
    return buttons, page


def _slap_feeds(page_slug, referer_page=None, only_label=None):
    """[(label, url)] for one slapstreams page: the home/away feeds as tokenised playlists plus any
    streame.center link. `only_label` checks just that button (the one being played)."""
    page_url = '%s/%s-live/' % (_SLAP_BASE, page_slug)
    buttons, page = _slap_page_buttons(page_slug)
    if only_label:
        buttons = [b for b in buttons if b[1] == only_label] or buttons

    def one(href, label):
        try:
            fr = _slap_fetch(href, '<', referer=page_url, timeout=6)
            h = fr.text if fr is not None else ''
            m = _RE_SLAP_D.search(h)
            if m:
                _prm = {'id': m.group(1), 'ts': m.group(2), 'pt': m.group(3)}
                cs = _slap_fetch(_SLAP_BASE + '/stream/check_stream.php', '"url"', referer=href, params=_prm, timeout=6)
                if cs is None:
                    return None
                url = (cs.json() or {}).get('url')
                if not url:
                    return None
                if not _slap_alive(url):
                    xbmc.log('[Starfleet/Sports] slapstreams %s: feed not on air' % label, xbmc.LOGINFO)
                    return None
                return (label, url)
            im = _RE_SLAP_IFRAME.search(h)
            if im:
                # LINK 3 / LINK 4 are third-party players (streame.center, rockylive...): follow them to a playlist
                res = _slap_resolve_embed(im.group(1))
                if res:
                    return (label, res)
                if WEB_SNIFF:
                    # the player hides its stream in JavaScript: the app's web view takes it from the page
                    WEB_URLS.add(im.group(1))
                    return (label, 'sfweb:' + im.group(1))
        except Exception as e:
            xbmc.log('[Starfleet/Sports] slapstreams feed %s: %s' % (href, e), xbmc.LOGINFO)
        return None

    out = []
    if buttons:
        with ThreadPoolExecutor(max_workers=len(buttons)) as pool:
            for res in pool.map(lambda bl: one(*bl), buttons):
                if res:
                    out.append(res)
    return out, page


def _slap_streams_by_title(sport_slug, event_title):
    if sport_slug != 'nhl' or not event_title:
        return []
    try:
        slugs = _slap_team_slugs()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] slapstreams index error: %s' % e, xbmc.LOGWARNING)
        return []
    import unicodedata as _ud
    t = _ud.normalize('NFKD', event_title).encode('ascii', 'ignore').decode().lower()
    hits = [sl for sl in slugs if _slap_nickname(sl) in t]
    if not hits:
        xbmc.log('[Starfleet/Sports] slapstreams: no team match for "%s"' % event_title, xbmc.LOGINFO)
        return []
    # the two sides THIS game's own title names - confirmed live 2026-11-19: a team not playing right now can
    # still show buttons that point at whatever game is currently in that broadcast slot (one team's page
    # pointed at another, unrelated, live game's feed). The old check only ran when both sides had their own
    # SlapStreams slug hit (len(hits) > 1); a one-sided hit skipped it and could hand back that wrong game, so
    # this now always checks the page's own matchup against the title's two sides, not just against `hits`.
    _parts = re.split(r'\s+(?:vs\.?|v|at|@|-|–)\s+', event_title, maxsplit=1, flags=re.I)
    _wanted = []
    for p in _parts:
        words = re.findall(r'[A-Za-z]+', _ud.normalize('NFKD', p).encode('ascii', 'ignore').decode())
        if words:
            _wanted.append(words[-1].lower())
    for sl in hits[:2]:
        try:
            # listed at once from the team page; the feed itself is checked and given a fresh token when it is played
            feeds, page = _slap_page_buttons(sl)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] slapstreams %s error: %s' % (sl, e), xbmc.LOGINFO)
            continue
        mm = _RE_SLAP_MATCHUP.search(page)
        if mm and len(_wanted) == 2:
            both = _ud.normalize('NFKD', mm.group(1) + ' ' + mm.group(2)).encode('ascii', 'ignore').decode().lower()
            if not all(w in both for w in _wanted):
                continue      # this team's page is showing a different game
        if not feeds:
            xbmc.log('[Starfleet/Sports] slapstreams %s: no live feeds' % sl, xbmc.LOGINFO)
            continue
        streams = []
        for _href, label in feeds:
            # these playlist addresses carry a token that stops working after about two minutes, so the address
            # is looked up again at the moment the stream is played (see _slap_refresh)
            streams.append({'label': 'SlapStreams %s' % label.title(),
                            'url': 'slap:%s#%s' % (sl, label), 'quality': 'HLS',
                            'language': 'EN', 'source': 'SlapStreams'})
        xbmc.log('[Starfleet/Sports] slapstreams streams for "%s": %d' % (event_title, len(streams)), xbmc.LOGINFO)
        return streams
    return []


# ── YouTube live broadcasts (college sports) ────────────────────────────────────────────────────────────────────────────────
# ESPN lists many college games as "YouTube" (tournament producers, schools' own channels). The stream is an ordinary YouTube live
# video, found by searching YouTube for the two teams; the shared resolver turns it into an HLS playlist (1080p60 at best).
# Score-ticker "live" channels (a scoreboard on a still picture) are common in the same search and are left out.
_YT_SPORTS = ('ncaab', 'ncaaw', 'ncaah', 'cfb', 'wnba', 'cfl')
_YT_BAD_TITLE = re.compile(r'live\s*scores?|scoreboard|play[- ]by[- ]play|commentary|box\s*score|audio|watch\s*along|reaction|radio|prediction|'
                           r'preview|highlights?|stats|simulation|\b2k\d*\b|\bfifa\b|\bncaaf\b|\bfootball\b.*\bbasketball\b', re.I)
_YT_BAD_CHANNEL = re.compile(r'score|dope media|zaiyd|lines crossed|betting|picks|odds|stats|gaming|sim\b', re.I)
# an official broadcast comes from a school / conference / event producer; the rest of what a search finds is score tickers and re-streams
_YT_OFFICIAL_CHANNEL = re.compile(r'athletic|network|conference|productions|vision\b|tv\b|sports\s*(?:media|network|video)|broadcast|invitational|classic|'
                                  r'espn|cbs|fox|nbc|big\s*(?:ten|east|12)|\bsec\b|\bacc\b|mountain west|sun belt|ivy|patriot|summit|horizon|wcc|mvc|a-10|swac|meac|southland', re.I)
_YT_GENERIC = {'state', 'st', 'university', 'college', 'southern', 'northern', 'western', 'eastern', 'central', 'new', 'north', 'south', 'east', 'west'}


def _yt_sides(event_title):
    import unicodedata as _ud
    t = _ud.normalize('NFKD', event_title or '').encode('ascii', 'ignore').decode()
    parts = re.split(r'\s+(?:vs\.?|v|at|@|-)\s+', t, maxsplit=1, flags=re.I)
    sides = []
    for p in parts:
        words = re.findall(r"[A-Za-z0-9&'.]+", p)
        if not words:
            continue
        mascot = words[-1].lower() if len(words) > 1 else ''
        school = ' '.join(words[:-1] if len(words) > 1 else words).lower()
        sides.append((school, mascot))
    return sides


def _yt_side_in(side, text):
    school, mascot = side
    if school and school in text:
        return True
    if mascot and re.search(r'\b%s\b' % re.escape(mascot), text):
        return True
    toks = [w for w in re.findall(r'[a-z0-9]+', school) if w not in _YT_GENERIC]
    return bool(toks) and all(re.search(r'\b%s\b' % re.escape(w), text) for w in toks)


def _yt_live_streams_by_title(sport_slug, event_title):
    if sport_slug not in _YT_SPORTS or not event_title:
        return []
    sides = _yt_sides(event_title)
    if len(sides) != 2:
        return []
    # the full names ("Troy Trojans Valparaiso Beacons basketball") find the producer's own upload; the short names only find score tickers
    import unicodedata as _ud
    full = re.split(r'\s+(?:vs\.?|v|at|@|-)\s+', _ud.normalize('NFKD', event_title).encode('ascii', 'ignore').decode(), maxsplit=1, flags=re.I)
    word = {'ncaah': 'hockey', 'cfb': 'football', 'cfl': 'football'}.get(sport_slug, 'basketball')
    away_n, home_n = full[0].strip(), full[1].strip()
    queries = [('%s %s %s' % (home_n, away_n, word), False), ('%s %s %s' % (away_n, home_n, word), False),
               ('%s %s %s live' % (home_n, away_n, word), True), ('%s vs %s live stream' % (away_n, home_n), True)]
    hdr = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36', 'Accept-Language': 'en-US,en;q=0.9'}

    def _search(qa):
        q, live_only = qa
        try:
            r = _sess().get('https://www.youtube.com/results', params={'search_query': q, 'sp': 'EgJAAQ%3D%3D' if live_only else ''},
                            timeout=10, headers=hdr, cookies={'CONSENT': 'YES+1'})
            m = re.search(r'var ytInitialData\s*=\s*(\{.*?\});</script>', r.text, re.S)
            return json.loads(m.group(1)) if m else None
        except Exception as e:
            xbmc.log('[Starfleet/Sports] youtube search error: %s' % e, xbmc.LOGINFO)
            return None
    with ThreadPoolExecutor(max_workers=4) as _ex_y:
        datas = list(_ex_y.map(_search, queries))
    found = []
    seen_ids = set()

    def walk(o):
        if isinstance(o, dict):
            v = o.get('videoRenderer')
            if v and v.get('videoId') not in seen_ids:
                seen_ids.add(v.get('videoId'))
                found.append(v)
            for x in o.values():
                walk(x)
        elif isinstance(o, list):
            for x in o:
                walk(x)
    for d in datas:
        if d:
            walk(d)
    cands = []
    for v in found:
        title = ''.join(x.get('text', '') for x in (v.get('title') or {}).get('runs', []))
        chan = ''.join(x.get('text', '') for x in (v.get('ownerText') or {}).get('runs', []))
        live = any((b.get('metadataBadgeRenderer') or {}).get('label') == 'LIVE' for b in v.get('badges') or [])
        low = title.lower()
        if not live or _YT_BAD_TITLE.search(title) or _YT_BAD_CHANNEL.search(chan):
            continue
        if not (_YT_OFFICIAL_CHANNEL.search(chan) or any(_yt_side_in(sd, chan.lower()) for sd in sides)):
            continue
        if not all(_yt_side_in(sd, low) for sd in sides):
            continue
        cands.append((v.get('videoId'), title, chan))
    out = []
    for vid, title, chan in cands[:3]:
        out.append({'label': 'YouTube - %s' % (chan or 'live'), 'url': 'https://www.youtube.com/watch?v=%s' % vid,
                    'quality': 'HD', 'language': 'EN', 'source': 'YouTube'})
    if out:
        xbmc.log('[Starfleet/Sports] youtube live for "%s": %d' % (event_title, len(out)), xbmc.LOGINFO)
    return out


def _slap_refresh(slap_url):
    """'slap:<team page>#<button label>' -> a fresh playlist address for that button (or None)."""
    try:
        rest = slap_url[len('slap:'):]
        page, _, label = rest.partition('#' if '#' in rest else '|')
        feeds, _page = _slap_feeds(page, only_label=label)
        for lab, url in feeds:
            if lab == label:
                return url
        return feeds[0][1] if len(feeds) == 1 else None
    except Exception as e:
        xbmc.log('[Starfleet/Sports] slapstreams refresh: %s' % (e or type(e).__name__), xbmc.LOGINFO)
        return None


def slap_nhl_network_url():
    """24/7 NHL Network playlist from slapstreams, or None."""
    try:
        feeds, _page = _slap_feeds('nhl-network')
    except Exception:
        return None
    for _label, url in feeds:
        if 'streame.center' not in url and not url.startswith('sfweb:'):
            return url
    return None


# ── mlb66.ir (MLB-specific — dedicated live stream aggregator) ────────────────

def _mlb66_events():
    return _x24_events('mlb66.ir', 'MLB', 'mlb66')

def _mlb66_streams(event_path):
    return _x24_streams(event_path, 'mlb66', 'mlb66.ir', 'MLB66')

def _mlb66_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'mlb66.ir', 'mlb66', 'MLB', 'MLB66')


# ── BuffStreams (baseball section) ────────────────────────────────────────────

BUFFSTREAMS_BASE = 'https://buffstreams.app'

_RE_BUFF_GAME = re.compile(
    r'<a[^>]+href="(/[^"]*(?:baseball|mlb)[^"]*)"[^>]*>\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)


def _buffstreams_mlb_events():
    for path in ('/baseball/', '/baseball', '/'):
        try:
            html = _sess().get(BUFFSTREAMS_BASE + path, timeout=10,
                               headers=dict(_HEADERS, Referer='https://www.google.com/')).text
            events = []
            skip = {'home', 'schedule', 'about', 'contact', 'privacy', 'dmca', 'terms'}
            for m in _RE_BUFF_GAME.finditer(html):
                link = m.group(1).strip()
                title = _clean(m.group(2))
                if not title or title.lower() in skip:
                    continue
                full_url = BUFFSTREAMS_BASE + link
                events.append({
                    'id': 'buff_' + re.sub(r'\W+', '_', link),
                    'slug': link.strip('/'),
                    'path': 'buffstreams:' + full_url,
                    'title': title, 'datetime': '', 'league': 'MLB',
                    'logo': '', 'is_live': True, 'start_ts': 0,
                })
            if events:
                xbmc.log('[Starfleet/Sports] BuffStreams MLB: %d events' % len(events), xbmc.LOGINFO)
                return events
        except Exception as e:
            xbmc.log('[Starfleet/Sports] BuffStreams fetch error (%s): %s' % (path, e), xbmc.LOGWARNING)
    return []


def _buffstreams_streams(event_path):
    url = event_path.replace('buffstreams:', '')
    try:
        html = _sess().get(url, timeout=10,
                           headers=dict(_HEADERS, Referer=BUFFSTREAMS_BASE + '/')).text
        return _extract_stream_links(html, 'buffstreams.app', 'BuffStreams')
    except Exception as e:
        xbmc.log('[Starfleet/Sports] BuffStreams streams error: %s' % e, xbmc.LOGWARNING)
        return []


def _buffstreams_streams_by_title(event_title):
    evs = _buffstreams_mlb_events()
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = ev['path']
    if not best_path or best_score < 2:
        return []
    return _buffstreams_streams(best_path)


# ── BuffStreams v6 (buffstreams.com.co/v6) — SSR event+mirror-link dump ──────
#
# A different, unrelated site from buffstreams.app above despite the shared
# name. Confirmed live 2026-08-15: the /v6 homepage is a Next.js app, but
# unlike a client-rendered SPA its React Server Components response embeds
# the ENTIRE event list — every currently scheduled/live game across every
# sport the site carries, each already with its own full array of 40-50+
# named mirror links (`"directStreams": [{"link","name","quality",...}]`)
# — right in the initial HTML response, as escaped JSON inside
# `self.__next_f.push([1,"..."])` script chunks. No per-game page fetch or
# API call needed at all: one homepage GET returns both the schedule AND
# every game's full mirror list in one shot.
#
# Those mirror links point to ~15 different third-party sites, each its own
# separate embed technology — not all chased down (out of scope for one
# integration), but one was verified end-to-end: the "ovostreams" mirror's
# ovo-goal.st page embeds an iframe.st player page whose JS computes its
# real HLS source via a purely static, reproducible 6-layer string
# transform (unshuffle -> XOR -> hex-decode -> ROT13 -> reverse -> base64
# decode — the player's own code comment literally calls this "OBFUSCATED
# CONFIGURATION", but it's cosmetic: no browser/JS engine ever needs to run
# it, confirmed live by reimplementing the exact same steps in plain Python
# against the real page's own embedded constants and getting back a
# byte-for-byte match for the URL the site's own JS would have computed).
# That URL is a Cloudflare Worker API endpoint which 403s with no Origin
# header but returns a real `{"success":true,"stream":"https://...m3u8?
# cst=..."}` once an `Origin: <player page's own origin>` header is sent —
# confirmed live end-to-end against a real, then-currently-live Chelsea vs
# Real Sociedad stream, all the way through fetching the resulting .m3u8
# and getting a genuine #EXTM3U live playlist back (not just a 200 on the
# API call).
#
# Every OTHER mirror on a matched game is still tried too, through the
# exact same generic resolveurl/embed_resolver chain this file's other
# sources already use (_sportsurge_try_resolve's own docstring has the
# rationale) — most of them are genuinely JS-gated the same way most of
# SportSurge's mirrors are (confirmed for at least one other mirror here,
# ripple.kora.st, whose iframe src is set via JS post-load with nothing
# static in the HTML — literally `src="about:blank"`), so only whichever
# mirrors actually resolve get shown, same self-correcting "don't hardcode
# a stale allowlist" approach already used throughout this file.

BUFFCOM_BASE = 'https://buffstreams.com.co/v6'

_RE_BUFFCOM_PUSH = re.compile(r'__next_f\.push\(\[1,"((?:[^"\\]|\\.)*)"\]\)')

# The decrypt player's own three embedded constants (see _buffcom_decrypt's
# docstring for what each layer does) — re-extracted fresh from each page's
# own HTML rather than hardcoded, since only the encoded _wd payload is
# guaranteed per-page/per-game; _wk/_wri could plausibly change too.
_RE_WORKER_WD  = re.compile(r'_wd\s*=\s*"([0-9a-fA-F]+)"')
_RE_WORKER_WK  = re.compile(r'_wk\s*=\s*(\d+)')
_RE_WORKER_WRI = re.compile(r'_wri\s*=\s*\[([\d,]+)\]')
_RE_IFRAME_SRC = re.compile(r'<iframe[^>]+src="(https?://[^"]+)"', re.IGNORECASE)


def _buffcom_events():
    """Parse buffstreams.com.co/v6's homepage RSC payload for every
    scheduled/live event across every sport, each already carrying its
    full directStreams mirror list — no second fetch needed."""
    ck = 'buffcom_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _sess().get(BUFFCOM_BASE, timeout=12, headers=_HEADERS).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] buffcom events fetch error: %s' % e, xbmc.LOGWARNING)
        return []
    if not html:
        return []

    import json
    chunks = []
    for m in _RE_BUFFCOM_PUSH.finditer(html):
        try:
            chunks.append(json.loads('"' + m.group(1) + '"'))
        except Exception:
            continue
    full_text = ''.join(chunks)

    # Next.js's RSC stream mixes plain JSON objects (the event/stream data
    # we want) in with its own React-element shorthand syntax that ISN'T
    # valid JSON on its own — a single json.loads() over the whole thing
    # doesn't work, so each self-contained `{"_id":"...", ...}` object is
    # located by a brace-balanced scan (respecting quoted strings, so a
    # literal "}" inside a title/URL string doesn't miscount) and parsed
    # individually instead.
    events = []
    marker = '{"_id":"'
    pos = 0
    while True:
        idx = full_text.find(marker, pos)
        if idx == -1:
            break
        depth, i, in_str, esc, end = 0, idx, False, False, None
        while i < len(full_text):
            c = full_text[i]
            if in_str:
                if esc:
                    esc = False
                elif c == '\\':
                    esc = True
                elif c == '"':
                    in_str = False
            else:
                if c == '"':
                    in_str = True
                elif c == '{':
                    depth += 1
                elif c == '}':
                    depth -= 1
                    if depth == 0:
                        end = i + 1
                        break
            i += 1
        if not end:
            break
        pos = end
        try:
            obj = json.loads(full_text[idx:end])
        except Exception:
            continue
        details = obj.get('details') or {}
        t2, t3 = (details.get('text2') or '').strip(), (details.get('text3') or '').strip()
        title = ('%s vs %s' % (t2, t3)).strip() if t2 or t3 else ''
        streams = obj.get('directStreams') or []
        if not title or not streams:
            continue
        events.append({
            'id':      obj.get('_id', ''),
            'title':   title,
            'league':  (obj.get('category') or '').upper(),
            'streams': streams,
        })
    _cache.set(ck, events, 5 * 60)
    xbmc.log('[Starfleet/Sports] buffcom events: %d' % len(events), xbmc.LOGINFO)
    return events


def _buffcom_decrypt(encoded, xor_key, rev_indices):
    """Plain reimplementation of iframe.st's own client-side `_decrypt()` —
    a purely static, deterministic 6-layer string transform (unshuffle,
    XOR, hex-decode, ROT13, reverse, base64) with no randomness or session
    state involved at all; confirmed live it reproduces byte-for-byte the
    same Cloudflare Worker URL the site's own in-browser JS computes. See
    this section's module-level docstring for the full verification
    story."""
    chars = list(encoded)
    unshuffled = [None] * len(chars)
    for i in range(len(chars)):
        unshuffled[rev_indices[i]] = chars[i]
    xor_encoded = ''.join(unshuffled)

    hex_encoded = ''
    for i in range(0, len(xor_encoded), 2):
        hex_encoded += chr(int(xor_encoded[i:i + 2], 16) ^ xor_key)

    rot13_str = ''
    for i in range(0, len(hex_encoded), 2):
        rot13_str += chr(int(hex_encoded[i:i + 2], 16))

    def _rot13(c):
        code = ord(c)
        if c.isalpha():
            base = 90 if c <= 'Z' else 122
            return chr(code + 13) if base >= (code + 13) else chr(code - 13)
        return c
    reversed_str = ''.join(_rot13(c) for c in rot13_str)

    b64 = reversed_str[::-1]
    pad = len(b64) % 4
    if pad:
        b64 += '=' * (4 - pad)
    import base64
    return base64.b64decode(b64).decode('utf-8', errors='replace')


def _buffcom_resolve_decrypt_worker(url, hop=0):
    """Resolve a mirror page that either IS, or is one hop away from, an
    iframe.st-style HLS player (the `_wd/_wk/_wri` decrypt-worker pattern —
    see this section's module docstring). Returns a real, verified-
    playable m3u8 URL (pipe-tagged with Referer, this codebase's existing
    convention) or None. Caps recursion at one nested-iframe hop — the one
    confirmed chain (ovo-goal.st -> iframe.st) is exactly one hop; deeper
    chains aren't chased, to keep this bounded like the rest of this
    file's per-source resolvers."""
    try:
        html = _sess().get(url, timeout=8, headers=_HEADERS).text
    except Exception:
        return None
    if not html:
        return None

    m_wd, m_wk, m_wri = _RE_WORKER_WD.search(html), _RE_WORKER_WK.search(html), _RE_WORKER_WRI.search(html)
    if not (m_wd and m_wk and m_wri):
        if hop >= 1:
            return None
        m_if = _RE_IFRAME_SRC.search(html)
        if not m_if or m_if.group(1) in ('about:blank', url):
            return None
        return _buffcom_resolve_decrypt_worker(m_if.group(1), hop=hop + 1)

    try:
        rev_indices = [int(x) for x in m_wri.group(1).split(',')]
        worker_url = _buffcom_decrypt(m_wd.group(1), int(m_wk.group(1)), rev_indices)
        if not worker_url.startswith('http'):
            return None
        import urllib.parse as _up6
        origin = '%s://%s' % (_up6.urlsplit(url).scheme, _up6.urlsplit(url).netloc)
        r = _sess().get(worker_url, timeout=8, headers=dict(_HEADERS, Origin=origin, Referer=url))
        data = r.json()
        stream = data.get('stream') if data.get('success') else None
        if not stream:
            return None
        check = _sess().get(stream, timeout=8, headers=dict(_HEADERS, Referer=url))
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            return None
        return '%s|Referer=%s' % (stream, _up6.quote(url, safe=''))
    except Exception as e:
        xbmc.log('[Starfleet/Sports] buffcom decrypt-worker resolve error: %s' % e, xbmc.LOGWARNING)
        return None


def _buffcom_try_resolve(link):
    """Same resolve chain as _sportsurge_try_resolve (ResolveURL, then
    embed_resolver's generic iframe follower), plus this source's own
    bespoke decrypt-worker chain as a further fallback for mirrors that
    route through an iframe.st-style player."""
    try:
        from starfleetscrapers import host as _sfhost; resolveurl = _sfhost.module('sf_resolve')
        hmf = resolveurl.HostedMediaFile(link)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                return r
    except ImportError:
        pass
    except Exception:
        pass
    try:
        from starfleetscrapers.core import embed_resolver as embed_resolver
        stream, referer = embed_resolver.resolve_generic_iframe_chain(link)
        if stream:
            if referer:
                import urllib.parse as _up7
                return '%s|Referer=%s' % (stream, _up7.quote(referer, safe=''))
            return stream
    except Exception:
        pass
    return _buffcom_resolve_decrypt_worker(link)


def _buffcom_streams_for_event(event):
    mirrors = event.get('streams') or []
    if not mirrors:
        return []
    # an event carries 40-80 mirrors, most of them dead hosts that each cost a connect timeout; trying them all
    # saturated the whole stream search (the built-in live sites came back empty on a live MLB game)
    mirrors = mirrors[:24]
    streams = []
    # measured: with 8 workers and 9 s, nothing finished while the other sources were busy; the mirrors are network waits, so
    # more of them side by side and a window that fits inside the 16 s the whole search gets (this source starts 2 s in)
    pool = ThreadPoolExecutor(max_workers=min(len(mirrors), 12))
    try:
        futures = {pool.submit(_buffcom_try_resolve, m.get('link', '')): m
                   for m in mirrors if m.get('link')}
        for future in as_completed(futures, timeout=13):
            m = futures[future]
            try:
                resolved = future.result()
            except Exception:
                resolved = None
            if resolved:
                streams.append({
                    'label': m.get('name') or 'BuffStreams', 'url': resolved,
                    'quality': m.get('quality', '') or '', 'language': '',
                    'source': 'BuffStreams',
                })
    except Exception as e:
        xbmc.log('[Starfleet/Sports] buffcom resolve timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)
    return streams


def _buffcom_streams_by_title(event_title):
    evs = _buffcom_events()
    if not evs:
        return []
    best_ev, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_ev = ev
    if not best_ev or best_score < 2:
        return []
    return _buffcom_streams_for_event(best_ev)


# ── DaddyLive (daily multi-sport schedule) ────────────────────────────────────

_DADDYLIVE_BASES = [
    'https://daddylive.eu',
]

_RE_DADDY_EVENT = re.compile(
    r'<a[^>]+href="(/[^"#\s]{4,80})"[^>]*>\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

_DADDY_SPORT_KEYWORDS = {
    'mlb':     ['mlb', 'baseball', 'red sox', 'yankees', 'dodgers', 'cubs', 'mets',
                'braves', 'astros', 'phillies', 'blue jays', 'mariners', 'giants',
                'padres', 'angels', 'tigers', 'twins', 'rays', 'orioles', 'guardians'],
    'nfl':     ['nfl', 'football', 'patriots', 'chiefs', 'bills', 'eagles', 'cowboys'],
    'nba':     ['nba', 'basketball', 'lakers', 'celtics', 'warriors', 'heat', 'bulls'],
    'nhl':     ['nhl', 'hockey', 'bruins', 'rangers', 'leafs', 'canadiens', 'penguins'],
    'soccer':  ['soccer', 'football', 'premier league', 'la liga', 'serie a', 'champions'],
}


def _daddylive_events(sport_slug):
    keywords = _DADDY_SPORT_KEYWORDS.get(sport_slug, [])
    if not keywords:
        return []
    for base in _DADDYLIVE_BASES:
        try:
            html = _sess().get(base + '/schedule.php', timeout=10,
                               headers=dict(_HEADERS, Referer='https://www.google.com/')).text
            events = []
            skip = {'home', 'schedule', 'about', 'contact', 'privacy'}
            for m in _RE_DADDY_EVENT.finditer(html):
                link = m.group(1).strip()
                title = _clean(m.group(2))
                if not title or title.lower() in skip or len(title) < 4:
                    continue
                tl = title.lower()
                if not any(kw in tl for kw in keywords):
                    continue
                full_url = base + link
                events.append({
                    'id': 'daddy_' + re.sub(r'\W+', '_', link),
                    'slug': link.strip('/'),
                    'path': 'daddylive:' + full_url,
                    'title': title, 'datetime': '', 'league': sport_slug.upper(),
                    'logo': '', 'is_live': True, 'start_ts': 0,
                })
            if events:
                xbmc.log('[Starfleet/Sports] DaddyLive %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
                return events
        except Exception as e:
            xbmc.log('[Starfleet/Sports] DaddyLive fetch error (%s): %s' % (base, e), xbmc.LOGWARNING)
    return []


def _daddylive_streams(event_path):
    url = event_path.replace('daddylive:', '')
    base = next((b for b in _DADDYLIVE_BASES if b in url), _DADDYLIVE_BASES[0])
    try:
        html = _sess().get(url, timeout=10,
                           headers=dict(_HEADERS, Referer=base + '/')).text
        streams = _extract_stream_links(html, 'daddylive', 'DaddyLive')
        if not streams:
            # Look for iframe embeds or redirects to player pages
            for m in re.finditer(r'href=["\']([^"\']+channel[^"\']+)["\']', html, re.I):
                chan_url = m.group(1)
                if not chan_url.startswith('http'):
                    chan_url = base + '/' + chan_url.lstrip('/')
                streams.append({'label': 'DaddyLive Channel', 'url': chan_url,
                                'quality': '', 'language': '', 'source': 'DaddyLive'})
        xbmc.log('[Starfleet/Sports] DaddyLive streams: %d' % len(streams), xbmc.LOGINFO)
        return streams
    except Exception as e:
        xbmc.log('[Starfleet/Sports] DaddyLive streams error: %s' % e, xbmc.LOGWARNING)
        return []


def _daddylive_streams_by_title(sport_slug, event_title):
    evs = _daddylive_events(sport_slug)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = ev['path']
    if not best_path or best_score < 2:
        return []
    return _daddylive_streams(best_path)


# NHL24/NFL24/NBA24 (nhl24all.ir/nfl24all.ir/nba24all.ir) are handled by the
# unified _all24_streams_by_title() above, alongside MLB24 — same API family.


# ── onhockey.tv (all hockey leagues) ─────────────────────────────────────────

# In-memory cache for inline stream links scraped from schedule_table.php
_ONHOCKEY_STREAM_CACHE = {}

_RE_ONHOCKEY_TBODY   = re.compile(r"<tbody[^>]*class=['\"]([^'\"]*)['\"][^>]*>(.*?)</tbody>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_LEAGUE  = re.compile(r'<b>([A-Z][A-Z0-9 /\-]{1,20})</b>', re.IGNORECASE)
_RE_ONHOCKEY_GAMEROW = re.compile(r"<tr class='game'[^>]*>(.*?)</tr>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_HOUR    = re.compile(r"class='game_hour'[^>]*>(\d+)</text>:(\d+)", re.IGNORECASE)
_RE_ONHOCKEY_TITLE   = re.compile(r"</td><td>([^<\n]{3,100})", re.IGNORECASE)
_RE_ONHOCKEY_GL      = re.compile(r"class='gamelinks'[^>]*>(.*?)</div>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_CHAN    = re.compile(r"href='np_stream400\.php\?channel=([^'\"&]{5,200})'[^>]*(?:title='([^']*)')?", re.IGNORECASE)
# fr_facebook.php?channel=<page>/videos/<id> — confirmed live 2026-08-16: a
# real currently-live QMJHL Preseason game (Sherbrooke - Victoriaville) only
# offered this one link type, labeled 'fblive' in onhockey.tv's own gamelinks
# div. Its backend (fr_facebook.php) just wraps facebook.com's own official
# video.php embed plugin around the plain URL https://www.facebook.com/
# <channel value>/ — confirmed by fetching it directly and reading the
# rendered <iframe src='//www.facebook.com/plugins/video.php?href=https://
# www.facebook.com/<page>/videos/<id>/live/...'> — so the channel value can
# be turned straight into a real facebook.com/<page>/videos/<id>/ URL and
# handed to ResolveURL, whose bundled Facebook plugin (confirmed present in
# the installed script.module.resolveurl, pattern matches .../videos/<id>)
# resolves it the same generic way _play_stream() already resolves any other
# unrecognized host — no dedicated resolver needed here.
_RE_ONHOCKEY_FB      = re.compile(r"href='fr_facebook\.php\?channel=([^'\"&]{5,200})'[^>]*(?:title='([^']*)')?", re.IGNORECASE)

_RE_ONHOCKEY_JS_M3U8 = re.compile(
    r'(?:src|href|file|source)\s*[:=]\s*["\']?(https?://[^"\'>\s]{15,300}\.m3u8[^"\'>\s]*)',
    re.IGNORECASE
)

_RE_ONHOCKEY_WATCH = re.compile(
    r'<a[^>]+href="(https?://(?!onhockey\.tv)[^"]{10,200})"[^>]*>([^<]*(?:Watch|Stream|Link|HD|Mirror|\d)[^<]*)</a>',
    re.IGNORECASE
)
_RE_ONHOCKEY_NUMBERED = re.compile(
    r'<a[^>]+href="(https?://(?!onhockey\.tv)[^"]{10,200})"[^>]*>\s*(?:(?:Stream|Link|Watch|HD)\s*)?\d+\s*</a>',
    re.IGNORECASE
)

# Several of onhockey.tv's own mirror links (vertex.st, s1.nexa.st, s2.kora.st,
# plain nexa.st, and presumably other siblings) — confirmed live 2026-09-05
# on a real, currently-live Liiga game (IFK Helsinki - HPK) to all be the
# SAME whitelabeled backend platform under different branded frontend
# domains, not independent sites: each one's /ch?id=<N> (or /ch.php?id=<N>)
# page never embeds a stream directly — its own client-side JS instead does
# `fetch("api/player.php?id="+id)` for a JSON `{"url": "<next-hop embed>"}`,
# then sets an iframe's src to it. That next hop varies per mirror (matchli.st,
# forgemindly.com, talentedlost.click all confirmed seen for the exact same
# underlying channel id) but each is a normal page carrying a real m3u8 in
# its own player-init JS, i.e. exactly the shape _RE_ONHOCKEY_JS_M3U8 already
# extracts from every other onhockey.tv stream page — no JS execution
# needed, just two extra plain requests. Without this, every one of these
# mirrors was being handed to the player as its bare, non-playable /ch?id=
# page — confirmed live end-to-end with a real signed m3u8 (HTTP 200, real
# #EXTM3U/segment listing) reachable this way for the same Liiga game.
_RE_ONHOCKEY_CHFAMILY = re.compile(r'^https?://([\w.-]+)/ch(?:\.php)?\?id=(\d+)', re.IGNORECASE)


def _onhockey_resolve_chfamily(channel_url, timeout_s=8):
    """Resolve one vertex.st/nexa.st/kora.st-family mirror link to a real
    playable stream — see the _RE_ONHOCKEY_CHFAMILY comment above for the
    two-hop mechanism. Returns None (unchanged by caller) for any link that
    isn't this family or that fails to resolve, same graceful-degradation
    behavior as every other stream candidate in this file."""
    m = _RE_ONHOCKEY_CHFAMILY.match(channel_url)
    if not m:
        return None
    host, chan_id = m.group(1), m.group(2)
    try:
        api_url = 'https://%s/api/player.php?id=%s' % (host, chan_id)
        data = _sess().get(api_url, timeout=timeout_s,
                           headers=dict(_HEADERS, Referer=channel_url)).json()
        next_hop = data.get('url')
        if not next_hop:
            return None
    except Exception:
        return None
    try:
        html2 = _sess().get(next_hop, timeout=timeout_s,
                            headers=dict(_HEADERS, Referer=channel_url)).text
    except Exception:
        return None
    m2 = _RE_ONHOCKEY_JS_M3U8.search(html2)
    # matchli.st (one of the confirmed next-hop embeds — see this function's
    # own docstring) is a Clappr player whose config is real, quoted JSON
    # (window.PP_CLAPPR_CONFIG={"srcBase":"...","src":"https://...m3u8",...})
    # rather than the bare JS-variable shape (src: "...") _RE_ONHOCKEY_JS_M3U8
    # was written for — confirmed live this quoted-key shape never matches
    # that regex at all (the closing quote sits directly between the key and
    # the colon, which \s*[:=] doesn't allow for). Scoped locally to this
    # function rather than broadening the shared regex, since that one is
    # already relied on elsewhere in this file for the JS-variable shape.
    if not m2:
        m2 = re.search(r'"src"\s*:\s*"(https?://[^"]+\.m3u8[^"]*)"', html2, re.IGNORECASE)
    if m2:
        su = m2.group(1).strip().replace('\\u0026', '&').replace('\\/', '/')
        import urllib.parse as _up_chf
        return su + '|Referer=%s' % _up_chf.quote(next_hop, safe='')
    m3 = _RE_IFRAME_SRC.search(html2)
    if m3:
        return m3.group(1).strip()
    return None


# onhockey.tv's own inline "channel" links for Brightcove-hosted games
# (confirmed live: its NHL Rookie Camp coverage) point straight at the
# bare embed PAGE (players.brightcove.net/<account>/<player>/index.html?
# videoId=<id>) — real HTML, not a stream, so ffmpeg can't demux it
# directly (confirmed live via kodi.log: "CDVDDemuxFFmpeg::Open - error
# probing input format" against exactly this URL shape). The embedded
# account id, 6415718365001, is confirmed to be the SAME Brightcove
# account replay_sources.py's own _nhl_resolve_video() already resolves
# successfully for NHL.com's condensed games via Brightcove's standard
# Playback API — reused directly below rather than re-implementing an
# identical resolver for the same account.
_RE_ONHOCKEY_BRIGHTCOVE = re.compile(
    r'players\.brightcove\.net/(\d+)/[^/]+/index\.html\?videoId=(\d+)', re.IGNORECASE)


def _onhockey_resolve_brightcove(video_id):
    """video_id here is already just the numeric Brightcove video id
    (extracted by the caller via _RE_ONHOCKEY_BRIGHTCOVE) — resolves via
    replay_sources._nhl_resolve_video(), which itself already caches (15
    min) and fails gracefully (returns None) on anything not resolvable,
    same convention as _onhockey_resolve_chfamily above."""
    try:
        from starfleetscrapers.sports import replay_sources as _rs
        return _rs._nhl_resolve_video(video_id)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] onhockey.tv brightcove resolve error (%s): %s' % (video_id, e),
                 xbmc.LOGWARNING)
        return None


_ONHOCKEY_LEAGUE_KEYWORDS = [
    ('AHL',   ('ahl',)),
    ('KHL',   ('khl',)),
    ('OHL',   ('ohl',)),
    ('WHL',   ('whl',)),
    ('QMJHL', ('qmjhl', 'lhjmq')),
    ('ECHL',  ('echl',)),
    ('SHL',   ('shl',)),
    ('DEL',   ('del ',)),
    ('NCAA',  ('ncaa', 'college hockey', 'university')),
    ('IIHF',  ('iihf', 'world championship', 'world cup of hockey')),
    ('PHF',   ('phf', 'premier hockey')),
    ('PWHL',  ('pwhl',)),
    ('NWHL',  ('nwhl',)),
]


def _onhockey_league(title):
    """Detect hockey league from event title; defaults to NHL."""
    t = title.lower()
    for league, keywords in _ONHOCKEY_LEAGUE_KEYWORDS:
        if any(k in t for k in keywords):
            return league
    return 'NHL'


@_cache.coalesced
def _onhockey_events():
    """Scrape onhockey.tv schedule via schedule_table.php (AJAX endpoint).
    Parses tbody/game-row structure, caches inline stream links per event.
    """
    import datetime as _dt
    import calendar as _cal

    global _ONHOCKEY_STREAM_CACHE

    try:
        r = _sess().get(
            ONHOCKEY_BASE + '/schedule_table.php',
            timeout=12,
            headers=dict(_HEADERS,
                         Referer=ONHOCKEY_BASE + '/',
                         **{'X-Requested-With': 'XMLHttpRequest'}),
        )
        r.raise_for_status()
        html = r.text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] onhockey.tv schedule error: %s' % e, xbmc.LOGWARNING)
        return []

    events = []
    _ONHOCKEY_STREAM_CACHE = {}
    current_league = 'NHL'
    # Default to today UTC; updated when we hit a Date row
    _now_utc = _dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None)
    current_date = _now_utc.date()
    current_year = _now_utc.year
    date_seen = False                    # the page has no date headers at the moment: see the day choice below

    for tbody_m in _RE_ONHOCKEY_TBODY.finditer(html):
        tbody_class = tbody_m.group(1)
        tbody_html  = tbody_m.group(2)

        if 'Date' in tbody_class:
            # Parse date like "<b>July 3</b>"
            dm = re.search(r'<b>(\w+ \d+)</b>', tbody_html)
            if dm:
                try:
                    current_date = _strp(
                        '%s %d' % (dm.group(1), current_year), '%B %d %Y'
                    ).date()
                    date_seen = True
                except Exception:
                    pass
            continue

        # League name from the bold header in this tbody
        lhdr = _RE_ONHOCKEY_LEAGUE.search(tbody_html)
        if lhdr:
            current_league = lhdr.group(1).strip()

        for game_m in _RE_ONHOCKEY_GAMEROW.finditer(tbody_html):
            row_html = game_m.group(1)

            title_m = _RE_ONHOCKEY_TITLE.search(row_html)
            if not title_m:
                continue
            title = title_m.group(1).strip()
            if not title or len(title) < 3:
                continue
            # Skip TV channel names (e.g. "NHL Network", "ESPN+") — not actual games.
            # ' - ' (plain hyphen) is a real separator too, not just 'vs'/'at'/'@'/'v'
            # — confirmed live 2026-08-16: onhockey.tv's own European/junior-league
            # rows (e.g. "Sherbrooke - Victoriaville", a real currently-live QMJHL
            # Preseason game) use a bare hyphen, and were being silently dropped
            # here entirely before ever reaching the link-parsing step below.
            _tl = title.lower()
            if not any(sep in _tl for sep in (' vs ', ' at ', ' @ ', ' v ', ' - ')):
                continue

            hour_m = _RE_ONHOCKEY_HOUR.search(row_html)
            start_ts = 0
            date_label = ''
            ev_day = current_date
            if hour_m:
                try:
                    hh = int(hour_m.group(1))
                    mm = int(hour_m.group(2))
                    if not date_seen:
                        # No date header: the hours are UTC and the table runs from a few hours back to about a day ahead, so the day is the one
                        # that puts the game inside that window. After 7 PM Eastern it is already tomorrow in UTC, and a game at 23:00 UTC belongs
                        # to the day before: with today's date it was filed as "tomorrow" and a game in progress showed as upcoming.
                        _now = time.time()
                        for off in (-1, 0, 1):
                            _d = current_date + _dt.timedelta(days=off)
                            _t = int(_cal.timegm(_dt.datetime(_d.year, _d.month, _d.day, hh, mm, 0).timetuple()))
                            if _now - 5 * 3600 <= _t < _now + 19 * 3600:
                                ev_day = _d
                                break
                    dt_utc = _dt.datetime(
                        ev_day.year, ev_day.month, ev_day.day, hh, mm, 0
                    )
                    start_ts = int(_cal.timegm(dt_utc.timetuple()))
                    # Human date label e.g. "Jul 3"
                    date_label = ev_day.strftime('%b %-d') if hasattr(ev_day, 'strftime') else str(ev_day)
                except Exception:
                    pass

            # Extract inline stream links from gamelinks div
            links = []
            gl_m = _RE_ONHOCKEY_GL.search(row_html)
            if gl_m:
                for lm in _RE_ONHOCKEY_CHAN.finditer(gl_m.group(1)):
                    chan = lm.group(1).strip()
                    if chan.startswith('//'):
                        chan = 'https:' + chan
                    elif not chan.startswith('http'):
                        chan = ONHOCKEY_BASE + '/' + chan.lstrip('/')
                    lbl = lm.group(2) or title
                    links.append({
                        'label': '[OnHockey] %s' % lbl,
                        'url': chan,
                        'quality': '', 'language': '', 'source': 'OnHockey.tv',
                    })
                for lm in _RE_ONHOCKEY_FB.finditer(gl_m.group(1)):
                    fb_chan = lm.group(1).strip()
                    fb_url = 'https://www.facebook.com/' + fb_chan.lstrip('/')
                    lbl = lm.group(2) or title
                    links.append({
                        'label': '[OnHockey] %s (Facebook Live)' % lbl,
                        'url': fb_url,
                        'quality': '', 'language': '', 'source': 'OnHockey.tv',
                    })

            ev_id = 'onhockey_%s_%s_%s' % (
                re.sub(r'\W+', '_', current_league.lower()),
                str(ev_day),
                re.sub(r'\W+', '_', title.lower())[:50],
            )

            if links:
                _ONHOCKEY_STREAM_CACHE[ev_id] = links

            # onhockey.tv's schedule HTML ships team/league names entity-
            # encoded (confirmed live: "K&#228;rp&#228;t", "Kitzb&#252;hel"), and
            # they were being shown to the user verbatim. Unescaped only for
            # display — ev_id above is deliberately built from the raw
            # title so it stays stable/ASCII-safe inside plugin:// URLs.
            import html as _html_mod
            events.append({
                'id':         ev_id,
                'slug':       ev_id,
                'path':       'onhockey:' + ev_id,
                'title':      _html_mod.unescape(title),
                'date_label': date_label,
                'league':     _html_mod.unescape(current_league),
                'logo':       '',
                'is_live':    bool(links),
                'start_ts':   start_ts,
            })

    xbmc.log('[Starfleet/Sports] onhockey.tv: %d events across %d leagues' % (
        len(events), len(set(e['league'] for e in events))), xbmc.LOGINFO)
    return events


# Hosts OnHockey still lists whose pages only produce a stream by running their own
# JavaScript (embedsports.me, the apl504 player) or answer 403 without a token minted by
# a parent page (hls.hockey.do) - checked 2026-10-02, no resolver in this addon can open
# them, and offering them just adds links that fail.
_ONHOCKEY_UNPLAYABLE_HOSTS = ('emb.apl504.me/', 'hls.hockey.do/secure_hls.php',
                              # player pages that never gave a playlist (login needed, or the host is gone)
                              'wideiptv.top/', 'cdnlivetv.is/', 'streamfree.top/', 'videocdn-')

_RE_ONHOCKEY_MATCHORA = re.compile(r'https?://(?:www\.)?matchora\.to/embed/(?:match|channel)/\d+', re.I)
_RE_MATCHORA_CH = re.compile(r'var\s+CH\s*=\s*"(\d+)"')
_RE_MATCHORA_FX = re.compile(r'FX\s*=\s*"(\d*)"')


def _onhockey_resolve_matchora(embed_url):
    """OnHockey's current players are matchora.to embed PAGES (an ad-laden HTML
    player), which Kodi cannot open - listed as a stream, they simply failed.
    The page's own script asks GET /api/play/<channel>?fx=<fixture> for
    {"ready", "reason", "url", "expires_in"}; "url" is an edge playlist
    (edge.matchora.pro/hls/<channel>/index.m3u8?t=<signed token>) that answers 200
    once the channel is running and 404 "warming" otherwise. Measured 2026-10-02 over
    52 links for 40 events: 14 playable (live European/NCAA games), the rest were
    "limit"/"capacity" (their server's viewer cap) or "dead" (no source) - those are
    dropped instead of offered. Returns 'playlist|Referer=..&User-Agent=..' or None."""
    from urllib.parse import quote as _q
    try:
        ua = _HEADERS.get('User-Agent', 'Mozilla/5.0')
        sess = _sess()
        page = sess.get(embed_url, timeout=8, headers=dict(_HEADERS, Referer=ONHOCKEY_BASE + '/')).text
        ch = _RE_MATCHORA_CH.search(page)
        if not ch:
            return None
        fx = _RE_MATCHORA_FX.search(page)
        api = 'https://matchora.to/api/play/%s%s' % (ch.group(1), ('?fx=' + fx.group(1)) if fx and fx.group(1) else '')
        d = sess.get(api, timeout=8, headers=dict(_HEADERS, Referer=embed_url)).json()
        url = d.get('url') or ''
        if not url or d.get('reason') in ('dead',):
            return None
        pl = sess.get(url, timeout=8, headers=dict(_HEADERS, Referer='https://matchora.to/'))
        if pl.status_code != 200 or '#EXTM3U' not in pl.text[:200]:
            return None
        return '%s|Referer=%s&User-Agent=%s' % (url, _q('https://matchora.to/', safe=''), _q(ua, safe=''))
    except Exception as e:
        xbmc.log('[Starfleet/Sports] matchora resolve error: %s' % e, xbmc.LOGINFO)
        return None



def _onhockey_resolve_special_links(links):
    """Resolve any vertex.st/nexa.st/kora.st-family links (see
    _onhockey_resolve_chfamily's own docstring) and any Brightcove embed-
    page links (see _onhockey_resolve_brightcove's own docstring) in a
    stream-link list to their real playable m3u8, before handing anything
    to the player. Done here (play time), not while building the
    schedule, so listing every event stays fast; only the handful of
    candidates for the ONE event a user actually opened pay this cost,
    resolved concurrently since a single event can carry several at once.

    Real bug fixed 2026-09-13: this used to live inline inside
    _onhockey_streams()'s FIRST cache-hit branch only — its own SECOND
    cache-hit branch (the "populate then retry" fallback a few lines down,
    for the also-real-and-separate bug where the in-memory cache is empty
    in a fresh process) returned the raw cached list directly with no
    resolution step at all, confirmed live via kodi.log: the exact same
    "CDVDDemuxFFmpeg::Open - error probing input format" against a raw
    players.brightcove.net URL kept happening even after that first fix
    shipped, because real users always hit the SECOND branch (a first-ever
    cache population), never the first (which only helps a second play
    attempt within the same process). Extracted into its own function so
    both branches genuinely share one code path instead of two
    similar-looking ones silently drifting apart again."""
    chfamily_idx = [i for i, s in enumerate(links)
                    if _RE_ONHOCKEY_CHFAMILY.match(s.get('url', ''))]
    brightcove_idx = [i for i, s in enumerate(links)
                      if _RE_ONHOCKEY_BRIGHTCOVE.search(s.get('url', ''))]
    matchora_idx = [i for i, s in enumerate(links)
                    if _RE_ONHOCKEY_MATCHORA.match(s.get('url', ''))]
    if not chfamily_idx and not brightcove_idx and not matchora_idx:
        return [s for s in links if not any(h in s.get('url', '') for h in _ONHOCKEY_UNPLAYABLE_HOSTS)]
    from concurrent.futures import ThreadPoolExecutor as _Pool
    resolved = list(links)
    with _Pool(max_workers=max(len(chfamily_idx) + len(brightcove_idx) + len(matchora_idx), 1)) as pool:
        futs = {}
        for i in matchora_idx:
            futs[pool.submit(_onhockey_resolve_matchora, links[i]['url'])] = i
        for i in chfamily_idx:
            futs[pool.submit(_onhockey_resolve_chfamily, links[i]['url'])] = i
        for i in brightcove_idx:
            m = _RE_ONHOCKEY_BRIGHTCOVE.search(links[i]['url'])
            futs[pool.submit(_onhockey_resolve_brightcove, m.group(2))] = i
        for fut in futs:
            i = futs[fut]
            try:
                real_url = fut.result(timeout=10)
            except Exception:
                real_url = None
            if real_url:
                resolved[i] = dict(resolved[i], url=real_url)
    # Drop any Brightcove entry that failed to resolve — the raw embed
    # page it'd otherwise still point to was never directly playable.
    return [s for s in resolved
            if not _RE_ONHOCKEY_BRIGHTCOVE.search(s.get('url', ''))
            and not _RE_ONHOCKEY_MATCHORA.match(s.get('url', ''))
            and not any(h in s.get('url', '') for h in _ONHOCKEY_UNPLAYABLE_HOSTS)]


def _onhockey_streams(event_path):
    """Return stream links for an onhockey.tv event.
    Checks the in-memory stream cache first (populated by _onhockey_events()).
    Falls back to fetching the game page URL if the path is a full URL.
    """
    ev_id = event_path.replace('onhockey:', '')

    # Try in-memory cache (schedule_table.php inline links)
    cached = _ONHOCKEY_STREAM_CACHE.get(ev_id)
    if cached:
        cached = _onhockey_resolve_special_links(cached)
        xbmc.log('[Starfleet/Sports] onhockey.tv cached streams for %s: %d' % (ev_id, len(cached)), xbmc.LOGINFO)
        return cached

    # Real bug fixed 2026-09-13, per a direct live report: _ONHOCKEY_STREAM_
    # CACHE is a plain module-level dict, populated only as a side effect of
    # _onhockey_events() actually running — fine within ONE process, but
    # Kodi's own sports_event_play action (triggered via a fresh
    # plugin://...&action=sports_event_play URL handed to xbmc.Player().
    # play()) runs as a SEPARATE python invocation from whatever earlier
    # call listed the event, so this cache is reliably empty every single
    # time a user actually presses play — confirmed live via kodi.log
    # ("onhockey.tv no streams cached for <id>" on literally every real
    # attempt traced). The old fallback below only ever handled a
    # different, no-longer-used id shape (a bare URL) — current ev_ids are
    # always the synthetic 'onhockey_<league>_<date>_<title>' string
    # _onhockey_events() builds, which never starts with "http", so that
    # fallback was unreachable dead code for every real event. Re-running
    # _onhockey_events() here repopulates the exact same cache (same
    # deterministic id format, so a fresh scrape's ids line up with the
    # one being looked up here as long as the site's own listing hasn't
    # changed in the few seconds between listing and play — the normal
    # case) and this function's own return path above then finds it on
    # retry, instead of giving up outright.
    if not ev_id.startswith('http'):
        _onhockey_events()
        cached = _ONHOCKEY_STREAM_CACHE.get(ev_id)
        if cached:
            cached = _onhockey_resolve_special_links(cached)
            xbmc.log('[Starfleet/Sports] onhockey.tv streams for %s found after cache refresh: %d'
                     % (ev_id, len(cached)), xbmc.LOGINFO)
            return cached
        xbmc.log('[Starfleet/Sports] onhockey.tv no streams cached for %s (even after refresh)' % ev_id,
                 xbmc.LOGINFO)
        return []

    try:
        html = _sess().get(ev_id, timeout=12,
                           headers=dict(_HEADERS, Referer=ONHOCKEY_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] onhockey.tv stream page error (%s): %s' % (ev_id, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen_urls = set()

    # Live/channel pages (e.g. index.php?place=daddylive&channel=NNN) don't list
    # plain <a> stream links like game pages do - the player embeds the .m3u8
    # directly in a JS player config (src/file/source: "...m3u8"). Check this
    # first since it's the primary pattern for this page type.
    m = _RE_ONHOCKEY_JS_M3U8.search(html)
    if m:
        su = m.group(1).strip()
        streams.append({'label': 'OnHockey Live Stream', 'url': su,
                        'quality': 'HLS', 'language': '', 'source': 'OnHockey.tv'})
        seen_urls.add(su)

    for m in _RE_ONHOCKEY_WATCH.finditer(html):
        su    = m.group(1).strip()
        label = _clean(m.group(2)) or 'OnHockey Stream'
        if su and su not in seen_urls:
            streams.append({'label': label, 'url': su,
                            'quality': '', 'language': '', 'source': 'OnHockey.tv'})
            seen_urls.add(su)

    for m in _RE_ONHOCKEY_NUMBERED.finditer(html):
        su = m.group(1).strip()
        if su and su not in seen_urls:
            streams.append({'label': 'OnHockey Stream', 'url': su,
                            'quality': '', 'language': '', 'source': 'OnHockey.tv'})
            seen_urls.add(su)

    if not streams:
        streams = _extract_stream_links(html, 'onhockey.tv', 'OnHockey.tv')

    # Last resort: the player embed may be proxied through onhockey.tv's own
    # domain (e.g. an internal /player.php iframe), which _extract_stream_links
    # deliberately skips since it excludes same-domain iframes. Follow one hop
    # through any same-domain iframe to reach the actual (usually external)
    # player, then look for an m3u8 or external iframe/link there.
    if not streams:
        for im in _RE_IFRAME_SRC.finditer(html):
            isrc = im.group(1).strip()
            if not isrc or isrc == ev_id or 'onhockey.tv' not in isrc:
                continue
            try:
                inner_html = _sess().get(isrc, timeout=10,
                                         headers=dict(_HEADERS, Referer=ev_id)).text
            except Exception:
                continue
            im2 = _RE_ONHOCKEY_JS_M3U8.search(inner_html)
            if im2:
                streams.append({'label': 'OnHockey Live Stream', 'url': im2.group(1).strip(),
                                'quality': 'HLS', 'language': '', 'source': 'OnHockey.tv'})
                break
            streams = _extract_stream_links(inner_html, 'onhockey.tv', 'OnHockey.tv')
            if streams:
                break

    xbmc.log('[Starfleet/Sports] onhockey.tv streams for %s: %d' % (ev_id, len(streams)), xbmc.LOGINFO)
    return streams


def _onhockey_prune(links, budget=5.0):
    """OnHockey lists 20-35 links per game. About half answer with an empty playlist (feed not on air) and many are
    player pages that lead nowhere (dead hosts, channels that need a login). Check them side by side and keep the
    playlists that really list segments plus the player pages that resolve to one; each address appears once."""
    from starfleetscrapers.sports import sports_starfleet_live as _sl_oh
    if len(links) < 2:
        return links

    def work(item):
        url = item.get('url', '')
        base = url.split('|', 1)[0]
        if '.m3u8' in base.lower():
            return url if _has_segments(url, timeout=5) else None
        try:
            out = _sl_oh.resolve_link(base)
            if out:
                return _remint_wrap(out, base)
            from starfleetscrapers.core import embed_resolver as _er
            st, ref = _er.resolve_generic_iframe_chain(base)
            if st:
                out = '%s|Referer=%s' % (st, ref) if ref else st
            return out
        except Exception:
            return None

    ex = ThreadPoolExecutor(max_workers=min(len(links), 14))
    futs = [ex.submit(work, it) for it in links]
    ex.shutdown(wait=False)
    end = time.time() + budget
    out, seen = [], set()
    for it, fut in zip(links, futs):
        try:
            url = fut.result(timeout=max(0.05, end - time.time()))
        except Exception:
            url = None
        if url and url.split('|', 1)[0] not in seen:
            seen.add(url.split('|', 1)[0])
            out.append(dict(it, url=url))
    return out


def _onhockey_streams_by_title(event_title):
    """Cross-reference: find onhockey.tv game by title match and scrape its streams."""
    evs = _onhockey_events()
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _onhockey_prune(_onhockey_streams(best_path))


# ── DaddyLive.mov 24/7 channels (NHL Network, etc.) ───────────────────────────
#
# NOTE: named "dlchan" (not "daddylive") to avoid colliding with the separate,
# pre-existing daddylive.eu multi-sport event scraper above (_daddylive_events/
# _daddylive_streams) — that one produces 'daddylive:' event paths; this one
# uses 'dlchan:' for the unrelated daddylive.mov 24/7-channel chain.
#
# Chain: daddylive.mov's per-channel page (/live/stream=Channel+Name) embeds a
# static JSON list of mirror URLs for that channel — the #video-player iframe
# itself is populated client-side by JS and is NOT usable from a plain fetch,
# but the underlying mirror-URL list is present in the raw HTML regardless.
# One mirror tier (logic.icelanders.st-style hosts) further obfuscates its own
# inline <script> with a simple XOR/subtract cipher hiding a signed,
# short-lived .m3u8 URL — decode it locally instead of needing a real browser.
# The signed URL expires (embedded unix ts a few hours out), so this must be
# re-resolved on every play — never cache the final .m3u8 long-term.

DLCHAN_BASE = 'https://daddylive.mov'

# Obfuscated blob: var _xx=[n,n,...],_yy=KEY,_zz=SUB, ... window["ev"+"al"](...)
_RE_DLCHAN_XOR_BLOB = re.compile(
    r'var\s+_[a-zA-Z0-9]+\s*=\s*\[([\d,\s]+)\]\s*,\s*_[a-zA-Z0-9]+\s*=\s*(\d+)\s*,\s*_[a-zA-Z0-9]+\s*=\s*(\d+)'
)

_RE_DLCHAN_SIGNED_M3U8 = re.compile(r'SIGNED_URL\s*=\s*"(https?://[^"]+?\.m3u8[^"]*)"')
_RE_DLCHAN_ANY_M3U8    = re.compile(r'https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*')


def _decode_dlchan_xor_blob(html):
    """Decode the site's obfuscated inline script: an int array XORed with a
    key then offset-subtracted (mod 256). Returns decoded JS text, or '' if
    the pattern isn't present (site may have changed the cipher again)."""
    m = _RE_DLCHAN_XOR_BLOB.search(html)
    if not m:
        return ''
    try:
        arr = [int(x) for x in m.group(1).replace(' ', '').split(',') if x]
        key = int(m.group(2))
        sub = int(m.group(3))
        return ''.join(chr(((c ^ key) - sub + 256) % 256) for c in arr)
    except Exception:
        return ''


_RE_DLCHAN_B64_DECODE_FN = re.compile(
    r'function\s+(\w+)\(\w+\)\s*\{\s*\w+\s*=\s*\w+\.replace\(/-/g,\s*[\'"]\+[\'"]\)'
    r'\.replace\(/_/g,\s*[\'"]/[\'"]\)', re.IGNORECASE
)


def _b64url_decode(s):
    import base64 as _b64
    s = s.replace('-', '+').replace('_', '/')
    s += '=' * (-len(s) % 4)
    return _b64.b64decode(s).decode('utf-8', errors='ignore')


def _decode_dlchan_fragment_concat(html):
    """Some mirror hosts (e.g. cdnlivetv.tv, first seen on the MLB Network
    mirror) don't use the single XOR-blob obfuscation _decode_dlchan_xor_blob
    handles — instead the stream URL is split into many small pieces, each
    independently base64-url-safe-encoded into its own var, then assembled
    via a decode-and-concatenate expression: var url=fn(v1)+fn(v2)+...+fn(vN).
    Since the real URL never appears as plaintext anywhere in the page, the
    plain-text .m3u8 regex search can never find it — this must be decoded
    piece by piece instead. Returns the assembled URL, or '' if not present."""
    fn_m = _RE_DLCHAN_B64_DECODE_FN.search(html)
    if not fn_m:
        return ''
    fn_name = fn_m.group(1)

    assembly_m = re.search(
        r'=\s*((?:%s\(\w+\)\s*\+\s*)+%s\(\w+\))\s*;' % (re.escape(fn_name), re.escape(fn_name)),
        html
    )
    if not assembly_m:
        return ''

    var_names = re.findall(r'%s\((\w+)\)' % re.escape(fn_name), assembly_m.group(1))
    if not var_names:
        return ''

    parts = []
    for vn in var_names:
        vm = re.search(r'\b%s\s*=\s*[\'"]([^\'"]+)[\'"]' % re.escape(vn), html)
        if not vm:
            return ''  # one missing fragment means we can't trust the reconstruction
        try:
            parts.append(_b64url_decode(vm.group(1)))
        except Exception:
            return ''

    url = ''.join(parts)
    return url if url.startswith('http') else ''


_TVNOW_STREAM_API = 'https://chat.cfbu247.sbs/api/resolve-dlstream/%s'
_RE_TVNOW_EMBED_SLUG = re.compile(r'tvnow247\.top/embed/([^/?#"\']+)', re.IGNORECASE)


def _tvnow_api_resolve_mirror(mirror_url):
    """Some daddylive.mov mirrors point straight back at tvnow247.top's own
    /embed/<slug> page — which is a client-rendered SPA with nothing usable
    in its static HTML (its player only gets a stream after a JS bundle
    calls out to an API). That API is a plain JSON endpoint, discovered via
    live network inspection of tvnow247.top/assets/streamService-*.js:
    GET https://chat.cfbu247.sbs/api/resolve-dlstream/<numeric channel_id>
    -> {"m3u8" or "proxyPlaylistUrl": "..."}. Far more reliable than trying
    to scrape the SPA shell itself. Returns None if this isn't a tvnow247
    embed mirror, or the channel has no live upstream right now."""
    sm = _RE_TVNOW_EMBED_SLUG.search(mirror_url)
    if not sm:
        return None
    slug = sm.group(1)
    try:
        from starfleetscrapers.live import live_sources as _ls
        channel_id = next(
            (c['id'] for c in _ls.get_tvnow_channels() if c.get('slug') == slug), None)
    except Exception:
        channel_id = None
    if not channel_id:
        return None
    from starfleetscrapers.core import dns_fallback as _dnsf
    try:
        # chat.cfbu247.sbs fails to resolve on some local/ISP DNS resolvers
        # even though it's live (confirmed via a public DNS resolver) —
        # _dnsf.get transparently retries via DNS-over-HTTPS on a local
        # resolution failure instead of just giving up.
        r = _dnsf.get(_TVNOW_STREAM_API % channel_id, timeout=6, headers=_HEADERS)
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tvnow stream API error (%s): %s' % (channel_id, e), xbmc.LOGWARNING)
        return None
    playlist_url = data.get('proxyPlaylistUrl') or data.get('m3u8')
    if not playlist_url:
        return None
    # The API happily returns a token even for a channel with no live upstream
    # right now (chunk.tvdaily.xyz then 502s on it) — verify it actually
    # serves before handing it to the player, same reasoning as the mirror
    # fallback fix below: better to report "no stream" than a guaranteed crash.
    try:
        check = _dnsf.get(playlist_url, timeout=6, headers=_HEADERS)
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            return None
    except Exception:
        return None
    return playlist_url


def _dlchan_resolve_mirror(mirror_url):
    """Turn one mirror-tier URL into a playable stream URL, or None.
    Handles the XOR-obfuscated JWPlayer embed pattern; falls back to a plain
    .m3u8 search for simpler mirror hosts."""
    tvnow_resolved = _tvnow_api_resolve_mirror(mirror_url)
    if tvnow_resolved:
        return tvnow_resolved

    try:
        # Referer derived from the mirror's own origin (same-origin is a
        # safe, generic default for an embed page) rather than a fixed
        # daddylive.mov value — that domain is now dead, and this function's
        # only remaining caller (_tim_streams_by_title, timstreams.st) is an
        # unrelated site this decoder just happens to also work against
        # (same XOR-cipher player-init pattern, confirmed live byte-for-byte
        # identical — see this module's own comment above _tim_events()).
        import urllib.parse as _up_ref
        _mp = _up_ref.urlparse(mirror_url)
        mirror_origin = '%s://%s/' % (_mp.scheme, _mp.netloc) if _mp.scheme and _mp.netloc else mirror_url
        html = _sess().get(mirror_url, timeout=6, headers=dict(
            _HEADERS, Referer=mirror_origin)).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] dlchan mirror error (%s): %s' % (mirror_url, e), xbmc.LOGWARNING)
        return None

    decoded = _decode_dlchan_xor_blob(html)
    sm = _RE_DLCHAN_SIGNED_M3U8.search(decoded)
    candidate = sm.group(1) if sm else None
    if not candidate:
        sm2 = _RE_DLCHAN_ANY_M3U8.search(html)
        candidate = sm2.group(0) if sm2 else None
    if not candidate:
        # Neither the XOR blob nor a plaintext .m3u8 was present — try the
        # fragment-concatenation pattern (confirmed live on cdnlivetv.tv).
        candidate = _decode_dlchan_fragment_concat(html) or None
    if not candidate:
        return None

    # The signed CDN (fiveo4.casadenoval.uk and siblings) started rejecting
    # plain requests with a bare 403 even with a correct Referer and matching
    # signed token/timestamp — confirmed live that this isn't expiry or a
    # cookie/session requirement, it's the absence of the Sec-Fetch-*
    # "fetch metadata" headers a real browser always sends and curl/requests
    # never do by default. Adding them is enough; no TLS-fingerprint wall
    # like Cloudflare Turnstile. Verify with them before accepting the
    # mirror, and carry them along on the URL Kodi's player actually opens
    # (its own HTTP client won't send them either otherwise) via the same
    # 'url|Header=value&Header2=value' pipe-syntax used elsewhere in this
    # file for Referer/User-Agent.
    verify_headers = dict(
        _HEADERS,
        Referer=mirror_url,
        **{
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
        }
    )
    try:
        check = _sess().get(candidate, timeout=6, headers=verify_headers)
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            xbmc.log('[Starfleet/Sports] dlchan candidate failed verify (%s): HTTP %s' %
                      (mirror_url, check.status_code), xbmc.LOGWARNING)
            return None
    except Exception as e:
        xbmc.log('[Starfleet/Sports] dlchan candidate verify error (%s): %s' % (mirror_url, e), xbmc.LOGWARNING)
        return None

    import urllib.parse as _up3
    return '%s|Referer=%s&Sec-Fetch-Dest=empty&Sec-Fetch-Mode=cors&Sec-Fetch-Site=cross-site' % (
        candidate, _up3.quote(mirror_url, safe='')
    )


_RE_DLCHAN_TITLE = re.compile(r'<title>\s*([^<]+?)\s*</title>', re.IGNORECASE)
_RE_DLCHAN_TITLE_SUFFIX = re.compile(
    r'\s+(?:Live\s+Stream\s+(?:Online\s+)?Free|Watch\s+Live\s+Online\s+Free|'
    r'Live\s+TV\s+Watch\s+Free|Live\s+Stream\s+Online|Online\s+Live|'
    r'Live\s+Stream|Live\s+TV|Live).*$', re.IGNORECASE
)
_RE_DLCHAN_TITLE_PREFIX = re.compile(r'^(?:Free|Watch)\s+', re.IGNORECASE)


def _dlchan_stream_url(channel_id, channel_name=None):
    """Resolve a DaddyLive/DLHD 24/7 channel id (e.g. 'NHL-Network', or a
    bare numeric id like '399') to a live stream URL. Not cacheable
    long-term — signed mirror URLs are short-lived.

    Rewritten 2026-08-24: daddylive.mov itself is dead (confirmed live —
    DNS/connection failure, not just a dead page), and this whole function
    used to scrape ITS OWN /live/stream=<name> page for a JSON mirror list,
    decoding one of several obfuscation layers (XOR blob, base64-fragment
    concat) to reach a signed .m3u8. That entire mechanism is gone along
    with the domain. DaddyLive/DLHD's current mirror, dlstreams.st (see
    live_sources.py's own get_dlstreams_channels()/resolve_dlstreams_channel()
    for the full site background), preserves the SAME channel_id numbering
    scheme daddylive.mov always used — confirmed live: id 663 is "NHL
    Network USA" there too, same as this file's own pre-existing comments
    already documented for the old domain — and resolves through a much
    simpler mechanism (a plain base64-encoded m3u8 URL, no XOR/fragment
    decoding needed at all). So this now just maps whatever id/name this
    function already receives onto dlstreams.st's own numeric id and
    delegates to that resolver, instead of reimplementing a second parallel
    channel directory here.

    channel_name: same purpose as before — pass this explicitly whenever
    the caller already knows the real display name (e.g. from
    tvnow247.top's own channel/schedule data), used here to find that
    channel's real dlstreams.st id when channel_id itself isn't already a
    bare number (e.g. 'NHL-Network' rather than '663').
    """
    from starfleetscrapers.live import live_sources as _ls

    if channel_id and channel_id.strip().isdigit():
        numeric_id = channel_id.strip()
    else:
        lookup_name = (channel_name or channel_id.replace('-', ' ')).strip().lower()
        numeric_id = None
        try:
            for ch in _ls._dlstreams_channels_raw():
                if ch.get('name', '').strip().lower() == lookup_name:
                    numeric_id = ch['id']
                    break
            if not numeric_id:
                # Loose fallback: every word in the lookup name present in
                # the channel's own title (handles e.g. "NHL Network" vs
                # the site's own "NHL Network USA").
                words = lookup_name.split()
                for ch in _ls._dlstreams_channels_raw():
                    name_l = ch.get('name', '').strip().lower()
                    if words and all(w in name_l for w in words):
                        numeric_id = ch['id']
                        break
        except Exception as e:
            xbmc.log('[Starfleet/Sports] dlchan: channel lookup error (%s): %s' % (lookup_name, e), xbmc.LOGWARNING)

    if not numeric_id:
        xbmc.log('[Starfleet/Sports] dlchan: no dlstreams.st channel matched for %s'
                 % (channel_name or channel_id), xbmc.LOGWARNING)
        return None

    try:
        return _ls.resolve_dlstreams_channel(numeric_id)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] dlchan: resolve error (%s): %s' % (numeric_id, e), xbmc.LOGWARNING)
        return None


def _dlchan_streams(event_path):
    """event_path format: 'dlchan:<channel-id>' e.g. 'dlchan:NHL-Network'."""
    channel_id = event_path.replace('dlchan:', '', 1)
    url = _dlchan_stream_url(channel_id)
    if not url:
        return []
    return [{
        'label': 'DaddyLive — Live 24/7',
        'url': url,
        'quality': '',
        'language': '',
        'source': 'DaddyLive',
    }]


def _dlchan_multi_streams(event_path):
    """event_path format: 'dlchan_multi:<id1>|<id2>|<id3>', where each entry
    is either a bare id/slug ('MLB-Network') or 'id=Real Channel Name' when
    the caller already knows the exact name (preferred — the id-guess and
    <title>-tag fallback inside _dlchan_stream_url are both unreliable for
    purely numeric ids). Resolves each in parallel, returns one stream entry
    per id labeled Link 1/Link 2/Link 3 (etc)."""
    entries = event_path.replace('dlchan_multi:', '', 1).split('|')
    entries = [e for e in entries if e]
    if not entries:
        return []

    def _split(entry):
        if '=' in entry:
            cid, name = entry.split('=', 1)
            return cid, name
        return entry, None

    results = [None] * len(entries)
    # one overall deadline, and no waiting for the stragglers on the way out: a channel with no feed behind it sends the resolver on to the
    # site's slow players (20-30 s), which held the whole list for that long although the answers that matter were in within seconds
    from concurrent.futures import as_completed as _as_completed
    ex = ThreadPoolExecutor(max_workers=len(entries))
    try:
        futs = {}
        for i, entry in enumerate(entries):
            cid, name = _split(entry)
            futs[ex.submit(_dlchan_stream_url, cid, name)] = i
        try:
            for fut in _as_completed(futs, timeout=10):
                i = futs[fut]
                try:
                    results[i] = fut.result()
                except Exception as e:
                    xbmc.log('[Starfleet/Sports] dlchan_multi error (%s): %s' % (entries[i], e), xbmc.LOGWARNING)
        except Exception:
            pass                       # the deadline: what has arrived is used
    finally:
        ex.shutdown(wait=False)

    streams = []
    for i, url in enumerate(results):
        if url:
            streams.append({
                'label': 'Link %d' % (i + 1),
                'url': url,
                'quality': '',
                'language': '',
                'source': 'DaddyLive',
            })
    return streams


# ── tvnow247.top events (schedule.json — same DaddyLive channel_id scheme) ────
#
# tvnow247.top (aka tv247us.live) publishes a clean JSON schedule at
# /schedule.json: {date_label: {category_label: [{time, event, channels:[
# {channel_id, channel_name}], channels2:[...]}]}}. Its channel_ids are the
# SAME numbering as daddylive.mov (verified: channel_id 663 = "NHL Network
# USA" on both), so events resolve through the existing _dlchan_stream_url
# chain — no separate resolver needed, just category → sport_slug tagging
# and a dlchan_multi: path per event (one link per listed channel/mirror).

_TVNOW_SCHEDULE_URL = 'https://tvnow247.top/schedule.json'

# category label keyword (lowercased) → sport_slug, matched against this
# addon's existing sport categories (sports_router / _CATEGORIES above)
_TVNOW_CATEGORY_SPORT_MAP = [
    ('soccer', 'soccer'), ('football ⚽', 'soccer'), ('premier league', 'soccer'),
    ('hockey', 'nhl'), ('nhl', 'nhl'),
    ('basketball', 'nba'), ('nba', 'nba'),
    ('baseball', 'mlb'), ('mlb', 'mlb'),
    ('nfl', 'nfl'), ('american football', 'nfl'),
    ('ufc', 'ufc'), ('mma', 'ufc'),
    ('boxing', 'boxing'),
    ('tennis', 'tennis'), ('atp', 'tennis'), ('wta', 'tennis'),
    ('cricket', 'cricket'),
    ('rugby', 'rugby'),
    ('darts', 'darts'),
    ('golf', 'golf'),
    ('snooker', 'snooker'),
    ('handball', 'handball'),
    ('volleyball', 'volleyball'),
    ('cycling', 'cycling'),
    ('f1', 'f1'), ('formula 1', 'f1'), ('formula1', 'f1'),
    ('motogp', 'motogp'),
    # deliberately NOT ('motorsport', 'f1') — confirmed live: tvnow's generic
    # "Motorsport" category mixes Formula E/DTM/Rally/GT4/Stock Car/etc.
    # together, not just F1, so attributing the whole bucket to F1 was
    # wrong. Left uncategorized (None) rather than guessed incorrectly.
    ('nascar', 'f1'),
    ('college football', 'cfb'), ('cfb', 'cfb'),
    ('college basketball', 'ncaab'), ('ncaab', 'ncaab'),
    ('cfl', 'cfl'),
    ('wwe', 'wwe'), ('wrestling', 'wwe'),
]


def _tvnow_detect_sport(category_label):
    lbl = (category_label or '').lower()
    for kw, slug in _TVNOW_CATEGORY_SPORT_MAP:
        if kw in lbl:
            return slug
    return None


@_cache.coalesced
def _tvnow_events():
    """Fetch + flatten tvnow247.top's schedule.json into a list of event dicts,
    each tagged with a best-guess sport_slug (None if uncategorizable — e.g.
    PPV motorsport/wrestling one-offs, TV show listings). Cached 15 min."""
    ck = 'tvnow_events_v2'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    events = []
    try:
        r = _sess().get(_TVNOW_SCHEDULE_URL, timeout=12, headers=_HEADERS)
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tvnow schedule fetch error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, [], 5 * 60)
        return []

    for _date_label, cats in (data or {}).items():
        if not isinstance(cats, dict):
            continue
        # _date_label looks like "Saturday 25th July 2026 - Schedule Time UK
        # GMT" — extract day/month/year once per date group and combine with
        # each event's own "HH:MM" time field to get a real timestamp.
        # Previously this was never parsed at all (start_ts hardcoded to 0),
        # so every tvnow-sourced event showed as TBD even when correctly
        # categorized. Treated as UTC (site labels it GMT year-round; no
        # confirmed BST adjustment, same precision limitation already
        # accepted elsewhere for HH:MM-only sources).
        # The site now writes the month short ("23rd Oct 2026"), which '%B' alone rejects - that left every event
        # without a start time (shown as TBD). Both spellings are read.
        day_ts_base = None
        m_date = re.search(r'(\d{1,2})\w{0,2}\s+([A-Za-z]+)\s+(\d{4})', _date_label)
        if m_date:
            for _fmt in ('%d %B %Y', '%d %b %Y'):
                try:
                    day_dt = _strp(
                        '%s %s %s' % (m_date.group(1), m_date.group(2), m_date.group(3)), _fmt)
                    day_ts_base = int((day_dt - datetime.datetime(1970, 1, 1)).total_seconds())
                    break
                except Exception:
                    day_ts_base = None

        for cat_label, evs in cats.items():
            sport_slug = _tvnow_detect_sport(cat_label)
            for ev in (evs or []):
                channels = ev.get('channels') or []
                # 'id=Name' when the schedule gives us a channel_name (it always
                # does) — _dlchan_stream_url needs the real name for numeric
                # ids since the page's own <title> tag is unreliable to parse.
                entries = [
                    '%s=%s' % (c['channel_id'], c['channel_name']) if c.get('channel_name')
                    else c['channel_id']
                    for c in channels if c.get('channel_id')
                ]
                if not entries:
                    continue
                cid0 = channels[0]['channel_id']
                title = ev.get('event', '')
                if not title:
                    continue

                start_ts = 0
                if day_ts_base is not None:
                    m_time = re.match(r'^(\d{1,2}):(\d{2})$', (ev.get('time') or '').strip())
                    if m_time:
                        start_ts = day_ts_base + int(m_time.group(1)) * 3600 + int(m_time.group(2)) * 60
                        # A schedule day runs from about 04:00 to 03:59 UTC the next morning: the US evening games listed
                        # at 00:00-03:59 (an NHL game at 00:00 is 8 PM Eastern) belong to the following calendar day.
                        if int(m_time.group(1)) < 4:
                            start_ts += 86400

                events.append({
                    'id':         'tvnow_%s' % cid0,
                    'slug':       'tvnow_%s' % cid0,
                    'path':       'dlchan_multi:' + '|'.join(entries),
                    'title':      title,
                    'league':     cat_label,
                    'sport_slug': sport_slug,
                    'logo':       '',
                    'is_live':    False,
                    'start_ts':   start_ts,
                    'date_label': ev.get('time', ''),
                })

    xbmc.log('[Starfleet/Sports] tvnow: %d events across %d categorized' % (
        len(events), sum(1 for e in events if e['sport_slug'])), xbmc.LOGINFO)
    _cache.set(ck, events, 15 * 60)
    return events


def _tvnow_events_for_sport(sport_slug):
    """Events from tvnow247.top's schedule tagged as belonging to sport_slug —
    used to supplement get_sport_events() with a real event listing (not just
    a stream-source fallback)."""
    try:
        return [e for e in _tvnow_events() if e.get('sport_slug') == sport_slug]
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tvnow_events_for_sport error: %s' % e, xbmc.LOGWARNING)
        return []


_RE_MOTORSPORT_TITLE = re.compile(r'moto\s?gp|moto[23]\b|formula|\bf1\b|nascar|indycar|grand prix|superbike|rally', re.I)


def _hoofoot_streams_by_title(event_title, sport_slug=''):
    """Cross-reference: hoofoot's live list by title (any sport), so a game listed
    by an official schedule (NHL/NBA/ESPN...) also gets hoofoot's channels. The
    hoofoot-path events already get theirs directly."""
    try:
        evs = _hoofoot_all_events()
    except Exception:
        return []
    if sport_slug == 'motogp':
        # the MotoGP class of that place (not the Moto2 / Moto3 sessions that carry the same sponsor name), the session on now or next
        after = re.split(r'\b(?:of|de|da|do|von|d[\'’])\b', event_title, maxsplit=1, flags=re.I)
        words = [w.lower() for w in re.split(r'\W+', after[1] if len(after) > 1 else event_title)
                 if len(w) >= 4 and w.lower() not in _MOTOGP_NOISE]
        now = time.time()
        pool = []
        for e in evs:
            blob = '%s %s' % (e.get('title') or '', e.get('league') or e.get('sport') or '')
            if not re.search(r'\bmoto\s?gp\b', blob, re.I) or re.search(r'moto[23]\b', blob, re.I):
                continue
            if not (words and any(w in blob.lower() for w in words)):
                continue
            st = int(e.get('start_ts') or 0)
            if st and (st < now - 4 * 3600 or st > now + 6 * 3600):
                continue
            pool.append(e)
        if not pool:
            return []
        started = [e for e in pool if int(e.get('start_ts') or 0) <= now + 600]
        pick = max(started, key=lambda e: int(e.get('start_ts') or 0)) if started else min(pool, key=lambda e: int(e.get('start_ts') or 0))
        return _hoofoot_event_streams(pick['path'])
    best, best_score = None, 0
    for e in evs:
        if not e.get('is_live') and (e.get('start_ts') or 0) > time.time() + 3600:
            continue   # not on yet
        # a race weekend ("Grand Prix of Portugal") must not take a football match of the same country for its feed
        if sport_slug in ('motogp', 'f1', 'motorsports') and not _RE_MOTORSPORT_TITLE.search(e['title']):
            continue
        score = _title_score(event_title, e['title'])
        if score > best_score:
            best_score, best = score, e
    if not best or best_score < 2:
        return []
    return _hoofoot_event_streams(best['path'])


def _tvnow_streams_by_title(event_title):
    """Cross-reference: find a tvnow247.top event by title match (any sport)
    and resolve all its listed channels as stream options."""
    try:
        evs = _tvnow_events()
    except Exception:
        return []
    best, best_score = None, 0
    for e in evs:
        score = _title_score(event_title, e['title'])
        if score > best_score:
            best_score = score
            best = e
    if not best or best_score < 2:
        return []
    return _dlchan_multi_streams(best['path'])


_MOTOGP_NOISE = {'grand', 'prix', 'gran', 'premio', 'premi', 'repsol', 'motul', 'petronas', 'airways', 'qatar', 'motogp', 'moto',
                 'round', 'race', 'sprint', 'practice', 'qualifying', 'the', 'del', 'des', 'von', 'dos', 'das', 'comunitat'}


def _tvnow_motogp_streams(event_title):
    """A MotoGP race weekend named by its sponsor ("REPSOL GRAND PRIX OF PORTUGAL"): the MotoGP session TVNow lists for that place that is on
    now or next ("MotoGP | Round 21 | Portugal Race"). The plain word match took the F1 "Grand Prix" listings (Sky Sports F1) for it."""
    try:
        evs = _tvnow_events()
    except Exception:
        return []
    after = re.split(r'\b(?:of|de|da|do|von|d[\'’])\b', event_title, maxsplit=1, flags=re.I)
    place = after[1] if len(after) > 1 else event_title
    words = [w.lower() for w in re.split(r'\W+', place) if len(w) >= 4 and w.lower() not in _MOTOGP_NOISE]
    if not words:
        return []
    now = time.time()
    cands = []
    for e in evs:
        t = e.get('title') or ''
        if not re.search(r'\bmoto\s?gp\b', t, re.I) or re.search(r'moto[23]\b', t, re.I):
            continue                                   # the MotoGP class only
        low = t.lower()
        if not any(w in low for w in words):
            continue
        st = int(e.get('start_ts') or 0)
        if st and st < now - 4 * 3600:
            continue                                   # long over
        cands.append(e)
    if not cands:
        return []
    cands.sort(key=lambda e: int(e.get('start_ts') or 0))
    # a session that started within the last hour is the one on; otherwise the next one up
    pick = next((e for e in cands if now - 3600 <= int(e.get('start_ts') or 0) <= now + 600), None) \
        or next((e for e in cands if int(e.get('start_ts') or 0) > now), None) or cands[-1]
    return _dlchan_multi_streams(pick['path'])


# ── streame.center resolver ───────────────────────────────────────────────────
#
# streame.center is a shared backend embed host that several front-end sites
# (powerstreams.site, realsportshd.buzz, and likely others) point at for many
# sports, not just MLB — but none of those front-ends expose a scrapable
# schedule of their own (one 403s outright, the other is a static link
# directory with no game listing). Rather than write a discovery scraper per
# front-end, this is applied as a universal post-processing step in
# get_event_streams: whenever ANY existing source (CrackStreams, StreamsEast,
# etc, across every sport they already cover) happens to hand back a
# streame.center-hosted embed link, resolve it here instead of returning the
# dead embed page. That gets every sport's coverage for free instead of one
# per-site scraper each.
#
# Chain: <front-end>/.../NN.html -> iframe streame.center/embed/chNN.php ->
# iframe streame.center/embed/hls.php?stream=<id> -> that page's own inline
# script already contains a plaintext base64 'input' blob (no JS/decryption
# needed on our end) which a plain POST to decrypt.php exchanges for a
# direct, real HLS URL — verified live, no WASM/P2P wall like embed.st.
# The resolved URL only actually serves segments with a matching Referer
# header, so that's carried along via Kodi's 'url|Referer=' pipe syntax.

_RE_STREAMECENTER_CH    = re.compile(r'streame\.center/embed/ch\d+\.php')
_RE_STREAMECENTER_HLS   = re.compile(r'streame\.center/embed/hls\.php\?[^"\'\s]+')
_RE_STREAMECENTER_INPUT = re.compile(r'input\s*:\s*"([^"]+)"')
_RE_STREAMECENTER_ANY   = re.compile(r'streame\.center/embed/\S+?\.php(?:\?[^"\'\s<]*)?')

# Confirmed white-label front-ends that just iframe straight through to a
# streame.center channel (same "NN.html"/"NN.php" per-game index across all
# three — one shared backend, several branded wrapper sites).
_STREAMECENTER_WRAPPER_HOSTS = ('powerstreams.site', 'realsportshd.buzz', 'crack-streams.site', 'streame.center')


def _resolve_streame_center(url):
    """Turn a streame.center embed URL — or one of its known wrapper front-
    ends (powerstreams.site/realsportshd.buzz/crack-streams.site, which just
    iframe straight to a streame.center channel) — into a direct, playable
    HLS URL tagged with the Referer it needs to actually serve. Returns None
    if this isn't a recognized link or resolution fails at any hop."""
    if not any(h in url for h in _STREAMECENTER_WRAPPER_HOSTS):
        return None

    if 'streame.center' not in url:
        # Wrapper front-end page — fetch it and pull out the streame.center
        # iframe it embeds, then continue exactly as if we'd started there.
        try:
            wrapper_html = _sess().get(url, timeout=8, headers=dict(_HEADERS, Referer=url)).text
        except Exception as e:
            xbmc.log('[Starfleet/Sports] streame.center wrapper fetch error (%s): %s' % (url, e), xbmc.LOGWARNING)
            return None
        m = _RE_STREAMECENTER_ANY.search(wrapper_html)
        if not m:
            return None
        url = 'https://' + m.group(0)

    try:
        html = _sess().get(url, timeout=8, headers=dict(_HEADERS, Referer='https://streame.center/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] streame.center fetch error (%s): %s' % (url, e), xbmc.LOGWARNING)
        return None

    hls_url = url
    if 'hls.php' not in url:
        m = _RE_STREAMECENTER_HLS.search(html)
        if not m:
            return None
        hls_url = 'https://' + m.group(0)
        try:
            html = _sess().get(hls_url, timeout=8, headers=dict(_HEADERS, Referer=url)).text
        except Exception as e:
            xbmc.log('[Starfleet/Sports] streame.center hls fetch error: %s' % e, xbmc.LOGWARNING)
            return None

    m = _RE_STREAMECENTER_INPUT.search(html)
    if not m:
        return None
    try:
        r = _sess().post('https://streame.center/embed/decrypt.php', data={'input': m.group(1)},
                          timeout=8, headers=dict(_HEADERS, Referer=hls_url))
        m3u8 = r.text.strip()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] streame.center decrypt error: %s' % e, xbmc.LOGWARNING)
        return None
    if not m3u8.startswith('http'):
        return None
    return m3u8 + '|Referer=https://streame.center/'


# ── daddylive.li sports events (live, in-addon — no scraper-PC dependency) ────
#
# Ported 2026-08-10 from the standalone scraper-PC fix for this exact site.
# daddylive.li's own schedule API only ever sets time=='Live' on events under
# its "Popular Live Events" bucket — every sport's own category listing keeps
# showing the original scheduled clock time even hours after the game
# started — but "Popular Live Events" entries use path-style PPV embed ids
# (admin/ppv-..., delta/...) whose embed.st hop now serves an ad-interstitial
# iframe (/ad.html) instead of the real player iframe in its static HTML,
# breaking the plain-HTTP resolve chain for every one of them. The SAME game
# is *also* listed under its own sport's category with ordinary numeric
# channel ids (e.g. "845" = NBC Universo) that still resolve fine — confirmed
# live end-to-end (3/3 real m3u8s resolved for a currently-live MLB game via
# that duplicate). So: the "Live" flag only decides WHICH games to list, and
# the actual channel list always comes from whichever same-game duplicate
# (matched by normalized team-name set, any category) has the most channels.
#
# No browser needed anywhere in this chain — confirmed live 2026-08-03 that
# daddylive.li's embed.php pages block Playwright outright via an anti-debug
# script, but a plain requests.get() never triggers it, and the real resolve
# chain is 3 static-HTML hops + one window.atob() base64 decode.

_DL_EVENTS_URL = 'https://daddylive.li/api/events'
_DL_API_BASE   = 'https://daddylive.li'

_DL_CAT_MAP = {
    'baseball': 'mlb', 'mlb': 'mlb',
    'football': 'soccer', 'soccer': 'soccer',
    'basketball': 'nba', 'nba': 'nba', 'wnba': 'wnba',
    'hockey': 'nhl', 'nhl': 'nhl',
    'nfl': 'nfl', 'american football': 'nfl',
    'ufc': 'ufc', 'mma': 'ufc', 'boxing': 'boxing',
    'wrestling': 'wwe', 'wwe': 'wwe', 'aew': 'wwe',
    'tennis': 'tennis', 'golf': 'golf', 'cricket': 'cricket',
    'rugby': 'rugby', 'motorsport': 'motorsports',
    'darts': 'darts', 'cfl': 'cfl',
}

# Checked BEFORE _DL_CAT_MAP, same fix (and same reasoning) as the
# standalone scraper's daddylive_common.py map_sport_category() - real F1
# races were matching the old bare 'f1'/'formula' keys above and landing in
# the 'motorsports' catch-all instead of the dedicated 'f1' folder; MotoGP
# had no mapping at all; CFB/NCAAB had none either and 'football'/
# 'basketball' would have wrongly matched them to soccer/nba; CFL's own
# "Am. Football (CFL)" category text contains the bare substring "football"
# which matched _DL_CAT_MAP's generic 'football': 'soccer' key first
# (dict iteration order) before ever reaching its own later 'cfl' key.
_RE_DL_F1     = re.compile(r'\bf1\b|\bformula\s*1\b|\bformula\s+one\b', re.IGNORECASE)
_RE_DL_MOTOGP = re.compile(r'\bmotogp\b', re.IGNORECASE)
_RE_DL_CFB    = re.compile(r'\b(?:college|ncaa|high school)\s+football\b|\bncaaf\b', re.IGNORECASE)
_RE_DL_NCAAB  = re.compile(r'\b(?:college|ncaa)\s+basketball\b|\bncaab\b', re.IGNORECASE)
_RE_DL_CFL    = re.compile(r'\bcfl\b', re.IGNORECASE)
_RE_DL_AFL    = re.compile(r'\bafl\b|\baussie\s*rules\b', re.IGNORECASE)

_RE_DL_CAT_PREFIX = re.compile(r'^[^:]+:\s*')
_RE_DL_IFRAME_SRC = re.compile(r'<iframe[^>]+src="([^"]+)"', re.IGNORECASE)
_RE_DL_ATOB_CALL  = re.compile(r"atob\(['\"]([A-Za-z0-9+/=]{20,})['\"]\)")


def _dl_map_sport_category(cat_text, event_title=''):
    blob = ('%s %s' % (cat_text or '', event_title or '')).lower()
    m = re.match(r'^([^:]+):', event_title or '')
    if m:
        blob = m.group(1).lower() + ' ' + blob
    if _RE_DL_CFB.search(blob):
        return 'cfb'
    if _RE_DL_NCAAB.search(blob):
        return 'ncaab'
    if _RE_DL_CFL.search(blob):
        return 'cfl'
    if _RE_DL_AFL.search(blob):
        return 'afl'
    if _RE_DL_F1.search(blob):
        return 'f1'
    if _RE_DL_MOTOGP.search(blob):
        return 'motogp'
    for key, slug in _DL_CAT_MAP.items():
        if key in blob:
            return slug
    return None


def _dl_norm_teams(title):
    import unicodedata
    t = _RE_DL_CAT_PREFIX.sub('', title or '')
    t = ''.join(c for c in unicodedata.normalize('NFKD', t) if not unicodedata.combining(c))
    t = ''.join(c for c in t if ord(c) < 128)
    t = re.sub(r'[^a-z0-9\s]', ' ', t.lower())
    return frozenset(t.split())


# Narrowed 2026-09-13, per a live kodi.log trace showing this fast path
# firing on Falcon's own unrelated candidate mirror URLs too (e.g.
# https://hamis.romponalis.st/premiumtv/rippleplays.php?id=667) — those
# also happen to contain "id=<digits>" in their query string, but that id
# has no guaranteed relationship to dlive.sx's own numbering the way
# daddylive.li's own embed.php?id=N genuinely does; matching them wasted a
# dlive.sx round-trip before correctly falling through to the real chain.
# Anchored specifically to daddylive.li's own embed.php path shape now.
_RE_DL_NUMERIC_ID = re.compile(r'daddylive\.\w+/player/embed\.php\?id=(\d+)(?:&|$)', re.IGNORECASE)



def _dl_hop_url(raw, base):
    """An iframe src taken from a wrapper page -> absolute http(s) URL, or None
    for the things that are not a player at all. The pages hand out all of:
    protocol-relative ('//streame.center/..'), site-relative ('/ad.html',
    'source027.html', '2/105.html?id=105'), 'about:blank' and javascript: stubs;
    the chain used to pass them to requests verbatim ("No scheme supplied",
    "No connection adapters were found for 'about:blank'") and give up."""
    raw = (raw or '').strip().replace('&amp;', '&')
    if not raw or raw.lower().startswith(('about:', 'javascript:', 'data:')):
        return None
    if raw.startswith('//'):
        return 'https:' + raw
    if raw.startswith('http'):
        if raw.startswith(('https:///', 'http:///')):   # host missing
            return None
        return raw
    from urllib.parse import urljoin as _uj
    out = _uj(base, raw)
    low = out.lower()
    if '/ad.html' in low or low.endswith('/ads.html'):
        return None
    return out


_RE_DL_PLAYERS = re.compile(r'const\s+PLAYERS\s*=\s*(\[.*?\]);', re.S)


_DL_DEAD_HOSTS = {}


def _dl_host_of(url):
    try:
        import urllib.parse as _up_dh
        return _up_dh.urlparse(url).netloc.lower()
    except Exception:
        return ''


def _dl_host_dead(host):
    """True for 10 minutes after an embed host failed to connect (2026-11-21: the *.cfd / *.shop DaddyLive embed hosts time out on connect, and every game re-waited 10+ s on each of them)."""
    t = _DL_DEAD_HOSTS.get(host)
    return bool(host and t and time.time() - t < 600)


def _dl_mark_host_dead(host):
    if host:
        _DL_DEAD_HOSTS[host] = time.time()


def _dl_resolve_player_list(embed_url, timeout_s=15):
    """daddylive.li/player/embed.php?id=<hex>&source=tvN: the page carries `const PLAYERS = [{"src": "<player page>"}, ...]`
    (vertex.st / nexa.st / kora.st channel pages). Each one is handed to the resolver module; the first playlist wins."""
    import json as _json
    from starfleetscrapers.core import dns_fallback as _dnsf
    r = _dnsf.get(embed_url, timeout=timeout_s, headers=dict(_HEADERS, Referer=_DL_API_BASE + '/'))
    m = _RE_DL_PLAYERS.search(r.text)
    srcs = []
    if m:
        try:
            srcs = [p.get('src') for p in _json.loads(m.group(1)) if p.get('src')]
        except Exception:
            srcs = []
    if not srcs:
        m = re.search(r'<iframe[^>]+id="media-player"[^>]+src="([^"]+)"', r.text)
        srcs = [m.group(1)] if m else []
    import starfleetresolve
    for src in srcs:
        try:
            out = starfleetresolve.resolve(src, referer=embed_url, debrid_links=False)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] daddylive player %s: %s' % (src, str(e)[:100]), xbmc.LOGINFO)
            continue
        if out:
            if isinstance(out, (list, tuple)):
                out = out[0]
            if isinstance(out, dict):
                out = out.get('url') or out.get('link')
            if out:
                return out
    return None


def _dl_resolve_embed(embed_url, timeout_s=15):
    """3 static-HTML hops + one atob() decode, no browser needed. Returns a
    playable URL (Referer/User-Agent pipe-tagged for Kodi's player) or None.

    Every hop goes through dns_fallback.get() rather than a plain
    _sess().get() — same reasoning as _dl_schedule()'s own fix: daddylive.li
    itself (hop 1) can fail plain DNS resolution on some local/ISP
    resolvers while genuinely live (confirmed live 2026-09-04), and this
    file's own docstring already documented the identical failure mode for
    one of the later-hop mirror domains (dlhd.st) — cheap and transparent
    to apply everywhere in this chain since it only ever does anything on
    an actual DNS failure.

    Fast-path fixed 2026-09-13, per a direct report that DaddyLive had
    stopped producing any streams at all (confirmed live via kodi.log: 50
    consecutive real resolve attempts, zero successes). Root-caused to
    daddylive.li's hop-2 mirror (nontongo.win) changing its markup: the
    real player iframe is no longer present in the raw HTML at all — it's
    now only created by a client-side click handler
    ($('<iframe>',{src:'https://nontongo.win/livetv/view/<id>'})...), which
    a plain HTTP fetch can never see, so _RE_DL_IFRAME_SRC found nothing
    (or, on pages with unrelated ad/decoy iframes elsewhere, matched junk
    like "/ad.html" instead of the real player). Traced the FULL chain live
    for a real channel id anyway, by fetching that deterministic
    /livetv/view/<id> URL directly: it lands on ANOTHER iframe
    (nontongo.app/watch/<token>), which itself lands on
    dlive.sx/stream/stream-<id>.php — using the exact SAME numeric id the
    original daddylive.li embed_url started with, and the exact same URL
    shape this file's own _livetv902_resolve_dlstreams() (used by the
    dlchan/dlchan_multi 24/7-channel chain, e.g. NHL/MLB Network) already
    knows how to resolve. So for any embed_url with a plain numeric id
    (the common case — "Link - N" channels from daddylive.li's main
    listing, including RedZone's own primary listing), skip the now-dead
    3-hop chain entirely and resolve straight through that existing,
    already-working function instead — also 3 requests cheaper per
    resolve. Non-numeric ids (the site's other "source=tvN" mirror
    listings, a different, unrelated set of embed providers entirely) fall
    through to the original chain below unchanged, since those were never
    confirmed broken by this same root cause and haven't been re-verified
    against whatever their own current markup looks like."""
    _dead_host = _dl_host_of(embed_url)
    if _dl_host_dead(_dead_host):
        return None
    if isinstance(timeout_s, (int, float)):
        timeout_s = (min(5, timeout_s), timeout_s)    # a host that does not connect in 5 s will not serve a page either
    id_m = _RE_DL_NUMERIC_ID.search(embed_url)
    if id_m:
        try:
            from starfleetscrapers.sports import dlhd_players as _dlp
            fast = _livetv902_resolve_dlstreams('%s/stream/stream-%s.php' % (_dlp.active_base(), id_m.group(1)))
        except Exception as e:
            fast = None
            xbmc.log('[Starfleet/Sports] daddylive site fast-path error (id=%s): %s'
                     % (id_m.group(1), e), xbmc.LOGWARNING)
        if fast:
            xbmc.log('[Starfleet/Sports] daddylive site fast-path OK (id=%s)' % id_m.group(1), xbmc.LOGINFO)
            return fast
        xbmc.log('[Starfleet/Sports] daddylive site fast-path returned nothing (id=%s), '
                 'falling through to legacy chain' % id_m.group(1), xbmc.LOGINFO)
    else:
        # The embed page now lists its players itself (const PLAYERS = [{"src":"https://vertex.st/ch?id=8"}, nexa.st, kora.st]):
        # each one is a channel page the resolver module already decodes.
        try:
            _found = _dl_resolve_player_list(embed_url, timeout_s)
        except Exception as e:
            _found = None
            xbmc.log('[Starfleet/Sports] daddylive player list error: %s' % e, xbmc.LOGINFO)
        if _found:
            return _found

    from starfleetscrapers.core import dns_fallback as _dnsf
    try:
        r1 = _dnsf.get(embed_url, timeout=timeout_s, headers=dict(_HEADERS, Referer=_DL_API_BASE + '/'))
        m1 = _RE_DL_IFRAME_SRC.search(r1.text)
        if not m1:
            return None
        hop2_url = _dl_hop_url(m1.group(1), embed_url)
        if not hop2_url:
            return None
        # A hop landing directly on a backend this file already has a
        # dedicated, known-working resolver for (found 2026-09-13 while
        # investigating FalconStreams: several of its dozens of
        # differently-skinned candidate mirrors converge on these exact
        # same backends after their own extra hop or two) — delegate
        # immediately rather than continuing this function's own
        # atob-only parse, which doesn't understand vivtops.st's shape at
        # all and would otherwise just silently return None for it.
        if 'vivtops.st' in hop2_url:
            return _livetv902_resolve_vivtops(hop2_url)
        if 'dlive.sx' in hop2_url or 'dlstreams.st' in hop2_url or 'thedaddy.li' in hop2_url:
            return _livetv902_resolve_dlstreams(hop2_url)

        r2 = _dnsf.get(hop2_url, timeout=timeout_s, headers=dict(_HEADERS, Referer=embed_url))
        m2 = _RE_DL_IFRAME_SRC.search(r2.text)
        if not m2:
            return None
        hop3_url = _dl_hop_url(m2.group(1), hop2_url)
        if not hop3_url:
            return None
        if 'vivtops.st' in hop3_url:
            return _livetv902_resolve_vivtops(hop3_url)
        if 'dlive.sx' in hop3_url or 'dlstreams.st' in hop3_url or 'thedaddy.li' in hop3_url:
            return _livetv902_resolve_dlstreams(hop3_url)

        # Retry added 2026-09-13 alongside the same fix in
        # _livetv902_resolve_dlstreams() — confirmed live this hop's usual
        # destination (a hamis.*.st-style mirror) is genuinely,
        # intermittently flaky under real concurrent load, not reliably
        # dead: a direct repro got timeout / 200-in-3.7s / 200-in-0.8s
        # across 3 back-to-back requests. One retry turns that transient
        # flakiness back into a normal success instead of a hard failure.
        r3 = None
        for attempt in range(2):
            try:
                r3 = _dnsf.get(hop3_url, timeout=timeout_s, headers=dict(_HEADERS, Referer=hop2_url))
                break
            except Exception:
                if attempt == 0:
                    continue
                raise
        m3 = _RE_DL_ATOB_CALL.search(r3.text)
        if not m3:
            return None
        import base64 as _b64
        m3u8 = _b64.b64decode(m3.group(1)).decode('utf-8', 'ignore')
        if not m3u8.startswith('http'):
            return None

        # Real bug fixed 2026-09-04: this used to do its own verification
        # GET against the final m3u8 before handing it back — confirmed
        # live via kodi.log that this exact CDN family (xameleon.*.top,
        # reached through hamis.*.st/premiumtv/daddy3.php - the same
        # referer chain built below) rejects Kodi's own real playback
        # fetch with a 403 immediately after this verification fetch
        # already succeeded moments earlier: CCurlFile::Stat failed with
        # error(22), then inputstream.adaptive got a flat HTTP 403 on the
        # identical URL. Same root cause and same fix as the OK.ru replay
        # bug fixed earlier this session (see local_proxy.py's own history)
        # - a signed/session-pinned CDN URL only tolerates ONE real
        # connection, and this addon's own "let's confirm it works first"
        # fetch was quietly spending that one connection before the real
        # player ever got a turn. Trust the decoded URL directly instead.
        import urllib.parse as _up_dl
        return '%s|Referer=%s&User-Agent=%s' % (
            m3u8, _up_dl.quote(hop3_url, safe=''), _up_dl.quote(_HEADERS['User-Agent'], safe='')
        )
    except Exception as e:
        if 'ConnectTimeout' in type(e).__name__ or 'ConnectTimeoutError' in str(e) or 'NameResolutionError' in str(e):
            _dl_mark_host_dead(_dead_host)
        xbmc.log('[Starfleet/Sports] daddylive embed resolve error: %s' % e, xbmc.LOGWARNING)
        return None


def _dl_schedule():
    """Fetch + cache daddylive.li's full day schedule (10 min, matches this
    file's event-list cache convention)."""
    ck = 'dlsports_schedule_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        # daddylive.li itself can fail plain DNS resolution on some local/
        # ISP resolvers even while it's genuinely live (confirmed live on
        # this network specifically, 2026-09-04 — a plain _sess().get() got
        # NameResolutionError while a public DoH resolver had a real
        # answer) — same class of issue dns_fallback.py already exists for
        # (see _tvnow_api_resolve_mirror's own use of it above), just not
        # previously applied to this specific call.
        from starfleetscrapers.core import dns_fallback as _dnsf
        r = _dnsf.get(_DL_EVENTS_URL, timeout=12, headers=_HEADERS)
        raw = r.json()
        # Real bug fixed 2026-09-04: daddylive.li's own /api/events used to
        # return a LIST of per-day {'categories': {...}, 'day': '...'}
        # objects - it now returns a single {'categories': {...},
        # 'popular_events': [...], 'total_events': N} dict directly with no
        # day-list wrapper (confirmed live). The old isinstance(days, list)
        # check silently treated every response as empty since this shape
        # change, so _dl_streams_by_title() - the live "attach a DaddyLive
        # source to whatever event the user already opened" cross-reference
        # - has been returning nothing for every sport this whole time, not
        # just a real "nothing live right now". Wrapping the single dict in
        # a one-item list keeps every line below unchanged; the new shape's
        # missing 'day' field just means day_ts_base stays None below (no
        # scheduled-kickoff time window fallback), same as before for any
        # response shape that never had a real 'day' string.
        if isinstance(raw, dict) and 'categories' in raw:
            days = [raw]
        elif isinstance(raw, list):
            days = raw
        else:
            days = []
    except Exception as e:
        xbmc.log('[Starfleet/Sports] daddylive schedule fetch error: %s' % e, xbmc.LOGWARNING)
        days = []
    _cache.set(ck, days, 10 * 60)
    return days


_RE_DL_DAY_DATE = re.compile(r'(\d{1,2})\w{0,2}\s+([A-Za-z]+)\s+(\d{4})')
# How long after its scheduled kickoff a game is still treated as "live" —
# generous enough to cover MLB extra innings / NHL overtime / a delayed
# start without matching yesterday's already-finished games.
_DL_LIVE_WINDOW_AFTER_SECS = 5 * 3600
# daddylive's own listed kickoff can genuinely run a bit later than this
# addon's own (ESPN-derived) event data — confirmed live: a real MLB game
# already showing "LIVE NOW" on the Sports screen was still 12 minutes
# ahead of daddylive's own listed start time for the exact same game. A
# small pre-game allowance avoids missing an event purely because the two
# sources' clocks don't quite agree, without being wide enough to start
# matching a genuinely different, much-later game with the same category.
_DL_LIVE_WINDOW_BEFORE_SECS = 45 * 60


def _dl_live_index():
    """Build (slug, normalized-teams) -> best-channeled duplicate index, plus
    the list of events considered live right now, from the cached schedule.
    Cached alongside the schedule fetch itself (same 10 min window) so
    get_sport_events() and get_event_streams() share one fetch+parse.

    Confirmed live 2026-08-14: daddylive.li's explicit time=='Live' flag is
    now only ever set on its curated "Popular Live Events" bucket, which at
    any given moment might contain as few as 1-2 games total across EVERY
    sport combined — a real MLB game with 4 real channels, listed under its
    own "Baseball (MLB)" category, still showed its original scheduled
    clock time ("22:40") hours after first pitch, so it never made it into
    live_events at all even though best_by_key already had its full channel
    list. Matches this addon's own already-documented finding above ("every
    sport's own category listing keeps showing the original scheduled clock
    time even hours after the game started") but that comment only explains
    why the channel LIST still needs the best-of-any-category lookup — it
    doesn't fix the separate problem that the "Live" flag alone decides
    which games are even attempted, effectively making almost all sports
    invisible whenever that curated bucket is this sparse. Same date-header
    parsing convention as _tvnow_schedule() above (day label + HH:MM,
    treated as UTC — the site labels it GMT year-round)."""
    ck = 'dlsports_index_v3'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    now_utc_ts = int((datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None) - datetime.datetime(1970, 1, 1)).total_seconds())

    days = _dl_schedule()
    best_by_key = {}
    live_events = []
    seen_live_keys = set()
    for day in days:
        cats = day.get('categories') or {}
        if not isinstance(cats, dict):
            continue

        day_ts_base = None
        m_date = _RE_DL_DAY_DATE.search(day.get('day') or '')
        if m_date:
            for _fmt in ('%d %B %Y', '%d %b %Y'):
                try:
                    day_dt = _strp(
                        '%s %s %s' % (m_date.group(1), m_date.group(2), m_date.group(3)), _fmt)
                    day_ts_base = int((day_dt - datetime.datetime(1970, 1, 1)).total_seconds())
                    break
                except Exception:
                    day_ts_base = None

        for cat_name, evs in cats.items():
            for ev in evs or []:
                title = (ev.get('event') or '').strip()
                if not title:
                    continue
                slug = _dl_map_sport_category(cat_name, title)
                if not slug:
                    continue
                key = (slug, _dl_norm_teams(title))
                chans = ev.get('channels') or []
                prev = best_by_key.get(key)
                if prev is None or len(chans) > len(prev.get('channels') or []):
                    best_by_key[key] = ev

                ev_time = (ev.get('time') or '').strip()
                is_live = ev_time.lower() == 'live'
                if not is_live and day_ts_base is not None:
                    m_time = re.match(r'^(\d{1,2}):(\d{2})$', ev_time)
                    if m_time:
                        start_ts = day_ts_base + int(m_time.group(1)) * 3600 + int(m_time.group(2)) * 60
                        # A schedule day runs from about 04:00 to 03:59 UTC the next morning: the US evening games listed
                        # at 00:00-03:59 (an NHL game at 00:00 is 8 PM Eastern) belong to the following calendar day.
                        if int(m_time.group(1)) < 4:
                            start_ts += 86400
                        is_live = -_DL_LIVE_WINDOW_BEFORE_SECS <= (now_utc_ts - start_ts) <= _DL_LIVE_WINDOW_AFTER_SECS
                if is_live and key not in seen_live_keys:
                    seen_live_keys.add(key)
                    live_events.append((slug, key, title))

    result = (best_by_key, live_events)
    _cache.set(ck, result, 10 * 60)
    return result


def _dl_streams_by_title(sport_slug, event_title):
    """Cross-reference: this addon's OWN event (from ESPN/official APIs/etc,
    already listed in get_sport_events()) against daddylive.li's currently-
    Live events for the same sport, by fuzzy title match — DaddyLive never
    gets its own separate listing, it only contributes source options onto
    whatever event the user already opened, same pattern as
    _tvnow_streams_by_title / _onhockey_streams_by_title below."""
    if not event_title:
        return []
    try:
        best_by_key, live_events = _dl_live_index()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] daddylive index error: %s' % e, xbmc.LOGWARNING)
        return []

    best_key, best_score = None, 0
    for slug, key, title in live_events:
        if slug != sport_slug:
            continue
        score = _title_score(event_title, title)
        if score > best_score:
            best_score = score
            best_key = key
    if not best_key or best_score < 2:
        return []

    best_ev = best_by_key.get(best_key)
    chans = (best_ev.get('channels') or []) if best_ev else []
    if not chans:
        return []

    streams = []
    # Same 'with ThreadPoolExecutor(...) as ex' issue already fixed
    # elsewhere this session — breaking out of the loop early (once 3
    # streams resolve) still left the pool's own __exit__ waiting on every
    # OTHER still-running channel resolve before this function could
    # return. as_completed + shutdown(wait=False) caps it properly.
    ex = ThreadPoolExecutor(max_workers=min(len(chans), 6))
    futs = {}
    for ch in chans:
        url = (ch.get('url') or '').strip()
        if not url:
            continue
        futs[ex.submit(_dl_resolve_embed, url)] = ch.get('channel_name') or 'Stream'
    try:
        for fut in as_completed(futs, timeout=18):
            label = futs[fut]
            try:
                resolved = fut.result()
            except Exception:
                resolved = None
            if resolved:
                streams.append({
                    'label': label,
                    'url': resolved,
                    'quality': '',
                    'language': '',
                    'source': 'DaddyLive',
                })
            if len(streams) >= 3:
                break
    except Exception:
        pass
    finally:
        ex.shutdown(wait=False)
    return streams



def _canadiens_streams(event_title, start_ts=0):
    """Montreal Canadiens exception: the French-language broadcaster is a source of every Canadiens game - RDS on weekdays
    (Monday to Friday), TVA Sports on Saturdays (the day of the game, on the local clock). Sundays have no rule. The
    channels come from the 24/7 channel directory."""
    t = (event_title or '').lower()
    if 'canadiens' not in t and 'montreal' not in t:
        return []
    import datetime
    try:
        day = datetime.datetime.fromtimestamp(int(start_ts)) if start_ts else datetime.datetime.now()
    except Exception:
        day = datetime.datetime.now()
    wd = day.weekday()
    if wd == 5:
        pattern, label = re.compile(r'tva\s*sports?', re.I), 'TVA Sports'
    elif wd < 5:
        pattern, label = re.compile(r'(^|\W)rds(\W|$)', re.I), 'RDS'
    else:
        return []
    streams = []
    try:
        from starfleetscrapers.live import live_sources as _ls
        chans = [c for c in _ls._dlstreams_channels_raw()
                 if pattern.search(c.get('name', '')) and 'info' not in c.get('name', '').lower()][:3]
        for ch in chans:
            try:
                url = _ls.resolve_dlstreams_channel(ch['id'])
            except Exception:
                url = None
            if url:
                streams.append({'label': 'Canadiens - %s (%s)' % (label, ch.get('name', label)), 'url': url,
                                'quality': '', 'language': 'FR', 'source': 'DaddyLive'})
    except Exception as e:
        xbmc.log('[Starfleet/Sports] canadiens channel error: %s' % e, xbmc.LOGWARNING)
    return streams


def _tv_listed_streams(sport_slug, title, start_ts=0):
    """The channels a game airs on (livesportsontv.com's listing: RDS, TSN2, ESPN...) as streams, taken from the 24/7 channel directory. This
    covers every game and every channel the listing names, including the ones whose own TV guide has nothing for the game."""
    from starfleetscrapers.sports import tv_listings as _tl
    chans = _tl.channels_for_game(sport_slug, title, start_ts)
    return _tl.streams_for_channels(chans, 'On TV') if chans else []


def _redbull_live_stream():
    """Red Bull TV's one free, legal 24/7 channel (motorsport, winter and action sports, event replays) - a fresh, signed
    link straight from Red Bull's own public session API, not a listing or title match (see live_sources.py)."""
    try:
        from starfleetscrapers.live import live_sources as _rb
        url = _rb.get_redbull_stream()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Red Bull TV error: %s' % e, xbmc.LOGWARNING)
        return []
    return [{'label': 'Red Bull TV - Live', 'url': url, 'quality': '', 'language': 'EN', 'source': 'Red Bull TV'}] if url else []


# ── falconstreams.app (Next.js aggregator, dozens of mirror links per match) ──
#
# Added 2026-08-10, originally a plain server-rendered "Streaming Now"
# section (game cards as static HTML anchors). Confirmed dead 2026-09-11 —
# the site rebuilt itself as a fully client-rendered Next.js app; a real
# browser network capture shows the homepage now fetches its own listing via
# GET /api/matches ({"message":"success","matches":[...]}) instead of
# shipping any per-card HTML at all, so the old aria-label/href regex below
# matched literally nothing regardless of real content. Confirmed via the
# site's own current JS bundle (chunks/f8ea56288a9eab13.js) exactly which
# fields each match object carries and how the site builds its own match-page
# URL from them: top-level `_id` and `category`, home/away team names at
# `details.text2`/`details.teamA` and `details.text3`/`details.teamB`
# (fallback pairs in that order), assembled into
# /live/{slugify(category)}/match/{slugify(home)}-vs-{slugify(away)}/{_id}
# (falls back to just the category slug if the away side is empty/"TBD" —
# matches the site's own logic). No live match existed anywhere on the site
# at fix time (matches: [] — genuinely nothing streaming/scheduled that
# moment, confirmed independently via the rendered page itself saying "No
# data available"), so this could only be verified against the API contract
# itself, not a full live end-to-end match resolve — worth a spot-check once
# a real live match appears.
#
# Each match page still embeds a matchData JSON blob (React Server Component
# payload, quote-escaped in the raw HTML) listing dozens of candidate mirror
# links per game across many differently-named front-ends (prostreams.best,
# streamrush.top, worldstreams.cc, 1ststreams.space, etc — mostly clones of
# the same handful of backends, going by identical URL date slugs across
# them) — _falcon_match_links() below, unaffected by the listing-format
# change above, still handles that page the same way it always did. At least
# one of them (prostreams.best) resolves through the EXACT SAME
# iframe->iframe->atob() chain as daddylive.li above (same CDN even —
# hamis.*.st/premiumtv/... -> atob() -> xameleon.*.top/.../index.m3u8) — no
# separate resolver needed, _dl_resolve_embed() already handles it since that
# function doesn't care which site an embed URL came from. No per-domain
# special-casing: just throw every candidate link at the same resolver in
# parallel and keep whichever ones actually decode to a real, verified m3u8
# (most won't — dead/seized domains, different chains entirely — that's
# expected, same "resolve what resolves" treatment as everywhere else in
# this file).


def _falcon_slugify(text):
    s = re.sub(r'[^a-z0-9]+', '-', (text or '').strip().lower()).strip('-')
    return s or 'match'

_FALCON_BASE = 'https://falconstreams.st'   # 2026-11-21: falconstreams.app redirects here; /api/matches answers 404 now
_FALCON_HOME = _FALCON_BASE + '/home1'
_FALCON_API  = False

_RE_FALCON_CARD = re.compile(
    r'aria-label="Watch ([^"]+?) live stream[^"]*"[^>]*?href="(/live/([a-z0-9-]+)/match/[a-z0-9-]+/[a-f0-9]+)"'
)
_RE_FALCON_LINK = re.compile(r'\\"link\\":\\"(https?://[^"\\]+)')

_FALCON_LEAGUE_KEYWORDS = {
    # 'wnba' must be checked before 'nba' — it's a substring match otherwise
    'wnba': 'wnba', 'mlb': 'mlb', 'nba': 'nba', 'nfl': 'nfl', 'nhl': 'nhl',
    'ufc': 'ufc', 'mma': 'ufc', 'boxing': 'boxing',
    'motorsport': 'motorsports',
    'tennis': 'tennis', 'golf': 'golf', 'cricket': 'cricket', 'rugby': 'rugby',
    'wwe': 'wwe', 'aew': 'wwe',
    # soccer league slugs (no single generic 'soccer' league name on this site)
    'liga': 'soccer', 'league': 'soccer', 'cup': 'soccer', 'premier': 'soccer',
    'friendly': 'soccer', 'mls': 'soccer', 'seria': 'soccer', 'bundesliga': 'soccer',
}

# Checked before _FALCON_LEAGUE_KEYWORDS — same F1/MotoGP fix as
# _DL_CAT_MAP above: the old bare 'f1'/'formula': 'motorsports' entries
# swallowed real F1 races into the generic catch-all instead of the
# dedicated 'f1' folder, and MotoGP had no mapping at all.
_RE_FALCON_F1     = re.compile(r'\bf1\b|\bformula\s*1\b|\bformula\s+one\b', re.IGNORECASE)
_RE_FALCON_MOTOGP = re.compile(r'\bmotogp\b', re.IGNORECASE)


def _falcon_map_league(league_slug):
    blob = (league_slug or '').replace('-', ' ').lower()
    if _RE_FALCON_F1.search(blob):
        return 'f1'
    if _RE_FALCON_MOTOGP.search(blob):
        return 'motogp'
    for kw, slug in _FALCON_LEAGUE_KEYWORDS.items():
        if kw in blob:
            return slug
    return None


def _falcon_events():
    """Fetch + cache (10 min) FalconStreams' current match list via its own
    GET /api/matches JSON endpoint (see this section's own header comment
    for why this replaced the old HTML-card scrape) — only whatever's
    currently featured, same "Live flag decides which games, not the whole
    schedule" shape as daddylive.li above."""
    ck = 'falcon_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    events = []
    try:
        if not _FALCON_API:
            raise RuntimeError('json endpoint retired')
        data = _sess().get(_FALCON_BASE + '/api/matches', timeout=12, headers=_HEADERS).json()
        for m in (data.get('matches') or []):
            mid = m.get('_id')
            category = m.get('category') or ''
            if not mid or not category:
                continue
            slug = _falcon_map_league(category)
            if not slug:
                continue
            details = m.get('details') or {}
            home = details.get('text2') or details.get('teamA') or ''
            away = details.get('text3') or details.get('teamB') or ''
            title = ('%s vs %s' % (home, away)) if (home and away and away.lower() != 'tbd') else (home or category)
            cat_slug = _falcon_slugify(category)
            if home and away and away.lower() != 'tbd':
                match_slug = '%s-vs-%s' % (_falcon_slugify(home), _falcon_slugify(away))
            else:
                match_slug = cat_slug
            href = '/live/%s/match/%s/%s' % (cat_slug, match_slug, mid)
            events.append({'slug': slug, 'title': title, 'href': href})
    except Exception as e:
        if _FALCON_API:
            xbmc.log('[Starfleet/Sports] falconstreams events error: %s' % e, xbmc.LOGWARNING)
        events = []
    if not events:
        # 2026-11-21: /api/matches now answers with a redirect to an HTML page; the home page's own game cards carry the same list
        try:
            import html as _html_falcon
            page = _sess().get(_FALCON_HOME, timeout=14, headers=_HEADERS).text
            seen_href = set()
            for label, href, cat_slug in _RE_FALCON_CARD.findall(page):
                slug = _falcon_map_league(cat_slug)
                if not slug or href in seen_href:
                    continue
                seen_href.add(href)
                events.append({'slug': slug, 'title': _html_falcon.unescape(label).strip(), 'href': href})
        except Exception as e:
            xbmc.log('[Starfleet/Sports] falconstreams page error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, events, 10 * 60 if events else 60)
    return events


# Set by an app that can open an embed page in a hidden web view (HazMat TV, Binge Hazmat Sports): sources whose players are obfuscated
# JavaScript then hand the page address on instead of dropping it, and the app digs the stream out of the page itself.
WEB_SNIFF = bool(os.environ.get('HAZMAT_WEBVIEW'))
WEB_URLS = set()      # the page addresses handed on for the web view: the player screen sends these to it instead of the resolvers


def _falcon_match_links(href):
    """Fetch + cache (10 min) one match page's full candidate mirror-link
    list."""
    ck = 'falcon_links_%s' % href
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _sess().get(_FALCON_BASE + href, timeout=12, headers=_HEADERS).text
        links = list(dict.fromkeys(_RE_FALCON_LINK.findall(html)))  # de-dup, keep order
        # 2026-11-21: the page now lists its mirrors as iframeStreams [{name, src}] (directStreams is empty)
        for blk in re.findall(r'\\"iframeStreams\\":\[(.*?)\]', html, re.S):
            for src in re.findall(r'\\"src\\":\\"(https?://[^"\\]+)', blk):
                if src not in links:
                    links.append(src)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] falconstreams match links error (%s): %s' % (href, e), xbmc.LOGWARNING)
        links = []
    _cache.set(ck, links, 10 * 60)
    return links


def _falcon_link_mismatched(url, team_words):
    """True if the URL's own path names a specific team-vs-team matchup that
    shares no words with the target event — defensive filter for
    FalconStreams' own directStreams data occasionally mixing in an
    unrelated match's link under the current match's entry. Confirmed live
    2026-08-13: the "Sportszone" mirror entry for a Miami Marlins vs
    Pittsburgh Pirates match page pointed at a completely unrelated
    mirassol-vs-corinthians SOCCER match, sitting right inside that match's
    own matchData.directStreams array — a data bug on FalconStreams' end,
    not a link-extraction scoping issue in this addon's regex. Since the
    resolver has no way to inspect actual video content, this URL-slug
    sanity check is the only defense available. Links with no descriptive
    "-vs-" slug (the numeric ?p=NNNN style mirrors) carry no team info to
    check and are always left alone."""
    import urllib.parse as _up_falcon
    path = _up_falcon.urlparse(url).path.lower()
    if '-vs-' not in path and '/vs/' not in path:
        return False
    slug_words = set(re.sub(r'[^a-z0-9]+', ' ', path).split()) - {'vs'}
    return bool(slug_words) and not (slug_words & team_words)


def _falcon_streams_by_title(sport_slug, event_title):
    """Cross-reference: this addon's OWN event against FalconStreams' current
    Streaming Now list by fuzzy title match, then try every candidate mirror
    link through the shared daddylive resolver — same title-match-onto-
    existing-event pattern as _dl_streams_by_title above, no separate
    listing of its own."""
    if not event_title:
        return []
    try:
        events = _falcon_events()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] falconstreams index error: %s' % e, xbmc.LOGWARNING)
        return []

    best_ev, best_score = None, 0
    for ev in events:
        if ev['slug'] != sport_slug:
            continue
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_ev = ev
    if not best_ev or best_score < 2:
        return []

    try:
        links = _falcon_match_links(best_ev['href'])
    except Exception as e:
        xbmc.log('[Starfleet/Sports] falconstreams links error: %s' % e, xbmc.LOGWARNING)
        return []
    if not links:
        return []

    team_words = _dl_norm_teams(best_ev['title']) - {'vs'}
    links = [u for u in links if not _falcon_link_mismatched(u, team_words)]
    links = links[:18]   # 50-60 mirrors per game; most are dead hosts that each cost a connect timeout
    if not links:
        return []

    # Real bug fixed 2026-09-13, per a direct report of "no FalconStreams
    # showing" at all for NFL — confirmed live via kodi.log: this call was
    # coming back as "stream source error (falcon): " with an EMPTY
    # message, the unmistakable signature of a bare
    # concurrent.futures.TimeoutError (its str() is ""), meaning
    # get_event_streams()'s own outer `fut.result(timeout=12)` around this
    # WHOLE function was firing before this function ever got a chance to
    # return anything. Root cause: the `with ThreadPoolExecutor(...) as
    # ex: for fut in futs:` pattern here iterates futures in SUBMISSION
    # order and blocks on each one's own `.result(timeout=18)` in turn —
    # with a real match page now confirmed to return 50-60 candidate
    # mirror links (RedZone: 54, a real game: 61) against only
    # max_workers=10, most of those futures are still queued, not even
    # started, by the time the loop reaches them, so a handful of slow or
    # hung candidates near the front of iteration order alone could burn
    # well past the outer 12s budget before this function got anywhere
    # near its own 3-streams-found early exit. Same exact bug (and same
    # fix) already applied to _dl_streams_by_title's own resolve loop
    # elsewhere in this file: as_completed() surfaces whichever future
    # actually finished FIRST regardless of submission order, and an
    # explicit shorter budget here (well under the outer 12s, leaving
    # margin for this function's own earlier _falcon_events()/
    # _falcon_match_links() fetches) means partial results — the
    # candidates that resolve quickly — come back instead of the whole
    # call timing out to nothing.
    streams = []
    # one mirror per host: the same site is listed several times (qualities / away feeds) and each is a full resolve
    import urllib.parse as _up_fk
    _seen_fk = set()
    _uniq_fk = []
    for _u in links:
        _h = _up_fk.urlparse(_u).netloc
        if _h not in _seen_fk:
            _seen_fk.add(_h)
            _uniq_fk.append(_u)
    links = _uniq_fk

    def _falcon_resolve(u):
        # 2026-11-21: the mirrors are mostly other sites' players (PPV/taifood-blog, trendy48, streame.center, embdlol...) that the shared
        # resolver reads; the DaddyLive chain alone resolved none of them. It stays as the fallback for the older mirror style.
        try:
            if 'topstreamer' in u:
                # websocket-published playlists (the relay serves them): only the game-page reader knows that player
                from starfleetscrapers.sports import sports_pages_live as _spl
                _r = _spl.resolve_page(u)
                if _r and _r[0] == 'stream' and _r[1].startswith('http'):
                    return _r[1]
                return None
            import starfleetresolve
            out = starfleetresolve.resolve(u, referer=_FALCON_BASE + '/', debrid_links=False)
            if out:
                return _remint_wrap(out, u)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] falcon resolver: %s' % e, xbmc.LOGINFO)
        return _dl_resolve_embed(u, 6)

    ex = ThreadPoolExecutor(max_workers=min(len(links), 6))
    try:
        futs = {ex.submit(_falcon_resolve, url): url for url in links}
        for fut in as_completed(futs, timeout=10):
            if len(streams) >= 4:
                break
            url = futs[fut]
            try:
                resolved = fut.result()
            except Exception:
                resolved = None
            if resolved:
                import urllib.parse as _up_falcon
                host = _up_falcon.urlparse(url).netloc
                streams.append({
                    'label': 'FalconStreams (%s)' % host,
                    'url': resolved,
                    'quality': '',
                    'language': '',
                    'source': 'FalconStreams',
                })
    except Exception:
        pass
    finally:
        ex.shutdown(wait=False)
    if not streams and WEB_SNIFF:
        # the mirrors are obfuscated players this file cannot read; the app opens them in a hidden web view instead (see WEB_SNIFF)
        import urllib.parse as _up_falcon
        seen_hosts = set()
        for url in links:
            host = _up_falcon.urlparse(url).netloc
            if host in seen_hosts:
                continue
            seen_hosts.add(host)
            streams.append({'label': 'FalconStreams web (%s)' % host, 'url': url, 'quality': '', 'language': '',
                            'source': 'FalconStreams', 'web': True})
            if len(streams) >= 8:
                break
        streams = _alive_web_pages(streams, 4)
        for st in streams:
            WEB_URLS.add(st['url'])
    return streams


# ── FalconStreams NFL — pre-resolved via a real browser on the scraper PC ────
# Added 2026-09-13. _falcon_streams_by_title() above resolves live, in-addon,
# by trying FalconStreams' own dozens of candidate mirror links through this
# file's lightweight requests-based resolver — confirmed live, repeatedly,
# that this has a real reliability ceiling: the small number of backend CDN
# hosts most of those candidates converge on (hamis.romponalis.st, dlive.sx)
# are themselves intermittently or currently fully unreachable, while the
# SAME match visited directly in a real browser plays fine, because the
# site's own client-side JS automatically tries many of its own candidates
# until one connects — something a bare HTTP client fundamentally can't
# replicate. scraper_falconstreams_nfl.py (standalone scraper suite) does
# exactly that instead: points a real headless Chromium (this suite's
# existing EmbedResolver, network-sniffing for the resulting .m3u8) directly
# at each NFL match's own page and lets the page's own JS pick a working
# mirror, unattended, on a schedule — same "resolve once on a real PC,
# addon just reads the result" architecture already used for
# streameast.json/daddylive_sports.json. Covers RedZone and NFL Network too
# (they're just two more entries in FalconStreams' own /api/matches list,
# teamA="NFL Redzone"/"NFL NETWORK", teamB="Live" — no special-casing
# needed in the scraper, matched here the same as any other title).


def _falcon_nfl_prescraped_events():
    """falconstreams_nfl.json is no longer produced (last scrape 2026-09-13); the live sources carry NFL Network and RedZone."""
    return []


def _falcon_nfl_streams_by_title(event_title):
    if not event_title:
        return []
    try:
        events = _falcon_nfl_prescraped_events()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] falcon NFL prescraped index error: %s' % e, xbmc.LOGWARNING)
        return []

    best_ev, best_score = None, 0
    for ev in events:
        for candidate_title in (ev.get('display_title') or '', ev.get('title') or ''):
            score = _title_score(event_title, candidate_title)
            if score > best_score:
                best_score = score
                best_ev = ev
    if not best_ev or best_score < 2:
        return []

    url = best_ev.get('playable_url')
    if not url:
        return []
    return [{
        'label': 'FalconStreams (pre-resolved)',
        'url': url,
        'quality': '',
        'language': '',
        'source': 'falconresolved',
    }]


# ── timstreams.st (clean JSON API — needs no new resolver at all) ────────────
#
# Added 2026-08-10. Its own /api/live-upcoming endpoint is a clean, documented
# REST API (no obfuscation on the schedule side at all) returning real events
# plus a genres/sub_categories list baked right into the same response. Each
# event's streams[].url points at a small embed wrapper (cdx-08192.website
# seen live, likely rotates) whose player init script turns out to be the
# EXACT SAME int-array XOR-cipher (key, then offset, mod 256) already
# decoded by _decode_dlchan_xor_blob()/_dlchan_resolve_mirror() above for
# daddylive.mov's 24/7 channels — confirmed live byte-for-byte identical
# formula. So this needs zero new resolver code: just fetch the schedule and
# hand each stream URL to the resolver that's already shipped.

# The site has moved domains more than once (timstreams.st is gone); try the known ones in order and use the first that answers.
_TIM_DOMAINS = ('https://tim-streams.com', 'https://timst.top', 'https://timstreams.st')
_TIM_BASE = _TIM_DOMAINS[0]
_TIM_API  = _TIM_BASE + '/api/live-upcoming'

# Genre id -> our sport slug (from the API's own /api/live-upcoming 'genres'
# list). Genre 7 "Basketball" covers both NBA and WNBA with no sub-category
# to tell them apart, so that one's resolved by team-name keyword instead.
_TIM_GENRE_MAP = {
    1: 'soccer', 2: 'motorsports', 3: 'ufc', 4: 'boxing', 5: 'boxing',
    6: 'wwe', 8: 'nfl', 9: 'mlb', 10: 'tennis', 11: 'nhl', 12: 'darts',
    13: 'cricket', 15: 'rugby', 16: 'rugby',
}
_TIM_WNBA_KEYWORDS = (
    'wnba', 'storm', 'sky', 'sparks', 'liberty', 'aces', 'lynx',
    'fever', 'mystics', 'mercury', 'sun', 'wings', 'dream', 'tempo',
)

# Genre 2 "Motorsport" has the same no-sub-category problem Basketball's
# genre 7 does above (WNBA/NBA share it) — timstreams' own API has no
# separate F1/MotoGP genre id, so a real Formula 1 or MotoGP race would
# otherwise land in the generic 'motorsports' catch-all instead of the
# addon's own dedicated f1/motogp folders. Same title-keyword split as the
# WNBA case, just two outcomes instead of one.
_RE_TIM_F1     = re.compile(r'\bf1\b|\bformula\s*1\b|\bformula\s+one\b', re.IGNORECASE)
_RE_TIM_MOTOGP = re.compile(r'\bmotogp\b', re.IGNORECASE)


def _tim_map_genre(genre_id, title):
    if genre_id == 7:
        t = (title or '').lower()
        return 'wnba' if any(k in t for k in _TIM_WNBA_KEYWORDS) else 'nba'
    if genre_id == 2:
        if _RE_TIM_F1.search(title or ''):
            return 'f1'
        if _RE_TIM_MOTOGP.search(title or ''):
            return 'motogp'
    return _TIM_GENRE_MAP.get(genre_id)


def _tim_events():
    """Fetch + cache (10 min) timstreams.st's live/upcoming event list."""
    ck = 'tim_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    events = []
    if _site_dead('tim'):
        return []
    try:
        global _TIM_BASE, _TIM_API
        data = None
        for base in (_TIM_BASE,) + tuple(d for d in _TIM_DOMAINS if d != _TIM_BASE):
            try:
                r = _sess().get(base + '/api/live-upcoming', timeout=8, headers=dict(_HEADERS, Referer=base + '/', Accept='application/json'))
                if r.status_code == 200:
                    data = r.json()
                    _TIM_BASE, _TIM_API = base, base + '/api/live-upcoming'
                    break
            except Exception:
                continue
        if data is None:
            raise RuntimeError('no TimStreams domain answered')
        for ev in data.get('events') or []:
            title = ev.get('name') or ''
            if not title:
                continue
            slug = _tim_map_genre(ev.get('genre'), title)
            if not slug:
                continue
            stream_urls = [s.get('url') for s in (ev.get('streams') or []) if s.get('url')]
            if not stream_urls:
                continue
            events.append({'slug': slug, 'title': title, 'streams': stream_urls})
    except Exception as e:
        xbmc.log('[Starfleet/Sports] timstreams events error: %s' % e, xbmc.LOGWARNING)
        _park_site('tim')
        events = []
    _cache.set(ck, events, 10 * 60)
    return events


def _tim_resolve(url):
    """Playable address for one TimStreams stream page. The player frames are served by rotating hosts (ehgembxe.cfd /
    embeds.gay today, cdx-*.website before); Starfleet Resolver reads both generations, the older int-array reader here is
    the fallback."""
    try:
        import starfleetresolve
        out = starfleetresolve.resolve(url, referer=_TIM_BASE + '/', debrid_links=False)
        if out:
            return out
    except Exception as e:
        xbmc.log('[Starfleet/Sports] timstreams resolver: %s' % e, xbmc.LOGWARNING)
    return _dlchan_resolve_mirror(url)


def _tim_playlist_ok(resolved):
    """False when the playlist the resolver found is answered with a server error or "gone" (TimStreams lists a game before its
    feed is on: the playlist then says 502 Upstream error). Anything unclear (no answer, odd reply) counts as playable."""
    try:
        from urllib.parse import unquote
        url, _, hdr = (resolved or '').partition('|')
        if '.m3u8' not in url:
            return True
        headers = {}
        for kv in hdr.split('&'):
            if '=' in kv:
                k, v = kv.split('=', 1)
                headers[unquote(k)] = unquote(v)
        r = _sess().get(url, headers=headers, timeout=6)
        return not (r.status_code >= 500 or r.status_code in (404, 410))
    except Exception:
        return True


def _tim_streams_by_title(sport_slug, event_title):
    """Cross-reference by fuzzy title match, same pattern as the DaddyLive/
    FalconStreams sources above — no separate listing of its own."""
    if not event_title:
        return []
    try:
        events = _tim_events()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] timstreams index error: %s' % e, xbmc.LOGWARNING)
        return []

    best_ev, best_score = None, 0
    for ev in events:
        if ev['slug'] != sport_slug:
            continue
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_ev = ev
    if not best_ev or best_score < 2:
        return []

    streams = []
    with ThreadPoolExecutor(max_workers=min(len(best_ev['streams']), 6)) as ex:
        futs = {ex.submit(_tim_resolve, u): u for u in best_ev['streams']}
        for fut in futs:
            if len(streams) >= 3:
                break
            try:
                resolved = fut.result(timeout=15)
            except Exception:
                resolved = None
            if resolved and _tim_playlist_ok(resolved):
                streams.append({
                    'label': 'TimStreams',
                    'url': resolved,
                    'quality': '',
                    'language': '',
                    'source': 'TimStreams',
                })
    return streams


# ── CDN Live (events with their channel feeds) ────────────────────────────────
#
# The service publishes a plain JSON schedule (api.cdnlivetv.tv/api/v1/events/sports/) in which every fixture lists the TV
# channels carrying it, each with a player page; Starfleet Resolver turns a player page into the signed playlist.

_CDN_API = ('https://api.cdnlivetv.tv', 'https://api.cdnlivetv.is', 'https://api.cdnlivetv.ru')
_CDN_QS = '?user=cdnlivetv&plan=free'
_CDN_CATEGORY_SLUG = {
    'soccer': 'soccer', 'nba': 'nba', 'nfl': 'nfl', 'nhl': 'nhl', 'mlb': 'mlb', 'ncaa': 'cfb', 'ncaaw': 'wnba',
    'tennis': 'tennis', 'golf': 'golf', 'motorsport': 'motorsports', 'ufc': 'ufc', 'mma': 'ufc', 'wwe': 'wwe',
    'cricket': 'cricket', 'rugby': 'rugby', 'darts': 'darts', 'hockey': 'nhl',
}


def _cdn_events():
    """[{'slug', 'title', 'channels': [player page, ...]}] for the fixtures that have channel feeds (cached 10 min)."""
    ck = 'cdn_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    events = []
    if _site_dead('cdnlive'):
        return []
    data = None
    for base in _CDN_API:
        try:
            r = _sess().get(base + '/api/v1/events/sports/' + _CDN_QS, timeout=10, headers=dict(_HEADERS, Accept='application/json'))
            if r.status_code == 200:
                data = (r.json() or {}).get('cdn-live-tv') or {}
                break
        except Exception:
            continue
    if data is None:
        _park_site('cdnlive')
        return []
    for cat, items in data.items():
        slug = _CDN_CATEGORY_SLUG.get(cat.lower())
        if not slug or not isinstance(items, list):
            continue
        for ev in items:
            chans = [c.get('url') for c in (ev.get('channels') or []) if c.get('url')]
            title = ev.get('event') or ''
            if title and chans:
                events.append({'slug': slug, 'title': title, 'channels': chans})
    _cache.set(ck, events, 10 * 60)
    return events


def _cdn_resolve(url):
    try:
        import starfleetresolve
        return starfleetresolve.resolve(url, referer='https://cdnlivetv.tv/', debrid_links=False)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] cdn resolver: %s' % e, xbmc.LOGWARNING)
        return None


def _hubs_streams_by_title(sport_slug, event_title):
    """Event hubs (PPV, ReedStreams, CricHD): see sports_hubs."""
    try:
        from starfleetscrapers.sports import sports_hubs
        return sports_hubs.streams_by_title(sport_slug, event_title)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] event hubs: %s' % e, xbmc.LOGWARNING)
        return []


def _cdn_streams_by_title(sport_slug, event_title):
    if not event_title:
        return []
    best_ev, best_score = None, 0
    for ev in _cdn_events():
        if ev['slug'] != sport_slug:
            continue
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score, best_ev = score, ev
    if not best_ev or best_score < 2:
        return []
    streams = []
    with ThreadPoolExecutor(max_workers=min(len(best_ev['channels']), 6)) as ex:
        futs = [ex.submit(_cdn_resolve, u) for u in best_ev['channels'][:8]]
        for fut in futs:
            if len(streams) >= 3:
                break
            try:
                resolved = fut.result(timeout=15)
            except Exception:
                resolved = None
            if resolved:
                streams.append({'label': 'CDN Live', 'url': resolved, 'quality': '', 'language': '', 'source': 'CDN Live'})
    return streams


# ── cinevid.sbs (free live events; the player is built by script, so the app's web view digs the stream out) ──

_CINEVID = 'https://cinevid.sbs'


def _cinevid_events():
    """[{'title', 'sport', 'league', 'status', 'page'}] of the events Cinevid lists (cached 2 min)."""
    ck = 'cinevid_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    out = []
    try:
        r = _sess().get(_CINEVID + '/api/public/events', timeout=6, headers=dict(_HEADERS, Accept='application/json'))
        if r.status_code == 200:
            data = r.json() or {}
            for ev in (data.get('events') if isinstance(data, dict) else data) or []:
                pu = ev.get('playerUrl') or ''
                if ev.get('title') and pu:
                    out.append({'title': ev['title'], 'sport': ev.get('sport') or '', 'league': ev.get('league') or '',
                                'status': ev.get('status') or '', 'page': pu if pu.startswith('http') else _CINEVID + pu})
    except Exception as e:
        xbmc.log('[Starfleet/Sports] cinevid events error: %s' % e, xbmc.LOGINFO)
    _cache.set(ck, out, 120 if out else 45)
    return out


def _cinevid_streams_by_title(sport_slug, event_title):
    """The live Cinevid player page for this game. Only offered where a web view exists to run the page (HAZMAT_WEBVIEW)."""
    return []   # 2026-11-21: the page never gave the web view a stream; the same event's channels come direct from vidcdn.vip (the Hoofoot source)
    words = [w for w in re.split(r'\W+', _strip_score(event_title)) if len(w) >= 3]
    need = max(2, min(len(words), 4))
    best, best_score = None, 0
    for ev in _cinevid_events():
        if ev['status'].lower() != 'live':
            continue
        score = _title_score(event_title, ev['title'])
        if score >= need and score > best_score:
            best, best_score = ev, score
    if not best:
        return []
    WEB_URLS.add(best['page'])
    return [{'label': 'Cinevid (web)', 'url': best['page'], 'quality': '', 'language': '', 'source': 'Cinevid', 'web': True}]


# ── Match feed playlist (event-named HLS list with its own request headers) ───

_FEED_URLS = ('https://fawasp.pages.dev/playlist.txt',)
_RE_FEED = re.compile(r'#EXTINF:[^\r\n,]*,([^\r\n]*)\r?\n((?:#EXTVLCOPT[^\r\n]*\r?\n)*)(https?://[^\r\n]+)')


def _feed_entries():
    ck = 'feed_entries_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    out = []
    for feed in _FEED_URLS:
        try:
            r = _sess().get(feed, timeout=10, headers=_HEADERS)
            if r.status_code != 200:
                continue
        except Exception:
            continue
        for name, opts, url in _RE_FEED.findall(r.text):
            hdr = {}
            m = re.search(r'http-referrer=(\S+)', opts)
            if m:
                hdr['Referer'] = m.group(1)
            m = re.search(r'http-origin=(\S+)', opts)
            if m:
                hdr['Origin'] = m.group(1)
            m = re.search(r'http-user-agent=([^\r\n]+)', opts)
            if m:
                hdr['User-Agent'] = m.group(1).strip()
            out.append({'title': re.sub(r'\s*-+\s*CH\s*\d+\s*$', '', name.strip(), flags=re.I), 'label': name.strip(),
                        'url': url.strip(), 'headers': hdr})
    _cache.set(ck, out, 5 * 60)
    return out


def _feed_pipe(entry):
    h = dict(entry['headers'])
    h.setdefault('User-Agent', _HEADERS.get('User-Agent', 'Mozilla/5.0'))
    from urllib.parse import quote
    return '%s|%s' % (entry['url'], '&'.join('%s=%s' % (k, quote(v, safe='')) for k, v in h.items()))


def _feed_alive(piped):
    try:
        import starfleetresolve
        return starfleetresolve.common.playlist_ok(piped, timeout=6)
    except Exception:
        return False


def _feed_streams_by_title(sport_slug, event_title):
    if not event_title:
        return []
    hits = [e for e in _feed_entries() if _title_score(event_title, e['title']) >= 2 and _title_score(e['title'], event_title) >= 2]
    if not hits:
        return []
    pipes = [_feed_pipe(e) for e in hits[:6]]
    streams = []
    with ThreadPoolExecutor(max_workers=len(pipes)) as ex:
        for e, piped, ok in zip(hits, pipes, ex.map(_feed_alive, pipes)):
            if ok:
                streams.append({'label': 'Match Feed', 'url': piped, 'quality': '', 'language': '', 'source': 'Match Feed'})
    return streams


# ── v2.sportsurge.net (Cloudflare Turnstile-gated aggregator) ─────────────────
#
# This site has the real, complete per-game provider table (StreamEast,
# CrackStreams, all the branded resellers, etc) — but it's behind Cloudflare
# Turnstile, which genuinely can't be solved by a script (verified multiple
# ways: cloudscraper's own challenge detectors don't even recognize this
# page's current markup; TLS-fingerprint spoofing still gets the challenge
# page). The one legitimate way through: a real browser passes Turnstile on
# its own, and the cf_clearance cookie it earns is reusable for a while
# (Cloudflare issues it per-session, not per-request). The user pastes that
# cookie (DevTools -> Application -> Cookies -> cf_clearance) into this
# addon's settings; while it's still valid, this scrapes the real listing
# and provider table. Once it expires this source just finds nothing, same
# as any other source with nothing to offer — no crash, no error shown.

_SPORTSURGE_BASE = 'https://v2.sportsurge.net'
_SPORTSURGE_SLUGS = {
    'nfl': 'list6-nfl', 'nba': 'list6-basketball', 'mlb': 'list6-baseball',
    'nhl': 'list6-hockey', 'boxing': 'list6-boxing', 'mma': 'list6-mma',
    'wwe': 'list6-wwe', 'cfb': 'list6-cfb', 'cfl': 'list6-cfl',
    'ncaab': 'list6-ncaab', 'wnba': 'list6-wnba', 'f1': 'list6-f1',
}

# Confirmed live 2026-08-09 both of these were completely broken (0 matches
# each) against the site's CURRENT html — not a Cloudflare/cookie problem,
# a real markup drift. Game rows now use class="match-row" (no "row "
# prefix the old regex required, with extra data-category/data-search
# attributes in between class and title that broke the old immediately-
# adjacent match too). Stream rows dropped the old '<h4>name</h4>' entirely
# in favor of double-quoted data-href + a nested
# <span class="stream-row-site-name">name</span> — found by directly
# inspecting a real, live watch page (MLB Guardians @ White Sox) after a
# user report that a genuinely live game wasn't showing up; confirmed the
# game and its real stream list (24 sources, including Streameast) really
# are on the page, the old regexes just couldn't see any of it.
_RE_SPORTSURGE_GAME = re.compile(
    r'href="(watch-\d+-[^"]+)"\s+class="match-row"[^>]*?title="([^"]+)"'
)
_RE_SPORTSURGE_ROW = re.compile(
    r'data-href="([^"]+)"[^>]*>.*?<span class="stream-row-site-name">([^<]+)</span>',
    re.DOTALL
)


_SPORTSURGE_AUTO_COOKIE_URL = 'https://hazmat77.github.io/repository.starfleet/data/sportsurge_cookie.json'


_SPORTSURGE_DEVICE = ('', '')


def set_sportsurge_clearance(cookie, ua):
    """The Cloudflare clearance the app's own web view earned on v2.sportsurge.net (cookie + the exact user agent it was issued to).
    Used before the scraper-PC cookie; replaces any earlier one and forgets the cached 'no events' answers made without it."""
    global _SPORTSURGE_DEVICE
    _SPORTSURGE_DEVICE = ((cookie or '').strip(), (ua or '').strip())
    for k in ('sportsurge_events_soccer',):
        try:
            _cache.set(k, None, 1)
        except Exception:
            pass
    return 'ok' if _SPORTSURGE_DEVICE[0] else ''


def _sportsurge_auto_cookie():
    """The scraper-PC-refreshed cf_clearance+UA pair (scraper_sportsurge_
    cookie.py — real headed Chrome, refreshed every ~2h, confirmed live to
    reliably pass v2.sportsurge.net's Cloudflare Managed Challenge, which no
    headless/automated approach could). Cached 30 min so ordinary sports
    browsing doesn't refetch this on every single menu click. Returns
    ('', '') on any failure so the caller falls back to the manually-pasted
    Settings value cleanly."""
    ck = 'sportsurge_auto_cookie_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    result = ('', '')
    try:
        r = _req.get(_SPORTSURGE_AUTO_COOKIE_URL, timeout=8)
        r.raise_for_status()
        data = r.json()
        cf = (data.get('cf_clearance') or '').strip()
        ua = (data.get('user_agent') or '').strip()
        if cf:
            result = (cf, ua)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] sportsurge auto-cookie fetch error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, result, 30 * 60)
    return result


def _sportsurge_get(path):
    """GET a v2.sportsurge.net path using a cf_clearance cookie — prefers
    the auto-refreshed one (see _sportsurge_auto_cookie) and falls back to
    the manually-pasted Settings value if that's unavailable. Returns None
    if neither is configured, or the cookie is expired/invalid (still gets
    the Cloudflare challenge page back) — callers must treat that exactly
    like any other source finding nothing, not an error."""
    cookie, ua = _SPORTSURGE_DEVICE
    if not cookie:                                   # what a person earned on this device (Verify screen) comes first
        try:
            from starfleetscrapers.core import http as _sfhttp
            cookie, ua = _sfhttp.clearance('sportsurge')
        except Exception:
            cookie, ua = '', ''
    if not cookie:
        cookie, ua = _sportsurge_auto_cookie()
    if not cookie:
        cookie = (ADDON.getSetting('sportsurge_cf_cookie') or '').strip()
        ua = (ADDON.getSetting('sportsurge_ua') or '').strip()
    if not cookie:
        return None
    ua = ua or _HEADERS['User-Agent']
    url = path if path.startswith('http') else _SPORTSURGE_BASE + '/' + path.lstrip('/')
    try:
        r = _sess().get(url, cookies={'cf_clearance': cookie},
                         headers=dict(_HEADERS, **{'User-Agent': ua}), timeout=12)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] sportsurge fetch error: %s' % e, xbmc.LOGWARNING)
        return None
    if r.status_code != 200 or 'Just a moment' in r.text[:2000]:
        xbmc.log('[Starfleet/Sports] sportsurge cf_clearance cookie missing/expired', xbmc.LOGWARNING)
        try:
            from starfleetscrapers.core import http as _sfhttp
            if _sfhttp.clearance('sportsurge')[0] == cookie:
                _sfhttp.mark_bad('sportsurge')
        except Exception:
            pass
        return None
    return r.text


_RE_SPORTSURGE_SOCCER_GAME = re.compile(
    r'href="(https?://soccersurge\.io/watch-\d+-[^"]+)"[^>]*?class="match-row"'
    r'[^>]*?data-category="26"[^>]*?title="([^"]+)"'
)


def _sportsurge_soccer_events():
    """Soccer isn't its own list6-* page on v2.sportsurge.net like every
    other sport here (confirmed live: list6-soccer/list6-football both
    just 301-redirect back to the homepage, 0 real content). Soccer games
    only appear mixed into the homepage's own combined listing
    (v2.sportsurge.net/), each row tagged data-category="26" and linking to
    a COMPLETELY DIFFERENT domain (soccersurge.io) instead of a relative
    v2.sportsurge.net path like every other sport uses — _sportsurge_get
    already passes an absolute http(s) URL through unchanged, so no other
    plumbing needed to change. soccersurge.io itself isn't behind the same
    Cloudflare challenge v2.sportsurge.net is (confirmed live: 200 with no
    cookie at all), so its own watch pages don't need the cf_clearance
    cookie either — only the initial v2.sportsurge.net homepage fetch does."""
    ck = 'sportsurge_events_soccer'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    html = _sportsurge_get('')
    if not html:
        return []
    events = []
    seen = set()
    for href, title in _RE_SPORTSURGE_SOCCER_GAME.findall(html):
        if href in seen:
            continue
        seen.add(href)
        events.append({
            'id': 'sportsurge_' + href, 'slug': href, 'path': 'sportsurge:' + href,
            'title': title, 'league': 'SOCCER', 'logo': '',
            'is_live': True, 'start_ts': 0, 'datetime': '',
        })
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] sportsurge soccer: %d events' % len(events), xbmc.LOGINFO)
    return events


def _sportsurge_events(sport_slug):
    if sport_slug == 'soccer':
        return _sportsurge_soccer_events()
    seg = _SPORTSURGE_SLUGS.get(sport_slug)
    if not seg:
        return []
    ck = 'sportsurge_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    html = _sportsurge_get(seg)
    if not html:
        return []
    events = []
    seen = set()
    for path, title in _RE_SPORTSURGE_GAME.findall(html):
        if path in seen:
            continue
        seen.add(path)
        events.append({
            'id': 'sportsurge_' + path, 'slug': path, 'path': 'sportsurge:' + path,
            'title': title, 'league': sport_slug.upper(), 'logo': '',
            'is_live': True, 'start_ts': 0, 'datetime': '',
        })
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] sportsurge %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _sportsurge_try_resolve(href):
    """Actually resolve href to a real playable stream using the exact same
    chain sports_router._play_stream() uses at play time (ResolveURL, then
    embed_resolver's generic iframe-chain follower — the latter is what
    already handles resports.cfd's 3-hop wrapper live). Returns a
    pipe-tagged 'url|Referer=...' string (this codebase's existing
    convention for a pre-resolved stream, same as DaddyLive/FalconStreams)
    or None if nothing on this addon's Python-only resolve chain can
    extract a real stream from it — which is exactly what makes most of
    SportSurge's ~20 embed rows (Stream 1/2/3, Alpha, NBCSports, etc.) dead
    links here: they need real JS execution this addon can't do."""
    try:
        from starfleetscrapers import host as _sfhost; resolveurl = _sfhost.module('sf_resolve')
        hmf = resolveurl.HostedMediaFile(href)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                return r
    except ImportError:
        pass
    except Exception:
        pass

    try:
        from starfleetscrapers.core import embed_resolver as embed_resolver
        stream, referer = embed_resolver.resolve_generic_iframe_chain(href)
        if stream:
            if referer:
                from urllib.parse import quote as _uq
                return '%s|Referer=%s' % (stream, _uq(referer, safe=''))
            return stream
    except Exception:
        pass
    return None


def _sportsurge_streams_for_path(path):
    _t0 = time.time()
    html = _sportsurge_get(path)
    _t_page = time.time() - _t0
    if not html:
        return []
    candidates, seen = [], set()
    for href, name in _RE_SPORTSURGE_ROW.findall(html):
        if href in seen:
            continue
        seen.add(href)
        candidates.append((href, name.strip()))
    if not candidates:
        return []

    # Only show rows that actually resolve to a real stream — per explicit
    # instruction, better than a hardcoded name whitelist (resports/bally)
    # since it self-corrects if those break or a new working source shows
    # up, instead of silently going stale. Resolved concurrently with a
    # tight 10s overall cap (matches this session's "reasonable timeout"
    # standard for the unified search) — not a 'with' block, same reason as
    # every other pool in this codebase: shutdown(wait=False) so a
    # straggler resolve can't hold the picker open past the cutoff.
    streams = []
    _t1 = time.time()
    pool = ThreadPoolExecutor(max_workers=min(len(candidates), 15))
    try:
        futures = {pool.submit(_sportsurge_try_resolve, href): (href, name) for href, name in candidates}
        for future in as_completed(futures, timeout=7):
            href, name = futures[future]
            try:
                resolved = future.result()
            except Exception:
                resolved = None
            if resolved:
                streams.append({
                    'label': name, 'url': resolved, 'quality': '', 'language': '',
                    'source': 'SportSurge',
                })
    except Exception as e:
        xbmc.log('[Starfleet/Sports] sportsurge resolve timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)
    try:
        xbmc.log('[Starfleet/Sports] sportsurge: %d rows, page %.1fs, resolve %.1fs, resolved %d: %s' % (len(candidates), _t_page, time.time() - _t1, len(streams), ' ; '.join(
            '%s=%s' % (s['label'], s['url'][:170]) for s in streams)), xbmc.LOGWARNING)
    except Exception:
        pass
    if WEB_SNIFF and len(streams) < 6:
        # rows whose player needs real JavaScript: the app opens the page in a hidden web view and takes the stream from it
        have = {x['label'] for x in streams}
        extra = 0
        web = []
        for href, name in candidates:
            if name in have or extra >= 8:
                continue
            extra += 1
            web.append({'label': '%s (web)' % name, 'url': href, 'quality': '', 'language': '',
                        'source': 'SportSurge', 'web': True})
        for st in _alive_web_pages(web, 4):
            streams.append(st)
            WEB_URLS.add(st['url'])
    return streams


def _sportsurge_streams_by_title(sport_slug, event_title):
    evs = _sportsurge_events(sport_slug)
    if not evs:
        return []
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = ev['slug']
    if not best_path or best_score < 2:
        return []
    return _sportsurge_streams_for_path(best_path)


# ── livetv902.me (livetv.sx family) ───────────────────────────────────────────
#
# Chain first built and verified live against a real CFL game, 2026-07-23.
#
# UPDATE 2026-08-20 — site restructured since then, confirmed live with a
# direct report this had stopped working: the mirror-listing endpoint
# (/player/links/ru/<eid>) now serves every link as type=ifr, on a
# renumbered domain (livetv903.me instead of livetv902.me for the link
# hrefs specifically — the main listing page itself is still reachable at
# the original livetv902.me) — the alieztv type this resolver was
# originally built for no longer appears at all, confirmed across
# multiple real events, not just one. Rather than assume the old "ifr
# wasn't confirmed working, skipped" note from 2026-07-23 still applied,
# traced where ifr actually goes this time: webplayer2.php?t=ifr's own
# iframe src is one of two real hosts, both resolving to a genuinely
# playable HLS URL with zero JS execution needed —
#   dlstreams.st (itself just DaddyLive/DLHD's current domain, confirmed
#     by its own site branding and public API docs at dlstreams.st/
#     api.php — the same DaddyLive family this codebase already has
#     extensive scraper support for elsewhere, just a different current
#     mirror domain): /stream/stream-<id>.php embeds the real master
#     m3u8 as a plain base64 string passed to
#     Clappr.Player({source: window.atob('...')}) — trivial regex + decode.
#   vivtops.st: one further hop (its own iframe points at
#     universaltokenforall.st/player<N>/<slug>) whose page assigns the
#     real, already token-signed m3u8 to a plain JS
#     `let streamUrl = "..."` string literal — same trivial extraction,
#     not even a decode step, just unescaping the JS string's own
#     escaped slashes.
# A third mirror type seen in the same listing (vdocity.com) uses Cloudflare
# Turnstile — a real bot-challenge, not attempted, consistent with this
# codebase's existing policy on other Turnstile/Cloudflare-gated sources.
# The domain the /player/links/ru/<eid> page hands back for each mirror is
# captured directly from its own href rather than hardcoded, since this
# site has already renumbered once and may again. Listing times are in
# Moscow time (site's own locale); not converted here, used only for
# matching, not display.

LIVETV902_BASE = 'https://livetv902.me'

_RE_LIVETV902_ROW = re.compile(
    r'<span class="cmp">([^<]*)</span>\s*<br>\s*<span class="spr">([^<]*)</span>.*?'
    r'href="/gowm\.php\?lid=(\d+)&eid=(\d+)"[^>]*>([^<]+)</a>',
    re.DOTALL
)
_RE_LIVETV902_LINK = re.compile(
    r'href="//(livetv90\d\.me)/webplayer2\.php\?t=(alieztv|ifr)&c=(\d+)&lang=ru&eid=(\d+)&lid=(\d+)&'
)
_RE_LIVETV902_EMBED = re.compile(r'(emb\.apl\d+\.me)/player/live\.php\?id=(\d+)')
_RE_LIVETV902_M3U8   = re.compile(r"pl\.init\('(//[^']+\.m3u8[^']*)'\)")
_RE_LIVETV902_IFRAME_SRC = re.compile(r'<iframe[^>]*\bsrc="(https://[^"]+)"')
_RE_DLSTREAMS_ATOB       = re.compile(r"atob\('([^']+)'\)")
_RE_VIVTOPS_STREAMURL    = re.compile(r'streamUrl\s*=\s*"([^"]+)"')


def _livetv902_verify_m3u8(sess, m3u8, referer):
    """Real bug fixed 2026-09-04: this used to GET the m3u8 itself to
    confirm it actually worked before returning it — confirmed live via
    kodi.log that this exact CDN family (xameleon.*.top, reached through
    dlstreams.st's own hamis.*.st/premiumtv/daddy3.php referer chain) 403s
    Kodi's own real playback fetch immediately after this same verify GET
    already succeeded: CCurlFile::Stat failed with error(22), then
    inputstream.adaptive got a flat HTTP 403 on the identical URL a moment
    later. Same root cause and same fix as the OK.ru replay bug fixed
    earlier this session (see local_proxy.py's own history) — a signed/
    session-pinned CDN URL only tolerates ONE real connection, and this
    verify step was quietly spending that one connection before the real
    player ever got a turn. Trust the decoded URL directly instead."""
    import urllib.parse as _up4
    return m3u8 + '|Referer=%s' % _up4.quote(referer, safe='')


_HOST_DOWN_TTL = 180


def _site_dead(name):
    """True while a site that failed outright (name not found, certificate error, unreadable answer) is parked.
    Kept on disk: every plugin action is a fresh process."""
    return bool(_cache.get('site_dead_%s' % name))


def _park_site(name, minutes=30):
    _cache.set('site_dead_%s' % name, True, minutes * 60)


def _host_marked_down(host):
    """True if a recent connect to `host` failed outright. Lives in the
    on-disk cache (not a module global) because Kodi runs each plugin
    action in a fresh process, so an in-memory flag would never carry from
    one play attempt to the next."""
    return bool(host and _cache.get('host_down_%s' % host))


def _mark_host_down(host):
    if host:
        _cache.set('host_down_%s' % host, True, _HOST_DOWN_TTL)


def _dlhd_channel_via_api(channel_id):
    """A DaddyLive channel number resolved through the tvnow247 service (it numbers its channels exactly like DLHD): a signed playlist
    in about 3 s, where the site's own players take 5-25 s to answer, or do not. None when the channel has no live feed right now."""
    if not str(channel_id).isdigit():
        return None
    from starfleetscrapers.core import dns_fallback as _dnsf
    try:
        data = _dnsf.get(_TVNOW_STREAM_API % channel_id, timeout=6, headers=_HEADERS).json()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] DLHD channel API (%s): %s' % (channel_id, e), xbmc.LOGINFO)
        return None
    playlist_url = data.get('proxyPlaylistUrl') or data.get('m3u8')
    if not playlist_url:
        return None
    try:
        check = _dnsf.get(playlist_url, timeout=6, headers=_HEADERS)
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            return None
    except Exception:
        return None
    return playlist_url


def _livetv902_resolve_dlstreams(iframe_url):
    from urllib.parse import urlparse as _urlparse
    _host = _urlparse(iframe_url).netloc
    # the fast route first: the channel number through the tvnow247 service (independent of the site's own, often unreachable, players)
    try:
        from starfleetscrapers.sports import dlhd_players as _dlpa
        _cida = _dlpa.channel_id_from_url(iframe_url)
        if _cida:
            _fast = _dlhd_channel_via_api(_cida)
            if _fast:
                xbmc.log('[Starfleet/Sports] dlstreams %s resolved via the channel service' % _cida, xbmc.LOGINFO)
                return _fast
    except Exception as _e:
        xbmc.log('[Starfleet/Sports] dlstreams channel service: %s' % _e, xbmc.LOGINFO)
    # Confirmed live 2026-09-19: dlive.sx's backend (213.21.239.30) stopped
    # accepting connections entirely (TCP timeout from a PC, connection
    # refused from the Firestick — while the same box still answers ping), and
    # every source that funnels through this function (DaddyLive channel
    # paths, tvnow, livetv902, the NFL Network/RedZone fast-path) then burned
    # its full 8s timeout PER CALL before failing — which also starved
    # unrelated, healthy sources (e.g. SportSurge) out of the shared result
    # deadline. One failed connect now marks the host down for 3 minutes so
    # every other caller fails instantly instead.
    if _host_marked_down(_host):
        return None
    # An address of the site that no longer exists (dlive.sx, dlstreams.st ...) is followed to where it lives now.
    try:
        from starfleetscrapers.sports import dlhd_players as _dlp0
        if _dlp0.channel_id_from_url(iframe_url) and _host in ('dlive.sx', 'dlstreams.st', 'dlhd.dad', 'dlhd.net'):
            _host = _urlparse(_dlp0.active_base('%s://%s' % (_urlparse(iframe_url).scheme or 'https', _host))).netloc
    except Exception:
        pass
    # The site now offers six player wrappers per channel (watch.php?id=N); each has its
    # own small decoder in dlhd_players, tried in turn until one gives a live playlist.
    try:
        from starfleetscrapers.sports import dlhd_players as _dlp
        _cid = _dlp.channel_id_from_url(iframe_url)
        if _cid:
            _res = _dlp.resolve_channel(_cid, base='%s://%s' % (_urlparse(iframe_url).scheme or 'https', _host))
            if _res:
                xbmc.log('[Starfleet/Sports] dlstreams %s resolved via player "%s"' % (_cid, _res['player']),
                         xbmc.LOGINFO)
                return _res['url']
    except _req.exceptions.ConnectionError:
        _mark_host_down(_host)
        return None
    except Exception as _e:
        xbmc.log('[Starfleet/Sports] dlstreams player resolver: %s' % _e, xbmc.LOGINFO)
    # Confirmed live 2026-09-25: the site is back up but its stream pages were
    # rebuilt - /stream/stream-<id>.php now iframes a clappr player page
    # (assetrage.net/e/<id>) whose playlist sits in a `_econfig` blob, not the
    # old base64 atob() page below. The generic iframe-chain resolver already
    # used for the live-sports providers decodes exactly that shape, so try it
    # first and keep the older path as the fallback.
    try:
        from starfleetscrapers.sports import sports_starfleet_live as _sl
        _direct = _sl.resolve_link(iframe_url)
        if _direct:
            return _direct
    except Exception as _e:
        xbmc.log('[Starfleet/Sports] dlstreams chain resolver: %s' % _e, xbmc.LOGINFO)
    sess = _req.Session()
    try:
        html = sess.get(iframe_url, timeout=(4, 8), headers=dict(_HEADERS, Referer=LIVETV902_BASE + '/')).text
    except _req.exceptions.ConnectionError:
        _mark_host_down(_host)
        return None
    except Exception:
        return None
    # dlstreams.st/stream/stream-<id>.php is itself one more wrapper — its
    # own iframe points at the real player page (a daddy3.php-style embed)
    # where the base64 atob(...) call actually lives, confirmed live this
    # is always one hop deeper, never inline on this page directly.
    m0 = _RE_LIVETV902_IFRAME_SRC.search(html)
    if not m0:
        return None
    deep_url = m0.group(1)
    # Retry added 2026-09-13, per a direct report of RedZone/NFL Network/
    # game streams all failing to resolve — confirmed live via kodi.log
    # AND a direct repro that this specific hop's host (a hamis.*.st-style
    # mirror) is genuinely, intermittently flaky under real concurrent
    # load: 3 isolated back-to-back requests came back
    # timeout/200-in-3.7s/200-in-0.8s. A single unconditional 8s timeout
    # with no second chance was turning a transient hiccup into a total
    # failure for every caller of this shared function (NHL/MLB Network,
    # and the new RedZone/NFL Network/daddylive fast-path all funnel
    # through here) — one quick retry covers the common case without
    # meaningfully punishing the case where the host is genuinely down.
    html2 = None
    for attempt in range(2):
        try:
            html2 = sess.get(deep_url, timeout=8, headers=dict(_HEADERS, Referer=iframe_url)).text
            break
        except Exception as e:
            if attempt == 0:
                xbmc.log('[Starfleet/Sports] dlstreams deep_url attempt 1 failed, retrying once (%s): %s'
                         % (deep_url, e), xbmc.LOGINFO)
                continue
            xbmc.log('[Starfleet/Sports] dlstreams deep_url failed twice (%s): %s' % (deep_url, e), xbmc.LOGWARNING)
            return None
    if html2 is None:
        return None
    m = _RE_DLSTREAMS_ATOB.search(html2)
    if not m:
        return None
    try:
        m3u8 = base64.b64decode(m.group(1)).decode('utf-8')
    except Exception:
        return None
    return _livetv902_verify_m3u8(sess, m3u8, deep_url)


def _livetv902_resolve_vivtops(iframe_url):
    sess = _req.Session()
    try:
        html = sess.get(iframe_url, timeout=8, headers=dict(_HEADERS, Referer=LIVETV902_BASE + '/')).text
    except Exception:
        return None
    m2 = _RE_LIVETV902_IFRAME_SRC.search(html)
    if not m2:
        return None
    deep_url = m2.group(1)
    try:
        html2 = sess.get(deep_url, timeout=8, headers=dict(_HEADERS, Referer=iframe_url)).text
    except Exception:
        return None
    m3 = _RE_VIVTOPS_STREAMURL.search(html2)
    if not m3:
        return None
    m3u8 = m3.group(1).replace('\\/', '/')
    return _livetv902_verify_m3u8(sess, m3u8, deep_url)


def _livetv902_resolve_ifr(domain, c_val, eid, lid):
    """webplayer2.php?t=ifr -> its own iframe points at either dlstreams.st
    or vivtops.st (see module comment above) -> real HLS URL."""
    referer = '%s/player/links/ru/%s' % (LIVETV902_BASE, eid)
    url = 'https://%s/webplayer2.php?t=ifr&c=%s&lang=ru&eid=%s&lid=%s&ci=64&si=1' % (
        domain, c_val, eid, lid)
    try:
        html = _req.get(url, timeout=8, headers=dict(_HEADERS, Referer=referer)).text
    except Exception:
        return None
    m = _RE_LIVETV902_IFRAME_SRC.search(html)
    if not m:
        return None
    iframe_url = m.group(1)
    if 'dlstreams.st' in iframe_url:
        return _livetv902_resolve_dlstreams(iframe_url)
    if 'vivtops.st' in iframe_url:
        return _livetv902_resolve_vivtops(iframe_url)
    return None


def _livetv902_events():
    ck = 'livetv902_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _sess().get(LIVETV902_BASE + '/export/webmasters.php?lang=en',
                            timeout=10, headers=_HEADERS).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] livetv902 events error: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for m in _RE_LIVETV902_ROW.finditer(html):
        comp, sport, lid, eid, title = m.groups()
        events.append({
            'competition': _clean(comp),
            'sport':       _clean(sport),
            'lid':         lid,
            'eid':         eid,
            'title':       _clean(title).replace('–', 'vs').replace('-', 'vs'),
        })
    xbmc.log('[Starfleet/Sports] livetv902: %d events' % len(events), xbmc.LOGINFO)
    _cache.set(ck, events, 5 * 60)
    return events


def _livetv902_streams_by_title(event_title):
    """Find the best-matching event across every sport this site carries,
    then resolve every alieztv mirror it offers (not just the first) —
    returns one stream entry per working mirror, labeled Link 1/2/3."""
    try:
        events = _livetv902_events()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] livetv902_streams_by_title error: %s' % e, xbmc.LOGWARNING)
        return []

    best_eid, best_score = None, 0
    for ev in events:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_eid = ev['eid']
    if not best_eid or best_score < 2:
        return []

    try:
        links_html = _req.get(
            '%s/player/links/ru/%s?t=%d' % (LIVETV902_BASE, best_eid, int(time.time())),
            timeout=8, headers=dict(_HEADERS, Referer=LIVETV902_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] livetv902 links page error: %s' % e, xbmc.LOGWARNING)
        return []

    # UPDATE 2026-08-20 — filters for 'ifr' now, not 'alieztv' (see module
    # comment above for why); domain comes from each link's own href, not
    # LIVETV902_BASE, since the site has already renumbered its link
    # domain once independently of the main listing page's own domain.
    candidates = [(domain, c, lid) for (domain, t, c, _eid, lid) in _RE_LIVETV902_LINK.findall(links_html)
                  if t == 'ifr']
    if not candidates:
        return []

    streams = [None] * len(candidates)
    with ThreadPoolExecutor(max_workers=len(candidates)) as ex:
        futs = {ex.submit(_livetv902_resolve_ifr, domain, c, best_eid, lid): i
                for i, (domain, c, lid) in enumerate(candidates)}
        for fut in futs:
            i = futs[fut]
            try:
                streams[i] = fut.result(timeout=10)
            except Exception:
                pass

    return [
        {'label': 'Link %d' % (i + 1), 'url': u, 'quality': '', 'language': '', 'source': 'LiveTV'}
        for i, u in enumerate(streams) if u
    ]


# ── hoofoot.ru (livetv.sx-family aggregator, own clean HLS proxy) ─────────────
#
# Own frontend over the same backend data as livetv902.me above (confirmed
# live: team logos served from cdn.livetv902.me), but exposed as a much
# cleaner JSON API instead of raw HTML tables. Both /api/events and
# /api/main-server?id=<eventId> return {"iv":..., "encrypted":...} — looks
# like a real barrier, but the site's own schedule.js ships the decryption
# key in plain text (literally commented "CORRECT ENCRYPTION KEY" — see
# resources/lib/aes128.py, a hand-rolled AES-128-CBC decrypt-only
# implementation added purely because Kodi's bundled Python has no
# pycryptodome/cryptography to reach for). Decrypted per-event channel URLs
# are one of: a YouTube embed (trivial), or a same-domain /ltv?id=... or
# /gl?id=... path that is ALREADY a real, directly playable HLS URL
# (confirmed live: /ltv returns a plain media playlist, /gl returns a proper
# HLS master playlist referencing further /gl variants) — no further
# resolution step needed either way, no browser required. Raw event
# Date/Time fields are Moscow time (confirmed live: every currently-"Live"
# event's raw time sits ~3h ahead of true UTC), same as livetv902's own
# export page above.

# 2026-11-21: hoofoot.ru's registration expired and hoofoot.net became a highlights-only site, but the same live feed (same /api/events, /api/main-server
# and /ltv playlists) is served by vidcdn.vip - the backend Cinevid's player page reads - so the source lives on there.
HOOFOOT_BASE        = 'https://vidcdn.vip'
_HOOFOOT_ALIVE      = True
_HOOFOOT_KEY         = bytes.fromhex('a7f3e9c2d4b8f1a6c3e7d9b2f4a8c1e5')
_HOOFOOT_MSK_OFFSET  = 3 * 3600  # Moscow = UTC+3 year-round (no DST since 2014)

# Sport-events-only scope (per explicit instruction): hoofoot's own "Sport"
# label -> our category slug. Deliberately excluded from this map: 'TV Show'
# (separate TMDB-matched feed, out of scope this round), 'Gambling' (not a
# sport). Labels with no matching category ('Watersports', 'Softball',
# 'Horse Racing', 'Other') aren't dropped — they feed the existing
# Other/International catch-all instead, via _hoofoot_other_events() below.
_HOOFOOT_SPORT_MAP = {
    'Football':   'soccer',
    'Baseball':   'mlb',
    'Basketball': 'nba',
    'Ice Hockey': 'nhl',
    'Tennis':     'tennis',
    'Handball':   'handball',
    'Cricket':    'cricket',
    'Volleyball': 'volleyball',
    'Cycling':    'cycling',
    'Golf':       'golf',
    'Snooker':    'snooker',
    'Fighting':   'ufc',
}


def _hoofoot_decrypt(payload):
    # 2026-10-02: /api/events and /api/main-server now answer plain JSON (no
    # {"iv","encrypted"} envelope any more - the old code died on KeyError 'iv'
    # and hoofoot contributed nothing). Accept both so a return of the
    # encrypted form keeps working too.
    if isinstance(payload, dict) and 'iv' not in payload:
        return payload
    import json as _json_hf
    import base64 as _b64_hf
    from starfleetscrapers.core import aes128 as _aes128_hf
    iv = _b64_hf.b64decode(payload['iv'])
    ct = _b64_hf.b64decode(payload['encrypted'])
    return _json_hf.loads(_aes128_hf.decrypt_cbc(_HOOFOOT_KEY, iv, ct).decode('utf-8'))


@_cache.coalesced
def _hoofoot_all_events():
    ck = 'hoofoot_events_v1'
    if not _HOOFOOT_ALIVE:
        return []
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    if _site_dead('hoofoot'):
        return []
    try:
        r = _sess().get(HOOFOOT_BASE + '/api/events', timeout=10, headers=_HEADERS)
        data = _hoofoot_decrypt(r.json())
    except Exception as e:
        xbmc.log('[Starfleet/Sports] hoofoot events error: %s' % e, xbmc.LOGWARNING)
        _park_site('hoofoot')
        return []

    events = []
    for e in data.get('events', []) or []:
        sport = e.get('Sport', '')
        try:
            dt = _strp('%s %s' % (e['Date'], e['Time']), '%Y-%m-%d %H:%M')
            start_ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds()) - _HOOFOOT_MSK_OFFSET
        except Exception:
            start_ts = 0
        eid = e.get('id', '')
        title = _clean((e.get('Match') or '').replace('–', 'vs'))
        events.append({
            'id':          'hoofoot_%s' % eid,
            'eid':         eid,
            'slug':        eid,
            'path':        'hoofoot:%s' % eid,
            'title':       title,
            'match_title': title,
            'datetime':    '',
            'league':      e.get('League') or '',
            'logo':        e.get('HomeTeamImage') or '',
            'is_live':     e.get('Status') == 'Live',
            'start_ts':    start_ts,
            'raw_sport':   sport,
        })
    xbmc.log('[Starfleet/Sports] hoofoot: %d events' % len(events), xbmc.LOGINFO)
    _cache.set(ck, events, 5 * 60)
    return events


def _hoofoot_events(sport_slug, max_items=20):
    events = _hoofoot_all_events()
    matching = [e for e in events if _HOOFOOT_SPORT_MAP.get(e['raw_sport']) == sport_slug]
    return matching[:max_items]


def _hoofoot_other_events():
    """Events whose raw Sport label has no matching category slug — folded
    into the Other/International catch-all rather than dropped entirely."""
    events = _hoofoot_all_events()
    return [e for e in events
            if e['raw_sport'] not in _HOOFOOT_SPORT_MAP
            and e['raw_sport'] not in ('TV Show', 'Gambling')]


def _hoofoot_event_streams(event_path):
    eid = event_path.replace('hoofoot:', '')
    try:
        r = _sess().get(
            HOOFOOT_BASE + '/api/main-server?id=%s' % eid, timeout=10,
            headers=dict(_HEADERS, Referer='https://cinevid.sbs/', Origin='https://cinevid.sbs'))
        data = _hoofoot_decrypt(r.json())
    except Exception as e:
        xbmc.log('[Starfleet/Sports] hoofoot stream error (%s): %s' % (eid, e), xbmc.LOGWARNING)
        return []

    streams = []
    for i, ch in enumerate(data.get('channels', []) or []):
        main = ch.get('Main') or ''
        if not main:
            continue
        if 'youtube.com' in main or 'youtu.be' in main:
            continue   # a YouTube embed page, not something the player can open
        if main.startswith('//'):
            main = 'https:' + main
        elif main.startswith('/'):
            main = HOOFOOT_BASE + main
        if '.m3u8' not in main.lower() and ('/ltv?' in main or '/gl?' in main):
            # these are HLS playlists with no file extension; the player setup keys on
            # '.m3u8' appearing in the URL (a fragment is never sent to the server)
            main += '#.m3u8'
        streams.append({
            'label':    ch.get('language') or ('Link %d' % (i + 1)),
            'url':      main,
            'quality':  ch.get('speed', ''),
            'language': ch.get('language', ''),
            'source':   'Hoofoot',
        })
    # A big match lists 40+ channels in a dozen languages and a fair share of the
    # /ltv ones answer 404 "Channel not found" at that moment. Rank (English, then HD,
    # then the premium /gl channels), keep at most two per language, offer the first 10.
    def _rank(st):
        return (0 if st['language'] == 'English' else 1,
                0 if st['quality'] in ('FHD', 'HD') else 1,
                0 if '/gl?' in st['url'] else 1)
    streams.sort(key=_rank)
    per_lang, picked = {}, []
    for st in streams:
        n = per_lang.get(st['language'], 0)
        if n < 2:
            per_lang[st['language']] = n + 1
            picked.append(st)
    # not validated here on purpose: hoofoot builds each playlist on demand (about 1.2s
    # one at a time, 5s each when 16 are asked at once), so checking them would add
    # 6-12s to every game; measured 2026-10-02, 44 of 45 channels of a big match
    # answered, and the player skips a dead one in a second
    streams = picked[:10]
    return streams


# ── Public stream API ─────────────────────────────────────────────────────────

def _status_of(piped_url, timeout=5):
    """HTTP status of `url|Header=value&...` (0 when it could not be asked: a slow answer must not count as a dead link)."""
    from urllib.parse import unquote as _unq
    base, _, tail = piped_url.partition('|')
    hdr = dict(_HEADERS)
    for kv in tail.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            hdr[k] = _unq(v)
    try:
        return _sess().get(base, timeout=timeout, headers=hdr).status_code
    except Exception:
        return 0


def _has_segments(piped_url, timeout=6):
    """True when the playlist (or the first variant of a master playlist) lists at least one segment.
    `url|Header=value&...` addresses are fetched with their headers."""
    from urllib.parse import unquote as _unq
    base, _, tail = piped_url.partition('|')
    hdr = dict(_HEADERS)
    for kv in tail.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            hdr[k] = _unq(v)
    try:
        r = _sess().get(base, timeout=timeout, headers=hdr)
        txt = r.text or ''
        if r.status_code != 200 or '#EXTM3U' not in txt[:60]:
            return False
        if 'EXT-X-STREAM-INF' in txt:
            nxt = [l for l in txt.splitlines() if l and not l.startswith('#')]
            if not nxt:
                return False
            from urllib.parse import urljoin as _uj
            r = _sess().get(_uj(r.url, nxt[-1]), timeout=timeout, headers=hdr)
            txt = r.text or ''
        return r.status_code == 200 and '#EXTINF' in txt
    except Exception:
        return False


def _after(delay, fn, *args):
    """Run fn(*args) after `delay` seconds. Every new HTTPS connection costs a few hundred ms of CPU (the CA bundle is
    reloaded each time), so the heavy mirror-crawling sources start a moment later and the built-in live sites get the
    first seconds to themselves."""
    time.sleep(delay)
    return fn(*args)


# ── Russian-language streams ──────────────────────────────────────────────────
# Some sources carry the Russian broadcast of a game (Match TV's feed on Kinescope, "RU" channels): a viewer who picked "just play" got
# Russian commentary. They are recognised by their video host, Cyrillic text or an RU / Rus / Russian tag in the label, and left out
# (Settings > General: "Sports: hide Russian-language streams", on by default).
_RU_HOSTS = ('kinescope', 'rutube.ru', 'vkvideo', 'matchtv', 'match.tv', 'okko.tv', 'ntv.ru', '1tv.ru', 'sportbox', 'championat.com')
_RE_RU_LABEL = re.compile('[Ѐ-ӿ]|(?<![A-Za-z])(?:RU|RUS|Russian|Rus)(?![A-Za-z])', re.I)


def _is_russian_stream(s):
    url = (s.get('url') or '').split('|', 1)[0].lower()
    host = url.split('/')[2] if url.startswith('http') and url.count('/') >= 2 else ''
    if host and any(h in host for h in _RU_HOSTS):
        return True
    text = ' '.join(str(s.get(k) or '') for k in ('label', 'source', 'language'))
    return bool(_RE_RU_LABEL.search(text))


def _drop_russian(streams):
    try:
        if _sfhost.addon().getSetting('sports_hide_russian') == 'false':
            return streams
    except Exception:
        pass
    kept = [s for s in streams if not _is_russian_stream(s)]
    if len(kept) != len(streams):
        xbmc.log('[Starfleet/Sports] left out %d Russian-language stream(s)' % (len(streams) - len(kept)), xbmc.LOGINFO)
    return kept


_SX_GROUP = {'ise': 'ise', 'ise_x': 'hubs', 'onhockey': 'onhockey', 'onhockey_x': 'onhockey', 'dlchan': 'daddylive', 'dlchan_multi': 'daddylive', 'hoofoot': 'hoofoot',
             'hoofoot_x': 'hoofoot', 'meth_x': 'meth', 'tvnow_x': 'tvnow', 'sportsurge': 'sportsurge', 'livetv902': 'livetv', 'buffcom': 'buffstreams',
             'falcon': 'falcon', 'falcon_nfl_pre': 'falcon', 'tim': 'timstreams', 'cdnlive': 'cdnlive', 'feeds': 'hubs', 'hubs': 'hubs', 'all24': 'all24',
             'slap': 'slap', 'livesites': 'livesites', 'cinevid': 'cinevid'}


def _sx_submit(key, submit, *args, **kwargs):
    """Start one stream source, unless the viewer switched its group off (Settings > Sports Sources): then an empty, finished result."""
    from starfleetscrapers.core import source_toggles as _st
    if _st.on('sports', _SX_GROUP.get(key, key)):
        return submit(*args, **kwargs)
    from concurrent.futures import Future
    done = Future()
    done.set_result([])
    return done


def get_event_streams(event_path, event_id='', sport_slug='', title='', start_ts=0):
    """
    Fetch stream links for a specific event.
    Merges ISE streams + Roxiestreams + StreamsEast + MethStreams
    + MLB24/NHL24/NFL24/NBA24 + TotalSportek24 + OnHockey.tv.
    Returns list of: {'label', 'url', 'quality', 'language', 'source'}
    """
    ck = ('sports_streams_%s' % event_id) if event_id else None
    if ck:
        cached = _cache.get(ck)
        if cached is not None:
            return cached

    # a live game's title carries the score ("Winnipeg Jets 0 - 1 Carolina Hurricanes"), which no source's own title has: every
    # title-based lookup (PPV, Footy4U, ReedStreams, MethStreams, SlapStreams...) matches on the team names alone
    if title:
        title = re.sub(r'\s+\d{1,3}\s*[-–:]\s*\d{1,3}\s+', ' vs ', title).strip()

    # an NHL game opened from the OnHockey.tv hockey list arrives as sport "hockey" (id onhockey_nhl_<date>_<teams>): every source that
    # looks a game up by title is keyed on "nhl", so without this the game got none of PPV, MethStreams, Footy4U, SlapStreams and the rest
    if sport_slug == 'hockey' and re.search(r'(?:^|[:_/])nhl_', '%s %s' % (event_path or '', event_id or ''), re.I):
        sport_slug = 'nhl'

    streams = []

    # Determine event path source by prefix
    is_seast_path    = event_path and event_path.startswith('streamseast:')
    is_meth_path     = event_path and event_path.startswith('meth:')
    is_tstek_path    = event_path and event_path.startswith('tstek:')
    is_onhockey_path   = event_path and event_path.startswith('onhockey:')
    is_dlchan_path     = event_path and event_path.startswith('dlchan:')
    is_dlchan_multi    = event_path and event_path.startswith('dlchan_multi:')
    is_hoofoot_path    = event_path and event_path.startswith('hoofoot:')
    is_lsite_path       = event_path and event_path.startswith('livesite:')
    is_nojhl_path       = event_path and event_path.startswith('nojhl:')
    is_redbull_path     = event_path and event_path.startswith('redbull:')
    is_ise_path      = (event_path and not is_seast_path and not is_meth_path
                        and not is_tstek_path and not is_onhockey_path
                        and not is_dlchan_path and not is_dlchan_multi
                        and not is_hoofoot_path and not is_lsite_path and not is_nojhl_path
                        and not is_redbull_path)
    if is_lsite_path and not title:
        from starfleetscrapers.sports import sports_starfleet_live as _cw
        _slug_p, title = _cw.parse_event_path(event_path)
        title = title or ''

    # Build parallel fetch tasks
    futures = {}
    # one worker per source: with ten, the slow ones (BuffStreams 14 s, OnHockey 7 s) held the pool and the quick token sites
    # (PPV, Footy4U, ReedStreams, SlapStreams) waited behind them past the deadline
    ex = ThreadPoolExecutor(max_workers=24)
    try:
        if is_ise_path:
            futures['ise']        = ex.submit(_ise_event_streams, event_path, event_id)
        if is_redbull_path:
            futures['redbull']    = ex.submit(_redbull_live_stream)
        # _seast_event_streams removed: it hands back raw embed.st page URLs
        # with no resolution step (relies on ResolveURL, which doesn't support
        # embed.st — that's the whole reason EmbedResolver exists), so these
        # never actually played. streameast.json now covers the same site
        # with properly-resolved links, picked up via json_data below.
        # MethStreams event pages are JS-rendered — no playable URL in HTML, skip as stream source
        # _tstek_streams / _tstek_streams_by_title removed 2026-08-03 —
        # totalsportek24.is superseded by totalsportek.json (json_data
        # below), scraped standalone from totalsportek.press instead; see
        # this file's get_sport_events() for the matching supplementary
        # source removal. Function bodies left in place as dead code.
        if is_onhockey_path:
            futures['onhockey']   = ex.submit(_onhockey_streams, event_path)
        if is_dlchan_path:
            futures['dlchan']     = ex.submit(_dlchan_streams, event_path)
        if is_dlchan_multi:
            futures['dlchan_multi'] = _sx_submit('dlchan_multi', ex.submit, _dlchan_multi_streams, event_path)
        if is_hoofoot_path:
            futures['hoofoot'] = _sx_submit('hoofoot', ex.submit, _hoofoot_event_streams, event_path)
        # _roxie_streams removed 2026-08-02 — confirmed live its m3u8 CDN
        # (a formaturamaxi.com.br host) sits behind genuine Cloudflare
        # bot-protection that 403s every non-browser client tried
        # (plain requests, cloudscraper) AND was independently confirmed
        # not to play in real Kodi either — the URL this function scrapes
        # was never actually playable, just successfully found.
        # _seast_event_streams_by_slug removed: streamseasti.is is now covered
        # by the streameast.json scraper output, picked up via json_data below.
        # MethStreams: the page lists its embeds in a static allStreams array (the JS only
        # builds the iframe from it); _meth_event_streams resolves them and keeps the ones
        # that yield a real playlist. (Was dropped when it returned the page URL itself.)
        if title and sport_slug in _METH_LEAGUE_PATHS:
            futures['meth_x'] = _sx_submit('meth_x', ex.submit, _meth_event_streams, sport_slug, title)
        if sport_slug == 'nhl' and not is_onhockey_path:
            # its own thread: it checks 20-35 links side by side and needs ~10 s, which the shared pool's other slow sources pushed past the deadline
            _oh_ex = ThreadPoolExecutor(max_workers=1)
            futures['onhockey_x'] = _sx_submit('onhockey_x', _oh_ex.submit, _onhockey_streams_by_title, title)
            _oh_ex.shutdown(wait=False)
        # _crack_streams_by_title removed: CrackStreams is now covered by the
        # crackstreams.json scraper output, picked up via json_data below.
        if title and not is_dlchan_multi:
            futures['tvnow_x']    = ex.submit(_after, 2.0, _tvnow_motogp_streams if sport_slug == 'motogp' else _tvnow_streams_by_title, title)
        if title and _HOOFOOT_ALIVE and not is_hoofoot_path:
            futures['hoofoot_x'] = _sx_submit('hoofoot_x', ex.submit, _hoofoot_streams_by_title, title, sport_slug)
        if title and sport_slug != 'motogp':
            futures['ise_x'] = _sx_submit('ise_x', ex.submit, _after, 2.0, _ise_streams_by_title, title)
        if title and (sport_slug in _SPORTSURGE_SLUGS or sport_slug == 'soccer'):
            futures['sportsurge'] = _sx_submit('sportsurge', ex.submit, _after, 0.3, _sportsurge_streams_by_title, sport_slug, title)
        if title:
            futures['livetv902'] = _sx_submit('livetv902', ex.submit, _after, 2.0, _livetv902_streams_by_title, title)
        # Several sites hand out a numbered channel slot ("premium6", "nba2") that shows whatever is on that
        # slot right now - before a game is close to starting that is some other event. Those are only offered
        # from 45 minutes before the start.
        _early = bool(start_ts) and (int(start_ts) - time.time()) > 45 * 60
        if title and not _early:
            futures['buffcom'] = _sx_submit('buffcom', ex.submit, _after, 2.0, _buffcom_streams_by_title, title)
        # dlsports removed 2026-08-14: confirmed live embed.st (daddylive's
        # hop-2 mirror) now builds its stream URL via JS execution with
        # nothing static left to scrape, so _dl_streams_by_title always
        # returned 0 here — daddylive.json (json_data.py, via the
        # scraper-PC's Playwright-fallback resolver) covers this now. See
        # json_data.py's own _JSON_SOURCES comment for the full story.
        if title and sport_slug:
            futures['falcon']   = ex.submit(_after, 2.0, _falcon_streams_by_title, sport_slug, title)
            futures['tim']      = ex.submit(_tim_streams_by_title, sport_slug, title)
            futures['cdnlive']  = ex.submit(_cdn_streams_by_title, sport_slug, title)
            futures['feeds']    = ex.submit(_feed_streams_by_title, sport_slug, title)
            futures['hubs']     = ex.submit(_hubs_streams_by_title, sport_slug, title)
        if title and sport_slug in _ALL24_DOMAINS:
            futures['all24'] = _sx_submit('all24', ex.submit, _all24_streams_by_title, sport_slug, title)
        if title and sport_slug == 'nhl':
            futures['canadiens'] = _sx_submit('canadiens', ex.submit, _canadiens_streams, title, start_ts)
        if title and sport_slug:
            futures['tvlisted'] = ex.submit(_tv_listed_streams, sport_slug, title, start_ts)
            futures['cinevid'] = _sx_submit('cinevid', ex.submit, _cinevid_streams_by_title, sport_slug, title)
        if title and sport_slug == 'nhl':
            # own thread: the shared pool is already saturated by slow sources (hoofoot timeouts etc.), which
            # left this queued past the deadline on a real run
            _slap_ex = ThreadPoolExecutor(max_workers=1)
            futures['slap'] = _sx_submit('slap', _slap_ex.submit, _slap_streams_by_title, sport_slug, title)
            _slap_ex.shutdown(wait=False)
        if title and sport_slug in _YT_SPORTS:
            futures['yt'] = ex.submit(_yt_live_streams_by_title, sport_slug, title)
        if title and sport_slug == 'nfl':
            futures['falcon_nfl_pre'] = _sx_submit('falcon_nfl_pre', ex.submit, _falcon_nfl_streams_by_title, title)
        # Sportzone / TopSurge / FlyEmbed / SportsOnline — plain-HTTP resolvers
        # plain-HTTP resolvers, see sports_starfleet_live.py. Matches by BOTH
        # team names, not word overlap.
        if title:
            # own thread, like SlapStreams: the shared pool is saturated by sources that try dozens of dead
            # mirrors (BuffStreams v6 alone queues ~80), which pushed this past the deadline on a live MLB game
            _ls_ex = ThreadPoolExecutor(max_workers=1)
            futures['livesites'] = _sx_submit('livesites', _ls_ex.submit, _livesites_streams, sport_slug, title, not _early)
            _ls_ex.shutdown(wait=False)

        # as_completed under ONE overall deadline instead of fut.result(
        # timeout=12) per future in submission order: that form restarts a
        # fresh 12s wait for every straggler, so several slow sources stacked
        # (measured 15-24s waits for NFL/soccer/college football, with the
        # useful sources long since finished) instead of capping at ~12s
        # total. Sources still running at the deadline are simply dropped.
        _name_by_fut = {f: n for n, f in futures.items()}
        try:
            # 16s hard ceiling: SportSurge's own chain (game listing + game page + up to 10s of
            # embed resolves) measures ~11-12s cold, and it's the only working source for
            # several sports (college football, CFL, NCAAB). But when several sources have
            # already produced links (4+ and 4s in), the stragglers only get 3 more seconds -
            # a busy game otherwise waited the full 10-16s on one slow source with plenty of
            # working links on screen. Games with few sources never reach that quorum.
            from concurrent.futures import wait as _cf_wait, FIRST_COMPLETED as _CF_FIRST
            _t_start = time.time()
            _pending = set(_name_by_fut)
            _quorum_at = None
            _first_at = None
            while _pending:
                _elapsed = time.time() - _t_start
                _limit = 16.0 if _quorum_at is None else min(16.0, _quorum_at + 3.0)
                if any(_name_by_fut[_f] == 'slap' for _f in _pending):
                    _limit = max(_limit, 13.0)    # SlapStreams = several sequential requests; slow on a Firestick
                if any(_name_by_fut[_f] == 'onhockey_x' for _f in _pending):
                    _limit = max(_limit, 19.0)    # OnHockey checks its 20-35 links side by side first (~10 s alone, more beside the others)
                if len(streams) < 10 and any(_name_by_fut[_f] == 'sportsurge' for _f in _pending):
                    _limit = max(_limit, 22.0)    # SportSurge: listing + game page + resolving, ~15-20 s on a box; it is often the only source with links
                if any(_name_by_fut[_f] == 'livesites' for _f in _pending):
                    _limit = max(_limit, 22.0)    # the built-in live sites: listing + game pages + resolving (game-page sites like Plavio / Strikeout come in late on a box)
                if any(_name_by_fut[_f] in ('hubs', 'feeds', 'all24', 'meth_x', 'onhockey_x') for _f in _pending):
                    _limit = max(_limit, 12.0)    # the title-matched sites (PPV, Footy4U, ReedStreams, MethStreams...) answer in 3-8 s
                if sport_slug == 'motogp' and any(_name_by_fut[_f] == 'tvnow_x' for _f in _pending):
                    _limit = max(_limit, 15.0)    # the race weekend's DaddyLive channels (20+ resolved side by side) need ~12 s; they are most of the working links
                # A busy game (NBA nights: 12-18 links by ~4 s) does not wait the full 15-19 s for the slowest source: with 10+ links in hand the
                # stragglers (live-site page resolves, OnHockey) get 6 s past the quorum, then the list is shown.
                if _quorum_at is not None and len(streams) >= 18:
                    _limit = min(_limit, max(_quorum_at + 10.0, 14.0))     # (10 links used to be enough to cut Plavio / Strikeout / SportSurge off)
                # Nothing found yet: keep waiting for the first links instead of reporting "no streams" - the first play
                # after Kodi starts on a Fire TV is cold and can need 30+ seconds before the first source answers (measured:
                # every source finished 2-10 s after the old deadline). Once links exist the normal deadline applies again,
                # with a short grace after the first one.
                if _first_at is None:
                    _limit = max(_limit, 45.0)
                else:
                    _limit = max(_limit, _first_at + 3.0)
                if _elapsed >= _limit:
                    break
                _done, _pending = _cf_wait(_pending, timeout=_limit - _elapsed, return_when=_CF_FIRST)
                for fut in _done:
                    name = _name_by_fut[fut]
                    try:
                        result = fut.result()
                        if result:
                            streams += result
                    except Exception as e:
                        xbmc.log('[Starfleet/Sports] stream source error (%s): %s' % (name, e or type(e).__name__), xbmc.LOGWARNING)
                if _first_at is None and streams:
                    _first_at = time.time() - _t_start
                if _quorum_at is None and len(streams) >= 4 and time.time() - _t_start >= 4.0:
                    _quorum_at = time.time() - _t_start
            if _pending:
                xbmc.log('[Starfleet/Sports] stream sources left behind after %.1fs: %s' % (
                    time.time() - _t_start, sorted(_name_by_fut[f] for f in _pending)), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] stream collection error: %s' % e, xbmc.LOGWARNING)
    finally:
        ex.shutdown(wait=False)

    # Links already unioned onto this event by json_data.merge_json_events()
    # during the listing phase (get_sport_events) — picked up here by id so
    # get_event_streams never has to re-fetch or re-match the JSON sources.
    if event_id:
        json_links = _cache.get('json_ev_links_%s' % event_id)
        from starfleetscrapers.core import source_toggles as _st_sx
        if json_links and not _st_sx.on('sports', 'json'):
            json_links = None
        if json_links:
            seen = {s.get('url') for s in streams}
            streams += [l for l in json_links if l.get('url') not in seen]

    # Post-process: any source above may have handed back a raw streame.center
    # embed link, or one of its wrapper front-ends (dead on their own) —
    # resolve those to the real playable URL, in parallel, regardless of
    # which source or sport it came from.
    # Match against the URL part only (before any "|Referer=..." pipe suffix).
    # Confirmed live 2026-09-19: SportSurge hands back already-resolved
    # edgestream*.pro/hls/*.m3u8 links whose Referer header is
    # https://streame.center/ — matching the whole string flagged every one
    # of them as an unresolved wrapper, _resolve_streame_center() then
    # returned None for them, and the filter below silently deleted ALL of
    # SportSurge's good streams (8 real ones for a live college football
    # game came out as 0).
    streamecenter_idx = [i for i, s in enumerate(streams)
                         if any(h in (s.get('url', '') or '').split('|', 1)[0]
                                for h in _STREAMECENTER_WRAPPER_HOSTS)]
    if streamecenter_idx:
        with ThreadPoolExecutor(max_workers=len(streamecenter_idx)) as rex:
            refuts = {rex.submit(_resolve_streame_center, streams[i]['url']): i for i in streamecenter_idx}
            for fut in refuts:
                i = refuts[fut]
                try:
                    resolved = fut.result(timeout=10)
                except Exception as e:
                    xbmc.log('[Starfleet/Sports] streame.center resolve error: %s' % e, xbmc.LOGWARNING)
                    resolved = None
                streams[i]['url'] = resolved
        streams = [s for s in streams if s['url']]

    # embed.st / embedsports players come back as page addresses from several sources (FalconStreams, RockyLive
    # links...): turn them into the real playlist, or drop them.
    _goat_idx = [i for i, s in enumerate(streams)
                 if any(h in (s.get('url', '') or '').split('|', 1)[0] for h in ('embed.st/embed/', 'embedsports.me/', 'sportsframe.me/'))]
    if _goat_idx:
        from starfleetscrapers.sports import sports_starfleet_live as _sl_goat
        with ThreadPoolExecutor(max_workers=len(_goat_idx)) as gex:
            gfuts = {gex.submit(_sl_goat.resolve_link, streams[i]['url'].split('|', 1)[0]): i for i in _goat_idx}
            for fut in gfuts:
                try:
                    streams[gfuts[fut]]['url'] = fut.result(timeout=12)
                except Exception as e:
                    xbmc.log('[Starfleet/Sports] embed resolve error: %s' % (e or type(e).__name__), xbmc.LOGINFO)
                    streams[gfuts[fut]]['url'] = None
        streams = [s for s in streams if s['url']]

    # pre-resolved NFL links come from a list that can be hours old: keep them only while the playlist still lists segments
    _fr_idx = [i for i, s_ in enumerate(streams) if s_.get('source') == 'falconresolved']
    if _fr_idx:
        with ThreadPoolExecutor(max_workers=len(_fr_idx)) as fex:
            _fr_ok = list(fex.map(lambda i: _has_segments(streams[i]['url'], timeout=5), _fr_idx))
        _fr_gone = {i for i, ok in zip(_fr_idx, _fr_ok) if not ok}
        streams = [s_ for i, s_ in enumerate(streams) if i not in _fr_gone]

    # dlive.sx stream pages are skipped while the site is unreachable
    _dead_dlive = _host_marked_down('dlive.sx') or _host_marked_down('thedaddy.li')
    if _dead_dlive:
        streams = [s for s in streams if '//dlive.sx/' not in (s.get('url', '') or '') and '//thedaddy.li/' not in (s.get('url', '') or '')]

    streams = _drop_russian(streams)

    # the same address offered by several sites is listed once, and a hub link whose playlist the edge refuses outright (403 / 404 / 410) is left out
    _seen_u, _uniq = set(), []
    for s_ in streams:
        _k = (s_.get('url', '') or '').split('|')[0]
        if _k and _k in _seen_u:
            continue
        _seen_u.add(_k)
        _uniq.append(s_)
    streams = _uniq
    _hub_idx = [i for i, s_ in enumerate(streams) if s_.get('source') in ('Footy4U', 'PPV', 'ReedStreams', 'CricHD', 'FreeStreams', 'FalconStreams', 'MethStreams', 'Hoofoot')
                and '.m3u8' in (s_.get('url', '') or '').split('|')[0]]
    if _hub_idx:
        _gone_idx = set()
        try:
            with ThreadPoolExecutor(max_workers=len(_hub_idx)) as hex_:
                for i_, bad_ in zip(_hub_idx, hex_.map(lambda i: (lambda c_: c_ in (401, 403, 404, 410) or 500 <= c_ < 600)(_status_of(streams[i]['url'])), _hub_idx)):
                    if bad_:
                        _gone_idx.add(i_)
        except Exception:
            _gone_idx = set()
        if _gone_idx:
            streams = [s_ for i, s_ in enumerate(streams) if i not in _gone_idx]

    # what each stream is (1080p / 720p / ~480p ...): read from the playlists side by side, a few seconds at most, so the list can show it
    try:
        from starfleetscrapers.sports import stream_quality as _sq
        _sq.annotate(streams)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] stream quality: %s' % e, xbmc.LOGINFO)

    if ck:
        ttl = 90 if streams else 60   # tokenised playlist addresses go stale within a couple of minutes
        _cache.set(ck, streams, ttl)

    xbmc.log('[Starfleet/Sports] event streams (%s/%s): %d total' % (sport_slug, event_id, len(streams)), xbmc.LOGINFO)
    return streams


def _seast_event_streams_by_slug(sport_slug, event_title):
    """
    Supplementary: fetch StreamsEast schedule for the sport, find matching event, get streams.
    Used when the event did NOT come from StreamsEast.
    """
    try:
        seast_evs = _seast_events(sport_slug)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] seast_event_streams_by_slug error: %s' % e, xbmc.LOGWARNING)
        return []

    best_path  = None
    best_score = 0
    for ev in seast_evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']

    if not best_path or best_score < 2:
        return []

    return _seast_event_streams(best_path)


# ── CrackStreams ──────────────────────────────────────────────────────────────

CRACK_BASE = 'https://crackstreams.mx'

_CRACK_LEAGUE_MAP = {
    'nfl':    'nflstreams',
    'nba':    'nbastreams',
    'mlb':    'mlbstreams',
    'nhl':    'nhlstreams',
    'soccer': 'soccerstreams',
    'mma':    'mmastreams',
    'boxing': 'boxingcasino',
}

_RE_CRACK_ALL_STREAMS = re.compile(r'const\s+allStreams\s*=\s*(\[.*?\]);', re.DOTALL)
_RE_CRACK_M3U8 = re.compile(r'(https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*)')


def _crack_slug_candidates(event_title):
    """CrackStreams event pages live at /stream/<away-team>-vs-<home-team> —
    but the site's own /league/<sport>streams listing pages are 404s (the
    real path is /category/<sport>/, confirmed live), and even the correct
    category page has no server-rendered event links to scrape (JS-rendered
    like most of this ecosystem now). Rather than reverse-engineer another
    discovery API, build the slug directly from the two team names in the
    title — verified this matches the site's real URLs exactly for a live
    game. Team order in the given title isn't guaranteed, so try both."""
    parts = re.split(r'\s+vs\.?\s+', event_title, flags=re.IGNORECASE)
    def _slug(s):
        return re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-')
    if len(parts) != 2:
        return [_slug(event_title)]
    a, b = _slug(parts[0]), _slug(parts[1])
    return ['%s-vs-%s' % (a, b), '%s-vs-%s' % (b, a)]


def _crack_resolve_embed(embed_url):
    """Try to extract an m3u8 from an embed page. Returns None on failure."""
    try:
        html = _sess().get(
            embed_url, timeout=8,
            headers=dict(_HEADERS, Referer=CRACK_BASE + '/')
        ).text
        m = _RE_CRACK_M3U8.search(html)
        if m:
            return m.group(1)
    except Exception:
        pass
    return None


def _crack_streams_for_url(event_url):
    """Fetch a CrackStreams event page and return resolved stream dicts."""
    import json as _json
    try:
        html = _sess().get(
            event_url, timeout=8,
            headers=dict(_HEADERS, Referer=CRACK_BASE + '/')
        ).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] CrackStreams event page error: %s' % e, xbmc.LOGWARNING)
        return []
    m = _RE_CRACK_ALL_STREAMS.search(html)
    if not m:
        xbmc.log('[Starfleet/Sports] CrackStreams: no allStreams found at %s' % event_url, xbmc.LOGWARNING)
        return []
    try:
        raw = _json.loads(m.group(1))
    except Exception:
        return []
    results = []
    for i, s in enumerate(raw):
        embed_url = s.get('value', '').strip()
        label     = s.get('label', 'Link %d' % (i + 1))
        if not embed_url:
            continue
        resolved  = _crack_resolve_embed(embed_url) or embed_url
        results.append({'url': resolved, 'label': label, 'source': 'crack', 'quality': 'HD'})
    return results


def _crack_streams_by_title(sport_slug, event_title):
    """Try CrackStreams' predictable /stream/<team>-vs-<team> URL directly —
    see _crack_slug_candidates for why this bypasses event-listing scraping."""
    if sport_slug not in _CRACK_LEAGUE_MAP:
        return []
    for slug in _crack_slug_candidates(event_title):
        url = CRACK_BASE + '/stream/' + slug
        streams = _crack_streams_for_url(url)
        if streams:
            xbmc.log('[Starfleet/Sports] CrackStreams matched "%s" -> %s' % (event_title, url), xbmc.LOGINFO)
            return streams
    return []
