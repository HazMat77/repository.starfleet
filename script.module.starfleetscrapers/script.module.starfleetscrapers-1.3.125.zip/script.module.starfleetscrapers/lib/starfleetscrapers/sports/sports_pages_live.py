# -*- coding: utf-8 -*-
"""Schedule-page providers for live sports, looked up per game.

Each provider publishes one HTML schedule page per league. Nothing is scraped when the sports lists are drawn;
when a game is opened `links_for(sport_slug, title)` fetches that league's page from every provider that has one
(in parallel, short timeouts), keeps the rows that are this game, and returns their page URLs. sports_starfleet_live
then resolves each page URL to a playable stream (`resolve_page`).

Providers (current domains come from data/live_sites.json when it lists them, else the defaults below)
    se   StreamEast        podium rows; a page has numbered server buttons that fill an iframe
    vg   StreamEast (vg)   <a class="ev ..."> rows
    ps   PlayoffsStream    block buttons
    p7   720pStream        match cards
    ih   iHDStreams        "Watch <teams> Live Stream" links
    fs   FSportsHD         media-body rows
    g2   GStream24         table rows with a WATCH link
    vk   VoloKit           table rows
    bf   BuffStreams       competition cards
    tt   TheTVApp          <a class="game"> rows; a game page has numbered server buttons that fill an iframe
    bg   Bingr             /api/sports/matches lists the games, /api/sports/streams/<id> gives each game's HLS feeds
    s8   Score808          sport pages list /links/<teams>; a links page's buttons open hitcast.st/totview.php?src=<player page>
    sx   SportsindX        /new lists the games; /streams/<slug> is open JSON with each game's feeds (embed pages)
"""
import base64
import datetime as _dt
import html as _html
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait as _wait, as_completed as _as_completed
from urllib.parse import urljoin, urlparse

from starfleetscrapers.core import http as requests
import xbmc

from starfleetscrapers.sports.timeparse import strptime as _strp

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
_TIMEOUT = 7


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/LivePages] %s' % msg, level)


def _get(url, referer=None, timeout=_TIMEOUT):
    h = {'User-Agent': UA}
    if referer:
        h['Referer'] = referer
    r = requests.get(url, headers=h, timeout=timeout)
    r.raise_for_status()
    return r.text


# ── row parsers: html -> [(title, href)] ─────────────────────────────────────

def _p_se(page, base):
    out = []
    for block in re.findall(r'(?s)<li[^>]*\bclass=["\'][^"\']*\bf1-podium--item\b[^"\']*["\'][^>]*>(.*?)</li>', page):
        m = re.search(r'(?s)<a\s+href=["\']([^"\']+)["\'].*?d-md-inline[^>]*>\s*([^<]+?)\s*</span>', block)
        if m:
            out.append((_html.unescape(m.group(2)).strip(), urljoin(base, _html.unescape(m.group(1)).strip())))
    return out


def _p_vg(page, base):
    out = []
    for cls, href, title, _blk in re.findall(r'<a class="ev (?:ev-match|ev-plain)([^"]*)" href="([^"]+)" title="([^"]+)"[^>]*>(.*?)</a>', page, re.S):
        if 'is-post' in cls:
            continue
        out.append((_html.unescape(title).strip(), urljoin(base, href)))
    return out


def _p_ps(page, base):
    return [(_html.unescape(t).strip(), urljoin(base, h)) for h, t in re.findall(
        r'(?s)<a class="btn btn-info btn-block"[^>]+href="([^"]+)"[^>]*>.*?<div class="text-center">[^<]*</div>'
        r'.*?<div[^>]+d-none d-md-inline[^>]*>([^<]+)</div>', page)]


def _p_p7(page, base):
    out = []
    for href, _tb, teams in re.findall(r'<a class="match-card" href="([^"]+)">\s*<div class="match-time">(.*?)</div>\s*<div class="match-teams">(.*?)</div>', page, re.S):
        names = [_html.unescape(t).strip() for t in re.findall(r'<strong>([^<]+)</strong>', teams) if t.strip()]
        if names:
            out.append((' vs '.join(names), urljoin(base, href)))
    return out


def _p_ih(page, base):
    return [(_html.unescape(t).strip(), urljoin(base, h)) for h, t in re.findall(r'<a href="([^"]+)"[^>]+title="Watch ([^"]+?) Live Stream', page)]


def _p_fs(page, base):
    out = []
    for href, teams, _blk in re.findall(r'<div class="media-body">\s*<a href=["\']([^"\']+)["\'][^>]*>.*?<h4[^>]*>\s*([^<]+?)\s*</h4>(.*?)</a>', page, re.S):
        if 'Click Here' in teams:
            continue
        out.append((_html.unescape(teams).strip(), urljoin(base, href)))
    return out


def _p_g2(page, base):
    out = []
    for _d, _lg, event, _t, status, href in re.findall(
            r'(?s)<tr>\s*<td>\s*([^<]*?)\s*</td>\s*<td>\s*<img[^>]+alt="([^"]*)"[^>]*>\s*</td>\s*<td>\s*([^<]*?)\s*</td>\s*'
            r'<td>\s*([^<]*?)\s*</td>\s*<td[^>]*>\s*([^<]*?)\s*</td>\s*<td>\s*<a href="([^"]+)"[^>]*>\s*WATCH\s*</a>', page):
        if _html.unescape(status).strip().lower() == 'ended':
            continue
        out.append((_html.unescape(event).strip(), urljoin(base, _html.unescape(href).strip())))
    return out


def _p_vk(page, base):
    out = []
    for m in re.finditer(r'(?s)padding:0">([^<]*).*?href="([^"]*)', page):
        t, h = _html.unescape(m.group(1)).strip(), m.group(2)
        if t and h:
            out.append((t, urljoin(base, h)))
    return out


def _p_bf(page, base):
    out = []
    for teams, href in re.findall(r'(?s)<a[^>]+class="competition"[^>]+title="([^"]+)"[^>]+href="([^"]+)"', page):
        out.append((_html.unescape(teams).replace('Buffstreams ', '').strip(), urljoin(base, href)))
    for href, block in re.findall(r'(?s)<a class="d-block competition p-4"[^>]*href="([^"]+)">\s*<div>\s*(.*?)\s*</div>', page):
        text = _html.unescape(re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', block))).strip()
        text = re.sub(r'\s*-\s*\d{1,2}:\d{2}\s*[AP]M\s*ET$', '', text)
        out.append((text, urljoin(base, href)))
    return out


def _p_sc(page, base):
    """streamcenter game cards: one row per source link of a card."""
    out = []
    for card in re.findall(r'(?is)<article\s+class=["\']game-card-row["\'][^>]*>(.*?)</article>', page):
        t = re.search(r'(?is)<h3[^>]*>\s*(.*?)\s*</h3>', card)
        if not t:
            continue
        name = re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', t.group(1)))).strip()
        name = re.sub(r'\s+vs\.?\s+', ' vs ', name)
        for href in re.findall(r'(?is)<a\s+class=["\']game-card-open-link["\'][^>]+href=["\']([^"\']+)["\']', card):
            href = _html.unescape(href).strip()
            out.append((name, ('https:' + href) if href.startswith('//') else urljoin(base, href)))
    return out


def _p_sh(page, base):
    out = []
    for event, _lg, _t, href in re.findall(
            r'(?s)<tr>\s*<td[^>]*><strong>([^<]+)</strong></td>.*?<td[^>]*><strong>([^<]+)<strong></td>.*?'
            r'<td[^>]*><strong>([^<]+)</strong></td>.*?<a href="([^"]+)"', page):
        out.append((_html.unescape(event).strip(), urljoin(base, href)))
    return out


def _p_sf(page, base):
    out = []
    for art in re.findall(r'<article.*?</article>', page, re.S):
        m = re.search(r'<h2 class="entry-title"[^>]*><a href="([^"]+)"[^>]*>([^<]+)</a></h2>', art, re.S)
        if m:
            out.append((_html.unescape(m.group(2)).strip(), m.group(1)))
    return out


def _p_rp(page, base):
    out = []
    for art in re.findall(r'<article id="post-\d+".*?</article>', page, re.S):
        m = re.search(r'<h3>\s*<a href="([^"]+)">([^<]+)</a>\s*</h3>', art, re.S)
        if m:
            out.append((_html.unescape(m.group(2)).strip(), m.group(1)))
    return out


def _p_ss(page, base):
    out = []
    for m in re.finditer(r'<a class="row MaclariListele[^"]*"\s+href="([^"]+)"[^>]*>(.*?)</a>', page, re.S):
        href, block = m.group(1), m.group(2)
        teams = re.findall(r'team-name-event-row.*?<span[^>]*>\s*([^<]+?)\s*</span>', block, re.S)
        if len(teams) >= 2:
            out.append(('%s vs %s' % (_html.unescape(teams[0]).strip(), _html.unescape(teams[1]).strip()), urljoin(base, href)))
        else:
            h4 = re.search(r'<h4[^>]*>\s*([^<]+?)\s*</h4>', block, re.S)
            if h4:
                out.append((_html.unescape(h4.group(1)).strip(), urljoin(base, href)))
    return out


def _p_rs(page, base):
    out = []
    for href, name in re.findall(r'(?s)<a href="(/[^"]+-streams?-\d+)">\s*([^<]+?)\s*</a>', page):
        out.append((_html.unescape(name).strip(), urljoin(base, href)))
    return out


def _p_ms(page, base):
    out = []
    for href, title in re.findall(r'(?s)<a class="card" href="(/stream/[^"]+)"[^>]*>.*?<div class="card-title">([^<]+)</div>', page):
        out.append((_html.unescape(title).strip(), urljoin(base, href)))
    return out


def _p_sk(page, base):
    """streameast.cool league page: one match-card per game ('Team vs Team' inside the card) linking to /<league>/<teams>/<id>, whose
    page frames the player (aapmains.net new-stream-embed, which the shared resolver opens)."""
    out, seen = [], set()
    for href, title in re.findall(r'(?s)<a\s+href="(https://streameast\.cool/[a-z0-9-]+/[a-z0-9-]+/\d+)"[^>]*>.*?<span\s+class="d-md-inline">([^<]+)</span>', page):
        t = re.sub(r'\s+', ' ', _html.unescape(title)).strip()
        if href in seen or not t:
            continue
        seen.add(href)
        out.append((t, href))
    return out


def _p_nb(page, base):
    """The NBAbite / NFLbite / TotalSportek list pages: one /<Team-vs-Team>/<id> link per game (the game page holds a farm of mirror links)."""
    out, seen = [], set()
    for path in re.findall(r"""href=["'](?:https?://[^/"']+)?(/[A-Za-z0-9%.-]+-vs-[A-Za-z0-9%.-]+/\d+)["']""", page):
        if path in seen:
            continue
        seen.add(path)
        name = path.strip('/').rsplit('/', 1)[0].replace('-', ' ')
        out.append((re.sub(r'\s+', ' ', name).strip().replace(' vs ', ' vs '), base.rstrip('/') + path))
    return out


# mirror hosts of those game pages that have opened (a live check of the rest runs in _nb_feeds)
_NB_GOOD = ('totalsportek.gives', 'topstreamer.site', 'foxeyst.st', 'tuktukstreams.cfd', 'wildgames.bz', 'nonstopservice.org', 'pandastreamz.xyz')
_NB_SKIP = ('t.me', 'twitter.com', 'x.com', 'facebook.com', 'youtube.com', 'dmca.com')


def _nb_check(u):
    """True when a mirror page leads to a player: a page the page-reader follows, or a channel player (Nexa / extraplayer) the live resolver opens."""
    if any(k in u for k in ('extraplayer', 'embedextra', 'nexa.st')):
        from starfleetscrapers.sports import sports_starfleet_live as _sl
        try:
            return bool(_sl.resolve_link(u))
        except Exception:
            return False
    try:
        res = resolve_page(u)
    except Exception:
        return False
    if res and res[0] == 'stream':               # a playlist address has to be on the air (a finished or not yet started game answers nothing)
        from starfleetscrapers.sports import sports_starfleet_live as _sl
        try:
            return bool(_sl._still_alive(res[1]))
        except Exception:
            return True
    return bool(res)


def _nb_feeds(href):
    """[(n, mirror page)] of one NBAbite-family game page that open right now: its hidden link inputs name ~45 mirror sites; the known
    good ones are tried first, then others, and only the pages that lead to a player are kept (a quick parallel check)."""
    ck = 'nbfeeds_' + href
    c = _cache()
    hit = c.get(ck)
    if hit is not None:
        return hit
    cand, seen = [], set()
    if 'totalsportek' in urlparse(href).netloc.lower():
        # TotalSportek's own game pages hide their links in script; its mirrors (live, live2 ...) carry the same /<teams>/<id> path, so they are tried directly
        path = urlparse(href).path
        page = ''
        cand = ['https://%s.totalsportek.gives%s' % (h, path) for h in ('live', 'live2', 'live4', 'live3', 'live5')]
        for h in ('live2', 'live4', 'live'):         # the mirror page lists the game's own link farm ("premium stream" rows), as NBAbite does
            try:
                mp = _get('https://%s.totalsportek.gives%s' % (h, path), referer='https://totalsportekl.is/')
            except Exception:
                continue
            rows = [_html.unescape(u) for u in re.findall(r'class="nocolor w-100" href="(https?://[^"]+)"', mp)]
            if rows:
                cand += [u for u in rows if u not in cand and not any(k in urlparse(u).netloc.lower() for k in _NB_SKIP)]
                break
    else:
        try:
            page = _get(href, referer=href.split('/', 3)[0] + '//' + urlparse(href).netloc + '/')
        except Exception as e:
            _log('nbabite page: %s' % str(e)[:80])
            return []
    for u in re.findall(r'value="(https?://[^"]+)"\s+id="linkk\d+"', page):
        u = _html.unescape(u)
        h = urlparse(u).netloc.lower()
        if u in seen or any(h == x or h.endswith('.' + x) for x in _NB_SKIP):
            continue
        seen.add(u)
        cand.append(u)
    cand.sort(key=lambda u: 0 if any(urlparse(u).netloc.lower().endswith(g) for g in _NB_GOOD) else 1)
    cand = cand[:20]
    out = []
    if cand:
        ex = ThreadPoolExecutor(max_workers=8)
        futs = {ex.submit(_nb_check, u): u for u in cand}
        ex.shutdown(wait=False)
        ok = []
        try:                                          # stop as soon as three mirrors have answered (the slow ones are not waited for)
            for f in _as_completed(list(futs), timeout=3.5):
                try:
                    if f.result():
                        ok.append(futs[f])
                except Exception:
                    pass
                if len(ok) >= 3:
                    break
        except Exception:
            pass
        ok.sort(key=cand.index)
        out = [(n, u) for n, u in enumerate(ok[:6], 1)]
    c.set(ck, out, 120 if out else 20)
    return out


def _p_tp(page, base):
    """topstreamer schedule: one block per game with two team names and a WATCH link."""
    out = []
    for blk in re.split(r'data-id="', page)[1:]:
        names = [_html.unescape(n).strip() for n in re.findall(r'<div class="name">([^<]*)</div>', blk)]
        codes = [c.strip() for c in re.findall(r'<span class="code">([^<]+)</span>', blk)]
        href = re.search(r'<a href="([^"]+)"[^>]*class="item"><span>WATCH', blk)
        if href and len(codes) >= 2:
            away = names[0] if len(names) > 0 and names[0] else codes[0]
            home = names[1] if len(names) > 1 and names[1] else codes[1]
            out.append(('%s @ %s' % (away, home), urljoin(base, href.group(1))))
    return out


def _p_eh(page, base):
    """rockylive/embedhd: {"days":[{"items":[{title, category, status, streams:[{link}]}]}]}"""
    import json as _json
    out = []
    for day in (_json.loads(page).get('days') or []):
        for ev in day.get('items') or []:
            title = (ev.get('title') or '').replace(' - ', ' vs ')
            for st in ev.get('streams') or []:
                if st.get('link'):
                    out.append((title, st['link']))
    return out


def _p_rp(page, base):
    """Ripple Network home page: one row per game, `<a class="rmla-title" href=..>team vs team</a>`."""
    out, seen = [], set()
    for href, title in re.findall(r'<a class="rmla-title" href="([^"]+)">([^<]*)</a>', page):
        title = _html.unescape(title).strip()
        if title and href not in seen:
            seen.add(href)
            out.append((title, urljoin(base, href)))
    return out


def _json_events(page):
    import json as _json
    try:
        return [e for c in (_json.loads(page).get('streams') or []) for e in (c.get('streams') or [])]
    except ValueError:
        return []


def _event_title(name):
    name = _html.unescape(name or '').strip()
    return name.replace(' vs. ', ' vs ').replace(' at ', ' @ ')


def _p_pv(page, base):
    """PPV's public stream list (api.ppv.st, the backend several sports sites show): one player page per event plus its extra feeds.
    The players are embed.st-family pages that the resolver reads."""
    out = []
    for e in _json_events(page):
        title = _event_title(e.get('name'))
        if not title:
            continue
        for u in [e.get('iframe')] + [x.get('iframe') for x in (e.get('substreams') or [])]:
            if u and u.startswith('http'):
                out.append((title, u))
    return out


def _dm_direct(enc):
    """DAMITV hides some playlist addresses as enc:<base64 of the address written backwards>."""
    try:
        b = enc[4:] if enc.startswith('enc:') else enc
        return base64.b64decode(b + '=' * (-len(b) % 4)).decode('utf-8', 'ignore')[::-1]
    except Exception:
        return ''


def _p_dm(page, base):
    """DAMITV's public stream list (documented on its site): its 'HD' feeds are plain playlist addresses (kept as direct:), and its
    /dl/<n>.m3u8 feeds are DLHD channel numbers (kept as dlhd:<n> and played through the DLHD player resolver)."""
    out = []
    for e in _json_events(page):
        title = _event_title(e.get('name'))
        if not title:
            continue
        for src in e.get('sources') or []:
            emb = src.get('embed') or ''
            if '/player/' in emb and 'url=' in emb:
                from urllib.parse import parse_qs
                raw = (parse_qs(urlparse(emb).query).get('url') or [''])[0]
                m = re.match(r'/dl/(\d+)\.m3u8', raw)
                if m:
                    out.append((title, 'dlhd:' + m.group(1)))
                    continue
                real = _dm_direct(raw)
                if real.startswith('http'):
                    out.append((title, 'direct:' + real))
    return out


def _p_au(page, base):
    """Aura Sports' own schedule (its /api/schedule list). Every game has a player page on the site's player host
    (<host>/<sport>/<id>) that frames a plain HLS player; only games on the air (or about to start) are listed."""
    import json as _json
    import datetime as _dt
    try:
        cats = _json.loads(page)
    except ValueError:
        return []
    now = _dt.datetime.now(_dt.timezone.utc)
    out = []
    for c in cats if isinstance(cats, list) else []:
        for e in c.get('schedule') or []:
            title = _event_title(e.get('title'))
            eid, cat = e.get('id'), (e.get('category') or c.get('category_name') or 'sports').lower()
            if not title or not eid:
                continue
            soon = False
            try:
                start = _strp(e.get('date_iso', '').rstrip('Z'), '%Y-%m-%dT%H:%M:%S.%f').replace(tzinfo=_dt.timezone.utc)
                soon = -4 * 3600 < (start - now).total_seconds() < 2700
            except ValueError:
                pass
            if e.get('status') == 'live' or (soon and e.get('status') != 'finished'):
                # the feed's own player pages (a main stream and a backup; the shared resolver opens both), else the old player host
                urls = [s.get('url') for s in (e.get('sources') or []) if (s.get('url') or '').startswith('http')]
                if not urls:
                    urls = [e.get('watchUrl') or e.get('iframeUrl') or 'https://play.meth-streams-hd.cfd/%s/%s' % (cat, eid)]
                for u in urls[:2]:
                    out.append((title, u))
    return out


_RE_WS_ROW = re.compile(r'<a href="(/[a-z0-9\-]+(?:/[a-z0-9.\-]+)?/\d+)" class="game-row[^"]*" aria-label="([^"]+)"')


def _p_ws(page, base):
    """WatchSports (watchsports.su): a page per sport; each row is a game page (/<sport>/<ESPN id>) whose label reads
    "<A> vs <B> - <time or Live> - <n> streams - <league>"."""
    out = []
    for href, label in _RE_WS_ROW.findall(page):
        parts = [p.strip() for p in _html.unescape(label).split(' - ')]
        if not parts or not parts[0]:
            continue
        m = re.search(r'(\d+)\s+streams?', label)
        if m and int(m.group(1)) == 0:
            continue
        out.append((parts[0], urljoin(base, href)))
    return out


# the players on a WatchSports game page that the shared resolver turns into a playlist (the page also lists a dozen more embeds that
# only wrap an ad page or a dead site)
_WS_PLAYERS = ('sportora.ru/stream/', 'yallashott.qzz.io/player/')


def _ws_feeds(href):
    """[(n, embed url)] of a WatchSports game page."""
    try:
        page = _get(href, referer=href.split('/', 3)[0] + '//' + href.split('/')[2] + '/')
    except Exception as e:
        _log('ws page: %s' % str(e)[:80])
        return []
    out, seen = [], set()
    for u in re.findall(r'href="(https?://[^"]+)"', page):
        u = _html.unescape(u)
        if any(k in u for k in _WS_PLAYERS) and u not in seen:
            seen.add(u)
            out.append((len(out) + 1, u))
    return out


_RE_SO_ROW = re.compile(r'<a[^>]+href="(/[a-z0-9\-]+/stream-[a-z0-9\-]+-live)"[^>]*>(.*?)</a>', re.S)


def _p_so(page, base):
    """Strikeout (strikeout.im): a page per sport; each row is a game / race / channel page whose title reads "<HH:MM> <A> vs. <B>"."""
    out, seen = [], set()
    for href, inner in _RE_SO_ROW.findall(page):
        title = re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', inner))).strip()
        title = re.sub(r'^\d{1,2}:\d{2}\s+', '', title)
        if title and href not in seen:
            seen.add(href)
            out.append((title, urljoin(base, href)))
    return out


_SO_ROWS_FULL = re.compile(r'<a[^>]+href="(/([a-z0-9\-]+)/stream-[a-z0-9\-]+-live)"[^>]*>(.*?)</a>', re.S)
# a Strikeout page -> the menus that list its leagues in the apps ("more" holds the small sports); the major league of a sport keeps its own
# section and is left out of that sport's menu
_SO_MENUS = {
    'hockey': (('hockey',), {'nhl'}),
    'basketball': (('basketball',), {'nba', 'wnba', 'mens-college-basketball'}),
    'baseball': (('baseball',), {'mlb'}),
    'rugby': (('rugby',), set()),
    'golf': (('golf',), set()),
    'boxing': (('boxing', 'fighting'), {'wwe', 'wrestling', 'aew'}),
    'more': (('darts', 'snooker', 'cycling', 'handball', 'volleyball', 'afl', 'others'), set()),
    'soccer': (('soccer',), set()),
}
_SO_LEAGUE_NAMES = {
    'kontinental-hockey-league': 'KHL', 'belarusian-extraleague': 'Belarus Extraleague', 'russia-rhl': 'Russia RHL', 'russia-vhl': 'VHL',
    'swiss-snl': 'Swiss National League', 'deutsche-eishockey-liga': 'DEL', 'denmark-metal-ligaen': 'Metal Ligaen',
    'czech-superliga': 'Czech Extraliga', 'sm-liiga': 'Liiga', 'shl-elitserien': 'SHL', 'nba-g-league': 'NBA G League',
    'spain-acb': 'Liga ACB', 'china-cba': 'CBA', 'turkish-tbl': 'Turkish Basketball League', 'lega-basket-a': 'Lega Basket Serie A',
    'french-lnb': 'LNB Pro A', 'germany-bbl': 'BBL', 'britian-bbl': 'British BBL', 'brazil-nbb': 'NBB', 'australia-nbl': 'NBL',
    'euroleague': 'EuroLeague', 'europe-euro-cup': 'EuroCup', 'fiba': 'FIBA', 'russian-vtb': 'VTB United League',
    'mens-college-basketball': 'College Basketball', 'la-liga': 'La Liga', 'serie-a': 'Serie A', 'epl': 'Premier League',
    'womens-super-league': "Women's Super League", 'lpga-tour': 'LPGA Tour', 'pga-tour': 'PGA Tour', 'dp-world-tour': 'DP World Tour', 'uk-championship': 'UK Championship', 'moto-gp': 'MotoGP',
}


def _so_label(slug):
    if slug in _SO_LEAGUE_NAMES:
        return _SO_LEAGUE_NAMES[slug]
    return ' '.join(w.upper() if len(w) <= 3 and w.isalpha() and w not in ('the', 'and', 'cup', 'one', 'pro') else w.capitalize() for w in slug.split('-'))


def so_games(menu):
    """[{title, league, league_slug, kind, href, start_ts, live}] for one of the Strikeout menus above (see _SO_MENUS): the games on the
    air or about to start, soonest first. Times on the page are UTC."""
    import datetime as _dt
    kinds, skip = _SO_MENUS.get(menu, ((menu,), set()))
    ck = 'so_games_%s' % menu
    c = _cache()
    hit = c.get(ck)
    if hit is not None:
        return hit

    def one(kind):
        try:
            page = _get('https://strikeout.im/' + kind, referer='https://strikeout.im/', timeout=12)
        except Exception as e:
            _log('so %s: %s' % (kind, str(e)[:80]))
            return []
        return [(kind,) + x for x in _SO_ROWS_FULL.findall(page)]
    ex = ThreadPoolExecutor(max_workers=len(kinds))
    futs = [ex.submit(one, k) for k in kinds]
    ex.shutdown(wait=False)
    now = _dt.datetime.now(_dt.timezone.utc)
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    out, seen = [], set()
    for f in futs:
        try:
            rows = f.result(timeout=14)
        except Exception:
            continue
        prev = None
        for kind, href, league, inner in rows:
            if league in skip or href in seen:
                continue
            title = re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', inner))).strip()
            m = re.match(r'^(\d{1,2}):(\d{2})\s+(.+)$', title)
            if not m:
                continue                       # a 24/7 channel row (no start time)
            ts = midnight + _dt.timedelta(hours=int(m.group(1)), minutes=int(m.group(2)))
            if prev is not None and ts < prev - _dt.timedelta(hours=1):
                ts += _dt.timedelta(days=1)    # the page lists today and then tomorrow in order
            elif ts < now - _dt.timedelta(hours=8):
                ts += _dt.timedelta(days=1)
            prev = ts
            start = int(ts.timestamp())
            if start < int(now.timestamp()) - 4 * 3600:
                continue                       # over
            seen.add(href)
            out.append({'title': m.group(3), 'league': _so_label(league), 'league_slug': league, 'kind': kind,
                        'href': 'https://strikeout.im' + href, 'start_ts': start, 'live': start <= int(now.timestamp())})
    out.sort(key=lambda e: e['start_ts'])
    out = _so_only_working(out)
    c.set(ck, out, 300 if out else 30)
    return out


def _so_on_air(href):
    """True when one of the game's player pages is on the air (a player of a game that is not shows an offline screen)."""
    for _n, u in _so_feeds(href)[:3]:
        try:
            if _so_stream(u, probe=True):
                return True
        except Exception:
            continue
    return False


def _so_only_working(games):
    """A game listed as live whose players are all offline is left out; games that have not started yet stay (they have no link to try)."""
    live = [g for g in games if g['live']]
    if not live:
        return games
    ex = ThreadPoolExecutor(max_workers=min(12, len(live)))
    futs = {g['href']: ex.submit(_so_on_air, g['href']) for g in live}
    ex.shutdown(wait=False)
    ok = set()
    for href, f in futs.items():
        try:
            if f.result(timeout=25):
                ok.add(href)
        except Exception:
            ok.add(href)                               # could not be checked in time: show it
    return [g for g in games if not g['live'] or g['href'] in ok]


def so_streams(href):
    """[(label, playlist address with its headers)] of a Strikeout game page: only the players that really open."""
    out = []
    feeds = _so_feeds(href)[:6]
    ex = ThreadPoolExecutor(max_workers=max(1, len(feeds)))
    futs = [(n, ex.submit(_so_stream, u)) for n, u in feeds]
    ex.shutdown(wait=False)
    for n, f in futs:
        try:
            r = f.result(timeout=20)
        except Exception:
            r = None
        if r and r[0] == 'stream':
            out.append(('Strikeout %d' % n, r[1]))
    return out


def _so_feeds(href):
    """[(n, stream page url)] of a Strikeout game page (every "Stream N" button names its own player page)."""
    try:
        page = _get(href, referer='https://strikeout.im/')
    except Exception as e:
        _log('so page: %s' % str(e)[:80])
        return []
    out, seen = [], set()
    for u in re.findall(r'data-uri="(/[a-z0-9\-]+/\d+/[a-z0-9\-]+-stream)"', page):
        if u not in seen:
            seen.add(u)
            out.append((len(out) + 1, urljoin(href, u)))
    return out


_SO_SESS = {}                      # playlist address without its query -> the Strikeout session behind it
_SO_LOCK = threading.Lock()


def _so_keep_start(key, tok, hdr, stream_id, state):
    """A Strikeout session lasts about ten minutes unless it is renewed (the site's player renews it every five). Every address handed out
    is renewed every four minutes for 25 minutes; an address that is really played (keep_session) keeps being renewed for four hours."""
    with _SO_LOCK:
        ent = _SO_SESS.get(key)
        if ent:
            ent['until'] = max(ent['until'], time.time() + 25 * 60)
            return
        _SO_SESS[key] = {'until': time.time() + 25 * 60, 'tok': tok, 'hdr': hdr, 'stream': stream_id, 'st': dict(state)}
    t = threading.Thread(target=_so_keep_loop, args=(key,), daemon=True)
    t.start()


def _so_keep_loop(key):
    fails = 0
    while True:
        time.sleep(240)
        ent = _SO_SESS.get(key)
        if not ent or time.time() > ent['until']:
            _SO_SESS.pop(key, None)
            return
        st = ent['st']
        try:
            r = requests.get(ent['tok'], params={'scode': st['scode'], 'stream': ent['stream'], 'expires': st['ts'], 'u_id': st['device_id'],
                                                 'session_id': st['session_id'], 'host_id': st['host_id'], 'r': '1'}, headers=ent['hdr'], timeout=10)
            j = r.json()
            if j.get('success'):
                fails = 0
                st.update({'scode': j.get('scode', st['scode']), 'ts': j.get('ts', st['ts']), 'session_id': j.get('session_id', st['session_id']),
                           'host_id': j.get('host_id') or st['host_id']})
                if j.get('device_id') and j['device_id'] != st['device_id']:
                    _log('so: session got a new device id; the playing address is no longer renewed')
                    _SO_SESS.pop(key, None)
                    return
                continue
        except Exception:
            pass
        fails += 1
        if fails >= 3:
            _SO_SESS.pop(key, None)
            return


def keep_session(url):
    """The address was picked to play: keep its Strikeout session alive for hours (a no-op for any other address)."""
    ent = _SO_SESS.get((url or '').split('|')[0].split('?')[0])
    if ent:
        ent['until'] = time.time() + 4 * 3600


def _so_stream(page_url, probe=False):
    """A Strikeout stream page -> ('stream', playlist address with the headers the edge wants). The page frames a player on a rotating
    host (/sd0embed/<sport>?...tokens from the page's own siteConfig); that player's config holds a playlist on an edge host plus a session
    that has to be opened at its token service first (the player does the same, then renews it every five minutes)."""
    import json as _json
    import base64 as _b64
    from urllib.parse import urlencode, urlsplit, urlunsplit, parse_qsl
    site = '%s://%s/' % (urlparse(page_url).scheme, urlparse(page_url).netloc)     # Strikeout and VIPLeague run the same player
    html = _get(page_url, referer=site)
    m = re.search(r'const siteConfig = (\{.*?\});\s*(?:</script>|const|var|\n)', html, re.S)
    tag = re.search(r'<script[^>]+embed\.min\.js[^>]*>', html)
    if not m or not tag:
        return None
    cfg = _json.loads(m.group(1))
    d = dict(re.findall(r'data-([a-z]+)="([^"]*)"', tag.group(0)))
    if not d.get('pldm') or not d.get('play'):
        return None
    emb = 'https://%s/sd0embed/%s?%s' % (d['pldm'], d.get('gc') or 'sports', urlencode({
        'pid': d.get('pid', ''), 'v': d['play'], 'player': d.get('player', 'jw'), 'csrf': cfg.get('csrf', ''),
        'csrf_ip': cfg.get('csrf_ip', ''), 'expires': cfg.get('sec_expires', ''), 'sec_hash': cfg.get('sec_hash', '')}))
    player = _get(emb, referer=page_url)
    pm = re.search(r'SecKeyPlayerConfig\["[^"]+"\]=(?=\{)', player)
    if not pm:
        return None                                    # the player page of a game that is not on the air shows an offline screen
    try:
        pc = _json.JSONDecoder().raw_decode(player[pm.end():])[0]
    except ValueError:
        return None
    if probe:
        return True                                    # only asked whether the game is on the air (no session is opened)

    def plain(x):
        try:
            y = _b64.b64decode(x).decode()
            return y if re.fullmatch(r'[ -~]+', y) else x
        except Exception:
            return x
    tok = plain(pc.get('secTokenUrl', ''))
    if not tok.startswith('http') or not pc.get('urlSource'):
        return None
    ua = {'User-Agent': UA, 'Referer': emb, 'Origin': 'https://' + d['pldm']}
    hdr = dict(ua, **{'X-CSRF-Auth': _b64.b64decode(pc['csrf_token']).decode(), 'Accept': 'application/json'})
    r = requests.get(tok, params={'scode': pc['sCode'], 'stream': pc['strUnqId'], 'expires': pc['expireTs'], 'u_id': pc['device_id'],
                                  'session_id': pc['session_id'], 'host_id': pc.get('edgeHostId', '')}, headers=hdr, timeout=_TIMEOUT)
    j = r.json()
    if not j.get('success'):
        return None
    sp = urlsplit(pc['urlSource'])
    q = dict(parse_qsl(sp.query))
    q['u_id'] = j.get('device_id') or pc['device_id']
    src = urlunsplit(sp._replace(query=urlencode(q)))
    _so_keep_start(src.split('?')[0], tok, hdr, pc['strUnqId'], {
        'scode': j.get('scode'), 'ts': j.get('ts'), 'device_id': q['u_id'], 'session_id': j.get('session_id'), 'host_id': j.get('host_id') or pc.get('edgeHostId', '')})
    # the playlist is named manifest.ts: without the type header the player would open it as a plain TS file
    return 'stream', '%s|User-Agent=%s&Referer=%s&Origin=%s&X-SF-Type=hls' % (
        src, requests.utils.quote(UA, safe=''), requests.utils.quote(emb, safe=''), requests.utils.quote('https://' + d['pldm'], safe=''))


_RE_VL_ROW = re.compile(r'<a href="(/now-playing/[a-z0-9\-]+/[a-z0-9\-]+)" title="([^"]+)"[^>]*>.*?<time[^>]+content="([^"]+)"', re.S)


def _p_vl(page, base):
    """VIPLeague (vipleague.li): the "watch now" page lists the games on the air and the ones about to start, each a game page
    (/now-playing/<sport>/<A>-vs-<B>) whose "Video N" buttons are player pages of the Strikeout engine (see _vl_feeds)."""
    out, seen = [], set()
    now = _dt.datetime.now(_dt.timezone.utc)
    for href, title, when in _RE_VL_ROW.findall(page):
        try:
            start = _dt.datetime.strptime(when[:16], '%Y-%m-%dT%H:%M').replace(tzinfo=_dt.timezone.utc)
        except ValueError:
            start = None
        if start is not None and not (-5 * 3600 < (start - now).total_seconds() < 2700):
            continue                                   # over, or not for hours yet
        title = _event_title(title).replace(' - ', ' vs ')
        if title and href not in seen:
            seen.add(href)
            out.append((title, urljoin(base, href)))
    return out


def _vl_feeds(href):
    """[(n, player page url)] of a VIPLeague game page."""
    try:
        page = _get(href, referer='https://vipleague.li/')
    except Exception as e:
        _log('vl page: %s' % str(e)[:80])
        return []
    out, seen = [], set()
    for u in re.findall(r'(?:href|data-uri)="(/view-live/[a-z0-9\-]+/[a-z0-9\-]+-link-\d+)"', page):
        if u not in seen:
            seen.add(u)
            out.append((len(out) + 1, urljoin(href, u)))
    return out


_RE_FN_ROW = re.compile(r'<a href="([^"]+\.html)"\s*>\s*<div class="user-item__name">([^<]+)</div>', re.S)


def _p_fn(page, base):
    """FawaNews (fawanews.sc): the home page lists today's games, a page per channel ("<A> vs <B> --- CH 2"); the page's player
    holds a plain playlist (see _fn_stream)."""
    out, seen = [], set()
    for href, name in _RE_FN_ROW.findall(page):
        title = re.sub(r'\s*---\s*CH\s*\d+\s*$', '', _html.unescape(name)).strip()
        if title and href not in seen:
            seen.add(href)
            out.append((_event_title(title), urljoin(base, requests.utils.quote(href))))
    return out


_RE_FN_FULL = re.compile(r'<a href="([^"]+\.html)"\s*>\s*<div class="user-item__name">([^<]+)</div>.*?<div class="user-item__playing">([^<]*)', re.S)


def fn_games(menu):
    """[{title, league, kind, href, start_ts, live}] of the FawaNews channels that are on the air now, for the "soccer" or "basketball"
    menu: the site lists games that no schedule carries (second divisions, small countries, youth cups), and a row is only kept when its
    playlist answers, so every game listed plays."""
    ck = 'fn_games_%s' % menu
    c = _cache()
    hit = c.get(ck)
    if hit is not None:
        return hit
    base = 'http://www.fawanews.sc/'
    try:
        page = _get(base + 'index.html', referer=base)
    except Exception as e:
        _log('fn games: %s' % str(e)[:80])
        return []
    cand, seen = [], set()
    for href, name, playing in _RE_FN_FULL.findall(page):
        title = _event_title(re.sub(r'\s*---\s*CH\s*\d+\s*$', '', _html.unescape(name)).strip())
        league = re.sub(r'\s*(?:\d{1,2}|--):(?:\d{2}|--)\s*$', '', _html.unescape(playing).replace('</b>', '')).strip()
        low = league.lower()
        kind = 'basketball' if low.startswith('basketball') else 'other' if any(
            k in low for k in ('cricket', 'darts', 'motogp', 'tennis', 'rugby', 'hockey', 'volleyball', 'handball')) else 'soccer'
        if kind != menu or ' vs ' not in title or title in seen:
            continue
        seen.add(title)
        cand.append((title, re.sub(r'^Basketball\s+', '', league), urljoin(base, requests.utils.quote(href))))
    out = []
    if cand:
        ex = ThreadPoolExecutor(max_workers=min(12, len(cand)))
        futs = [(x, ex.submit(_fn_stream, x[2])) for x in cand]
        ex.shutdown(wait=False)
        now = int(time.time())
        for (title, league, href), f in futs:
            try:
                ok = f.result(timeout=20)
            except Exception:
                ok = None
            if ok:
                out.append({'title': title, 'league': league, 'kind': menu, 'href': href, 'start_ts': now, 'live': True})
    c.set(ck, out, 120 if out else 30)
    return out


def _fn_stream(page_url):
    """A FawaNews channel page -> ('stream', playlist). The page builds its playlist address from a list of hosts plus a file name; the
    hosts answer only when the site is the referer, and some of them are down, so the first that answers is used."""
    html = _get(page_url, referer='http://www.fawanews.sc/')
    names = dict(re.findall(r'var (\w+)\s*=\s*"([^"]*)"', html))
    hosts = []
    for blk in re.findall(r'var \w+\s*=\s*\[(.*?)\]', html, re.S):
        hosts += re.findall(r'"(https?://[^"]+)"', blk)
    tail = ''
    m = re.search(r'var (\w+)\s*=\s*"([^"]*)";\s*var (\w+)\s*=\s*"(\.m3u8)"', html)
    if m:
        tail = m.group(2) + m.group(4)
    if not hosts:
        m2 = re.search(r'var (\w+)\s*=\s*"(https?://[^"]+/hls/)";\s*var (\w+)\s*=\s*"([^"]+)";\s*var (\w+)\s*=\s*"(\.m3u8)"', html)
        if m2:
            hosts, tail = [m2.group(2)], m2.group(4) + m2.group(6)
    ua = {'User-Agent': UA, 'Referer': 'http://www.fawanews.sc/'}
    for h in hosts:
        u = h + tail
        try:
            r = requests.get(u, headers=ua, timeout=8)
        except Exception:
            continue
        if r.status_code == 200 and '#EXTM3U' in r.text[:20]:
            return 'stream', '%s|User-Agent=%s&Referer=%s' % (u, requests.utils.quote(UA, safe=''), requests.utils.quote('http://www.fawanews.sc/', safe=''))
    return None


_PL_BASE = 'https://addon.plavio.site'


def _p_pl(page, base):
    """Plavio's live catalogs (Stremio add-on JSON): [{id, name: "<game> · <source>"}] -> (title, stream endpoint). The 24/7 Pluto channels
    that share the big catalog are left out."""
    import json as _json
    out = []
    for m in (_json.loads(page).get('metas') or []):
        name = m.get('name') or ''
        if 'pluto' in name.lower() or not m.get('id'):
            continue
        title = name.rsplit('·', 1)[0].strip()
        if title:
            out.append((_event_title(title), '%s/stream/tv/%s.json' % (_PL_BASE, requests.utils.quote(m['id'], safe=''))))
    return out


def _pl_feeds(href):
    """A Plavio stream endpoint -> [(n, 'playlist|headers')]: the playlists that answer (the headers each one wants come with the entry)."""
    import json as _json
    try:
        data = _json.loads(_get(href, referer=_PL_BASE + '/'))
    except Exception:
        return []
    cand = []
    for s in (data.get('streams') or []):
        u = (s.get('url') or '').strip()
        if not u.startswith('http'):
            continue
        hd = dict(((s.get('behaviorHints') or {}).get('proxyHeaders') or {}).get('request') or {})
        hd = {k: re.sub(r'^%s=' % re.escape(k), '', str(v)) for k, v in hd.items()}      # (one entry carries "User-Agent=" in the value)
        hd.setdefault('User-Agent', UA)
        cand.append((u, hd))

    def ok(c):
        try:
            r = requests.get(c[0], headers=c[1], timeout=8)
            return r.status_code == 200 and '#EXTM3U' in r.text[:200]
        except Exception:
            return False
    out = []
    if cand:
        with ThreadPoolExecutor(max_workers=min(8, len(cand))) as ex:
            res = list(ex.map(ok, cand))
        for (u, hd), good in zip(cand, res):
            if good:
                out.append((len(out) + 1, _pl_pipe(u, hd)))
    return out


def _pl_pipe(u, hd):
    return u + '|' + '&'.join('%s=%s' % (k, requests.utils.quote(v, safe='')) for k, v in hd.items())


def _p_tm(page, base):
    """timst channels JSON: {"channels":[{"name","streams":[{"url"}]}]}"""
    import json as _json
    out = []
    for ch in (_json.loads(page).get('channels') or []):
        for st in ch.get('streams') or []:
            if st.get('url'):
                out.append((ch.get('name') or '', st['url']))
    return out


def _p_sm(page, base):
    """Streamic's own event feed (api/getEvents.php answers base64 of a JSON list): every game with channel embeds per language. Only
    the embeds the shared resolver can open are kept (DLHD player pages and Streamic's own /e/ players); the rest of the hosts it
    lists (shopping/lovetier/exmxbxe...) hand out nothing playable."""
    import json as _json
    try:
        data = _json.loads(base64.b64decode(page.strip() + '=' * (-len(page.strip()) % 4)))
    except Exception:
        return []
    out = []
    for e in data if isinstance(data, list) else []:
        title = _event_title((e.get('title') or '').replace(' - ', ' vs '))
        if not title:
            continue
        for lang in e.get('_embeds') or []:
            for v in (lang.get('embeds') or {}).values():
                u = (v.get('embed') or '').strip()
                host = urlparse(u).netloc.lower()
                if host in ('dlhd.pk', 'dlhd.st') or (host == 'streamic.st' and '/e/' in u):
                    out.append((title, u))
    return out


def _p_nm(page, base):
    """NBAMonster's own game feed (api/live/nba, api/live/nhl): every game of the day with several channel links, each a smartplayer
    page that the shared resolver opens down to the playlist."""
    import json as _json
    try:
        data = _json.loads(page)
    except ValueError:
        return []
    out = []
    for g in data.get('live_games') or []:
        title = _event_title('%s vs %s' % (g.get('away') or '', g.get('home') or ''))
        if not g.get('home') or not g.get('away'):
            continue
        for l in g.get('links') or []:
            u = (l.get('URL') or '').strip()
            if u.startswith('http'):
                out.append((title, u))
    return out


def _p_bt(page, base):
    """BinTV's own match feed (the JSON its site draws from): every game on the air, with several channel links each. A link is a
    player page of the TimStreams family (ehgembxe.cfd/bintv/<id>) or a small wrapper page; the shared resolver opens both."""
    import json as _json
    out = []
    try:
        data = _json.loads(page)
    except ValueError:
        return out
    for ev in data.get('Live Events') or []:
        title = _event_title(ev.get('name'))
        for st in ev.get('streams') or []:
            enc = (st.get('url') or '').split('id=')[-1]
            if not title or not enc:
                continue
            try:
                link = base64.b64decode(enc + '=' * (-len(enc) % 4)).decode('utf-8', 'ignore').strip()
            except Exception:
                continue
            if link.startswith('http'):
                out.append((title, link))
    return out


_RE_ST_EVENT = re.compile(r'href="(https://streamit\.st/events/[a-z0-9-]+/watch-([a-z0-9-]+?)-\d{4}-\d{2}-\d{2})"')


def _p_st(page, base):
    """Streamit's home page: one link per game (/events/<sport>/watch-<team>-vs-<team>-<date>). The game's player page lists its
    channels (see resolve_page)."""
    out, seen = [], set()
    for href, slug in _RE_ST_EVENT.findall(page):
        if href in seen:
            continue
        seen.add(href)
        out.append((slug.replace('-', ' ').title().replace(' Vs ', ' vs '), href.replace('/events/', '/embed/events/', 1).replace('/watch-', '/', 1)))
    return out


_RE_TT = re.compile(r'<a class="game"[^>]*\bhref="([^"]+)"[^>]*>(.*?)</a>', re.S)


def _p_tt(page, base):
    """TheTVApp's schedule: one <a class="game"> per game (matchup, start time, status); its game page has numbered server buttons
    that fill a player iframe (see _iframe_of)."""
    out, seen = [], set()
    for href, block in _RE_TT.findall(page):
        m = re.search(r'class="matchup">\s*([^<]+?)\s*<', block)
        if not m or href in seen:
            continue
        seen.add(href)
        out.append((_html.unescape(m.group(1)).strip(), urljoin(base, _html.unescape(href).strip())))
    return out


def _p_sx(page, base):
    """SportsindX's schedule (/new): one /match/<slug> link per game with the matchup as its text; a game's embed links come from
    its /streams/<slug> JSON (see _sx_streams), which links_for expands into one row per feed."""
    out, seen = [], set()
    for slug in re.findall(r'href="/match/([^"#?]+)"', page):
        if slug in seen:
            continue
        seen.add(slug)
        out.append((slug.replace('-', ' ').replace(' at ', ' @ ').title().replace(' Vs ', ' vs '), base.rstrip('/') + '/streams/' + slug))
    return out


def _p_bg(page, base):
    """Bingr's open match list (/api/sports/matches): one /api/sports/streams/<id> JSON per game (its feeds are read by links_for)."""
    import json as _json
    try:
        data = _json.loads(page)
    except ValueError:
        return []
    out = []
    for m in data if isinstance(data, list) else []:
        t, i = _event_title(m.get('title')), m.get('id')
        if t and i:
            out.append((t, base.rstrip('/') + '/api/sports/streams/' + i))
    return out


def _bg_feeds(url):
    """[(label, playlist address)] of one Bingr game: HLS feeds only (some go through Bingr's own proxy, some are DAMITV channels)."""
    try:
        j = requests.get(url, headers={'User-Agent': UA, 'Referer': 'https://bingr.one/'}, timeout=_TIMEOUT).json()
    except Exception as e:
        _log('bingr feeds: %s' % str(e)[:80])
        return []
    out = []
    for f in j if isinstance(j, list) else []:
        u = f.get('url') or ''
        if f.get('kind') == 'hls' and u.startswith('http') and 'streamrip.fun' in u:   # the DAMITV channel feeds answer but their segments are refused
            out.append((re.sub(r'[^\w \-|()]+', '', f.get('label') or 'Feed').strip() or 'Feed', u))
    return out


def _p_s8(page, base):
    """Score808's sport page: one /links/<teams> page per game; links_for expands it into that page's feeds (see _s8_feeds)."""
    out, seen = [], set()
    for slug in re.findall(r'href="/links/([^"#?]+)"', page):
        if slug in seen:
            continue
        seen.add(slug)
        out.append((slug.replace('-', ' ').title().replace(' Vs ', ' vs '), base.rstrip('/') + '/links/' + slug))
    return out


# player hosts on a Score808 links page that Starfleet opens (the rest are ad-wrapped pages with no playlist to read)
_S8_HOSTS = ('vertex.st', 'vivtops.st', 'universaltokenforall.st', 'sportsguru.st', 'nexa.st', 'kora.st', 'embed.st', 'streamed.pk',
             'sportspatrika.com', 'topembed.online', 'streameo.online')


def _s8_host_ok(url):
    h = urlparse(url).netloc.lower()
    return any(h == x or h.endswith('.' + x) for x in _S8_HOSTS)


def _s8_feeds(url):
    """[(n, embed address)] of one Score808 links page: its buttons open hitcast.st/totview.php?src=<player page>."""
    try:
        page = requests.get(url, headers={'User-Agent': UA, 'Referer': 'https://score-808.st/'}, timeout=_TIMEOUT).text
    except Exception as e:
        _log('score808 links: %s' % str(e)[:80])
        return []
    out, seen = [], set()
    for u in re.findall(r'totview\.php\?src=(https?://[^"\\\s<]+)', page):
        if u in seen or not _s8_host_ok(u):
            continue
        seen.add(u)
        out.append((len(out) + 1, u))
    return out


def _sx_streams(url):
    """The feeds of one SportsindX game: [(feed name, embed address)] (the embeds are topembed / streameo / sportspatrika / sportsguru /
    CharlieStreams / Aura / StreamFree / PPV wrapper pages that resolve_link opens)."""
    try:
        j = requests.get(url, headers={'User-Agent': UA, 'Referer': 'https://sportsindx.st/'}, timeout=_TIMEOUT).json()
    except Exception as e:
        _log('sportsindx streams: %s' % str(e)[:80])
        return []
    out = []
    for s in ((j.get('data') or {}).get('streams') or []):
        u = s.get('embedUrl') or ''
        if u.startswith('http') and s.get('linkType', 'iframe') == 'iframe':
            out.append(((s.get('name') or 'Stream').strip(), u))
    return out


# code -> (label, base, {sport slug: path}, parser)
_PROVIDERS = {
    'sx': ('SportsindX', 'https://sportsindx.st', {'*': 'new'}, _p_sx),
    'bg': ('Bingr', 'https://bingr.one', {'*': 'api/sports/matches'}, _p_bg),
    's8': ('Score808', 'https://score-808.st', {'nba': 'nba', 'nfl': 'nfl', 'nhl': 'nhl', 'mlb': 'baseball', 'boxing': 'boxing', 'f1': 'f1',
                                                'ufc': 'ufc', 'mma': 'ufc', 'rugby': 'rugby'}, _p_s8),
    'se': ('StreamEast', 'https://streameast.cool',
           {'nhl': 'nhlstreams', 'nfl': 'nflstreams', 'nba': 'nbastreams', 'mlb': 'mlbstreams', 'ufc': 'mmastreams',
            'boxing': 'boxingstreams', 'cfb': 'cfbstreams', 'ncaab': 'ncaabstreams', 'wwe': 'wwestreams3'}, _p_se),
    'vg': ('StreamEast VG', 'https://streameast.vg',
           {'nhl': 'nhl', 'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'ufc': 'mma', 'boxing': 'boxing', 'cfb': 'college-football', 'wwe': 'wwe'}, _p_vg),
    'ps': ('PlayoffsStream', 'https://playoffsstream.com',
           {'nhl': 'nhl-streams', 'nfl': 'nfl-streams', 'nba': 'nba-streams', 'mlb': 'mlb-streams', 'ufc': 'ufc-streams',
            'boxing': 'boxing-streams', 'cfb': 'ncaaf-streams', 'ncaab': 'ncaam-streams'}, _p_ps),
    'p7': ('720pStream', 'https://720pstream.cx',
           {'nhl': 'nhl-online', 'nfl': 'nfl-online', 'nba': 'nba-online', 'mlb': 'mlb-online', 'ufc': 'mma-online',
            'boxing': 'boxing-online', 'cfb': 'ncaaf-online', 'ncaab': 'ncaam-online', 'soccer': 'soccer-online'}, _p_p7),
    'ih': ('iHDStreams', 'https://ihdstreams.top',
           {'nhl': '?sport=NHL', 'nfl': '?sport=NFL', 'nba': '?sport=NBA', 'mlb': 'index.php?sport=MLB', 'ufc': '?sport=UFC',
            'boxing': '?sport=Boxing', 'cfb': '?sport=CFB', 'ncaab': '?sport=NCAAB', 'soccer': '?sport=Soccer', 'wwe': '?sport=WWE'}, _p_ih),
    'fs': ('FSportsHD', 'https://fsportshdz.xyz',
           {'nfl': 'nflstreams.php', 'ufc': 'mmastreams.php', 'soccer': 'footballstreams.php'}, _p_fs),
    'g2': ('GStream24', 'https://gstream24.fun',
           {'nhl': 'sport/nhl/', 'nfl': 'sport/nfl/', 'nba': 'sport/nba/', 'mlb': 'sport/mlb/', 'ufc': 'sport/ufc/',
            'boxing': 'sport/boxing/', 'cfb': 'sport/college-football/', 'ncaab': 'sport/mens-college-basketball/'}, _p_g2),
    'vk': ('VoloKit', 'http://volokit2.fun',
           {'nhl': 'sport/nhl', 'nfl': 'sport/nfl', 'nba': 'sport/nba/', 'mlb': 'sport/mlb/', 'ufc': 'sport/ufc/',
            'boxing': 'sport/boxing/', 'cfb': 'sport/college-football', 'ncaab': 'sport/mens-college-basketball/'}, _p_vk),
    'bf': ('BuffStreams', 'https://mybuffstreams.plus',
           {'nhl': 'nhlstreams', 'nfl': 'nflstreams', 'nba': 'nbastreams', 'mlb': 'mlb-live-streams', 'ufc': 'mmastreams',
            'boxing': 'boxingstreams', 'cfb': 'cfbstreams', 'ncaab': 'ncaastreams', 'soccer': 'soccer-live-streams',
            'wwe': 'wwestreams', 'f1': 'f1streams2'}, _p_bf),
    'sc': ('StreamCenter', 'https://streamcenter.st/game-cards/embed',
           {'nhl': '?sport=hockey', 'nfl': '?sport=football', 'cfb': '?sport=football', 'nba': '?sport=basketball',
            'ncaab': '?sport=basketball', 'mlb': '?sport=baseball', 'soccer': '?sport=soccer'}, _p_sc),
    'sh': ('StreamHD', 'https://streamhd247.click', {'*': 'index.html'}, _p_sh),
    'sf': ('Streamsify', 'https://streamsify.xyz', {'*': ''}, _p_sf),
    'ss': ('SportSurge', 'https://isportsurge.ws', {'*': 'index8'}, _p_ss),
    'rs': ('RoxieStreams', 'https://roxiestreams.biz',
           {'nhl': 'nhl', 'nfl': 'nfl', 'cfb': 'nfl', 'nba': 'nba', 'ncaab': 'nba', 'mlb': 'mlb', 'soccer': 'soccer',
            'ufc': 'fighting', 'mma': 'fighting', 'boxing': 'fighting', 'wwe': 'fighting',
            'f1': 'motorsports', 'motogp': 'motorsports', 'nascar': 'motorsports'}, _p_rs),
    'ms': ('MethStreams', 'https://methstreams.gs',
           {'nhl': 'league/nhlstreams', 'nfl': 'league/nflstreams', 'nba': 'league/nbastreams', 'mlb': 'league/mlbstreams',
            'soccer': 'league/soccerstreams', 'ufc': 'league/mmastreams', 'mma': 'league/mmastreams',
            'boxing': 'league/boxingstreams', 'cfb': 'league/cfbstreams', 'ncaab': 'league/nbastreams',
            'wwe': 'category/wwe-aew', 'f1': 'league/f1streams'}, _p_ms),
    'sk': ('StreamEast 2', 'https://streameast.cool',
           {'nba': 'nbastreams4', 'nfl': 'nflstreams4', 'cfb': 'cfbstreams4', 'nhl': 'nhlstreams4', 'ncaab': 'ncaabstreams4',
            'ufc': 'mmastreams4', 'mma': 'mmastreams4', 'boxing': 'boxingstreams4', 'f1': 'f1streams4', 'mlb': 'mlbstreams4'}, _p_sk),
    'nb': ('NBAbite', 'https://nbabitez.com', {'nba': ''}, _p_nb),
    'nf': ('NFLbite', 'https://www.nflbite.is', {'nfl': ''}, _p_nb),
    'tk': ('TotalSportek Links', 'https://totalsportekl.is', {'*': ''}, _p_nb),
    'tp': ('TopStreamer', 'https://topstreamer.site',
           {'nfl': 'nfl/schedule', 'nba': 'nba/schedule'}, _p_tp),
    'eh': ('RockyLive', 'https://rockylive.st', {'*': 'api-event.php'}, _p_eh),
    'tm': ('TimStreams', 'https://tim-streams.com', {'*': 'api/channels'}, _p_tm),
    'rp': ('Ripple Network', 'https://ripplestream.cyou', {'*': ''}, _p_rp),
    'pv': ('PPV', 'https://api.ppv.st', {'*': 'api/streams'}, _p_pv),
    'dm': ('DAMITV', 'https://ondemand.st', {'*': 'papi/api/streams'}, _p_dm),
    'au': ('Aura Sports', 'https://aurasports.cfd', {'*': 'api/schedule'}, _p_au),
    'ws': ('WatchSports', 'https://watchsports.su',
           {'nfl': 'nfl', 'nba': 'nba', 'nhl': 'nhl', 'mlb': 'mlb', 'cfb': 'cfb', 'wnba': 'wnba', 'ncaab': 'college-basketball',
            'ncaaw': 'college-basketball', 'soccer': 'football', 'mls': 'football', 'tennis': 'tennis', 'f1': 'f1',
            'motogp': 'f1', 'motorsports': 'nascar|indycar|nhra|f1', 'ufc': 'mma', 'mma': 'mma', 'boxing': 'boxing', 'wwe': 'wwe|aew',
            'golf': 'golf', 'cricket': 'cricket', 'rugby': 'rugby', 'volleyball': 'volleyball', 'afl': 'afl'}, _p_ws),
    'sko': ('Strikeout', 'https://strikeout.im',
           {'nfl': 'nfl', 'nba': 'nba|basketball', 'nhl': 'nhl|hockey', 'mlb': 'mlb', 'cfb': 'ncaaf', 'ncaab': 'ncaam|basketball', 'wnba': 'basketball',
            'basketball': 'basketball', 'hockey': 'hockey', 'ice-hockey': 'hockey',
            'soccer': 'soccer', 'mls': 'soccer', 'tennis': 'tennis', 'f1': 'f1', 'motogp': 'motogp', 'motorsports': 'motorsports|nascar|f1|motogp',
            'ufc': 'ufc|mma|fighting', 'mma': 'mma|fighting', 'boxing': 'boxing|fighting', 'wwe': 'wwe', 'golf': 'golf', 'rugby': 'rugby', 'afl': 'afl',
            'ncaah': 'hockey', 'cfl': 'football', 'darts': 'darts', 'cycling': 'cycling', 'snooker': 'snooker', 'rugby': 'rugby',
            'handball': 'handball', 'volleyball': 'volleyball', 'others': 'others', 'baseball': 'baseball', 'other_international': 'others'}, _p_so),
    'bt': ('BinTV', 'https://bintvjson.lovable.app', {'*': 'api/matches/bintvjson'}, _p_bt),
    'sm': ('Streamic', 'https://streamic.st', {'*': 'api/getEvents.php'}, _p_sm),
    'nm': ('NBAMonster', 'https://nbamonster.com', {'nba': 'api/live/nba', 'nhl': 'api/live/nhl'}, _p_nm),
    'st': ('Streamit', 'https://streamit.st', {'*': ''}, _p_st),
    'vl': ('VIPLeague', 'https://vipleague.li', {'*': 'watch-now'}, _p_vl),
    'fn': ('FawaNews', 'http://www.fawanews.sc', {'*': 'index.html'}, _p_fn),
    'pl': ('Plavio', 'https://addon.plavio.site', {'*': 'catalog/tv/plaviohd-live-roxie.json|catalog/tv/plaviohd-live-plaviotv.json|catalog/tv/plaviohd-live-ksportslive.json|catalog/tv/plaviohd-live-tv.json'}, _p_pl),
    'tt': ('TheTVApp', 'https://thetvapp.plus', {'*': ''}, _p_tt),      # the site root forwards to its current version page (v12 -> v13 ...)
}
# sports some providers cover that the first table left out (their league pages)
for _c, _extra in {
        'vg': {'f1': 'f1', 'motogp': 'f1'},
        'ih': {'f1': '?sport=F1'},
        'g2': {'f1': 'sport/race/', 'motogp': 'sport/race/'},
        'vk': {'f1': 'sport/race/', 'motogp': 'sport/race/'},
        'se': {'f1': 'f1streams3'},
        'fs': {'motogp': 'motogpstreams.php', 'f1': 'f1streams.php'},
}.items():
    _PROVIDERS[_c][2].update(_extra)
LABEL = {k: v[0] for k, v in _PROVIDERS.items()}
# another address of the same site, tried when the first does not answer
_ALT_BASES = {'au': ('https://aurasports.xyz',), 'ws': ('https://watchsports.to', 'https://wtchsprts.st')}


def _cache():
    from starfleetscrapers.sports import sports_sources as _ss
    return _ss._cache


def _rows(code, sport_slug):
    label, base, paths, parser = _PROVIDERS[code]
    path = paths.get(sport_slug)
    if path is None:
        path = paths.get('*')
    if path is None:
        return []
    ck = 'livepages_%s_%s' % (code, '*' if '*' in paths and sport_slug not in paths else sport_slug)
    c = _cache()
    hit = c.get(ck)
    if hit is not None:
        return hit
    rows = []
    # a provider can list a sport over several pages ("nascar|indycar") and can have another address to fall back on
    for sub in path.split('|'):
        got, err = None, None
        for b in [base] + list(_ALT_BASES.get(code, ())):
            url = b.rstrip('/') + '/' + sub.lstrip('/')
            try:
                text = _get_tim(url, b) if code == 'tm' else _get(url, referer=b + '/')
                got = parser(text, b + '/')
                break
            except Exception as e:
                err = e
        if got is None:
            _log('%s %s listing: %s' % (code, sport_slug, str(err)[:80]))
        else:
            rows += got
    c.set(ck, rows, 300 if rows else 30)
    return rows


def warm():
    """Fetch the whole-list feeds ahead of time (PPV, DAMITV, Aura...), so opening a game does not wait for them: on a slow device
    these were still running when the 6 s window for the game pages closed, and the game showed without them."""
    codes = [k for k, v in _PROVIDERS.items() if '*' in v[2]]
    ex = ThreadPoolExecutor(max_workers=len(codes) or 1)
    for k in codes:
        ex.submit(_rows, k, '*')
    ex.shutdown(wait=False)


def _expand_one(code, href):
    """The playable rows behind one matched game row of a provider whose game page has to be opened: [(code, {'label', 'url'})]."""
    if code == 'bg':
        return [(code, {'label': '%s' % lab[:30] if lab else 'Feed %d' % n, 'url': 'bgs:' + u}) for n, (lab, u) in enumerate(_bg_feeds(href)[:6], 1)]
    if code == 's8':
        return [(code, {'label': 'Link %d' % n, 'url': 'embed:' + emb}) for n, emb in _s8_feeds(href)[:6]]
    if code in ('nb', 'nf', 'tk'):         # one row per working mirror of the game
        return [(code, {'label': '%s %d' % (LABEL[code], n), 'url': u}) for n, u in _nb_feeds(href)]
    if code == 'sko':                       # a game page has a player page per stream button
        return [(code, {'label': 'Strikeout %d' % n, 'url': sp_}) for n, sp_ in _so_feeds(href)[:6]]
    if code == 'vl':                        # a game page has a player page per "Video N" button
        return [(code, {'label': 'VIPLeague %d' % n, 'url': vp}) for n, vp in _vl_feeds(href)[:6]]
    if code == 'pl':                        # a game has one playlist per feed, each with the headers it wants
        return [(code, {'label': 'Plavio %d' % n, 'url': 'pls:' + pu}) for n, pu in _pl_feeds(href)[:6]]
    if code == 'ws':                       # a game page lists several players; the ones that open are kept
        return [(code, {'label': 'WatchSports %d' % n, 'url': 'embed:' + emb}) for n, emb in _ws_feeds(href)[:6]]
    if code == 'sx':                       # one row per feed of the game
        return [(code, {'label': name, 'url': 'embed:' + emb}) for name, emb in _sx_streams(href)[:8]]
    return []


_EXPAND_CODES = ('bg', 's8', 'nb', 'nf', 'tk', 'sko', 'vl', 'pl', 'ws', 'sx')


def _provider_links(code, sport_slug, title, match_fn):
    """One provider, start to end: its listing, the rows that are this game, and the playable rows behind them."""
    out = []
    for t, href in _rows(code, sport_slug):
        if not (match_fn(title, t) or (code == 'rp' and t.strip().lower() == sport_slug)):
            continue      # (Ripple lists a whole race series under one row, 'F1' / 'Motogp')
        if code == 'sko' and sport_slug in ('motogp', 'f1', 'motorsports') and any(
                (c_ in title.lower()) != (c_ in t.lower()) for c_ in ('moto2', 'moto3')):
            continue      # a Moto2 / Moto3 race is not the MotoGP feed of the same weekend (and the other way round)
        if code in _EXPAND_CODES:
            out += _expand_one(code, href)
        elif code == 'fn':
            mch = re.search(r'CH%20(\d+)', href) or re.search(r'CH (\d+)', href)
            out.append((code, {'label': 'FawaNews CH %s' % mch.group(1) if mch else 'FawaNews', 'url': href}))
        else:
            out.append((code, {'label': LABEL[code], 'url': href}))
    return out


def links_for(sport_slug, title, match_fn, deadline=11.0):
    """[(provider code, {'label', 'url'})] for the rows of every provider that are this game. Every provider is worked through on its
    own thread (listing, match, game page) under one overall deadline, and what has answered by then is returned: one slow site no
    longer holds up (or throws away) the others."""
    codes = [k for k, v in _PROVIDERS.items() if sport_slug in v[2] or '*' in v[2]]
    if not codes:
        return []
    ex = ThreadPoolExecutor(max_workers=len(codes))
    futs = [(ex.submit(_provider_links, k, sport_slug, title, match_fn), k) for k in codes]
    ex.shutdown(wait=False)
    _wait([f for f, _k in futs], timeout=deadline)
    out, seen = [], set()
    for f, _k in futs:
        if not f.done():
            continue
        try:
            got = f.result()
        except Exception:
            continue
        for code, l in got:
            if l['url'] not in seen:
                seen.add(l['url'])
                out.append((code, l))
    return out


def _aes_tables():
    sbox = [0] * 256
    p = q = 1
    while True:
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        q ^= q << 1; q ^= q << 2; q ^= q << 4; q &= 0xFF
        if q & 0x80:
            q ^= 0x09
        x = q ^ (q << 1 | q >> 7) & 0xFF ^ (q << 2 | q >> 6) & 0xFF ^ (q << 3 | q >> 5) & 0xFF ^ (q << 4 | q >> 4) & 0xFF
        sbox[p] = (x ^ 0x63) & 0xFF
        if p == 1:
            break
    sbox[0] = 0x63
    inv = [0] * 256
    for i, v in enumerate(sbox):
        inv[v] = i
    return sbox, inv


_SBOX, _RSBOX = _aes_tables()


def _xt(a):
    a <<= 1
    return (a ^ 0x11B) & 0xFF if a & 0x100 else a


def _gm(a, b):
    r = 0
    for _ in range(8):
        if b & 1:
            r ^= a
        a = _xt(a)
        b >>= 1
    return r


def _aes128_decrypt_block(key, block):
    w = [list(key[4 * i:4 * i + 4]) for i in range(4)]
    rcon = 1
    for i in range(4, 44):
        t = list(w[i - 1])
        if i % 4 == 0:
            t = [_SBOX[b] for b in t[1:] + t[:1]]
            t[0] ^= rcon
            rcon = _xt(rcon)
        w.append([w[i - 4][j] ^ t[j] for j in range(4)])
    rk = [sum((w[r * 4 + c] for c in range(4)), []) for r in range(11)]

    def inv_shift(st):
        o = st[:]
        for r in range(1, 4):
            row = [st[r + 4 * c] for c in range(4)]
            row = row[-r:] + row[:-r]
            for c in range(4):
                o[r + 4 * c] = row[c]
        return o

    def inv_mix(st):
        o = [0] * 16
        for c in range(4):
            a = st[4 * c:4 * c + 4]
            o[4 * c] = _gm(a[0], 14) ^ _gm(a[1], 11) ^ _gm(a[2], 13) ^ _gm(a[3], 9)
            o[4 * c + 1] = _gm(a[0], 9) ^ _gm(a[1], 14) ^ _gm(a[2], 11) ^ _gm(a[3], 13)
            o[4 * c + 2] = _gm(a[0], 13) ^ _gm(a[1], 9) ^ _gm(a[2], 14) ^ _gm(a[3], 11)
            o[4 * c + 3] = _gm(a[0], 11) ^ _gm(a[1], 13) ^ _gm(a[2], 9) ^ _gm(a[3], 14)
        return o

    st = [block[i] ^ rk[10][i] for i in range(16)]
    for rnd in range(9, 0, -1):
        st = [_RSBOX[b] for b in inv_shift(st)]
        st = inv_mix([st[i] ^ rk[rnd][i] for i in range(16)])
    st = [_RSBOX[b] for b in inv_shift(st)]
    return [st[i] ^ rk[0][i] for i in range(16)]


def _solve_shield(page):
    """Cookie (name, value) for the host's JavaScript challenge page."""
    text = re.sub(r'\\x([0-9A-Fa-f]{2})', lambda m: chr(int(m.group(1), 16)), page)
    ck = re.search(r'document\.cookie\s*=\s*"([A-Za-z0-9_-]+)=', text)
    b1 = re.search(r'b1\s*=\s*atob\("([^"]+)"\)', text)
    c3 = re.search(r'c3\s*=\s*toNumbers\("([0-9a-fA-F]{32})"\)', text)
    arr = re.search(r'var\s+_0x\w+\s*=\s*\[(.*?)\];', text, re.S)
    if not (ck and b1 and c3 and arr):
        return None
    key = None
    for item in re.findall(r'"([A-Za-z0-9+/=]{40,})"', arr.group(1)):
        try:
            cand = base64.b64decode(item).decode()
            if re.fullmatch(r'[0-9a-fA-F]{32}', cand):
                key = bytes.fromhex(cand)
        except Exception:
            pass
    if not key:
        return None
    iv = bytes.fromhex(base64.b64decode(b1.group(1)).decode())
    pt = _aes128_decrypt_block(list(key), list(bytes.fromhex(c3.group(1))))
    return ck.group(1), bytes(x ^ y for x, y in zip(pt, iv)).hex()


def _get_tim(url, base):
    h = {'User-Agent': UA, 'Referer': base + '/', 'Accept': 'application/json, text/plain, */*', 'Accept-Encoding': 'identity'}
    sess = requests.Session()
    r = sess.get(url, headers=h, timeout=_TIMEOUT)
    body = r.content.decode('utf-8', 'replace')
    try:
        r.json()
        return body
    except Exception:
        pass
    solved = _solve_shield(body)
    if not solved:
        raise ValueError('challenge not understood')
    sess.cookies.set(solved[0], solved[1], domain=urlparse(base).netloc, path='/')
    r = sess.get(url, headers=h, timeout=_TIMEOUT)
    return r.content.decode('utf-8', 'replace')


# ── page url -> stream ───────────────────────────────────────────────────────

_RE_BTN = re.compile(r'(?s)id="stream-btn-(\d+)"[^>]*?>(.*?)</div>')
_RE_TMPL = re.compile(
    r"getElementById\(['\"](?:wp_player|cx-iframe)['\"]\)\.src\s*=\s*['\"]([^'\"]+)['\"]\s*\+\s*streamId(?:\s*\+\s*['\"]([^'\"]*)['\"])?")


def _iframe_of(page_url, page, referer):
    """The player iframe of a provider page (numbered server buttons fill it from a template)."""
    tmpl = _RE_TMPL.search(page)
    servers = _RE_BTN.findall(page)
    if tmpl and servers:
        return tmpl.group(1) + servers[0][0] + (tmpl.group(2) or '')
    m = re.search(r'(?is)<iframe[^>]+src=["\']([^"\']+)', page)
    return m.group(1) if m else None


_GOAT_HOSTS = ('embed.st', 'embedsports', 'pooembed', 'embedindia', 'taifood-blog')


def _is_goat(host_or_url):
    """True for a player host of the embed.st / embedsports family (dembed.st and similar names are other players)."""
    h = host_or_url.lower()
    if '/' in h:
        h = urlparse(h).netloc or h
    return h == 'embed.st' or h.endswith('.embed.st') or any(x in h for x in _GOAT_HOSTS[1:])


def _pipe_for(src, page_url):
    src = src.replace('\\u0026', '&').replace('\\/', '/')   # JSON-escaped addresses
    p = urlparse(page_url)
    origin = '%s://%s' % (p.scheme, p.netloc)
    return '%s|User-Agent=%s&Referer=%s&Origin=%s' % (
        src, requests.utils.quote(UA, safe=''), requests.utils.quote(origin + '/', safe=''), requests.utils.quote(origin, safe=''))


def _decode_array_payload(page):
    """Pages that hide a stream address in a number array, XOR key and offset (decoded here, not run)."""
    m = re.search(r'var\s+\w+\s*=\s*\[([\d,\s]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*""\s*,\s*\w+\s*;', page, re.S)
    if not m:
        return None
    arr = [int(n) for n in m.group(1).split(',') if n.strip()]
    k1, k2 = int(m.group(2)), int(m.group(3))
    text = ''.join(chr(((n ^ k1) - k2 + 256) & 255) for n in arr)
    mm = re.search(r'(?:\burl|SIGNED_URL)\s*=\s*"([^"]+)"', text)
    if not mm:
        return None
    return re.sub(r'(?<!:)/{2,}', '/', mm.group(1).replace('\\/', '/'))


def _is_playlist(url, referer):
    """True when `url` answers with an HLS playlist (some players publish it at an extension-less address)."""
    try:
        p = urlparse(referer)
        r = requests.get(url, headers={'User-Agent': UA, 'Referer': referer, 'Origin': '%s://%s' % (p.scheme, p.netloc)},
                         timeout=_TIMEOUT)
        return r.status_code == 200 and r.text.lstrip().startswith('#EXTM3U')
    except Exception:
        return False


def _streamit_event(url):
    """A Streamit game: its player page names a list of channels (a JSON manifest); the first channel that is online leads, through
    /embed/stream/<id>, to an embed.st player, which the caller resolves."""
    import json as _json
    hdr = {'Referer': 'https://streamit.st/'}
    page = _get(url, referer='https://streamit.st/')
    mc = re.search(r'data-watch-embed-config>(.*?)</script>', page, re.S)
    if not mc:
        return None
    try:
        man = requests.get(_json.loads(mc.group(1))['manifestUrl'], headers=dict(hdr, **{'User-Agent': UA}), timeout=_TIMEOUT).json()
    except Exception:
        return None
    for ch in sorted(man.get('premium') or [], key=lambda c: c.get('sort_order', 99)):
        if not ch.get('is_online') or not ch.get('id'):
            continue
        try:
            sp = _get('https://streamit.st/embed/stream/%s' % ch['id'], referer=url)
        except Exception:
            continue
        m = re.search(r'(?is)<iframe[^>]+src=["\']([^"\']+)', sp)
        if m and m.group(1).startswith('http'):
            return 'embed', _html.unescape(m.group(1))
    return None


def resolve_page(page_url):
    """Provider page -> ('stream', piped_url) for a decoded playlist, or ('embed', url) when the page leads to a player
    host the caller should resolve. Follows up to five page / iframe hops."""
    if page_url.startswith('bgs:'):                          # a Bingr feed: a playlist, DAMITV channels need DAMITV as the referer
        u = page_url[4:]
        return ('stream', _pipe_for(u, 'https://damitv.st/' if 'damitv.st' in u and 'streamrip' not in u else 'https://bingr.one/'))
    if 'strikeout.im/' in page_url and re.search(r'/\d+/[a-z0-9\-]+-stream$', page_url):   # a Strikeout stream page (see _so_stream)
        return _so_stream(page_url)
    if 'vipleague.li/view-live/' in page_url:                # a VIPLeague player page: the same engine as Strikeout
        return _so_stream(page_url)
    if 'fawanews.sc/' in page_url:
        return _fn_stream(page_url)
    if page_url.startswith('pls:'):                          # a Plavio feed: a playlist with its headers (some have no .m3u8 in the address)
        return 'stream', page_url[4:] + ('&' if '|' in page_url else '|') + 'X-SF-Type=hls'
    if page_url.startswith('embed:'):                       # a feed row that is already a player page (SportsindX): the caller resolves it
        return 'embed', page_url[6:]
    if _is_goat(page_url):                                  # already a player of the embed.st family: the caller resolves it
        return 'embed', page_url
    if any(k in page_url for k in ('extraplayer', 'embedextra', 'nizar.nexa.st')):   # a TotalSportek channel player: the live resolver opens it
        return 'embed', page_url
    _host = urlparse(page_url).netloc.lower()
    if _host in ('ehgembxe.cfd', 'epiembeds.online', 'embeds.gay') or _host.endswith('.github.io'):
        return 'embed', page_url                           # TimStreams-family players (BinTV): the shared resolver decodes them
    if _host == 'streamit.st' and '/embed/events/' in page_url:
        return _streamit_event(page_url)
    if page_url.startswith('dlhd:'):                       # a DLHD channel number (DAMITV lists those)
        try:
            from starfleetscrapers.sports import dlhd_players as _dlp
            res = _dlp.resolve_channel(page_url[5:])
        except Exception:
            res = None
        return ('stream', res['url']) if res and res.get('url') else None
    if page_url.startswith('direct:'):                     # a plain playlist address
        u = page_url[7:]
        return ('stream', _pipe_for(u, u)) if _is_playlist(u, u) else None
    cur, ref = page_url, page_url
    seen_hops = set()
    for _hop in range(5):
        page = _get(cur, referer=ref)
        # Ripple Network: the game page frames ripple.kora.st/ch?id=N, whose player is created by script from api/player.php;
        # the page it names (matchli.st) holds the signed playlist address in its player config
        host = urlparse(cur).netloc.lower()
        if host.endswith('ripple.kora.st') and '/ch' in urlparse(cur).path:
            cid = (re.search(r'[?&]id=(\d+)', cur) or [None, ''])[1]
            if not cid:
                return None
            try:
                pj = requests.get('%s://%s/api/player.php?id=%s' % (urlparse(cur).scheme, host, cid),
                                  headers={'User-Agent': UA, 'Referer': cur}, timeout=_TIMEOUT).json()
            except Exception:
                return None
            nxt = (pj or {}).get('url', '')
            if not nxt.startswith('http'):
                return None
            cur, ref = nxt, cur
            continue
        mm = re.search(r'window\.PP_CLAPPR_CONFIG\s*=\s*(\{.*?\})\s*;', page, re.S)
        if mm:
            import json as _json
            try:
                src = (_json.loads(mm.group(1)) or {}).get('src') or ''
            except Exception:
                src = ''
            if src.startswith('http'):
                if not _is_playlist(src, cur):          # the game's channel has to be on the air right now
                    return None
                return 'stream', _pipe_for(src, cur)
        # dembed.st player: the playlist lives on an edge that wants a short-lived token on every reload (kept fresh by the relay)
        if 'dembed.st' in host:
            em = re.search(r'(?:const|let|var)\s+EDGE\s*=\s*"([^"]+)"', page)
            cm = re.search(r'(?:const|let|var)\s+CHANNEL\s*=\s*"([^"]+)"', page)
            if em and cm:
                edge, slug = em.group(1).rstrip('/'), cm.group(1)
                hdr = {'User-Agent': UA, 'Referer': 'https://dembed.st/', 'Origin': 'https://dembed.st'}
                from starfleetscrapers.sports import local_proxy as _lp
                try:                    # the channel has to be on the air right now (an idle channel answers with an error)
                    _tok = _lp._edge_token(edge, slug, hdr)
                    _pl = requests.get('%s/%s/index.m3u8' % (edge, slug), params={'t': _tok}, headers=hdr, timeout=8)
                    if _pl.status_code != 200 or '#EXTM3U' not in _pl.text[:200]:
                        return None
                except Exception:
                    return None
                relay = _lp.build_etok_url(edge, slug, hdr)
                if relay:
                    return 'stream', relay
                try:
                    tok = _lp._edge_token(edge, slug, hdr)
                except Exception:
                    return None
                return 'stream', '%s/%s/index.m3u8?t=%s|User-Agent=%s&Referer=%s&Origin=%s' % (
                    edge, slug, requests.utils.quote(tok, safe=''), requests.utils.quote(UA, safe=''),
                    requests.utils.quote('https://dembed.st/', safe=''), requests.utils.quote('https://dembed.st', safe=''))
        # stream address hidden in a number array
        arr = _decode_array_payload(page)
        if arr and arr.startswith('http'):
            return 'stream', _pipe_for(arr, cur)
        # playlist published over a websocket (TopStreamer): served through the local relay, refreshed on every request
        if 'window.masterinf' in page and 'SERVICE_HOSTS' in page:
            mi = re.search(r'window\.masterinf\s*=\s*(\{.*?\})\s*;', page, re.S)
            hosts_m = re.search(r'const\s+SERVICE_HOSTS\s*=\s*\[([^\]]+)\]', page)
            chan_m = re.search(r"var\s+channel\s*=\s*'([^']+)'", page)
            path_m = re.search(r'new\s+WebSocket\(\s*"wss://"\s*\+\s*host\s*\+\s*"([^"]+)"', page)
            if mi and hosts_m and chan_m:
                import json as _json
                from starfleetscrapers.sports import local_proxy as local_proxy
                try:
                    inf = {k[:-5] if k.endswith('.m3u8') else k: v.get('inf', '') for k, v in _json.loads(mi.group(1)).items()}
                except Exception:
                    inf = {}
                p = urlparse(cur)
                from starfleetscrapers.sports import ws_playlist as ws_playlist
                hosts = re.findall(r'"([^"]+)"', hosts_m.group(1))
                rends = ws_playlist.fetch_renditions(hosts, chan_m.group(1), '%s://%s' % (p.scheme, p.netloc),
                                                     path_m.group(1) if path_m else '/websocket', wait=6)
                if not any(ws_playlist.freshness(t) > 0 for t in rends.values()):
                    return None
                url = local_proxy.build_tsws_url(chan_m.group(1), re.findall(r'"([^"]+)"', hosts_m.group(1)),
                                                 '%s://%s' % (p.scheme, p.netloc), inf, path_m.group(1) if path_m else '/websocket')
                return ('stream', url) if url else None
        # player address kept as base64 text and run through an XOR key twice (the two passes cancel out)
        mm = re.search(r'var\s+_raw\s*=\s*"([A-Za-z0-9+/=]+)"\s*;\s*var\s+_d\s*=\s*atob\(_raw\)', page)
        if mm and cur not in seen_hops:
            try:
                nxt = base64.b64decode(mm.group(1)).decode('utf-8', 'ignore').strip()
            except Exception:
                nxt = ''
            if nxt:
                seen_hops.add(cur)
                nxt = urljoin(cur, nxt)
                if _is_goat(nxt):
                    return 'embed', nxt
                cur, ref = nxt, cur
                continue
        # single-game pages that name the playlist in `globalurl` and add a fresh session id themselves
        mm = re.search(r"var\s+globalurl\s*=\s*'(https?://[^']+\.m3u8[^']*)'", page)
        if mm:
            import uuid as _uuid
            gurl = mm.group(1).split('&sessionId=')[0] + '&sessionId=' + str(_uuid.uuid4())
            piped = _pipe_for(gurl, cur)
            # protected games (NBA League Pass feeds) publish their ClearKey as `masterinf = {"<kid>": "<key>"}`
            km = re.search(r'masterinf\s*=\s*\{\s*"([0-9a-fA-F]{32})"\s*:\s*"([0-9a-fA-F]{32})"', page)
            if km:
                piped += '&X-Starfleet-License-Type=clearkey&X-Starfleet-License-Key=%s' % requests.utils.quote(
                    km.group(1).lower() + ':' + km.group(2).lower(), safe='')
            return 'stream', piped
        # playlist address built from a published host list (RoxieStreams)
        mm = re.search(r"getRandomStream\('([^']+\.m3u8)'(?:\s*,\s*'([^']+)')?", page)
        if mm:
            p = urlparse(cur)
            sub = mm.group(2) or (re.search(r"var\s+subdomain\s*=\s*'([^']+)'", page) or [None, 'admin2'])[1]
            try:
                doms = [d.strip() for d in _get('%s://%s/domainsz77.txt' % (p.scheme, p.netloc), referer=cur).split('\n') if d.strip()]
            except Exception:
                doms = []
            for dm in doms[:3]:
                u = 'https://%s.%s/%s' % (sub, dm, mm.group(1))
                try:
                    if requests.get(u, headers={'User-Agent': UA, 'Referer': cur}, timeout=8).text.startswith('#EXTM3U'):
                        return 'stream', _pipe_for(u, cur)
                except Exception:
                    continue
        # list of player links on the page (MethStreams): prefer hosts we can decode, else follow in order
        mm = re.search(r'const\s+allStreams\s*=\s*(\[.*?\]);', page, re.S)
        if mm:
            import json as _json
            try:
                links = [x.get('value', '').replace('\\/', '/') for x in _json.loads(mm.group(1))]
            except Exception:
                links = []
            links = [l for l in links if l.startswith('http')]
            for l in links:
                if _is_goat(l):
                    return 'embed', l
            for l in links[:3]:
                try:
                    sub_res = resolve_page(l) if _hop < 3 else None
                except Exception:
                    sub_res = None
                if sub_res:
                    return sub_res
            return None
        # base64 iframe address (rockystream / rockylive and relatives)
        m = re.search(r'atob\(["\']([A-Za-z0-9+/=]{16,})["\']\)', page)
        if m:
            try:
                dec = base64.b64decode(m.group(1)).decode('utf-8', 'ignore').strip()
            except Exception:
                dec = ''
            if dec.startswith('http'):
                if '.m3u8' in dec:
                    return 'stream', _pipe_for(dec, cur)
                if _is_goat(dec):
                    return 'embed', dec
                if _is_playlist(dec, cur):
                    return 'stream', _pipe_for(dec, cur)
                cur, ref = dec, cur
                continue
        # plain playlist address in the page
        for pat in (r'const\s+streamUrls\s*=\s*(\[.*?\]);', r'const\s+streamUrl\s*=\s*"([^"]*)"', r'var\s+streamUrl\s*=\s*"([^"]+)"',
                    r'(?:const|var|let)\s+source\s*=\s*["\']([^"\']+)', r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)'):
            mm = re.search(pat, page)
            if not mm:
                continue
            val = mm.group(1)
            if val.startswith('['):
                import json as _json
                try:
                    urls = [u for u in _json.loads(val) if u]
                except Exception:
                    urls = []
                val = urls[0] if urls else ''
            val = val.replace('\\/', '/')
            if val.startswith('http'):
                return 'stream', _pipe_for(val, cur)
        # streams-center style: an encrypted token the site decrypts for us
        mm = re.search(r'input:\s*"([^"]+)"', page)
        if mm:
            p = urlparse(cur)
            try:
                resp = requests.post('%s://%s/embed/decrypt.php' % (p.scheme, p.netloc), data={'input': mm.group(1)}, timeout=_TIMEOUT,
                                     headers={'User-Agent': UA, 'Referer': cur}).text.strip()
            except Exception:
                resp = ''
            if resp.startswith('http'):
                if '.m3u8' in resp:
                    return 'stream', _pipe_for(resp, cur)
                cur, ref = resp, cur
                continue
        nxt = _iframe_of(cur, page, ref)
        if not nxt:
            return None
        nxt = _html.unescape(nxt).strip()
        if nxt.startswith('https:///'):
            nxt = 'https://' + urlparse(cur).netloc + '/' + nxt[len('https:///'):]
        elif nxt.startswith('//'):
            nxt = 'https:' + nxt
        nxt = urljoin(cur, nxt)
        if _is_goat(nxt):
            return 'embed', nxt
        cur, ref = nxt, cur
    return None
