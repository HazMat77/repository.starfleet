# -*- coding: utf-8 -*-
"""The page of one sports event, whatever the sport: what an event's screen shows before anything is played.

page(sport, title, start_ts) ->
  {'kind': 'game' | 'fight' | 'plain', 'title', 'league', 'start_ts', 'state': 'pre' | 'in' | 'post', 'status', 'venue', 'photo',
   'starts': [{'name', 'ts'}],                                   when each part of the event begins (UTC epoch seconds)
   'teams': [{'name', 'logo', 'record', 'split', 'score', 'home'}],       a game: both teams with their win-loss record and the score
   'segments': [{'name', 'ts', 'fights': [{'weight', 'title_bout', 'rounds', 'result', 'a', 'b'}]}]}      a fight night: the card
A game: ESPN's scoreboard (records, logos, live score and clock). UFC: ufc.com's card (see ufc_events) with ESPN's records.
PFL / Bellator: ESPN's card. Boxing / BKFC: the fighters named in the title, with a photo when TheSportsDB knows them.
The page is None when nothing could be said about the event (the caller then falls back to looking for streams)."""
import calendar
import re
import time

import xbmc

from starfleetscrapers.core import http as requests
from starfleetscrapers.sports import live_scores as ls
from starfleetscrapers.sports import ufc_events as ufc

_UA = ufc._UA
_API = 'https://site.api.espn.com/apis/site/v2/sports/%s/%s/scoreboard?dates=%s&limit=100'
_TTL = 20
_mem = {}

_TEAM = {
    'nfl': ('football', 'nfl', 'NFL'), 'nba': ('basketball', 'nba', 'NBA'), 'mlb': ('baseball', 'mlb', 'MLB'),
    'nhl': ('hockey', 'nhl', 'NHL'), 'cfb': ('football', 'college-football', 'College Football'),
    'ncaab': ('basketball', 'mens-college-basketball', 'College Basketball'), 'cfl': ('football', 'cfl', 'CFL'),
    'wnba': ('basketball', 'wnba', 'WNBA'), 'ncaaw': ('basketball', 'womens-college-basketball', "Women's College Basketball"),
    'ncaah': ('hockey', 'mens-college-hockey', 'College Hockey'), 'soccer': ('soccer', 'all', 'Soccer'),
}
_MMA = {'pfl': [('mma', 'pfl', 'PFL'), ('mma', 'bellator', 'Bellator')], 'mma': [('mma', 'ufc', 'UFC'), ('mma', 'pfl', 'PFL'), ('mma', 'bellator', 'Bellator')]}
COMBAT = ('ufc', 'mma', 'pfl', 'boxing', 'bkfc')


def _log(msg):
    xbmc.log('[Starfleet/EventPage] %s' % msg, xbmc.LOGINFO)


def _day_board(sport, league, day):
    key = '%s/%s/%s' % (sport, league, day)
    hit = _mem.get(key)
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    try:
        r = requests.get(_API % (sport, league, day), headers={'User-Agent': _UA}, timeout=10)
        r.raise_for_status()
        evs = r.json().get('events', [])
    except Exception as e:
        _log('%s: %s' % (key, str(e)[:80]))
        return hit[1] if hit else []
    _mem[key] = (time.time(), evs)
    return evs


def _board(sport, league, start_ts, spread=1):
    """ESPN's scoreboard events for the event's day and the days around it (cached 20 seconds). Single days: the team leagues refuse a range."""
    day = lambda t: time.strftime('%Y%m%d', time.gmtime(t))
    base = start_ts or time.time()
    out, seen = [], set()
    for k in range(-spread, spread + 1):
        for ev in _day_board(sport, league, day(base + k * 86400)):
            if ev.get('id') not in seen:
                seen.add(ev.get('id'))
                out.append(ev)
    return out


def _iso(s):
    m = re.match(r'(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d)', s or '')
    return calendar.timegm((int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4)), int(m.group(5)), 0)) if m else 0


def _state(ev):
    return ((ev.get('status') or {}).get('type') or {}).get('state', 'pre')


def _record(c, kind):
    for r in c.get('records') or []:
        if r.get('type') == kind or (kind == 'total' and r.get('name') == 'overall'):
            return r.get('summary', '')
    return ''


_photo_mem = {}


def _venue_photo(league, vid, name):
    """A picture of the arena / stadium / field: ESPN's own (where it has one), else the venue's Wikipedia picture ('' when neither)."""
    key = '%s|%s|%s' % (league, vid, name)
    hit = _photo_mem.get(key)
    if hit is not None and time.time() - hit[0] < 24 * 3600:
        return hit[1]
    url = ''
    try:
        if vid:
            cand = 'https://a.espncdn.com/i/venues/%s/day/%s.jpg' % (league.split('.')[0], vid)
            if requests.head(cand, headers={'User-Agent': _UA}, timeout=6, allow_redirects=True).status_code == 200:
                url = cand
    except Exception:
        pass
    if not url and name:
        try:
            from urllib.parse import quote
            r = requests.get('https://en.wikipedia.org/api/rest_v1/page/summary/' + quote(name.replace(' ', '_')), headers={'User-Agent': _UA}, timeout=8)
            d = r.json()
            if d.get('type') == 'standard':
                url = (d.get('thumbnail') or {}).get('source', '')
                url = re.sub(r'/\d+px-', '/1280px-', url)
        except Exception as e:
            _log('venue photo %s: %s' % (name, str(e)[:60]))
    _photo_mem[key] = (time.time(), url)
    return url


def _leaders(c):
    """A team's best players as the scoreboard lists them: up to three, each with a head shot and a stat line."""
    out, seen = [], set()
    for cat in c.get('leaders') or []:
        for lead in (cat.get('leaders') or [])[:1]:
            a = lead.get('athlete') or {}
            nm = a.get('displayName') or a.get('fullName')
            if not nm or nm in seen:
                continue
            seen.add(nm)
            shot = a.get('headshot')
            if isinstance(shot, dict):
                shot = shot.get('href', '')
            out.append({'name': nm, 'photo': shot or '', 'pos': (a.get('position') or {}).get('abbreviation', ''),
                        'stat': ('%s %s' % (lead.get('displayValue', ''), '' if len(lead.get('displayValue', '')) > 10 else cat.get('abbreviation', ''))).strip()})
        if len(out) >= 3:
            break
    return out


def _json(url, ttl=24 * 3600):
    hit = _photo_mem.get(url)
    if hit is not None and time.time() - hit[0] < ttl:
        return hit[1]
    try:
        r = requests.get(url, headers={'User-Agent': _UA}, timeout=10)
        r.raise_for_status()
        val = r.json()
    except Exception as e:
        _log('%s: %s' % (url[-60:], str(e)[:60]))
        return hit[1] if hit else {}
    _photo_mem[url] = (time.time(), val)
    return val


def _home_arena(sport, league, team_id):
    """The home team's own arena / stadium / field: (picture url, venue name)."""
    if not team_id or league == 'all':
        return '', ''
    v = ((_json('https://site.api.espn.com/apis/site/v2/sports/%s/%s/teams/%s' % (sport, league, team_id)).get('team') or {}).get('franchise') or {}).get('venue') or {}
    imgs = v.get('images') or []
    return (imgs[0].get('href', '') if imgs else ''), v.get('fullName', '')


def _summary_leaders(sport, league, event_id):
    """team id -> leaders, from the game summary (the scoreboard has none for some leagues)."""
    d = _json('https://site.api.espn.com/apis/site/v2/sports/%s/%s/summary?event=%s' % (sport, league, event_id), ttl=600)
    return {str((x.get('team') or {}).get('id')): _leaders(x) for x in (d.get('leaders') or [])}



_CORE = 'https://sports.core.api.espn.com/v2/sports/%s/leagues/%s/seasons/%s/types/%s/teams/%s/leaders'
_PICK = ('points', 'goals', 'assists', 'passingYards', 'rushingYards', 'receivingYards', 'avg', 'homeRuns', 'rebounds', 'pointsPerGame')


def _core_leaders(sport, league, season, stype, team_id):
    """A team's season leaders from ESPN's core feed (the scoreboard has none for the NHL): up to three players, with head shot."""
    if not (season and team_id):
        return []
    d = _json(_CORE % (sport, league, season, stype or 2, team_id))
    out, seen = [], set()
    cats = sorted(d.get('categories') or [], key=lambda c: _PICK.index(c['name']) if c.get('name') in _PICK else 99)
    for cat in cats:
        for lead in (cat.get('leaders') or [])[:1]:
            m = re.search(r'/athletes/(\d+)', (lead.get('athlete') or {}).get('$ref', ''))
            if not m or m.group(1) in seen:
                continue
            seen.add(m.group(1))
            a = _json(lead['athlete']['$ref'].replace('http://', 'https://'))
            nm = a.get('displayName') or a.get('fullName')
            if not nm:
                continue
            shot = (a.get('headshot') or {}).get('href', '') or 'https://a.espncdn.com/i/headshots/%s/players/full/%s.png' % (league, m.group(1))
            val = lead.get('displayValue', '')
            out.append({'name': nm, 'photo': shot, 'pos': (a.get('position') or {}).get('abbreviation', ''),
                        'stat': ('%s %s' % (val, cat.get('abbreviation', ''))).strip()})
        if len(out) >= 3:
            break
    return out



def _plain_game(slug, title, start_ts):
    """The scoreboard has nothing for this game (a league it does not carry, a game too far ahead): the teams are still named by the title."""
    t = title.split(' : ')[-1]
    parts = re.split(r'\s+(?:vs\.?|@|at|v)\s+', t, maxsplit=1, flags=re.I)
    if len(parts) < 2:
        parts = re.split(r'\s+-\s+', t, maxsplit=1)
    if len(parts) < 2:
        return None
    teams = [{'name': n.strip(), 'logo': '', 'record': '', 'split': '', 'score': '', 'home': i == 1, 'leaders': []} for i, n in enumerate(parts)]
    return {'kind': 'game', 'title': title, 'league': _TEAM[slug][2], 'start_ts': start_ts, 'state': _state_of(start_ts, 4 * 3600), 'status': '',
            'venue': '', 'photo': '', 'broadcast': '', 'starts': [{'name': 'Start', 'ts': start_ts}] if start_ts else [], 'teams': teams, 'segments': []}



def _game(slug, title, start_ts):
    sport, league, label = _TEAM[slug]
    t = title.split(' : ')[-1]
    toks = set(ls._tokens(t))
    best = None
    for ev in _board(sport, league, start_ts):
        comp = (ev.get('competitions') or [{}])[0]
        cs = comp.get('competitors') or []
        home = next((c for c in cs if c.get('homeAway') == 'home'), None)
        away = next((c for c in cs if c.get('homeAway') == 'away'), None)
        if not home or not away:
            continue
        ha, aa = ls._distinct(ls._tokens(home['team'].get('displayName', '')), ls._tokens(away['team'].get('displayName', '')))
        if not (ha & toks and aa & toks):
            continue
        ts = _iso(ev.get('date', ''))
        if start_ts and ts and abs(start_ts - ts) > 36 * 3600:
            continue
        best = (ev, comp, home, away, ts)
        break
    if not best:
        return _plain_game(slug, title, start_ts)
    ev, comp, home, away, ts = best
    st = (ev.get('status') or {}).get('type') or {}
    state = st.get('state', 'pre')
    venue = comp.get('venue') or {}
    place = ', '.join(x for x in (venue.get('fullName'), (venue.get('address') or {}).get('city')) if x)

    lead = {str(c['team'].get('id')): _leaders(c) for c in (home, away)}
    if not any(lead.values()):
        try:
            lead = _summary_leaders(sport, league, ev.get('id'))
        except Exception as e:
            _log('leaders: %s' % str(e)[:60])
    if not any(lead.values()):
        try:
            season = ev.get('season') or {}
            lead = {str(c['team'].get('id')): _core_leaders(sport, league, season.get('year'), season.get('type'), str(c['team'].get('id'))) for c in (home, away)}
        except Exception as e:
            _log('core leaders: %s' % str(e)[:60])

    def team(c, is_home):
        tm = c['team']
        return {'name': tm.get('displayName', ''), 'logo': tm.get('logo', ''), 'record': _record(c, 'total'),
                'split': ('Home ' + _record(c, 'home')) if is_home and _record(c, 'home') else (('Away ' + _record(c, 'road')) if _record(c, 'road') else ''),
                'score': str(c.get('score', '')) if state != 'pre' else '', 'home': is_home, 'leaders': lead.get(str(tm.get('id')), [])}
    # in the order the event's own title gives the teams (a visitor first for the US leagues)
    a, h = team(away, False), team(home, True)
    first = set(ls._tokens(re.split(r'\s+(?:vs\.?|@|at|v)\s+', t, maxsplit=1)[0]))
    ha, aa = ls._distinct(ls._tokens(h['name']), ls._tokens(a['name']))
    teams = [h, a] if (first & ha and not first & aa) else [a, h]
    status = st.get('shortDetail', '') if state != 'pre' else ''
    arena = _home_arena(sport, league, str(home['team'].get('id'))) [0] or _venue_photo(league if sport != 'soccer' else 'soccer', venue.get('id'), venue.get('fullName', ''))
    caster = ', '.join(sorted({n for b in (comp.get('broadcasts') or []) for n in (b.get('names') or [])}))
    return {'kind': 'game', 'title': title, 'league': label, 'start_ts': ts or start_ts, 'state': state, 'status': status,
            'venue': place, 'photo': arena, 'broadcast': caster, 'starts': [{'name': 'Start', 'ts': ts or start_ts}], 'teams': teams, 'segments': []}


# ── fights ──────────────────────────────────────────────────────────────────────────────────────────────────────────

def _state_of(start_ts, ends_after=5 * 3600):
    now = time.time()
    if start_ts and now < start_ts:
        return 'pre'
    if start_ts and now < start_ts + ends_after:
        return 'in'
    return 'post' if start_ts else 'pre'


_OTHER_ORG = re.compile(r'\b(pfl|bellator|one (?:championship|fc)|one \d+|bkfc|bare knuckle|cage warriors|ksw|oktagon|rizin|lfa|eagle fc|cwfc|invicta|karate combat|boxing|wbc|wba|ibf|wbo|dazn|top rank|matchroom|golden boy|pbc|zuffa boxing)\b', re.I)
_GENERIC = {'ufc', 'fight', 'night', 'fights', 'main', 'card', 'event', 'vs', 'v', 'live', 'full', 'prelims', 'early', 'the', 'and'}


def _ufc_page(title, start_ts):
    """The UFC card this title is. Only a real match counts (the event number, or a fighter in its name): the nearest date alone does not,
    or every other organisation's fight that weekend would show the UFC card."""
    if _OTHER_ORG.search(title) and not re.search(r'\bufc\b', title, re.I):
        return None
    evs = ufc.list_events(24 * 120)
    num = re.search(r'\bufc\s*(\d{3})\b', title, re.I)
    toks = {t for t in ls._tokens(re.sub(r'\d+', ' ', title)) if t not in _GENERIC and len(t) > 2}
    best, score = None, 0
    for e in evs:
        s = 0
        if num and str(e.get('id', '')).endswith('-' + num.group(1)):
            s += 10
        t = {x for x in ls._tokens(re.sub(r'\d+', ' ', e.get('title', ''))) if x not in _GENERIC and len(x) > 2}
        s += len(toks & t) * 2
        if s and start_ts and abs(e['main_ts'] - start_ts) < 36 * 3600:
            s += 1
        if s >= 2 and s > score:
            best, score = e, s
    if not best:
        return None
    c = ufc.card(best['id'])
    if not c:
        return None
    starts = [{'name': n, 'ts': ts} for n, ts in ((s['name'], s['ts'] or c['main_ts']) for s in c['segments']) if ts]
    first = min([s['ts'] for s in starts] or [c['main_ts']])
    return {'kind': 'fight', 'title': c['title'], 'league': 'UFC', 'start_ts': first, 'state': _state_of(first, 8 * 3600),
            'status': '', 'venue': ', '.join(x for x in (c.get('venue'), c.get('city'), c.get('country')) if x),
            'photo': (c.get('photos') or [''])[0], 'starts': starts, 'teams': [], 'segments': c['segments']}


def _mma_page(slug, title, start_ts):
    _skip = _GENERIC | {'pfl', 'bellator', 'champions', 'series', 'championship', 'world', 'tournament', 'playoffs', 'finals', 'season'}
    toks = {t for t in ls._tokens(re.sub(r'\d+', ' ', title)) if t not in _skip and len(t) > 2}
    for sport, league, label in _MMA.get(slug, []):
        for ev in _board(sport, league, start_ts):
            ts = _iso(ev.get('date', ''))
            t = {x for x in ls._tokens(re.sub(r'\d+', ' ', ev.get('name', ''))) if x not in _skip and len(x) > 2}
            if not (toks & t) or (start_ts and ts and abs(start_ts - ts) > 36 * 3600):
                continue
            fights = []
            for comp in ev.get('competitions') or []:
                cs = comp.get('competitors') or []
                if len(cs) < 2:
                    continue

                def fighter(c):
                    ath = c.get('athlete') or {}
                    return {'name': ath.get('displayName') or ath.get('fullName') or '', 'slug': '', 'rank': '', 'record': _record(c, 'total'),
                            'photo': '', 'head': 'https://a.espncdn.com/i/headshots/mma/players/full/%s.png' % c.get('id') if c.get('id') else '',
                            'flag': (ath.get('flag') or {}).get('href', ''), 'country': (ath.get('flag') or {}).get('alt', '')}
                typ = comp.get('type') or {}
                weight = typ.get('text') or typ.get('abbreviation') or ''
                fights.append({'weight': weight, 'title_bout': 'title' in weight.lower(), 'rounds': 5 if 'title' in weight.lower() else 3,
                               'result': '', 'a': fighter(cs[0]), 'b': fighter(cs[1])})
            if not fights:
                continue
            fights.reverse()                                       # ESPN lists the opening bout first; a card reads main event first
            comp0 = (ev.get('competitions') or [{}])[0]
            venue = comp0.get('venue') or {}
            place = ', '.join(x for x in (venue.get('fullName'), (venue.get('address') or {}).get('city')) if x)
            return {'kind': 'fight', 'title': ev.get('name', title), 'league': label, 'start_ts': ts or start_ts,
                    'state': _state(ev) if _state(ev) != 'pre' else _state_of(ts or start_ts, 6 * 3600) if (ts or start_ts) else 'pre',
                    'status': '', 'venue': place, 'photo': '', 'starts': [{'name': 'Main Card', 'ts': ts or start_ts}] if (ts or start_ts) else [],
                    'teams': [], 'segments': [{'name': 'Fight Card', 'ts': ts or start_ts, 'fights': fights}]}
    return None


_cache_p = {}


def _tsdb_photo(name):
    """A fighter's picture from TheSportsDB ('' when it does not know the name)."""
    if name in _cache_p:
        return _cache_p[name]
    url = ''
    try:
        from urllib.parse import quote
        r = requests.get('https://www.thesportsdb.com/api/v1/json/123/searchplayers.php?p=' + quote(name), headers={'User-Agent': _UA}, timeout=8)
        for p in (r.json().get('player') or []):
            if (p.get('strSport') or '').lower() in ('fighting', 'boxing', 'mixed martial arts', 'martial arts'):
                url = p.get('strCutout') or p.get('strThumb') or ''
                if url:
                    break
    except Exception as e:
        _log('photo %s: %s' % (name, str(e)[:60]))
    _cache_p[name] = url
    return url


def _org_of(title):
    m = _OTHER_ORG.search(title)
    return (m.group(1).upper() if m and len(m.group(1)) <= 5 else (m.group(1).title() if m else 'MMA'))


def _boxing_page(slug, title, start_ts):
    """Boxing / BKFC: no card source has the full list, so the headline fight is built from the names in the title."""
    t = re.sub(r'^.*?:\s+', '', title) if re.search(r'\bvs\.?\b', title, re.I) else title
    parts = re.split(r'\s+(?:vs\.?|v)\s+', t, maxsplit=1, flags=re.I)
    if len(parts) < 2:
        return None
    names = [re.sub(r'\s*[\(\[].*$', '', p).strip() for p in parts]
    fighters = [{'name': n, 'slug': '', 'rank': '', 'record': '', 'photo': '', 'head': _tsdb_photo(n), 'flag': '', 'country': ''} for n in names]
    fights = [{'weight': 'Main Event', 'title_bout': False, 'rounds': 12 if slug == 'boxing' else 5, 'result': '', 'a': fighters[0], 'b': fighters[1]}]
    return {'kind': 'fight', 'title': title, 'league': {'boxing': 'Boxing', 'bkfc': 'BKFC'}.get(slug, _org_of(title)), 'start_ts': start_ts, 'state': _state_of(start_ts, 5 * 3600),
            'status': '', 'venue': '', 'photo': '', 'starts': [{'name': 'Main Event', 'ts': start_ts}] if start_ts else [], 'teams': [],
            'segments': [{'name': 'Main Event', 'ts': start_ts, 'fights': fights}]}


def page(sport, title, start_ts=0):
    start_ts = int(start_ts or 0)
    try:
        if sport in _TEAM:
            return _game(sport, title, start_ts)
        if sport == 'ufc':
            return _ufc_page(title, start_ts) or _mma_page('mma', title, start_ts) or _boxing_page('mma', title, start_ts)
        if sport in ('pfl', 'mma'):
            return (_ufc_page(title, start_ts) if sport == 'mma' else None) or _mma_page(sport if sport == 'pfl' else 'mma', title, start_ts) or _boxing_page('mma', title, start_ts)
        if sport in ('boxing', 'bkfc'):
            return _boxing_page(sport, title, start_ts)
    except Exception as e:
        _log('%s %s failed: %s' % (sport, title[:40], str(e)[:100]))
    return None
