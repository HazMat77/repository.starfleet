# -*- coding: utf-8 -*-
"""
live/m3u_lists.py

Public IPTV playlists (the Free-TV curated list and the iptv-org category / country lists) turned into Live TV lists that hold only
channels that really play, with the programme now on air.

The check runs quietly in the background from the add-on's service (service(): a few minutes after Kodi starts and then every few
hours, two connections at a time, paused while anything plays), so the lists are usually ready before Live TV is opened. Opening
Live TV calls boost(): the same pass then runs at full speed (the device's normal number of connections) and also fetches what is
on now / next. The service and the menu are separate processes, so they talk through small flag files in the data folder. The pass
itself, in the background,

  1. downloads each playlist (kept 6 hours),
  2. checks every channel - the stream's playlist has to answer with real HLS (or DASH) data; a verdict is kept 12 hours when the
     channel works and 4 hours when it does not, so a channel is not tested again every time Live TV is opened,
  3. matches the working channels to the free guide packs (epg_live.py) and keeps what is on now / next.

channels(key) returns the working channels found so far (a list that is still being checked simply grows), status() says how far
each list is. Streams of services the add-on already lists (Pluto, Samsung, Plex, Roku...) and adult groups are left out.
"""
import hashlib
import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urljoin

import requests
import xbmc

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
_LIST_TTL = 6 * 3600
_OK_TTL = 12 * 3600
_BAD_TTL = 4 * 3600


def _workers():
    """How many channels are checked at once: few on a Fire TV Stick, many on a PC."""
    try:
        from starfleetscrapers.core import device
        return {'low': 6, 'mid': 12, 'high': 32}.get(device.profile().get('tier'), 8)
    except Exception:
        return 8

_IPTVORG = 'https://iptv-org.github.io/iptv/'
# key -> (title, address)
LISTS = {
    'freetv': ('Free-TV (curated)', 'https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8'),
    'us': ('IPTV-org - USA', _IPTVORG + 'countries/us.m3u'),
    'ca': ('IPTV-org - Canada', _IPTVORG + 'countries/ca.m3u'),
    'news': ('IPTV-org - News', _IPTVORG + 'categories/news.m3u'),
    'sports': ('IPTV-org - Sports', _IPTVORG + 'categories/sports.m3u'),
    'movies': ('IPTV-org - Movies', _IPTVORG + 'categories/movies.m3u'),
    'music': ('IPTV-org - Music', _IPTVORG + 'categories/music.m3u'),
    'kids': ('IPTV-org - Kids', _IPTVORG + 'categories/kids.m3u'),
    'documentary': ('IPTV-org - Documentary', _IPTVORG + 'categories/documentary.m3u'),
}
ORDER = ['freetv', 'us', 'ca', 'news', 'sports', 'movies', 'music', 'kids', 'documentary']

# services the add-on lists on their own, and groups that are not for this list
_DUP_HOSTS = ('pluto.tv', 'samsung', 'plex.tv', 'jmp2.uk', 'tubi', 'roku.com')
_SKIP_GROUP = re.compile(r'xxx|adult|porn|erotic|18\+', re.I)
_COUNTRY_CODE = {'usa': 'US', 'united states': 'US', 'uk': 'GB', 'united kingdom': 'GB', 'canada': 'CA', 'australia': 'AU', 'india': 'IN',
                 'germany': 'DE', 'france': 'FR', 'spain': 'ES', 'italy': 'IT', 'ireland': 'IE', 'south africa': 'ZA', 'nigeria': 'NG'}

_HOME = ('US', 'CA', 'GB')
_RE_ATTR = lambda k: re.compile(k + r'="([^"]*)"')   # noqa: E731
_RE_ID, _RE_LOGO, _RE_GROUP = _RE_ATTR('tvg-id'), _RE_ATTR('tvg-logo'), _RE_ATTR('group-title')
_RE_QUALITY = re.compile(r'\s*[\[(](?:\d{3,4}p|Not 24/7|Geo-blocked)[\])]', re.I)

_lock = threading.Lock()
_progress = {}                # key -> [checked, total]
_running = [False]
_verdicts = None


def _log(msg):
    xbmc.log('[Starfleet/M3U] %s' % msg, xbmc.LOGINFO)


def _dir():
    import xbmcvfs
    d = xbmcvfs.translatePath('special://profile/addon_data/script.module.starfleetscrapers/m3ulists/')
    if not xbmcvfs.exists(d):
        xbmcvfs.mkdirs(d)
    return d


# ── playlists ────────────────────────────────────────────────────────────────

def _download(key):
    """Text of a playlist, cached 6 hours in a file; a stale copy is used when the download fails."""
    path = os.path.join(_dir(), '%s.m3u' % key)
    try:
        if os.path.exists(path) and time.time() - os.path.getmtime(path) < _LIST_TTL:
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                return f.read()
    except Exception:
        pass
    try:
        r = requests.get(LISTS[key][1], headers={'User-Agent': _UA}, timeout=(8, 60))
        if r.status_code == 200 and r.content:
            with open(path + '.part', 'wb') as f:
                f.write(r.content)
            os.replace(path + '.part', path)
            return r.content.decode('utf-8', 'replace')
    except Exception as e:
        _log('%s download: %s' % (key, str(e)[:80]))
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            return f.read()
    except Exception:
        return ''


def parse(text, source=''):
    """[{'id','title','group','thumbnail','stream_url','tvg_id','cc','source'}] from an M3U text (stream headers kept as Kodi pipe)."""
    out, seen = [], set()
    cur = None
    opts = {}
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith('#EXTINF'):
            nm = line.rsplit(',', 1)
            title = _RE_QUALITY.sub('', nm[1]).strip() if len(nm) == 2 else ''
            g = _RE_GROUP.search(line)
            cur = {'title': title, 'group': (g.group(1) if g else '') or 'Other',
                   'thumbnail': (_RE_LOGO.search(line) or [None, ''])[1], 'tvg_id': (_RE_ID.search(line) or [None, ''])[1]}
            opts = {}
        elif line.startswith('#EXTVLCOPT:'):
            k, _, v = line[len('#EXTVLCOPT:'):].partition('=')
            if k == 'http-referrer':
                opts['Referer'] = v
            elif k == 'http-user-agent':
                opts['User-Agent'] = v
        elif cur and line and not line.startswith('#'):
            url = line
            cur_item, cur = cur, None
            if not url.startswith('http'):
                continue
            base = url.split('|', 1)[0]
            if any(h in base for h in _DUP_HOSTS) or _SKIP_GROUP.search(cur_item['group']) or _SKIP_GROUP.search(cur_item['title']):
                continue
            if base in seen or not cur_item['title']:
                continue
            seen.add(base)
            if opts and '|' not in url:
                url = '%s|%s' % (url, '&'.join('%s=%s' % (k, quote(v, safe='')) for k, v in opts.items()))
            tv = cur_item['tvg_id']
            cc = tv.rsplit('.', 1)[1].split('@')[0].upper() if '.' in tv else ''
            if not cc:
                cc = _COUNTRY_CODE.get(cur_item['group'].strip().lower(), '')
            out.append({'id': 'm3u-' + hashlib.md5(base.encode('utf-8')).hexdigest()[:12], 'title': cur_item['title'],
                        'group': cur_item['group'], 'thumbnail': cur_item['thumbnail'], 'stream_url': url,
                        'tvg_id': tv, 'cc': cc, 'source': source})
    return out


# ── channel checks ───────────────────────────────────────────────────────────

def _load_verdicts():
    global _verdicts
    if _verdicts is None:
        try:
            with open(os.path.join(_dir(), 'verdicts.json'), 'r', encoding='utf-8') as f:
                _verdicts = json.load(f)
        except Exception:
            _verdicts = {}
    return _verdicts


def _save_verdicts():
    try:
        v = _load_verdicts()
        now = time.time()
        for k in [k for k, (t, ok) in v.items() if now - t > _OK_TTL]:
            del v[k]
        with open(os.path.join(_dir(), 'verdicts.json.tmp'), 'w', encoding='utf-8') as f:
            json.dump(v, f)
        os.replace(os.path.join(_dir(), 'verdicts.json.tmp'), os.path.join(_dir(), 'verdicts.json'))
    except Exception:
        pass


def _headers(url):
    h = {'User-Agent': _UA}
    if '|' in url:
        for kv in url.split('|', 1)[1].split('&'):
            k, _, v = kv.partition('=')
            if k:
                from urllib.parse import unquote_plus
                h[k] = unquote_plus(v)
    return h


_session = None
_session_lock = threading.Lock()


def _sess():
    """One shared session whose connections all use ONE TLS context. By default every new host builds its own context and reads
    the whole CA bundle again (about 0.3 s of CPU each), which made a check cost ~0.5 s of CPU per channel - far too much for a Fire
    TV Stick. The certificates are still verified."""
    global _session
    if _session is not None:
        return _session
    with _session_lock:                         # built once: forty threads asking at the same moment must not build forty
        if _session is not None:
            return _session
        s = requests.Session()
        try:
            import ssl
            ctx = ssl.create_default_context(cafile=requests.certs.where())

            class _Fast(requests.adapters.HTTPAdapter):
                def init_poolmanager(self, *a, **k):
                    k['ssl_context'] = ctx
                    super().init_poolmanager(*a, **k)

                def cert_verify(self, conn, url, verify, cert):
                    conn.cert_reqs = 'CERT_REQUIRED' if url.lower().startswith('https') else 'CERT_NONE'
                    conn.ca_certs = None            # the shared context already holds them: nothing is read again
                    conn.ca_cert_dir = None

            adapter = _Fast(pool_connections=64, pool_maxsize=64, max_retries=0)
        except Exception:
            adapter = requests.adapters.HTTPAdapter(pool_connections=64, pool_maxsize=64, max_retries=0)
        s.mount('https://', adapter)
        s.mount('http://', requests.adapters.HTTPAdapter(pool_connections=64, pool_maxsize=64, max_retries=0))
        _session = s
    return _session


def _read_head(resp, want=700, budget=7.0):
    """The first `want` bytes of a response, but never waiting longer than `budget` seconds in all: a stream that trickles a few
    bytes at a time would otherwise keep a worker (and, with two workers, the whole quiet pass) busy for minutes."""
    out = b''
    end = time.time() + budget
    for chunk in resp.iter_content(chunk_size=None):         # whatever has arrived: a fixed size would wait for a slow stream to fill it
        out += chunk
        if len(out) >= want or time.time() > end:
            break
    return out


def probe(url):
    """True when the stream answers with real HLS / DASH / media data."""
    base = url.split('|', 1)[0]
    h = _headers(url)
    try:
        r = _sess().get(base, headers=h, timeout=(3, 5), stream=True)
        try:
            if r.status_code >= 400:
                return False
            head = _read_head(r)
            ct = (r.headers.get('content-type') or '').lower()
            final = r.url
        finally:
            r.close()
        if head[:7] == b'#EXTM3U':
            txt = head.decode('utf-8', 'ignore')
            if 'EXT-X-STREAM-INF' in txt:                       # a master playlist: its first variant has to answer too
                lines = [l for l in txt.splitlines() if l and not l.startswith('#')]
                if lines:
                    v = _sess().get(urljoin(final, lines[0]), headers=h, timeout=(3, 5), stream=True)
                    try:
                        return v.status_code < 400 and _read_head(v, 16)[:7] == b'#EXTM3U'
                    finally:
                        v.close()
            return True
        if b'<MPD' in head[:600]:
            return True
        if head and (ct.startswith(('video/', 'audio/')) or 'mpegurl' in ct or head[:1] == b'G'):
            return True
        return False
    except Exception:
        return False


# ── how fast the pass runs: quiet (2 checks at a time) or, once Live TV was opened, the device's normal speed ──────────────────────
_QUIET_WORKERS = 2
_BOOST_SECS = 20 * 60
_gate = threading.Condition()
_active = [0]
_allowed_cache = [0.0, _QUIET_WORKERS]


def _flag(name):
    return os.path.join(_dir(), name)


def _touch(name):
    try:
        with open(_flag(name), 'w') as f:
            f.write(str(time.time()))
    except Exception:
        pass


def _age(name):
    try:
        return time.time() - os.path.getmtime(_flag(name))
    except OSError:
        return 1e9


def _allowed():
    """How many channels may be checked at this moment (re-read at most every 2 seconds: the flag is written by another process)."""
    now = time.time()
    if now - _allowed_cache[0] > 2:
        _allowed_cache[0] = now
        _allowed_cache[1] = _workers() if _age('_boost') < _BOOST_SECS else _QUIET_WORKERS
    return _allowed_cache[1]


def _acquire():
    with _gate:
        while _active[0] >= _allowed():
            _gate.wait(1.0)
        _active[0] += 1


def _release():
    with _gate:
        _active[0] -= 1
        _gate.notify_all()


def _paused():
    """True while a video is playing: the check waits so it never competes with playback (or Kodi shutting down)."""
    try:
        return xbmc.Player().isPlaying()
    except Exception:
        return False


def _check(item):
    waited = 0
    while _paused() and waited < 3600:
        time.sleep(3)
        waited += 3
    key = item['stream_url']
    v = _load_verdicts()
    h = hashlib.md5(key.encode('utf-8')).hexdigest()[:16]
    hit = v.get(h)
    now = time.time()
    if hit and now - hit[0] < (_OK_TTL if hit[1] else _BAD_TTL):
        return hit[1]
    _acquire()
    try:
        ok = probe(key)
    finally:
        _release()
    v[h] = [now, ok]
    return ok


def _known(item):
    hit = _load_verdicts().get(hashlib.md5(item['stream_url'].encode('utf-8')).hexdigest()[:16])
    return hit is not None and time.time() - hit[0] < (_OK_TTL if hit[1] else _BAD_TTL), bool(hit and hit[1])


_parsed = {}


def _items(key):
    hit = _parsed.get(key)
    if hit and time.time() - hit[0] < _LIST_TTL:
        return hit[1]
    items = parse(_download(key), LISTS[key][0])
    if items:
        _parsed[key] = (time.time(), items)
    return items


def channels(key):
    """The working channels of a list found so far (a list that has never been checked is empty until its first channels pass)."""
    items = _items(key)
    out = []
    now = _now_next()
    for it in items:
        fresh, ok = _known(it)
        if fresh and ok:
            n = now.get(it['id'])
            if n:
                it = dict(it, plot=n)
            out.append(it)
    return out


def status():
    """{key: (checked, total)} for the lists being checked now."""
    with _lock:
        return {k: tuple(v) for k, v in _progress.items()}


def running():
    return _running[0]


def _verify_list(key):
    items = _items(key)
    todo = [it for it in items if not _known(it)[0]]
    todo.sort(key=lambda it: 0 if it.get('cc') in _HOME else 1)     # the viewer's own countries first: they fill in first
    with _lock:
        _progress[key] = [len(items) - len(todo), len(items)]
    if not todo:
        return
    from concurrent.futures import as_completed
    pool = ThreadPoolExecutor(max_workers=_workers())
    try:
        # counted as each channel finishes (not in list order: one slow channel must not hide the progress of the others)
        for n, _f in enumerate(as_completed([pool.submit(_check, it) for it in todo]), 1):
            with _lock:
                _progress[key][0] += 1
            if n % 200 == 0:
                _save_verdicts()
    finally:
        pool.shutdown(wait=False)
    _save_verdicts()


# ── what is on now ───────────────────────────────────────────────────────────

_NOW_FILE = 'nownext.json'


def _now_next():
    """{channel id: 'Now: ...  |  Next: ...'} from the last guide pass (kept up to 3 hours)."""
    try:
        with open(os.path.join(_dir(), _NOW_FILE), 'r', encoding='utf-8') as f:
            d = json.load(f)
        if time.time() - d.get('t', 0) < 3 * 3600:
            return d.get('items') or {}
    except Exception:
        pass
    return {}


def _guide_pass():
    """Match the working channels to the free guide packs and keep the programmes airing now and next."""
    try:
        from starfleetscrapers.live import epg_live
        import xml.etree.ElementTree as ET
        chans = []
        for k in ORDER:
            for it in channels(k):
                if it.get('cc'):
                    chans.append((it['id'], it['title'], it['cc']))
        seen = {}
        for c in chans:
            seen.setdefault(c[0], c)
        chans = list(seen.values())
        if not chans:
            return
        matched, xml_bytes, _stats = epg_live.build(chans)
        if not matched or not xml_bytes:
            return
        root = ET.fromstring(xml_bytes)
        now = time.time()
        progs = {}
        for p in root.iter('programme'):
            progs.setdefault(p.get('channel'), []).append(
                (epg_live._xmltv_ts(p.get('start', '')), epg_live._xmltv_ts(p.get('stop', '')), (p.findtext('title') or '').strip()))
        items = {}
        for cid, epg_id in matched.items():
            rows = sorted(progs.get(epg_id, []))
            cur = next((r for r in rows if r[0] <= now < r[1]), None)
            nxt = next((r for r in rows if r[0] >= (cur[1] if cur else now)), None)
            bits = []
            if cur:
                bits.append('Now: %s' % cur[2])
            if nxt:
                bits.append('Next: %s' % nxt[2])
            if bits:
                items[cid] = '  |  '.join(bits)
        with open(os.path.join(_dir(), _NOW_FILE), 'w', encoding='utf-8') as f:
            json.dump({'t': time.time(), 'items': items}, f)
        _log('guide: %d of %d channels have a programme now' % (len(items), len(chans)))
    except Exception as e:
        _log('guide pass: %s' % str(e)[:100])


def _run():
    try:
        t0 = time.time()
        for k in ORDER:
            _verify_list(k)
        if _age('_boost') < _BOOST_SECS + (time.time() - t0):     # the guide (a heavy download and scan) only once Live TV was opened
            _guide_pass()
        _log('all lists checked in %.0fs' % (time.time() - t0))
    except Exception as e:
        _log('check failed: %s' % str(e)[:100])
    finally:
        _running[0] = False


def start(min_gap=1800):
    """Begin downloading and checking in this process (a thread). Does nothing when a pass is running or one ended less than
    `min_gap` seconds ago. Returns True when a pass was started."""
    with _lock:
        if _running[0]:
            return False
        if _age('_last_pass') < min_gap:
            return False
        _running[0] = True
        _touch('_last_pass')
    threading.Thread(target=_run, daemon=True).start()
    return True


def _service_alive():
    return _age('_alive') < 30


def boost():
    """Called when Live TV is opened: speed the background pass up to the device's normal speed, start one if none is under way, and
    make sure the guide is fetched. The add-on's service does the work when it is running (this call only leaves it a note: the
    menu and the service are different processes); without a service the pass runs here."""
    _touch('_boost')
    if _service_alive():
        _touch('_request')
        return
    start(min_gap=1800)
    if _age(_NOW_FILE) > 3 * 3600 and not _running[0]:
        threading.Thread(target=_guide_pass, daemon=True).start()


def service(monitor, quiet=True):
    """Body of the add-on service's thread: a quiet pass a few minutes after Kodi starts (and again every 5 hours), plus the work
    that boost() asks for when Live TV is opened."""
    if monitor.waitForAbort(150):
        return
    handled = 0.0
    last_guide = 0.0
    while not monitor.abortRequested():
        _touch('_alive')
        req = os.path.getmtime(_flag('_request')) if os.path.exists(_flag('_request')) else 0.0
        if req > handled:
            handled = req
            start(min_gap=1800)                              # Live TV was opened: a pass now (fast, the boost flag is set)
        elif quiet and not _running[0]:
            start(min_gap=5 * 3600)
        if (_age('_boost') < _BOOST_SECS and not _running[0] and _age(_NOW_FILE) > 3 * 3600
                and time.time() - last_guide > 1800):
            last_guide = time.time()
            threading.Thread(target=_guide_pass, daemon=True).start()
        if monitor.waitForAbort(4):
            break
