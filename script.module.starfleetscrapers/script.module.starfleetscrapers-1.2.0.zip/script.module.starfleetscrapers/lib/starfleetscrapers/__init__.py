# -*- coding: utf-8 -*-
"""Starfleet Scrapers - the scraping half of Starfleet, usable on its own and by other add-ons.

    starfleetscrapers.adult      adult site / tube / studio scrapers
    starfleetscrapers.movies     movie and TV hoster scrapers, free streaming services, personal sources
    starfleetscrapers.debrid     torrent / usenet / Easynews search for debrid services
    starfleetscrapers.sports     sports events, live and replay sources
    starfleetscrapers.live       live TV channel lists, guide matching
    starfleetscrapers.radio      internet radio directory
    starfleetscrapers.core       the small helpers they share (cache, request guard, title cleaning, ...)
    starfleetscrapers.host       how the scrapers reach the add-on that uses them (settings, data folder, optional extras)
    starfleetscrapers.hooks      plug-in points for a host's debrid layer and site list
    starfleetscrapers.providers  the torrent sources in the layout other add-ons walk (see sources() below)
    starfleetscrapers.compat     adapters to and from other scraper modules

Another add-on can pick this module as its scraper module: it imports the package and calls
    sources(specified_folders=['torrents'])   ->  [(provider name, source class), ...]
then runs  source().sources(data, hostDict)  for each, exactly as for any other scraper module of that kind.
"""
import os
import pkgutil

__version__ = '1.2.0'
sourceFolder = 'providers'
_MODULE_ID = 'script.module.starfleetscrapers'


def _setting(key):
    try:
        import xbmcaddon
        return xbmcaddon.Addon(_MODULE_ID).getSetting(key)
    except Exception:
        return ''


def enabledCheck(module_name):
    """On when its switch is on; before the switch has ever been set, only the fast core set is on."""
    value = _setting('provider.' + module_name)
    if value in ('true', 'false'):
        return value == 'true'
    from starfleetscrapers.compat import layout
    return module_name in [layout.file_name(k) for k in layout.CORE]


def sources(specified_folders=None, ret_all=False):
    """Same call as the other common-layout scraper modules: [(provider name, source class), ...]."""
    import importlib
    found = []
    base = os.path.join(os.path.dirname(__file__), sourceFolder)
    try:
        folders = specified_folders or [d for d in os.listdir(base) if os.path.isdir(os.path.join(base, d)) and not d.startswith('__')]
    except OSError:
        return found
    for folder in folders:
        for _importer, name, is_pkg in pkgutil.iter_modules([os.path.join(base, folder)]):
            if is_pkg or not (ret_all or enabledCheck(name)):
                continue
            try:
                mod = importlib.import_module('starfleetscrapers.%s.%s.%s' % (sourceFolder, folder, name))
                found.append((name, mod.source))
            except Exception:
                continue
    return found
