# -*- coding: utf-8 -*-
"""Category browsing for the Adult > Scenes tube sites.

Each site is a small table row:
    index  page(s) listing the categories
    rx     regex over that HTML; named groups href, name (raw html, tags stripped later),
           optional thumb / count
    url    (category_url, page) -> listing URL
    parse  html -> films, one of the site's own listing parsers in adult_streams or one of
           the card parsers below (built on that site's own card regex)
    get    optional fetch function name in adult_streams (default _get)
    limit  keep only the N biggest categories (tag clouds)

The Scenes menus (native list and Starfleet skin) offer a site's categories when it has a
row here, then that category's videos, using the same film dicts, source check and play
path as the site's Latest list.
"""
import html as _html
import json
import re

import xbmc

from starfleetscrapers.adult import streams as _as
from starfleetscrapers.core import cache as _cache

_RE_TAGS = re.compile(r'<[^>]+>')
_RE_COUNT_TAIL = re.compile(
    r'^(?P<n>.*?)<(?P<t>span|small|em|b|strong|i)[^>]*>\s*\(?\s*(?P<c>[\d.,]+\s*[KkMm]?)\s*(?:videos?)?\s*\)?\s*</(?P=t)>\s*$',
    re.DOTALL | re.IGNORECASE)


def _abs(base, href):
    href = _html.unescape(href).strip()
    if href.startswith('//'):
        return 'https:' + href
    if href.startswith('/'):
        return base + href
    return href


def _clean(txt):
    return re.sub(r'\s+', ' ', _html.unescape(_RE_TAGS.sub(' ', txt or ''))).strip()


def _num(txt):
    """'22.3K' / '5.507' / '285,092' -> int (best effort)."""
    m = re.search(r'([\d.,]+)\s*([KkMm]?)', txt or '')
    if not m:
        return 0
    s, suf = m.group(1), m.group(2).lower()
    try:
        if suf:
            return int(float(s.replace(',', '')) * (1000 if suf == 'k' else 1000000))
        return int(re.sub(r'[.,]', '', s))
    except ValueError:
        return 0


def _paged(fmt_first, fmt_next):
    """url builder: first page -> fmt_first, later pages -> fmt_next.
    {u} = category URL as listed, {us} = same without trailing slash, {p} = page, {p0} = page-1."""
    return lambda u, p: (fmt_first if p <= 1 else fmt_next).format(u=u, us=u.rstrip('/'), p=p, p0=p - 1)


def _anchor(path_rx):
    return r'<a[^>]+href="(?P<href>%s)"[^>]*>(?P<name>.*?)</a>' % path_rx


# ── card parsers for sites whose own Latest function parses inline ──────────

def _film(slug, url, title, thumb, source):
    return {'slug': slug, 'url': url, 'title': _as._clean_title(title), 'title_norm': _as._norm_title(title),
            'thumb': thumb or '', 'source': source, 'streams': []}


def _cards_slugtitle(rx_name, source, url_g=1, slug_g=2, title_g=3, base=''):
    """card regex gives (url, id/slug, url-slug); title is rebuilt from the url slug."""
    def parse(html):
        rx, films, seen = getattr(_as, rx_name), [], set()
        for m in rx.finditer(html):
            slug = m.group(slug_g)
            if slug in seen:
                continue
            seen.add(slug)
            title = m.group(title_g).replace('-', ' ').title() if title_g else slug.replace('-', ' ').title()
            films.append(_film(slug, _abs(base, m.group(url_g)), title, '', source))
        return films
    return parse


def _parse_gf13(source, base):
    def parse(html):
        films, seen = [], set()
        for m in _as._RE_GF13_CARD.finditer(html):
            slug = m.group(2)
            if slug in seen:
                continue
            seen.add(slug)
            films.append(_film(slug, base + m.group(1), _html.unescape(m.group(3)), '', source))
        return films
    return parse


def _parse_porn00(html):
    films, seen = [], set()
    for m in _as._RE_P00_CARD.finditer(html):
        slug = m.group(2)
        if slug in seen:
            continue
        seen.add(slug)
        films.append(_film(slug, m.group(1), slug.replace('-', ' ').title(), '', 'porn00'))
    return films


_RE_APS_CARD = re.compile(
    r'data-href="(?P<p>/post/[^"]+)"[^>]*?data-title="(?P<t>[^"]+)"(?:[^>]*?data-images="\[&quot;(?P<th>[^&]+)&quot;)?')


def _parse_aps(html):
    films, seen = [], set()
    for m in _RE_APS_CARD.finditer(html):
        title, path, thumb = _html.unescape(m.group('t')), m.group('p'), m.group('th') or ''
        slug = path.split('/')[-1]
        if slug in seen:
            continue
        seen.add(slug)
        films.append(_film(slug, _as.APS_BASE + path, title, thumb, 'allpornstream'))
    return films


def _parse_redtube(html):
    """RedTube category pages use a different card layout from its homepage."""
    films, seen = [], set()
    for chunk in html.split('<li id="browse_')[1:]:
        vid = re.match(r'(\d+)', chunk)
        if not vid or vid.group(1) in seen:
            continue
        seen.add(vid.group(1))
        t = re.search(r'title="([^"]{3,200})"', chunk)
        th = re.search(r'data-src="([^"]+)"', chunk)
        title = _html.unescape(t.group(1)) if t else 'RedTube %s' % vid.group(1)
        films.append(_film(vid.group(1), _as.REDTUBE_BASE + '/' + vid.group(1), title,
                           _html.unescape(th.group(1)) if th else '', 'redtube'))
    return films


def _parse_xmfy(html):
    films, seen = [], set()
    for m in _as._RE_XMFY_CARD.finditer(html):
        slug, thumb, title = m.group(1).strip('/'), m.group(2), _html.unescape(m.group(3))
        if slug in seen:
            continue
        seen.add(slug)
        films.append(_film(slug, _as.XMFY_BASE + '/' + slug, title, thumb, 'xmoviesforyou'))
    return films


def _parse_pnone(html):
    films, seen = [], set()
    for m in _as._RE_PNONE_CARD.finditer(html):
        film_url, slug, vid = m.group(1), m.group(2), m.group(3)
        key = slug + '-' + vid
        if key in seen:
            continue
        seen.add(key)
        window = html[m.end():m.end() + 900]
        tm = _as._RE_PNONE_TITLE.search(window)
        title = _html.unescape(tm.group(1).strip()) if tm else slug.replace('-', ' ').title()
        films.append(_film(key, film_url, title, '', 'pornone'))
    return films


SITES = {
    # ── sites with their own listing parser ──────────────────────────────────
    'xvideos': dict(
        base='https://www.xvideos.com', index=['https://www.xvideos.com/'],
        rx=r'<li class="dyntop-cat[^"]*"><a href="(?P<href>/c/[^"]+)">(?P<name>[^<]+)</a>',
        url=_paged('{u}', '{us}/{p0}'), parse=lambda h: _as._xvideos_parse_listing(h)),
    'xnxx': dict(
        base='https://www.xnxx.com', index=['https://www.xnxx.com/tags'], limit=250,
        rx=r'<li><a href="(?P<href>/search/[^"]+)">(?P<name>[^<]+)</a><strong>(?P<count>[^<]+)</strong>',
        url=_paged('{u}', '{u}/{p0}'), parse=lambda h: _as._xnxx_parse_listing(h)),
    'pornhub': dict(
        base='https://www.pornhub.com', index=['https://www.pornhub.com/categories'], get='_pornhub_get',
        rx=r'<a href="(?P<href>/video\?c=\d+)" alt="(?P<name>[^"]+)"',
        url=_paged('{u}', '{u}&page={p}'), parse=lambda h: _as._pornhub_parse_listing(h)),
    'youporn': dict(
        base='https://www.youporn.com', index=['https://www.youporn.com/categories/'],
        rx=_anchor(r'/category/[a-z0-9-]+/'), strip=r'\s+Category$',
        url=_paged('{u}', '{u}?page={p}'), parse=lambda h: _as._youporn_parse_listing(h)),
    'xhamster': dict(
        base='https://xhamster.com', index=['https://xhamster.com/categories'], limit=120,
        rx=_anchor(r'https://xhamster\.com/categories/[a-z0-9-]+'),
        url=_paged('{u}', '{us}/{p}'), parse=lambda h: _as._xhamster_parse_listing(h)),
    'thumbzilla': dict(
        base='https://www.thumbzilla.com', index=['https://www.thumbzilla.com/categories/'],
        rx=_anchor(r'/category/[a-z0-9-]+/'),
        url=_paged('{u}', '{u}?page={p}'), parse=lambda h: _as._thumbzilla_parse_listing(h)),
    'porntrex': dict(
        base='https://www.porntrex.com', index=['https://www.porntrex.com/categories/'],
        strip=r'^Find\s+',
        rx=r'<a(?=[^>]*href="(?P<href>https://www\.porntrex\.com/categories/[a-z0-9-]+/)")(?=[^>]*title="(?P<name>[^"]+)")[^>]*>',
        url=_paged('{u}', '{u}?mode=async&function=get_block&block_id=list_videos_common_videos_list_norm&sort_by=post_date&from={p}'),
        parse=lambda h: _as._porntrex_parse_listing(h)),
    'letmejizz': dict(
        base='https://www.letmejizz.co', index=['https://www.letmejizz.co/categories/'], limit=250,
        rx=r'<a href="(?P<href>/tag/[a-z0-9-]+/)">(?P<name>[^<]+)<span class="count">(?P<count>[^<]+)</span>',
        url=_paged('{u}', '{u}?p={p}'), parse=lambda h: _as._letmejizz_parse_listing(h)),
    'eporner': dict(
        base='https://www.eporner.com', index=['https://www.eporner.com/cats/'],
        rx=r'<a[^>]+href="(?P<href>/cat/[a-z0-9-]+/)"[^>]*>(?P<name>.*?)</a>',
        url=_paged('{u}', '{u}{p}/'), parse=lambda h: _as._eporner_parse_listing(h)),
    'tnaflix': dict(
        base='https://www.tnaflix.com', index=['https://www.tnaflix.com/categories/'],
        rx=r'<a href="(?P<href>https://www\.tnaflix\.com/[a-z0-9-]+-porn)">\s*(?P<name>[^<]+?)\s*<span>(?P<count>[^<]+)</span>',
        url=_paged('{u}', '{u}/{p}'), parse=lambda h: _as._tnaflix_parse_listing(h)),
    '6xtube': dict(
        base='https://www.6xtube.com', index=['https://www.6xtube.com/channels/'],
        rx=r'<a href="(?P<href>https://www\.6xtube\.com/channels/\d+/[a-z0-9-]+/)" title="(?P<name>[^"]*)">\s*'
           r'<div class="thumb-overlay">\s*<img[^>]*src="(?P<thumb>[^"]+)"',
        url=_paged('{u}', '{u}page{p}.html'), parse=lambda h: _as._6xtube_parse_listing(h)),
    'xerotica': dict(
        base='https://www.xerotica.com', index=['https://www.xerotica.com/categories/'],
        rx=r'<a href="(?P<href>https://www\.xerotica\.com/categories/\d+/[a-z0-9-]+/)"><span>(?P<name>[^<]*?)\s*<small>\((?P<count>[^)]*)\)',
        url=_paged('{u}', '{u}page{p}.html'), parse=lambda h: _as._xerotica_parse_listing(h)),
    'redtube': dict(
        base='https://www.redtube.com', index=['https://www.redtube.com/categories'],
        rx=_anchor(r'/redtube/[a-z0-9-]+'),
        url=_paged('{u}', '{u}?page={p}'), parse=_parse_redtube),
    'tube8': dict(
        base='https://www.tube8.com', index=['https://www.tube8.com/'],
        rx=_anchor(r'/cat/[a-z0-9-]+/'), strip=r'\s+Category$',
        url=_paged('{u}', '{u}?page={p}'), parse=lambda h: _as._tube8_parse_listing(h)),
    # ── sites parsed from their own card regex ───────────────────────────────
    '3movs': dict(
        base='https://www.3movs.com', index=['https://www.3movs.com/categories/'],
        rx=r'<a class="th_cat" href="(?P<href>https://www\.3movs\.com/categories/[a-z0-9-]+/)" title="(?P<name>[^"]+)".*?'
           r'data-src="(?P<thumb>[^"]+)"',
        url=_paged('{u}', '{u}{p}/'), loose=True, parse=_cards_slugtitle('_RE_TMOVS_CARD', '3movs')),
    'justporn': dict(
        base='https://www.justporn.com', index=['https://www.justporn.com/categories/'],
        rx=_anchor(r'https://www\.justporn\.com/categories/[a-z0-9-]+/'),
        url=_paged('{u}', '{u}?mode=async&function=get_block&block_id=custom_list_videos_common_videos_list&sort_by=post_date&from={p}'),
        parse=_cards_slugtitle('_RE_JPORN_CARD', 'justporn')),
    'porn00': dict(
        base='https://www.porn00.org', index=['https://www.porn00.org/category-list/'],
        rx=r'<a class="item" href="(?P<href>https://www\.porn00\.org/category-name/[a-z0-9-]+/)"[^>]*>.*?'
           r'<img class="thumb" src="(?P<thumb>[^"]+)".*?<strong class="title">(?P<name>[^<]+)</strong>',
        url=_paged('{u}', '{u}{p}/'), parse=_parse_porn00),
    'porngo': dict(
        base='https://www.porngo.com', index=['https://www.porngo.com/categories/'], first=100,
        rx=r'<a href="(?P<href>https://www\.porngo\.com/categories/[a-z0-9-]+/)" class="letter-block__link">\s*<span>(?P<name>[^<]+)</span>',
        url=_paged('{u}', '{u}{p}/'), parse=_cards_slugtitle('_RE_PGO_CARD', 'porngo')),
    'pornhat': dict(
        base='https://pornhat.com', index=['https://pornhat.com/tags/'], limit=250,
        rx=r'<a class="item" href="(?P<href>/tags/[a-z0-9-]+/)"><i class="fa fa-tag"></i>\s*(?P<name>[^<(]+?)\s*\((?P<count>[\d.,KkMm]+)\)</a>',
        url=_paged('{u}', '{u}{p}/'), parse=_parse_gf13('pornhat', 'https://pornhat.com')),
    'okxxx': dict(
        base='https://ok.xxx', index=['https://ok.xxx/tags/'], limit=250,
        rx=r'<a class="item" href="(?P<href>/tags/[a-z0-9-]+/)"[^>]*>(?:<i[^>]*></i>)?\s*(?P<name>[^<(]+?)\s*\((?P<count>[\d.,KkMm]+)\)</a>',
        url=_paged('{u}', '{u}{p}/'), parse=_parse_gf13('okxxx', 'https://ok.xxx')),
    'xmoviesforyou': dict(
        base='https://xmoviesforyou.com', index=['https://xmoviesforyou.com/categories'],
        rx=r'<a href="(?P<href>/category/[a-z0-9-]+)"[^>]*>\s*<h3[^>]*>(?P<name>[^<]+)</h3>.*?</span>\s*(?P<count>\d+)\s*</span>',
        url=_paged('{u}', '{u}?page={p}'), parse=_parse_xmfy),
    'allpornstream': dict(
        base='https://allpornstream.com', index=['https://allpornstream.com/categories'],
        rx=r'<a class="group relative[^"]*" title="View all videos in (?P<name>[^"]+)" href="(?P<href>/categories/[a-z0-9-]+)"',
        url=_paged('{u}', '{u}?page={p}'), parse=_parse_aps),
    'pornone': dict(
        base='https://pornone.com', index=['https://pornone.com/categories/'],
        rx=r'<a href="(?P<href>/[a-z0-9-]+/)" class="popbop[^"]*">\s*<img[^>]*data-src="(?P<thumb>[^"]+)"[^>]*>\s*'
           r'<p[^>]*>(?P<name>[^<]+)</p>',
        url=_paged('{u}', '{u}{p}/'), parse=_parse_pnone),

    # ── Adult > Movies sites (category rows; stubs come from each site's own list function) ──
    'freeomovie': dict(
        base='https://www.freeomovie.to', index=['https://www.freeomovie.to/'],
        rx=_anchor(r'https://www\.freeomovie\.to/category/[a-z0-9-]+/'),
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._freeo_film_list(1, url_override=u)),
    'pornwatch': dict(
        base='https://pornwatch.ws', index=['https://pornwatch.ws/genres/?sort=pop'], limit=150,
        rx=r'<a class="chip" href="(?P<href>https://pornwatch\.ws/genre/[^"]+)">(?P<name>.*?)</a>',
        url=_paged('{u}', '{us}/page/{p}/'), list_fn=lambda u: _as._wpw_film_list(1, url_override=u)),
    'watchpornfree': dict(
        base='https://watchpornfree.info', index=['https://watchpornfree.info/watch-free-moivies-by-genres'], limit=150,
        rx=r'<a class="chip" href="(?P<href>https://watchpornfree\.info/genre/[^"]+)">(?P<name>.*?)</a>',
        url=_paged('{u}', '{us}/page/{p}'), list_fn=lambda u: _as._wpf_film_list(1, url_override=u)),
    'speedporn': dict(
        base='https://speedporn.net', index=['https://speedporn.net/'],
        rx=_anchor(r'https://speedporn\.net/director/[a-z0-9-]+/'),
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._spn_film_list(1, url_override=u)),
    'xmovix': dict(
        base='https://hd.xmovix.net', index=['https://hd.xmovix.net/'],
        rx=r'<li><a href="(?P<href>/(?!favorites|movies|porn-scenes|porno-parodies)[a-z0-9_-]+/)">(?P<name>[^<]+)</a></li>',
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._xmovix_film_list(1, url_override=u)),
    'pelisxporno': dict(
        base='https://www.pelisxporno.net', index=['https://www.pelisxporno.net/'], limit=150,
        rx=r'<a href="(?P<href>https://www\.pelisxporno\.net/[a-z0-9-]+/)" class="">(?P<name>[^<]+)</a>',
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._pxp_film_list(1, url_override=u)),
    'filmadult': dict(
        base='https://film-adult.video', index=['https://film-adult.video/en/'],
        static=[('Movies in FullHD', 'https://film-adult.video/en/movies/hd-1080p/'),
                ('Movies in HD', 'https://film-adult.video/en/movies/hd-720p/'),
                ('Russian Movies', 'https://film-adult.video/en/movies/russian/'),
                ('Classic', 'https://film-adult.video/en/movies/vintagexxx/'),
                ('Parodies', 'https://film-adult.video/en/movies/porno-parodies/')],
        rx=r'<a href="(?P<href>/en/(?!favorites|page|lastviewed|movies|russian|vintagexxx|porno-parodies)(?:watch/country/[A-Za-z]+|[a-z0-9_-]+)/)">(?P<name>[^<]+)</a>',
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._fa_film_list(1, url_override=u)),
    'mangoporn': dict(
        base='https://mangoporn.net', index=['https://mangoporn.net/'],
        rx=_anchor(r'https://mangoporn\.net/(?:movies/category|movies/studios|studios)/[a-z0-9-]+/'),
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._mango_film_list(1, url_override=u)),
    'swingerpornfun': dict(
        base='https://swingerpornfun.com', index=['https://swingerpornfun.com/'],
        rx=_anchor(r'https://swingerpornfun\.com/category/[a-z0-9_-]+/'),
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._sf_film_list(1, url_override=u)),
    'paradisehill': dict(
        base='https://en.paradisehill.cc', index=['https://en.paradisehill.cc/categories/'], get='_paradise_get',
        rx=r'<a href="(?P<href>/category/[a-z0-9-]+/\?sort=created_at)">.*?<span>(?P<name>[^<]+)</span>.*?'
           r'<img itemprop="image" src="(?P<thumb>[^"]+)"',
        url=_paged('{u}', '{u}&page={p}'), list_fn=lambda u: _as._paradise_film_list(1, url_override=u)),
    '5moviesporn': dict(
        base='https://www.5moviesporn.io', index=['https://www.5moviesporn.io/'],
        rx=_anchor(r'https://www\.5moviesporn\.io/(?:tag|genre)/[a-z0-9-]+/'),
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._mp5_film_list(1, url_override=u)),
    'sujmobi': dict(
        base='https://pc.suj.mobi', index=['https://pc.suj.mobi/en/films'],
        rx=_anchor(r'https://pc\.suj\.mobi/en/films/[a-z0-9_-]+'),
        url=_paged('{u}', '{u}?page={p}'), list_fn=lambda u: _as._suj_parse_cards(_as._get(u, timeout=(5, 12)))),
    'uiiumovie': dict(
        base='https://uiiumovie.com', index=['https://uiiumovie.com/'],
        rx=_anchor(r'https://uiiumovie\.com/(?:category|country|quality)/[a-z0-9-]+/'),
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._uiiu_film_list(1, url_override=u)),
    'krx18': dict(
        base='https://krx18.com', index=['https://krx18.com/'], limit=150,
        rx=_anchor(r'https://krx18\.com/genre/[a-z0-9-]+/'),
        url=_paged('{u}', '{u}page/{p}/'), list_fn=lambda u: _as._krx_film_list(1, url_override=u)),
    'superporn': dict(
        base='https://www.superporn.com', index=['https://www.superporn.com/series/full-movies'], first=100,
        rx=_anchor(r'https://www\.superporn\.com/series/[a-z0-9-]+'),
        url=_paged('{u}', '{u}/{p}'), list_fn=lambda u: _as._sup_film_list(1, url_override=u)),
}


# txxx / hdzog share one JSON api (categories list + per-category video lists)
def _json_family(base, source):
    def cats():
        j = json.loads(_as._get(base + '/api/json/categories/14400/str.all.en.json'))
        return [{'name': c.get('title', ''), 'slug': str(c.get('dir')),
                 'count': int(c.get('total_videos') or 0), 'thumb': ''} for c in j.get('categories', []) if c.get('dir')]

    def movies(cdir, page):
        u = base + '/api/json/videos/86400/str/latest-updates/60/categories.%s.%d.all..day.json' % (cdir, page)
        return _as._txxx_parse_listing(json.loads(_as._get(u)), source, base)
    return cats, movies


_JSON_SITES = {k: _json_family(b, k) for k, b in _as._TXXX_FAMILY_BASE.items()}


def _stub(f, site):
    """Listing stubs from the older list functions carry only slug/url (+ maybe title/thumb);
    the menus need a title, so build the missing fields from the slug."""
    f = dict(f)
    title = f.get('title') or f.get('slug', '').replace('-', ' ').replace('_', ' ').title()
    f['title'] = _as._clean_title(title)
    f.setdefault('title_norm', _as._norm_title(title))
    f.setdefault('thumb', '')
    f.setdefault('source', site)
    f.setdefault('streams', [])
    return f


def has_categories(site):
    return site in SITES or site in _JSON_SITES


def _fetch(site, url):
    cfg = SITES[site]
    if cfg.get('loose'):        # server answers real pages with a 404 status on later pages
        return _as._sess().get(url, timeout=(5, 12)).text
    getter = getattr(_as, cfg['get']) if cfg.get('get') else _as._get
    try:
        return getter(url, timeout=(6, 25))
    except TypeError:
        return getter(url)
    except Exception:
        return getter(url, timeout=(6, 25))        # one more try - these index pages are 200 KB - 1 MB


def categories(site):
    """[{'name', 'slug', 'count', 'thumb'}] for a site (cached 24h)."""
    ck = 'adultcat_%s_v1' % site
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    cats, seen = [], set()
    if site in _JSON_SITES:
        try:
            cats = _JSON_SITES[site][0]()
        except Exception as e:
            xbmc.log('[Starfleet/AdultCats] %s categories: %s' % (site, e), xbmc.LOGWARNING)
    else:
        cfg = SITES[site]
        for name, href in cfg.get('static', ()):
            seen.add(href)
            cats.append({'name': name, 'slug': href, 'count': 0, 'thumb': ''})
        rx = re.compile(cfg['rx'], re.IGNORECASE | re.DOTALL) if cfg.get('rx') else None
        for idx in (cfg.get('index') or ()) if rx else ():
            try:
                html = _fetch(site, idx)
            except Exception as e:
                xbmc.log('[Starfleet/AdultCats] %s index %s: %s' % (site, idx, e), xbmc.LOGWARNING)
                continue
            for m in rx.finditer(html):
                gd = m.groupdict()
                href = _abs(cfg['base'], gd['href'])
                raw, count = gd.get('name') or '', gd.get('count')
                tail = _RE_COUNT_TAIL.match(raw)
                if tail and not count:
                    raw, count = tail.group('n'), tail.group('c')
                name = _clean(raw)
                if cfg.get('strip'):
                    name = re.sub(cfg['strip'], '', name, flags=re.IGNORECASE).strip()
                w = name.split(' ')
                if len(w) > 1 and w[0].lower() == w[1].lower():      # 'HD HD 1080p' (label + alt text)
                    name = ' '.join(w[1:])
                if not name or href in seen:
                    continue
                seen.add(href)
                cats.append({'name': name, 'slug': href, 'count': _num(count),
                             'thumb': _abs(cfg['base'], gd['thumb']) if gd.get('thumb') else ''})
        if cfg.get('first'):
            cats = cats[:cfg['first']]
        if cfg.get('limit') and len(cats) > cfg['limit']:
            cats = sorted(cats, key=lambda c: -c['count'])[:cfg['limit']]
            cats.sort(key=lambda c: c['name'].lower())
    if cats:
        _cache.set(ck, cats, 24 * 3600)
    return cats


def category_movies(site, slug, page=1):
    """Films for one category page, via the site's own parser/card regex."""
    ck = 'adultcat_%s_%s_%d' % (site, re.sub(r'\W+', '_', slug)[-60:], page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    try:
        if site in _JSON_SITES:
            films = _JSON_SITES[site][1](slug, page)
        else:
            cfg = SITES[site]
            url = cfg['url'](slug, page)
            films = cfg['list_fn'](url) if cfg.get('list_fn') else cfg['parse'](_fetch(site, url))
        films = [_stub(f, site) for f in (films or [])]
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/AdultCats] %s %s p%d: %s' % (site, slug, page, e), xbmc.LOGWARNING)
        return []
