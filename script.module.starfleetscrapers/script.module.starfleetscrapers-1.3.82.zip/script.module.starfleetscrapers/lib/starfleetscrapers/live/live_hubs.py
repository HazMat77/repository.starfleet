# -*- coding: utf-8 -*-
"""Channel hubs for Live TV: free catalogues of 24/7 channels, each returned as the list live_sources hands to the menus
([{'id','title','group','source','thumbnail','stream_url','alt_streams'}], grouped by 'group').

    Famelack         open channel database (famelack-data): ~6,000 channels with direct playlists, grouped by category
    Easy Web TV      the public iptv-org category playlists, grouped by category
    PPV 24/7         the 24/7 channels of the ppv.st feed (US sports networks); frames resolved by Starfleet Resolver
    NTV Hesgoal      ntv.st's channel catalogue, the Hesgoal part (the rest of that catalogue is DLHD / CDN Live, already here)
    Free Streams TV  freestreams-live1i.pk 24/7 sports channels; the channel pages are opened by Starfleet Resolver
"""
import gzip
import json
import re
from concurrent.futures import ThreadPoolExecutor

import xbmc

from starfleetscrapers import host as _sfhost
from starfleetscrapers.core import http as requests
from starfleetscrapers.core import cache as _cache

_cache.init(_sfhost.profile() + '/cache.db')

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
_DAY = 24 * 3600


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/LiveHubs] %s' % msg, level)


def _get(url, referer=None, timeout=20):
    h = {'User-Agent': UA}
    if referer:
        h['Referer'] = referer
    r = requests.get(url, headers=h, timeout=timeout)
    r.raise_for_status()
    return r


def _cached(key, ttl, build):
    hit = _cache.get(key)
    if hit is not None:
        return hit
    out = build()
    if out:
        _cache.set(key, out, ttl)
    return out


# ── Famelack ──────────────────────────────────────────────────────────────────

_FAME = 'https://raw.githubusercontent.com/famelack/famelack-data/main/tv/compressed/categories/%s.json'
# first match wins when a channel is in several categories; 'general' (a catch-all) last
_FAME_CATS = (('sports', 'Sports'), ('news', 'News'), ('top-news', 'News'), ('movies', 'Movies'), ('series', 'Series'),
              ('kids', 'Kids'), ('animation', 'Kids'), ('family', 'Kids'), ('music', 'Music'),
              ('documentary', 'Documentary'), ('science', 'Documentary'), ('culture', 'Documentary'),
              ('education', 'Education'), ('entertainment', 'Entertainment'), ('comedy', 'Entertainment'),
              ('show', 'Entertainment'), ('classic', 'Entertainment'), ('lifestyle', 'Lifestyle'),
              ('cooking', 'Lifestyle'), ('travel', 'Lifestyle'), ('outdoor', 'Lifestyle'), ('relax', 'Lifestyle'),
              ('auto', 'Lifestyle'), ('business', 'Business'), ('shop', 'Shopping'), ('religious', 'Religious'),
              ('legislative', 'Government'), ('weather', 'Weather'), ('general', 'General'))


def _fame_json(cat):
    raw = requests.get(_FAME % cat, headers={'User-Agent': UA}, timeout=30).content
    try:
        raw = gzip.decompress(raw)          # the files are served gzip-compressed
    except Exception:
        pass
    return json.loads(raw.decode('utf-8'))


def _build_famelack():
    def one(entry):
        try:
            return entry, _fame_json(entry[0])
        except Exception as e:
            _log('famelack %s: %s' % (entry[0], str(e)[:70]), xbmc.LOGINFO)
            return entry, []
    seen, out = set(), []
    with ThreadPoolExecutor(max_workers=6) as ex:
        for (_cat, group), items in ex.map(one, _FAME_CATS):
            for it in items or []:
                nid = it.get('nanoid')
                streams = [u for u in ((it.get('sources') or {}).get('streams') or []) if u.startswith('http')]
                if not nid or nid in seen or not streams or not it.get('name'):
                    continue
                seen.add(nid)
                cc = (it.get('country') or '').upper()
                out.append({'id': 'fame_%s' % nid, 'title': '%s (%s)' % (it['name'].strip(), cc) if cc else it['name'].strip(),
                            'group': group, 'source': 'Famelack', 'thumbnail': '', 'stream_url': streams[0],
                            'alt_streams': streams[1:4]})
    _log('famelack: %d channels' % len(out))
    return out


def get_famelack_channels():
    return _cached('famelack_channels_v1', _DAY, _build_famelack)


# ── Easy Web TV (iptv-org category playlists) ─────────────────────────────────

_IPTV = 'https://iptv-org.github.io/iptv/categories/%s.m3u'
_IPTV_CATS = ('animation', 'auto', 'business', 'classic', 'comedy', 'cooking', 'culture', 'documentary', 'education',
              'entertainment', 'family', 'general', 'kids', 'legislative', 'lifestyle', 'movies', 'music', 'news',
              'outdoor', 'public', 'relax', 'religious', 'science', 'series', 'shop', 'sports', 'travel', 'weather')
_RE_EXTINF = re.compile(r'#EXTINF:[^,\n]*?(?:tvg-logo="([^"]*)")?[^,\n]*,\s*([^\n]*)')


def _parse_iptv(text, group):
    out = []
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if not line.startswith('#EXTINF'):
            continue
        name = line.rsplit(',', 1)[-1].strip()
        logo = re.search(r'tvg-logo="([^"]*)"', line)
        j = i + 1
        while j < len(lines) and lines[j].startswith('#'):
            j += 1
        url = lines[j].strip() if j < len(lines) else ''
        if name and url.startswith('http'):
            out.append({'title': name, 'group': group, 'thumbnail': logo.group(1) if logo else '', 'stream_url': url})
    return out


def _build_easywebtv():
    def one(cat):
        try:
            return cat, _get(_IPTV % cat, timeout=30).text
        except Exception as e:
            _log('easy web tv %s: %s' % (cat, str(e)[:70]), xbmc.LOGINFO)
            return cat, ''
    seen, out = set(), []
    with ThreadPoolExecutor(max_workers=6) as ex:
        for cat, text in ex.map(one, _IPTV_CATS):
            group = cat.replace('-', ' ').title()
            for ch in _parse_iptv(text, group):
                if ch['stream_url'] in seen:
                    continue
                seen.add(ch['stream_url'])
                ch['id'] = 'ewtv_%d' % len(out)
                ch['source'] = 'Easy Web TV'
                out.append(ch)
    _log('easy web tv: %d channels' % len(out))
    return out


def get_easywebtv_channels():
    return _cached('easywebtv_channels_v1', _DAY, _build_easywebtv)


# ── PPV 24/7 ──────────────────────────────────────────────────────────────────

def _build_ppv247():
    data = _get('https://api.ppv.st/api/streams', referer='https://ppv.st/').json()
    out = []
    for cat in data.get('streams') or []:
        for s in cat.get('streams') or []:
            if not s.get('always_live') or not s.get('iframe'):
                continue
            alt = [x['iframe'] for x in (s.get('substreams') or []) if x.get('iframe')]
            out.append({'id': 'ppv_%s' % s.get('id'), 'title': (s.get('name') or '').strip(),
                        'group': s.get('category_name') or cat.get('category') or '24/7', 'source': 'PPV 24/7',
                        'thumbnail': s.get('poster') or '', 'stream_url': s['iframe'], 'alt_streams': alt[:3]})
    _log('ppv 24/7: %d channels' % len(out))
    return out


def get_ppv247_channels():
    return _cached('ppv247_channels_v1', 6 * 3600, _build_ppv247)


# ── NTV Hesgoal ───────────────────────────────────────────────────────────────

_RE_SPORT_NAME = re.compile(r'sport|bein|espn|dazn|fox\s*s|tnt|sky\s*s|nbc\s*s|nba|nfl|nhl|mlb|ufc|wwe|golf|tennis|f1|racing|'
                            r'eleven|arena|sony\s*ten|star\s*s|super\s*s|viaplay|canal\+?\s*s|movistar|premier|euro\s*s', re.I)
_RE_NEWS_NAME = re.compile(r'news|cnn|bbc|msnbc|cnbc|aljazeera|al jazeera|sky news|euronews|france\s*24|dw\b', re.I)
_RE_HESGOAL_ID = re.compile(r'[?&]id=([A-Za-z0-9_-]+)')


def _build_ntvhub():
    out, off = [], 0
    while off < 3000:
        d = _get('https://ntv.st/api/get-channels?limit=200&offset=%d' % off, referer='https://ntv.st/channels').json()
        for c in d.get('channels') or []:
            if c.get('server') != 'hesgoales':
                continue                  # DLHD and CDN Live channels are listed by their own sections
            m = _RE_HESGOAL_ID.search(c.get('channel_url') or '')
            name = (c.get('channel_name') or '').strip()
            if not m or not name:
                continue
            group = 'Sports' if _RE_SPORT_NAME.search(name) else 'News' if _RE_NEWS_NAME.search(name) else 'TV'
            out.append({'id': 'ntv_%s' % c.get('channel_id'), 'title': name, 'group': group, 'source': 'NTV',
                        'thumbnail': '', 'stream_url': 'https://wideiptv.top/player/%s' % m.group(1)})
        if not d.get('has_more'):
            break
        off += 200
    _log('ntv hesgoal: %d channels' % len(out))
    return out


def get_ntvhub_channels():
    return _cached('ntvhub_channels_v1', 6 * 3600, _build_ntvhub)


# ── Free Streams TV ───────────────────────────────────────────────────────────

_FSL = 'https://freestreams-live1i.pk'
_RE_FSL_CH = re.compile(r'(?is)<a\s[^>]*href="(https?://freestreams-live1i[.]pk/[a-z0-9-]+/)"[^>]*>(.*?)</a>')


def _build_fsltv():
    page = _get(_FSL + '/live-tv/', referer=_FSL + '/', timeout=25).text
    i = page.find('/dmca/')                     # everything before the DMCA link is the site menu
    out, seen = [], set()
    for href, inner in _RE_FSL_CH.findall(page[i:] if i > 0 else page):
        title = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', inner)).strip()
        if not title or title.upper() in ('WATCH', 'HOME') or href in seen:
            continue
        seen.add(href)
        out.append({'id': 'fsl_%s' % href.rstrip('/').rsplit('/', 1)[-1], 'title': title, 'group': 'Sports', 'source': 'Free Streams',
                    'thumbnail': '', 'stream_url': href})
    _log('free streams tv: %d channels' % len(out))
    return out


def get_fsltv_channels():
    return _cached('fsltv_channels_v1', 6 * 3600, _build_fsltv)


# ── TVNow.st ─────────────────────────────────────────────────────────────────────

_TVNOWST = 'https://tvnow.st'


def _build_tvnowst():
    d = _get(_TVNOWST + '/api/channels', referer=_TVNOWST + '/').json()
    out = []
    for c in d.get('channels') or []:
        url, name = c.get('playback') or '', (c.get('name') or '').strip()
        if not url or not name:
            continue
        out.append({'id': 'tvnowst_%s' % c.get('slug'), 'title': name, 'group': c.get('category') or 'TV', 'source': 'TVNow.st',
                    'thumbnail': (_TVNOWST + c['logo']) if (c.get('logo') or '').startswith('/') else (c.get('logo') or ''),
                    'stream_url': '%s|Referer=%s/&Origin=%s' % (url, _TVNOWST, _TVNOWST)})
    _log('tvnow.st: %d channels' % len(out))
    return out


def get_tvnowst_channels():
    return _cached('tvnowst_channels_v1', 6 * 3600, _build_tvnowst)
