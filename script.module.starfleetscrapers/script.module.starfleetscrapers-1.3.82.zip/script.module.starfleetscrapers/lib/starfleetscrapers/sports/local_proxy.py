# -*- coding: utf-8 -*-
"""
resources/lib/local_proxy.py — a tiny loopback-only HTTP relay built to
close the real, live-confirmed gap behind OK.ru replays failing to play:
Kodi's own inputstream.ffmpegdirect/cURL layer doesn't reliably send back
the exact header a signed OK.ru CDN URL needs (see sports_router.
_resolve_okru's own docstring for the live investigation) — instead of an
instant rejection, the connection just stalls for ~30s and then fails,
confirmed live on both Windows and Firestick alike, so it was never
device-specific the way it first looked.

v2.3.478 shipped this as a per-request server, started lazily inside
whatever short-lived `plugin://` invocation happened to be resolving a
stream — and immediately proved broken via a real kodi.log: this addon
declares <reuselanguageinvoker>false</reuselanguageinvoker>, so Kodi tears
down that entire Python process once the resolving call returns control,
killing the background thread serving the relay right as the player was
starting to stream from it. Same ~30s hang-then-fail as before, just one
layer further in.

Fixed properly here by moving the server into service.py (at the addon
root, registered via addon.xml's xbmc.python.service extension point), a
real Kodi background service (start="startup") that lives for the whole
Kodi session, independent of any single plugin:// call. Since the
resolving call and the service are separate OS processes, they can't
share Python objects directly — they agree on one FIXED port instead
(_PORT below). The resolving side does a fast loopback health-check before
building a relay URL and falls back to the pre-existing direct-URL
behavior if the service isn't up yet (e.g. right after this update, before
the next Kodi restart — services only start at Kodi startup, not
retroactively for an addon that just updated mid-session).

UPDATE 2026-09-05 — confirmed live via a real kodi.log this was built and
never actually finished: addon.xml never declared the xbmc.python.service
extension point at all (so this file's own run_service() never ran, ever
— no "[Starfleet/LocalProxy] service started" line has ever appeared in
any log), AND sports_router._resolve_okru() never called
build_relay_url() below, still handing Kodi's player the direct CDN URL
regardless. Both gaps are fixed alongside this update.

UPDATE 2026-09-05 (later same day) — with the relay actually running and
wired in, a fresh kodi.log (this file's own new per-request logging,
added the same update) showed something the direct-URL failures never
could: Kodi opened SIX separate connections to the relay for the exact
same target URL within about 2 seconds (the first couple with no Range
header at all, the rest with "Range: bytes=0-") — and every one of them
except the last got an upstream TCP reset from okcdn.ru after almost
exactly one 65536-byte chunk; the one connection that got further only
made it to ~8MB before the whole thing still gave up around 32s. That
shape — many near-simultaneous connections to the identical signed URL,
all but one cut short almost immediately — is consistent with okcdn.ru
enforcing (loosely) one live connection per signed URL and punishing the
others, and this relay was making that worse: each of Kodi's own
retry/probe connections got its own brand-new, fully independent upstream
fetch with zero coordination between them. Serializing same-target
requests through a per-URL lock (below) stops the relay from ever having
more than one connection open to okcdn.ru for a given URL at a time,
regardless of how many overlapping requests Kodi itself makes — closing
off that specific way of provoking the CDN's own connection limit,
whatever that limit's exact rule turns out to be.
"""
import re
import threading
import time
import xbmc

_PORT = 51621

# A device that is sent a stream (casting to a Chromecast / Google TV) reaches this relay over the LAN: such a request is answered only when
# it carries the token made by cast_url(), and the links in the playlists it gets point at the address it used, not at 127.0.0.1.
_tl = threading.local()
_cast_token = [None]


def _self_base():
    h = getattr(_tl, 'host', None)
    return 'http://%s' % (h or '127.0.0.1:%d' % _PORT)


def _ct():
    return '&ct=%s' % _cast_token[0] if getattr(_tl, 'remote', False) and _cast_token[0] else ''

# Per-target-URL locks so overlapping requests for the identical upstream
# URL (Kodi's own probe/retry connections landing on this relay at close
# to the same moment — see the docstring update above for why that
# happens and why it matters) are serialized into one upstream connection
# at a time instead of each opening its own independently. Plain dict of
# locks, never pruned — this addon only ever relays a small, short-lived
# number of distinct URLs per session (one active stream at a time in
# practice), so unbounded growth here isn't a real concern.
_target_locks = {}
_target_locks_guard = threading.Lock()


def _lock_for(target):
    with _target_locks_guard:
        lock = _target_locks.get(target)
        if lock is None:
            lock = threading.Lock()
            _target_locks[target] = lock
        return lock

_server = None
_lock = threading.Lock()


# ── HLS "unwrap" relay ───────────────────────────────────────────────────────
#
# Added 2026-10-02 after a real kodi.log of a Starfleet sports stream (MLB
# game, inputstream.adaptive): "Cannot detect container type from media url,
# fallback to TS" -> "Cannot get the stream sample reader" -> "Codec id 27
# require extradata" -> video stream disabled, audio only, then EOF. Cause:
# several live-sports CDNs serve every .ts segment disguised as a picture -
# 40-odd bytes of RIFF/WEBP (or similar) header, sometimes more, in front of
# the real MPEG-TS - and Kodi's demuxers need the segment to START on a
# transport-stream sync byte. Measured the same day: FlyEmbed and MethStreams
# streams return Content-Type image/webp segments whose first aligned TS sync
# byte sits 42 bytes in.
#
# /hls serves a rewritten copy of the real playlist (every segment/variant/key
# URI pointed back at this relay, with the headers the upstream needs carried
# along), /seg fetches a segment and drops everything before the first
# 0x47-aligned run, /raw passes keys and init segments through untouched. A
# stream whose segments are already plain TS never goes through it (see
# maybe_wrap_hls) - this is a repair path, not a default one.

_TS_PACKET = 188


def _find_ts_start(data):
    """Offset of the first byte that begins 5 consecutive 188-byte TS packets,
    -1 when the data isn't MPEG-TS at all (fMP4, encrypted, HTML error...)."""
    limit = min(4096, len(data) - 5 * _TS_PACKET)
    for off in range(max(limit, 0)):
        if data[off] == 0x47 and all(data[off + k * _TS_PACKET] == 0x47 for k in range(1, 5)):
            return off
    return -1


_TS_MARK_RAW = b'TIKTIKRAW'
_TS_MARK_GZ = b'TIKTIKTSGZ'
_TS_MARK_PIX = b'TIKTIKPX'


def _is_ts_at(data, off=0):
    return (len(data) > off + _TS_PACKET and data[off] == 0x47
            and data[off + _TS_PACKET] == 0x47)


def _webp_exif_ts(data):
    """WebP whose EXIF chunk carries the transport stream."""
    import struct
    if len(data) < 16 or data[:4] != b'RIFF' or data[8:12] != b'WEBP':
        return None
    off = 12
    while off + 8 <= len(data):
        tag = data[off:off + 4]
        size = struct.unpack_from('<I', data, off + 4)[0]
        off += 8
        if off + size > len(data):
            return None
        if tag == b'EXIF':
            chunk = data[off:off + size]
            return chunk if _is_ts_at(chunk) else None
        off += size + (size & 1)
    return None


def _png_chunks(data):
    import struct
    off = 8
    while off + 8 <= len(data):
        size = struct.unpack_from('>I', data, off)[0]
        if size > len(data) - off - 12:
            return
        yield data[off + 4:off + 8], data[off + 8:off + 8 + size], off + 12 + size
        off += 12 + size


def _png_trailer_ts(data):
    """Valid PNG with the transport stream appended after IEND."""
    for ctype, _body, end in _png_chunks(data):
        if ctype == b'IEND':
            return data[end:] if _is_ts_at(data, end) else None
    return None


def _png_pixel_ts(data):
    """PNG whose RGB pixel bytes hold  TIKTIKPX + u32 length + gzip(transport stream)."""
    import struct
    import zlib
    import gzip
    width = height = depth = ctype = interlace = 0
    idat = []
    for name, body, _end in _png_chunks(data):
        if name == b'IHDR':
            width, height, depth, ctype, _c, _f, interlace = struct.unpack('>IIBBBBB', body[:13])
        elif name == b'IDAT':
            idat.append(body)
        elif name == b'IEND':
            break
    if not width or not height or depth != 8 or interlace or ctype not in (2, 6):
        return None
    raw = zlib.decompress(b''.join(idat))
    bpp = 4 if ctype == 6 else 3
    stride = width * bpp
    prev = bytearray(stride)
    out = bytearray()
    src = 0
    for _ in range(height):
        if src + 1 + stride > len(raw):
            return None
        ft = raw[src]
        row = raw[src + 1:src + 1 + stride]
        src += 1 + stride
        if ft == 0:
            cur = bytearray(row)
        elif ft == 2:
            cur = bytearray((a + b) & 255 for a, b in zip(row, prev))
        elif ft in (1, 3, 4):
            cur = bytearray(stride)
            for i in range(stride):
                left = cur[i - bpp] if i >= bpp else 0
                if ft == 1:
                    v = row[i] + left
                elif ft == 3:
                    v = row[i] + ((left + prev[i]) >> 1)
                else:
                    ul = prev[i - bpp] if i >= bpp else 0
                    p = left + prev[i] - ul
                    pa, pb, pc = abs(p - left), abs(p - prev[i]), abs(p - ul)
                    v = row[i] + (left if pa <= pb and pa <= pc else (prev[i] if pb <= pc else ul))
                cur[i] = v & 255
        else:
            return None
        if ctype == 6:
            px = bytearray(cur)
            del px[3::4]
            out += px
        else:
            out += cur
        prev = cur
        if len(out) >= 8 and out[:8] != _TS_MARK_PIX:
            return None
    if len(out) < 12 or out[:8] != _TS_MARK_PIX:
        return None
    n = struct.unpack_from('>I', out, 8)[0]
    packed = bytes(out[12:12 + n])
    if n <= 0 or packed[:2] != b'\x1f\x8b':
        return None
    ts = gzip.decompress(packed)
    return ts if ts[:1] == b'G' else None


def _looks_disguised(head):
    """True when the first bytes of a segment say it is not plain TS."""
    return (head[:4] == b'RIFF' or head[:2] == b'\x89P' or b'TIKTIK' in head[:4096]
            or _find_ts_start(head) > 0)


def _unwrap_segment(data):
    """Return the transport stream hidden inside `data` (unchanged when it is plain)."""
    ts = _webp_exif_ts(data)
    if ts:
        return ts
    if data[:2] == b'\x89P':
        ts = _png_trailer_ts(data)
        if ts:
            return ts
        # the stream written straight into the picture, right behind its header (the 8-byte signature and the header chunk)
        off = _find_ts_start(data[:5200])
        if off >= 0:
            body = data[off:]
            if body.endswith(b'IEND\xaeB`\x82'):
                body = body[:-12]
            return body[:len(body) - len(body) % _TS_PACKET]
        try:
            ts = _png_pixel_ts(data)
        except Exception:
            ts = None
        return ts or data
    off = data.find(_TS_MARK_RAW)
    while off >= 0:
        if data[off + len(_TS_MARK_RAW):off + len(_TS_MARK_RAW) + 1] == b'G':
            return data[off + len(_TS_MARK_RAW):]
        off = data.find(_TS_MARK_RAW, off + 1)
    off = data.find(_TS_MARK_GZ)
    if off >= 0:
        try:
            import gzip
            return gzip.decompress(data[off + len(_TS_MARK_GZ):])
        except Exception:
            pass
    off = _find_ts_start(data[:5200])
    return data[off:] if off > 0 else data


def _split_pipe_headers(url):
    """'https://x/y.m3u8|Referer=..&User-Agent=..' -> (url, {headers})."""
    from urllib.parse import unquote
    base, _, tail = url.partition('|')
    headers = {}
    for kv in tail.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            headers[k] = unquote(v)
    return base, headers


def _enc_headers(headers):
    import base64
    import json
    return base64.urlsafe_b64encode(json.dumps(headers or {}).encode('utf-8')).decode('ascii')


def _dec_headers(blob):
    import base64
    import json
    try:
        return json.loads(base64.urlsafe_b64decode((blob or '').encode('ascii') + b'=' * (-len(blob or '') % 4)))
    except Exception:
        return {}


_DEFAULT_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
               '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')


_LIVE_KEEP = 40          # segments kept of a very long live playlist


def _trim_live(text, keep=_LIVE_KEEP):
    """A live playlist that lists the whole event so far (thousands of segments, no end tag) is cut down to its newest `keep`
    segments, with the sequence numbers moved on to match. Re-reading a playlist that long every few seconds, and rewriting every
    line of it, stalls a small device. Playlists that end (movies, replays) and short ones are returned untouched."""
    lines = text.splitlines()
    if '#EXT-X-ENDLIST' in text or text.count('#EXTINF') <= keep * 2:
        return text
    first = next((i for i, l in enumerate(lines) if l.startswith('#EXTINF')), -1)
    if first < 0:
        return text
    head, body = lines[:first], lines[first:]
    uris = [i for i, l in enumerate(body) if l.strip() and not l.startswith('#')]
    drop = len(uris) - keep
    if drop <= 0:
        return text
    cut = uris[drop - 1] + 1
    gone, kept = body[:cut], body[cut:]
    seq = 0
    dseq = 0
    new_head = []
    for l in head:
        if l.startswith('#EXT-X-MEDIA-SEQUENCE:'):
            try:
                seq = int(l.split(':', 1)[1])
            except ValueError:
                seq = 0
        elif l.startswith('#EXT-X-DISCONTINUITY-SEQUENCE:'):
            try:
                dseq = int(l.split(':', 1)[1])
            except ValueError:
                dseq = 0
        elif l.startswith(('#EXT-X-PLAYLIST-TYPE', '#EXT-X-PROGRAM-DATE-TIME')):
            continue                    # a sliding window is not an "event" list; the date of the old first segment no longer applies
        else:
            new_head.append(l)
    discs = sum(1 for l in gone if l.startswith('#EXT-X-DISCONTINUITY') and not l.startswith('#EXT-X-DISCONTINUITY-SEQUENCE'))
    maps = [l for l in gone if l.startswith('#EXT-X-MAP')]
    if maps and not any(l.startswith('#EXT-X-MAP') for l in kept[:kept.index(next(l for l in kept if l.strip() and not l.startswith('#'))) + 1]):
        kept = [maps[-1]] + kept
    # sequence tags go right after the version tag
    at = next((i + 1 for i, l in enumerate(new_head) if l.startswith('#EXT-X-VERSION')), 1)
    new_head[at:at] = ['#EXT-X-MEDIA-SEQUENCE:%d' % (seq + drop)] + (['#EXT-X-DISCONTINUITY-SEQUENCE:%d' % (dseq + discs)] if dseq or discs else [])
    return chr(10).join(new_head + kept) + chr(10)


def _rewrite_playlist(text, base_url, headers):
    """Point every URI in an HLS playlist back at this relay."""
    import re
    from urllib.parse import urljoin, quote as _uq
    text = _trim_live(text)
    hb = _enc_headers(headers)

    def link(kind, target, suffix):
        return '%s/%s/x%s?url=%s&h=%s%s' % (
            _self_base(), kind, suffix, _uq(urljoin(base_url, target), safe=''), hb, _ct())

    ck = _clearkey_of(headers)
    out, prev_variant = [], False
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            out.append(line)
        elif stripped.startswith('#'):
            if ck and (stripped.startswith('#EXT-X-KEY') or stripped.startswith('#EXT-X-SESSION-KEY')):
                continue                    # the player gets the key from the ClearKey session, not from the playlist
            if stripped.startswith('#EXT-X-STREAM-INF'):
                prev_variant = True
            if 'URI="' in stripped:
                kind = 'hls' if stripped.startswith('#EXT-X-MEDIA') else 'raw'
                suffix = '.m3u8' if kind == 'hls' else '.bin'
                if ck and stripped.startswith('#EXT-X-MAP'):
                    kind, suffix = 'init', '.mp4'
                line = re.sub(r'URI="([^"]+)"', lambda m: 'URI="%s"' % link(kind, m.group(1), suffix), line)
            out.append(line)
        else:
            if prev_variant or '.m3u8' in stripped.split('?')[0].lower():
                out.append(link('hls', stripped, '.m3u8'))
            elif ck:
                out.append(link('raw', stripped, '.m4s'))       # encrypted fragments: passed on untouched
            else:
                out.append(link('seg', stripped, '.ts'))
            prev_variant = False
    return '\n'.join(out) + '\n'


# ---- ClearKey streams (CENC fragmented MP4 behind an HLS playlist) ------------------------------------------------
# The stream address carries `X-Starfleet-License-Type=clearkey` and `X-Starfleet-License-Key=<kid>:<key>` (hex). The relay never sends
# those upstream. It removes the playlist's key lines (a player only understands the DRM systems named there) and puts a ClearKey
# pssh box into each init segment, so the player's own ClearKey session decrypts the stream with the key it was given.
_LIC_TYPE_HDR = 'X-Starfleet-License-Type'
_LIC_KEY_HDR = 'X-Starfleet-License-Key'


def _clearkey_of(headers):
    """(kid_hex, key_hex) when `headers` name a ClearKey licence, else None."""
    if not headers:
        return None
    low = {str(k).lower(): v for k, v in headers.items()}
    if str(low.get(_LIC_TYPE_HDR.lower(), '')).lower() not in ('clearkey', 'org.w3.clearkey'):
        return None
    kid, _, key = str(low.get(_LIC_KEY_HDR.lower(), '')).partition(':')
    kid, key = kid.strip().replace('-', '').lower(), key.strip().lower()
    try:
        if len(bytes.fromhex(kid)) == 16 and len(bytes.fromhex(key)) == 16:
            return kid, key
    except ValueError:
        pass
    return None


def _no_licence_headers(headers):
    return {k: v for k, v in (headers or {}).items() if not str(k).lower().startswith('x-starfleet-license')}


def _pssh_box(system_id_hex, kid_hex):
    kid = bytes.fromhex(kid_hex)
    body = b'\x01\x00\x00\x00' + bytes.fromhex(system_id_hex) + (1).to_bytes(4, 'big') + kid + (0).to_bytes(4, 'big')
    return (len(body) + 8).to_bytes(4, 'big') + b'pssh' + body


def _with_clearkey_pssh(init, kid_hex):
    """The init segment with ClearKey pssh boxes added inside its moov box (unchanged if it has none)."""
    off = 0
    while off + 8 <= len(init):
        size = int.from_bytes(init[off:off + 4], 'big')
        typ = init[off + 4:off + 8]
        if size < 8:
            break
        if typ == b'moov':
            add = _pssh_box('1077efecc0b24d02ace33c1e52e2fb4b', kid_hex) + _pssh_box('e2719d58a985b3c9781ab030af78d30e', kid_hex)
            moov = init[off:off + size] + add
            moov = (len(moov)).to_bytes(4, 'big') + moov[4:]
            return init[:off] + moov + init[off + size:]
        off += size
    return init


def _first_segment(playlist_text, base_url, headers, depth=0):
    """Resolve master -> media playlist -> absolute URL of its first segment."""
    from starfleetscrapers.core import http as _req
    from urllib.parse import urljoin
    lines = [l.strip() for l in playlist_text.splitlines() if l.strip() and not l.startswith('#')]
    if not lines:
        return None
    first = urljoin(base_url, lines[0])
    if 'EXT-X-STREAM-INF' in playlist_text and depth < 2:
        r = _req.get(first, headers=headers, timeout=8)
        return _first_segment(r.text, r.url, headers, depth + 1)
    return first


# Streams from these hosts hide the transport stream in a picture (see _unwrap_segment): they are relayed even when the
# check below could not be made, because a stream played unwrapped cannot be demuxed at all.
_DISGUISED_HOSTS = ('indianservers.st', 'tiktokcdn.com')


def _known_disguised(url):
    low = (url or '').split('|')[0].lower()
    return any(h in low for h in _DISGUISED_HOSTS)


def _get_twice(url, headers, timeout, **kw):
    """One quick retry: the edges answer an occasional request with an error or a stall, which must not decide how a stream is played."""
    from starfleetscrapers.core import http as _req
    try:
        return _req.get(url, headers=headers, timeout=timeout, **kw)
    except Exception:
        return _req.get(url, headers=headers, timeout=timeout, **kw)


def _host(url):
    from urllib.parse import urlparse
    try:
        return urlparse((url or '').split('|')[0]).netloc or '?'
    except Exception:
        return '?'


def _header_gated(headers):
    """True when the stream names a Referer or Origin - the sign of an edge that checks who is asking."""
    return any(k.lower() in ('referer', 'origin') for k in (headers or {}))


# Edges that hand out a short-lived token inside the playlist address (".../secure/<token>/<from>/<to>/<stream>/index.m3u8"): a token
# that is not used for a minute or two is thrown away and the address answers 403 for good. A stream list that was opened a while before
# a link was picked therefore holds dead addresses. The scraper marks such a link with the page it came from (private headers, never
# sent upstream); when the edge turns the playlist away the relay asks that page for a fresh token and carries on with the same stream.
_REMINT_HDR = 'X-SF-Remint'              # the embed / game page the link was resolved from
_REMINT_PAGE_HDR = 'X-SF-Remint-Page'    # '1' when that is a schedule-page link (resolved the long way)
_remint_lock = threading.Lock()
_reminted = {}                           # page -> (fresh stream address or None, time)


def _pop_hint(headers):
    """Take the re-mint hint out of `headers` (in place) and return it."""
    hint = {}
    for k in list(headers or {}):
        if k.lower() in (_REMINT_HDR.lower(), _REMINT_PAGE_HDR.lower()):
            hint[k] = headers.pop(k)
    return hint


def _strip_hint(stream_url):
    """The stream address without the re-mint hint (for a player that gets it straight, not through the relay)."""
    if _REMINT_HDR.lower() not in (stream_url or '').lower():
        return stream_url
    from urllib.parse import quote as _uq
    base, headers = _split_pipe_headers(stream_url)
    _pop_hint(headers)
    return base + ('|' + '&'.join('%s=%s' % (k, _uq(v, safe='')) for k, v in headers.items()) if headers else '')


def _remint(hint):
    """A fresh stream address ('url|Header=..') for the page named in `hint`, or None. One lookup serves everything that asked within
    half a minute (a player opens a playlist several times a second at the start); a failed lookup is not repeated for ten seconds."""
    page = ''
    for k, v in (hint or {}).items():
        if k.lower() == _REMINT_HDR.lower():
            page = v
    if not page:
        return None
    paged = any(k.lower() == _REMINT_PAGE_HDR.lower() and v == '1' for k, v in hint.items())
    with _remint_lock:
        hit = _reminted.get(page)
        if hit and time.time() - hit[1] < (30 if hit[0] else 10):
            return hit[0]
        out = None
        try:
            from starfleetscrapers.sports import sports_starfleet_live as _sl
            out = _sl._resolve_page_link(page) if paged else _sl.resolve_link(page)
        except Exception as e:
            xbmc.log('[Starfleet/LocalProxy] could not get a new token: %s' % e, xbmc.LOGINFO)
        if out and out.startswith('http://127.0.0.1:%d/' % _PORT):
            out = None
        _reminted[page] = (out, time.time())
        if len(_reminted) > 40:
            for k in [k for k, v in _reminted.items() if time.time() - v[1] > 120]:
                _reminted.pop(k, None)
        return out


_TOKEN_PREFIX = re.compile(r'^(https?://[^/]+/secure/[^/]+/)')


def _with_new_token(target, fresh):
    """`target` (a playlist address with an old token) moved onto the token of the fresh stream address `fresh`, or None."""
    m = _TOKEN_PREFIX.match((fresh or '').partition('|')[0])
    if not m or not _TOKEN_PREFIX.match(target):
        return None
    return _TOKEN_PREFIX.sub(m.group(1), target, count=1)


def maybe_wrap_hls(stream_url):
    """Return a relay URL for `stream_url` ('url|Header=..' form) when its media
    segments are disguised TS; otherwise return it unchanged. Never raises."""
    out = _maybe_wrap_hls(stream_url)
    return out if out.startswith('http://127.0.0.1:%d/' % _PORT) else _strip_hint(out)


def _maybe_wrap_hls(stream_url):
    known = _known_disguised(stream_url)
    wrapped = None
    try:
        if _DIRECT_HDR.lower() in stream_url.lower():
            return _strip_direct(stream_url)
        if wants_parallel(stream_url):
            return parallel_url(stream_url)             # a speed-limited file: fetched in parallel parts
        if '.m3u8' not in stream_url.lower():
            return stream_url
        if not _service_reachable():
            xbmc.log('[Starfleet/LocalProxy] relay is not reachable on port %d - playing direct' % _PORT, xbmc.LOGINFO)
            return stream_url
        if stream_url.startswith('http://127.0.0.1:%d/' % _PORT):
            return stream_url                       # already served by this relay
        # Signed one-connection CDNs (the xameleon family behind DaddyLive, see
        # sports_sources._livetv902_resolve_dlstreams: "a signed/session-pinned CDN URL only
        # tolerates ONE real connection") would have that connection spent by this probe.
        # Those streams are known to play directly.
        if 'xameleon' in stream_url.lower():
            return stream_url
        from urllib.parse import quote as _uq
        base, headers = _split_pipe_headers(stream_url)
        hint = _pop_hint(headers)               # rides on the relay address only, never to the edge
        headers.setdefault('User-Agent', _DEFAULT_UA)
        if _clearkey_of(headers):
            # protected stream: always relayed (no probe - its address may only be good once); the licence stays on the address
            # so the player can open its ClearKey session
            lic = {k: v for k, v in headers.items() if k.lower().startswith('x-starfleet-license')}
            xbmc.log('[Starfleet/LocalProxy] %s is a ClearKey stream - relaying' % _host(base), xbmc.LOGINFO)
            return 'http://127.0.0.1:%d/hls/x.m3u8?url=%s&h=%s|%s' % (
                _PORT, _uq(base, safe=''), _enc_headers(headers), '&'.join('%s=%s' % (k, _uq(v, safe='')) for k, v in lic.items()))
        # a stream that names a Referer/Origin is relayed even when the check below cannot be made: played direct it is turned away (403)
        known = known or _header_gated(headers)

        def _relay_of(b, h):
            return 'http://127.0.0.1:%d/hls/x.m3u8?url=%s&h=%s' % (_PORT, _uq(b, safe=''), _enc_headers(dict(h, **hint) if hint else h))

        wrapped = _relay_of(base, headers)
        pl = _get_twice(base, headers, 8)
        if '#EXTM3U' not in pl.text[:200] and pl.status_code == 403 and hint:
            # a link that waited too long in a list: its token is gone. Ask the page it came from for a new one.
            fresh = _remint(hint)
            if fresh:
                nb, nh = _split_pipe_headers(fresh)
                _pop_hint(nh)
                for _k, _v in nh.items():
                    headers.setdefault(_k, _v)
                try:
                    _r = _get_twice(nb, headers, 8)
                except Exception:
                    _r = None
                if _r is not None and '#EXTM3U' in _r.text[:200]:
                    xbmc.log('[Starfleet/LocalProxy] %s: the link had expired - a new one was fetched' % _host(nb), xbmc.LOGINFO)
                    base, pl = nb, _r
                    wrapped = _relay_of(base, headers)
        if '#EXTM3U' not in pl.text[:200] and pl.status_code in (401, 403) and _header_gated(headers):
            # an edge that turns the first request away is asked again the way other players ask (no Origin; Referer only; another agent)
            _alt = dict(headers)
            _alt.pop('Origin', None)
            _only_ref = {k: v for k, v in headers.items() if k.lower() == 'referer'}
            _only_ref['User-Agent'] = _DEFAULT_UA
            for _why, _h in (('no Origin', _alt), ('Referer only', _only_ref)):
                try:
                    _r = _get_twice(base, _h, 8)
                except Exception:
                    continue
                if '#EXTM3U' in _r.text[:200]:
                    xbmc.log('[Starfleet/LocalProxy] %s: playlist answered with %s' % (_host(base), _why), xbmc.LOGINFO)
                    pl, headers = _r, _h
                    wrapped = _relay_of(base, headers)
                    break
        if '#EXTM3U' not in pl.text[:200]:
            xbmc.log('[Starfleet/LocalProxy] %s gave no playlist (status %s, server %s, body %r, sent %s) - %s' % (
                _host(base), pl.status_code, pl.headers.get('Server', '-'), pl.text[:60], sorted(headers), 'relaying anyway' if known else 'playing direct'), xbmc.LOGINFO)
            return wrapped if known else stream_url
        seg = _first_segment(pl.text, pl.url, headers)
        if not seg:
            xbmc.log('[Starfleet/LocalProxy] %s playlist has no segment - %s' % (
                _host(base), 'relaying anyway' if known else 'playing direct'), xbmc.LOGINFO)
            return wrapped if known else stream_url
        if 'tiktokcdn' in seg.lower() or '.image' in seg.lower().split('?')[0]:
            xbmc.log('[Starfleet/LocalProxy] segments are pictures (%s) - relaying' % seg.split('?')[0][-40:], xbmc.LOGINFO)
            return wrapped
        r = _get_twice(seg, headers, 10, stream=True)
        try:
            head = b''
            for chunk in r.iter_content(2048):
                head += chunk
                if len(head) >= 5000:
                    break
        finally:
            r.close()
        if r.status_code != 200 or len(head) < 1000:
            if known:
                xbmc.log('[Starfleet/LocalProxy] segment check gave %s - relaying anyway (known disguised host)' % r.status_code, xbmc.LOGINFO)
                return wrapped
            return stream_url
        off = _find_ts_start(head)
        if not _looks_disguised(head):
            if _header_gated(headers):
                # an edge that wants a Referer/Origin is often one that also turns a phone/box player's own TLS stack away (403);
                # the relay fetches with the add-on's own client, which those edges accept
                xbmc.log('[Starfleet/LocalProxy] segments clean but the host wants a Referer - relaying', xbmc.LOGINFO)
                return wrapped
            xbmc.log('[Starfleet/LocalProxy] segments already clean (ts offset %d) - direct' % off, xbmc.LOGINFO)
            return stream_url
        xbmc.log('[Starfleet/LocalProxy] segments disguised (ts offset %d, %s) - relaying' % (
            off, r.headers.get('Content-Type', '?')), xbmc.LOGINFO)
        return wrapped
    except Exception as e:
        if known and wrapped:
            xbmc.log('[Starfleet/LocalProxy] segment check failed (%s) - relaying anyway (known disguised host)' % e, xbmc.LOGINFO)
            return wrapped
        xbmc.log('[Starfleet/LocalProxy] maybe_wrap_hls skipped: %s' % e, xbmc.LOGINFO)
        return stream_url


# Edges that only serve their playlist with `?t=<token>`: the stream address carries the token's own address in a private header
# (X-SF-Token-Url, never sent upstream); the relay asks for a token when it fetches the playlist and again once half of its
# life is gone, so a long watch keeps working. Only the playlist the player opens carries it, not the variants or segments.
_TOKEN_HDR = 'X-SF-Token-Url'
_DIRECT_HDR = 'X-SF-Direct'            # "play this one as it is" (a single-use address the relay must not open first)
_ptok = {}                             # token address -> (token, renew_at)


def playlist_token(token_url, headers, fresh=False):
    from starfleetscrapers.core import http as _req
    now = time.time()
    hit = _ptok.get(token_url)
    if hit and not fresh and now < hit[1]:
        return hit[0]
    r = _req.get(token_url, headers=headers, timeout=(5, 10))
    r.raise_for_status()
    j = r.json()
    tok = j.get('token') or ''
    if not tok:
        raise ValueError('no playlist token')
    _ptok[token_url] = (tok, now + max(20, float(j.get('ttl') or 120)) * 0.5)
    return tok


def tokenized(url, token):
    from urllib.parse import quote as _uq
    return '%s%st=%s&_=%d' % (url, '&' if '?' in url else '?', _uq(token, safe=''), int(time.time() * 1000))


def build_token_url(piped, token_url):
    """Stream address for a playlist that needs a token: the relay URL when the service runs, else the playlist with a token
    from now (good for a couple of minutes)."""
    from urllib.parse import quote as _uq
    base, headers = _split_pipe_headers(piped)
    headers.setdefault('User-Agent', _DEFAULT_UA)
    if _service_reachable():
        headers[_TOKEN_HDR] = token_url
        return 'http://127.0.0.1:%d/hls/x.m3u8?url=%s&h=%s' % (_PORT, _uq(base, safe=''), _enc_headers(headers))
    try:
        base = tokenized(base, playlist_token(token_url, headers))
    except Exception as e:
        xbmc.log('[Starfleet/LocalProxy] playlist token: %s' % e, xbmc.LOGINFO)
    return base + '|' + '&'.join('%s=%s' % (k, _uq(v, safe='')) for k, v in headers.items())


def _strip_direct(stream_url):
    """The stream address without the "play as it is" marker."""
    from urllib.parse import quote as _uq
    base, headers = _split_pipe_headers(stream_url)
    headers.pop(_DIRECT_HDR, None)
    return base + ('|' + '&'.join('%s=%s' % (k, _uq(v, safe='')) for k, v in headers.items()) if headers else '')


def _serve_hls(handler, kind, target, headers):
    """GET handler for /hls, /seg, /raw."""
    from starfleetscrapers.core import http as _req
    last = None
    up = None
    tok_url = ''
    plain = target
    if kind == 'hls' and _TOKEN_HDR in headers:
        headers = dict(headers)
        tok_url = headers.pop(_TOKEN_HDR)
    stale = False
    headers = dict(headers)
    hint = _pop_hint(headers)              # the page this link came from (see _remint): kept on the links we hand out, not sent upstream
    ck = _clearkey_of(headers)
    if ck:
        headers_full, headers = headers, _no_licence_headers(headers)
    else:
        headers_full = headers
    if hint:
        headers_full = dict(headers_full, **hint)
    reminted = False
    for _attempt in range(3):
        try:
            if tok_url:
                target = tokenized(plain, playlist_token(tok_url, headers, fresh=stale))
                stale = False
            up = _req.get(target, headers=headers, timeout=(5, 15))
            if up.status_code == 403 and hint and kind == 'hls' and not reminted:
                # the token in this playlist address has expired (they last about a minute without use): get a new one from the page
                reminted = True
                fresh = _remint(hint)
                new_target = _with_new_token(target, fresh) if fresh else None
                if new_target:
                    xbmc.log('[Starfleet/LocalProxy] %s: playlist token had expired - using a new one' % _host(target), xbmc.LOGINFO)
                    target = new_target
                    continue
            # a segment or playlist the edge refused or failed on is asked for again (they answer an occasional request with an error)
            if up.status_code >= 400 and _attempt < 2:
                stale = up.status_code == 403
                xbmc.log('[Starfleet/LocalProxy] %s answered %s - trying again' % (kind, up.status_code), xbmc.LOGINFO)
                time.sleep(0.4)
                continue
            break
        except Exception as e:
            last = e
    if up is None:
        xbmc.log('[Starfleet/LocalProxy] %s upstream error: %s' % (kind, last), xbmc.LOGWARNING)
        handler.send_response(502)
        handler.end_headers()
        return
    if up.status_code >= 400:
        try:
            _body = (up.text or '')[:160].replace(chr(10), ' ')
        except Exception:
            _body = '?'
        xbmc.log('[Starfleet/LocalProxy] %s upstream status %s for %s (server %s, body %r, sent %s, url %d chars)' % (
            kind, up.status_code, target.split('?')[0][-60:], up.headers.get('Server', '-'), _body, sorted(headers), len(target)), xbmc.LOGWARNING)
        handler.send_response(up.status_code)
        handler.end_headers()
        return
    body = up.content
    ctype = 'application/octet-stream'
    if kind == 'hls':
        if not up.text.lstrip().startswith('#EXTM3U'):
            handler.send_response(502)
            handler.end_headers()
            return
        body = _rewrite_playlist(up.text, up.url, headers_full).encode('utf-8')
        ctype = 'application/vnd.apple.mpegurl'
    elif kind == 'init':
        body = _with_clearkey_pssh(body, ck[0]) if ck else body
        ctype = 'video/mp4'
    elif kind == 'seg':
        body = _unwrap_segment(body)
        ctype = 'video/mp2t'
    handler.send_response(200)
    handler.send_header('Content-Type', ctype)
    handler.send_header('Content-Length', str(len(body)))
    handler.end_headers()
    try:
        handler.wfile.write(body)
    except Exception:
        pass


_etok = {}                 # (edge, slug) -> (token, renew_at)


def _edge_token(edge, slug, headers):
    """Playlist token of an edge that only serves a playlist with `?t=<token>` (a token lives ~2 minutes, the player asks for a
    new one halfway through). Cached until half its life is gone."""
    import time as _time
    from starfleetscrapers.core import http as _req
    key = (edge, slug)
    hit = _etok.get(key)
    now = _time.time()
    if hit and now < hit[1]:
        return hit[0]
    r = _req.get('%s/api/playlist-token?slug=%s' % (edge, slug), headers=headers, timeout=(5, 10))
    r.raise_for_status()
    j = r.json()
    tok = j.get('token') or ''
    if not tok:
        raise ValueError('no playlist token')
    _etok[key] = (tok, now + max(20, float(j.get('ttl') or 120)) * 0.5)
    return tok


def _serve_etok(handler, q):
    """GET /etok/x.m3u8?edge=..&slug=..&h=..: the edge's media playlist fetched with a fresh token and pointed at this relay."""
    from starfleetscrapers.core import http as _req
    from urllib.parse import quote as _uq
    edge = q.get('edge', [''])[0]
    slug = q.get('slug', [''])[0]
    headers = _dec_headers(q.get('h', [''])[0])
    up = None
    try:
        for _attempt in range(2):
            tok = _edge_token(edge, slug, headers)
            up = _req.get('%s/%s/index.m3u8?t=%s' % (edge, slug, _uq(tok, safe='')), headers=headers, timeout=(5, 12))
            if up.status_code != 403:
                break
            _etok.pop((edge, slug), None)               # refused token: ask for a new one once
    except Exception as e:
        xbmc.log('[Starfleet/LocalProxy] etok upstream error: %s' % e, xbmc.LOGWARNING)
    if up is None or up.status_code >= 400 or not up.text.lstrip().startswith('#EXTM3U'):
        handler.send_response(up.status_code if up is not None and up.status_code >= 400 else 502)
        handler.end_headers()
        return
    body = _rewrite_playlist(up.text, up.url, headers).encode('utf-8')
    handler.send_response(200)
    handler.send_header('Content-Type', 'application/vnd.apple.mpegurl')
    handler.send_header('Content-Length', str(len(body)))
    handler.end_headers()
    try:
        handler.wfile.write(body)
    except Exception:
        pass


def build_etok_url(edge, slug, headers):
    """Relay URL for a live channel on a token edge, or None when the relay service is not running."""
    if not _service_reachable():
        return None
    from urllib.parse import quote as _uq
    return 'http://127.0.0.1:%d/etok/x.m3u8?edge=%s&slug=%s&h=%s' % (_PORT, _uq(edge, safe=''), _uq(slug, safe=''), _enc_headers(headers))


def _serve_tsws(handler, path, q):
    """GET /tsws/master.m3u8 and /tsws/media.m3u8: playlists the site publishes over a websocket (see ws_playlist).
    Every request fetches the current playlist, so the player's normal live refresh keeps working."""
    from urllib.parse import quote as _uq
    from starfleetscrapers.sports import ws_playlist as ws_playlist

    def arg(name):
        return q.get(name, [''])[0]

    hosts = [h for h in arg('hosts').split(',') if h]
    channel, origin = arg('c'), arg('o')
    wspath = arg('p') or '/websocket'
    body = None
    if path.endswith('/master.m3u8'):
        import base64
        import json
        try:
            inf = json.loads(base64.urlsafe_b64decode(arg('inf').encode('ascii') + b'=' * (-len(arg('inf')) % 4)))
        except Exception:
            inf = {}
        import re as _re
        lines = ['#EXTM3U', '#EXT-X-VERSION:3']
        for rend, line in sorted(inf.items(), key=lambda kv: -int((_re.search(r'BANDWIDTH=(\d+)', kv[1]) or [0, 0])[1])):
            lines.append(line)
            lines.append('%s/tsws/media.m3u8?c=%s&hosts=%s&o=%s&p=%s&r=%s%s' % (
                _self_base(), _uq(channel, safe=''), _uq(','.join(hosts), safe=','), _uq(origin, safe=''), _uq(wspath, safe=''),
                _uq(rend, safe=''), _ct()))
        body = '\n'.join(lines) + '\n'
    else:
        try:
            body = ws_playlist.media_playlist(hosts, channel, origin, arg('r'), wspath)
        except Exception as e:
            xbmc.log('[Starfleet/LocalProxy] tsws playlist error: %s' % e, xbmc.LOGWARNING)
            body = None
        if not body:
            handler.send_response(503)
            handler.end_headers()
            return
    data = body.encode('utf-8')
    handler.send_response(200)
    handler.send_header('Content-Type', 'application/vnd.apple.mpegurl')
    handler.send_header('Content-Length', str(len(data)))
    handler.send_header('Cache-Control', 'no-cache')
    handler.end_headers()
    try:
        handler.wfile.write(data)
    except Exception:
        pass


def cast_url(stream_url, lan_ip):
    """The address a casting device can fetch: a relayed stream gets this device's LAN address and the cast token, a playlist that needs
    headers (Referer / Origin) is served through the relay with them, and a plain address is returned as it is (without the player's own
    '|X-SF-Type' tag)."""
    try:
        if not lan_ip:
            return stream_url
        import secrets
        from urllib.parse import quote as _uq
        if not _cast_token[0]:
            _cast_token[0] = secrets.token_hex(8)
        prefix = 'http://127.0.0.1:%d/' % _PORT
        if stream_url.startswith(prefix):
            u = 'http://%s:%d/%s' % (lan_ip, _PORT, stream_url[len(prefix):].split('|')[0])
            return u + ('&' if '?' in u else '?') + 'ct=' + _cast_token[0]
        base, headers = _split_pipe_headers(stream_url)
        real = {k: v for k, v in headers.items() if k.lower() != 'x-sf-type'}
        gated = _header_gated(real) or any(k.lower() == 'user-agent' for k in real)
        is_hls = '.m3u8' in base.lower().split('?')[0] or (headers.get('X-SF-Type') or '').lower() == 'hls'
        if gated and is_hls and _service_reachable():
            real.setdefault('User-Agent', _DEFAULT_UA)
            return 'http://%s:%d/hls/x.m3u8?url=%s&h=%s&ct=%s' % (lan_ip, _PORT, _uq(base, safe=''), _enc_headers(real), _cast_token[0])
        return base
    except Exception:
        return stream_url.split('|')[0]


def wrap_hls_always(stream_url):
    """Relay URL that serves `stream_url` ('url|Header=..') as an .m3u8 through this service, for playlists whose
    address does not end in .m3u8 (the player would otherwise treat them as raw video). Unchanged when the service
    is not running."""
    try:
        if not _service_reachable():
            return stream_url
        from urllib.parse import quote as _uq
        base, headers = _split_pipe_headers(stream_url)
        headers.setdefault('User-Agent', _DEFAULT_UA)
        return 'http://127.0.0.1:%d/hls/x.m3u8?url=%s&h=%s' % (_PORT, _uq(base, safe=''), _enc_headers(headers))
    except Exception:
        return stream_url


def build_tsws_url(channel, hosts, origin, inf, path='/websocket'):
    """Relay URL for a websocket-published live channel, or None when the relay service is not running.
    `inf` maps rendition name -> its '#EXT-X-STREAM-INF:...' line."""
    if not _service_reachable():
        return None
    import base64
    import json
    from urllib.parse import quote as _uq
    blob = base64.urlsafe_b64encode(json.dumps(inf).encode('utf-8')).decode('ascii')
    return 'http://127.0.0.1:%d/tsws/master.m3u8?c=%s&hosts=%s&o=%s&p=%s&inf=%s' % (
        _PORT, _uq(channel, safe=''), _uq(','.join(hosts), safe=','), _uq(origin, safe=''), _uq(path, safe=''), blob)


# ── speed-limited video files ────────────────────────────────────────────────────────────────────────────────────────────────────────
# Some hosts (VOE and the hosts behind it, the Doodstream family) hand a plain MP4 out at a fixed speed per connection (about 0.4 MB/s) while
# the file itself needs more than that to play (a 3 GB "720p" file, with a 20 MB index at its start). Eight connections to the same address,
# each taking its own part of the file, get about five times that, so the relay fetches the file in 1 MB parts, eight at a time, and hands the
# player one ordinary, seekable stream.
_PAR_HOSTS = ('cloudwindow-route.com', 'cloudatacdn.com', 'dood.video')
_PAR_CHUNK = 1 << 20
_PAR_WORKERS = 8
_par_sizes = {}


def wants_parallel(stream_url):
    """True for a plain video file on a host known to limit the speed of one connection."""
    try:
        from urllib.parse import urlparse
        base = stream_url.split('|')[0]
        low = base.lower()
        if not low.startswith('http') or '.m3u8' in low or '.mpd' in low:
            return False
        u = urlparse(base)
        return any(h in (u.hostname or '') for h in _PAR_HOSTS)
    except Exception:
        return False


def parallel_url(stream_url):
    """The relay address that fetches `stream_url` in parallel parts, or the address itself when the relay is not running."""
    try:
        if not _service_reachable():
            return stream_url
        from urllib.parse import quote as _uq
        base, headers = _split_pipe_headers(stream_url)
        headers.setdefault('User-Agent', _DEFAULT_UA)
        return 'http://127.0.0.1:%d/par/x.mp4?url=%s&h=%s' % (_PORT, _uq(base, safe=''), _enc_headers(headers))
    except Exception:
        return stream_url


def _par_fetch(target, headers, a, b):
    from starfleetscrapers.core import http as _req
    last = None
    for attempt in range(3):
        try:
            r = _req.get(target, headers=dict(headers, Range='bytes=%d-%d' % (a, b)), timeout=(10, 40))
            if r.status_code == 206:
                return r.content, r
            last = 'status %s' % r.status_code
        except Exception as e:
            last = str(e)
        time.sleep(0.4 * (attempt + 1))
    raise IOError('part %d-%d: %s' % (a, b, last))


def _par_total(target, headers):
    if target in _par_sizes:
        return _par_sizes[target]
    data, r = _par_fetch(target, headers, 0, 0)
    cr = r.headers.get('Content-Range') or ''
    total = int(cr.rsplit('/', 1)[-1]) if '/' in cr and cr.rsplit('/', 1)[-1].isdigit() else 0
    ctype = r.headers.get('Content-Type') or 'video/mp4'
    _par_sizes[target] = (total, ctype)
    return _par_sizes[target]


def _serve_par(handler, q):
    import re
    from concurrent.futures import ThreadPoolExecutor
    target = q.get('url', [''])[0]
    headers = _dec_headers(q.get('h', [''])[0])
    if not target:
        handler.send_response(400)
        handler.end_headers()
        return
    try:
        total, ctype = _par_total(target, headers)
        if not total:
            raise IOError('no size')
    except Exception as e:
        xbmc.log('[Starfleet/LocalProxy] parallel: %s gave no size (%s)' % (_host(target), e), xbmc.LOGWARNING)
        handler.send_response(502)
        handler.end_headers()
        return
    rng = handler.headers.get('Range') or ''
    start, end = 0, total - 1
    m = re.match(r'bytes=(\d*)-(\d*)', rng)
    if m and (m.group(1) or m.group(2)):
        if m.group(1):
            start = int(m.group(1))
            if m.group(2):
                end = min(int(m.group(2)), total - 1)
        else:                                               # the last N bytes
            start = max(0, total - int(m.group(2)))
    if start >= total or start > end:
        handler.send_response(416)
        handler.send_header('Content-Range', 'bytes */%d' % total)
        handler.end_headers()
        return
    handler.send_response(206 if m else 200)
    handler.send_header('Content-Type', ctype)
    handler.send_header('Accept-Ranges', 'bytes')
    handler.send_header('Content-Length', str(end - start + 1))
    if m:
        handler.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, total))
    handler.end_headers()
    xbmc.log('[Starfleet/LocalProxy] parallel %s %d-%d of %d' % (_host(target), start, end, total), xbmc.LOGINFO)
    parts = [(a, min(a + _PAR_CHUNK - 1, end)) for a in range(start, end + 1, _PAR_CHUNK)]
    pool = ThreadPoolExecutor(_PAR_WORKERS)
    pending = []
    nxt = 0
    sent = 0
    try:
        while nxt < len(parts) and len(pending) < _PAR_WORKERS * 2:
            pending.append(pool.submit(_par_fetch, target, headers, *parts[nxt]))
            nxt += 1
        while pending:
            data, _r = pending.pop(0).result()
            if nxt < len(parts):
                pending.append(pool.submit(_par_fetch, target, headers, *parts[nxt]))
                nxt += 1
            handler.wfile.write(data)
            sent += len(data)
    except Exception as e:
        xbmc.log('[Starfleet/LocalProxy] parallel stopped after %d bytes: %s' % (sent, e), xbmc.LOGINFO)
    finally:
        for f in pending:
            f.cancel()
        pool.shutdown(wait=False)


def _make_handler():
    import http.server
    from starfleetscrapers.core import http as _req

    class _Handler(http.server.BaseHTTPRequestHandler):
        # One response per connection — this only ever serves a whole
        # video or one Range chunk, so HTTP/1.1 keep-alive buys nothing on
        # loopback but does trip a noisy (harmless) ConnectionResetError in
        # socketserver's own next-request read whenever the player
        # disconnects mid-stream (pause/seek/stop) — confirmed live.
        protocol_version = 'HTTP/1.0'

        def log_message(self, fmt, *args):
            pass  # default logs every request to stderr — real errors already go through xbmc.log below

        def end_headers(self):
            # a cast receiver fetches playlists from a web page: it needs the cross-origin header
            self.send_header('Access-Control-Allow-Origin', '*')
            super().end_headers()

        def do_OPTIONS(self):
            self.send_response(204)
            self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Range, Content-Type')
            self.end_headers()

        def do_GET(self):
            from urllib.parse import urlparse, parse_qs, unquote
            parsed = urlparse(self.path)
            q = parse_qs(parsed.query)
            _tl.remote = self.client_address[0] not in ('127.0.0.1', '::1', '::ffff:127.0.0.1')
            _tl.host = self.headers.get('Host') if _tl.remote else None
            if _tl.remote and not (_cast_token[0] and q.get('ct', [''])[0] == _cast_token[0]):
                self.send_response(403)
                self.end_headers()
                return
            if parsed.path.startswith('/tsws/'):
                _serve_tsws(self, parsed.path, q)
                return
            if parsed.path.startswith('/etok/'):
                _serve_etok(self, q)
                return
            if parsed.path.startswith('/par/'):
                _serve_par(self, q)
                return
            for _kind in ('hls', 'seg', 'raw', 'init'):
                if parsed.path.startswith('/%s/' % _kind):
                    _t = q.get('url', [''])[0]
                    if not _t:
                        self.send_response(400)
                        self.end_headers()
                        return
                    _serve_hls(self, _kind, _t, _dec_headers(q.get('h', [''])[0]))
                    return
            target = unquote(q.get('url', [''])[0])
            ua = unquote(q.get('ua', [''])[0])
            if not target:
                self.send_response(400)
                self.end_headers()
                return

            headers = {}
            if ua:
                headers['User-Agent'] = ua
            rng = self.headers.get('Range')
            if rng:
                headers['Range'] = rng

            # Confirmed live 2026-09-05 this relay had NO visibility at all
            # into its own success path — only the upstream-connect
            # exception and the swallowed player-disconnect exception ever
            # logged anything, so a real kodi.log capture of an actual
            # failure (playback hanging ~32s then failing at the demuxer,
            # after the relay itself had already accepted the connection)
            # gave zero signal on whether the relay ever reached upstream,
            # what status it got, or how many bytes it actually served
            # before things went wrong. Logging the request in and the
            # outcome out closes that blind spot for next time.
            xbmc.log('[Starfleet/LocalProxy] GET %s (range=%s)' % (target, rng or '-'), xbmc.LOGINFO)

            # Serialize overlapping requests for the identical target URL —
            # see this module's own docstring (2026-09-05 update) for the
            # live evidence this matters: Kodi's own probe/retry behavior
            # opened up to 6 near-simultaneous connections to this relay
            # for the exact same URL, each spawning its own independent
            # upstream fetch with no coordination, and okcdn.ru cut all but
            # one of them short almost immediately. Only one thread at a
            # time gets to hold an upstream connection to a given target;
            # everyone else queues here first.
            lock = _lock_for(target)
            with lock:
                try:
                    upstream = _req.get(target, headers=headers, stream=True, timeout=20)
                except Exception as e:
                    xbmc.log('[Starfleet/LocalProxy] upstream connect error: %s' % e, xbmc.LOGWARNING)
                    self.send_response(502)
                    self.end_headers()
                    return

                xbmc.log('[Starfleet/LocalProxy] upstream status=%s content-type=%s content-length=%s '
                          'accept-ranges=%s content-range=%s'
                          % (upstream.status_code, upstream.headers.get('Content-Type'),
                             upstream.headers.get('Content-Length'), upstream.headers.get('Accept-Ranges'),
                             upstream.headers.get('Content-Range')), xbmc.LOGINFO)
                sent = 0
                try:
                    self.send_response(upstream.status_code)
                    for h in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges'):
                        v = upstream.headers.get(h)
                        if v:
                            self.send_header(h, v)
                    self.end_headers()
                    it = upstream.iter_content(chunk_size=65536)
                    while True:
                        # Split so the log can tell WHICH side actually
                        # dropped the connection — upstream (okcdn.ru
                        # itself resetting the fetch) vs downstream (Kodi
                        # closing its connection to this relay, e.g. a
                        # real seek/stop/exit) look identical as a bare
                        # exception otherwise, and that distinction is
                        # exactly what's still unresolved after the first
                        # round of logging added here.
                        try:
                            chunk = next(it)
                        except StopIteration:
                            break
                        except Exception as e:
                            xbmc.log('[Starfleet/LocalProxy] UPSTREAM dropped connection after %d bytes: %s'
                                      % (sent, e), xbmc.LOGWARNING)
                            return
                        if chunk:
                            try:
                                self.wfile.write(chunk)
                            except Exception as e:
                                xbmc.log('[Starfleet/LocalProxy] downstream (player) closed connection '
                                          'after %d bytes: %s' % (sent, e), xbmc.LOGINFO)
                                return
                            sent += len(chunk)
                    xbmc.log('[Starfleet/LocalProxy] relay complete, %d bytes served' % sent, xbmc.LOGINFO)
                finally:
                    upstream.close()

    return _Handler


def run_service(monitor):
    """Called once from resources/service.py's main thread at Kodi startup.
    Binds _PORT and serves until Kodi asks the service to stop. If the
    port's already taken (another instance already bound it — services
    only start once per Kodi session, but a same-machine multi-instance or
    unclean-restart edge case could still leave one behind), that's
    treated as "already being served, nothing more to do" rather than a
    fatal error."""
    import http.server
    global _server

    try:
        handler = _make_handler()
        _server = http.server.ThreadingHTTPServer(('0.0.0.0', _PORT), handler)
    except OSError as e:
        xbmc.log('[Starfleet/LocalProxy] port %d unavailable (%s) — assuming '
                  'another instance is already serving it' % (_PORT, e), xbmc.LOGINFO)
        _server = None
    else:
        t = threading.Thread(target=_server.serve_forever, daemon=True)
        t.start()
        xbmc.log('[Starfleet/LocalProxy] service started on 127.0.0.1:%d' % _PORT, xbmc.LOGINFO)

    while not monitor.abortRequested():
        if monitor.waitForAbort(5):
            break

    if _server is not None:
        _server.shutdown()
        xbmc.log('[Starfleet/LocalProxy] service stopped', xbmc.LOGINFO)


def _service_reachable():
    import socket
    try:
        with socket.create_connection(('127.0.0.1', _PORT), timeout=0.4):
            return True
    except OSError:
        return False


def build_relay_url(target_url, user_agent=''):
    """Returns a http://127.0.0.1:<_PORT>/relay?url=...&ua=... URL — see
    module docstring for why this is the real fix and not a workaround.
    Raises RuntimeError if the background service isn't reachable (not
    started yet, e.g. right after this update before a Kodi restart), so
    callers can fall back to their pre-existing direct-URL behavior."""
    if not _service_reachable():
        raise RuntimeError('local proxy service not reachable on port %d '
                            '(Kodi may need a restart after this update)' % _PORT)
    from urllib.parse import quote as _uq
    url = 'http://127.0.0.1:%d/relay?url=%s' % (_PORT, _uq(target_url, safe=''))
    if user_agent:
        url += '&ua=%s' % _uq(user_agent, safe='')
    return url
