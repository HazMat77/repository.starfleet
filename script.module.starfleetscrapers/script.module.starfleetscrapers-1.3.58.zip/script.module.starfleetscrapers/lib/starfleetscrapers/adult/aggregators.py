# -*- coding: utf-8 -*-
"""Porn aggregators for Adult > Scenes.

An aggregator indexes videos that live on other tubes: every tile on its category pages is an
"/out/?l=<token>" link that lands on the origin site's own video page. Starfleet lists the
aggregator's categories and tiles like any other Scenes site; to play one it works out the
origin page (the target URL is inside the token, otherwise the redirect is followed) and plays
that - ResolveURL understands the big origins (XHamster, Eporner, PornHub, XVideos...), and for
the rest the page is read for a direct stream.
"""
import base64
import hashlib
import html as _html
import re
from urllib.parse import urljoin, quote_plus

import xbmc

from starfleetscrapers.adult import streams as _as
from starfleetscrapers.adult import tubes as _at
from starfleetscrapers.core import cache as _cache

# the sites below share one engine (same /out/ redirect, same /new and ?page=N paging)
AGGS = {
    'fuq':        dict(label='Fuq', base='https://www.fuq.com', cat='/category/'),
    'ixxx':       dict(label='iXXX', base='https://www.ixxx.com', cat='/c/'),
    'tubegalore': dict(label='TubeGalore', base='https://www.tubegalore.com', cat='/c/'),
    'porzo':      dict(label='Porzo', base='https://www.porzo.com', cat='/category/'),
    'lobstertube': dict(label='LobsterTube', base='https://www.lobstertube.com', cat='/category/'),
    'dinotube':   dict(label='DinoTube', base='https://www.dinotube.com', cat='/category/'),
    'melonstube': dict(label='MelonsTube', base='https://www.melonstube.com', cat='/category/'),
    'qorno':      dict(label='Qorno', base='https://www.qorno.com', cat='/category/'),
    'tiava':      dict(label='Tiava', base='https://www.tiava.com', cat='/category/'),
    # other aggregator engines
    'iwank':      dict(label='iWank', base='https://iwank.tv', engine='go'),
}

# partner links that only lead to a paid affiliate page - there is nothing to play behind them
_NO_STREAM_HOSTS = ('apclips.com',)
_RE_TILE = re.compile(r'<a[^>]*href="(?P<h>/out/\?l=[^"]+)"[^>]*title="(?P<t>[^"]*)"', re.I)
_RE_IMG = re.compile(r'(?:data-src|data-original|src)="((?:https?:)?//[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"', re.I)


def _title(raw):
    t = _html.unescape(_html.unescape(raw or '')).strip()
    return t


_RE_GO_TILE = re.compile(
    r'<a title="(?P<t>[^"]*)" href="(?P<h>/go\?[^"]+)"[^>]*>\s*<img[^>]*src="(?P<th>[^"]+)"', re.I)
_RE_SAFARI_TILE = re.compile(
    r'href="(?P<h>/video\?id=[^"]+)"[^>]*>\s*<img[^>]*?src=[\'"](?P<th>[^\'"]+)[\'"].*?'
    r'class="vid_title[^"]*">\s*(?P<t>[^<]+?)\s*</a>', re.I | re.S)


def _engine_tiles(site, html):
    cfg = AGGS[site]
    base = cfg['base']
    rx = _RE_GO_TILE if cfg['engine'] == 'go' else _RE_SAFARI_TILE
    films, seen = [], set()
    for m in rx.finditer(html):
        href = _html.unescape(m.group('h'))
        if href in seen:
            continue
        seen.add(href)
        title = _title(m.group('t'))
        th = m.group('th')
        th = ('https:' + th) if th.startswith('//') else th
        slug = hashlib.md5(href.encode('utf-8')).hexdigest()[:16]
        films.append({'slug': slug, 'url': base + href, 'title': _as._clean_title(title), 'title_norm': _as._norm_title(title),
                      'thumb': th, 'source': site, 'streams': []})
    return films


def _tiles(site, html):
    if AGGS[site].get('engine'):
        return _engine_tiles(site, html)
    base = AGGS[site]['base']
    films, seen = [], set()
    for m in _RE_TILE.finditer(html):
        href = _html.unescape(m.group('h'))
        if href in seen:
            continue
        seen.add(href)
        title = _title(m.group('t'))
        if not title:
            continue
        if any(h in _target_from_token(href) for h in _NO_STREAM_HOSTS):
            continue
        img = _RE_IMG.search(html[m.end():m.end() + 1800]) or _RE_IMG.search(html[max(0, m.start() - 900):m.start()])
        thumb = img.group(1) if img else ''
        if thumb.startswith('//'):
            thumb = 'https:' + thumb
        slug = hashlib.md5(href.encode('utf-8')).hexdigest()[:16]
        films.append({'slug': slug, 'url': base + href, 'title': _as._clean_title(title), 'title_norm': _as._norm_title(title),
                      'thumb': thumb, 'source': site, 'streams': []})
    return films


def _list(site, url, ck):
    ck = 'v2_' + ck                   # v2: tiles that lead to an affiliate page are no longer listed
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    try:
        films = _tiles(site, _as._get(url))
        _cache.set(ck, films, 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/%s] list error: %s' % (site, e), xbmc.LOGWARNING)
        return []


def latest(site, page=1):
    eng = AGGS[site].get('engine')
    if eng == 'go':
        return category_movies(site, AGGS[site]['base'] + '/en/0/all/', page)
    if eng == 'safari':
        return category_movies(site, AGGS[site]['base'] + '/search/amateur', page)
    url = AGGS[site]['base'] + '/new' + ('' if page <= 1 else '?page=%d' % page)
    return _list(site, url, 'agg_%s_new_%d' % (site, page))


def categories(site):
    cfg = AGGS[site]
    ck = 'aggcat_%s_v1' % site
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _as._get(cfg['base'] + '/')
    except Exception as e:
        xbmc.log('[Starfleet/%s] categories error: %s' % (site, e), xbmc.LOGWARNING)
        return []
    eng = cfg.get('engine')
    if eng == 'go':
        pat = r'/en/\d+/[a-z0-9-]+/'
    elif eng == 'safari':
        pat = r'/search/[a-z0-9-]+'
    else:
        pat = re.escape(cfg['cat']) + r'[a-z0-9_-]+'
    rx = re.compile(r'<a[^>]+href="(%s)"[^>]*>(.*?)</a>' % pat, re.S | re.I)
    cats, seen = [], set()
    for m in rx.finditer(html):
        path = m.group(1)
        if path in seen:
            continue
        name = re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', m.group(2)))).strip()
        name = re.sub(r'\s*\(?\d[\d.,]*\s*(?:videos?)?\)?$', '', name).strip()
        if not name or len(name) > 40:
            name = path.rsplit('/', 1)[-1].replace('-', ' ').title()
        seen.add(path)
        cats.append({'name': name, 'slug': cfg['base'] + path, 'count': 0, 'thumb': ''})
    if eng == 'safari':
        cats = cats[:150]
    if cats:
        _cache.set(ck, cats, 24 * 3600)
    return cats


def category_movies(site, slug, page=1):
    eng = AGGS[site].get('engine')
    if eng == 'go':
        url = slug if page <= 1 else '%s%d/' % (slug, page)
    else:
        url = slug + ('' if page <= 1 else '?page=%d' % page)
    return _list(site, url, 'aggcat_%s_%s_%d' % (site, re.sub(r'\W+', '_', slug)[-50:], page))


def search(site, query, page=1):
    if AGGS[site].get('engine') == 'safari':
        return category_movies(site, '%s/search/%s' % (AGGS[site]['base'], quote_plus(query)), page)
    if AGGS[site].get('engine') == 'go':
        return []
    url = '%s/search?q=%s' % (AGGS[site]['base'], quote_plus(query)) + ('' if page <= 1 else '&page=%d' % page)
    return _list(site, url, 'aggsearch_%s_%s_%d' % (site, re.sub(r'\W+', '_', query)[:30], page))


# ── play: tile -> origin page -> stream ──────────────────────────────────────

def _target_from_token(out_url):
    """The origin URL sits base64-encoded inside the token."""
    m = re.search(r'l=([^&]+)', out_url)
    if not m:
        return ''
    for b in re.findall(r'(aHR0c[A-Za-z0-9+/_-]{8,}={0,2})', m.group(1)):
        try:
            u = base64.urlsafe_b64decode(b + '=' * (-len(b) % 4)).decode('utf-8', 'ignore')
        except Exception:
            continue
        u = re.split(r'[\x00-\x20"{]', u)[0]
        if u.startswith('http'):
            return u
    return ''


def _safari_origin(url):
    """tubesafari /video?id=... page -> the origin's embed iframe."""
    try:
        html = _as._get(url, timeout=(5, 12))
    except Exception:
        return ''
    for m in re.finditer(r'<iframe[^>]+(?:data-src|src)=["\']([^"\']+)', html):
        u = urljoin(url, _html.unescape(m.group(1)))
        if u.startswith('http') and _at._resolvable(u):
            return u
    return ''


def _origin(out_url):
    """Final origin page of a tile (follows the partner redirect, never the page body)."""
    from starfleetscrapers.core import http as requests
    target = _target_from_token(out_url) or out_url
    try:
        r = requests.get(target, headers={'User-Agent': 'Mozilla/5.0', 'Referer': out_url.split('/out')[0] + '/'},
                         timeout=(5, 10), allow_redirects=True, stream=True)
        final = r.url
        r.close()
        return final
    except Exception:
        return target


def detail(site, slug, url):
    cfg = AGGS[site]
    ck = 'agg_%s_detail_%s' % (site, slug)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        final = _safari_origin(url) if cfg.get('engine') == 'safari' else _origin(url)
        if not final:
            return None
        host = re.sub(r'^www\.', '', final.split('/')[2]) if final.count('/') >= 2 else ''
        streams = []
        if _at._resolvable(final):
            streams.append({'label': '[%s] %s' % (cfg['label'], host), 'url': final})
        else:
            html = _as._get(final, timeout=(5, 12))
            direct, hosts = _at._collect({'label': '%s > %s' % (cfg['label'], host)}, html, final)
            streams = direct or hosts
        film = {'id': '%s_%s' % (site, slug), 'slug': slug, 'title': _as._clean_title(slug), 'title_norm': _as._norm_title(slug),
                'thumb': '', 'description': 'via %s' % host, 'url': url, 'source': site, 'streams': streams}
        if streams:
            _cache.set(ck, film, 6 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/%s] detail error (%s): %s' % (site, slug, e), xbmc.LOGWARNING)
        return None
