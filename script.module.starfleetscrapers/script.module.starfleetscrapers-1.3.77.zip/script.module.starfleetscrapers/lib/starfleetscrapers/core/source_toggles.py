# -*- coding: utf-8 -*-
"""Which individual sources may run.

One list (CATALOG) names every source the viewer can switch, by category: debrid (torrent indexes and release sites), free (movie
and TV sites), anime, sports (groups of stream sites) and live TV. Each has a setting id and a default; a setting the viewer never
touched falls back to the default, so a fresh install runs 3 debrid, every free, 3 anime and 3 sports sources and every live TV list.

    from starfleetscrapers.core import source_toggles as st
    st.on('free', 'vixsrc')            # True / False
    st.catalog()                       # [{'category', 'key', 'label', 'id', 'on'}, ...] for a settings screen
    st.reset('free')                   # back to the recommended ones (all categories when none is named)

The debrid master switch ("use_debrid") is separate: see debrid_gate.
"""
import json
import os

from starfleetscrapers import host as _sfhost

# (category, key, label, setting id, default)
CATALOG = (
    ('debrid', 'torrentio', 'Torrentio', 'src_torrentio', False),
    ('debrid', 'comet', 'Comet', 'src_comet', True),
    ('debrid', 'stremthru', 'StremThru', 'src_stremthru', True),
    ('debrid', 'peerflix', 'Peerflix', 'src_peerflix', False),
    ('debrid', 'torrent9', 'Torrent9 (French)', 'src_torrent9', False),
    ('debrid', 'bitmagnet', 'Bitmagnet', 'src_bitmagnet', False),
    ('debrid', 'zilean', 'Zilean', 'src_zilean', False),
    ('debrid', 'mediafusion', 'MediaFusion', 'src_mediafusion', False),
    ('debrid', 'meteor', 'Meteor', 'src_meteor', True),
    ('debrid', 'torrentsdb', 'TorrentsDB', 'src_torrentsdb', False),
    ('debrid', 'aiostreams', 'AIOStreams', 'src_aiostreams', False),
    ('debrid', 'dmm', 'DMM (Debrid Media Manager, movies only)', 'src_dmm', False),
    ('debrid', 'knaben', 'Knaben', 'src_knaben', False),
    ('debrid', 'tpb', 'The Pirate Bay', 'src_tpb', False),
    ('debrid', 'yts', 'YTS (movies only)', 'src_yts', False),
    ('debrid', 'eztv', 'EZTV (TV only)', 'src_eztv', False),
    ('debrid', '1337x', '1337x', 'src_1337x', False),
    ('debrid', 'bitsearch', 'Bitsearch', 'src_bitsearch', False),
    ('debrid', 'torrentdl', 'TorrentDownloads', 'src_torrentdl', False),
    ('debrid', 'limetorrents', 'LimeTorrents', 'src_limetorrents', False),
    ('debrid', 'magnetdl', 'MagnetDL', 'src_magnetdl', False),
    ('debrid', 'bittorrented', 'BitTorrented', 'src_bittorrented', False),
    ('debrid', 'msearch', 'MSearch', 'src_msearch', False),
    ('debrid', 'tgx', 'TorrentGalaxy', 'src_tgx', False),
    ('debrid', 'zooqle', 'Zooqle', 'src_zooqle', False),
    ('debrid', 'nyaa', 'Nyaa', 'src_nyaa', False),
    ('debrid', 'extto', 'EXT.to', 'src_extto', False),
    ('debrid', 'therarbg', 'TheRarBG', 'src_therarbg', False),
    ('debrid', 'torrentproject2', 'TorrentProject2', 'src_torrentproject2', False),
    ('debrid', 'torrentz2', 'Torrentz2', 'src_torrentz2', False),
    ('debrid', 'kickass2', 'Kickass2', 'src_kickass2', False),
    ('debrid', 'kontrast', 'KONTRAST', 'src_kontrast', False),
    ('debrid', 'torrentfunk', 'TorrentFunk', 'src_torrentfunk', False),
    ('debrid', 'torlock', 'Torlock', 'src_torlock', False),
    ('debrid', 'torrentscsv', 'TorrentsCSV', 'src_torrentscsv', False),
    ('debrid', 'torrentkitty', 'TorrentKitty (DHT index, no seed counts)', 'src_torrentkitty', False),
    ('debrid', 'btdig', 'BitDig', 'src_btdig', False),
    ('debrid', 'animetosho', 'AnimeTosho', 'src_animetosho', False),
    ('debrid', 'tordl', 'Tordl (torrentdownload.info)', 'src_tordl', False),
    ('debrid', 'rutor', 'Rutor (rutor.is)', 'src_rutor', False),
    ('debrid', 'nnmclub', 'NNMClub (nnmclub.to)', 'src_nnmclub', False),
    ('debrid', 'snowfl', 'Snowfl (snowfl.com)', 'src_snowfl', False),
    ('debrid', 'yourbittorrent', 'YourBitTorrent (yourbittorrent.com)', 'src_yourbittorrent', False),
    ('debrid', 'apachetorrent', 'ApacheTorrent (apachetorrent.com)', 'src_apachetorrent', False),
    ('debrid', 'redetorrent', 'RedeTorrent (redetorrent.com)', 'src_redetorrent', False),
    ('debrid', 'torseek', 'Torseek (torseek.org)', 'src_torseek', False),
    ('debrid', 'filemood', 'FileMood (filemood.com)', 'src_filemood', False),
    ('debrid', 'publicdomaintorrents', 'PublicDomainTorrents (publicdomaintorrents.info)', 'src_publicdomaintorrents', False),
    ('debrid', 'cleanbay', 'Cleanbay (cleanbay.netlify.app)', 'src_cleanbay', False),
    ('debrid', 'damag', 'DaMagNet (damag.net) — DHT index', 'src_damag', False),
    ('debrid', 'rarbgdump', 'RARBG Dump (rarbgdump.com)', 'src_rarbgdump', False),
    ('debrid', 'demonoid', 'Demonoid (demonoid.nl) — small curated catalog', 'src_demonoid', False),
    ('debrid', 'bt4g', 'Bt4g', 'src_bt4g', False),
    ('debrid', 'youplex', 'Youplex', 'src_youplex', False),
    ('debrid', 'zeromag', '0Magnet (0mag.net)', 'src_zeromag', False),
    ('debrid', 'ddl_rapidmoviez', 'RapidMoviez (release site)', 'src_ddl_rapidmoviez', False),
    ('debrid', 'ddl_releasebb', 'ReleaseBB (release site)', 'src_ddl_releasebb', False),
    ('debrid', 'ddl_scenerls', 'Scene-RLS (release site)', 'src_ddl_scenerls', False),
    ('debrid', 'ddl_myvideolinks', 'MyVideoLinks (TV) (release site)', 'src_ddl_myvideolinks', False),
    ('debrid', 'ddl_oneddl', '1DDL (release site)', 'src_ddl_oneddl', False),
    ('free', 'vixsrc', 'VixSrc (1080p, several audio languages)', 'fs_vixsrc', True),
    ('free', 'meowtv', 'MeowTV', 'fs_meowtv', True),
    ('free', 'vaplayer', 'VAPlayer', 'fs_vaplayer', True),
    ('free', 'bingr', 'Bingr (direct 1080p)', 'fs_bingr', True),
    ('free', 'cinejoy', 'CineJoy', 'fs_cinejoy', True),
    ('free', 'nexa', 'Nexa (up to 4K)', 'fs_nexa', True),
    ('free', 'vidup', 'VidUp (up to 4K)', 'fs_vidup', True),
    ('free', 'vidcore', 'VidCore', 'fs_vidcore', True),
    ('free', 'vidfast', 'VidFast', 'fs_vidfast', True),
    ('free', 'vidbolt', 'VidBolt', 'fs_vidbolt', True),
    ('free', 'movenerds', 'MovieNerds', 'fs_movenerds', True),
    ('free', 'vidmoly', 'Vidmoly', 'fs_vidmoly', True),
    ('free', 'videasy', 'Videasy (up to 4K)', 'fs_videasy', True),
    ('free', 'rive', 'RiveStream', 'fs_rive', True),
    ('free', 'lookmovie2', 'LookMovie', 'fs_lookmovie2', True),
    ('free', 'cuevana3', 'Cuevana 3 (Spanish)', 'fs_cuevana3', True),
    ('free', 'srstop', 'SRSTop (TV only)', 'fs_srstop', True),
    ('free', 'vavoo', 'Vavoo', 'fs_vavoo', True),
    ('free', 'rarefilmm', 'RareFilmm (classics)', 'fs_rarefilmm', True),
    ('free', 'archive', 'Internet Archive (public-domain films)', 'fs_archive', True),
    ('anime', 'animeparadise', 'AnimeParadise (free)', 'an_animeparadise', True),
    ('anime', 'megaplay', 'MegaPlay (free)', 'an_megaplay', True),
    ('anime', 'anizone', 'AniZone (free, multi-audio)', 'an_anizone', True),
    ('anime', 'donghua', 'Donghua - AnimeXin, Donghua4K (free, Chinese anime)', 'an_donghua', True),
    ('anime', 'nyaa', 'Nyaa (debrid)', 'src_anime_nyaa', True),
    ('anime', 'animetosho', 'AnimeTosho (debrid)', 'src_anime_animetosho', False),
    ('anime', 'subsplease', 'SubsPlease (debrid)', 'src_anime_subsplease', False),
    ('anime', 'tokyotosho', 'Tokyo Toshokan (debrid)', 'src_anime_tokyotosho', False),
    ('anime', 'acgnx', 'AcgnX (debrid)', 'src_anime_acgnx', False),
    ('anime', 'nekobt', 'NekoBT (debrid)', 'src_anime_nekobt', False),
    ('anime', 'tsukihime', 'Tsukihime (debrid)', 'src_anime_tsukihime', False),
    ('sports', 'json', 'Scraped lists - DaddyLive, StreamsEast, CrackStreams, TotalSportek', 'sp_json', True),
    ('sports', 'hubs', 'Match sites - PPV, Footy4U, ReedStreams, CricHD, FreeStreams', 'sp_hubs', True),
    ('sports', 'livesites', 'Live sites - Sportzone, TopSurge, FlyEmbed, SportsOnline', 'sp_livesites', True),
    ('sports', 'ise', 'ISE sports index', 'sp_ise', False),
    ('sports', 'daddylive', 'DaddyLive channels', 'sp_daddylive', False),
    ('sports', 'onhockey', 'OnHockey.tv', 'sp_onhockey', False),
    ('sports', 'meth', 'MethStreams', 'sp_meth', False),
    ('sports', 'sportsurge', 'SportSurge', 'sp_sportsurge', False),
    ('sports', 'buffstreams', 'BuffStreams', 'sp_buffstreams', False),
    ('sports', 'falcon', 'FalconStreams', 'sp_falcon', False),
    ('sports', 'timstreams', 'TimStreams', 'sp_timstreams', False),
    ('sports', 'cdnlive', 'CDN Live', 'sp_cdnlive', False),
    ('sports', 'all24', 'MLB24 / NHL24 / NFL24 / NBA24', 'sp_all24', False),
    ('sports', 'slap', 'SlapStreams', 'sp_slap', False),
    ('sports', 'hoofoot', 'Hoofoot', 'sp_hoofoot', False),
    ('sports', 'tvnow', 'TVNow', 'sp_tvnow', False),
    ('sports', 'livetv', 'LiveTV', 'sp_livetv', False),
    ('live', 'samsung', 'Samsung TV+', 'lv_samsung', True),
    ('live', 'plex', 'Plex', 'lv_plex', True),
    ('live', 'roku', 'Roku Channel', 'lv_roku', True),
    ('live', 'lg', 'LG Channels', 'lv_lg', True),
    ('live', 'pluto', 'Pluto TV', 'lv_pluto', True),
    ('live', 'onhockey', 'OnHockey.tv', 'lv_onhockey', True),
    ('live', 'toutv', 'Tou.tv', 'lv_toutv', True),
    ('live', 'sinclair', 'Sinclair', 'lv_sinclair', True)
)

CATEGORIES = (('debrid', 'Debrid sources'), ('free', 'Free sources'), ('anime', 'Anime sources'), ('sports', 'Sports sources'), ('live', 'Live TV sources'))
_BY = dict(((c[0], c[1]), c) for c in CATALOG)
_VERSION = 2
_migrated = [False]


def _get(sid):
    try:
        return (_sfhost.addon().getSetting(sid) or '').strip().lower()
    except Exception:
        return ''


def setting_id(category, key):
    row = _BY.get((category, key))
    return row[3] if row else ''


def on(category, key):
    """Whether this source may run. An unknown key counts as on (a source added later is not silently dropped)."""
    row = _BY.get((category, key))
    if row is None:
        return True
    if not _migrated[0]:
        migrate()
    v = _get(row[3])
    if v in ('true', 'false'):
        return v == 'true'
    return bool(row[4])


def known(category, key):
    return (category, key) in _BY


def catalog(category=None):
    out = []
    for c in CATALOG:
        if category and c[0] != category:
            continue
        out.append({'category': c[0], 'key': c[1], 'label': c[2], 'id': c[3], 'on': on(c[0], c[1]), 'default': bool(c[4])})
    return out


def catalog_json(category=None):
    return json.dumps({'categories': [{'id': i, 'label': l} for i, l in CATEGORIES], 'sources': catalog(category)})


def reset(category=None):
    """Write the recommended on / off value of every source (of one category, or all) into the settings."""
    n = 0
    try:
        addon = _sfhost.addon()
        for c in CATALOG:
            if category and c[0] != category:
                continue
            addon.setSetting(c[3], 'true' if c[4] else 'false')
            n += 1
    except Exception:
        pass
    return n


def set_on(category, key, value):
    row = _BY.get((category, key))
    if row is None:
        return False
    try:
        _sfhost.addon().setSetting(row[3], 'true' if value else 'false')
        return True
    except Exception:
        return False


def migrate():
    """Once per _VERSION. Version 1: an install that already stores its old source switches gets the recommended set, so the new
    defaults reach everyone. Version 2: every free source is switched on (only the free ones: the viewer's debrid, anime, sports and
    live TV choices are not touched). Later changes by the viewer are never overwritten again."""
    _migrated[0] = True
    try:
        marker = os.path.join(_sfhost.profile(), 'source_defaults.json')
        seen = 0
        try:
            with open(marker, 'r', encoding='utf-8') as fh:
                seen = int((json.load(fh) or {}).get('version', 0))
        except (OSError, ValueError):
            pass
        if seen >= _VERSION:
            return False
        os.makedirs(os.path.dirname(marker), exist_ok=True)
        with open(marker, 'w', encoding='utf-8') as fh:
            json.dump({'version': _VERSION}, fh)
        if seen < 1:
            reset()
            msg = 'Sources set to the recommended ones - change them in Settings > Sources'
        else:
            reset('free')
            msg = 'All free sources are switched on - change them in Settings > Sources'
        try:
            import xbmcgui
            xbmcgui.Dialog().notification('Starfleet', msg, xbmcgui.NOTIFICATION_INFO, 6000)
        except Exception:
            pass
        return True
    except Exception:
        return False
