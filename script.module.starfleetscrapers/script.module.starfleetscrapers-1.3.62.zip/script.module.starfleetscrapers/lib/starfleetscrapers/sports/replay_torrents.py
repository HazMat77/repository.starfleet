# -*- coding: utf-8 -*-
"""
Replay torrents: magnets for finished games and fights, from the torrent sites that actually carry them.

Checked live 2026-11-04 (each site asked with the same sports queries on its own, no debrid involved):
  fights, wrestling, racing  - bitsearch, knaben, tpb, limetorrents, tordl, therarbg, filemood, torrentdownloads, torrentkitty
  NFL                        - torrentdownloads, bitsearch, filemood, limetorrents, tordl (names like NFL.2026-2027.W08.Eagles-Commanders)
  NBA / NHL                  - limetorrents, bitsearch, torrentdownloads (names like "NBA 20261102 PHX @ GSW 1080p60", team CODES not names)
  MLB                        - bitsearch, filemood, torrentdownloads (names like "MLB 2026.10.12 - NLCS - Los Angeles Dodgers ...")
The sites search literally, so each sport gets the query shape its releases are named with, and what comes back is
kept only when the title names both sides (and, where the release states a date, the right day).
"""
import re
import datetime
import xbmc
from concurrent.futures import ThreadPoolExecutor, wait

# the sites worth asking for sports (the rest returned nothing for any sports query)
_SOURCES = ('bitsearch', 'knaben', 'tpb', 'limetorrents', 'tordl', 'therarbg', 'filemood', 'torrentdownloads',
            'torrentkitty', 'torrentfunk', 'torrentscsv', 'youplex')

_NBA = {
    'atlanta hawks': 'ATL', 'boston celtics': 'BOS', 'brooklyn nets': 'BKN', 'charlotte hornets': 'CHA', 'chicago bulls': 'CHI',
    'cleveland cavaliers': 'CLE', 'dallas mavericks': 'DAL', 'denver nuggets': 'DEN', 'detroit pistons': 'DET',
    'golden state warriors': 'GSW', 'houston rockets': 'HOU', 'indiana pacers': 'IND', 'la clippers': 'LAC',
    'los angeles clippers': 'LAC', 'los angeles lakers': 'LAL', 'la lakers': 'LAL', 'memphis grizzlies': 'MEM',
    'miami heat': 'MIA', 'milwaukee bucks': 'MIL', 'minnesota timberwolves': 'MIN', 'new orleans pelicans': 'NOP',
    'new york knicks': 'NYK', 'oklahoma city thunder': 'OKC', 'orlando magic': 'ORL', 'philadelphia 76ers': 'PHI',
    'phoenix suns': 'PHX', 'portland trail blazers': 'POR', 'sacramento kings': 'SAC', 'san antonio spurs': 'SAS',
    'toronto raptors': 'TOR', 'utah jazz': 'UTA', 'washington wizards': 'WAS',
}
_NHL = {
    'anaheim ducks': 'ANA', 'boston bruins': 'BOS', 'buffalo sabres': 'BUF', 'calgary flames': 'CGY', 'carolina hurricanes': 'CAR',
    'chicago blackhawks': 'CHI', 'colorado avalanche': 'COL', 'columbus blue jackets': 'CBJ', 'dallas stars': 'DAL',
    'detroit red wings': 'DET', 'edmonton oilers': 'EDM', 'florida panthers': 'FLA', 'los angeles kings': 'LAK',
    'minnesota wild': 'MIN', 'montreal canadiens': 'MTL', 'nashville predators': 'NSH', 'new jersey devils': 'NJD',
    'new york islanders': 'NYI', 'new york rangers': 'NYR', 'ottawa senators': 'OTT', 'philadelphia flyers': 'PHI',
    'pittsburgh penguins': 'PIT', 'san jose sharks': 'SJS', 'seattle kraken': 'SEA', 'st. louis blues': 'STL',
    'st louis blues': 'STL', 'tampa bay lightning': 'TBL', 'toronto maple leafs': 'TOR', 'utah mammoth': 'UTA',
    'utah hockey club': 'UTA', 'vancouver canucks': 'VAN', 'vegas golden knights': 'VGK', 'washington capitals': 'WSH',
    'winnipeg jets': 'WPG',
}
_TWO_WORD_NICK = ('white sox', 'red sox', 'blue jays', 'trail blazers', 'maple leafs', 'red wings', 'blue jackets',
                  'golden knights', 'golden state')
_LEAGUE = {'nfl': 'NFL', 'nba': 'NBA', 'nhl': 'NHL', 'mlb': 'MLB'}
_SPLIT = re.compile(r'\s+(?:vs\.?|v\.?|@|at)\s+', re.I)


def _teams(title):
    """'Chicago Bears vs. Seattle Seahawks - Full Game Replay - NFL ...' -> ('Chicago Bears', 'Seattle Seahawks') or None"""
    head = re.split(r'\s+[-–—]\s+', title or '', maxsplit=1)[0]
    parts = _SPLIT.split(head)
    if len(parts) != 2 or not parts[0].strip() or not parts[1].strip():
        return None
    return parts[0].strip(), parts[1].strip()


def _nick(team):
    t = re.sub(r'[^a-z0-9. ]', '', team.lower()).strip()
    for n in _TWO_WORD_NICK:
        if t.endswith(n):
            return n if n != 'golden state' else 'warriors'
    return t.split()[-1] if t else ''


def _code(team, table):
    t = re.sub(r'\s+', ' ', team.lower().replace('é', 'e')).strip()
    if t in table:
        return table[t]
    for k, v in table.items():
        if k.endswith(' ' + _nick(team)) or k.split()[-1] == _nick(team):
            return v
    return ''


def _date_forms(date_key):
    try:
        d = datetime.date.fromisoformat(date_key)
    except Exception:
        return set()
    forms = set()
    for dd in (d - datetime.timedelta(days=1), d, d + datetime.timedelta(days=1)):   # a game's file is dated by local night
        forms.update((dd.strftime('%Y%m%d'), dd.strftime('%Y-%m-%d'), dd.strftime('%Y.%m.%d'), dd.strftime('%Y %m %d'),
                      dd.strftime('%Y_%m_%d')))
    return forms


_RE_ANY_DATE = re.compile(r'(?<!\d)(20\d{2})[-_. ]?([01]\d)[-_. ]?([0-3]\d)(?!\d)')


def _date_ok(text, date_key):
    """True unless the release names a date that is not the game's day (or a day either side)."""
    found = _RE_ANY_DATE.findall(text)
    if not found:
        return True
    ok = _date_forms(date_key)
    return any(('%s%s%s' % f) in ok or ('%s-%s-%s' % f) in ok for f in found)


def _norm(text):
    return re.sub(r'[^a-z0-9@ ]+', ' ', (text or '').lower().replace('&amp;', '&'))


def _queries(sport, event):
    title = event.get('title', '')
    league = _LEAGUE.get(sport)
    tm = _teams(title) if league else None
    if not tm:
        return [], None
    a, b = tm
    if sport in ('nba', 'nhl'):
        table = _NBA if sport == 'nba' else _NHL
        ca, cb = _code(a, table), _code(b, table)
        if not (ca and cb):
            return [], None
        qs = ['%s %s@%s' % (league, ca, cb), '%s %s@%s' % (league, cb, ca)]
        return qs, ('codes', (ca, cb), (_nick(a), _nick(b)))
    na, nb = _nick(a), _nick(b)
    qs = ['%s %s %s' % (league, na, nb), '%s %s %s' % (league, nb, na)]
    return qs, ('names', (na, nb), (na, nb))


def _season_start(date_key):
    try:
        d = datetime.date.fromisoformat(date_key)
    except Exception:
        return 0
    return d.year if d.month >= 6 else d.year - 1


def _nfl_week(date_key):
    """Regular-season week number of a game day (the season opens the Thursday after Labor Day); 0 when unknown."""
    try:
        d = datetime.date.fromisoformat(date_key)
    except Exception:
        return 0
    y = _season_start(date_key)
    labor = datetime.date(y, 9, 1)
    while labor.weekday() != 0:
        labor += datetime.timedelta(days=1)
    kickoff = labor + datetime.timedelta(days=3)
    days = (d - kickoff).days
    return days // 7 + 1 if days >= 0 else 0


def _relevant(sport, event, spec, title):
    t = _norm(title)
    kind, codes, nicks = spec
    toks = set(t.replace('@', ' ').split())
    has_nicks = all(n in t for n in nicks)
    has_codes = kind == 'codes' and all(c.lower() in toks for c in codes)
    if not (has_nicks or has_codes):
        return False
    if sport == 'nfl':
        m = re.search(r'(20\d{2})\D{1,3}(20\d{2})', title)
        if m and int(m.group(1)) != _season_start(event.get('date_key', '')):
            return False
        w = re.search(r'(?<![A-Za-z0-9])W(\d{1,2})(?![0-9])', title)
        wk = _nfl_week(event.get('date_key', ''))
        if w and wk and int(w.group(1)) != wk:
            return False
        return bool(m or str(event.get('date_key', '')[:4]) in title)
    if not _date_ok(title, event.get('date_key', '')):
        return False
    # without a date in the name only a 2026-style year keeps last season's game out
    if not _RE_ANY_DATE.search(title):
        return event.get('date_key', '')[:4] in title
    return True


def _ask(name, query):
    from starfleetscrapers.debrid import torrent_sources as T
    fn = getattr(T, 'search_' + name, None)
    if not fn:
        return []
    try:
        return fn(query, limit=8) or []
    except TypeError:
        try:
            return fn(query) or []
        except Exception:
            return []
    except Exception as e:
        xbmc.log('[Starfleet/ReplayTorrents] %s %r: %s' % (name, query, e), xbmc.LOGINFO)
        return []


def sources(sport, event, limit=12, timeout=22):
    """Playable-with-debrid magnets for a team-sport game: [{'label', 'url', 'magnet'}] best-seeded first."""
    if sport not in _LEAGUE:
        return []
    try:
        from starfleetscrapers.core import debrid_gate as _gate
        if not _gate.torrents_allowed():
            return []
    except Exception:
        pass
    queries, spec = _queries(sport, event)
    if not queries:
        return []
    pool = ThreadPoolExecutor(max_workers=16)
    futs = [pool.submit(_ask, n, q) for n in _SOURCES for q in queries]
    done, _pending = wait(futs, timeout=timeout)
    pool.shutdown(wait=False)
    seen, out = set(), []
    for f in done:
        try:
            res = f.result()
        except Exception:
            continue
        for r in res:
            magnet = r.get('magnet') or ''
            name = r.get('title') or r.get('name') or ''
            if not magnet or not name or not _relevant(sport, event, spec, name):
                continue
            key = (r.get('info_hash') or magnet.split('btih:')[-1][:40]).lower()
            if key in seen:
                continue
            seen.add(key)
            out.append((int(r.get('seeds') or 0), name, r, magnet))
    out.sort(key=lambda x: x[0], reverse=True)
    res = []
    for seeds, name, r, magnet in out[:limit]:
        clean = re.sub(r'^\[[^\]]+\]\s*', '', name)[:48]
        res.append({'label': '%s - %s [%s, %s seeds]' % (r.get('source') or 'Torrent', clean, r.get('quality') or '?', seeds),
                    'url': magnet, 'magnet': magnet})
    return res
