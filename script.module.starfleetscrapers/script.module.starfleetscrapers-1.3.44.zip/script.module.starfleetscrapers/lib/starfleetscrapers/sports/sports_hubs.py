# -*- coding: utf-8 -*-
"""Event hubs for live sports: sites that publish one JSON schedule (or one page per game) with the player frames of every
game. Nothing is resolved while the lists are drawn; when a game is opened `streams_by_title(sport_slug, title)` finds that
game in every hub (cached 10 min), and resolves the player frames of the best match to playable addresses with Starfleet
Resolver.

Hubs
    ppv    ppv.st JSON (the same feed also drives sportontv.click)   one frame per quality
    reed   reedstreams.to JSON                                       one frame per quality
    crich  crichd.at pages                                           one frame per game page (cricket)

TimStreams keeps its own code in sports_sources (_tim_*); its 24/7 channels live in live_sources.
"""
import re
import time
from concurrent.futures import ThreadPoolExecutor, wait as _wait
from urllib.parse import urljoin

import xbmc

from starfleetscrapers import host as _sfhost
from starfleetscrapers.core import http as requests
from starfleetscrapers.core import cache as _cache

_cache.init(_sfhost.profile() + '/cache.db')

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
_TIMEOUT = 9
_EVENTS_TTL = 10 * 60


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/SportsHubs] %s' % msg, level)


def _get(url, referer=None, timeout=_TIMEOUT):
    h = {'User-Agent': UA, 'Accept': '*/*'}
    if referer:
        h['Referer'] = referer
    r = requests.get(url, headers=h, timeout=timeout)
    r.raise_for_status()
    return r


# ── sport names -> Starfleet sport slugs ─────────────────────────────────────

_RE_F1 = re.compile(r'\bf1\b|formula\s*(?:1|one)', re.I)
_RE_MOTOGP = re.compile(r'moto\s*gp', re.I)
_RE_WWE = re.compile(r'\bwwe\b|wrestl|\baew\b', re.I)
_RE_BOX = re.compile(r'box', re.I)
_RE_NCAA = re.compile(r'ncaa|college|cfb', re.I)
_RE_WNBA = re.compile(r'wnba', re.I)


def slug_for(category, tag='', title=''):
    """Starfleet sport slug for a hub's category / tag / title, '' when it is not a sport the lists know."""
    c = (category or '').lower().strip()
    blob = '%s %s %s' % (c, tag or '', title or '')
    if c in ('football', 'soccer', 'futbol', 'pilkanozna'):
        return 'soccer'
    if c in ('american football', 'american-football', 'americanfootball', 'nfl'):
        return 'cfb' if _RE_NCAA.search('%s %s' % (tag or '', title or '')) else 'nfl'
    if c in ('basketball', 'koszykowka', 'nba'):
        return 'wnba' if _RE_WNBA.search('%s %s' % (tag or '', title or '')) else 'nba'
    if c in ('ice hockey', 'hockey', 'hokej', 'nhl'):
        return 'nhl'
    if c in ('baseball', 'mlb'):
        return 'mlb'
    if c in ('motorsports', 'motorsport', 'motor-sports', 'motor sports', 'racing'):
        if _RE_F1.search(blob):
            return 'f1'
        if _RE_MOTOGP.search(blob):
            return 'motogp'
        return 'motorsports'
    if c in ('combat sports', 'fighting', 'fight', 'mma', 'ufc', 'boxing', 'wrestling'):
        if _RE_WWE.search(blob):
            return 'wwe'
        if _RE_BOX.search(blob) or c == 'boxing':
            return 'boxing'
        return 'ufc'
    if c in ('tennis', 'golf', 'cricket', 'rugby', 'darts', 'krykiet'):
        return 'cricket' if c == 'krykiet' else c
    if c == 'australian football':
        return 'afl'
    return ''


def _quality_of(text):
    t = (text or '').upper()
    if 'FHD' in t or 'UHD' in t or '4K' in t:
        return 'FHD'
    if t.startswith('HD') or ' HD' in t or '|HD' in t.replace(' ', ''):
        return 'HD'
    if t.startswith('SD') or ' SD' in t or '540' in t:
        return 'SD'
    return ''


# ── hubs: each returns [{'slug','title','start','links':[(label, url)]}] ─────

def _ppv_events():
    out = []
    data = _get('https://api.ppv.st/api/streams', referer='https://ppv.st/').json()
    for cat in data.get('streams') or []:
        for s in cat.get('streams') or []:
            if s.get('always_live'):
                continue          # 24/7 channels belong to Live TV (live_hubs)
            title = (s.get('name') or '').strip()
            slug = slug_for(s.get('category_name') or cat.get('category'), s.get('tag'), title)
            links = []
            if s.get('iframe'):
                links.append((s.get('source_tag') or 'HD', s['iframe']))
            for sub in s.get('substreams') or []:
                if sub.get('iframe'):
                    links.append((sub.get('source_tag') or 'SD', sub['iframe']))
            if title and slug and links:
                out.append({'slug': slug, 'title': title, 'start': int(s.get('starts_at') or 0), 'links': links})
    return out


def _reed_events():
    out = []
    for m in requests.get('https://api.reedstreams.link/api/matches', headers={'User-Agent': UA}, timeout=_TIMEOUT).json() or []:
        teams = m.get('teams') or {}
        home = ((teams.get('home') or {}).get('name') or '').strip()
        away = ((teams.get('away') or {}).get('name') or '').strip()
        title = (m.get('title') or ('%s vs %s' % (home, away) if home and away else '')).strip()
        slug = slug_for(m.get('category'), '%s %s' % (m.get('tag') or '', m.get('league_name') or ''), title)
        links = [(s.get('name') or 'HD', s['embedUrl']) for s in (m.get('sources') or []) if s.get('embedUrl')]
        if title and slug and links:
            out.append({'slug': slug, 'title': title, 'start': int((m.get('date') or 0) / 1000), 'links': links})
    return out


_RE_CRICH_EVENT = re.compile(r'href="(/events/[a-z0-9-]+)"')
_RE_CRICH_FRAME = re.compile(r'src=(https?://[^"&\s<]+/embed/[^"&\s<]+)')


def _crich_events():
    base = 'https://crichd.at'
    home = _get(base + '/', referer=base + '/').text
    paths = sorted(set(_RE_CRICH_EVENT.findall(home)))[:14]

    def one(path):
        try:
            page = _get(base + path, referer=base + '/').text
        except Exception:
            return None
        frames = []
        for u in _RE_CRICH_FRAME.findall(page):
            if u not in [f[1] for f in frames]:
                frames.append(('HD', u))
        if not frames:
            return None
        return {'slug': 'cricket', 'title': path.rsplit('/', 1)[-1].replace('-', ' '), 'start': 0, 'links': frames}

    with ThreadPoolExecutor(max_workers=6) as ex:
        return [e for e in ex.map(one, paths) if e]


# code -> (label, fetcher, referer used to open the frames)
HUBS = {
    'ppv':   ('PPV', _ppv_events, 'https://ppv.st/'),
    'reed':  ('ReedStreams', _reed_events, 'https://reedstreams.to/'),
    'crich': ('CricHD', _crich_events, 'https://crichd.at/'),
}


def _hub_events(code):
    """Cached event list of one hub; a hub that failed outright is left alone for 20 minutes."""
    key = 'hubs_events_%s_v1' % code
    cached = _cache.get(key)
    if cached is not None:
        return cached
    if _cache.get('hubs_dead_%s' % code):
        return []
    try:
        events = HUBS[code][1]()
    except Exception as e:
        _log('%s: %s' % (code, str(e)[:100]), xbmc.LOGWARNING)
        _cache.set('hubs_dead_%s' % code, True, 20 * 60)
        return []
    _cache.set(key, events, _EVENTS_TTL)
    return events


def _score(a, b):
    from starfleetscrapers.sports.sports_sources import _title_score
    return _title_score(a, b)


def _resolve(url, referer):
    try:
        import starfleetresolve
        return starfleetresolve.resolve(url, referer=referer, debrid_links=False)
    except Exception as e:
        _log('resolve %s: %s' % (url[:60], str(e)[:80]), xbmc.LOGINFO)
        return None


def _best_event(code, sport_slug, event_title):
    best, best_score = None, 0
    for ev in _hub_events(code):
        if ev['slug'] != sport_slug:
            continue
        sc = _score(event_title, ev['title'])
        if sc > best_score:
            best, best_score = ev, sc
    return best if best_score >= 2 else None


def _hub_streams(code, sport_slug, event_title, per_hub=4, budget=14.0):
    label, _fetch, referer = HUBS[code]
    ev = _best_event(code, sport_slug, event_title)
    if not ev:
        return []
    if ev['start'] and ev['start'] - time.time() > 30 * 60:
        return []         # frames only answer once the game is near: offering them earlier gives dead links
    out = []
    ex = ThreadPoolExecutor(max_workers=min(len(ev['links']), 6))
    try:
        futs = [(lbl, ex.submit(_resolve, url, referer)) for lbl, url in ev['links'][:8]]
        deadline = time.time() + budget
        for lbl, fut in futs:
            if len(out) >= per_hub:
                break
            try:
                url = fut.result(timeout=max(0.5, deadline - time.time()))
            except Exception:
                url = None
            if url:
                out.append({'label': '%s %s' % (label, lbl) if lbl else label, 'url': url, 'quality': _quality_of(lbl),
                            'language': '', 'source': label})
    finally:
        ex.shutdown(wait=False)
    return out


def streams_by_title(sport_slug, event_title):
    """Playable streams for one game from every hub that lists it (hubs are asked side by side)."""
    if not (sport_slug and event_title):
        return []
    out = []
    ex = ThreadPoolExecutor(max_workers=len(HUBS))
    try:
        futs = [ex.submit(_hub_streams, code, sport_slug, event_title) for code in HUBS]
        done, _pending = _wait(futs, timeout=18.0)
        for f in done:
            try:
                out += f.result()
            except Exception as e:
                _log('hub: %s' % str(e)[:80], xbmc.LOGINFO)
    finally:
        ex.shutdown(wait=False)
    return out


def warm():
    """Fetch every hub's event list now (used by the background warm-up)."""
    for code in HUBS:
        _hub_events(code)
