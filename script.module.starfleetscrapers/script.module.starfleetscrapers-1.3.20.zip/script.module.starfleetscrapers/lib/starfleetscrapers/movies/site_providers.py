# -*- coding: utf-8 -*-
"""
movies/site_providers.py

Streaming sites that are only a front end for a small set of players. Each entry here reads the site's own backend (the same
request its web page makes) and returns direct HLS playlists, so no browser or script engine is needed:

  VixSrc     vixsrc.to (also the player behind StreamingUnity): /api/movie/<tmdb> or /api/tv/<tmdb>/<s>/<e> gives the embed page,
             whose `window.masterPlaylist` carries the signed master playlist (AES-128 HLS, 1080p, several audio languages).
  MovieNerds api.movenerds.space/api/stream, the backend of movienerds.site and cineruv.website (it carries VidRock, VidZee,
             VidSrc and CineJoy streams). Its own proxy refuses other sites, so the underlying CDN address and the headers it names
             are played directly.

Every link is checked (the playlist answers and starts with #EXTM3U) before it is handed back, and every call is bounded in time.
All are keyed on the TMDB id. Nothing here returns a page address: Kodi cannot play a page.
"""
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import parse_qs, quote, unquote, urlparse

import xbmc

try:
    import requests as _req
except ImportError:
    _req = None

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/126.0.0.0 Safari/537.36')


def _log(msg):
    xbmc.log('[Starfleet/Sites] %s' % msg, xbmc.LOGINFO)


def _pipe(url, headers):
    """url|Referer=..&Origin=..&User-Agent=.. (Kodi's convention for stream headers)."""
    h = dict(headers or {})
    h.setdefault('User-Agent', _UA)
    return '%s|%s' % (url, '&'.join('%s=%s' % (k, quote(str(v), safe='')) for k, v in h.items()))


def _alive(url, headers, timeout=6):
    """The playlist answers 200 and really is one. Only the playlist is fetched (signed segments tolerate few requests)."""
    try:
        h = dict(headers or {})
        h.setdefault('User-Agent', _UA)
        r = _req.get(url, headers=h, timeout=timeout, stream=True)
        try:
            head = next(r.iter_content(512), b'')
        finally:
            r.close()
        return r.status_code < 400 and head[:7] == b'#EXTM3U'
    except Exception:
        return False


def _quality(text):
    m = re.search(r'(2160|4k|1440|1080|720|480|360)', (text or '').lower())
    if not m:
        return ''
    return '4K' if m.group(1) in ('2160', '4k') else m.group(1) + 'p'


# ── VixSrc ───────────────────────────────────────────────────────────────────

def vixsrc(tmdb_id, media_type, season=None, episode=None, **_):
    path = ('movie/%s' % tmdb_id) if media_type == 'movie' else ('tv/%s/%s/%s' % (tmdb_id, season or 1, episode or 1))
    h = {'User-Agent': _UA, 'Referer': 'https://vixsrc.to/'}
    src = _req.get('https://vixsrc.to/api/' + path, headers=h, timeout=8).json().get('src')
    if not src:
        return []
    page = _req.get('https://vixsrc.to' + src, headers=h, timeout=8).text
    tok = re.search(r"'token':\s*'([^']+)'", page)
    exp = re.search(r"'expires':\s*'([^']+)'", page)
    base = re.search(r"url:\s*'(https://[^']+/playlist/\d+)'", page)
    if not (tok and exp and base):
        return []
    fhd = 'canPlayFHD = true' in page
    url = '%s?token=%s&expires=%s%s&lang=en' % (base.group(1), tok.group(1), exp.group(1), '&h=1' if fhd else '')
    if not _alive(url, h):
        return []
    return [{'label': 'VixSrc [%s, multi-audio]' % ('1080p' if fhd else '720p'), 'url': _pipe(url, {'Referer': 'https://vixsrc.to/'})}]


# ── MovieNerds (movienerds.site, cineruv.website) ────────────────────────────

def _movenerds_item(s):
    u = s.get('url') or ''
    q = parse_qs(urlparse(u).query)
    raw = (q.get('url') or [''])[0]
    if not raw.startswith('http'):
        return None
    try:
        hd = json.loads((q.get('headers') or ['{}'])[0])
    except ValueError:
        hd = s.get('headers') or {}
    return raw, {k: v for k, v in (hd or {}).items() if k.lower() in ('referer', 'origin', 'user-agent')}


def movenerds(tmdb_id, media_type, season=None, episode=None, **_):
    qs = 'tmdbId=%s&type=%s' % (tmdb_id, 'movie' if media_type == 'movie' else 'tv')
    if media_type != 'movie':
        qs += '&season=%s&episode=%s' % (season or 1, episode or 1)
    d = _req.get('https://api.movenerds.space/api/stream?' + qs, headers={'User-Agent': _UA}, timeout=25).json()
    cands = []
    for s in d.get('primarySources') or []:
        if (s.get('language') or 'en').lower() not in ('en', 'english'):
            continue
        it = _movenerds_item(s)
        if it:
            cands.append((s, it))
    out = []
    with ThreadPoolExecutor(max_workers=max(1, min(len(cands), 8))) as pool:
        ok = list(pool.map(lambda c: _alive(c[1][0], c[1][1]), cands))
    for (s, (raw, hd)), good in zip(cands, ok):
        if good:
            name = re.sub(r'\s*\(.*', '', (s.get('name') or '').replace('�', '-')).strip() or s.get('providerName') or 'stream'
            out.append({'label': 'MovieNerds - %s %s' % (name, _quality(s.get('quality') or s.get('name'))), 'url': _pipe(raw, hd)})
    return out


PROVIDERS = (('vixsrc', vixsrc), ('movenerds', movenerds))


def search_sites(tmdb_id, media_type='movie', season=None, episode=None, budget=14):
    """Every provider in parallel; whatever answers inside `budget` seconds. [{'label', 'url'}]."""
    if not _req or not tmdb_id or media_type not in ('movie', 'tv'):
        return []
    out = []
    pool = ThreadPoolExecutor(max_workers=len(PROVIDERS))
    try:
        futs = {pool.submit(fn, tmdb_id, media_type, season, episode): name for name, fn in PROVIDERS}
        try:
            for f in as_completed(futs, timeout=budget):
                try:
                    out.extend(f.result() or [])
                except Exception as e:
                    _log('%s: %s' % (futs[f], str(e)[:100]))
        except Exception:
            pass
    finally:
        pool.shutdown(wait=False)
    seen, uniq = set(), []
    for it in out:
        key = it['url'].split('|', 1)[0].split('?', 1)[0]
        if key not in seen:
            seen.add(key)
            uniq.append(it)
    _log('%d link(s) for tmdb %s' % (len(uniq), tmdb_id))
    return uniq
