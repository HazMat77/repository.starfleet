# -*- coding: utf-8 -*-
"""Adult live-TV directories, resolved at play time.

Five sites, three player technologies (all confirmed live 2026-09-25):

* eroteve.com, okteve.com, okporntv.com - WordPress channel pages that iframe a
  shared "xplay" player page. The page carries `var streams = [...]` whose URLs
  are AES-256-GCM encrypted ("#S" + 16 hex HMAC + base64url(iv16 + tag16 + data)),
  with both keys printed in the same page (`window._xpc = {k1, k2}`). The key is
  sha256(k1). The decrypted JSON holds a short-lived (1h) proxy .m3u8; entries of
  type "livecams" are cam embeds with no playlist and are skipped.
* adult-tv-channels.com - the channel page iframes /tv/<name>.php, whose
  `signedUrl` is an array of char codes XORed with a single key.
* adult-tv-channels.click - `playerConfig` either names a direct playlist or an
  API: POST <apiUrl>/<endpoint> returns {"fileUrl": base64(reversed(url))}. The
  `sourceUrl` in that config is only a placeholder, so it is not used for API
  channels.

Every playlist URL is token/IP bound and expires, so channels carry the *page*
they come from and are resolved when played, never cached as stream URLs.
"""

import base64
import hashlib
import hmac
import html as _html
import json
import re
import threading
import time
import unicodedata

import requests
import xbmc

from starfleetscrapers.core import cache as _cache

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
_TIMEOUT = 12

_XPLAY_SITES = (
    # (label, base, listing paths, channel-link pattern)
    ('EroTeVe', 'https://eroteve.com', ('/', '/page/2/', '/page/3/', '/page/4/'),
     r'https://eroteve\.com/[a-z0-9\-]+/'),
    ('OKPornTV', 'https://okporntv.com', ('/live-tv/', '/live-tv/page/2/', '/live-tv/page/3/', '/live-tv/page/4/', '/live-tv/page/5/'),
     r'https://okporntv\.com/live-tv/[a-z0-9\-]+/'),
    ('OKTeVe', 'https://okteve.com', ('/playlist/adult-18/', '/playlist/adult-18/page/2/'),
     r'https://okteve\.com/[a-z0-9\-]+/\?list=\d+'),
)
_ATCOM = 'https://adult-tv-channels.com'
_ATCLICK = 'https://adult-tv-channels.click'

# Site furniture that also matches the channel-link patterns.
_NOT_CHANNEL = re.compile(
    r'/(page|feed|category|tag|wp-[a-z]+|about|contact|contact-us|privacy-policy|dmca|dmca-policy|terms|login|'
    r'categories|channel|playlist|tv|blog|author|comments|browse|archives|tags|live-tv)(/|$)')

_RE_XPLAY_IFRAME = re.compile(r'<iframe[^>]+src=["\']((?:https?:)?//[^"\']*/xplay/[a-z0-9]+\.html[^"\']*)', re.I)
_RE_TITLE = re.compile(r'<title>([^<]*)</title>', re.I)
_RE_H1 = re.compile(r'<h1[^>]*>([^<]+)</h1>', re.I)


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/AdultTV] %s' % msg, level)


_XPLAY_HOSTS = ('eroteve.com', 'okteve.com', 'okporntv.com', 'oklivetv.com')
_throttle_lock = threading.Lock()
_last_xplay_req = [0.0]


class _RateLimited(Exception):
    pass


def _get(url, referer=None, timeout=_TIMEOUT):
    """GET with the courtesy the xplay-family hosts need. They sit behind CrowdSec, which
    answers a burst of requests with a captcha wall for about an hour (a 403 "Verify you
    are human" page) - measured 2026-09-25 after a few hundred requests in quick
    succession. So requests to those hosts are spaced out (under 1.5 a second overall), and once the wall appears the
    host is left alone for an hour instead of being hit again."""
    host = re.sub(r'^https?://([^/]+).*', r'\1', url)
    xplay = host.endswith(_XPLAY_HOSTS)
    if xplay:
        if _cache.get('atv_blocked_' + host):
            raise _RateLimited(host)
        with _throttle_lock:
            wait = _last_xplay_req[0] + 0.8 - time.time()
            if wait > 0:
                time.sleep(wait)
            _last_xplay_req[0] = time.time()
    headers = {'User-Agent': _UA}
    if referer:
        headers['Referer'] = referer
    r = requests.get(url, headers=headers, timeout=timeout)
    if xplay and r.status_code == 403 and 'Verify you are human' in r.text[:4000]:
        for h in _XPLAY_HOSTS:
            _cache.set('atv_blocked_' + h, True, 3600)
        _log('%s answered with a captcha wall; pausing the xplay sites for an hour' % host, xbmc.LOGWARNING)
        raise _RateLimited(host)
    r.raise_for_status()
    return r.text


# ── AES-256-GCM (decrypt only, tag not checked - the HMAC below already guards the payload) ──

def _b64u(s):
    s = s.replace('-', '+').replace('_', '/')
    return base64.b64decode(s + '=' * (-len(s) % 4))


def _gmul(x, y):
    """GF(2^128) multiply in GCM bit order."""
    z, v = 0, y
    for i in range(127, -1, -1):
        if (x >> i) & 1:
            z ^= v
        v = (v >> 1) ^ (0xE1 << 120) if v & 1 else v >> 1
    return z


def _ghash(h, data):
    y = 0
    for i in range(0, len(data), 16):
        block = data[i:i + 16].ljust(16, b'\0')
        y = _gmul(y ^ int.from_bytes(block, 'big'), h)
    return y


def _gcm_decrypt_pure(key, iv, ciphertext):
    import pyaes
    aes = pyaes.AES(bytes(key))
    enc = lambda b16: bytes(aes.encrypt(bytes(b16)))
    h = int.from_bytes(enc(b'\0' * 16), 'big')
    if len(iv) == 12:
        j0 = int.from_bytes(iv + b'\0\0\0\1', 'big')
    else:
        pad = b'\0' * ((16 - len(iv) % 16) % 16 + 8)
        j0 = _ghash(h, iv + pad + (len(iv) * 8).to_bytes(8, 'big'))
    prefix = (j0 >> 32) << 32
    out = bytearray()
    for n, i in enumerate(range(0, len(ciphertext), 16), 1):
        counter = prefix | (((j0 & 0xFFFFFFFF) + n) & 0xFFFFFFFF)
        stream = enc(counter.to_bytes(16, 'big'))
        out += bytes(a ^ b for a, b in zip(ciphertext[i:i + 16], stream))
    return bytes(out)


def _gcm_decrypt(key, iv, tag, ciphertext):
    for mod in ('Cryptodome', 'Crypto'):
        try:
            AES = __import__(mod + '.Cipher', fromlist=['AES']).AES
            return AES.new(key, AES.MODE_GCM, nonce=iv).decrypt_and_verify(ciphertext, tag)
        except ImportError:
            continue
    return _gcm_decrypt_pure(key, iv, ciphertext)


def _xplay_streams(page):
    """[{'type', 'url'}] decoded from an xplay player page ('' url for cam embeds)."""
    keys = re.search(r"k1:\s*'([^']+)',\s*k2:\s*'([^']+)'", page)
    arr = re.search(r'var streams = (\[.*?\]);', page, re.S)
    if not (keys and arr):
        return []
    k1, k2 = keys.group(1), keys.group(2)
    aes_key = hashlib.sha256(k1.encode()).digest()
    out = []
    for s in json.loads(arr.group(1)):
        url = s.get('url') or ''
        if url.startswith('#S'):
            data = url[2:]
            mac, payload = data[:16], data[16:]
            if hmac.new(k2.encode(), payload.encode(), hashlib.sha256).hexdigest()[:16] != mac:
                continue
            raw = _b64u(payload)
            try:
                plain = _gcm_decrypt(aes_key, raw[:16], raw[16:32], raw[32:])
                url = json.loads(plain.decode('utf-8')).get('url') or ''
            except Exception as e:
                _log('xplay decrypt failed: %s' % e, xbmc.LOGWARNING)
                continue
        elif url.startswith('#X'):
            continue   # older XOR form, not seen live
        out.append({'type': s.get('type', ''), 'url': url})
    return out


# ── per-technology resolvers: (page url) -> (playlist URL, referer) ──────────

def _resolve_xplay(player_url, referer):
    page = _get(player_url, referer)
    for s in _xplay_streams(page):
        if s['type'] == 'hls' and s['url']:
            return s['url'], None
    return None, None


def _resolve_xpage(page_url, _unused=None):
    """Channel page of an xplay site -> player iframe -> playlist (used for the
    sites' pages that were not probed when the list was built)."""
    m = _RE_XPLAY_IFRAME.search(_get(page_url))
    if not m:
        return None, None
    player = m.group(1)
    return _resolve_xplay('https:' + player if player.startswith('//') else player, page_url)


def _xor_signed_url(page):
    m = re.search(r'signedUrl = \(function\(\)\{var k=(\d+),a=\[([\d,]+)\]', page)
    if not m:
        return None
    k = int(m.group(1))
    return ''.join(chr(int(v) ^ k) for v in m.group(2).split(','))


def _resolve_atcom(page_url, _unused=None):
    page = _get(page_url)
    m = re.search(r'<iframe[^>]+src=["\'](/tv/[^"\']+)', page)
    if not m:
        return None, None
    url = _xor_signed_url(_get(_ATCOM + m.group(1), page_url))
    return url, _ATCOM + '/'


def _resolve_atclick(page_url, _unused=None):
    page = _get(page_url, _ATCLICK + '/')
    cfg = re.search(r'streamType:\s*"(\w+)",\s*apiUrl:\s*"([^"]+)",\s*endpoint:\s*"([^"]+)"', page)
    if cfg and cfg.group(1) == 'api':
        r = requests.post(cfg.group(2) + '/' + cfg.group(3), timeout=_TIMEOUT, headers={
            'User-Agent': _UA, 'Content-Type': 'application/x-www-form-urlencoded',
            'Referer': page_url, 'Origin': _ATCLICK})
        file_url = (r.json() or {}).get('fileUrl')
        if not file_url:
            return None, None
        return base64.b64decode(file_url).decode('utf-8')[::-1], _ATCLICK + '/'
    m = re.search(r'sourceUrl\s*:\s*"([^"]+)"', page)
    return (m.group(1), None) if m else (None, None)


_RESOLVERS = {'xplay': _resolve_xplay, 'xpage': _resolve_xpage,
              'atcom': _resolve_atcom, 'atclick': _resolve_atclick}


def _playlist_ok(url, referer):
    try:
        headers = {'User-Agent': _UA}
        if referer:
            headers['Referer'] = referer
        r = requests.get(url, headers=headers, timeout=8)
        return r.status_code == 200 and '#EXTM3U' in r.text[:200]
    except Exception:
        return False


def resolve(channel_id):
    """'ATV:<b64 json>' -> playable URL (with Kodi pipe headers when the host
    wants a Referer) or None. Each candidate source of the channel is tried in
    order until one yields a playlist URL."""
    if not channel_id.startswith('ATV:'):
        return None
    try:
        cands = json.loads(_b64u(channel_id[4:]).decode('utf-8'))
    except Exception:
        return None
    for kind, url, referer in cands:
        fn = _RESOLVERS.get(kind)
        if not fn:
            continue
        try:
            stream, ref = fn(url, referer)
        except Exception as e:
            _log('%s resolve error (%s): %s' % (kind, url[:60], e), xbmc.LOGWARNING)
            continue
        # adult-tv-channels playlists are checked (a dead one falls through to the next
        # candidate); the xplay proxy links are not fetched, in case they are one-shot
        if stream and kind in ('atcom', 'atclick') and not _playlist_ok(stream, ref):
            continue
        if stream:
            if ref:
                from urllib.parse import quote
                return '%s|Referer=%s&User-Agent=%s' % (stream, quote(ref, safe=''), quote(_UA, safe=''))
            return stream
    return None


# ── channel discovery ────────────────────────────────────────────────────────

def _norm(title):
    t = unicodedata.normalize('NFD', title.lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    t = re.sub(r'\b(online|live|tv|channel|watch)\b', ' ', t)
    return re.sub(r'[^a-z0-9]+', '', t)


def _clean_title(raw):
    t = _html.unescape(raw or '').strip()
    t = re.split(r'\s[-–—|]\s', t)[0]
    t = re.sub(r'\s+(?:Live|Online)$', '', t, flags=re.I)
    t = re.sub(r'\s+TV\s+(?:Live|Online)$', ' TV', t, flags=re.I)
    return t.strip()


def _fetch_listing(base, paths, pattern):
    """Channel page URLs found on a site's listing pages."""
    seen = {}
    for path in paths:
        try:
            hrefs = re.findall(r'href="(%s)"' % pattern, _get(base + path))
        except _RateLimited:
            break
        except Exception:
            continue
        for href in hrefs:
            # okporntv keeps every channel under /live-tv/, so judge the slug after that prefix
            if _NOT_CHANNEL.search(re.sub(r'^https://[^/]+(?:/live-tv(?=/.))?', '', href.split('?')[0])):
                continue
            seen.setdefault(href, None)
    return list(seen)


def _slug_title(url):
    slug = re.sub(r'^https?://[^/]+/(?:live-tv/)?', '', url.split('?')[0]).strip('/')
    slug = re.sub(r'-(?:tv-)?live$', '', slug)
    return slug.replace('-', ' ').title()


def _probe_xplay(page_url):
    """(title, player_url) when the channel page's player carries a real playlist."""
    try:
        html_text = _get(page_url)
        m = _RE_XPLAY_IFRAME.search(html_text)
        if not m:
            return None
        player = m.group(1)
        player = 'https:' + player if player.startswith('//') else player
        if not any(s['type'] == 'hls' and s['url'] for s in _xplay_streams(_get(player, page_url))):
            return None
        t = _RE_TITLE.search(html_text)
        return _clean_title(t.group(1) if t else ''), player
    except _RateLimited:
        raise
    except Exception:
        return None


def _plays(kind, page_url):
    """True when the channel page resolves to a playlist that really answers (a page can list a channel whose stream is gone)."""
    try:
        stream, ref = _RESOLVERS[kind](page_url, None)
        return bool(stream) and _playlist_ok(stream, ref)
    except Exception:
        return False


def _probe_atcom(page_url):
    try:
        html_text = _get(page_url)
        m = re.search(r'<iframe[^>]+src=["\'](/tv/[^"\']+)', html_text)
        if not m or not _xor_signed_url(_get(_ATCOM + m.group(1), page_url)):
            return None
        if not _plays('atcom', page_url):
            return None
        h1 = _RE_H1.search(html_text)
        return _clean_title(h1.group(1) if h1 else ''), page_url
    except Exception:
        return None


def _probe_atclick(page_url):
    try:
        html_text = _get(page_url, _ATCLICK + '/')
        if 'playerConfig' not in html_text or not _plays('atclick', page_url):
            return None
        h1 = _RE_H1.search(html_text)
        return _clean_title(h1.group(1) if h1 else ''), page_url
    except Exception:
        return None


def _cached(key, ttl_hit, ttl_miss, fn):
    hit = _cache.get(key)
    if hit is not None:
        return hit if hit else None
    res = fn()
    _cache.set(key, res if res else False, ttl_hit if res else ttl_miss)
    return res


def _xplay_channels(deadline):
    """Channels of the three xplay-family sites, merged by name so that only ONE page per
    channel is probed (the same channel is on all three sites). Returns
    ({key: {'title', 'candidates'}}, complete)."""

    def build_listing():
        found = {}   # key -> [page urls in preference order]
        pref = {'OKPornTV': 0, 'EroTeVe': 1, 'OKTeVe': 2}
        for label, base, paths, pat in sorted(_XPLAY_SITES, key=lambda x: pref[x[0]]):
            for page in _fetch_listing(base, paths, pat):
                key = _norm(_slug_title(page))
                if key:
                    found.setdefault(key, []).append(page)
        return found

    listing = _cached('atv_xplay_listing_v1', 12 * 3600, 20 * 60, build_listing) or {}
    # an empty listing means the sites could not be read (blocked / down), not that they are
    # complete - never let that be cached for hours as "done"
    out, complete = {}, bool(listing)

    def probe_key(item):
        key, pages = item
        ck = 'atv_xprobe_' + hashlib.md5(key.encode('utf-8')).hexdigest()
        hit = _cache.get(ck)
        if hit is not None:
            return key, (hit or None)
        result = None
        for page in pages:
            res = _probe_xplay(page)
            if res and res[0]:
                cands = [['xplay', res[1], page]] + [['xpage', p, None] for p in pages if p != page]
                result = {'title': res[0], 'candidates': cands}
                break
        _cache.set(ck, result if result else False, 7 * 24 * 3600 if result else 6 * 3600)
        return key, result

    from concurrent.futures import ThreadPoolExecutor, as_completed
    pool = ThreadPoolExecutor(max_workers=3)
    futs = []
    try:
        futs = [pool.submit(probe_key, it) for it in listing.items()]
        try:
            for fut in as_completed(futs, timeout=max(deadline - time.time(), 1)):
                try:
                    key, result = fut.result()
                except _RateLimited:
                    complete = False
                    continue
                except Exception:
                    continue
                if result:
                    out[key] = result
        except Exception:
            complete = False
    finally:
        pool.shutdown(wait=False)
    if any(not f.done() for f in futs):
        complete = False
    return out, complete


def get_channels():
    """[{'title', 'candidates': [[kind, url, referer], ...]}] merged across the five
    sites by channel name. Cached 6h once every xplay channel has been probed. Probing is
    paced (see _get), so a first build takes a few passes: each pass keeps what earlier
    ones learned (per-channel probe results are cached a week) and the partial list is
    only cached for 10 min."""
    ck = 'adult_tv_sites_v3'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    from concurrent.futures import ThreadPoolExecutor
    deadline = time.time() + 35
    plain = {}   # key -> {'title', 'candidates'}

    def add(kind, title, url):
        key = _norm(title)
        if not key:
            return
        entry = plain.setdefault(key, {'title': title, 'candidates': []})
        cand = [kind, url, None]
        if cand not in entry['candidates']:
            entry['candidates'].append(cand)

    click_pages = [p for p in _fetch_listing(_ATCLICK, ('/', '/page2'), r'https://adult-tv-channels\.click/[a-z0-9\-]+/')
                   if not p.rstrip('/').endswith('/page2')]
    com_pages = _fetch_listing(_ATCOM, ('/', '/page/2/', '/page/3/'), r'https://adult-tv-channels\.com/[a-z0-9\-]+/')
    with ThreadPoolExecutor(max_workers=8) as pool:
        click_res = list(pool.map(_probe_atclick, click_pages))
        com_res = list(pool.map(_probe_atcom, com_pages))
    for res in click_res:
        if res:
            add('atclick', res[0], res[1])
    for res in com_res:
        if res:
            add('atcom', res[0], res[1])

    try:
        xplay, complete = _xplay_channels(deadline)
    except Exception as e:
        _log('xplay discovery failed: %s' % e, xbmc.LOGWARNING)
        xplay, complete = {}, False
    merged = dict(plain)
    for key, entry in xplay.items():
        if key in merged:
            merged[key]['candidates'].extend(entry['candidates'])
        else:
            merged[key] = entry
    channels = sorted(merged.values(), key=lambda c: c['title'].lower())
    _log('%d adult channels (xplay sites %s)' % (len(channels), 'complete' if complete else 'still being probed'))
    _cache.set(ck, channels, 6 * 3600 if (channels and complete) else 10 * 60)
    return channels


def channel_id(channel):
    raw = json.dumps(channel['candidates'], separators=(',', ':')).encode('utf-8')
    return 'ATV:' + base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')
