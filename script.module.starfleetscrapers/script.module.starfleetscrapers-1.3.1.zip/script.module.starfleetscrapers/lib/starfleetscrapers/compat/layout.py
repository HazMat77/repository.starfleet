# -*- coding: utf-8 -*-
"""Starfleet's torrent sources, presented in the shape host add-ons that use a common-layout scraper module expect.

Such a host imports this package (starfleetscrapers), calls sources(specified_folders=['torrents']) and gets a list of
(provider name, source class). It then calls  source().sources(data, hostDict)  with
    data = {'title', 'year', 'imdb', 'aliases', 'premiered'}                                   for a movie
         = {'tvshowtitle', 'title' (episode title), 'year', 'imdb', 'season', 'episode', ...}  for an episode
and expects a list of dicts:
    {'provider', 'source': 'torrent', 'seeders', 'hash', 'name', 'name_info', 'quality', 'language', 'url' (magnet),
     'info', 'direct': False, 'debridonly': True, 'size' (float, GB)}
make_source(key) builds that class around one of Starfleet's search_<key> functions."""
import inspect
import re

# search functions that need an account, are adult-only or are not meant for a general movie/TV host
EXCLUDE = {'all', 'xxxclub', 'rintor', 'xxxtor', 'freejavtorrent', 'ijavtorrent', 'bitporn', 'sukebei_nyaa', 'podzemlje',
           'telegram_bot', 'torrenthunt_bot', 'publicdomaintorrents'}
# the fast, reliable core that is switched on out of the box (everything else is one tick away in the settings)
CORE = ('torrentio', 'comet', 'torz', 'zilean', 'dmm', 'knaben', 'tpb', 'yts', 'eztv', '1337x', 'mediafusion', 'meteor',
        'torrentsdb', 'bitsearch', 'nyaa', 'peerflix', 'aiostreams', 'anime')

_QUALITY = (('4K', ('2160', '216o', '4k', 'uhd')), ('1080p', ('1080', '1o8o', 'fhd')), ('720p', ('720', '72o')),
            ('SD', ('480', '576', '360', 'dvd', 'sd')))


def file_name(key):
    """Module file name for a provider key (a module name cannot start with a digit)."""
    return 'x' + key if key[0].isdigit() else key


def _quality(text):
    t = (text or '').lower()
    for label, keys in _QUALITY:
        if any(k in t for k in keys):
            return label
    if any(k in t for k in ('cam', 'telesync', 'hdts', 'tsrip')):
        return 'CAM'
    return 'SD'


def _gb(size):
    if isinstance(size, (int, float)):
        return round(size / 1073741824.0, 2) if size > 1000 else float(size)
    m = re.search(r'([\d.,]+)\s*(TB|GB|GiB|MB|MiB)', str(size or ''), re.I)
    if not m:
        return 0
    v = float(m.group(1).replace(',', ''))
    u = m.group(2).lower()
    return round(v * 1024 if u == 'tb' else v if u in ('gb', 'gib') else v / 1024.0, 2)


def to_layout(item, provider):
    """One Starfleet result -> a common-layout source dict (or None when it has no usable hash)."""
    ih = (item.get('info_hash') or '').lower()
    magnet = item.get('magnet') or ''
    if not ih:
        m = re.search(r'btih:([0-9a-fA-F]{40}|[A-Za-z2-7]{32})', magnet)
        ih = m.group(1).lower() if m else ''
    if not ih:
        return None
    name = item.get('title') or ''
    size = _gb(item.get('size'))
    try:
        seeders = int(item.get('seeds') or 0)
    except (TypeError, ValueError):
        seeders = 0
    quality = _quality(item.get('quality') or name)
    info = ' | '.join(x for x in ('%.2f GB' % size if size else '', item.get('quality') or '') if x)
    return {'provider': provider, 'source': 'torrent', 'seeders': seeders, 'hash': ih, 'name': name, 'name_info': '',
            'quality': quality, 'language': 'en', 'url': magnet or 'magnet:?xt=urn:btih:%s&dn=%s' % (ih, name),
            'info': info, 'direct': False, 'debridonly': True, 'size': size}


# API-style sources (one cheap call, the whole list comes back) are not capped; page-scraping sources are, because each
# extra result can cost another page request
API_LIMIT = 3000
SCRAPE_LIMIT = 60


def _call(fn, data, limit=None):
    """Call a Starfleet search function the way its signature wants it."""
    params = list(inspect.signature(fn).parameters)
    if limit is None:
        limit = API_LIMIT if ('imdb_id' in params and 'season' in params) or fn.__name__ in ('search_dmm', 'search_knaben') else SCRAPE_LIMIT
    tv = 'tvshowtitle' in data
    title = data.get('tvshowtitle') if tv else data.get('title')
    year = data.get('year')
    imdb = data.get('imdb')
    season, episode = (int(data['season']), int(data['episode'])) if tv else (None, None)
    mt = 'tv' if tv else 'movie'
    query = '%s S%02dE%02d' % (title, season, episode) if tv else title
    args = []
    for p in params:
        if p == 'title':
            args.append(query)
        elif p == 'year':
            args.append(None if tv else year)
        elif p == 'imdb_id':
            args.append(imdb)
        elif p == 'season':
            args.append(season)
        elif p == 'episode':
            args.append(episode)
        elif p == 'media_type':
            args.append(mt)
        elif p in ('limit', 'max_per_source'):
            args.append(limit)
        elif p == 'category':
            args.append(205 if tv else 207)
        else:
            args.append(None)
    return fn(*args) or []


def make_source(key):
    """The common-layout `source` class for Starfleet's search_<key>."""
    class source(object):
        priority = 1
        pack_capable = False
        hasMovies = True
        hasEpisodes = True
        language = ['en']

        def __init__(self):
            self.provider = key

        def sources(self, data, hostDict=None):
            from starfleetscrapers.debrid import torrent_sources as ts
            fn = getattr(ts, 'search_' + key, None)
            if fn is None or not data:
                return []
            if 'tvshowtitle' not in data and not (data.get('title') or data.get('imdb')):
                return []
            try:
                items = _call(fn, data)
            except Exception:
                return []
            out, seen = [], set()
            for it in items:
                d = to_layout(it, key)
                if d and d['hash'] not in seen:
                    seen.add(d['hash'])
                    out.append(d)
            return out

        def sources_packs(self, data, hostDict=None, search_series=False, total_seasons=None, bypass_filter=False):
            return []

    source.__name__ = 'source'
    return source


def available_keys():
    from starfleetscrapers.debrid import torrent_sources as ts
    return sorted(n[7:] for n in dir(ts) if n.startswith('search_') and n[7:] not in EXCLUDE and callable(getattr(ts, n)))
