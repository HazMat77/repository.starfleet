# -*- coding: utf-8 -*-
"""
movies/critic_scores.py - the critics' scores shown as badges on a title's page: the Metacritic Metascore (0-100) and the Rotten Tomatoes
Tomatometer (%). Both sites publish the score in the page's own structured data, so no account or key is needed. A title the sites do not
list, or a site that does not answer, simply has no badge.

    scores(title, year, tv) -> {'metacritic': 74, 'rt': 87}   (only the scores that were found)
"""
import json
import re
import threading
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor

from starfleetscrapers.core import http as requests

_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
_cache = {}
_lock = threading.Lock()
_TTL = 7 * 24 * 3600


def _slug(title, sep='-'):
    t = unicodedata.normalize('NFKD', title or '').encode('ascii', 'ignore').decode()
    t = re.sub(r"['’]", '', t.lower())
    t = re.sub(r'&', ' and ', t)
    t = re.sub(r'[^a-z0-9]+', sep, t).strip(sep)
    return t


def _ld_value(html, host):
    """The ratingValue out of the page's aggregateRating (Metacritic: the Metascore; Rotten Tomatoes: the Tomatometer)."""
    for m in re.finditer(r'"aggregateRating"\s*:\s*\{(.{0,600}?)\}', html, re.S):
        blob = m.group(1)
        if host == 'mc' and 'Metascore' not in blob:
            continue
        v = re.search(r'"ratingValue"\s*:\s*"?(\d{1,3})', blob)
        if v:
            return int(v.group(1))
    return 0


def _page_matches(html, title, year):
    """The page is for this film: its <title> carries the name, and (when known) the year is near the one given."""
    t = re.search(r'<title[^>]*>(.*?)</title>', html, re.S | re.I)
    head = _slug(re.sub(r'&amp;', '&', t.group(1))) if t else ''
    want = _slug(title)
    return bool(want) and want in head


def _metacritic(title, year, tv):
    kind = 'tv' if tv else 'movie'
    base = _slug(title)
    tries = [base] + (['%s-%s' % (base, year)] if year else [])
    for s in tries:
        try:
            r = requests.get('https://www.metacritic.com/%s/%s/' % (kind, s), headers={'User-Agent': _UA}, timeout=10)
        except Exception:
            continue
        if r.status_code != 200 or not _page_matches(r.text, title, year):
            continue
        v = _ld_value(r.text, 'mc')
        if v:
            return v
    return 0


def _rotten(title, year, tv):
    base = _slug(title, '_')
    tries = ['https://www.rottentomatoes.com/tv/%s' % base] if tv else \
            ['https://www.rottentomatoes.com/m/%s' % base] + (['https://www.rottentomatoes.com/m/%s_%s' % (base, year)] if year else [])
    for u in tries:
        try:
            r = requests.get(u, headers={'User-Agent': _UA}, timeout=10)
        except Exception:
            continue
        if r.status_code != 200 or not _page_matches(r.text, title, year):
            continue
        v = _ld_value(r.text, 'rt')
        if not v:
            m = re.search(r'"criticsScore"\s*:\s*\{[^}]*?"score"\s*:\s*"?(\d{1,3})', r.text) or re.search(r'tomatometerScore[^>]*?(\d{1,3})\s*%', r.text)
            v = int(m.group(1)) if m else 0
        if v:
            return v
    return 0


def scores(title, year=0, tv=False):
    key = '%s|%s|%s' % (_slug(title), year or 0, bool(tv))
    now = time.time()
    with _lock:
        c = _cache.get(key)
        if c and c[1] > now:
            return dict(c[0])
    pool = ThreadPoolExecutor(max_workers=2)
    f_mc = pool.submit(_metacritic, title, year, tv)
    f_rt = pool.submit(_rotten, title, year, tv)
    pool.shutdown(wait=False)
    out = {}
    for name, f in (('metacritic', f_mc), ('rt', f_rt)):
        try:
            v = f.result(timeout=14)
        except Exception:
            v = 0
        if v:
            out[name] = v
    with _lock:
        _cache[key] = (out, now + (_TTL if out else 3600))
    return dict(out)
