# -*- coding: utf-8 -*-
"""
movies/anime_providers.py

Anime streaming sites read through their own backends (the calls their web pages make), returning direct HLS playlists:

  AnimeParadise  animeparadise.moe: /search and /anime/<id>/episode on api.animeparadise.moe list the series and its episodes; the
                 watch page's own server action ("getEpisode", its id is read from the site's script) returns the episode's stream
                 address, which stream.animeparadise.moe turns into an HLS playlist (no headers needed).

Only run for titles that are anime (TMDB: animation, made in Japan), so other shows cost nothing. Keyed on the TMDB id the add-on
already has; every link is checked as a real playlist first.
"""
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmc

try:
    from starfleetscrapers.core import http as _req
except ImportError:
    _req = None

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/126.0.0.0 Safari/537.36')
_TMDB_KEY = '1865f43a0549ca50d341dd9ab8b29f49'
_TTL = 3600
_info_cache = {}
_action_cache = {}


def _log(msg):
    xbmc.log('[Starfleet/Anime] %s' % msg, xbmc.LOGINFO)


def _norm(t):
    return re.sub(r'[^a-z0-9]+', ' ', (t or '').lower()).strip()


def tmdb_info(tmdb_id, media_type):
    """{'names': [...], 'is_anime': bool, 'year': int} from TMDB (kept an hour)."""
    key = (tmdb_id, media_type)
    hit = _info_cache.get(key)
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    out = {'names': [], 'is_anime': False, 'is_donghua': False, 'year': 0}
    try:
        d = _req.get('https://api.themoviedb.org/3/%s/%s' % ('tv' if media_type == 'tv' else 'movie', tmdb_id),
                     params={'api_key': _TMDB_KEY}, timeout=8).json()
        names = [d.get('name') or d.get('title'), d.get('original_name') or d.get('original_title')]
        out['names'] = [n for n in dict.fromkeys(names) if n]
        genres = {g.get('id') for g in d.get('genres') or []}
        out['is_anime'] = 16 in genres and (d.get('original_language') == 'ja' or 'JP' in (d.get('origin_country') or []))
        out['is_donghua'] = 16 in genres and (d.get('original_language') == 'zh' or any(c in ('CN', 'TW', 'HK') for c in (d.get('origin_country') or [])))
        out['year'] = int(((d.get('first_air_date') or d.get('release_date') or '0')[:4]) or 0)
        if out['is_anime'] or out['is_donghua']:
            out['names'] += [n for n in _anilist_names(out['names'][0], out['year'], media_type) if n not in out['names']]
    except Exception as e:
        _log('tmdb %s: %s' % (tmdb_id, str(e)[:80]))
    _info_cache[key] = (time.time(), out)
    return out


def _anilist_names(title, year, media_type):
    """English / romaji titles and synonyms of the series on AniList (the names anime sites list it under)."""
    q = ('query($s:String){Page(perPage:6){media(search:$s,type:ANIME,sort:SEARCH_MATCH){title{romaji english} synonyms seasonYear '
         'format}}}')
    try:
        media = _req.post('https://graphql.anilist.co', json={'query': q, 'variables': {'s': title}}, timeout=8).json()['data']['Page']['media']
    except Exception:
        return []
    if media_type == 'movie':
        media = [m for m in media if m.get('format') == 'MOVIE'] or media
    pick = next((m for m in media if year and m.get('seasonYear') == year), media[0] if media else None)
    if not pick:
        return []
    t = pick.get('title') or {}
    return [n for n in [t.get('english'), t.get('romaji')] + (pick.get('synonyms') or [])[:3] if n and n.isascii()]


def _alive(url, timeout=8):
    try:
        r = _req.get(url, headers={'User-Agent': _UA}, timeout=timeout, stream=True)
        try:
            head = next(r.iter_content(256), b'')
        finally:
            r.close()
        return r.status_code < 400 and head[:7] == b'#EXTM3U'
    except Exception:
        return False


# ── AnimeParadise ────────────────────────────────────────────────────────────

_AP = 'https://www.animeparadise.moe'
_AP_API = 'https://api.animeparadise.moe'
_AP_ACTION_FALLBACK = '60edb8d72ddf7f3fdfbfc1303642e4829b0825ddef'


def _ap_action_id(watch_url):
    """Id of the site's getEpisode server action: it changes with every deploy, so it is read from the watch page's scripts."""
    hit = _action_cache.get('ap')
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    found = _AP_ACTION_FALLBACK
    try:
        page = _req.get(watch_url, headers={'User-Agent': _UA}, timeout=10).text
        for src in re.findall(r'src="(/_next/static/chunks/[^"]+\.js)"', page):
            js = _req.get(_AP + src, headers={'User-Agent': _UA}, timeout=10).text
            m = re.search(r'createServerReference\)?\("([0-9a-f]{20,})"[^)]*?"getEpisode"', js)
            if m:
                found = m.group(1)
                break
    except Exception as e:
        _log('animeparadise action id: %s' % str(e)[:80])
    _action_cache['ap'] = (time.time(), found)
    return found


def _ap_pick(results, names, season, year):
    """The search hit that is this series (and this season: AnimeParadise lists each season as its own entry)."""
    import difflib
    wanted = [_norm(n) for n in names]
    best, best_score = None, 0
    for r in results:
        t = _norm(r.get('title'))
        for w in wanted:
            if not w:
                continue
            if season and season > 1:
                ok = t == w or re.search(r'(?:season|part|cour)\s*%d\b' % season, t) and t.startswith(w) \
                    or t.startswith(w) and re.search(r'\b%d\b|\b%s\b' % (season, ('ii', 'iii', 'iv', 'v', 'vi')[min(season, 6) - 2]), t[len(w):])
                score = 2 if ok else 0
            else:
                score = 3 if t == w else (2 if difflib.SequenceMatcher(None, t, w).ratio() >= 0.88 else
                                          (1 if t.startswith(w + ' ') and not re.search(r'season|part|movie|ova|special|shippuden|boruto', t[len(w):]) else 0))
            if score > best_score:
                best, best_score = r, score
    return best


def animeparadise(names, media_type, season=None, episode=None, year=0):
    if not names:
        return []
    h = {'User-Agent': _UA}
    results = []
    for q in names[:2]:
        d = _req.get(_AP_API + '/search', params={'q': q}, headers=h, timeout=8).json().get('data') or []
        results = d
        pick = _ap_pick(d, names, season if media_type == 'tv' else None, year)
        if pick:
            break
    else:
        pick = None
    if not pick:
        return []
    eps = _req.get('%s/anime/%s/episode' % (_AP_API, pick['_id']), headers=h, timeout=10).json().get('data') or []
    num = str(episode or 1) if media_type == 'tv' else '1'
    ep = next((e for e in eps if str(e.get('number')) == num), None)
    if not ep:
        return []
    watch = '%s/watch/%s?origin=%s' % (_AP, ep['uid'], pick['_id'])
    m = None
    for attempt in (0, 1):
        action = _action_cache.get('ap', (0, _AP_ACTION_FALLBACK))[1] if attempt == 0 else _ap_action_id(watch)
        hdr = {'User-Agent': _UA, 'Next-Action': action, 'Content-Type': 'text/plain;charset=UTF-8',
               'Accept': 'text/x-component', 'Referer': watch}
        body = _req.post(watch, headers=hdr, data='["%s","%s"]' % (ep['uid'], pick['_id']), timeout=12).text
        m = re.search(r'"streamLink":"([^"]+)"', body)
        if m:
            break
    if not m:
        return []
    url = 'https://stream.animeparadise.moe/m3u8?url=' + m.group(1)
    if not _alive(url):
        return []
    return [{'label': 'AnimeParadise [%s, sub]' % (pick.get('title') or names[0])[:40], 'url': url}]


# ── MegaPlay (megaplay.buzz: the player many anime sites embed; sub and dub playlists by MyAnimeList id) ───────────────────────
# The MAL id comes from a public anime id table (enc-dec.app/db/kai); the player page names its internal file id in its title,
# getSources returns an encrypted answer and the same public helper opens it (only that encrypted text is sent).

_MP = 'https://megaplay.buzz'
_ENCDEC = 'https://enc-dec.app'
_MP_HDR = {'User-Agent': _UA, 'Origin': _MP, 'Referer': _MP + '/', 'X-Requested-With': 'XMLHttpRequest'}
_mal_cache = {}


def _mal_id(names, media_type, season, year):
    key = (tuple(names[:2]), media_type, season)
    if key in _mal_cache:
        return _mal_cache[key]
    want = 'movie' if media_type == 'movie' else 'tv'
    mal = None
    for q in names[:2]:
        for query in ([q] if media_type == 'movie' or not season or int(season) == 1 else ['%s Season %s' % (q, season), '%s %s' % (q, season)]):
            try:
                rows = _req.get(_ENCDEC + '/db/kai/search', params={'query': query}, timeout=8).json()
            except Exception:
                continue
            cands = []
            for r in rows if isinstance(rows, list) else []:
                i = r.get('info') or {}
                if not i.get('mal_id') or (i.get('type') or '') not in ((want, 'ona', 'ova') if want == 'tv' else ('movie',)):
                    continue
                name = _norm(i.get('title_en'))
                exact = name == _norm(query)
                yr_ok = (not year) or abs(int(i.get('year') or 0) - year) <= 1 or (season and int(season) > 1)
                if exact and yr_ok:
                    cands.append((0, r))
                elif name.startswith(_norm(query)) and yr_ok and want == 'movie':
                    cands.append((1, r))
            if cands:
                cands.sort(key=lambda c: c[0])
                mal = cands[0][1]['info']['mal_id']
                break
        if mal:
            break
    _mal_cache[key] = mal
    return mal


def _megaplay_one(mal, ep, voice):
    page = _req.get('%s/stream/mal/%s/%s/%s' % (_MP, mal, ep, voice), headers=_MP_HDR, timeout=10).text
    m = re.search(r'<title>File (\d+) - MegaPlay</title>', page)
    if not m:
        return None
    src = _req.get(_MP + '/stream/getSources', params={'id': m.group(1), 'platform': 'OTHER'}, headers=_MP_HDR, timeout=10).json()
    if not src.get('enc'):
        return None
    dec = _req.post(_ENCDEC + '/api/dec-megaplay', json={'text': src['enc']}, timeout=12).json().get('result') or {}
    f = dec.get('file') or ((dec.get('sources') or {}).get('file') if isinstance(dec.get('sources'), dict) else '')
    return f if f and f.startswith('http') else None


def megaplay(names, media_type, season=None, episode=None, year=0):
    if not names:
        return []
    mal = _mal_id(names, media_type, season, year)
    if not mal:
        return []
    ep = str(episode or 1) if media_type == 'tv' else '1'
    from starfleetscrapers.movies.site_providers import _pipe
    hdr = {'Referer': _MP + '/'}
    out = []
    for voice in ('sub', 'dub'):
        try:
            u = _megaplay_one(mal, ep, voice)
        except Exception as e:
            _log('megaplay %s: %s' % (voice, str(e)[:80]))
            continue
        if u and _alive_h(u, hdr):
            out.append({'label': 'MegaPlay [%s]' % voice, 'url': _pipe(u, hdr)})
    return out


# ── AniZone (anizone.to: Livewire site; the episode page names a master playlist with several audio tracks) ────────────────────

_AZ = 'https://anizone.to'


def _az_search(q):
    """Search hits [{'slug','title'}]: the search box is a Livewire component, so its state is posted back with the query."""
    import json as _j
    import html as _h
    s = _req.new_session()
    h = {'User-Agent': _UA}
    page = s.get(_AZ + '/anime', headers=h, timeout=10).text
    tok = re.search(r'name="csrf-token" content="([^"]+)"', page)
    if not tok:
        return []
    snap = None
    for raw in re.findall(r'wire:snapshot="([^"]+)"', page):
        sn = _h.unescape(raw)
        try:
            if _j.loads(sn)['memo']['name'] == 'pages.anime-index':
                snap = sn
                break
        except Exception:
            continue
    if not snap:
        return []
    hdr = dict(h, **{'Content-Type': 'application/json', 'X-Livewire': '', 'Referer': _AZ + '/anime'})
    body = _j.dumps({'_token': tok.group(1), 'components': [{'snapshot': snap, 'updates': {'search': q}, 'calls': []}]})
    r = s.post(_AZ + '/livewire/update', data=body, headers=hdr, timeout=12).json()
    html_ = r['components'][0]['effects'].get('html', '')
    m = re.search(r"items: JSON\.parse\('(.*?)'\)", html_, re.S)
    if not m:
        return []
    bs = chr(92)
    raw = m.group(1).replace(bs + 'u0022', '"').replace(bs * 2, bs).replace(bs + '/', '/')
    try:
        rows = _j.loads(raw)
    except Exception:
        return []
    out = []
    for r in rows:
        if not r.get('slug'):
            continue
        names = [r.get('main_title')] + list((r.get('title_list') or {}).values())
        seen = set()
        for t in names:                         # one hit per ascii title, so a match on any name finds the entry
            if t and t.isascii() and t not in seen:
                seen.add(t)
                out.append({'slug': r['slug'], 'title': t, 'main': r.get('main_title') or t})
    return out


def anizone(names, media_type, season=None, episode=None, year=0):
    if not names:
        return []
    pick = None
    for q in names[:2]:
        hits = [h for h in _az_search(q) if h['title']]
        pick = _ap_pick(hits, names, season if media_type == 'tv' else None, year)
        if pick:
            break
    if not pick:
        return []
    num = int(episode or 1) if media_type == 'tv' else 1
    page = _req.get('%s/anime/%s/%d' % (_AZ, pick['slug'], num), headers={'User-Agent': _UA}, timeout=12).text
    import html as _h
    bs = chr(92)
    page = re.sub(re.escape(bs) + '+/', '/', _h.unescape(page).replace(bs + 'u0022', '"'))
    m = re.search(r'https://[^"\s<>\\]+?/master\.m3u8', page)
    if not m:
        return []
    url = m.group(0)
    if not _alive(url):
        return []
    return [{'label': 'AniZone [%s, multi-audio]' % pick.get('main', pick['title'])[:40], 'url': url}]


def _alive_h(url, headers, timeout=8):
    try:
        h = {'User-Agent': _UA}
        h.update(headers)
        r = _req.get(url, headers=h, timeout=timeout, stream=True)
        try:
            head = next(r.iter_content(256), b'')
        finally:
            r.close()
        return r.status_code < 400 and head[:7] == b'#EXTM3U'
    except Exception:
        return False


# ── Donghua (Chinese animation): AnimeXin and Donghua4K, two sites on the same WordPress theme ───────────────────────────────
# /?s=<title> lists the series (/anime/<slug>/), the series page links every episode (...-episode-<n>-...), and an episode page names
# its servers as base64-encoded <iframe> snippets in a <select>; the servers that matter are Dailymotion uploads whose ids start with
# k (unlisted), which the player metadata call opens with a plain HLS playlist.

_DH_SITES = (('AnimeXin', 'https://animexin.dev'), ('Donghua4K', 'https://donghua4k.net'))
_RE_DH_HIT = re.compile(r'href="(https://[^"/]+/anime/[^"/]+/)"[^>]*>(?:\s*<[^>]+>)*\s*([^<]{3,90})')
_RE_DH_OPT = re.compile(r'<option[^>]+value="([A-Za-z0-9+/=]{24,})"[^>]*>([^<]*)')
_RE_DH_DM = re.compile(r'dailymotion\.com/(?:embed/video/|player/[^"\'\s?]*\?video=|video/)([xk][0-9A-Za-z]+)|[?&]video=([xk][0-9A-Za-z]+)')
_DH_DM_DEAD = ('removed', 'private', 'not found')


_DH_ROMAN = {'ii': '2', 'iii': '3', 'iv': '4', 'v': '5', 'vi': '6'}


def _dh_tokens(t):
    return {_DH_ROMAN.get(w, w) for w in _norm(t).split() if w not in ('the', 'of', 'a', 'and', 'season', 'part')}


def _dh_pick(hits, names, season):
    """The search hit that is this series: the one that holds the most words of a TMDB / AniList name (the shorter title wins a tie, so
    "Soul Land" is not taken for "Soul Land 2"), and for a later season the entry that says so. A hit is matched on its text and on
    its address (some pages show only a type badge as the link text)."""
    best, best_key = None, None
    for h in hits:
        slug = h['url'].rstrip('/').rsplit('/', 1)[-1].replace('-', ' ')
        for title in (h['title'], slug):
            ht = _dh_tokens(title)
            for n in names:
                nt = _dh_tokens(n)
                if not nt or not ht:
                    continue
                score = len(nt & ht) / float(len(nt))
                extra = {w for w in ht - nt if w.isdigit()}      # "Soul Land" is not "Soul Land 2"
                if extra and not any(w.isdigit() for w in nt):
                    score -= 0.5
                if season and season > 1:
                    score += 0.3 if re.search(r'(?:season|s)\s*%d|%d(?:st|nd|rd|th)? season|season %d' % (season, season, season), title.lower()) else -0.3
                key = (round(score, 2), -len(ht))
                if score >= 0.75 and (best_key is None or key > best_key):
                    best, best_key = h, key
    return best


def _dh_dm_stream(vid):
    """Playable HLS address of a Dailymotion upload (None when it was taken down or is not a playlist)."""
    try:
        import requests as _rq                     # a plain call: the shared session would re-send its own cookie jar and spoil the visit cookies
        r = _rq.get('https://www.dailymotion.com/player/metadata/video/' + vid, headers={'User-Agent': _UA, 'Referer': 'https://www.dailymotion.com/'}, timeout=10)
        j = r.json()
        # the playlist address is tied to the visit cookies the metadata call hands out (without them it answers 403)
        cookie = '; '.join('%s=%s' % (k, v) for k, v in r.cookies.get_dict().items())
    except Exception:
        return None
    if j.get('error'):
        return None
    q = j.get('qualities') or {}
    for key in ('auto', '1080', '720', '480', '380', '240'):
        for s in q.get(key) or []:
            if s.get('url'):
                url = s['url']
                hdr = {'Referer': 'https://www.dailymotion.com/'}
                if cookie:
                    hdr['Cookie'] = cookie
                try:
                    head = _rq.get(url, headers=dict(hdr, **{'User-Agent': _UA}), timeout=10).content[:7]
                except Exception:
                    return None
                if head != b'#EXTM3U':
                    return None
                from urllib.parse import quote
                return url + '|' + '&'.join('%s=%s' % (k, quote(v, safe='')) for k, v in hdr.items())
    return None


def _dh_site(label, base, names, season, episode):
    import base64
    h = {'User-Agent': _UA, 'Referer': base + '/'}
    pick = None
    for q in names[:3]:
        if not q or not q.isascii():
            continue
        page = _req.get(base + '/', params={'s': q}, headers=h, timeout=10).text
        hits, seen = [], set()
        for href, title in _RE_DH_HIT.findall(page):
            if href not in seen:
                seen.add(href)
                hits.append({'url': href, 'title': re.sub(r'\s+', ' ', title).strip()})
        pick = _dh_pick(hits, names, season)
        if pick:
            break
    if not pick:
        return []
    series = _req.get(pick['url'], headers=h, timeout=12).text
    target = int(episode or 1)
    ep_url = None
    import difflib
    ser_slug = _norm(pick['url'].rstrip('/').rsplit('/', 1)[-1].replace('-', ' '))
    own = []                                       # this series' episode links on the page: (url, slug before -episode-, number, rest of slug)
    for u, pre_raw, num, rest in re.findall(r'href="(%s/([^"/]*?)-episode-(\d+)(-[^"/]*)?/?)"' % re.escape(base), series):
        # the page also lists other series' latest episodes: only this series' own episode links count
        pre = _norm(pre_raw.replace('-', ' '))
        if pre and difflib.SequenceMatcher(None, pre, ser_slug[:len(pre)]).ratio() >= 0.85:
            own.append((u, pre_raw, int(num), rest or ''))
    for u, _p, num, _r in own:
        if num == target:
            ep_url = u
            break
    if not ep_url and own:                         # a short "latest episodes" list: the episode address follows the same pattern
        u, pre_raw, _n, rest = own[0]
        guess = '%s/%s-episode-%d%s/' % (base, pre_raw, target, rest)
        try:
            if _req.get(guess, headers=h, timeout=10).status_code == 200:
                ep_url = guess
        except Exception:
            pass
    if not ep_url:
        return []
    page = _req.get(ep_url, headers=h, timeout=12).text
    servers = []                                   # (server label, embed html)
    for raw, name in _RE_DH_OPT.findall(page):
        try:
            servers.append((re.sub(r'\s+', ' ', name).strip(), base64.b64decode(raw + '=' * (-len(raw) % 4)).decode('utf-8', 'ignore')))
        except Exception:
            continue
    servers.append(('Player', ' '.join(re.findall(r'<iframe[^>]+src=["\']([^"\']+)', page))))
    out, ids = [], set()
    for name, html_ in servers:
        for m in _RE_DH_DM.finditer(html_):
            vid = m.group(1) or m.group(2)
            if vid in ids:
                continue
            ids.add(vid)
            url = _dh_dm_stream(vid)
            if url:
                out.append({'label': '%s [%s]' % (label, (name or 'Dailymotion').replace('Daylimotion', 'Dailymotion')[:40]), 'url': url})
    return out


def donghua(names, media_type, season=None, episode=None, year=0):
    if not names or media_type != 'tv':
        return []
    out = []
    with ThreadPoolExecutor(max_workers=len(_DH_SITES)) as ex:
        futs = [ex.submit(_dh_site, label, base, names, season, episode) for label, base in _DH_SITES]
        for f in futs:
            try:
                out.extend(f.result(timeout=12) or [])
            except Exception as e:
                _log('donghua: %s' % str(e)[:100])
    return out


# ── Hoster-page anime sites (AniWorld DE, AnimeAV1 ES, LatAnime ES) and AniLiberty (RU) ───────────────────────────────────────
# Each lists an episode's hoster embeds (VOE, Filemoon, Vidmoly, MP4Upload, StreamWish...) which the Starfleet resolvers turn into
# direct streams; AniLiberty serves HLS playlists itself. Matched by title, season and episode like the sites above.

def _resolve_many(items, referer, prefix, limit=6, wait=9):
    """[(label, hoster_url)] -> [{'label','url'}]: each hoster page resolved in parallel; hosts the resolvers do not know are skipped."""
    import starfleetresolve as _sfr
    items = [(l, u) for l, u in items if u and u.startswith('http') and 'undef' not in u and _sfr.knows_host(u) not in (None, 'dead')][:limit]
    if not items:
        return []
    out = []
    pool = ThreadPoolExecutor(max_workers=len(items))
    futs = [(l, u, pool.submit(_sfr.resolve, u, referer)) for l, u in items]
    pool.shutdown(wait=False)
    deadline = time.time() + wait
    for l, u, f in futs:
        try:
            r = f.result(timeout=max(0.1, deadline - time.time()))
        except Exception:
            continue
        if r:
            host = re.sub(r'^www\.', '', re.sub(r'^https?://([^/]+).*', r'\1', u))
            out.append({'label': ('%s %s [%s]' % (prefix, l, host)).replace('  ', ' '), 'url': r})
    return out


def _best_title(cands, names, key_title='title'):
    """The candidate whose normalised title equals one of the names (else the closest that contains it)."""
    nn = [_norm(n) for n in names if n]
    for c in cands:
        if _norm(c[key_title]) in nn:
            return c
    for c in cands:
        t = _norm(c[key_title])
        if any(n and (n in t or t in n) and abs(len(t) - len(n)) < 12 for n in nn):
            return c
    return None


_AW = 'https://aniworld.to'
_AW_LANG = {'1': 'German dub', '2': 'English sub', '3': 'German sub'}


def aniworld(names, media_type, season=None, episode=None, year=0):
    if not names:
        return []
    h = {'User-Agent': _UA, 'X-Requested-With': 'XMLHttpRequest'}
    pick = None
    for q in names[:2]:
        d = _req.get(_AW + '/ajax/seriesSearch', params={'keyword': q}, headers=h, timeout=8).json()
        pick = _best_title([{'title': re.sub(r'<[^>]+>', '', x.get('name', '')), 'link': x.get('link', '')} for x in d or []], names)
        if pick:
            break
    if not pick:
        return []
    slug = pick['link']
    page = ('%s/anime/stream/%s/filme/film-1' % (_AW, slug)) if media_type == 'movie' else \
           ('%s/anime/stream/%s/staffel-%s/episode-%s' % (_AW, slug, season or 1, episode or 1))
    t = _req.get(page, headers={'User-Agent': _UA}, timeout=10).text
    items = []
    for m in re.finditer(r'<li[^>]*data-lang-key="(\d)"[^>]*data-link-target="(/redirect/\d+)"[^>]*>(.*?)</li>', t, re.S):
        lang, path, body = m.groups()
        name = re.search(r'<h4>([^<]+)</h4>', body)
        items.append((lang, (name.group(1) if name else 'host'), _AW + path))
    items.sort(key=lambda x: {'2': 0, '1': 1, '3': 2}.get(x[0], 3))
    resolved = []
    for lang, nm, red in items[:8]:
        try:
            r = _req.get(red, headers={'User-Agent': _UA, 'Referer': _AW + '/'}, timeout=8, allow_redirects=False)
            loc = r.headers.get('Location') or ''
            if loc:
                resolved.append(('%s %s' % (_AW_LANG.get(lang, ''), nm), loc))
        except Exception:
            pass
    return _resolve_many(resolved, _AW + '/', 'AniWorld')


_AV = 'https://animeav1.com'


def animeav1(names, media_type, season=None, episode=None, year=0):
    if not names:
        return []
    h = {'User-Agent': _UA}
    pick = None
    for q in names[:2]:
        t = _req.get(_AV + '/catalogo', params={'search': q}, headers=h, timeout=8).text
        cands = [{'title': s.replace('-', ' '), 'link': s} for s in dict.fromkeys(re.findall(r'href="/media/([a-z0-9-]+)"', t))]
        pick = _best_title(cands, names)
        if pick:
            break
    if not pick:
        return []
    ep = 1 if media_type == 'movie' else (episode or 1)
    t = _req.get('%s/media/%s/%s' % (_AV, pick['link'], ep), headers=h, timeout=10).text
    m = re.search(r'embeds:\{(.*?)\},downloads', t, re.S)
    if not m:
        return []
    items = []
    for kind in ('SUB', 'DUB'):
        mm = re.search(kind + r':\[(.*?)\]', m.group(1), re.S)
        for s, u in re.findall(r'server:"([^"]+)",url:"([^"]+)"', mm.group(1) if mm else ''):
            items.append(('%s %s' % ('Sub' if kind == 'SUB' else 'Dub', s), u))
    return _resolve_many(items, _AV + '/', 'AnimeAV1')


_LA = 'https://latanime.org'


def latanime(names, media_type, season=None, episode=None, year=0):
    import base64
    if not names:
        return []
    h = {'User-Agent': _UA}
    pick = None
    for q in names[:2]:
        t = _req.get(_LA + '/buscar', params={'q': q}, headers=h, timeout=8).text
        cands = [{'title': s.replace('-', ' '), 'link': s} for s in dict.fromkeys(re.findall(r'href="https://latanime\.org/anime/([a-z0-9-]+)"', t))]
        pick = _best_title(cands, names)
        if pick:
            break
    if not pick:
        return []
    ep = 1 if media_type == 'movie' else (episode or 1)
    page = _req.get('%s/ver/%s-episodio-%s' % (_LA, pick['link'], ep), headers=h, timeout=10)
    if page.status_code >= 400:
        return []
    items = []
    for b in dict.fromkeys(re.findall(r'data-player="([A-Za-z0-9+/=]{16,})"', page.text)):
        try:
            u = base64.b64decode(b).decode('utf-8', 'ignore')
        except Exception:
            continue
        items.append(('', u))
    return _resolve_many(items, _LA + '/', 'LatAnime (Spanish)')


_AL = 'https://aniliberty.top/api/v1'


def aniliberty(names, media_type, season=None, episode=None, year=0):
    if not names:
        return []
    h = {'User-Agent': _UA}
    pick = None
    for q in names[:2]:
        d = _req.get(_AL + '/app/search/releases', params={'query': q}, headers=h, timeout=8).json() or []
        cands = []
        for x in d:
            nm = x.get('name') or {}
            cands.append({'title': nm.get('english') or nm.get('main') or '', 'link': x.get('id')})
        pick = _best_title(cands, names)
        if pick:
            break
    if not pick:
        return []
    rel = _req.get('%s/anime/releases/%s' % (_AL, pick['link']), headers=h, timeout=10).json()
    eps = rel.get('episodes') or []
    num = 1 if media_type == 'movie' else (episode or 1)
    e = next((x for x in eps if x.get('ordinal') == num), None)
    if not e:
        return []
    for q in ('hls_1080', 'hls_720', 'hls_480'):
        u = e.get(q)
        if u and _alive(u):
            return [{'label': 'AniLiberty [Russian voice, %sp]' % q[4:], 'url': u}]
    return []


PROVIDERS = (('animeparadise', animeparadise), ('megaplay', megaplay), ('anizone', anizone), ('donghua', donghua),
             ('aniworld', aniworld), ('animeav1', animeav1), ('latanime', latanime), ('aniliberty', aniliberty))
_DONGHUA_ONLY = ('donghua',)


def search_anime(tmdb_id, media_type='tv', season=None, episode=None, budget=14):
    """[{'label', 'url'}] from every anime site, only when the title is anime."""
    if not _req or not tmdb_id or media_type not in ('movie', 'tv'):
        return []
    info = tmdb_info(tmdb_id, media_type)
    if not (info['is_anime'] or info['is_donghua']):
        return []
    from starfleetscrapers.core import source_toggles as _st
    # Japanese anime goes to the anime sites; Chinese animation only to the donghua ones
    active = [(n, fn) for n, fn in PROVIDERS if _st.on('anime', n) and ((n in _DONGHUA_ONLY) == (not info['is_anime']))]
    if not active:
        return []
    out = []
    pool = ThreadPoolExecutor(max_workers=len(active))
    try:
        futs = {pool.submit(fn, info['names'], media_type, season, episode, info['year']): name for name, fn in active}
        try:
            for f in as_completed(futs, timeout=budget):
                try:
                    out.extend(f.result() or [])
                except Exception as e:
                    _log('%s: %s' % (futs[f], str(e)[:100]))
        except Exception:
            pass
    finally:
        pool.shutdown(wait=False)
    _log('%d link(s) for %s' % (len(out), info['names'][:1]))
    return out
