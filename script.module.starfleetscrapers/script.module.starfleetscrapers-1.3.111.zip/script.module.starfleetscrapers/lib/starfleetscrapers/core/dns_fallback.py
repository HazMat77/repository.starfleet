"""
DNS-over-HTTPS fallback for hostnames whose local resolution is blocked
even though the domain itself is live. Confirmed for chat.cfbu247.sbs:
the local/ISP resolver returns NXDOMAIN (getaddrinfo failed) while
Cloudflare's own public DoH resolver returns a real, working A record for
the exact same query, and the resolved IP serves real content when hit
directly. Rather than hardcode that IP (it can rotate), this queries DoH
fresh on first failure, caches the answer briefly, and swaps it in only
for the single failing request via a scoped socket.getaddrinfo patch —
transparent to requests/urllib3/ssl (SNI/Host header untouched), so no
other error handling needs to change.
"""
import socket
import threading
import time

import requests

_DOH_CACHE = {}
_DOH_LOCK = threading.Lock()
_DOH_TTL = 300

_DOH_ENDPOINTS = [
    ('https://cloudflare-dns.com/dns-query', {'accept': 'application/dns-json'}),
    ('https://dns.google/resolve', {}),
    # by address, for when the local resolver is down altogether (these certificates cover the IP)
    ('https://1.1.1.1/dns-query', {'accept': 'application/dns-json'}),
    ('https://8.8.8.8/resolve', {}),
]


def _doh_lookup(hostname):
    now = time.time()
    with _DOH_LOCK:
        cached = _DOH_CACHE.get(hostname)
        if cached and cached[1] > now:
            return cached[0]

    for endpoint, headers in _DOH_ENDPOINTS:
        try:
            r = requests.get(endpoint, params={'name': hostname, 'type': 'A'},
                              headers=headers, timeout=5)
            data = r.json()
            for ans in data.get('Answer', []):
                if ans.get('type') == 1:
                    ip = ans['data']
                    with _DOH_LOCK:
                        _DOH_CACHE[hostname] = (ip, now + _DOH_TTL)
                    return ip
        except Exception:
            continue
    return None


def _is_dns_failure(exc):
    msg = str(exc)
    return 'getaddrinfo failed' in msg or 'NameResolutionError' in msg or 'Name or service not known' in msg


def request(method, url, **kwargs):
    """requests.request(), but on a local DNS resolution failure, retries
    once with getaddrinfo scoped-patched to a fresh DoH-resolved IP for
    just that hostname. Re-raises the original error if DoH can't resolve
    it either (a genuinely dead domain still fails the same way as before)."""
    from urllib.parse import urlparse

    try:
        return requests.request(method, url, **kwargs)
    except requests.exceptions.ConnectionError as e:
        if not _is_dns_failure(e):
            raise
        hostname = urlparse(url).hostname
        ip = _doh_lookup(hostname)
        if not ip:
            raise

        real_getaddrinfo = socket.getaddrinfo

        def _patched(host, *a, **kw):
            if host == hostname:
                host = ip
            return real_getaddrinfo(host, *a, **kw)

        socket.getaddrinfo = _patched
        try:
            return requests.request(method, url, **kwargs)
        finally:
            socket.getaddrinfo = real_getaddrinfo


def get(url, **kwargs):
    return request('GET', url, **kwargs)


# ── Shared-layer support ──────────────────────────────────────────────────────────────────────────────────────────────────────
# core/http.py calls override() when a host cannot be resolved locally. The answer is kept (a few minutes) and applied by ONE
# permanent wrapper around socket.getaddrinfo that only touches hosts which failed locally, so concurrent requests never race to
# patch and restore it. Certificates and the Host/SNI name are untouched: only the address is swapped.
_OVERRIDE = {}
_WRAP_LOCK = threading.Lock()
_wrapped = False
_real_getaddrinfo = socket.getaddrinfo

# A good answer is reused for a few minutes: one search fans out across many pages/mirrors/retries of the same handful of
# hosts, each of which otherwise pays a fresh resolution. Desktop's OS keeps its own resolver cache warm for this (confirmed
# live 2026-11-20: a repeat lookup answers at once there); Android does not do this nearly as well for an app making dozens of
# parallel lookups to different hosts at once, which is exactly this shape of traffic - so this cache is kept here, in our own
# process, where every platform gets the same benefit instead of leaning on however well each one's own resolver happens to cache.
_POS_CACHE = {}
_POS_TTL = 180
_POS_LOCK = threading.Lock()
_POS_CAP = 800


def _wrapper(host, *a, **kw):
    now = time.time()
    ent = _OVERRIDE.get(host) if isinstance(host, str) else None
    if ent and ent[1] > now:
        return _real_getaddrinfo(ent[0], *a, **kw)
    if not isinstance(host, str) or host.replace('.', '').isdigit() or ':' in host:
        return _real_getaddrinfo(host, *a, **kw)          # already an address, or not a plain hostname: nothing to cache
    key = (host,) + a + tuple(sorted(kw.items()))
    with _POS_LOCK:
        cached = _POS_CACHE.get(key)
    if cached and cached[1] > now:
        return cached[0]
    result = _real_getaddrinfo(host, *a, **kw)
    with _POS_LOCK:
        if len(_POS_CACHE) > _POS_CAP:
            _POS_CACHE.clear()
        _POS_CACHE[key] = (result, now + _POS_TTL)
    return result


def _install():
    global _wrapped
    with _WRAP_LOCK:
        if not _wrapped:
            socket.getaddrinfo = _wrapper
            _wrapped = True


_install()       # active from the moment anything imports this module - core/http.py does so eagerly, before its first request


def is_dns_failure(exc):
    return _is_dns_failure(exc)


def override(hostname):
    """Resolve hostname over HTTPS (Cloudflare, then Google) and make this process use that address for it. True when it worked."""
    if not hostname or hostname.replace('.', '').isdigit():
        return False
    ip = _doh_lookup(hostname)
    if not ip:
        return False
    _install()
    with _WRAP_LOCK:
        _OVERRIDE[hostname] = (ip, time.time() + _DOH_TTL)
    return True
