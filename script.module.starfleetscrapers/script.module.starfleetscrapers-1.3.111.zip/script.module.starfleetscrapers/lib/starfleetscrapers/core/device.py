# -*- coding: utf-8 -*-
"""What the scrapers are running on, so they can use the device sensibly.

    profile()   -> dict, worked out once:  tier ('low' | 'mid' | 'high'), cores, ram_mb, platform, model, and the knobs below
    knob(name)  -> one value of that dict

A Fire TV Stick has four slow cores and under 2 GB of memory: starting forty threads at once there makes every one of them
slower and can push Kodi out of memory. An NVIDIA SHIELD or a PC has the cores and the memory to run everything at once. The
scrapers are waiting on the network most of the time, so the knobs are about how many requests are in flight at once, how many
results are post-processed (the title filter and de-duplication are the CPU-heavy part, and the GIL means extra cores do not
speed them up), and whether the second-choice sources start beside the first-choice ones instead of after them.

The viewer can force a tier in the add-on settings (device_tier: 0 = detect, 1 = low, 2 = mid, 3 = high).

Detection reads only what is freely readable: the CPU count, /proc/meminfo, the Android model / manufacturer (getprop), the
Windows memory status. Nothing is sent anywhere.
"""
import os
import re
import sys
import threading

_lock = threading.Lock()
_cached = {}

# per tier: how many source threads at most, results kept per source, raw results post-processed in total, whether the
# aggregator sources of the second choice start at the same moment as the first choice (speculative), grace given to slow
# sources after the main ones answered, connections kept open per host
TIERS = {
    'low':  {'pool': 8,  'per_source': 500,  'raw_cap': 1400, 'speculative': False, 'grace': 0.7, 'conn': 8},
    'mid':  {'pool': 16, 'per_source': 1200, 'raw_cap': 3500, 'speculative': False, 'grace': 1.0, 'conn': 16},
    'high': {'pool': 48, 'per_source': 3000, 'raw_cap': 0,    'speculative': False, 'grace': 1.0, 'conn': 32},
}

# Fire TV models (ro.product.model): the plain sticks and the Lite are low; the 4K Max and the Cube have more memory and cores
_FIRE_MID = ('AFTMM', 'AFTKRT', 'AFTGAZL', 'AFTRS')           # Stick 4K Max (both), Cube 2nd / 3rd gen
_FIRE_HIGH = ()


def _read(path, limit=65536):
    try:
        with open(path, 'r', errors='replace') as fh:
            return fh.read(limit)
    except Exception:
        return ''


def _getprop(name):
    try:
        import subprocess
        out = subprocess.run(['getprop', name], capture_output=True, text=True, timeout=2)
        return (out.stdout or '').strip()
    except Exception:
        return ''


def _ram_mb():
    m = re.search(r'MemTotal:\s+(\d+)\s*kB', _read('/proc/meminfo'))
    if m:
        return int(m.group(1)) // 1024
    if sys.platform.startswith('win'):
        try:
            import ctypes

            class _MS(ctypes.Structure):
                _fields_ = [('l', ctypes.c_ulong), ('load', ctypes.c_ulong), ('tp', ctypes.c_ulonglong), ('ap', ctypes.c_ulonglong),
                            ('tpf', ctypes.c_ulonglong), ('apf', ctypes.c_ulonglong), ('tv', ctypes.c_ulonglong),
                            ('av', ctypes.c_ulonglong), ('ae', ctypes.c_ulonglong)]
            ms = _MS()
            ms.l = ctypes.sizeof(_MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
            return int(ms.tp // (1024 * 1024))
        except Exception:
            return 0
    return 0


def _is_android():
    # Confirmed live 2026-11-20: under HazMat TV (Chaquopy) xbmc.getCondVisibility() is a stand-in that always answers False -
    # it never raises, so the except branch below never ran there and every HazMat TV device was being read as not-Android.
    # sys.platform reads 'android' there (the same check telegram_link.py already uses), so it is tried first.
    if sys.platform == 'android':
        return True
    try:
        import xbmc
        if xbmc.getCondVisibility('System.Platform.Android'):
            return True
    except Exception:
        pass
    return 'ANDROID_ROOT' in os.environ or os.path.exists('/system/build.prop')


def classify(cores, ram_mb, android=False, model='', manufacturer=''):
    """The tier for a device. Pure function (the same answer for the same facts), so it can be tested without the device."""
    model = (model or '').strip()
    man = (manufacturer or '').strip().lower()
    cores = cores or 2
    if man == 'nvidia' or model.upper().startswith('SHIELD'):
        return 'high'                                            # Tegra X1: fast cores, 2-3 GB, usually wired
    if man == 'amazon' or model.upper().startswith('AFT'):
        if model in _FIRE_HIGH:
            return 'high'
        return 'mid' if model in _FIRE_MID else 'low'
    if ram_mb and ram_mb < 2300:
        return 'low'
    if android:
        if cores >= 8 and ram_mb >= 3500:
            return 'high'
        return 'mid'
    if cores >= 8 and (not ram_mb or ram_mb >= 6000):
        return 'high'
    if cores >= 4:
        return 'mid'
    return 'low'


def _forced():
    try:
        v = os.environ.get('STARFLEET_DEVICE_TIER')
        if not v:
            from starfleetscrapers import host as _host
            v = _host.addon().getSetting('device_tier')
        return {'1': 'low', '2': 'mid', '3': 'high', 'low': 'low', 'mid': 'mid', 'high': 'high'}.get(str(v or '').strip().lower())
    except Exception:
        return None


def _detect():
    cores = os.cpu_count() or 2
    ram = _ram_mb()
    android = _is_android()
    model = manufacturer = ''
    if android:
        model = _getprop('ro.product.model')
        manufacturer = _getprop('ro.product.manufacturer')
    tier = classify(cores, ram, android, model, manufacturer)
    plat = 'android' if android else sys.platform
    return {'tier': tier, 'detected': tier, 'cores': cores, 'ram_mb': ram, 'platform': plat, 'model': model,
            'manufacturer': manufacturer}


def profile():
    """The device profile (computed once). A tier forced in the settings replaces the detected one."""
    forced = _forced()
    with _lock:
        if 'base' not in _cached:
            _cached['base'] = _detect()
    p = dict(_cached['base'])
    if forced:
        p['tier'] = forced
    quiet = quiet_mode()
    if quiet:
        p['tier'] = 'low'                 # Quiet mode: the lowest tier, fewer threads, nothing speculative or prepared ahead
    p.update(TIERS[p['tier']])
    p['quiet'] = quiet
    if quiet:
        p['pool'] = min(p['pool'], 4)
        p['raw_cap'] = min(p['raw_cap'], 900)
        p['speculative'] = False
    return p


def quiet_mode():
    """True when the viewer switched Quiet mode on (Settings): a thin box or a hot stick searches with fewer threads and prepares nothing ahead."""
    import time
    now = time.time()
    hit = _cached.get('quiet')
    if hit and now - hit[0] < 5:                      # read at most every few seconds: this is asked on every request
        return hit[1]
    val = False
    try:
        if os.environ.get('STARFLEET_QUIET_MODE') == '1':
            val = True
        else:
            from starfleetscrapers import host as _host
            val = str(_host.addon().getSetting('quiet_mode') or '').strip().lower() == 'true'
    except Exception:
        val = False
    _cached['quiet'] = (now, val)
    return val


def knob(name):
    return profile()[name]


def reset():
    with _lock:
        _cached.clear()
