# -*- coding: utf-8 -*-
"""
Telling an ISP block from everything else, and (only then) going through a US / Canadian proxy.

A link that fails can fail for many reasons: the site is down, the link expired, the file is gone, the server refuses a bot...
Only one of those is cured by a different network: the viewer's ISP (or country) blocking the host. This module works out which it
is, with a layer-by-layer probe of the host, and ONLY when it finds an ISP block (the viewer's own DNS lies, the connection is reset
or intercepted, a block page comes back, or the host answers normally through the proxy but not directly) does it send that one
host through the viewer's own US / Canadian proxy for a while. No block found = no proxy, ever.

Where the proxy comes from: the "ISP-block proxy" setting (block_proxy), one or more http(s):// or socks5:// addresses, one per
line. A proxy is only used after it proved - through the same IP lookup the report uses - that it really exits in the US or Canada.
Nothing is bundled: a free public proxy can read and change everything that goes through it.

    diagnose(url)      the probe: dict with layer results and a verdict (verdict, isp_block)
    check_and_route(url)   diagnose, and when it is an ISP block + a proxy is available, route that host through it. True when routed.
    proxies_for(host)  requests-style proxies for a host that is currently routed, else None (core/http.py asks this on every call)
    network_info()     the viewer's public IP, ISP, country, city (cached), for the broken-link report
    report_text(url)   the above as the lines of the auto report
"""
import json
import re
import socket
import ssl
import threading
import time
from urllib.parse import urlparse

import requests

_LOCK = threading.Lock()
_ROUTED = {}          # host -> (until, proxy url)
_ROUTE_SECS = 30 * 60
_GOOD = {}            # proxy url -> (until, country)  verified US / CA exits
_BAD = {}             # proxy url -> until             proxies that do not work or exit elsewhere
_NET = {'t': 0.0, 'v': None}
_DIAG = {}            # host -> (until, result)

_UA = {'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36'}
_BLOCK_PAGE = re.compile(
    r'(this (site|website|page|content) (has been|is|was) (blocked|restricted)|access (to this (site|website|page) )?(is )?(denied|blocked|restricted)|'
    r'blocked (by|due to|under)|has been blocked|court order|ordered (by|to)|copyright (infringement|holder)|'
    r'not available in your (country|region|location)|unavailable in your (country|region)|geo.?(restrict|block)|'
    r'sorry,? this (content|video|site) is not available|restricted by (your )?(internet|isp|network)|'
    r'(internet|service) provider.{0,60}(block|restrict)|ofcom|cleanfeed|web ?filter|content filter|parental control|'
    r'blocked: category|site blocked|url blocked|webroot|fortiguard|sophos|forcepoint|netsweeper|zscaler|opendns)', re.I)
_IPV4 = re.compile(r'^\d{1,3}(\.\d{1,3}){3}$')


class _Private(object):
    @staticmethod
    def match(v):
        """True for a private, loopback, link-local or blank IP address (anything else, host names included, is False)."""
        import ipaddress
        try:
            a = ipaddress.ip_address(v)
        except ValueError:
            return False
        return a.is_private or a.is_loopback or a.is_link_local or a.is_unspecified


_PRIVATE = _Private()


# ---- settings -------------------------------------------------------------------------------------------------------------------------

def _setting(key):
    try:
        from starfleetscrapers import host as _sfhost
        return (_sfhost.addon().getSetting(key) or '').strip()
    except Exception:
        try:
            import xbmcaddon
            return (xbmcaddon.Addon().getSetting(key) or '').strip()
        except Exception:
            return ''


def configured():
    """The proxy addresses the viewer entered (may be empty)."""
    raw = _setting('block_proxy')
    out = []
    for p in re.split(r'[\s,;]+', raw):
        p = p.strip()
        if not p:
            continue
        if '://' not in p:
            p = 'http://' + p
        if p not in out:
            out.append(p)
    return out[:6]


def enabled():
    return _setting('block_proxy_on').lower() != 'false'


def _pdict(p):
    return {'http': p, 'https': p}


# ---- lookups ----------------------------------------------------------------------------------------------------------------------------

def _lookup(proxy=None, timeout=6):
    """(ip, isp, country code, city, region, asn) of the network a request leaves from; direct or through a proxy. None on failure."""
    kw = {'timeout': timeout, 'headers': _UA}
    if proxy:
        kw['proxies'] = _pdict(proxy)
    for url in ('https://ipinfo.io/json', 'https://ipwho.is/', 'https://ipapi.co/json/'):
        try:
            d = requests.get(url, **kw).json()
        except Exception:
            continue
        ip = d.get('ip') or d.get('query')
        if not ip:
            continue
        conn = d.get('connection') if isinstance(d.get('connection'), dict) else {}
        isp = d.get('org') or conn.get('isp') or conn.get('org') or d.get('isp') or ''
        cc = d.get('country') if len(str(d.get('country') or '')) == 2 else (d.get('country_code') or d.get('countryCode') or '')
        return {'ip': ip, 'isp': isp, 'country': str(cc or d.get('country') or ''), 'city': d.get('city') or '',
                'region': d.get('region') or d.get('region_name') or '', 'asn': str(conn.get('asn') or ''), 'tz': (d.get('timezone') if isinstance(d.get('timezone'), str) else (d.get('timezone') or {}).get('id', '')) or ''}
    return None


def network_info():
    """The viewer's public network: ip, isp, country, city, region, tz (cached 10 minutes). {} when no lookup answered."""
    now = time.time()
    with _LOCK:
        if _NET['v'] is not None and now - _NET['t'] < 600:
            return _NET['v']
    v = _lookup() or {}
    with _LOCK:
        _NET['t'], _NET['v'] = now, v
    return v


def _proxy_ok(p):
    """True when this proxy answers and its exit is in the US or Canada (the result is remembered)."""
    now = time.time()
    with _LOCK:
        g = _GOOD.get(p)
        if g and g[0] > now:
            return True
        if _BAD.get(p, 0) > now:
            return False
    info = _lookup(p, timeout=8)
    ok = bool(info) and (info.get('country') or '').upper() in ('US', 'CA')
    with _LOCK:
        if ok:
            _GOOD[p] = (now + 1800, info.get('country'))
        else:
            _BAD[p] = now + 600
    return ok


def usable_proxy():
    """The first configured proxy that really exits in the US or Canada, else ''."""
    if not enabled():
        return ''
    for p in configured():
        if _proxy_ok(p):
            return p
    return ''


# ---- routing -------------------------------------------------------------------------------------------------------------------------

def _host(url):
    try:
        return (urlparse(url.split('|')[0]).hostname or '').lower()
    except Exception:
        return ''


def proxies_for(host):
    """A requests `proxies` dict while `host` is routed through the proxy (a block was found for it), else None."""
    if not _ROUTED:
        return None
    r = _ROUTED.get((host or '').lower())
    if not r:
        return None
    if r[0] < time.time():
        _ROUTED.pop((host or '').lower(), None)
        return None
    return _pdict(r[1])


def is_routed(url):
    return proxies_for(_host(url)) is not None


def routed_hosts():
    now = time.time()
    return sorted(h for h, v in _ROUTED.items() if v[0] > now)


# ---- the probe -------------------------------------------------------------------------------------------------------------------------

def _tcp(ip, port, timeout=4):
    t0 = time.time()
    try:
        s = socket.create_connection((ip, port), timeout=timeout)
        s.close()
        return 'ok', int((time.time() - t0) * 1000)
    except socket.timeout:
        return 'timeout', int((time.time() - t0) * 1000)
    except ConnectionResetError:
        return 'reset', int((time.time() - t0) * 1000)
    except ConnectionRefusedError:
        return 'refused', int((time.time() - t0) * 1000)
    except OSError as e:
        return 'error:%s' % (str(e)[:40]), int((time.time() - t0) * 1000)


def _tls(host, ip, timeout=5):
    """TLS handshake with the real name as SNI. ok / reset / cert (certificate does not match: someone is in the middle) / timeout / error."""
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((ip, 443), timeout=timeout) as raw:
            with ctx.wrap_socket(raw, server_hostname=host):
                return 'ok'
    except ssl.SSLCertVerificationError:
        return 'cert'
    except ConnectionResetError:
        return 'reset'
    except socket.timeout:
        return 'timeout'
    except ssl.SSLError as e:
        return 'error:%s' % (str(e)[:40])
    except OSError as e:
        return 'error:%s' % (str(e)[:40])


def _http(url, proxy=None, timeout=7):
    """(status, final host, first 1500 chars of the body, error text) of one GET (not following to media bodies)."""
    kw = {'timeout': timeout, 'headers': _UA, 'stream': True, 'allow_redirects': True}
    if proxy:
        kw['proxies'] = _pdict(proxy)
    try:
        r = requests.get(url.split('|')[0], **kw)
        try:
            chunk = next(r.iter_content(1500), b'')
        except Exception:
            chunk = b''
        body = chunk.decode('utf-8', 'replace') if (r.headers.get('content-type', '') or '').lower().startswith(('text', 'application/json', 'application/x-mpegurl', 'application/vnd.apple')) else ''
        host = urlparse(r.url).hostname or ''
        status = r.status_code
        r.close()
        return status, host, body, ''
    except requests.exceptions.SSLError as e:
        return 0, '', '', 'ssl: %s' % str(e)[:80]
    except requests.exceptions.ConnectTimeout:
        return 0, '', '', 'connect timeout'
    except requests.exceptions.ReadTimeout:
        return 0, '', '', 'read timeout'
    except requests.exceptions.ConnectionError as e:
        t = str(e)
        if 'Connection reset' in t or 'ECONNRESET' in t or 'reset by peer' in t:
            return 0, '', '', 'connection reset'
        if 'getaddrinfo' in t or 'Name or service' in t or 'NameResolution' in t:
            return 0, '', '', 'dns failure'
        return 0, '', '', 'connection error: %s' % t[:80]
    except Exception as e:
        return 0, '', '', 'error: %s' % str(e)[:80]


def _doh(host):
    try:
        from starfleetscrapers.core import dns_fallback as _d
        return _d._doh_lookup(host) or ''
    except Exception:
        return ''


def _internet_ok():
    for u in ('https://www.cloudflare.com/cdn-cgi/trace', 'https://www.google.com/generate_204'):
        s, _, _, e = _http(u, timeout=5)
        if s:
            return True
    return False


def _segment_host(url):
    """For a playlist, the host of its first media segment (a playlist can load fine while the CDN behind it is the blocked one)."""
    try:
        base = url.split('|')[0]
        if '.m3u8' not in base.lower() and 'mpegurl' not in base.lower():
            return ''
        from urllib.parse import urljoin
        cur = base
        for _ in range(2):
            r = requests.get(cur, headers=_UA, timeout=6)
            lines = [l.strip() for l in r.text.splitlines() if l.strip() and not l.startswith('#')]
            if not lines:
                return ''
            nxt = urljoin(cur, lines[0])
            if '.m3u8' in nxt.lower():
                cur = nxt
                continue
            return (urlparse(nxt).hostname or '').lower()
    except Exception:
        return ''
    return ''


def _probe_host(host, url, with_proxy):
    """One host, layer by layer. Returns a dict of findings and a list of reasons that point at an ISP block."""
    out = {'host': host}
    reasons = []
    port = 443 if (urlparse(url.split('|')[0]).scheme or 'https') == 'https' else 80
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
        sys_ips = sorted({i[4][0] for i in infos if ':' not in i[4][0]})[:4]
        out['dns'] = ','.join(sys_ips) or 'none'
    except Exception as e:
        sys_ips = []
        out['dns'] = 'failed (%s)' % str(e)[:40]
    doh_ip = _doh(host)
    out['doh'] = doh_ip or 'none'
    if not sys_ips and doh_ip:
        reasons.append('your DNS cannot resolve %s but a public resolver can' % host)
    elif sys_ips and any(_PRIVATE.match(i) for i in sys_ips) and doh_ip and not _PRIVATE.match(doh_ip):
        reasons.append('your DNS returns a private/blank address (%s) for %s' % (sys_ips[0], host))
    elif sys_ips and doh_ip and doh_ip not in sys_ips:
        # a different answer is normal for CDNs; it only counts when the system address then does not serve the host
        out['dns_differs'] = True
    ip = sys_ips[0] if sys_ips and not (sys_ips and _PRIVATE.match(sys_ips[0])) else doh_ip
    if not ip:
        out['tcp'] = out['tls'] = 'skipped (no address)'
        if not doh_ip and not sys_ips:
            out['dead_name'] = True
    else:
        out['tcp'], out['tcp_ms'] = _tcp(ip, port)
        if out['tcp'] == 'ok' and port == 443:
            out['tls'] = _tls(host, ip)
            if out['tls'] == 'reset':
                reasons.append('the connection is reset right after the TLS hello (SNI filtering)')
            elif out['tls'] == 'cert':
                reasons.append('the certificate does not match %s (a filter is in the middle)' % host)
        elif out['tcp'] in ('reset', 'refused'):
            reasons.append('TCP connection to %s is %s' % (ip, out['tcp']))
        elif out['tcp'] == 'timeout' and doh_ip and doh_ip != ip:
            t2, _ = _tcp(doh_ip, port)
            out['tcp_doh_ip'] = t2
            if t2 == 'ok':
                reasons.append('the address your DNS gives times out but the true address answers')
    st, fh, body, err = _http(url)
    out['http'] = st or err
    if fh and fh != host:
        out['http_final_host'] = fh
    if st in (451,):
        reasons.append('HTTP 451 (blocked for legal reasons)')
    if body and _BLOCK_PAGE.search(body) and (st != 200 or (len(body) < 1400 and 'html' in body.lower())):
        m = _BLOCK_PAGE.search(body)
        out['block_text'] = m.group(0)[:60]
        reasons.append('a block page came back ("%s")' % m.group(0)[:60])
    if err in ('connection reset',):
        reasons.append('the server connection is reset')
    out['_err'] = err
    out['_status'] = st
    return out, reasons


def diagnose(url, with_proxy=True):
    """Probe the link's host (and, for a playlist, the host of its segments). Returns a dict with 'verdict' and 'isp_block'.

    isp_block is only True when there is positive evidence: a lying DNS, a reset / intercepted connection, a block page, HTTP 451, or
    the host answering through a (verified US / Canadian) proxy while it fails directly."""
    host = _host(url)
    if not host:
        return {'host': '', 'verdict': 'no host in the link', 'isp_block': False}
    if _PRIVATE.match(host) or host in ('localhost',) or host.endswith('.local') or '.' not in host:
        return {'host': host, 'verdict': 'a local-network address - not an ISP block', 'isp_block': False, 'layers': []}
    now = time.time()
    with _LOCK:
        c = _DIAG.get(host)
        if c and c[0] > now:
            return c[1]
    hosts = [host]
    seg = _segment_host(url)
    if seg and seg != host:
        hosts.append(seg)
    results, reasons, failing = [], [], ''
    net_ok = _internet_ok()
    for h in hosts[:2]:
        r, why = _probe_host(h, url if h == host else 'https://%s/' % h, with_proxy)
        results.append(r)
        direct_failed = bool(r.get('_err')) or r.get('_status') in (0, 451) or bool(why)
        if direct_failed and not failing:
            failing = h
        reasons.extend(why)
    res = {'host': host, 'segment_host': seg if seg != host else '', 'internet': net_ok, 'layers': [{k: v for k, v in r.items() if not k.startswith('_')} for r in results],
           'reasons': reasons, 'failing_host': failing, 'proxy': 'none configured', 'isp_block': False}
    if not net_ok:
        res['verdict'] = 'no internet connection from this device right now'
    else:
        verdict = ''
        direct_bad = bool(failing)
        px = ''
        if direct_bad and with_proxy:
            px = usable_proxy()
            res['proxy'] = ('verified %s exit' % _GOOD.get(px, (0, '?'))[1]) if px else ('configured but none exits in US/CA' if configured() else 'none configured')
            if px:
                st, _, body, err = _http(('https://%s/' % failing) if failing != host else url, proxy=px)
                res['via_proxy'] = st or err
                if st and st < 500 and st != 451 and not (body and _BLOCK_PAGE.search(body)):
                    reasons.append('%s answers normally through a %s proxy but not from your connection' % (failing, _GOOD.get(px, (0, 'US/CA'))[1]))
        if reasons:
            res['isp_block'] = True
            verdict = 'ISP / network block: ' + '; '.join(reasons[:3])
        elif direct_bad:
            err = next((r.get('_err') or str(r.get('_status')) for r in results if r.get('_err') or r.get('_status')), '')
            if any(r.get('dead_name') for r in results):
                verdict = 'the host name does not exist anywhere (site gone)'
            else:
                verdict = 'host not reachable (%s) - no sign of an ISP block (site down or link expired)' % err
        else:
            st = results[0].get('_status')
            verdict = 'host reachable directly (HTTP %s) - not an ISP block' % st
        res['verdict'] = verdict
    with _LOCK:
        _DIAG[host] = (now + 120, res)
        if len(_DIAG) > 60:
            for k in [k for k, v in _DIAG.items() if v[0] < now]:
                _DIAG.pop(k, None)
    return res


def check_and_route(url):
    """Diagnose; when (and only when) the diagnosis is an ISP block and a verified US / Canadian proxy exists, route the failing host(s)
    through it for half an hour. Returns the diagnosis dict, with 'routed' listing the hosts now going through the proxy."""
    if not enabled() or not configured():
        return {'isp_block': False, 'verdict': 'no ISP-block proxy is set up (nothing was probed)', 'routed': [], 'proxy': 'none configured'}
    d = dict(diagnose(url))
    d['routed'] = []
    if not d.get('isp_block'):
        return d
    px = usable_proxy()
    if not px:
        return d
    until = time.time() + _ROUTE_SECS
    for h in {x for x in (d.get('failing_host'), d.get('host'), d.get('segment_host')) if x}:
        with _LOCK:
            _ROUTED[h.lower()] = (until, px)
        d['routed'].append(h)
    return d


def forget():
    with _LOCK:
        _ROUTED.clear()
        _DIAG.clear()


# ---- the report ----------------------------------------------------------------------------------------------------------------------

def report_text(url=''):
    """Network + block diagnosis lines for the auto report."""
    lines = []
    n = network_info()
    if n:
        lines.append('Network: IP %s | ISP %s | %s%s%s | tz %s' % (
            n.get('ip', '?'), n.get('isp', '?'), n.get('city', ''), (', ' + n['region']) if n.get('region') else '', (', ' + n['country']) if n.get('country') else '', n.get('tz', '?')))
    else:
        lines.append('Network: public IP lookup did not answer')
    if url and url.startswith('http'):
        try:
            d = diagnose(url)
            lines.append('Block check: %s' % d.get('verdict', '?'))
            for L in d.get('layers', []):
                lines.append('  %s: dns=%s doh=%s tcp=%s tls=%s http=%s%s' % (L.get('host'), L.get('dns'), L.get('doh'), L.get('tcp', '-'), L.get('tls', '-'), L.get('http', '-'),
                                                                        (' final=' + L['http_final_host']) if L.get('http_final_host') else ''))
            lines.append('  internet=%s proxy=%s%s routed=%s' % (d.get('internet'), d.get('proxy'), (' via_proxy=%s' % d['via_proxy']) if d.get('via_proxy') else '', ','.join(routed_hosts()) or '-'))
        except Exception as e:
            lines.append('Block check failed: %s' % e)
    return '\n'.join(lines)


def summary_json(url):
    """For the app: what was found, and whether the link should be tried again (the host is now routed)."""
    d = check_and_route(url)
    return json.dumps({'isp_block': bool(d.get('isp_block')), 'verdict': d.get('verdict', ''), 'routed': d.get('routed', []),
                       'proxy': d.get('proxy', '')})
