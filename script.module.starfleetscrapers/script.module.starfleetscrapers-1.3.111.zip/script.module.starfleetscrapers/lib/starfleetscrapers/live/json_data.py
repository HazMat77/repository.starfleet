# -*- coding: utf-8 -*-
"""
resources/lib/json_data.py

Reads the pre-scraped JSON files produced by the standalone scraper suite
(running on a dedicated PC, pushed to GitHub) instead of live-scraping those
same sites from inside Kodi. Handles fetch+cache, per-source category-key
normalization, and same-game deduplication across sources (unions every
source's links into one listing per real-world event).

Every public function accepts an optional `_overrides` dict ({source_name:
parsed_json}) purely so a standalone script can exercise this module's real
logic against local sample files without a running Kodi instance — normal
addon code never passes it, so nothing here needs stubbing to ship.
"""

from starfleetscrapers import host as _sfhost
import re
import hashlib
import xbmc
import xbmcaddon
import xbmcvfs

try:
    from starfleetscrapers.core import http as _req
except ImportError:
    _req = None

from starfleetscrapers.core import cache as _cache

ADDON    = _sfhost.addon()
_PROFILE = _sfhost.profile()
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
}

_DATA_BASE = 'https://hazmat77.github.io/repository.starfleet/data/'

_JSON_SOURCES = {
    # the event feeds (streameast, daddylive_sports, mut, sportsbite, timstreams, bosscast, crickfree) are gone: the live sources
    # read those sites directly now. Only the weekly channel catalogue is still hosted.
    'daddylive_channels': _DATA_BASE + 'daddylive_channels.json',
}

# Per-source category key -> our own canonical slug (from sports_sources._CATEGORIES).
# Anything not listed here is assumed to already match our slug directly.
# Empty for now — every source that once needed re-normalization here
# (daddylive_sports, totalsportek) has been removed entirely (2026-08-10).
# Left as a dict (not deleted) since _events_by_slug_categories() below
# still looks sources up in it generically.
_CATEGORY_NORMALIZE = {}

# Labels/icons for slugs that only exist because a JSON source introduced them.
# 'icon' here is the remote fallback only — wnba/motorsports/other_international
# each get a custom Starfleet-branded local icon resolved below via the same
# _ss._local_sport_icon() lookup _CATEGORIES itself uses (sports_sources.py),
# since these 3 are built dynamically rather than living in that static list.
_NEW_CATEGORY_META = {
    'wnba':                {'label': 'WNBA',                  'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/wnba.png'},
    'motorsports':         {'label': 'Motorsports (F1/F2/F3)', 'icon': ''},
    'afl':                 {'label': 'AFL (Aussie Rules)',     'icon': ''},
    # 'other_events' removed 2026-08-02 — folded into 'other_international'
    # below instead of keeping two separate, confusingly-similar catch-all
    # menus. daddylive_sports's "Other" bucket (previously the only real
    # source of 'other_events') now normalizes straight to
    # 'other_international' (see _CATEGORY_NORMALIZE above) and
    # get_other_international_events() pulls it in alongside the existing
    # bosscast/crickfree leftovers.
    'other_international': {'label': 'Other / International',  'icon': ''},
}

# slug -> local icon filename in resources/skins/Default/media/sports, for the
# dynamically-discovered slugs above that now have a custom icon shipped.
_NEW_CATEGORY_LOCAL_ICON = {
    'wnba':        'wnba.png',
    'motorsports': 'motorsports.png',
}

_RE_TIME_PREFIX = re.compile(r'^(\d{1,2}:\d{2})\s*(.*)$')


def split_time_prefix(raw_title):
    """'20:10Milwaukee Brewers - Colorado Rockies' -> ('20:10', 'Milwaukee Brewers - Colorado Rockies').
    bosscast/crickfree smash a leading HH:MM straight against the title with
    no separator. Time is parsed but not converted to a timestamp (no
    confirmed timezone/date assumption for these two sources yet)."""
    m = _RE_TIME_PREFIX.match((raw_title or '').strip())
    if m:
        return m.group(1), m.group(2).strip(' -')
    return '', (raw_title or '').strip()


def _stable_id(prefix, title):
    """Deterministic id for a JSON-only event (no ESPN/TSDB id exists for it).
    Must use hashlib, not Python's hash() — str hash() is randomized per
    process (PYTHONHASHSEED), so a raw hash() would mint a different id every
    Kodi restart and break the get_sport_events -> get_event_streams
    side-channel cache lookup below (same event_id needed on both ends)."""
    return '%s_%s' % (prefix, hashlib.md5(title.encode('utf-8')).hexdigest()[:12])


def _fetch_json(name, _override_data=None):
    """Fetch+cache one source's raw parsed JSON. None on failure/missing."""
    if _override_data is not None:
        return _override_data
    ck = 'jsondata_raw_%s' % name
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None   # cached {} sentinel = known-bad, don't refetch yet
    url = _JSON_SOURCES.get(name)
    if not url or _req is None:
        return None
    try:
        r = _req.get(url, timeout=(4, 8), headers=_HEADERS)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/JSONData] fetch %s failed: %s' % (name, e), xbmc.LOGWARNING)
        _cache.set(ck, {}, 60)
        return None
    _cache.set(ck, data, 300)
    return data


@_cache.coalesced
def _fetch_all(_overrides=None):
    """Fetch every active source. Returns {name: data_or_None}."""
    overrides = _overrides or {}
    if overrides:
        return {n: _fetch_json(n, overrides.get(n)) for n in _JSON_SOURCES}
    # every source is its own host (~2s each): fetched one after the other that was 16s on a cold start
    from concurrent.futures import ThreadPoolExecutor
    names = list(_JSON_SOURCES)
    with ThreadPoolExecutor(max_workers=len(names) or 1) as pool:
        return dict(zip(names, pool.map(_fetch_json, names)))


def _norm_links(raw_links, source):
    out, seen = [], set()
    for l in (raw_links or []):
        u = l.get('playable_url')
        if not u:
            continue
        base = u.split('|', 1)[0]
        if base in seen:
            continue
        seen.add(base)
        out.append({'label': l.get('label', 'Link'), 'url': u,
                    'quality': '', 'language': '', 'source': source})
    return out


def _events_by_slug_categories(data, source_name):
    """streameast/crackstreams/mut/sportsbite share the {slug: [event,...]}
    shape keyed 'categories', already close to our slugs. daddylive_sports
    uses the same per-event shape but its own top-level key ('sports_events'
    — see scraper_daddylive_sports.py's own output). ('sports' key / all24
    case removed 2026-08-14 along with all24.json itself — see
    _JSON_SOURCES's own comment.)"""
    if not data:
        return {}
    key = 'sports_events' if source_name == 'daddylive_sports' else 'categories'
    norm_map = _CATEGORY_NORMALIZE.get(source_name, {})
    out = {}
    for raw_slug, evs in (data.get(key) or {}).items():
        slug = norm_map.get(raw_slug, raw_slug)
        bucket = out.setdefault(slug, [])
        for ev in (evs or []):
            bucket.append({
                'title':    ev.get('title', ''),
                'is_live':  bool(ev.get('is_live', False)),
                'links':    _norm_links(ev.get('links'), source_name),
                'source':   source_name,
                # Only mut/sportsbite's own scrapers actually populate this
                # (real timestamps their raw APIs provide) — every other
                # source here defaults to 0, same as before this existed.
                'start_ts': int(ev.get('start_ts', 0) or 0),
            })
    return out


def _events_flat(data, source_name):
    """bosscast/crickfree: {'games': [{'title','links'}]} — no category
    grouping at all. Splits the smashed HH:MM prefix off the title."""
    if not data:
        return []
    out = []
    for g in (data.get('games') or []):
        _time, title = split_time_prefix(g.get('title', ''))
        out.append({
            'title': title, 'is_live': False,
            'links': _norm_links(g.get('links'), source_name), 'source': source_name,
        })
    return out


def merge_json_events(primary_events, sport_slug, _overrides=None):
    """Enrich primary_events (already produced by sports_sources.get_sport_events
    from ESPN/TSDB/etc.) with every matching JSON-sourced event, UNIONING
    links across however many of the JSON sources also have that game — the
    "one listing, dialog shows every source's links" mechanism.

    Lazily imports sports_sources._titles_match (NOT at module scope —
    sports_sources must not import json_data at module scope either, or this
    becomes a circular import; only the 2 functions in sports_sources that
    need it import it locally).
    """
    from starfleetscrapers.sports.sports_sources import _titles_match

    all_data = _fetch_all(_overrides)
    candidates = []
    for name in ('streameast', 'mut', 'sportsbite', 'daddylive_sports'):
        candidates += _events_by_slug_categories(all_data.get(name), name).get(sport_slug, [])
    flat_candidates = (
        _events_flat(all_data.get('bosscast'), 'bosscast') +
        _events_flat(all_data.get('crickfree'), 'crickfree')
    )

    merged = [dict(e) for e in primary_events]
    claimed_titles = set()

    for jc in candidates + flat_candidates:
        matched_idx = None
        for i, pe in enumerate(merged):
            if _titles_match(jc['title'], pe.get('title', ''), threshold=2):
                matched_idx = i
                break
        if matched_idx is not None:
            existing = merged[matched_idx].get('links', [])
            seen_urls = {l['url'] for l in existing}
            merged[matched_idx]['links'] = existing + [l for l in jc['links'] if l['url'] not in seen_urls]
            claimed_titles.add(jc['title'])
        elif jc.get('source') not in ('bosscast', 'crickfree'):
            # JSON-only event with no ESPN/TSDB counterpart (e.g. a
            # CrackStreams-only PPV) — still show it as its own listing.
            merged.append({
                'id': _stable_id('json', jc['title']), 'path': '', 'title': jc['title'],
                'league': '', 'logo': '', 'is_live': jc.get('is_live', False),
                'start_ts': jc.get('start_ts', 0), 'venue': '', 'links': jc['links'],
            })
        # unmatched bosscast/crickfree entries are silently skipped here —
        # they aren't known to belong to this sport_slug at all.

    for ev in merged:
        if ev.get('links'):
            _cache.set('json_ev_links_%s' % ev['id'], ev['links'], 600)

    if claimed_titles:
        ck = 'json_claimed_titles'
        prev = _cache.get(ck) or set()
        _cache.set(ck, prev | claimed_titles, 600)

    return merged


def get_other_international_events(_overrides=None):
    """bosscast/crickfree games that never matched any named sport category
    this cache window — backs the single "Other / International" catch-all
    menu. (daddylive_sports's own "Other" bucket used to fold in here too;
    removed 2026-08-10 along with the rest of that JSON source — see
    _JSON_SOURCES's own comment.)

    Known v1 limitation: a bosscast/crickfree game is only excluded here if
    merge_json_events() already ran for the sport category that claims it,
    in this same ~10min cache window (i.e. that sport's menu was opened
    first). Accepted as shipped behavior rather than eagerly merging all
    ~24 categories on every menu open."""
    from starfleetscrapers.sports.sports_sources import _titles_match

    all_data = _fetch_all(_overrides)
    flat = (
        _events_flat(all_data.get('bosscast'), 'bosscast') +
        _events_flat(all_data.get('crickfree'), 'crickfree')
    )
    claimed = _cache.get('json_claimed_titles') or set()
    leftovers = [e for e in flat if e['title'] not in claimed]

    out = []
    for e in leftovers:
        dup = next((o for o in out if _titles_match(e['title'], o['title'])), None)
        if dup:
            seen = {l['url'] for l in dup['links']}
            dup['links'] += [l for l in e['links'] if l['url'] not in seen]
        else:
            out.append({
                'id': _stable_id('other', e['title']), 'path': '', 'title': e['title'],
                'league': '', 'logo': '', 'is_live': False, 'start_ts': 0,
                'venue': '', 'links': e['links'],
            })
    for e in out:
        _cache.set('json_ev_links_%s' % e['id'], e['links'], 600)
    return out


def get_all_categories(_overrides=None):
    """sports_sources._CATEGORIES plus any category only discovered in the
    JSON sources (e.g. 'wnba' from CrackStreams), plus the always-present
    'other_international' catch-all."""
    from starfleetscrapers.sports import sports_sources as _ss
    base = _ss.get_sport_categories()
    existing = {c['slug'] for c in base}

    all_data = _fetch_all(_overrides)
    discovered = set()
    for name in ('streameast', 'mut', 'sportsbite', 'daddylive_sports'):
        discovered |= set(_events_by_slug_categories(all_data.get(name), name).keys())
    discovered.add('other_international')

    extra = []
    for slug in sorted(discovered - existing):
        meta = _NEW_CATEGORY_META.get(slug, {'label': slug.replace('_', ' ').title(), 'icon': ''})
        icon = meta['icon']
        local_icon_file = 'other.png' if slug == 'other_international' else _NEW_CATEGORY_LOCAL_ICON.get(slug)
        if local_icon_file:
            # Custom Starfleet-branded local icon — same _local_sport_icon
            # resolver _CATEGORIES itself uses, reused here since these
            # slugs are built dynamically rather than living in that static
            # list.
            icon = _ss._local_sport_icon(local_icon_file, icon)
        extra.append({'slug': slug, 'label': meta['label'], 'icon': icon, 'tsdb_sport': ''})
    return base + extra


def _live_directory_titles():
    """Titles in the live DLHD 24/7 directory (what a channel is re-resolved against when it is played); [] when it cannot be read."""
    try:
        from starfleetscrapers.live import live_sources as _ls
        return [c.get('title', '') for c in (_ls.get_dlstreams_channels() or []) if c.get('title')]
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] live channel directory: %s' % e, xbmc.LOGINFO)
        return []


def _norm_title(t):
    return re.sub(r'[^a-z0-9]+', ' ', (t or '').lower()).strip()


def get_live_tv_channels_by_country(_overrides=None):
    """daddylive_channels.json's live_tv_by_country, merged with
    timstreams.json's (added 2026-08-03 - USA only) -> {country:
    [{'title','logo','playable_url'}]}. Both sources use the identical
    shape by design, so this just unions their per-country lists rather
    than picking one.

    The addresses baked into daddylive_channels.json were scraped long ago (the file is from the weekly scraper PC) and sit on stream
    hosts that have since disappeared, so they are never handed to the player: those channels come back without an address, which
    makes the plugin look the channel up by its name in the live DLHD directory when it is played. Only channels the directory still
    has are listed (a name that is not there could only fail); when the directory cannot be read, the whole catalogue is kept."""
    import difflib
    all_data = _fetch_all(_overrides)
    live = [_norm_title(t) for t in _live_directory_titles()]
    live_set = set(live)
    grouped = {}
    for source_name in ('daddylive_channels', 'timstreams'):
        data = all_data.get(source_name)
        baked = source_name != 'daddylive_channels'
        for country, chans in (data or {}).get('live_tv_by_country', {}).items():
            rows = []
            for c in (chans or []):
                if not c.get('playable_url'):
                    continue
                if not baked and live:
                    n = _norm_title(c.get('title', ''))
                    if n not in live_set and not difflib.get_close_matches(n, live, 1, 0.8):
                        continue
                rows.append({'title': c.get('title', ''), 'logo': c.get('logo', ''),
                             'playable_url': c.get('playable_url', '') if baked else ''})
            grouped.setdefault(country, []).extend(rows)
    return {k: v for k, v in grouped.items() if v}


