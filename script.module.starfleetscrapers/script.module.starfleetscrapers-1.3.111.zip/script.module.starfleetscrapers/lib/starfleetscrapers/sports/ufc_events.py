# -*- coding: utf-8 -*-
"""UFC events with their real card times and the fight card of each: the list of upcoming events, and for one event the Early Prelims /
Prelims / Main Card with every fight, both fighters' photos, ranks and records.

Sources: ufc.com/events (the event list, each card's start as a UTC timestamp, the event's photos) and ufc.com/event/<slug> (the card:
which fights are in which segment, weight class, ranks, fighter photos); ESPN's UFC scoreboard adds each fighter's record and a head shot.
Times are returned as UTC epoch seconds; the caller shows them in the viewer's own time zone.

list_events() -> [{'id', 'title', 'headline', 'early_ts', 'prelim_ts', 'main_ts', 'start_ts', 'venue', 'city', 'country', 'photos': [url, url]}]
card(event_id) -> {'id', 'title', ..., 'segments': [{'name', 'ts', 'fights': [{'weight', 'title_bout', 'rounds', 'result', 'a': fighter, 'b': fighter}]}]}
fighter = {'name', 'slug', 'rank', 'record', 'photo' (full body, ufc.com), 'head' (head shot, ESPN), 'flag', 'country'}"""
import calendar
import html as _html
import re
import time
import unicodedata

import xbmc

from starfleetscrapers.core import cache as _cache
from starfleetscrapers.core import http as requests

_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
_EVENTS = 'https://www.ufc.com/events'
_EVENT = 'https://www.ufc.com/event/%s'
_ESPN = 'https://site.api.espn.com/apis/site/v2/sports/mma/ufc/scoreboard?dates=%s&limit=100'
_LIST_TTL = 30 * 60
_CARD_TTL = 20 * 60
_mem = {}


def _log(msg):
    xbmc.log('[Starfleet/UFC] %s' % msg, xbmc.LOGINFO)


def _get(url, timeout=20):
    r = requests.get(url, headers={'User-Agent': _UA, 'Accept-Language': 'en'}, timeout=timeout)
    r.raise_for_status()
    return r.text


def _text(s):
    return re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', s or ''))).strip()


def _norm(name):
    s = unicodedata.normalize('NFKD', name or '')
    s = ''.join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r'[^a-z ]', '', s).strip()


def _kept(key, ttl, fetch):
    """Fresh copy when there is one, else the last good one (a source that is down must not empty the page)."""
    hit = _mem.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    try:
        val = fetch()
    except Exception as e:
        _log('%s failed: %s' % (key, str(e)[:100]))
        return hit[1] if hit else None
    if val:
        _mem[key] = (time.time(), val)
        return val
    return hit[1] if hit else None


def _event_title(slug, headline):
    m = re.match(r'ufc-(\d+)', slug)
    if m:
        return 'UFC %s: %s' % (m.group(1), headline) if headline else 'UFC %s' % m.group(1)
    if slug.startswith('ufc-fight-night'):
        return 'UFC Fight Night: %s' % headline if headline and 'TBD' not in headline else 'UFC Fight Night'
    return ('UFC: %s' % headline) if headline else slug


def _parse_list(page):
    out = []
    for art in re.split(r'<article class="c-card-event--result">', page)[1:]:
        slug = re.search(r'href="/event/([^"#?]+)"', art)
        if not slug:
            continue
        head = re.search(r'c-card-event--result__headline[^>]*>\s*<a[^>]*>([^<]+)</a>', art)
        ts = dict((k, int(v)) for k, v in re.findall(r'data-(main|prelims|early)-card-timestamp="(\d+)"', art))
        venue = re.search(r'taxonomy-term-title[^>]*>\s*<h5>([^<]+)</h5>', art)
        city = re.search(r'<span class="locality">([^<]*)</span>', art)
        country = re.search(r'<span class="country">([^<]*)</span>', art)
        photos = re.findall(r'<img[^>]+src="(https://[^"]*event_results_athlete_headshot[^"]+)"', art)
        main = ts.get('main', 0)
        if not main:
            continue
        starts = [v for v in (ts.get('early'), ts.get('prelims'), main) if v]
        headline = _text(head.group(1)) if head else ''
        out.append({
            'id': slug.group(1), 'headline': headline, 'title': _event_title(slug.group(1), headline),
            'early_ts': ts.get('early', 0), 'prelim_ts': ts.get('prelims', 0), 'main_ts': main, 'start_ts': min(starts),
            'venue': _text(venue.group(1)) if venue else '', 'city': _text(city.group(1)) if city else '',
            'country': _text(country.group(1)) if country else '', 'photos': photos[:2],
        })
    out.sort(key=lambda e: e['main_ts'])
    return out


def list_events(include_past_hours=8):
    """Upcoming UFC events (and one that is on right now), soonest first."""
    evs = _kept('list', _LIST_TTL, lambda: _parse_list(_get(_EVENTS))) or []
    floor = time.time() - include_past_hours * 3600
    return [e for e in evs if e['main_ts'] >= floor]


def _espn_records(main_ts):
    """name -> {'record', 'head', 'flag', 'country'} of every fighter ESPN lists around that event day."""
    day = lambda t: time.strftime('%Y%m%d', time.gmtime(t))
    rng = '%s-%s' % (day(main_ts - 86400), day(main_ts + 86400))

    def fetch():
        import json
        data = json.loads(_get(_ESPN % rng))
        found = {}
        for ev in data.get('events', []):
            for comp in ev.get('competitions', []):
                for c in comp.get('competitors', []):
                    ath = c.get('athlete') or {}
                    nm = _norm(ath.get('displayName') or ath.get('fullName'))
                    if not nm:
                        continue
                    rec = ''
                    for r in c.get('records') or []:
                        if r.get('type') == 'total' or r.get('name') == 'overall':
                            rec = r.get('summary', '')
                    flag = (ath.get('flag') or {})
                    found[nm] = {'record': rec, 'flag': flag.get('href', ''), 'country': flag.get('alt', ''),
                                 'head': 'https://a.espncdn.com/i/headshots/mma/players/full/%s.png' % c.get('id') if c.get('id') else ''}
        return found

    return _kept('espn_%s' % rng, _CARD_TTL, fetch) or {}


def _fighter(block, side, ranks, espn):
    corner = re.search(r'c-listing-fight__corner-name--%s">(.*?)</div>' % side, block, re.S)
    name, slug = '', ''
    if corner:
        slug_m = re.search(r'/athlete/([^"]+)"', corner.group(1))
        slug = slug_m.group(1) if slug_m else ''
        given = re.search(r'corner-given-name">([^<]*)<', corner.group(1))
        family = re.search(r'corner-family-name">([^<]*)<', corner.group(1))
        name = _text('%s %s' % (given.group(1) if given else '', family.group(1) if family else ''))
    img = re.search(r'c-listing-fight__corner-image--%s">.*?<img[^>]+src="([^"]+)"' % side, block, re.S)
    photo = _html.unescape(img.group(1)) if img else ''
    info = espn.get(_norm(name))
    if not info and name:                                   # a name written differently on the two sites: match on the family name
        fam = _norm(name).split(' ')[-1]
        hits = [v for k, v in espn.items() if k.split(' ')[-1] == fam]
        info = hits[0] if len(hits) == 1 else None
    info = info or {}
    return {'name': name, 'slug': slug, 'rank': ranks, 'record': info.get('record', ''), 'photo': photo,
            'head': info.get('head', ''), 'flag': info.get('flag', ''), 'country': info.get('country', '')}


def _parse_fights(section, espn, first_is_main):
    fights = []
    for n, block in enumerate(re.split(r'<div class="c-listing-fight" data-fmid=', section)[1:]):
        weight = re.search(r'c-listing-fight__class-text">([^<]*)<', block)
        weight = _text(weight.group(1)) if weight else ''
        row = re.search(r'c-listing-fight__ranks-row">(.*?)<div class="c-listing-fight__banner', block, re.S)
        ranks = [_text(x) for x in re.findall(r'<div class="js-listing-fight__corner-rank[^"]*">(.*?)</div>', row.group(1), re.S)] if row else []
        ra, rb = (ranks[0] if ranks else ''), (ranks[1] if len(ranks) > 1 else '')
        title = 'title' in weight.lower()
        outcomes = re.findall(r'c-listing-fight__outcome">\s*([^<]*?)\s*</div>', block)
        fights.append({
            'weight': weight, 'title_bout': title, 'rounds': 5 if (title or (first_is_main and n == 0)) else 3,
            'a': _fighter(block, 'red', ra, espn), 'b': _fighter(block, 'blue', rb, espn),
            'result': next((o for o in outcomes if o), ''),
        })
    return [f for f in fights if f['a']['name'] and f['b']['name']]


def card(event_id):
    """The fight card of one event, or None when the page cannot be read."""
    ev = next((e for e in list_events(24 * 14) if e['id'] == event_id), None)

    def fetch():
        page = _get(_EVENT % event_id)
        main_ts = ev['main_ts'] if ev else 0
        if not main_ts:
            m = re.search(r'data-timestamp="(\d+)"', page)
            main_ts = int(m.group(1)) if m else int(time.time())
        espn = _espn_records(main_ts)
        marks = [(m.start(), key) for key, m in ((k, re.search(r'id="%s"' % k, page)) for k in ('main-card', 'prelims-card', 'early-prelims')) if m]
        marks.sort()
        names = {'main-card': 'Main Card', 'prelims-card': 'Prelims', 'early-prelims': 'Early Prelims'}
        stamps = {'main-card': (ev or {}).get('main_ts', 0), 'prelims-card': (ev or {}).get('prelim_ts', 0), 'early-prelims': (ev or {}).get('early_ts', 0)}
        segs = []
        for i, (pos, key) in enumerate(marks):
            end = marks[i + 1][0] if i + 1 < len(marks) else len(page)
            fights = _parse_fights(page[pos:end], espn, key == 'main-card')
            if fights:
                segs.append({'name': names[key], 'ts': stamps[key], 'fights': fights})
        if not segs:
            return None
        out = dict(ev or {'id': event_id, 'title': _event_title(event_id, ''), 'headline': '', 'main_ts': main_ts, 'start_ts': main_ts,
                          'early_ts': 0, 'prelim_ts': 0, 'venue': '', 'city': '', 'country': '', 'photos': []})
        out['segments'] = segs
        return out

    return _kept('card_%s' % event_id, _CARD_TTL, fetch)
