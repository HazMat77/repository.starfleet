# -*- coding: utf-8 -*-
"""Which TV channels air a game: the "where to watch" listings of livesportsontv.com.

channels_for_game(sport_slug, title, start_ts) -> [{'name', 'short', 'logo', 'streaming'}]   the channels listed for the game ([] when none)
streams_for_channels(channels)                  -> [{'label', 'url', 'quality', 'language', 'source', 'logo'}]   live streams of those channels

The site is a server-rendered Next.js page: every team page (/team/<team>) and league page (/league/<league>) carries the games of the day
with their channels as JSON inside the page. Nothing is logged into and nothing is bypassed: the page is asked for like a browser asks for it,
and the listing is kept for 20 minutes. A page that does not load or does not carry the game gives [] (the callers then do what they did before).
"""
import json
import re
import time

import xbmc

from starfleetscrapers.core import http as requests

_BASE = 'https://www.livesportsontv.com'
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
_TTL = 20 * 60
_mem = {}
_LOGO = 'https://res.cloudinary.com/roninventure/image/upload/w_96,h_96,c_fit,q_auto,f_auto/icons/channels/%s.jpg'

# our sport / league slugs -> the site's league pages (a league page lists every game of the day, so one request covers a whole slate)
_LEAGUE = {'nhl': 'nhl', 'nba': 'nba', 'nfl': 'nfl', 'mlb': 'mlb', 'mls': 'mls', 'cfb': 'ncaa-football', 'ncaab': 'ncaa-basketball', 'ncaaw': 'ncaa-basketball-women'}

# words that say nothing about WHICH channel it is (country tags, quality tags)
_NOISE = {'hd', 'sd', 'uhd', 'usa', 'us', 'ca', 'canada', 'uk', 'au', 'nz', 'fr', 'the', 'channel', 'tv', 'live', 'feed'}
# streaming-only services that have no channel to play
_STREAM_ONLY = re.compile(r'\+|select|unlimited|prime|peacock|apple|paramount|fubo|hulu|dazn|max\b|app\b|now\b|flo|kayo|vix', re.I)


def _log(msg):
    xbmc.log('[Starfleet/TVListings] %s' % msg, xbmc.LOGINFO)


def _slug(s):
    return re.sub(r'-+', '-', re.sub(r'[^a-z0-9]+', '-', (s or '').lower().replace('&', ' and '))).strip('-')


def _flight_text(html):
    """The page's data: the pieces the server hands to the page's script, decoded and joined."""
    parts = []
    for m in re.finditer(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)</script>', html, re.S):
        try:
            parts.append(json.loads('"%s"' % m.group(1)))
        except ValueError:
            continue
    return ''.join(parts)


def _fixtures_of(url):
    """The games on one page of the site: [{'home', 'away', 'ts', 'league', 'channels': [...]}] (kept 20 minutes)."""
    hit = _mem.get(url)
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    out = []
    try:
        r = requests.get(url, headers={'User-Agent': _UA, 'Accept-Language': 'en-US,en;q=0.8'}, timeout=12)
        if r.status_code != 200:
            raise ValueError('HTTP %s' % r.status_code)
        txt = _flight_text(r.text)
        dec = json.JSONDecoder()
        seen = set()
        for m in re.finditer(r'\{"fixture_id":', txt):
            try:
                fx, _ = dec.raw_decode(txt, m.start())
            except ValueError:
                continue
            fid = fx.get('fixture_id')
            if fid in seen:
                continue
            seen.add(fid)
            try:
                ts = int(time.mktime(time.strptime(fx['date'][:19], '%Y-%m-%dT%H:%M:%S')) - time.timezone)   # the date is UTC
            except Exception:
                ts = 0
            chans = []
            for c in fx.get('channels') or []:
                name = (c.get('name') or '').strip()
                if not name:
                    continue
                sprite = (c.get('sprite_class') or '').replace('icons-channels-', '') or 'default'
                chans.append({'name': name, 'short': c.get('shortname') or name, 'logo': _LOGO % sprite,
                              'streaming': bool(_STREAM_ONLY.search(name))})
            out.append({'home': fx.get('home_team', ''), 'away': fx.get('visiting_team', ''), 'ts': ts, 'league': fx.get('league', ''), 'channels': chans})
    except Exception as e:
        _log('%s: %s' % (url, str(e)[:100]))
    _mem[url] = (time.time(), out)
    return out


def _teams_in(title):
    """The two team names of a game title ("Carolina Hurricanes vs Montreal Canadiens", "A at B", "A - B")."""
    parts = re.split(r'\s+(?:vs\.?|v|at|@|-|–)\s+', title or '', maxsplit=1, flags=re.I)
    return [p.strip() for p in parts if p.strip()] if len(parts) == 2 else []


def _nick(name):
    w = re.findall(r'[a-z0-9]+', (name or '').lower())
    return w[-1] if w else ''


def _is_team(fx_team, title_team):
    a, b = _slug(fx_team), _slug(title_team)
    return bool(a and b and (a == b or a in b or b in a or _nick(fx_team) == _nick(title_team)))


def channels_for_game(sport_slug, title, start_ts=0):
    """The channels the game airs on, as listed by the site ([] when it is not listed). start_ts (UTC epoch) picks the right game of a team that plays often."""
    teams = _teams_in(re.sub(r'\s+\d{1,3}\s*[-–:]\s*\d{1,3}\s+', ' vs ', title or ''))
    if len(teams) != 2:
        return []
    urls = []
    lg = _LEAGUE.get((sport_slug or '').lower())
    if lg:
        urls.append('%s/league/%s' % (_BASE, lg))
    urls += ['%s/team/%s' % (_BASE, _slug(t)) for t in teams]
    for url in urls:
        for fx in _fixtures_of(url):
            if not fx['channels']:
                continue
            ok = (_is_team(fx['home'], teams[0]) and _is_team(fx['away'], teams[1])) or (_is_team(fx['home'], teams[1]) and _is_team(fx['away'], teams[0]))
            if not ok:
                continue
            if start_ts and fx['ts'] and abs(int(start_ts) - fx['ts']) > 10 * 3600:
                continue
            return fx['channels']
    return []


# ── the channels as streams ──────────────────────────────────────────────────────────────────────────────────────────────────────

def _key(name):
    w = [x for x in re.findall(r'[a-z0-9]+', (name or '').lower()) if x not in _NOISE]
    return ''.join(w)


def streams_for_channels(channels, game_label='', limit=6):
    """Live streams of the listed channels, taken from the 24/7 channel directory. Each stream is named after its channel and carries the
    channel's logo. Streaming-only services (ESPN+, Sportsnet+...) have no live channel and are left out."""
    wanted = {}
    for c in channels or []:
        if c.get('streaming'):
            continue
        k = _key(c.get('name'))
        if k and k not in wanted:
            wanted[k] = c
    if not wanted:
        return []
    out = []
    try:
        from starfleetscrapers.live import live_sources as _ls
        found = []
        for ch in _ls._dlstreams_channels_raw():
            k = _key(ch.get('name'))
            if k in wanted and 'info' not in (ch.get('name') or '').lower():
                found.append((ch, wanted[k]))
        from concurrent.futures import ThreadPoolExecutor

        def one(pair):
            ch, c = pair
            try:
                url = _ls.resolve_dlstreams_channel(ch['id'])
            except Exception:
                url = None
            return pair, url
        if found:
            with ThreadPoolExecutor(max_workers=min(6, len(found))) as ex:
                for (ch, c), url in ex.map(one, found[:limit * 2]):
                    if url:
                        out.append({'label': '%s%s' % ('%s - ' % game_label if game_label else '', c['name']), 'url': url, 'quality': '',
                                    'language': 'FR' if re.search(r'\b(rds|tva|rdi|noovo|ici)\b', c['name'], re.I) else 'EN', 'source': 'TV channel',
                                    'logo': c['logo']})
    except Exception as e:
        _log('channel streams: %s' % str(e)[:100])
    return out[:limit]
