# -*- coding: utf-8 -*-
"""
resources/lib/javseen_sources.py — JAV (Japanese Adult Video) section, v2.

Replaces the earlier missav.ws-based JAV section (removed this session).
missav.ws's actual video CDN (surrit.com) needed a real desktop browser to
clear its Cloudflare wall, which can't run on a Firestick or other
ARM/Android Kodi device — the workaround (an always-on-PC "harvest
service") only worked for Kodi devices able to reach that PC's private LAN
address, which meant it never worked for anyone off that one home network.

javseen.tv doesn't have that problem, confirmed live:
  - Its own pages (sitemap + video detail pages) are NOT Cloudflare-walled
    — plain requests get real HTML back, no challenge page, no browser
    needed.
  - It doesn't host video itself. Each detail page embeds a resolution
    chain: detail page -> its own /embed/<id>/ page -> myserver.javseen.tv
    -> a rotating list of THIRD-PARTY embed hosts (mixdrop, streamtape,
    dood, mycloudz, turbovid, avgle, and others — varies per title).
    Every one of those is already a host this addon's own resolvers.py
    chain (Real-Debrid/AllDebrid/Premiumize/TorBox, then ResolveURL as a
    broad 50+-hoster fallback) already knows how to resolve — so there's
    no new Cloudflare-bypass problem to solve, just candidate-URL
    discovery; resolvers.py does the rest, same as it would for any other
    embed-aggregator source.
  - Its in-page search/browse grids are JS/AJAX-rendered (confirmed: no
    video links appear in the raw HTML of the homepage, a performer page,
    or a search-results page) and so aren't scrapable without a real
    browser — same limitation missav.ws's search had, for a different
    reason. "New / Latest" browsing (sitemap-based, no JS needed) is the
    only listing mode this version supports; there's no search.
"""
import re
import xbmc
import xbmcaddon
import xbmcvfs

from starfleetscrapers import host as _sfhost
ADDON = _sfhost.addon()
_PROFILE = _sfhost.profile()

from starfleetscrapers.core import cache as _cache
_cache.init(_PROFILE + '/cache.db')

JAVSEEN_BASE = 'https://javseen.tv'

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
    'Accept-Language': 'en-US,en;q=0.9',
}

PAGE_SIZE = 30
_LATEST_SITEMAP_URL = JAVSEEN_BASE + '/sitemaps/sitemap-videos-1.xml'
_LATEST_CACHE_KEY    = 'javseen_latest_all'
_LATEST_CACHE_TTL    = 6 * 3600  # sitemap itself only updates periodically

_RE_SITEMAP_ITEM = re.compile(
    r'<loc>https://javseen\.tv/(\d+)/([a-z0-9\-]+)/</loc>', re.IGNORECASE
)
_RE_IFRAME_SRC   = re.compile(r'<iframe[^>]+src="([^"]+)"', re.IGNORECASE)
_RE_PLAY_EMBED   = re.compile(r"playEmbed\('([^']+)'\)")
_RE_OG_IMAGE     = re.compile(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', re.IGNORECASE)
_RE_OG_DESC      = re.compile(r'<meta[^>]+property="og:description"[^>]+content="([^"]+)"', re.IGNORECASE)


def _get(url, referer='', timeout=15):
    from starfleetscrapers.core import http as requests
    headers = dict(_HEADERS)
    if referer:
        headers['Referer'] = referer
    try:
        r = requests.get(url, headers=headers, timeout=timeout)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log('[Starfleet/JAVSeen] fetch error %s: %s' % (url[:80], e), xbmc.LOGWARNING)
    return ''


def _slug_title(slug):
    return re.sub(r'\s+', ' ', slug.replace('-', ' ')).strip().title()


def _detail_url(vid, slug):
    return '%s/%s/%s/' % (JAVSEEN_BASE, vid, slug)


# ── "New / Latest" browsing (sitemap-based, no JS needed) ────────────────────

def _load_latest_all():
    """Full parsed sitemap-videos-1.xml — highest-numbered ids first (this
    sitemap file is confirmed live to already list newest-first), cached
    since it's a ~12MB fetch. Every function here derives its title from
    the URL slug directly (no per-item detail fetch) the same way ade.py's
    _minimal() does for ADE — real thumbnails/descriptions are fetched
    lazily per-item via get_javseen_detail(), same lazy-detail pattern the
    custom-skin category list already uses elsewhere in this addon."""
    cached = _cache.get(_LATEST_CACHE_KEY)
    if cached is not None:
        return cached or []
    xml_text = _get(_LATEST_SITEMAP_URL)
    items = []
    if xml_text:
        for m in _RE_SITEMAP_ITEM.finditer(xml_text):
            vid, slug = m.group(1), m.group(2)
            items.append({'id': vid, 'slug': slug, 'title': _slug_title(slug), 'source': 'javseen'})
    _cache.set(_LATEST_CACHE_KEY, items or False, _LATEST_CACHE_TTL)
    xbmc.log('[Starfleet/JAVSeen] sitemap parsed: %d items' % len(items), xbmc.LOGINFO)
    return items


def _populate_artwork(items):
    """Concurrently fetch each item's own detail page for its real cover
    art + description before the grid ever opens -- see javleak_sources.py's
    identical helper for the full reasoning (this site's sitemap-based
    listing is image-less the same way)."""
    if not items:
        return
    from concurrent.futures import ThreadPoolExecutor

    def _fetch(item):
        try:
            detail = get_javseen_detail(item['id'], item['slug'])
            if detail.get('fanart'):
                item['thumb']  = detail['fanart']
                item['fanart'] = detail['fanart']
            if detail.get('description'):
                item['plot'] = detail['description']
        except Exception:
            pass

    with ThreadPoolExecutor(max_workers=min(15, len(items))) as pool:
        list(pool.map(_fetch, items))


def browse_javseen_latest(page=1):
    """'New / Latest' listing: the site's own Latest Updates page (the newest titles, with cover pictures and when each was added);
    when its feed does not answer, the cached sitemap (which only holds titles up to 2024)."""
    from starfleetscrapers.adult import javcommon
    items = javcommon.latest_updates(JAVSEEN_BASE, 'javseen', page)
    if items:
        return items
    items = _load_latest_all()
    start = (page - 1) * PAGE_SIZE
    page_items = items[start:start + PAGE_SIZE]
    _populate_artwork(page_items)
    return page_items


def get_javseen_detail(vid, slug):
    """Lazily fetch a video's real thumbnail/description from its detail
    page's OG tags — called on-demand (e.g. when the custom-skin list's
    focus lands on an item), not for every item up front."""
    html = _get(_detail_url(vid, slug))
    if not html:
        return {}
    out = {}
    m = _RE_OG_IMAGE.search(html)
    if m:
        out['fanart'] = m.group(1)
    m = _RE_OG_DESC.search(html)
    if m:
        import html as _html_lib
        out['description'] = _html_lib.unescape(m.group(1))
    return out


# ── Play-time resolution ──────────────────────────────────────────────────────

_RE_B64_ATTR = re.compile(r'(?:data-[a-z\-]+|value|href)="([A-Za-z0-9+/]{24,}={0,2})"')


def _decoded_hosts(html):
    """Host addresses the embed page carries base64-encoded (aHR0cHM6Ly9... = https://...), in page order, duplicates dropped."""
    import base64
    out = []
    for token in _RE_B64_ATTR.findall(html or ''):
        try:
            url = base64.b64decode(token + '=' * (-len(token) % 4)).decode('utf-8', 'ignore').strip()
        except Exception:
            continue
        if url.startswith(('http://', 'https://')) and url not in out:
            out.append(url)
    return out


def _candidate_embed_urls(vid, slug):
    """Walk the real resolution chain confirmed live: detail page -> its
    own /embed/<id>/ page -> myserver.javseen.tv's play page -> the list of
    third-party embed hosts it offers ("Multi Server" dropdown). Returns
    that list of still-unresolved embed URLs, in the order the site itself
    presents them."""
    detail_url = _detail_url(vid, slug)
    html = _get(detail_url)
    if not html:
        return []

    m = _RE_IFRAME_SRC.search(html)
    if not m:
        return []
    embed_url = m.group(1)

    embed_html = _get(embed_url, referer=detail_url)
    if not embed_html:
        return []
    # the embed page now lists its hosts directly, each address base64-encoded in a data attribute
    direct = _decoded_hosts(embed_html)
    if direct:
        return direct
    myserver_urls = list(dict.fromkeys(_RE_PLAY_EMBED.findall(embed_html)))
    if not myserver_urls:
        return []

    myserver_html = _get(myserver_urls[0], referer=embed_url)
    if not myserver_html:
        return []
    candidates = list(dict.fromkeys(_RE_PLAY_EMBED.findall(myserver_html)))
    return candidates


def resolve_javseen_stream(vid, slug):
    """Try each candidate third-party embed host in turn. mycloudz.cc/
    cloudwish.xyz (and any other mirror of the same "VidHide" player
    template) get a direct plain-HTTP bypass first — confirmed live
    2026-08-04 that ResolveURL has no plugin support for them at all, so
    without this they'd always fall through to the generic chain below and
    fail. Everything else still goes through this addon's own resolvers.py
    chain (Real-Debrid/AllDebrid/Premiumize/TorBox, then ResolveURL) same
    as before. Returns '' if none do."""
    candidates = _candidate_embed_urls(vid, slug)
    if not candidates:
        from starfleetscrapers.adult import javcode
        return javcode.resolve_by_code(slug, skip='javseen')
    from starfleetscrapers.adult import javcommon, javcode
    return javcommon.first_playable(candidates, 'JAVSeen') or javcode.resolve_by_code(slug, skip='javseen')
