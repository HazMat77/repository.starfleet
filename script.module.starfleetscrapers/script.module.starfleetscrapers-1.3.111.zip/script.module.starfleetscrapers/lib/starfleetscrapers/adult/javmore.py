# -*- coding: utf-8 -*-
"""More JAV sites for javsites.py (same table shape): MissAV, Javtiful, JAVGG, HoHoJ, JavTrailers, Caribbeancom previews, the JavyNow
family (masutabe, iqoo, nukistream), YourAVHost, LoveH, Zmero and the HD-porn family (javhdporn, javdock, javxxx).

The Japanese-language sites list their titles in Japanese: javcommon.english() turns them into English (kept for 30 days) and puts the
product code in front, so every list reads the same. Plain-text parsing only: nothing here needs a browser."""
import re
from urllib.parse import quote_plus, urljoin

import xbmc

from starfleetscrapers.adult import javsites as J

_clean = J._clean
_get = J._get


def _abs(u, base):
    u = (u or '').strip()
    if u.startswith('//'):
        return 'https:' + u
    return urljoin(base, u) if u else ''


def _item(vid, slug, title, thumb, plot=''):
    d = {'id': vid, 'slug': slug, 'title': title, 'thumb': thumb, 'poster': thumb, 'fanart': thumb}
    if plot:
        d['plot'] = plot
    return d


# ── MissAV (missav.live, mirrors njavtv.com / missav.ws are tried by javsites._get) ────────────────────────────────

_MISS = 'https://missav.live'
_RE_SURRIT = re.compile(r"(https://surrit\.com/[0-9a-f\-]+/playlist\.m3u8)")


def _miss_parse(html):
    out, seen = [], set()
    for chunk in (html or '').split('class="thumbnail group"')[1:]:
        code = re.search(r'href="https://[^"/]+/(?:dm\d+/)?en/([a-z0-9\-]+)"', chunk)
        if not code or code.group(1) in seen:
            continue
        seen.add(code.group(1))
        img = re.search(r'data-src="(https://fourhoi\.com/[^"]+/cover-t\.jpg)"', chunk)
        title = re.search(r'class="text-secondary[^"]*"[^>]*>\s*([^<]+?)\s*</a>', chunk)
        dur = re.search(r'rounded-lg px-2 py-1[^>]*>\s*([\d:]+)\s*<', chunk)
        thumb = img.group(1) if img else ''
        out.append(_item(code.group(1), code.group(1), _clean(title.group(1)) if title else code.group(1).upper(), thumb,
                         ('Runtime %s' % dur.group(1)) if dur else ''))
    return out


def _miss_direct(vid, slug):
    from starfleetscrapers.adult import javcommon
    html, _f = _get('%s/en/%s' % (_MISS, slug), referer=_MISS + '/')
    if not html:
        return ''
    try:
        from starfleetresolve import common
        js = common.unpack_js(html)
    except Exception:
        js = ''
    m = _RE_SURRIT.search(js or '') or _RE_SURRIT.search(html.replace('\\/', '/'))
    if not m:
        return ''
    for ref in (_MISS + '/', 'https://missav.ws/'):
        url = J._pipe(m.group(1), ref)
        if javcommon._plays(url, ref):
            return url
    return ''


# ── Javtiful (the page asks its own playback endpoint for a signed file address) ───────────────────────────────────

_TIFUL = 'https://javtiful.com'
_RE_TIFUL = re.compile(r'<article class="video-card"[^>]*>(.*?)</article>', re.S)


def _tiful_parse(html):
    out, seen = [], set()
    for body in _RE_TIFUL.findall(html or ''):
        a = re.search(r'href="/video/(\d+)/([^"/]+)"', body)
        if not a or a.group(1) in seen:
            continue
        seen.add(a.group(1))
        img = re.search(r'data-front-lazy-src="([^"]+)"', body)
        title = re.search(r'class="video-card__title"[^>]*>([^<]+)<', body)
        dur = re.search(r'video-card__details"><strong>([^<]*)</strong>([\d:]+)', body)
        kind = re.search(r'video-card__type">([^<]+)<', body)
        thumb = _abs(img.group(1), _TIFUL) if img else ''
        bits = [b for b in ((dur.group(1) + ' ' + dur.group(2)) if dur else '', _clean(kind.group(1)) if kind else '') if b]
        out.append(_item(a.group(1), a.group(2), _clean(title.group(1)) if title else a.group(2), thumb, ' • '.join(bits)))
    return out


def _tiful_direct(vid, slug):
    import json
    from starfleetscrapers.core import http as requests
    page = '%s/video/%s/%s' % (_TIFUL, vid, slug)
    s = requests.session() if hasattr(requests, 'session') else None
    if s is None:
        return ''
    h = dict(J._HEADERS)
    try:
        r = s.get(page, headers=h, timeout=15)
        m = re.search(r'"playback":\{"endpoint":"([^"]+)","ticket":"([^"]+)"', r.text)
        if not m:
            return ''
        tok = s.get(_TIFUL + '/csrf-token', headers=dict(h, Referer=page), timeout=10).json().get('token', '')
        p = s.post(_TIFUL + m.group(1), data={'ticket': m.group(2)}, timeout=15,
                   headers=dict(h, Referer=page, **{'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-TOKEN': tok, 'Accept': 'application/json'}))
        srcs = (p.json() or {}).get('sources') or []
    except Exception as e:
        xbmc.log('[Starfleet/JAV] javtiful: %s' % e, xbmc.LOGINFO)
        return ''
    for src in sorted(srcs, key=lambda x: -int(x.get('size') or 0)):
        u = _abs(src.get('src'), _TIFUL)
        got = J._check_file(u, page, lenient=True) if u else ''
        if got:
            return got
    return ''


# ── JAVGG (the player hosts are in the page; the resolvers read them) ──────────────────────────────────────────────

_GG = 'https://javgg.net'
_RE_GG = re.compile(r'<article id="post-\d+" class="item movies">(.*?)</article>', re.S)


def _gg_parse(html):
    out, seen = [], set()
    for body in _RE_GG.findall(html or ''):
        a = re.search(r'href="https://javgg\.net/jav/([^"/]+)/"', body)
        if not a or a.group(1) in seen:
            continue
        seen.add(a.group(1))
        img = re.search(r'data-src="(https?://[^"]+)"', body) or re.search(r'<img[^>]+src="(https?://[^"]+)"', body)
        alt = re.search(r'alt="([^"]*)"', body)
        cap = re.search(r'class="titlecontent">([^<]+)<', body)
        date = re.search(r'<span>([A-Z][a-z]{2}\. \d{1,2}, \d{4})</span>', body)
        code = _clean(alt.group(1)) if alt else a.group(1).upper()
        title = code + ((' - ' + _clean(cap.group(1))) if cap else '')
        thumb = img.group(1) if img else ''
        out.append(_item(a.group(1), a.group(1), title, thumb, ('Added %s' % date.group(1)) if date else ''))
    return out


def _gg_candidates(vid, slug):
    html, _f = _get('%s/jav/%s/' % (_GG, slug), referer=_GG + '/')
    out = []
    for u in re.findall(r'<iframe[^>]+(?:src|data-src|data-lazy-src)="(https?://[^"]+)"', html or ''):
        if not J._is_ad(u):
            out.append(u)
    return list(dict.fromkeys(out))


# ── HoHoJ (the embed page names the HLS playlist) ──────────────────────────────────────────────────────────────────

_HOHOJ = 'https://hohoj.tv'
_RE_HOHOJ = re.compile(r'href="/video\?id=(\d+)"[^>]*>\s*<img[^>]+src="([^"]+)"[^>]*alt="([^"]*)"', re.S)


def _hohoj_parse(html):
    out, seen = [], set()
    for vid, thumb, alt in _RE_HOHOJ.findall(html or ''):
        if vid in seen:
            continue
        seen.add(vid)
        out.append(_item(vid, vid, _clean(alt) or vid, _abs(thumb, _HOHOJ)))
    return out


def _hohoj_direct(vid, slug):
    from starfleetscrapers.adult import javcommon
    html, _f = _get('%s/embed?id=%s' % (_HOHOJ, vid), referer='%s/video?id=%s' % (_HOHOJ, vid))
    m = re.search(r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)', (html or '').replace('\\/', '/'))
    if not m:
        return ''
    for ref in (_HOHOJ + '/', ''):
        url = J._pipe(m.group(1), ref) if ref else m.group(1)
        if javcommon._plays(url, ref):
            return url
    return ''


# ── JavTrailers (official previews: a playlist per title) ──────────────────────────────────────────────────────────

_TRAIL = 'https://javtrailers.com'
_RE_TRAIL = re.compile(r'<a href="/video/([a-z0-9_]+)" class="video-link" title="([^"]*)">(.*?)</a>', re.S)


def _trail_parse(html):
    out, seen = [], set()
    for vid, title, body in _RE_TRAIL.findall(html or ''):
        if vid in seen:
            continue
        seen.add(vid)
        img = re.search(r'<img src="(https?://[^"]+)"', body)
        alt = re.search(r'alt="([^"]*?) jav"', body)
        dur = re.search(r'duration-badge">([\d:]+)<', body)
        if re.search(r'\[VR\]|VR', title or ''):                  # VR scenes have no flat preview
            continue
        code = _clean(alt.group(1)) if alt else vid.upper()
        out.append(_item(vid, vid, '%s %s' % (code, _clean(title)), img.group(1) if img else '', ('Preview • full runtime %s' % dur.group(1)) if dur else 'Preview'))
    return out


def _trail_direct(vid, slug):
    from starfleetscrapers.adult import javcommon
    html, _f = _get('%s/video/%s' % (_TRAIL, slug), referer=_TRAIL + '/')
    urls = list(dict.fromkeys(re.findall(r'https?://[^\s"\'<>]+/playlist\.m3u8', (html or '').replace('\\/', '/'))))
    for u in sorted(urls, key=lambda x: 0 if 'javtrailers' in x else 1):
        for ref in (_TRAIL + '/', ''):
            url = J._pipe(u, ref) if ref else u
            if javcommon._plays(url, ref):
                return url
    return ''


# ── Caribbeancom (the site's own free preview clips) ───────────────────────────────────────────────────────────────

_CARIB = 'https://en.caribbeancom.com'
_RE_CARIB = re.compile(r'href="/eng/moviepages/(\d+-\d+)/index\.html"(.{0,1400})', re.S)


def _carib_parse(html):
    out, seen = [], set()
    for vid, body in _RE_CARIB.findall(html or ''):
        if vid in seen:
            continue
        seen.add(vid)
        img = re.search(r'<img[^>]+(?:data-src|src)="([^"]*(?:jacket|l_l|thumb|images)[^"]*)"', body) or re.search(r'<img[^>]+src="([^"]+)"', body)
        title = re.search(r'class="[^"]*(?:title|heading)[^"]*"[^>]*>\s*(?:<[^>]+>\s*)*([^<]{3,})<', body) or re.search(r'alt="([^"]{3,})"', body)
        thumb = _abs(img.group(1), _CARIB) if img else 'https://smovie.caribbeancom.com/sample/movies/%s/poster.jpg' % vid
        out.append(_item(vid, vid, 'Caribbeancom %s - %s' % (vid, _clean(title.group(1)) if title else 'preview'), thumb, 'Free preview clip'))
    return out


def _carib_direct(vid, slug):
    for name in ('480p.mp4', 'sample_m.mp4'):
        got = J._check_file('https://smovie.caribbeancom.com/sample/movies/%s/%s' % (slug, name), _CARIB + '/eng/moviepages/%s/index.html' % slug)
        if got:
            return got
    return ''


# ── masutabe.info / iqoo.me / nukistream.com (the JavyNow family: the same player behind each page) ──────────────

_MASU = 'https://masutabe.info'
_IQOO = 'https://iqoo.me'
_NUKI = 'https://www.nukistream.com'


def _family_parse(base, pat_id):
    rx = re.compile(r'<article>(.*?)</article>', re.S)

    def parse(html):
        out, seen = [], set()
        for body in rx.findall(html or ''):
            a = re.search(pat_id, body)
            if not a or a.group(1) in seen:
                continue
            seen.add(a.group(1))
            img = re.search(r'<img[^>]+src="([^"]+)"', body)
            ttl = re.search(r'<h[23]><a[^>]*>([^<]+)</a>', body) or re.search(r'alt="([^"]+)"', body)
            dur = re.search(r'class="duration">([^<]+)<', body)
            out.append(_item(a.group(1), a.group(1), _clean(ttl.group(1)) if ttl else a.group(1), _abs(img.group(1), base) if img else '',
                             ('Runtime %s' % dur.group(1).strip()) if dur else ''))
        return out
    return parse


def _family_candidates(base, detail):
    def fn(vid, slug):
        html, _f = _get(detail(vid), referer=base + '/')
        return [_abs(u, base) for u in re.findall(r'<iframe[^>]+src="((?:https?:)?//javynow\.com/player/\d+/?)"', html or '')]
    return fn


# ── youravhost.net, loveh.org, zmero.com ───────────────────────────────────────────────────────────────────────────

_YAV = 'https://youravhost.net'
_LOVEH = 'https://loveh.org'
_ZMERO = 'https://zmero.com'


def _yav_parse(html):
    out, seen = [], set()
    for vid, body in re.findall(r'href="/entry/(\d+)">(.{0,900}?)</h3>', html or '', re.S):
        if vid in seen:
            continue
        seen.add(vid)
        img = re.search(r'data-src="(https?://[^"]+)"', body)
        alt = re.search(r'alt="([^"]+)"', body)
        dur = re.search(r'video-duration">\s*([\d:]+)', body)
        out.append(_item(vid, vid, _clean(alt.group(1)) if alt else vid, img.group(1) if img else '', ('Runtime %s' % dur.group(1)) if dur else ''))
    return out


def _embed_candidates(base, detail):
    def fn(vid, slug):
        html, _f = _get(detail(vid, slug), referer=base + '/')
        out = []
        for u in re.findall(r'<iframe[^>]+(?:src|data-src)="((?:https?:)?//[^"]+)"', html or ''):
            u = _abs(u, base)
            if not J._is_ad(u) and base.split('//')[1] not in u and not re.search(r'pokoran|trafsa|trck|labadena|tsyndicate', u):
                out.append(u)
        return list(dict.fromkeys(out))
    return fn


def _loveh_parse(html):
    out, seen = [], set()
    for vid, title, body in re.findall(r'<a href="https://loveh\.org/\?p=(\d+)" title="([^"]*)"[^>]*>(.{0,1500})', html or '', re.S):
        if vid in seen:
            continue
        seen.add(vid)
        img = re.search(r'<img[^>]+src="(https?://[^"]+)"', body)
        out.append(_item(vid, vid, _clean(title) or vid, img.group(1) if img else ''))
    return out


def _zmero_parse(html):
    out, seen = [], set()
    for vid, title, body in re.findall(r'href="/entry/(\d+)/" class="card[^"]*" title="([^"]*)">(.{0,900}?)</a>', html or '', re.S):
        if vid in seen:
            continue
        seen.add(vid)
        img = re.search(r'<img[^>]+src="([^"]+)"', body)
        out.append(_item(vid, vid, _clean(title) or vid, _abs(img.group(1), _ZMERO) if img else '', 'Free preview clip'))
    return out


def _zmero_direct(vid, slug):
    html, _f = _get('%s/entry/%s/' % (_ZMERO, vid), referer=_ZMERO + '/')
    for u in re.findall(r'<source[^>]+src="((?:https?:)?//[^"]+\.mp4[^"]*)"', html or ''):
        got = J._check_file(_abs(u, _ZMERO), _ZMERO + '/', lenient=True)
        if got:
            return got
    return ''


# ── the HD-porn family: javhdporn.net, javdock.com, javxxx.me (their players are encrypted: playback goes by product code) ──

def _hdp_parse(base):
    def parse(html):
        out, seen = [], set()
        for slug, body in re.findall(r'<a [^>]*href="%s/video/([^"/]+)/"[^>]*>(.{0,1800}?)</a>' % re.escape(base), html or '', re.S):
            if slug in seen:
                continue
            seen.add(slug)
            img = re.search(r'data-lazy-src="(https?://[^"]+)"', body) or re.search(r'<img[^>]+src="(https?://[^"]+)"', body)
            alt = re.search(r'alt="([^"]+)"', body)
            out.append(_item(slug, slug, _clean(alt.group(1)) if alt else slug.replace('-', ' ').upper(), img.group(1) if img else ''))
        return out
    return parse


SITES_MORE = {
    'missav': {'label': 'MissAV', 'parse': _miss_parse, 'candidates': lambda v, s: [], 'direct': _miss_direct,
               'pages': lambda p: ['%s/dm539/en/new?page=%d' % (_MISS, max(p, 1))],
               'search': lambda q: '%s/en/search/%s' % (_MISS, quote_plus(q)), 'detail': lambda v, s: '%s/en/%s' % (_MISS, s), 'group': 'English'},
    'javtiful': {'label': 'Javtiful', 'parse': _tiful_parse, 'candidates': lambda v, s: [], 'direct': _tiful_direct,
                 'pages': lambda p: ['%s/videos?page=%d' % (_TIFUL, max(p, 1))],
                 'search': lambda q: '%s/search/videos?search_query=%s' % (_TIFUL, quote_plus(q)),
                 'detail': lambda v, s: '%s/video/%s/%s' % (_TIFUL, v, s), 'group': 'English'},
    'javgg': {'label': 'JAVGG', 'parse': _gg_parse, 'candidates': _gg_candidates,
              'pages': lambda p: ['%s/new-post/%s' % (_GG, '' if p <= 1 else 'page/%d/' % p)],
              'search': lambda q: '%s/?s=%s' % (_GG, quote_plus(q)), 'detail': lambda v, s: '%s/jav/%s/' % (_GG, s), 'group': 'English'},
    'hohoj': {'label': 'HoHoJ', 'parse': _hohoj_parse, 'candidates': lambda v, s: [], 'direct': _hohoj_direct,
              'pages': lambda p: ['%s/search?type=censored&order=latest&p=%d' % (_HOHOJ, max(p, 1))],
              'search': lambda q: '%s/search?text=%s' % (_HOHOJ, quote_plus(q)), 'detail': lambda v, s: '%s/video?id=%s' % (_HOHOJ, v), 'group': 'Translated'},
    'javtrailers': {'label': 'JavTrailers (previews)', 'parse': _trail_parse, 'candidates': lambda v, s: [], 'direct': _trail_direct,
                    'pages': lambda p: ['%s/videos%s' % (_TRAIL, '' if p <= 1 else '?page=%d' % p)],
                    'search': lambda q: '%s/search/%s' % (_TRAIL, quote_plus(q)), 'detail': lambda v, s: '%s/video/%s' % (_TRAIL, s), 'group': 'Previews'},
    'caribbean': {'label': 'Caribbeancom (previews)', 'parse': _carib_parse, 'candidates': lambda v, s: [], 'direct': _carib_direct,
                  'pages': lambda p: ['%s/eng/listpages/all%d.htm' % (_CARIB, max(p, 1))],
                  'search': lambda q: '%s/eng/search/?q=%s' % (_CARIB, quote_plus(q)),
                  'detail': lambda v, s: '%s/eng/moviepages/%s/index.html' % (_CARIB, s), 'group': 'Previews'},
    'masutabe': {'label': 'masutabe', 'parse': _family_parse(_MASU, r'href="/video/(\d+)/"'),
                 'candidates': _family_candidates(_MASU, lambda v: '%s/video/%s/' % (_MASU, v)),
                 'pages': lambda p: ['%s/' % _MASU] if p <= 1 else [],
                 'search': lambda q: '%s/search/%s/' % (_MASU, quote_plus(q)), 'detail': lambda v, s: '%s/video/%s/' % (_MASU, v), 'group': 'Translated'},
    'iqoo': {'label': 'iQoo', 'parse': _family_parse(_IQOO, r'href="/video/(\d+)/"'),
             'candidates': _family_candidates(_IQOO, lambda v: '%s/video/%s/' % (_IQOO, v)),
             'pages': lambda p: ['%s/%s' % (_IQOO, '' if p <= 1 else '?p=%d' % p)],
             'search': lambda q: '%s/search/%s/' % (_IQOO, quote_plus(q)), 'detail': lambda v, s: '%s/video/%s/' % (_IQOO, v), 'group': 'Translated'},
    'nukistream': {'label': 'nukistream', 'parse': _family_parse(_NUKI, r'href="/video\.php\?id=(\d+)"'),
                   'candidates': _family_candidates(_NUKI, lambda v: '%s/video.php?id=%s' % (_NUKI, v)),
                   'pages': lambda p: ['%s/%s' % (_NUKI, '' if p <= 1 else '?p=%d' % p)],
                   'search': lambda q: '%s/search.php?keyword=%s' % (_NUKI, quote_plus(q)), 'detail': lambda v, s: '%s/video.php?id=%s' % (_NUKI, v), 'group': 'Translated'},
    'youravhost': {'label': 'YourAVHost', 'parse': _yav_parse,
                   'candidates': _embed_candidates(_YAV, lambda v, s: '%s/entry/%s' % (_YAV, v)),
                   'pages': lambda p: ['%s/' % _YAV] if p <= 1 else ['%s/ama?page=%d' % (_YAV, p)],
                   'search': lambda q: '%s/search/%s' % (_YAV, quote_plus(q)), 'detail': lambda v, s: '%s/entry/%s' % (_YAV, v), 'group': 'Translated'},
    'loveh': {'label': 'LoveH', 'parse': _loveh_parse,
              'candidates': _embed_candidates(_LOVEH, lambda v, s: '%s/?p=%s' % (_LOVEH, v)),
              'pages': lambda p: ['%s/%s' % (_LOVEH, '' if p <= 1 else '?paged=%d' % p)],
              'search': lambda q: '%s/?s=%s' % (_LOVEH, quote_plus(q)), 'detail': lambda v, s: '%s/?p=%s' % (_LOVEH, v), 'group': 'Translated'},
    'javhdporn': {'label': 'JAV HD Porn', 'parse': _hdp_parse('https://www.javhdporn.net'), 'candidates': lambda v, s: [],
                  'pages': lambda p: ['https://www.javhdporn.net/v1/category/censored/%s' % ('' if p <= 1 else 'page/%d/' % p)],
                  'search': lambda q: 'https://www.javhdporn.net/?s=%s' % quote_plus(q), 'detail': lambda v, s: 'https://www.javhdporn.net/video/%s/' % s, 'group': 'English'},
    'javdock': {'label': 'JAVDock', 'parse': _hdp_parse('https://www.javdock.com'), 'candidates': lambda v, s: [],
                'pages': lambda p: ['https://www.javdock.com/v1/category/censored/%s' % ('' if p <= 1 else 'page/%d/' % p)],
                'search': lambda q: 'https://www.javdock.com/?s=%s' % quote_plus(q), 'detail': lambda v, s: 'https://www.javdock.com/video/%s/' % s, 'group': 'English'},
    'javxxx': {'label': 'JAVXXX', 'parse': _hdp_parse('https://www.javxxx.me'), 'candidates': lambda v, s: [],
               'pages': lambda p: ['https://www.javxxx.me/v1/category/censored/%s' % ('' if p <= 1 else 'page/%d/' % p)],
               'search': lambda q: 'https://www.javxxx.me/?s=%s' % quote_plus(q), 'detail': lambda v, s: 'https://www.javxxx.me/video/%s/' % s, 'group': 'English'},
}
