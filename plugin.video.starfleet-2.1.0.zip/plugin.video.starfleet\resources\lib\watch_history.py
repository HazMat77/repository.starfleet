# -*- coding: utf-8 -*-
"""
resources/lib/watch_history.py

Lightweight watch-progress tracker stored as JSON in the addon data directory.

Schema per entry:
  {
    "imdb_id":  "tt1234567",          # movie
    "season":   2,                    # tv (0 = movie)
    "episode":  4,                    # tv (0 = movie)
    "title":    "Breaking Bad",
    "watched":  true,                 # played past 90%
    "resume_s": 1234.5,               # resume point in seconds
    "total_s":  3600.0,
    "ts":       1719600000            # unix timestamp of last play
  }

Key = "tt1234567" for movies, "tt1234567:S02E04" for episodes.
"""

import json
import os
import time
import threading
import xbmc
import xbmcvfs

_LOCK = threading.Lock()
_DB   = None   # in-memory dict {key: entry}

def _db_path():
    profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/')
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'watch_history.json')


def _load():
    global _DB
    if _DB is not None:
        return _DB
    try:
        p = _db_path()
        if xbmcvfs.exists(p):
            with open(p, 'r', encoding='utf-8') as f:
                _DB = json.load(f)
        else:
            _DB = {}
    except Exception as e:
        xbmc.log('[Starfleet/WatchHistory] load error: %s' % e, xbmc.LOGWARNING)
        _DB = {}
    return _DB


def _save():
    try:
        with open(_db_path(), 'w', encoding='utf-8') as f:
            json.dump(_DB, f, indent=2)
    except Exception as e:
        xbmc.log('[Starfleet/WatchHistory] save error: %s' % e, xbmc.LOGWARNING)


def _key(imdb_id, season=0, episode=0):
    if season and episode:
        return '%s:S%02dE%02d' % (imdb_id, int(season), int(episode))
    return imdb_id or ''


# ── Public API ────────────────────────────────────────────────────────────────

def mark_played(imdb_id, title='', season=0, episode=0,
                resume_s=0.0, total_s=0.0, watched=False):
    """Record a play event. Call this when playback ends."""
    if not imdb_id:
        return
    k = _key(imdb_id, season, episode)
    with _LOCK:
        db = _load()
        prev = db.get(k, {})
        entry = {
            'imdb_id':  imdb_id,
            'season':   int(season),
            'episode':  int(episode),
            'title':    title or prev.get('title', ''),
            'watched':  watched or prev.get('watched', False),
            'resume_s': resume_s,
            'total_s':  total_s or prev.get('total_s', 0.0),
            'ts':       int(time.time()),
        }
        if total_s and total_s > 0:
            pct = resume_s / total_s
            if pct >= 0.9:
                entry['watched'] = True
                entry['resume_s'] = 0.0  # don't resume if finished
        db[k] = entry
        _save()
    xbmc.log('[Starfleet/WatchHistory] marked %s watched=%s resume=%.0fs' % (
        k, entry['watched'], entry['resume_s']), xbmc.LOGINFO)


def get_progress(imdb_id, season=0, episode=0):
    """
    Return (watched: bool, resume_s: float, percent: float).
    Returns (False, 0.0, 0.0) if not found.
    """
    if not imdb_id:
        return False, 0.0, 0.0
    k = _key(imdb_id, season, episode)
    with _LOCK:
        db = _load()
        entry = db.get(k)
    if not entry:
        return False, 0.0, 0.0
    resume_s = entry.get('resume_s', 0.0)
    total_s  = entry.get('total_s', 0.0)
    pct = (resume_s / total_s * 100) if total_s > 0 else 0.0
    return entry.get('watched', False), resume_s, pct


def is_watched(imdb_id, season=0, episode=0):
    watched, _, _ = get_progress(imdb_id, season, episode)
    return watched


def progress_label(imdb_id, season=0, episode=0):
    """Return a short label suffix like ' [✓]' or ' [47%]' or ''."""
    watched, resume_s, pct = get_progress(imdb_id, season, episode)
    if watched:
        return ' [W]'
    if resume_s > 60:
        return ' [%.0f%%]' % pct
    return ''


def start_playback_monitor(imdb_id, title='', season=0, episode=0):
    """
    Spawn a daemon thread that watches Kodi's player and records progress
    when playback stops.  Call this right after launching playback.
    """
    def _monitor():
        player = xbmc.Player()
        monitor = xbmc.Monitor()

        # Wait up to 15s for playback to start
        for _ in range(150):
            if player.isPlaying():
                break
            if monitor.waitForAbort(0.1):
                return

        if not player.isPlaying():
            return

        # Poll until playback ends
        while player.isPlaying() and not monitor.abortRequested():
            monitor.waitForAbort(5)

        # Collect final position
        try:
            total_s  = player.getTotalTime()
            resume_s = player.getTime()
        except Exception:
            total_s = resume_s = 0.0

        if total_s > 0:
            mark_played(imdb_id, title=title, season=season, episode=episode,
                        resume_s=resume_s, total_s=total_s)

    t = threading.Thread(target=_monitor, daemon=True)
    t.start()
