# -*- coding: utf-8 -*-
"""
resources/lib/sports_sources.py

Sports live-stream scraper.

Event sources (priority order):
  1. ESPN API          — NFL, NBA, MLB, NHL, CFB, NCAAB, CFL (official logos + scores)
  2. TheSportsDB       — UFC, Boxing, WWE (free tier, API key 3)
  3. istreameast.cx    — fallback / soccer / F1 / anything else

Stream sources (merged):
  1. istreameast.cx    — /links/{slug} stream table when live
  2. roxiestreams.info — sport-page links matched by event title

Cache: event list 10 min (live data), stream list 5 min
"""

import re
import datetime
import time
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

ISE_BASE   = 'https://istreameast.cx'
CRACK_BASE = 'https://crackstreams.mx'
ROXIE_BASE = 'https://roxiestreams.info'

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5, redirect=False)
        )
        _session.mount('https://', a)
    return _session


def _get(url, timeout=12):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _get_json(url, timeout=10):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()


def _ts_to_dt(date_str):
    """Parse ISO date string to (unix_timestamp, display_string). Returns (0, '') on failure."""
    try:
        dt = datetime.datetime.strptime(date_str[:19], '%Y-%m-%dT%H:%M')
        ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
        return ts, dt.strftime('%b %d %H:%M')
    except Exception:
        return 0, date_str


# ── Sport categories ──────────────────────────────────────────────────────────

_CATEGORIES = [
    {'slug': 'nfl',    'label': 'NFL',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nfl.png'},
    {'slug': 'nba',    'label': 'NBA',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nba.png'},
    {'slug': 'mlb',    'label': 'MLB',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/mlb.png'},
    {'slug': 'nhl',    'label': 'NHL',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'},
    {'slug': 'ufc',    'label': 'UFC / MMA',              'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ufc.png'},
    {'slug': 'boxing', 'label': 'Boxing',                 'icon': 'https://iili.io/3aqk6js.webp'},
    {'slug': 'soccer', 'label': 'Soccer',                 'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/fifa.png'},
    {'slug': 'f1',     'label': 'Formula 1',              'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/f1.png'},
    {'slug': 'cfb',    'label': 'College Football (CFB)', 'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaaf.png'},
    {'slug': 'ncaab',  'label': 'College Basketball (NCAAB)', 'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaab.png'},
    {'slug': 'cfl',    'label': 'CFL',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/cfl.png'},
    {'slug': 'wwe',    'label': 'WWE / Wrestling',        'icon': 'https://r2.thesportsdb.com/images/media/league/badge/r43xns1461424282.png/tiny'},
]

def get_sport_categories():
    return _CATEGORIES


# ── ESPN API ──────────────────────────────────────────────────────────────────

_ESPN_SPORTS = {
    'nfl':   ('football',   'nfl'),
    'nba':   ('basketball', 'nba'),
    'mlb':   ('baseball',   'mlb'),
    'nhl':   ('hockey',     'nhl'),
    'cfb':   ('football',   'college-football'),
    'ncaab': ('basketball', 'mens-college-basketball'),
    'cfl':   ('football',   'cfl'),
}
_ESPN_API = 'https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard'


def _espn_events(sport_slug):
    if sport_slug not in _ESPN_SPORTS:
        return []
    sport, league = _ESPN_SPORTS[sport_slug]
    url = _ESPN_API.format(sport=sport, league=league)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ESPN API (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in data.get('events', []):
        state   = ev.get('status', {}).get('type', {}).get('state', 'pre')
        is_live = (state == 'in')

        comp        = (ev.get('competitions') or [{}])[0]
        competitors = comp.get('competitors', [])
        venue       = comp.get('venue', {}).get('fullName', '')

        if len(competitors) >= 2:
            teams  = [c.get('team', {}).get('displayName', '') for c in competitors]
            scores = [c.get('score', '') for c in competitors]
            title_str = ' vs '.join(teams)
            if is_live and all(scores):
                title_str = '%s %s - %s %s' % (teams[0], scores[0], scores[1], teams[1])
        else:
            title_str = ev.get('name', ev.get('shortName', ''))

        logo = ''
        if competitors:
            logo = competitors[0].get('team', {}).get('logo', '')

        start_ts, datetime_str = _ts_to_dt(ev.get('date', ''))

        events.append({
            'id':       ev.get('id', ''),
            'slug':     ev.get('id', ''),
            'path':     '',
            'title':    title_str,
            'datetime': datetime_str,
            'league':   sport_slug.upper(),
            'logo':     logo,
            'is_live':  is_live,
            'start_ts': start_ts,
            'venue':    venue,
        })

    return events


# ── TheSportsDB (UFC / Boxing / WWE) ─────────────────────────────────────────

_TSDB_LEAGUES = {
    'ufc':    '4407',
    'boxing': '4414',
    'wwe':    '4412',
}
_TSDB_NEXT = 'https://www.thesportsdb.com/api/v1/json/3/eventsnextleague.php'


def _tsdb_events(sport_slug):
    league_id = _TSDB_LEAGUES.get(sport_slug)
    if not league_id:
        return []
    url = '%s?id=%s' % (_TSDB_NEXT, league_id)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in (data.get('events') or []):
        date_str = ev.get('dateEvent', '')
        time_str = (ev.get('strTime') or '00:00:00')[:8]
        try:
            dt = datetime.datetime.strptime('%s %s' % (date_str, time_str), '%Y-%m-%d %H:%M:%S')
            start_ts  = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
            datetime_str = dt.strftime('%b %d %H:%M')
        except Exception:
            start_ts, datetime_str = 0, date_str

        title_str = ev.get('strEvent', ev.get('strFilename', ''))
        logo = ev.get('strThumb', '') or ev.get('strBanner', '') or ''

        events.append({
            'id':       str(ev.get('idEvent', '')),
            'slug':     str(ev.get('idEvent', '')),
            'path':     '',
            'title':    title_str,
            'datetime': datetime_str,
            'league':   ev.get('strLeague', sport_slug.upper()),
            'logo':     logo,
            'is_live':  False,
            'start_ts': start_ts,
        })

    return events


# ── istreameast.cx events (fallback) ─────────────────────────────────────────

_RE_ISE_CARD = re.compile(
    r'class="event-card"[^>]*onclick="window\.location\.href=[^\']*\'(/links/([^\']+))\''
    r'[^>]*data-event-id="(\d+)"[^>]*data-start-ts="(\d+)"',
    re.IGNORECASE | re.DOTALL
)
_RE_ISE_LOGO = re.compile(
    r'<img[^>]+src="(https://[^"]+thesportsdb[^"]+|https://[^"]+espncdn[^"]+)"[^>]*alt="([^"]*)"',
    re.IGNORECASE
)
_RE_ISE_TITLE    = re.compile(r'class="event-title"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_DATETIME = re.compile(r'class="event-datetime"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_LEAGUE   = re.compile(r'class="event-league"\s*>(.*?)</div>', re.IGNORECASE | re.DOTALL)
_RE_ISE_STATUS   = re.compile(r'class="event-status\s+([^"]+)"\s*>(.*?)</span>', re.IGNORECASE)


def _parse_ise_block(block):
    m_title = _RE_ISE_TITLE.search(block)
    m_dt    = _RE_ISE_DATETIME.search(block)
    m_lg    = _RE_ISE_LEAGUE.search(block)
    m_st    = _RE_ISE_STATUS.search(block)
    m_logo  = _RE_ISE_LOGO.search(block)

    title    = _clean(m_title.group(1)) if m_title else ''
    dt_str   = _clean(m_dt.group(1))   if m_dt    else ''
    league   = _clean(_RE_STRIP.sub(' ', m_lg.group(1))) if m_lg else ''
    league   = re.sub(r'\s+\d+\s+(?:hours?|minutes?)\s+from\s+now.*', '', league, flags=re.IGNORECASE).strip()
    status_class = m_st.group(1).strip() if m_st else 'upcoming'
    is_live  = 'live' in status_class.lower()
    logo_url = m_logo.group(1) if m_logo else ''
    return title, dt_str, league, logo_url, is_live


def _ise_events(sport_slug):
    url = ISE_BASE + '/schedule/%s' % sport_slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE schedule error (%s): %s' % (sport_slug, e), xbmc.LOGERROR)
        try:
            html = _get(ISE_BASE + '/')
        except Exception:
            return []

    events = []
    seen   = set()

    for m in _RE_ISE_CARD.finditer(html):
        path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
        if event_id in seen:
            continue
        seen.add(event_id)
        block = html[m.end():m.end() + 900]
        title, dt_str, league, logo_url, is_live = _parse_ise_block(block)

        if sport_slug != 'nfl' and league and sport_slug.lower() not in league.lower():
            continue

        events.append({
            'id':       event_id,
            'slug':     slug,
            'path':     path,
            'title':    title or slug.replace('-', ' ').title(),
            'datetime': dt_str,
            'league':   league,
            'logo':     logo_url,
            'is_live':  is_live,
            'start_ts': int(start_ts_str),
        })

    return events


# ── Public event API ──────────────────────────────────────────────────────────

def get_sport_events(sport_slug='nfl'):
    ck = 'sports_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    events = []

    if sport_slug in _ESPN_SPORTS:
        events = _espn_events(sport_slug)

    if not events and sport_slug in _TSDB_LEAGUES:
        events = _tsdb_events(sport_slug)

    if not events:
        events = _ise_events(sport_slug)

    events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def get_all_events():
    ck = 'sports_events_all'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(ISE_BASE + '/')
        events = []
        seen   = set()

        for m in _RE_ISE_CARD.finditer(html):
            path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[m.end():m.end() + 900]
            title, dt_str, league, logo_url, is_live = _parse_ise_block(block)
            events.append({
                'id':       event_id,
                'slug':     slug,
                'path':     path,
                'title':    title or slug.replace('-', ' ').title(),
                'datetime': dt_str,
                'league':   league,
                'logo':     logo_url,
                'is_live':  is_live,
                'start_ts': int(start_ts_str),
            })

        events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
        _cache.set(ck, events, 10 * 60)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] all events error: %s' % e, xbmc.LOGERROR)
        return []


# ── Stream links ──────────────────────────────────────────────────────────────

# istreameast.cx stream table row
_RE_ISE_STREAM_ROW = re.compile(
    r'<tr[^>]*>\s*<td[^>]*>([^<]*)</td>\s*'
    r'<td[^>]*>([^<]*)</td>\s*'
    r'<td[^>]*>([^<]*)</td>\s*'
    r'<td[^>]*>([^<]*)</td>\s*'
    r'<td[^>]*>[^<]*</td>\s*'
    r'<td[^>]*>[^<]*</td>\s*'
    r'<td[^>]*>[^<]*</td>\s*'
    r'<td[^>]*>[^<]*</td>\s*'
    r'<td[^>]*><a[^>]+href="([^"]+)"[^>]*>',
    re.IGNORECASE | re.DOTALL
)


def _ise_event_streams(event_path, event_id=''):
    url = ISE_BASE + event_path
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE stream page error (%s): %s' % (event_path, e), xbmc.LOGERROR)
        return []

    streams = []
    for m in _RE_ISE_STREAM_ROW.finditer(html):
        streamer, channel, language, quality, watch_url = (
            m.group(1).strip(), m.group(2).strip(),
            m.group(3).strip(), m.group(4).strip(),
            m.group(5).strip()
        )
        if not watch_url or watch_url == '#':
            continue
        label = ('%s %s %s' % (streamer or channel, quality, language)).strip()
        streams.append({
            'label':    label or 'Stream',
            'url':      watch_url,
            'quality':  quality,
            'language': language,
            'source':   'StreamEast',
        })

    return streams


# Roxiestreams
_ROXIE_SLUGS = {
    'nfl':    'nfl',
    'nba':    'nba',
    'mlb':    'mlb',
    'nhl':    'nhl',
    'ufc':    'fighting',
    'boxing': 'fighting',
    'soccer': 'soccer',
    'wwe':    'wwe',
    'cfb':    'ncaaf',
    'ncaab':  'ncaab',
    'f1':     'f1',
    'cfl':    'cfl',
}

_RE_ROXIE_ROW = re.compile(
    r'<a[^>]+href="(/[^"#\s]{3,80})"[^>]*>\s*([^<]{3,120}?)\s*</a>',
    re.IGNORECASE
)


def _roxie_streams(sport_slug, event_title=''):
    slug = _ROXIE_SLUGS.get(sport_slug)
    if not slug:
        return []
    url = ROXIE_BASE + '/' + slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Roxie (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    streams = []
    title_words = [w.lower() for w in re.split(r'\W+', event_title) if len(w) > 3] if event_title else []

    for m in _RE_ROXIE_ROW.finditer(html):
        link_path = m.group(1)
        row_text  = _clean(m.group(2))

        # Skip nav/generic links
        if not row_text or len(row_text) < 4:
            continue
        skip_words = ('home', 'menu', 'schedule', 'login', 'register', 'about', 'contact')
        if row_text.lower() in skip_words:
            continue

        # If we have an event title, require at least one keyword match
        if title_words:
            row_lower = row_text.lower()
            if not any(w in row_lower for w in title_words):
                continue

        full_url = ROXIE_BASE + link_path if not link_path.startswith('http') else link_path
        streams.append({
            'label':    row_text,
            'url':      full_url,
            'quality':  '',
            'language': '',
            'source':   'RoxieStreams',
        })
        if len(streams) >= 8:
            break

    xbmc.log('[Starfleet/Sports] Roxie %s "%s": %d streams' % (sport_slug, event_title, len(streams)), xbmc.LOGINFO)
    return streams


def get_event_streams(event_path, event_id='', sport_slug='', title=''):
    """
    Fetch stream links for a specific event.
    Merges ISE streams (if event_path) + Roxiestreams (if sport_slug).
    Returns list of: {'label', 'url', 'quality', 'language', 'source'}
    """
    ck = ('sports_streams_%s' % event_id) if event_id else None
    if ck:
        cached = _cache.get(ck)
        if cached is not None:
            return cached

    streams = []

    if event_path:
        streams += _ise_event_streams(event_path, event_id)

    if sport_slug:
        streams += _roxie_streams(sport_slug, title)

    if ck:
        ttl = 5 * 60 if streams else 2 * 60
        _cache.set(ck, streams, ttl)

    xbmc.log('[Starfleet/Sports] event streams (%s/%s): %d total' % (sport_slug, event_id, len(streams)), xbmc.LOGINFO)
    return streams


# ── Crackstreams (supplementary) ─────────────────────────────────────────────

_RE_CRACK_CARD = re.compile(
    r'<a[^>]+href="(/watch-live/([^/\"]+)/([^/\"]+)/([^/\"]+)/(\d+))"[^>]*>'
    r'(?:(?!</a>).)*?'
    r'<div[^>]*class="[^"]*event-title[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE | re.DOTALL
)
_RE_CRACK_IMG = re.compile(
    r'<img[^>]+src="(https://[^"]+espncdn[^"]+)"[^>]+alt="([^"]+)"',
    re.IGNORECASE
)


def get_crack_events():
    ck = 'sports_crack_events'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(CRACK_BASE + '/')
        events = []
        seen   = set()

        for m in _RE_CRACK_CARD.finditer(html):
            path, sport = m.group(1), m.group(2)
            event_id    = m.group(5)
            title       = _clean(m.group(6))
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[max(0, m.start() - 400):m.start()]
            im    = _RE_CRACK_IMG.search(block)
            logo  = im.group(1) if im else ''
            events.append({
                'id':    event_id,
                'title': title,
                'sport': sport,
                'path':  path,
                'logo':  logo,
            })

        _cache.set(ck, events, 10 * 60)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] crackstreams events error: %s' % e, xbmc.LOGWARNING)
        return []
