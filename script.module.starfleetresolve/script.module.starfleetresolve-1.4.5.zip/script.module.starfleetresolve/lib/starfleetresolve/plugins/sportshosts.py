# -*- coding: utf-8 -*-
"""Sports embed hosts with a fixed, host-specific format (the generic page reader covers the rest)."""
from starfleetresolve import common, pagedecode
from starfleetresolve.plugins.base import Resolver


class GSports(Resolver):
    """gsports.lat event / player pages: the player script travels as <page>?v=font.woff2 (XOR 'gs99' + raw deflate)."""
    name = 'gsports'
    domains = ('gsports.lat',)
    priority = 'first'

    def resolve(self, url, referer=''):
        return pagedecode.font_payload(url.split('|')[0])

