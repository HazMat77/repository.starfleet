# -*- coding: utf-8 -*-
"""Where paired debrid accounts are kept: one small JSON file in this add-on's profile folder
(special://profile/addon_data/script.module.starfleetresolve/accounts.json). Thread-safe, never raises."""
import json
import os
import tempfile
import threading
import time

_lock = threading.RLock()
_cache = {'data': None, 'mtime': 0}


def _path():
    base = None
    try:
        import xbmcvfs
        base = xbmcvfs.translatePath('special://profile/addon_data/script.module.starfleetresolve/')
    except Exception:
        base = os.path.join(tempfile.gettempdir(), 'starfleetresolve')
    try:
        os.makedirs(base, exist_ok=True)
    except OSError:
        pass
    return os.path.join(base, 'accounts.json')


def _load():
    p = _path()
    try:
        m = os.path.getmtime(p)
    except OSError:
        return {}
    if _cache['data'] is not None and _cache['mtime'] == m:
        return _cache['data']
    try:
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
    except Exception:
        data = {}
    _cache['data'], _cache['mtime'] = data, m
    return data


def get(service):
    with _lock:
        return dict(_load().get(service) or {})


def put(service, **fields):
    with _lock:
        data = dict(_load())
        cur = dict(data.get(service) or {})
        cur.update(fields)
        data[service] = cur
        _write(data)


def clear(service):
    with _lock:
        data = dict(_load())
        data.pop(service, None)
        _write(data)


def _write(data):
    p = _path()
    tmp = p + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh)
        os.replace(tmp, p)
        _cache['data'], _cache['mtime'] = data, os.path.getmtime(p)
    except Exception:
        pass


def now():
    return int(time.time())
