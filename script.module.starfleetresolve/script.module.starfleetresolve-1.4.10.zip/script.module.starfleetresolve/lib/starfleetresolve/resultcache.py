# -*- coding: utf-8 -*-
"""Short-lived on-disk memory of resolved addresses (default 90 s), shared between processes. Every Kodi plugin run is a
fresh interpreter, so an in-memory cache never survives from one click to the next; this one does. prefetch() fills it in
the background (from a service, or while a list is on screen) so a click on a link that was already resolved is instant."""
import os
import json
import time
import tempfile
import threading

TTL = 90
MAX = 80
_lock = threading.Lock()


def enabled():
    return not os.environ.get('STARFLEET_NO_DISKCACHE')


def _path():
    try:
        import xbmcvfs
        base = xbmcvfs.translatePath('special://profile/addon_data/script.module.starfleetresolve/')
    except Exception:
        base = os.path.join(tempfile.gettempdir(), 'starfleetresolve')
    try:
        os.makedirs(base, exist_ok=True)
    except OSError:
        pass
    return os.path.join(base, 'resolve_cache.json')


def _load():
    try:
        with open(_path(), 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return {}


def get(url):
    if not enabled():
        return None
    rec = _load().get(url)
    if rec and time.time() - rec[0] < TTL:
        return rec[1]
    return None


def put(url, out):
    if not enabled() or not out:
        return
    with _lock:
        data = {k: v for k, v in _load().items() if time.time() - v[0] < TTL}
        data[url] = [time.time(), out]
        if len(data) > MAX:
            for k in sorted(data, key=lambda k: data[k][0])[:len(data) - MAX]:
                data.pop(k, None)
        try:
            tmp = _path() + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(data, fh)
            os.replace(tmp, _path())
        except Exception:
            pass


def clear():
    try:
        os.remove(_path())
    except OSError:
        pass
