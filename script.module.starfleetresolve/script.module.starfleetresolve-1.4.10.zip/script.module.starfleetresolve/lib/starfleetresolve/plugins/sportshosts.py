# -*- coding: utf-8 -*-
"""Sports embed hosts with a fixed, host-specific format (the generic page reader covers the rest)."""
from starfleetresolve import common, pagedecode
from starfleetresolve.plugins.base import Resolver


class GSports(Resolver):
    """gsports.lat event / player pages: the player script travels as <page>?v=font.woff2 (XOR 'gs99' + raw deflate)."""
    name = 'gsports'
    domains = ('gsports.lat',)
    priority = 'first'

    def resolve(self, url, referer=''):
        return pagedecode.font_payload(url.split('|')[0])



def _urlsafe_b64(piece):
    import base64
    piece = piece.replace('-', '+').replace('_', '/')
    try:
        return base64.b64decode(piece + '=' * (-len(piece) % 4)).decode('utf-8', 'replace')
    except Exception:
        return ''


def decode_piece_player(page):
    """Playlist address a player page assembles at run time: the script keeps the address in url-safe base64 pieces
    (var a='..'; var b='..') and joins decode(a)+decode(b)+... through a one-line helper."""
    import re
    m = re.search(r'function (\w+)\(s\)\{s=s\.replace', page or '')
    if not m:
        return ''
    fn = m.group(1)
    pieces = dict(re.findall(r"var (\w+)='([A-Za-z0-9_\-]+)';", page))
    expr = re.search(r'var \w+=((?:%s\(\w+\)\+?)+);' % re.escape(fn), page)
    if not expr:
        return ''
    names = re.findall(r'%s\((\w+)\)' % re.escape(fn), expr.group(1))
    url = ''.join(_urlsafe_b64(pieces.get(n, '')) for n in names)
    return url if url.startswith('http') else ''


class CdnLive(Resolver):
    """cdnlivetv.tv / cdnlivetv.is channel player pages: the page builds a signed playlist address out of base64 pieces."""
    name = 'cdnlive'
    domains = ('cdnlivetv.tv', 'cdnlivetv.is', 'cdn-live.tv')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        from urllib.parse import urlparse
        host = urlparse(link)
        origin = '%s://%s/' % (host.scheme or 'https', host.netloc)
        # the player pages answer on either spelling of the domain: try the one given, then its sibling
        tried = [link]
        for a, b in (('cdnlivetv.tv', 'cdnlivetv.is'), ('cdnlivetv.is', 'cdnlivetv.tv')):
            if a in link:
                tried.append(link.replace(a, b))
        for cand in tried:
            page = common.text(cand, referer=origin)
            stream = decode_piece_player(page) if page else ''
            if stream:
                piped = common.with_headers(stream, referer=origin)
                if common.playlist_ok(piped):
                    return piped
        return None


class TimEmbed(Resolver):
    """ehgembxe.cfd / epiembeds.online player frames (the TimStreams family): the page carries a byte-array script that asks a
    token address for the signed playlist, which is returned XOR-ed with the token (see pagedecode.array_token)."""
    name = 'timembed'
    domains = ('ehgembxe.cfd', 'epiembeds.online', 'embeds.gay')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        ref = referer if referer.startswith('http') else 'https://timst.top/'
        page = common.text(link, referer=ref)
        return pagedecode.array_token(page, link) if page else None
