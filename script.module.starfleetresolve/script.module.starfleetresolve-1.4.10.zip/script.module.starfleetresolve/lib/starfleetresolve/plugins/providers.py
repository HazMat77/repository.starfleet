# -*- coding: utf-8 -*-
"""Embed providers (movie / TV pages addressed by TMDB id) whose stream can be read without running their JavaScript.

VixSrc  : /api/movie/<id> (or /api/tv/<id>/<season>/<episode>) names the player page; the page holds the playlist address
          and its one-time token; the master playlist carries every quality and the audio tracks.
Vidbolt : /api/resolve?type=..&id=.. answers with HLS sources (1080p) ready to play."""
import re
import json
from urllib.parse import urlencode

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver


def _ids(url, pattern_movie, pattern_tv):
    m = re.search(pattern_tv, url)
    if m:
        return 'tv', m.group(1), m.group(2), m.group(3)
    m = re.search(pattern_movie, url)
    if m:
        return 'movie', m.group(1), None, None
    return None


class VixSrc(Resolver):
    name = 'vixsrc'
    domains = ('vixsrc.to', 'vixcloud.co')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        base = 'https://vixsrc.to'
        player = None
        m = re.search(r'/embed/(\d+)', link)
        if m:
            player = link
        else:
            ids = _ids(link, r'/movie/(\d+)', r'/tv/(\d+)/(\d+)/(\d+)')
            if not ids:
                return None
            kind, tid, s, e = ids
            api = base + ('/api/movie/%s' % tid if kind == 'movie' else '/api/tv/%s/%s/%s' % (tid, s, e))
            r = common.get(api, referer=link)
            try:
                src = r.json().get('src')
            except Exception:
                return None
            if not src:
                return None
            player = base + src if src.startswith('/') else src
        r = common.get(player, referer=base + '/')
        if r is None or r.status_code != 200:
            return None
        t = r.text
        tok = re.search(r"'token':\s*'([^']+)'", t)
        exp = re.search(r"'expires':\s*'([^']+)'", t)
        pl = re.search(r"url:\s*'(https://[^']+/playlist/\d+)'", t)
        if not (tok and exp and pl):
            return None
        q = {'token': tok.group(1), 'expires': exp.group(1)}
        asn = re.search(r"'asn':\s*'([^']*)'", t)
        if asn and asn.group(1):
            q['asn'] = asn.group(1)
        q['h'] = 1                                          # full-HD ladder
        return common.with_headers('%s?%s' % (pl.group(1), urlencode(q)), referer=base + '/')


class Vidbolt(Resolver):
    name = 'vidbolt'
    domains = ('vidbolt.xyz',)
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        ids = _ids(link, r'/movie/(\d+)', r'/tv/(\d+)/(\d+)/(\d+)')
        if not ids:
            return None
        kind, tid, s, e = ids
        q = {'type': kind, 'id': tid}
        if kind == 'tv':
            q.update({'season': s, 'episode': e})
        r = common.get('https://vidbolt.xyz/api/resolve?' + urlencode(q), referer='https://vidbolt.xyz/%s/%s' % (kind, tid))
        try:
            st = r.json().get('stream') or {}
        except Exception:
            return None
        srcs = [x for x in st.get('sources') or [] if x.get('url')]
        if not srcs:
            return None
        order = {'2160p': 4, '1440p': 3, '1080p': 2, '720p': 1}
        srcs.sort(key=lambda x: (x.get('kind') != 'hls', -order.get(x.get('quality'), 0)))
        h = st.get('headers') or {}
        return common.with_headers(srcs[0]['url'], referer=h.get('Referer') or 'https://vidbolt.xyz/', origin=h.get('Origin'))


class Vidrift(Resolver):
    """embed.vidrift.net/embed/movie/<tmdb> and /embed/tv/<tmdb>/<season>/<episode>: the page carries its stream list
    (original audio first, then dubs) as JSON; every address needs the embed host as referer."""
    name = 'vidrift'
    domains = ('vidrift.net',)
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        base = 'https://embed.vidrift.net'
        ids = _ids(link, r'/(?:embed/)?movie/(\d+)', r'/(?:embed/)?tv/(\d+)/(\d+)/(\d+)')
        if not ids:
            return None
        kind, tid, s, e = ids
        page = '%s/embed/%s' % (base, 'movie/%s' % tid if kind == 'movie' else 'tv/%s/%s/%s' % (tid, s, e))
        r = common.get(page, referer=base + '/')
        if r is None or r.status_code != 200 or '"orionStreams":' not in r.text:
            return None
        t = r.text
        try:
            streams = json.JSONDecoder().raw_decode(t[t.index('"orionStreams":') + 15:])[0]
        except Exception:
            return None
        best = None
        for st in streams:
            if not st.get('url'):
                continue
            if 'original' in (st.get('name') or '').lower():
                best = st
                break
            best = best or st
        if not best:
            return None
        u = best['url']
        u = base + u if u.startswith('/') else u
        return common.with_headers(u, referer=base + '/')



class GlobalNews(Resolver):
    """globalnews.ca/live/<region>/ (national plus 13 regional newscasts): the page names its media id, Corus' delivery
    service answers with the live manifest address (DRM-free; the same origin also serves DASH at the same path with
    .mpd instead of .m3u8)."""
    name = 'globalnews'
    domains = ('globalnews.ca',)
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        m = re.search(r'globalnews\.ca/+live(?:/+([a-z\-]+))?', link)
        if not m:
            return None
        page = common.text('https://globalnews.ca/live/%s/' % (m.group(1) or 'national'), referer='https://globalnews.ca/')
        mm = re.search(r'"mediaId":"([0-9a-f\-]{36})"', (page or '').replace('\/', '/'))
        if not mm:
            return None
        r = common.get('https://content.news.corusappservices.com/templates/media/smil/%s?delivery_protocol=hls' % mm.group(1),
                       referer='https://globalnews.ca/')
        src = re.search(r'<video[^>]+src="([^"]+)"', r.text if r is not None else '')
        if not src:
            return None
        out = common.with_headers(src.group(1), referer='https://globalnews.ca/')
        return out if common.playlist_ok(out) else None
