# -*- coding: utf-8 -*-
"""Live-sports player families.

extract_stream() reads the four ways these embed pages hide their playlist:
  window._econfig = '<shuffled base64 json>'      window.PP_CLAPPR_CONFIG = {...}
  var a=[bytes], k1, k2 (xor/sub blob)            plain src / streamUrl / "file": "...m3u8"."""
import re
import json
import math
import base64
import hashlib
from urllib.parse import urlparse, quote

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver


def econfig(html):
    m = re.search(r"window\._econfig\s*=\s*'([^']+)'", html)
    if not m:
        return None
    try:
        s = base64.b64decode(m.group(1)).decode('utf-8')
        size = math.ceil(len(s) / 4)
        chunks = [s[i * size:(i + 1) * size] for i in range(4)]
        out = [''] * 4
        for i, p in enumerate([2, 0, 3, 1]):
            c = chunks[i]
            out[p] = base64.b64decode(c[:3] + c[4:]).decode('utf-8')
        cfg = json.loads(base64.b64decode(''.join(out)).decode('utf-8'))
        u = cfg.get('stream_url') or cfg.get('url_nop2p') or cfg.get('stream_url_nop2p')
        return re.sub(r'(?<!:)/{2,}', '/', u) if u else None
    except Exception:
        return None


def pp_config(html):
    i = html.find('PP_CLAPPR_CONFIG')
    if i < 0:
        return None
    j = html.find('{', i)
    if j < 0:
        return None
    try:
        cfg, _ = json.JSONDecoder().raw_decode(html[j:])
        return cfg.get('srcBase') or cfg.get('src')
    except Exception:
        return None


_RE_XOR = re.compile(
    r'var\s+\w+\s*=\s*\[([\d,\s]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)\s*,'
    r'\s*\w+\s*=\s*""\s*,\s*\w+\s*;\s*for\s*\([^)]*\)\s*\{[^}]*?fromCharCode\('
    r'\(\(\s*\w+\[\w+\]\s*\^\s*\w+\s*\)\s*-\s*\w+\s*\+\s*(\d+)\s*\)\s*(?:&\s*(\d+)|%\s*(\d+))', re.S)


def xor_payload(html):
    m = _RE_XOR.search(html)
    if not m:
        return None
    try:
        arr = [int(n) for n in m.group(1).split(',') if n.strip()]
        k1, k2, add = int(m.group(2)), int(m.group(3)), int(m.group(4))
        mask = int(m.group(5)) if m.group(5) else None
        mod = int(m.group(6)) if m.group(6) else None
        dec = ''.join(chr(((n ^ k1) - k2 + add) & mask if mask is not None else ((n ^ k1) - k2 + add) % mod) for n in arr)
    except Exception:
        return None
    mu = re.search(r'SIGNED_URL\s*=\s*"([^"]+)"', dec) or re.search(r'\burl\s*=\s*"([^"]+)"', dec)
    if not mu:
        return None
    try:
        u = json.loads('"' + mu.group(1) + '"')
    except Exception:
        u = mu.group(1).replace('\\/', '/')
    return re.sub(r'(?<!:)/{2,}', '/', u)


def plain_m3u8(html):
    m = (re.search(r'src\s*=\s*"([^"]*\.m3u8[^"]*)"', html)
         or re.search(r'var\s+streamUrl\s*=\s*"([^"]+\.m3u8[^"]*)"', html)
         or re.search(r'"(?:file|source|src|url)"\s*:\s*"(https?:[^"]+\.m3u8[^"]*)"', html))
    return m.group(1).replace('\\/', '/') if m else None


def hexxor_payload(html):
    """var _c = "<hex>", var _k = "<hex>": the playlist address XOR-ed with the repeating key."""
    c = re.search(r'_c\s*=\s*"([0-9a-fA-F]{20,})"', html)
    k = re.search(r'_k\s*=\s*"([0-9a-fA-F]{8,})"', html)
    if not (c and k):
        return None
    try:
        cb, kb = bytes.fromhex(c.group(1)), bytes.fromhex(k.group(1))
        u = ''.join(chr(b ^ kb[i % len(kb)]) for i, b in enumerate(cb))
    except ValueError:
        return None
    return u if u.startswith('https://') else None


def extract_stream(html):
    return econfig(html) or pp_config(html) or xor_payload(html) or hexxor_payload(html) or plain_m3u8(html)


class ChFamily(Resolver):
    """nexa.st / kora.st / vertex.st and their mirrors: /ch?id=N (or channel.php?id=N) asks /api/player.php?id=N for
    {"url": <embed page>}, and that page carries the playlist."""
    name = 'nexa / kora / vertex channels'
    domains = ('nexa.st', 'kora.st', 'vertex.st')

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        m = re.search(r'[?&]id=(\d+)', link)
        org = common.origin_of(link)
        page = ''
        if not m:
            page = common.text(link, referer=link)
            m = re.search(r'window\.loadPlayerChannel\((\d+)\)', page)
            if not m:
                found = extract_stream(page)
                return common.with_headers(found, referer=org + '/', origin=org) if found else None
        r = common.get('%s/api/player.php?id=%s' % (org, m.group(1)), headers={'Referer': link, 'Origin': org})
        try:
            embed = r.json().get('url')
        except Exception:
            return None
        if not embed:
            return None
        html = common.text(embed, referer=org + '/', timeout=15)
        found = extract_stream(html)
        if not found:
            return None
        eo = common.origin_of(embed)
        return common.with_headers(found, referer=eo + '/', origin=eo)


_XYZ_SECRET = b'MySuperSecretKey123!'
_XYZ_SERVERS = ('xyzstreams.space', 'eu-4605069466.duckdns.org', 'hls.fancy-shark151.workers.dev')


class XyzStreams(Resolver):
    """xyzstreams.st/embedserver2?<id>: the player fetches /api/token (AES-256-CBC, key = SHA256 of a constant on the
    page); the decrypted token also works as ?token= on the playlist address."""
    name = 'xyzstreams'
    domains = ('xyzstreams.st',)

    def resolve(self, url, referer=''):
        sid = urlparse(url.split('|')[0]).query.split('&')[0]
        if not sid:
            return None
        try:
            import pyaes
        except Exception:
            return None
        key = hashlib.sha256(_XYZ_SECRET).digest()
        org = common.origin_of(url)
        for host in _XYZ_SERVERS:
            r = common.get('https://%s/api/token' % host, headers={'Referer': org + '/'}, timeout=6)
            try:
                d = r.json()
                dec = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, bytes.fromhex(d['iv'])))
                raw = dec.feed(bytes.fromhex(d['token'])) + dec.feed()
                tok = ''.join(c for c in raw.decode('utf-8', 'ignore') if 32 <= ord(c) < 127).strip()
                if not tok:
                    continue
                u = 'https://%s/%s/mono.ts.m3u8?server=2&token=%s' % (host, sid, quote(tok, safe=''))
                piped = common.with_headers(u, referer=org + '/', origin=org)
                rr = common.get(u, headers={'Referer': org + '/', 'Origin': org}, timeout=7)
                if rr is not None and rr.status_code == 200 and '#EXTM3U' in (rr.text or '')[:200]:
                    return piped
            except Exception:
                continue
        return None


class Brightcove(Resolver):
    """players.brightcove.net/<account>/<player>/index.html?videoId=<id> -> the account's Playback API."""
    name = 'brightcove'
    domains = ('players.brightcove.net',)

    def resolve(self, url, referer=''):
        m = re.search(r'players\.brightcove\.net/(\d+)/([^/]+)/index\.html\?.*?videoId=(\d+)', url)
        if not m:
            return None
        acct, player, vid = m.groups()
        js = common.text('https://players.brightcove.net/%s/%s_default/index.min.js' % (acct, player))
        pk = re.search(r'policyKey\s*:\s*"([^"]+)"', js or '')
        if not pk:
            return None
        r = common.get('https://edge.api.brightcove.com/playback/v1/accounts/%s/videos/%s' % (acct, vid),
                       headers={'Accept': 'application/json;pk=%s' % pk.group(1)})
        try:
            srcs = r.json().get('sources') or []
        except Exception:
            return None
        hls = [s['src'] for s in srcs if s.get('src', '').startswith('https') and 'm3u8' in s.get('src', '')]
        mp4 = sorted([s for s in srcs if s.get('container') == 'MP4' and s.get('src', '').startswith('https')],
                     key=lambda s: -(s.get('size') or 0))
        if mp4:
            return mp4[0]['src']
        return hls[0] if hls else None
