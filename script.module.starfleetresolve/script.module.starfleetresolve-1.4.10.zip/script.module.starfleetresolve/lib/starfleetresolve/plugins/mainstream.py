# -*- coding: utf-8 -*-
"""Big video sites with a public player API or plain page data: Dailymotion, Archive.org, Rutube, PeerTube, Vimeo,
XNXX, YouJizz, RedTube. Tried after the ResolveURL copy has failed (priority 'last')."""
import re
import json
from urllib.parse import urljoin, quote

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver


def _json(url, referer='', headers=None):
    r = common.get(url, referer=referer, headers=headers)
    if r is None or r.status_code != 200:
        return None
    try:
        return r.json()
    except Exception:
        return None


class Dailymotion(Resolver):
    name = 'dailymotion'
    domains = ('dailymotion.com', 'dai.ly')
    priority = 'last'

    def resolve(self, url, referer=''):
        m = re.search(r'(?:/video/|/embed/video/|dai\.ly/)(x[0-9a-z]+)', url)
        if not m:
            return None
        js = _json('https://www.dailymotion.com/player/metadata/video/' + m.group(1), referer='https://www.dailymotion.com/')
        if not js or js.get('error'):
            return None
        q = js.get('qualities') or {}
        for key in ('auto', '1080', '720', '480', '380', '240'):
            for s in q.get(key) or []:
                if s.get('url'):
                    return common.with_headers(s['url'], referer='https://www.dailymotion.com/')
        return None


class ArchiveOrg(Resolver):
    name = 'archive.org'
    domains = ('archive.org',)
    priority = 'last'
    _EXT = ('.mp4', '.m4v', '.mkv', '.webm', '.ogv', '.avi', '.mpeg', '.mpg', '.mov', '.mp3', '.flac', '.ogg', '.m4a', '.wav')

    def resolve(self, url, referer=''):
        base = url.split('|')[0]
        if re.search(r'archive\.org/download/[^/]+/.+', base):
            return base
        m = re.search(r'archive\.org/(?:details|embed)/([^/?#]+)', base)
        if not m:
            return None
        ident = m.group(1)
        js = _json('https://archive.org/metadata/' + ident)
        files = (js or {}).get('files') or []
        best, best_score = None, -1
        for f in files:
            name = f.get('name', '')
            ext = '.' + name.rsplit('.', 1)[-1].lower() if '.' in name else ''
            if ext not in self._EXT:
                continue
            size = int(f.get('size') or 0)
            fmt = (f.get('format') or '').lower()
            score = size
            if ext in ('.mp4', '.m4v') or 'h.264' in fmt or 'mpeg4' in fmt:
                score += 10 ** 12             # mp4 plays everywhere
            if f.get('source') == 'original':
                score += 10 ** 6
            if 'thumb' in name.lower() or name.lower().endswith('_sample.mp4'):
                continue
            if score > best_score:
                best, best_score = name, score
        if not best:
            return None
        return 'https://archive.org/download/%s/%s' % (ident, quote(best))


class Rutube(Resolver):
    name = 'rutube'
    domains = ('rutube.ru',)
    priority = 'last'

    def resolve(self, url, referer=''):
        m = re.search(r'rutube\.ru/(?:video|play/embed)/(?:private/)?([0-9a-f]{32})', url)
        if not m:
            return None
        js = _json('https://rutube.ru/api/play/options/%s/?no_404=true&referer=https%%3A%%2F%%2Frutube.ru' % m.group(1),
                   referer='https://rutube.ru/')
        vb = (js or {}).get('video_balancer') or {}
        u = vb.get('m3u8') or vb.get('default')
        return common.with_headers(u, referer='https://rutube.ru/') if u else None


class PeerTube(Resolver):
    name = 'peertube'
    domains = ()
    priority = 'last'

    def match(self, url):
        return bool(re.search(r'^https?://[^/]+/(?:videos/(?:embed|watch)|w)/[A-Za-z0-9-]{8,}', url.split('|')[0]))

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        m = re.search(r'^(https?://[^/]+)/(?:videos/(?:embed|watch)|w)/([A-Za-z0-9-]+)', link)
        if not m:
            return None
        js = _json('%s/api/v1/videos/%s' % (m.group(1), m.group(2)))
        if not js or 'uuid' not in js:
            return None
        pls = js.get('streamingPlaylists') or []
        if pls and pls[0].get('playlistUrl'):
            return pls[0]['playlistUrl']
        files = sorted(js.get('files') or [], key=lambda f: -int((f.get('resolution') or {}).get('id') or 0))
        return files[0].get('fileUrl') if files else None


class Vimeo(Resolver):
    name = 'vimeo'
    domains = ('vimeo.com',)
    priority = 'last'

    def resolve(self, url, referer=''):
        m = re.search(r'vimeo\.com/(?:video/|[^/]+/)?(\d{6,})(?:/([0-9a-f]{10}))?', url)
        if not m:
            return None
        cfg = 'https://player.vimeo.com/video/%s/config' % m.group(1)
        if m.group(2):
            cfg += '?h=' + m.group(2)
        js = _json(cfg, referer=referer or 'https://vimeo.com/')
        files = ((js or {}).get('request') or {}).get('files') or {}
        hls = files.get('hls') or {}
        cdns = hls.get('cdns') or {}
        pick = cdns.get(hls.get('default_cdn')) or (list(cdns.values())[0] if cdns else None)
        if pick and pick.get('url'):
            return pick['url']
        prog = sorted(files.get('progressive') or [], key=lambda p: -int(p.get('height') or 0))
        return prog[0]['url'] if prog else None


class XNXX(Resolver):
    name = 'xnxx'
    domains = ('xnxx.com', 'xvideos.com')
    priority = 'last'

    def resolve(self, url, referer=''):
        r = common.get(url.split('|')[0], referer=referer or common.origin_of(url) + '/')
        if r is None or r.status_code != 200:
            return None
        t = r.text
        for key in ('setVideoHLS', 'setVideoUrlHigh', 'setVideoUrlLow'):
            m = re.search(key + r"\('([^']+)'\)", t)
            if m:
                return common.with_headers(m.group(1), referer=common.origin_of(r.url) + '/')
        return None


class YouJizz(Resolver):
    name = 'youjizz'
    domains = ('youjizz.com',)
    priority = 'last'

    def resolve(self, url, referer=''):
        r = common.get(url.split('|')[0], referer=referer or 'https://www.youjizz.com/')
        if r is None or r.status_code != 200:
            return None
        t = r.text.replace('\\/', '/')
        best, bq = None, -1
        for m in re.finditer(r'"quality"\s*:\s*"?(\d+)"?\s*,\s*"filename"\s*:\s*"([^"]+)"', t):
            q, u = int(m.group(1)), m.group(2)
            if q > bq and not u.endswith('.m3u8') or (u.endswith('.m3u8') and best is None):
                best, bq = u, q
        if not best:
            m = re.search(r'"filename"\s*:\s*"([^"]+\.(?:mp4|m3u8)[^"]*)"', t)
            best = m.group(1) if m else None
        if not best:
            return None
        if best.startswith('//'):
            best = 'https:' + best
        return common.with_headers(best, referer='https://www.youjizz.com/')


class RedTube(Resolver):
    name = 'redtube'
    domains = ('redtube.com',)
    priority = 'last'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        m = re.search(r'[?&]id=(\d+)|redtube\.com/(\d+)', link)
        vid = (m.group(1) or m.group(2)) if m else None
        if not vid:
            return None
        r = common.get('https://embed.redtube.com/?id=' + vid, referer='https://www.redtube.com/')
        if r is None or r.status_code != 200:
            return None
        i = r.text.find('"mediaDefinitions"')
        if i < 0:
            return None
        j = r.text.find('[', i)
        depth, k = 0, j
        while k < len(r.text):
            c = r.text[k]
            depth += (c == '[') - (c == ']')
            k += 1
            if depth == 0:
                break
        try:
            defs = json.loads(r.text[j:k])
        except Exception:
            return None
        base = 'https://www.redtube.com'
        cands = []
        for d in sorted(defs, key=lambda d: d.get('format') != 'hls'):          # HLS first
            if d.get('videoUrl'):
                lst = _json(urljoin(base, d['videoUrl'].replace('\/', '/')), referer=base + '/')
                if isinstance(lst, list):
                    cands += [x for x in lst if x.get('videoUrl')]
                if cands:
                    break
        if not cands:
            return None
        cands.sort(key=lambda x: (x.get('format') != 'hls', -int(x['quality']) if str(x.get('quality') or '').isdigit() else 0))
        return common.with_headers(cands[0]['videoUrl'], referer=base + '/')


class Streamable(Resolver):
    name = 'streamable'
    domains = ('streamable.com',)
    priority = 'last'

    def resolve(self, url, referer=''):
        m = re.search(r'streamable\.com/(?:[a-z]/)?([a-z0-9]{4,8})', url)
        if not m:
            return None
        js = _json('https://api.streamable.com/videos/' + m.group(1), referer='https://streamable.com/')
        files = (js or {}).get('files') or {}
        for key in ('mp4', 'mp4-mobile'):
            u = (files.get(key) or {}).get('url')
            if u:
                return common.with_headers('https:' + u if u.startswith('//') else u, referer='https://streamable.com/')
        return None
