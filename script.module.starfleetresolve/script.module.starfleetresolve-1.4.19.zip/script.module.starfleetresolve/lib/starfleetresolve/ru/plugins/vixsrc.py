"""
    Starfleet Resolver plugin: VixSrc (vixsrc.to), the player behind several streaming sites (StreamingUnity and the VixCloud
    server of the MyFlixer / HiMovies / MoviesJoy / HDToday / Zoechip family).

    A page address (vixsrc.to/movie/<tmdb> or vixsrc.to/tv/<tmdb>/<season>/<episode>) is turned into the signed master playlist
    (AES-128 HLS, 1080p, several audio languages) the way the site's own player does it: /api/... gives the embed page and the embed
    page carries `window.masterPlaylist` (token, expiry, playlist address).
"""
import re

from starfleetresolve.ru import common
from starfleetresolve.ru.lib import helpers
from starfleetresolve.ru.resolver import ResolveUrl, ResolverError


class VixSrcResolver(ResolveUrl):
    name = 'VixSrc'
    domains = ['vixsrc.to']
    pattern = r'(?://|\.)(vixsrc\.to)/((?:movie|tv)/\d+(?:/\d+/\d+)?)'

    def get_media_url(self, host, media_id):
        ref = 'https://%s/' % host
        headers = {'User-Agent': common.RAND_UA, 'Referer': ref}
        data = self.net.http_GET('https://%s/api/%s' % (host, media_id), headers=headers).content
        src = re.search(r'"src"\s*:\s*"([^"]+)"', data)
        if not src:
            raise ResolverError('File not found')
        page = self.net.http_GET('https://%s%s' % (host, src.group(1).replace('\\/', '/')), headers=headers).content
        tok = re.search(r"'token':\s*'([^']+)'", page)
        exp = re.search(r"'expires':\s*'([^']+)'", page)
        base = re.search(r"url:\s*'(https://[^']+/playlist/\d+)'", page)
        if not (tok and exp and base):
            raise ResolverError('File not found')
        fhd = 'canPlayFHD = true' in page
        url = '%s?token=%s&expires=%s%s&lang=en' % (base.group(1), tok.group(1), exp.group(1), '&h=1' if fhd else '')
        return url + helpers.append_headers({'User-Agent': headers['User-Agent'], 'Referer': ref})

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/{media_id}')
