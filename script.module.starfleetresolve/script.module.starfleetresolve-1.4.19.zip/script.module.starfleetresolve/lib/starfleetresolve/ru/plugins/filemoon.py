"""
    Plugin for ResolveURL
    Copyright (C) 2026 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
from six.moves import urllib_parse
from starfleetresolve.ru import common
from starfleetresolve.ru.lib import helpers
from starfleetresolve.ru.resolver import ResolveUrl, ResolverError


class FileMoonResolver(ResolveUrl):
    name = 'FileMoon'
    domains = ['filemoon.org']
    pattern = r'(?://|\.)(filemoon\.org)/(\w{1,2}/[0-9a-zA-Z]+)'

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        ref = urllib_parse.urljoin(web_url, '/')
        headers = {'User-Agent': common.RAND_UA, 'Referer': ref}
        resp = self.net.http_GET(web_url, headers=headers)
        cookie = resp.get_cookies()
        r = re.search(r'data-hls-url="([^"]+)', resp.content)
        if r:
            headers.update({'Cookie': cookie})
            source = r.group(1)
            resp = self.net.http_GET(source, headers=headers, redirect=False)
            if not resp.get_redirect_url():
                return source + helpers.append_headers(headers)

        raise ResolverError('File Not Found or Removed')

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/{media_id}/embed')
