# -*- coding: utf-8 -*-
"""More player-page payloads seen on live sports embeds. Each function takes the page text and its address and returns a
playable 'url|headers' string or None. No JavaScript is run; every format is a few lines of arithmetic:

  layered   const _dd/_dk/_dri  (or _wd/_wk/_wri for a worker address, or _d/_k/_ri plus a window token for a php address)
            -> characters put back by index list, hex pairs XOR key, hex pairs -> chars, ROT13, reverse, base64
  const MODE / DIRECT_STREAM_URL / WORKER_URL   JSON worker that answers {success, stream}
  var sourceUrl = "..."                          plain address in a player frame
  <page>?v=font.woff2                            payload XOR 'gs99', raw-deflated, holds  source: '...'
  var a=[n,...], k1=.., k2=..  eval(...)         byte array, 256 or 65536 modulo"""
import re
import json
import zlib
import base64

from starfleetresolve import common


def _layered(encoded, xor_key, rev_indices):
    out = [''] * len(encoded)
    for i, c in enumerate(encoded):
        out[rev_indices[i]] = c
    s = ''.join(out)
    h = ''.join(chr(int(s[i:i + 2], 16) ^ xor_key) for i in range(0, len(s), 2))
    r13 = ''.join(chr(int(h[i:i + 2], 16)) for i in range(0, len(h), 2))
    r13 = r13.translate(str.maketrans('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
                                      'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm'))
    return base64.b64decode(r13[::-1] + '==').decode('utf-8')


def _ints(s):
    return [int(x) for x in re.findall(r'\d+', s)]


def _hdr(stream, page_url):
    o = common.origin_of(page_url)
    return common.with_headers(stream, referer=o + '/', origin=o)


def _worker(url, page_url):
    o = common.origin_of(page_url)
    r = common.get(url, referer=o + '/', headers={'Origin': o})
    try:
        js = r.json()
    except Exception:
        return None
    return js.get('stream') if js.get('success') else None


def layered(page, cur):
    m = re.search(r'const _dd\s*=\s*"([^"]+)"', page)
    k = re.search(r'const _dk\s*=\s*(\d+)', page)
    ri = re.search(r'const _dri\s*=\s*\[([^\]]+)\]', page)
    if m and k and ri:
        return _hdr(_layered(m.group(1), int(k.group(1)), _ints(ri.group(1))), cur)
    m = re.search(r'_wd\s*=\s*"([^"]+)"', page)
    k = re.search(r'_wk\s*=\s*(\d+)', page)
    ri = re.search(r'_wri\s*=\s*\[([^\]]+)\]', page)
    if m and k and ri:
        s = _worker(_layered(m.group(1), int(k.group(1)), _ints(ri.group(1))), cur)
        return _hdr(s, s) if s else None
    tok = re.search(r"window\['([^']+)'\]\s*=\s*'([^']+)'", page)
    d = re.search(r'const _d\s*=\s*"([^"]+)"', page)
    ri = re.search(r'const _ri\s*=\s*\[([^\]]+)\]', page)
    if tok and d and ri:
        kk = re.search(r'const _k\s*=\s*(\d+)', page)
        php = _layered(d.group(1), int(kk.group(1)) if kk else 42, _ints(ri.group(1)))
        o = common.origin_of(cur)
        r = common.get(php, referer=o + '/', headers={'Origin': o, 'X-Token': tok.group(2), tok.group(1): tok.group(2)})
        try:
            js = r.json()
        except Exception:
            return None
        return _hdr(js['stream'], cur) if js.get('success') and js.get('stream') else None
    return None


def mode_page(page, cur):
    if not re.search(r'const\s+MODE\s*=', page):
        return None
    mode = re.search(r'const\s+MODE\s*=\s*"([^"]+)"', page)
    if (mode.group(1) if mode else 'direct') == 'direct':
        m = re.search(r'const\s+DIRECT_STREAM_URL\s*=\s*"([^"]+)"', page)
        return _hdr(m.group(1), cur) if m else None
    m = re.search(r'const\s+WORKER_URL\s*=\s*"([^"]+)"', page)
    s = _worker(m.group(1), cur) if m else None
    return _hdr(s, cur) if s else None


def source_url(page, cur):
    m = re.search(r'var\s+sourceUrl\s*=\s*"([^"]+)"', page)
    return _hdr(m.group(1).replace('\\/', '/'), cur) if m else None


def font_payload(cur):
    """gsports-style: the player script is served as <page>?v=font.woff2, XORed with 'gs99' and raw-deflated."""
    r = common.get(cur + ('&' if '?' in cur else '?') + 'v=font.woff2', referer=cur)
    if r is None or r.status_code != 200 or not r.content:
        return None
    key = b'gs99'
    try:
        script = zlib.decompress(bytes(c ^ key[i % 4] for i, c in enumerate(r.content)), -15).decode('utf-8', 'replace')
    except Exception:
        return None
    m = re.search(r"source:\s*'([^']+)'", script) or re.search(r'source:\s*"([^"]+)"', script)
    return _hdr(m.group(1), cur) if m else None


def array_modulo(page, cur):
    m = re.search(r'var\s+\w+\s*=\s*\[([\d,\s]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*""\s*,\s*\w+\s*;.{0,260}?'
                  r'\(\(\s*\w+\[\w+\]\s*\^\s*\w+\s*\)\s*-\s*\w+\s*\+\s*(65536|256)\s*\)\s*%\s*(?:65536|256)', page, re.S)
    if not m:
        return None
    mod = int(m.group(4))
    text = ''.join(chr(((n ^ int(m.group(2))) - int(m.group(3)) + mod) % mod) for n in _ints(m.group(1)))
    mm = re.search(r'(?:SIGNED_URL|\burl)\s*=\s*"([^"]+)"', text)
    if not mm:
        return None
    return _hdr(re.sub(r'(?<!:)/{2,}', '/', mm.group(1).replace('\\/', '/')), cur)


_RE_ARRAY3 = re.compile(r'(?<!\w)(?:var\s+)?\w+\s*=\s*\[([\d,\s]+)\][,\s]*(?:var\s+)?\w+\s*=\s*(\d+)[,\s]*(?:var\s+)?\w+\s*=\s*(\d+)')


def array_token(page, cur):
    """var a=[n,...], k1=.., k2=..  -> a script that calls loadStreamUrl("<host>/p/<token>", ...): that address answers with
    bytes whose first byte s seeds the cipher; byte i is  b[i] ^ token[(i-1) % len] ^ ((s + i - 1) & 255)  and the text is
    the signed playlist address (ehgembxe / embeds.gay style player frames)."""
    for m in _RE_ARRAY3.finditer(page):
        nums = _ints(m.group(1))
        if len(nums) < 40:
            continue
        k1, k2 = int(m.group(2)), int(m.group(3))
        text = ''.join(chr(((n ^ k1) - k2 + 256) & 255) for n in nums)
        direct = re.search(r'(?:file|source|SIGNED_URL|url)\s*[:=]\s*"(https?:[^"]+)"', text)
        if direct and 'loadStreamUrl' not in text:
            return _hdr(direct.group(1).replace('\\/', '/'), cur)
        t = re.search(r'loadStreamUrl\(\s*["\']([^"\']+)["\']', text)
        if not t:
            continue
        addr = t.group(1)
        o = common.origin_of(cur)
        r = common.get(addr, referer=o + '/', headers={'Origin': o})
        if r is None or r.status_code != 200 or len(r.content) < 8:
            continue
        b = r.content
        token = addr.rsplit('/', 1)[-1]
        s = b[0]
        out = ''.join(chr(b[i] ^ ord(token[(i - 1) % len(token)]) ^ ((s + i - 1) & 255)) for i in range(1, len(b)))
        if out.startswith('http'):
            return _hdr(out.strip(), cur)
    return None


def decode(page, cur):
    for fn in (layered, mode_page, source_url, array_modulo, array_token):
        try:
            out = fn(page, cur)
        except Exception as e:
            common.log('pagedecode %s failed: %s' % (fn.__name__, e))
            out = None
        if out and out.startswith('http'):
            return out
    return None
