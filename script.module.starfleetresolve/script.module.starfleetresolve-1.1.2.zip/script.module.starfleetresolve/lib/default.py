# -*- coding: utf-8 -*-
"""Entry point for plugin://script.module.starfleetresolve/?mode=...  (used by this add-on's Settings page)
    mode=pair&service=realdebrid|alldebrid|premiumize|torbox|debridlink|offcloud   pair an account (code + address dialog)
    mode=reset&service=...                                                          forget an account
    mode=status                                                                     show the paired accounts
    mode=import                                                                     bring accounts over from the Starfleet plugin / ResolveURL"""
import sys
from urllib.parse import parse_qsl

import xbmcgui


def _notify(msg):
    xbmcgui.Dialog().notification('Starfleet Resolver', msg, xbmcgui.NOTIFICATION_INFO, 5000)


def main():
    from starfleetresolve import debrid
    from starfleetresolve.debrid import importer
    q = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}
    mode, sid = q.get('mode', ''), q.get('service', '')
    names = {s[0]: s[1] for s in debrid.services()}
    if mode == 'pair' and sid in names:
        ok = debrid.pair(sid)
        _notify('%s paired' % names[sid] if ok else '%s not paired' % names[sid])
    elif mode == 'reset' and sid in names:
        debrid.reset(sid)
        _notify('%s account removed' % names[sid])
    elif mode == 'import':
        res = {}
        for fn in (importer.import_from_plugin, importer.import_from_resolveurl):
            res.update({k: v for k, v in fn(force=False).items() if v == 'imported'})
        _notify('Imported: %s' % (', '.join(names[k] for k in res) or 'nothing new'))
    elif mode == 'status':
        st = debrid.status()
        lines = ['%s: %s%s' % (names[k], v.get('user') or '?', '' if v.get('premium', True) else ' (not premium)') for k, v in st.items()]
        xbmcgui.Dialog().textviewer('Debrid accounts', '\n'.join(lines) or 'No debrid account is paired yet.')


if __name__ == '__main__':
    main()
