# -*- coding: utf-8 -*-
from starfleetresolve.plugins.goat import Goat
from starfleetresolve.plugins.embedsports_me import EmbedSportsMe
from starfleetresolve.plugins.players import StreameCenter, Gooz, Rocky, Vidload, Gbsagbo, FilecodePlayer, SiteOwn
from starfleetresolve.plugins.legacy import MixDrop, Dood
from starfleetresolve.plugins.streamtape import StreamTape
from starfleetresolve.plugins.voe import Voe
from starfleetresolve.plugins.livesites import ChFamily, XyzStreams, Brightcove
from starfleetresolve.plugins.dlhd import Dlhd
from starfleetresolve.plugins.adult_sites import Eporner, Pornhub, XHamster
from starfleetresolve.plugins.mainstream import Dailymotion, ArchiveOrg, Rutube, PeerTube, Vimeo, XNXX, YouJizz, RedTube, Streamable
from starfleetresolve.plugins.filehosts import (Pixeldrain, Gofile, MediaFire, Dropbox, GoogleDrive, Sendspace,
                                                UploadEe, FilesFm, XFileSharing, Mp4upload, YourUpload, Sendvid)

# order matters only between resolvers that match the same address
ALL = [Goat(), EmbedSportsMe(), StreameCenter(), Gooz(), Rocky(), Vidload(), Gbsagbo(), FilecodePlayer(), SiteOwn(),
       Voe(), ChFamily(), XyzStreams(), Brightcove(), Dlhd(), MixDrop(), Dood(), StreamTape(),
       Pixeldrain(), Gofile(), MediaFire(), Dropbox(), Sendspace(), UploadEe(), FilesFm(),
       Eporner(), Pornhub(), XHamster(),
       GoogleDrive(), XFileSharing(), Mp4upload(), YourUpload(), Sendvid(),
       Dailymotion(), ArchiveOrg(), Rutube(), PeerTube(), Vimeo(), XNXX(), YouJizz(), RedTube(), Streamable()]
