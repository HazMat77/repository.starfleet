# -*- coding: utf-8 -*-
"""Debrid accounts for the Starfleet resolver: pair a service, then turn hoster links into direct links through it.

    from starfleetresolve import debrid
    debrid.pair('offcloud')                 # shows a code + address, waits for approval, stores the account
    debrid.authorized()                     # ['realdebrid', 'offcloud', ...]
    debrid.unrestrict('https://rapidgator.net/file/..')      # ('https://...direct', 'realdebrid') or None
    debrid.supports(url)                    # services (paired) whose host list covers this address
    debrid.status()                         # {'realdebrid': {'user': ..., 'premium': True, ...}, ...}

Services: Real-Debrid, AllDebrid, Premiumize, TorBox, Debrid-Link, Offcloud."""
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from starfleetresolve import common
from starfleetresolve.debrid import store, importer
from starfleetresolve.debrid.services import ALL, BY_ID

DEFAULT_ORDER = ['realdebrid', 'alldebrid', 'premiumize', 'torbox', 'debridlink', 'offcloud']


def service(sid):
    importer.ensure()
    return BY_ID.get(sid)


def services():
    """[(id, name, authorized)] for every supported service."""
    importer.ensure()
    return [(s.id, s.name, s.authorized()) for s in ALL]


def authorized():
    importer.ensure()
    return [s.id for s in ALL if s.authorized()]


def order():
    saved = store.get('prefs').get('order')
    base = [i for i in (saved or DEFAULT_ORDER) if i in BY_ID]
    return base + [i for i in DEFAULT_ORDER if i not in base]


def set_order(ids):
    store.put('prefs', order=[i for i in ids if i in BY_ID])


def reset(sid):
    s = BY_ID.get(sid)
    if s:
        s.reset()
        store.clear(sid + '_hosts')


def status():
    importer.ensure()
    out = {}
    for s in ALL:
        if s.authorized():
            try:
                out[s.id] = s.account() or {'user': '?'}
            except Exception:
                out[s.id] = {'user': '?'}
    return out


# ── pairing ──────────────────────────────────────────────────────────────────

class _KodiUI(object):
    """Progress dialog with the address, the code and a countdown; Cancel stops the pairing."""

    def __init__(self, title):
        import xbmcgui
        self._dlg = xbmcgui.DialogProgress()
        self._title = title

    def start(self, info):
        self._dlg.create(self._title, 'Go to: %s\nEnter code: %s' % (info.get('display_url') or info['url'], info['code']))

    def update(self, pct, info, remaining):
        self._dlg.update(pct, 'Go to: %s\nEnter code: %s\nWaiting for approval... %ds' % (
            info.get('display_url') or info['url'], info['code'], remaining))

    def cancelled(self):
        return self._dlg.iscanceled()

    def close(self):
        try:
            self._dlg.close()
        except Exception:
            pass


class _TextUI(object):
    """No Kodi (tests, scripts): print the instructions."""

    def __init__(self, title):
        self._title = title

    def start(self, info):
        print('%s: open %s and enter code %s' % (self._title, info.get('display_url') or info['url'], info['code']))

    def update(self, pct, info, remaining):
        pass

    def cancelled(self):
        return False

    def close(self):
        pass


def start_pairing(sid):
    """First half of pairing for callers with their own UI: returns the dict(url, code, expires_in, interval, state)."""
    s = BY_ID.get(sid)
    return s.start_pairing() if s else None


def poll_pairing(sid, state):
    """True when paired, False while waiting, None when the code expired / was refused."""
    s = BY_ID.get(sid)
    return s.poll_pairing(state) if s else None


def pair(sid, ui=None):
    """Run the whole device-code pairing for `sid`. Returns True when the account is stored."""
    s = BY_ID.get(sid)
    if s is None:
        return False
    info = s.start_pairing()
    if not info:
        return False
    if ui is None:
        try:
            ui = _KodiUI('Starfleet - pair %s' % s.name)
        except Exception:
            ui = _TextUI('Starfleet - pair %s' % s.name)
    total = int(info.get('expires_in', 600))
    interval = max(int(info.get('interval', 5)), 2)
    end = time.time() + total
    ok = False
    try:
        ui.start(info)
        while time.time() < end:
            if ui.cancelled():
                break
            res = s.poll_pairing(info['state'])
            if res:
                ok = True
                break
            if res is None:
                break
            for _ in range(interval * 2):
                if ui.cancelled():
                    break
                ui.update(int(100 * (end - time.time()) / total), info, int(end - time.time()))
                time.sleep(0.5)
    finally:
        ui.close()
    if ok:
        common.log('%s paired' % s.name)
    return ok


# ── links ────────────────────────────────────────────────────────────────────

def supports(url):
    """Ids of the paired services whose own host list covers this address."""
    importer.ensure()
    return [i for i in order() if BY_ID[i].authorized() and BY_ID[i].supports(url)]


def unrestrict(url, ids=None, parallel=False, timeout=30):
    """Direct link for a hoster address through the first service that can do it: (link, service id) or None.
    parallel=True asks all candidates at once and takes the first answer (faster, uses every account's request)."""
    cands = [i for i in (ids or supports(url)) if i in BY_ID]
    if not cands:
        return None
    if parallel and len(cands) > 1:
        ex = ThreadPoolExecutor(max_workers=len(cands))
        futs = {ex.submit(BY_ID[i].unrestrict, url): i for i in cands}
        ex.shutdown(wait=False)
        try:
            for f in as_completed(futs, timeout=timeout):
                try:
                    link = f.result()
                except Exception:
                    link = None
                if link:
                    return link, futs[f]
        except Exception:
            pass
        return None
    for i in cands:
        try:
            link = BY_ID[i].unrestrict(url)
        except Exception as e:
            common.log('%s unrestrict failed: %s' % (i, e))
            link = None
        if link:
            return link, i
    return None
