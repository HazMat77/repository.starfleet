# -*- coding: utf-8 -*-
"""Shared helpers for the Starfleet resolvers: one HTTP session, header handling, small decoders, playlist checks."""
import re
import base64
from urllib.parse import urlparse, urljoin, quote, unquote, unquote_plus

try:
    import requests
except ImportError:                       # never expected inside Kodi
    requests = None

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
TIMEOUT = 12

_session = None


def session():
    global _session
    if _session is None and requests is not None:
        _session = requests.Session()
        _session.headers['User-Agent'] = UA
    return _session


def log(msg):
    try:
        import xbmc
        xbmc.log('[StarfleetResolve] %s' % msg, xbmc.LOGINFO)
    except Exception:
        pass


def split_pipe(url):
    """'https://x/y|Referer=..&User-Agent=..' -> (url, {headers})."""
    base, _, tail = url.partition('|')
    headers = {}
    for kv in tail.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            headers[k] = unquote_plus(v)
    return base, headers


def with_headers(url, referer=None, origin=None, extra=None):
    """Kodi's 'url|Header=value&...' form (always with a browser User-Agent)."""
    h = {'User-Agent': UA}
    if referer:
        h['Referer'] = referer
    if origin:
        h['Origin'] = origin
    h.update(extra or {})
    return '%s|%s' % (url, '&'.join('%s=%s' % (k, quote(v, safe='')) for k, v in h.items()))


def origin_of(url):
    p = urlparse(url)
    return '%s://%s' % (p.scheme or 'https', p.netloc)


def get(url, referer='', headers=None, timeout=TIMEOUT, **kw):
    """requests.get with browser headers; returns the Response or None on any failure."""
    s = session()
    if s is None:
        return None
    base, tail_h = split_pipe(url)
    if not base.startswith(('http://', 'https://')):
        return None
    h = dict(tail_h)
    h.update(headers or {})
    if referer and 'Referer' not in h:
        h['Referer'] = referer
    try:
        return s.get(base, headers=h, timeout=timeout, **kw)
    except Exception:
        return None


def post(url, data=None, json=None, referer='', headers=None, timeout=TIMEOUT):
    s = session()
    if s is None:
        return None
    h = dict(headers or {})
    if referer and 'Referer' not in h:
        h['Referer'] = referer
    try:
        return s.post(url, data=data, json=json, headers=h, timeout=timeout)
    except Exception:
        return None


def text(url, referer='', headers=None, timeout=TIMEOUT):
    r = get(url, referer, headers, timeout)
    return r.text if r is not None and r.status_code == 200 else ''


def clean_js_url(u):
    """URL taken out of JavaScript source: undo \\/ and \\u0026 style escapes."""
    u = u.replace('\\/', '/')
    return re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), u).strip()


def b64decode_text(s):
    for pad in ('', '=', '==', '==='):
        try:
            return base64.b64decode(s + pad).decode('utf-8', 'ignore').strip()
        except Exception:
            continue
    return ''


_SOURCE_RES = [
    re.compile(r'''["']?file["']?\s*:\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''<source[^>]+src=["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''loadSource\(["'](https?://[^"']+\.m3u8[^"']*)["']''', re.I),
    re.compile(r'''(?:var|let|const)?\s*(?:src|source|url|stream|streamUrl|hls)\s*[:=]\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''["'](https?://[^\s"'<>]+\.m3u8[^\s"'<>]*)["']''', re.I),
    re.compile(r'''["'](https?://[^\s"'<>]+\.mp4[^\s"'<>]*)["']''', re.I),
]


def find_media_url(html):
    """First direct .m3u8 / .mp4 address found in page source ('' when there is none)."""
    html = (html or '').replace('\/', '/')
    for rx in _SOURCE_RES:
        m = rx.search(html)
        if m:
            u = clean_js_url(m.group(1))
            if u.startswith('http'):
                return u
    return ''


def unpack_js(html):
    """Decode Dean Edwards 'p,a,c,k,e,d' packed scripts found in a page; returns the decoded text (or '')."""
    out = []
    for m in re.finditer(r"eval\(function\(p,a,c,k,e,(?:d|r)\)\{.*?\}\('(.*?)',(\d+),(\d+),'(.*?)'\.split\('\|'\)", html or '', re.S):
        payload, radix, count, words = m.group(1), int(m.group(2)), int(m.group(3)), m.group(4).split('|')

        def tok(n):
            return (tok(n // radix) if n >= radix else '') + '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'[n % radix]

        table = {}
        for i in range(count):
            key = tok(i)
            table[key] = words[i] if i < len(words) and words[i] else key
        out.append(re.sub(r'\b\w+\b', lambda mm: table.get(mm.group(0), mm.group(0)), payload.replace("\\'", "'")))
    return '\n'.join(out)


def playlist_ok(piped_url, timeout=6):
    """True when the playlist lists segments and one of them can really be fetched."""
    base, h = split_pipe(piped_url)
    h.setdefault('User-Agent', UA)
    s = session()
    if s is None:
        return False
    try:
        r = s.get(base, headers=h, timeout=timeout)
        txt = r.text or ''
        if r.status_code != 200 or '#EXTM3U' not in txt[:80]:
            return False
        if 'EXT-X-STREAM-INF' in txt:
            nxt = [l for l in txt.splitlines() if l and not l.startswith('#')]
            if not nxt:
                return False
            r = s.get(urljoin(r.url, nxt[0]), headers=h, timeout=timeout)
            txt = r.text or ''
        segs = [l for l in txt.splitlines() if l and not l.startswith('#')]
        if not segs:
            return False
        vod = '#EXT-X-ENDLIST' in txt or 'PLAYLIST-TYPE:VOD' in txt
        seg = segs[0] if vod else (segs[-2] if len(segs) > 2 else segs[-1])
        g = s.get(urljoin(r.url, seg), headers=dict(h, Range='bytes=0-2047'), timeout=timeout, stream=True)
        try:
            return g.status_code in (200, 206) and len(next(g.iter_content(1024), b'')) > 0
        finally:
            g.close()
    except Exception:
        return False


def host_matches(url, domains):
    host = urlparse(url).netloc.lower().split(':')[0]
    return any(host == d or host.endswith('.' + d) for d in domains)


# Hosts that are gone for good (domain no longer resolves, or parked by a domain reseller): fail at once instead of
# spending time on fallbacks. Checked live 2026-10-17.
DEAD_HOSTS = ('gounlimited.to', 'mystream.to', 'vidlox.me', 'fembed.com', 'vup.to', 'upvid.co', 'usersfiles.com', 'letsupload.io',
              'racaty.io', 'racaty.net', 'streamhub.to', 'anonfiles.com', 'bayfiles.com', 'vev.io', 'clipwatching.com', 'cloudyfiles.net',
              'uploadrocket.net', 'onlystream.tv', 'solidfiles.com', 'openload.co', 'oload.stream', 'streamango.com', 'streamcherry.com',
              'rapidvideo.com', 'thevideo.me', 'vidup.io')


try:
    from starfleetresolve import deadlist as _dl
    DEAD_HOSTS = tuple(DEAD_HOSTS) + tuple(_dl.DOMAINS)
except Exception:
    pass


def is_dead(url):
    return host_matches(url, DEAD_HOSTS)


def is_parked(html):
    t = (html or '')[:20000].lower()
    return 'parklogic' in t or 'sedoparking' in t or 'domain is for sale' in t
