# -*- coding: utf-8 -*-
"""Starfleet resolver: turn a player / host address into something Kodi can play.

    import starfleetresolve
    url = starfleetresolve.resolve('https://embed.st/embed/admin/ppv-x/1')   # 'https://...m3u8|Referer=..&User-Agent=..'
    starfleetresolve.valid_url(addr)                                         # do we (or ResolveURL) know this host?
    starfleetresolve.HostedMediaFile(addr).valid_url() / .resolve()          # same shape as resolveurl's

Order of attempts for one address:
  1. Starfleet resolvers marked 'first' (hosts ResolveURL does not have, or ones we do better)
  2. a paired debrid account (Real-Debrid, AllDebrid, Premiumize, TorBox, Debrid-Link, Offcloud) for file lockers
     ResolveURL has no free resolver for
  3. Starfleet's own copy of the ResolveURL resolvers (starfleetresolve.ru), then the installed ResolveURL add-on
     (script.module.resolveurl) as the last chance: it may have been updated before ours
  4. the debrid account again for hosts ResolveURL does handle (when ResolveURL failed)
  5. Starfleet resolvers marked 'last' (a second chance on hosts ResolveURL failed on)
  6. generic page reading (follow iframes, read the player's own source list)
resolve_first(urls) races several mirrors of one stream and returns the first that works.
resolve() never raises; it returns None when nothing worked."""
import re
from urllib.parse import urljoin

from starfleetresolve import common
from starfleetresolve.plugins import ALL

__version__ = '1.4.2'
_MAX_DEPTH = 3


def _resolveurl():
    """The installed ResolveURL add-on (kept as the last-chance fallback: it may have been updated before ours)."""
    try:
        import resolveurl
        return resolveurl
    except Exception:
        return None


_FORK = []


def _fork():
    """Starfleet's own copy of the ResolveURL host resolvers (starfleetresolve.ru), maintained and tested here."""
    if not _FORK:
        try:
            import starfleetresolve.ru as sru
            _FORK.append(sru)
        except Exception as e:
            common.log('fork not available: %s' % e)
            _FORK.append(None)
    return _FORK[0]


def _ours(url, priority):
    return [r for r in ALL if r.priority == priority and r.match(url)]


def _try(r, url, referer):
    try:
        out = r.resolve(url, referer)
        if out:
            common.log('%s resolved %s' % (r.name, url[:70]))
        return out
    except Exception as e:
        common.log('%s failed on %s: %s' % (r.name, url[:70], e))
        return None


def _generic(url, referer, depth=0):
    """Unknown host: read the page like a browser would (iframes, encoded addresses...) until a playlist shows up."""
    from starfleetresolve import pagewalk
    res = pagewalk.walk(url, referer)
    if res:
        kind, val = res
        if kind == 'stream':
            return val
        if kind == 'embed' and depth < _MAX_DEPTH:
            return resolve(val, referer=url, _depth=depth + 1)
    # last resort: first direct address anywhere in the page
    html = common.text(url.split('|')[0], referer=referer)
    found = common.find_media_url(html) or common.find_media_url(common.unpack_js(html))
    if found:
        return common.with_headers(common.clean_js_url(found), referer=url.split('|')[0], origin=common.origin_of(url))
    return None


_RESULTS = {}
_RESULT_TTL = 45


def _ru_specific(ru, url):
    """True when ResolveURL has a non-debrid resolver of its own for this host (free hosts it handles well)."""
    try:
        from urllib.parse import urlparse
        host = urlparse(url).netloc.lower().split(':')[0]
        return bool(ru.relevant_resolvers(domain=host, include_universal=False))
    except Exception:
        return True


def _via_debrid(url):
    try:
        from starfleetresolve import debrid
        got = debrid.unrestrict(url)
        if got:
            common.log('debrid (%s) resolved %s' % (got[1], url[:70]))
            return got[0]
    except Exception as e:
        common.log('debrid failed on %s: %s' % (url[:70], e))
    return None


def _debrid_covers(url):
    try:
        from starfleetresolve import debrid
        return bool(debrid.supports(url))
    except Exception:
        return False


_RU_TIMEOUT = 14
_RU_INSTALLED_TIMEOUT = 10
# the Byse / Filemoon family solves a proof-of-work puzzle (5-25 s, the time varies from run to run): give it longer
_SLOW_HOSTS = ('filemoon', 'byse', 'kerapoxy', 'streamlyplayer', 'boosteradx', 'cinegrab', 'moonmov', 'furher', 'klcams',
               'smdfs40r', 'bf0skv', 'z1ekv717', 'l1afav', '222i8x', '8mhlloqo', 'f16px', '1azayf9w', '81u6xl9d',
               'sb1254w9megshle', 'xcoic', 'f51rm', 'c1z39', 'moflix-stream')
_SLOW_TIMEOUT = 32


def _via_resolveurl(ru, url, timeout=None):
    """ResolveURL, but never waiting on it for more than _RU_TIMEOUT seconds (some of its hosts take 20-30 s to fail)."""
    from concurrent.futures import ThreadPoolExecutor, TimeoutError as _TO

    def work():
        hmf = ru.HostedMediaFile(url)
        return hmf.resolve() if hmf.valid_url() else None

    ex = ThreadPoolExecutor(max_workers=1)
    fut = ex.submit(work)
    ex.shutdown(wait=False)
    try:
        out = fut.result(timeout=timeout or _RU_TIMEOUT)
        if out:
            common.log('ResolveURL resolved %s' % url[:70])
            return out
    except _TO:
        common.log('ResolveURL timed out on %s' % url[:70])
    except Exception as e:
        common.log('ResolveURL failed on %s: %s' % (url[:70], e))
    return None


def resolve(url, referer='', use_resolveurl=True, generic=True, debrid_links=True, _depth=0):
    """Playable address for `url`, or None. See the module docstring for the order of attempts."""
    if not url or _depth > _MAX_DEPTH:
        return None
    url = url.strip()
    import time as _time
    hit = _RESULTS.get(url)
    if hit and _time.time() - hit[0] < _RESULT_TTL:
        return hit[1]
    if _depth == 0 and use_resolveurl and generic and debrid_links:
        from starfleetresolve import resultcache
        cached = resultcache.get(url)                       # resolved a moment ago by another process / prefetch()
        if cached:
            _RESULTS[url] = (_time.time(), cached)
            return cached
    out = _resolve(url, referer, use_resolveurl, generic, debrid_links, _depth)
    if out:
        if _depth == 0 and use_resolveurl and generic and debrid_links:
            from starfleetresolve import resultcache
            resultcache.put(url, out)
        _RESULTS[url] = (_time.time(), out)
        if len(_RESULTS) > 200:
            for k in sorted(_RESULTS, key=lambda k: _RESULTS[k][0])[:100]:
                _RESULTS.pop(k, None)
    return out


_DIRECT_EXT = ('.m3u8', '.mpd', '.mp4', '.mkv', '.ts', '.webm', '.m4v', '.mov', '.flv')


def _is_direct(url):
    base = url.split('|')[0].split('?')[0].lower()
    return base.endswith(_DIRECT_EXT) and url.startswith(('http://', 'https://'))


def _resolve(url, referer, use_resolveurl, generic, debrid_links, depth):
    if _is_direct(url):                    # already a playlist / media file: nothing to resolve
        return url
    if common.is_dead(url):
        common.log('dead host, skipped: ' + url[:70])
        return None
    for r in _ours(url, 'first'):
        out = _try(r, url, referer)
        if out:
            return out
    fork = _fork() if use_resolveurl else None
    ru = _resolveurl() if use_resolveurl else None
    covered = debrid_links and url.startswith(('http://', 'https://')) and _debrid_covers(url)
    specific = any(m is not None and _ru_specific(m, url) for m in (fork, ru))
    # file lockers with no free resolver anywhere go straight to the paired debrid account
    if covered and not specific:
        out = _via_debrid(url)
        if out:
            return out
    slow = any(w in url.split('/')[2].lower() for w in _SLOW_HOSTS) if '//' in url else False
    if fork is not None:                                    # our own copy of the ResolveURL resolvers
        out = _via_resolveurl(fork, url, _SLOW_TIMEOUT if slow else None)
        if out:
            return out
    if ru is not None and not (slow and fork is not None):  # the installed ResolveURL: maybe it was updated before ours
        out = _via_resolveurl(ru, url, _RU_INSTALLED_TIMEOUT)
        if out:
            return out
    if covered and specific:
        out = _via_debrid(url)
        if out:
            return out
    for r in _ours(url, 'last'):
        out = _try(r, url, referer)
        if out:
            return out
    out = None
    if generic:
        try:
            out = _generic(url, referer, depth)
        except Exception:
            out = None
    if not out and debrid_links and use_resolveurl and url.startswith(('http://', 'https://')) and '.' in url.split('/')[2]:
        try:                                              # TorBox-style services accept sites that are on no host list
            from starfleetresolve import debrid
            got = debrid.unrestrict_any(url)
            if got:
                common.log('debrid (%s, any link) resolved %s' % (got[1], url[:70]))
                out = got[0]
        except Exception as e:
            common.log('any-link debrid failed: %s' % e)
    return out


def resolve_first(urls, referer='', timeout=25, **kw):
    """Race several addresses (the mirrors of one stream): returns (address, playable) for the first that resolves,
    or None. The others are left to finish in the background and are ignored."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    urls = [u for u in urls if u]
    if not urls:
        return None
    ex = ThreadPoolExecutor(max_workers=min(len(urls), 8))
    futs = {ex.submit(resolve, u, referer, **kw): u for u in urls}
    ex.shutdown(wait=False)
    try:
        for f in as_completed(futs, timeout=timeout):
            try:
                out = f.result()
            except Exception:
                out = None
            if out:
                return futs[f], out
    except Exception:
        pass
    return None


def knows_host(url):
    """'starfleet', 'debrid', 'resolveurl', 'dead' (gone for good) or None: who has a resolver for this address (no network needed)."""
    if common.is_dead(url):
        return 'dead'
    if any(r.match(url) for r in ALL):
        return 'starfleet'
    if url.startswith(('http://', 'https://')) and _debrid_covers(url):
        return 'debrid'
    for m in (_fork(), _resolveurl()):
        if m is not None:
            try:
                if m.HostedMediaFile(url).valid_url():
                    return 'resolveurl'
            except Exception:
                pass
    return None


def valid_url(url):
    return knows_host(url) is not None


class HostedMediaFile(object):
    """Drop-in for resolveurl.HostedMediaFile in the two calls this addon family uses."""

    def __init__(self, url='', *args, **kwargs):
        self.url = url or kwargs.get('url', '')

    def valid_url(self):
        return valid_url(self.url)

    def resolve(self):
        return resolve(self.url) or False


def known_domains():
    """{domain: 'starfleet' | 'fork'} for every host this module resolves by itself: Starfleet's own resolvers
    first, then everything in its copy of the ResolveURL resolvers (including the adult extension)."""
    out = {}
    fork = _fork()
    if fork is not None:
        try:
            for c in fork.relevant_resolvers(include_universal=False, include_disabled=True, include_popups=True):
                for d in c.domains or []:
                    if d != '*':
                        out[d.lower()] = 'fork'
        except Exception as e:
            common.log('known_domains: %s' % e)
    for r in ALL:
        for d in getattr(r, 'domains', ()) or ():
            out[d.lower()] = 'starfleet'
    return out


def prefetch(urls, referer='', workers=4):
    """Resolve these addresses in the background (daemon threads) and keep the answers for a minute and a half, so that
    resolve() on any of them returns at once. Returns immediately; call it as soon as a list of links is shown."""
    import threading
    urls = [u for u in dict.fromkeys(urls or []) if u]
    if not urls:
        return
    queue = list(urls)
    lock = threading.Lock()

    def work():
        while True:
            with lock:
                if not queue:
                    return
                u = queue.pop(0)
            try:
                resolve(u, referer)
            except Exception:
                pass

    for _ in range(min(workers, len(urls))):
        t = threading.Thread(target=work)
        t.daemon = True
        t.start()
