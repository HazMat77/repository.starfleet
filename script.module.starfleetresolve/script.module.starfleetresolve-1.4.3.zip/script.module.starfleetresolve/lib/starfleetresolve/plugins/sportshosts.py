# -*- coding: utf-8 -*-
"""Sports embed hosts with a fixed, host-specific format (the generic page reader covers the rest)."""
from starfleetresolve import common, pagedecode
from starfleetresolve.plugins.base import Resolver


class GSports(Resolver):
    """gsports.lat event / player pages: the player script travels as <page>?v=font.woff2 (XOR 'gs99' + raw deflate)."""
    name = 'gsports'
    domains = ('gsports.lat',)
    priority = 'first'

    def resolve(self, url, referer=''):
        return pagedecode.font_payload(url.split('|')[0])


class LiveLive24(Resolver):
    """livelive24 test.html?url=<stream> and the player.787200.com/live page behind it: the stream address is the
    url / liveUrl parameter itself."""
    name = 'livelive24'
    domains = ('livelive24.com', '787200.com')
    priority = 'first'

    def resolve(self, url, referer=''):
        from urllib.parse import urlparse, parse_qs
        link = url.split('|')[0]
        q = parse_qs(urlparse(link).query)
        target = (q.get('liveUrl') or q.get('url') or [''])[0]
        if not target.startswith('http'):
            return None
        return common.with_headers(target, referer=common.origin_of(link) + '/')
