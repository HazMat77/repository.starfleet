# -*- coding: utf-8 -*-
"""Generic page reader: follow a player / game page through its iframes and encoded hops until it names a playlist.

walk(url) -> ('stream', 'playlist|Headers...')   a playlist address was found and decoded
          -> ('embed', url)                      the page leads to a player host that has its own resolver
          -> None
Understands (no JavaScript is run): numbered server buttons that fill an iframe from a template, base64 atob()
addresses, a base64 address XOR-ed twice, number-array XOR blobs, window._econfig / PP_CLAPPR_CONFIG / hex-XOR
payloads, `globalurl` NBA streams, host lists published next to the page (getRandomStream), allStreams arrays,
const streamUrl / streamUrls / source, and a decrypt.php token exchange."""
import re
import json
import base64
import html as _html
import uuid
from urllib.parse import urlparse, urljoin

from starfleetresolve import common
from starfleetresolve.plugins.livesites import extract_stream

_EMBED_HOSTS = ('embed.st', 'embedsports', 'pooembed', 'embedindia', 'taifood-blog')
_RE_BTN = re.compile(r'(?s)id="stream-btn-(\d+)"[^>]*?>(.*?)</div>')
_RE_TMPL = re.compile(
    r"getElementById\(['\"](?:wp_player|cx-iframe)['\"]\)\.src\s*=\s*['\"]([^'\"]+)['\"]\s*\+\s*streamId(?:\s*\+\s*['\"]([^'\"]*)['\"])?")


def _pipe(src, page_url):
    src = src.replace('\\u0026', '&').replace('\\/', '/')
    o = common.origin_of(page_url)
    return common.with_headers(src, referer=o + '/', origin=o)


def _is_embed_host(u):
    if any(h in urlparse(u).netloc.lower() for h in _EMBED_HOSTS):
        return True
    try:                                   # any player host one of Starfleet's own resolvers claims
        from starfleetresolve.plugins import ALL
        return any(r.priority == 'first' and r.match(u) for r in ALL)
    except Exception:
        return False


def _iframe_of(page):
    tmpl = _RE_TMPL.search(page)
    servers = _RE_BTN.findall(page)
    if tmpl and servers:
        return tmpl.group(1) + servers[0][0] + (tmpl.group(2) or '')
    m = re.search(r'(?is)<iframe[^>]+src=["\']([^"\']+)', page)
    return m.group(1) if m else None


def _array_payload(page):
    m = re.search(r'var\s+\w+\s*=\s*\[([\d,\s]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*""\s*,\s*\w+\s*;', page, re.S)
    if not m:
        return None
    arr = [int(n) for n in m.group(1).split(',') if n.strip()]
    k1, k2 = int(m.group(2)), int(m.group(3))
    text = ''.join(chr(((n ^ k1) - k2 + 256) & 255) for n in arr)
    mm = re.search(r'(?:\burl|SIGNED_URL)\s*=\s*"([^"]+)"', text)
    return re.sub(r'(?<!:)/{2,}', '/', mm.group(1).replace('\\/', '/')) if mm else None


_RE_MPD = re.compile(r"""["'`](https?:(?:\\?/){2}[^"'`\s<>]+?\.mpd(?:\?[^"'`\s<>]*)?)["'`]""")
_HEX32 = r'[0-9a-fA-F]{32}'
_RE_KEYS = (
    re.compile(r"""["']?(?:keyId|kid|key_id)["']?\s*[:=]\s*["'](%s)["']\s*,\s*["']?(?:key|k)["']?\s*[:=]\s*["'](%s)["']""" % (_HEX32, _HEX32), re.I),
    re.compile(r"""["']?clear_?keys?["']?\s*[:=]\s*\{\s*["'](%s)["']\s*:\s*["'](%s)["']""" % (_HEX32, _HEX32), re.I),
    re.compile(r'\b(%s)\s*:\s*(%s)\b' % (_HEX32, _HEX32)),
)
_RE_WV = re.compile(r"""["']?(?:licen[sc]e_?(?:server|url)|serverURL)["']?\s*[:=]\s*["'](https?:[^"']+)["']""", re.I)


def drm_hints(page):
    """({kid: key}, widevine licence address or '') found in a player page."""
    keys = {}
    for rx in _RE_KEYS:
        for k, v in rx.findall(page):
            keys.setdefault(k.lower(), v.lower())
        if keys:
            break
    wv = _RE_WV.search(page)
    return keys, (wv.group(1).replace('\/', '/') if wv else '')


def _mpd_stream(page, cur):
    """A DASH manifest named in the page, with its licence details, or None."""
    m = _RE_MPD.search(page)
    if not m:
        return None
    mpd = m.group(1).replace('\/', '/').replace('\u0026', '&')
    keys, lic = drm_hints(page)
    o = common.origin_of(cur)
    return common.with_drm(mpd, referer=o + '/', origin=o, clearkeys=keys, license_url=lic if not keys else None)


def _is_playlist(url, referer):
    o = common.origin_of(referer)
    r = common.get(url, referer=referer, headers={'Origin': o})
    return r is not None and r.status_code == 200 and r.text.lstrip().startswith('#EXTM3U')


def walk(page_url, referer='', depth=0):
    cur, ref = page_url.split('|')[0], referer or page_url
    seen = set()
    for _hop in range(5):
        page = common.text(cur, referer=ref)
        if not page:
            return None
        page = re.sub(r'https?:(?:\\?/){2}[^"\'\s]*?(?:\\?/)troll(?:\\?/)[^"\'\s]*', '', page)      # a decoy playlist some players list before the real one
        found = _array_payload(page)
        if found and found.startswith('http'):
            return 'stream', _pipe(found, cur)
        from starfleetresolve import pagedecode
        dec = pagedecode.decode(page, cur)
        if dec:
            return 'stream', dec
        mm = re.search(r'var\s+_raw\s*=\s*"([A-Za-z0-9+/=]+)"\s*;\s*var\s+_d\s*=\s*atob\(_raw\)', page)
        if mm and cur not in seen:
            nxt = common.b64decode_text(mm.group(1))
            if nxt:
                seen.add(cur)
                nxt = urljoin(cur, nxt)
                if _is_embed_host(nxt):
                    return 'embed', nxt
                cur, ref = nxt, cur
                continue
        mm = re.search(r"var\s+globalurl\s*=\s*'([^']+\.m3u8[^']*)'", page)
        if mm:
            return 'stream', _pipe(mm.group(1).split('&sessionId=')[0] + '&sessionId=' + str(uuid.uuid4()), cur)
        mm = re.search(r"getRandomStream\('([^']+\.m3u8)'(?:\s*,\s*'([^']+)')?", page)
        if mm:
            sub = mm.group(2) or (re.search(r"var\s+subdomain\s*=\s*'([^']+)'", page) or [None, 'admin2'])[1]
            doms = [d.strip() for d in common.text(common.origin_of(cur) + '/domainsz77.txt', referer=cur).split('\n') if d.strip()]
            for dm in doms[:3]:
                u = 'https://%s.%s/%s' % (sub, dm, mm.group(1))
                if _is_playlist(u, cur):
                    return 'stream', _pipe(u, cur)
        mm = re.search(r'const\s+allStreams\s*=\s*(\[.*?\]);', page, re.S)
        if mm and depth < 2:
            try:
                links = [x.get('value', '').replace('\\/', '/') for x in json.loads(mm.group(1))]
            except ValueError:
                links = []
            links = [l for l in links if l.startswith('http')]
            for l in links:
                if _is_embed_host(l):
                    return 'embed', l
            for l in links[:3]:
                res = walk(l, cur, depth + 1)
                if res:
                    return res
            return None
        ex = extract_stream(page)
        if not ex:
            mpd = _mpd_stream(page, cur)
            if mpd:
                return 'stream', mpd
        if ex and ex.startswith('http'):
            return 'stream', _pipe(ex, cur)
        for b in re.findall(r'atob\(["\']([A-Za-z0-9+/=]{16,})["\']\)', page):
            dec = common.b64decode_text(b)
            if not dec.startswith('http'):
                continue
            if '.m3u8' in dec:
                return 'stream', _pipe(dec, cur)
            if _is_embed_host(dec):
                return 'embed', dec
            if _is_playlist(dec, cur):
                return 'stream', _pipe(dec, cur)
            cur, ref = dec, cur
            break
        else:
            for pat in (r'const\s+streamUrls\s*=\s*(\[.*?\]);', r'const\s+streamUrl\s*=\s*"([^"]*)"', r'var\s+streamUrl\s*=\s*"([^"]+)"',
                        r'(?:const|var|let)\s+source\s*=\s*["\']([^"\']+)', r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)'):
                mm = re.search(pat, page)
                if not mm:
                    continue
                val = mm.group(1)
                if val.startswith('['):
                    try:
                        urls = [u for u in json.loads(val) if u]
                    except ValueError:
                        urls = []
                    val = urls[0] if urls else ''
                val = val.replace('\\/', '/')
                if val.startswith('http'):
                    if '.m3u8' in val or _is_playlist(val, cur):
                        return 'stream', _pipe(val, cur)
            mm = re.search(r'input:\s*"([^"]+)"', page)
            if mm:
                r = common.post(common.origin_of(cur) + '/embed/decrypt.php', data={'input': mm.group(1)}, referer=cur)
                resp = r.text.strip() if r is not None else ''
                if resp.startswith('http'):
                    if '.m3u8' in resp:
                        return 'stream', _pipe(resp, cur)
                    cur, ref = resp, cur
                    continue
            nxt = _iframe_of(page)
            if not nxt or nxt.startswith(('about:', 'javascript:')):
                return None
            nxt = _html.unescape(nxt).strip()
            if nxt.startswith(('https:///', 'http:///')):
                nxt = common.origin_of(cur) + '/' + nxt.split('///', 1)[1]
            elif nxt.startswith('//'):
                nxt = 'https:' + nxt
            nxt = urljoin(cur, nxt)
            if _is_embed_host(nxt):
                return 'embed', nxt
            cur, ref = nxt, cur
            continue
    return None
