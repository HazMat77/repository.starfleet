# -*- coding: utf-8 -*-
"""embed.st and the embedsports player family (embedsports.top, pooembed, embedindia, taifood-blog).

The player page asks the site's /fetch endpoint for the playlist address with a small protobuf request. The answer
is a protobuf message whose field 1 is a cipher; the key comes in the response header named by
access-control-expose-headers. The cipher text is a shifted printable alphabet, then base64, then a ChaCha20 box
(12 byte nonce, ciphertext, 16 byte tag). Pure Python, no crypto library."""
import base64
import struct
import time
from urllib.parse import urlparse

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver

_INDIANS_SECRET = {'embedindia': '679808d3e4c8a4068767e6f22dfe191318909a62e6601b8149c8e2fa29a5375e'}
_INDIANS_DEFAULT = '18866ebec06934ba03ad3387e9fc9ebfbf2ea2d0e9305c86797b66c62ee4f8a5'


def _rotl32(x, n):
    return ((x << n) & 0xFFFFFFFF) | (x >> (32 - n))


def chacha20(key, nonce, data, counter=1):
    k = struct.unpack('<8L', key)
    n = struct.unpack('<3L', nonce)
    out = bytearray()

    def qr(w, a, b, c, d):
        w[a] = (w[a] + w[b]) & 0xFFFFFFFF; w[d] = _rotl32(w[d] ^ w[a], 16)
        w[c] = (w[c] + w[d]) & 0xFFFFFFFF; w[b] = _rotl32(w[b] ^ w[c], 12)
        w[a] = (w[a] + w[b]) & 0xFFFFFFFF; w[d] = _rotl32(w[d] ^ w[a], 8)
        w[c] = (w[c] + w[d]) & 0xFFFFFFFF; w[b] = _rotl32(w[b] ^ w[c], 7)

    for off in range(0, len(data), 64):
        st = [0x61707865, 0x3320646e, 0x79622d32, 0x6b206574] + list(k) + [counter + off // 64] + list(n)
        w = st[:]
        for _ in range(10):
            qr(w, 0, 4, 8, 12); qr(w, 1, 5, 9, 13); qr(w, 2, 6, 10, 14); qr(w, 3, 7, 11, 15)
            qr(w, 0, 5, 10, 15); qr(w, 1, 6, 11, 12); qr(w, 2, 7, 8, 13); qr(w, 3, 4, 9, 14)
        block = struct.pack('<16L', *[(w[i] + st[i]) & 0xFFFFFFFF for i in range(16)])
        out += bytes(a ^ b for a, b in zip(data[off:off + 64], block))
    return bytes(out)


def _varint(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | 0x80 if n else b)
        if not n:
            return bytes(out)


def _field(num, val):
    return bytes([(num << 3) | 2]) + _varint(len(val)) + val


def _decode(resp):
    ac = resp.headers.get('access-control-expose-headers')
    key = resp.headers.get(ac) if ac else None
    c = resp.content
    if not key or not c:
        return None
    i, cipher = 0, None
    while i < len(c):
        tag = c[i]; i += 1
        length, shift = 0, 0
        while True:
            b = c[i]; i += 1
            length |= (b & 0x7F) << shift
            if not (b & 0x80):
                break
            shift += 7
        val = c[i:i + length]; i += length
        if tag >> 3 == 1:
            cipher = val
            break
    if cipher is None:
        return None
    dec = bytes(((b - 0x21 + 71) % 94) + 0x21 for b in cipher)
    raw = base64.b64decode(dec + b'=' * (-len(dec) % 4))
    if len(raw) < 29:
        return None
    return chacha20(key.encode('utf-8'), raw[:12], raw[12:-16]).decode('utf-8', 'ignore').strip()


class Goat(Resolver):
    name = 'embed.st / embedsports'
    domains = ('embed.st', 'embedsports.top', 'embedsports.pro', 'pooembed.top', 'pooembed.eu', 'embedindia.st',
               'taifood-blog.asia')

    def match(self, url):
        host = urlparse(url).netloc.lower()
        return (host == 'embed.st' or host.endswith('.embed.st')
                or any(k in host for k in ('embedsports.top', 'pooembed', 'embedindia', 'taifood-blog')))

    def resolve(self, url, referer=''):
        link = url.split('#')[0].split('|')[0]
        p = urlparse(link)
        host = p.netloc.lower()
        origin = '%s://%s' % (p.scheme or 'https', p.netloc)
        seg = link.rstrip('/').split('/')
        hdr = {'Referer': link, 'Origin': origin, 'Content-Type': 'application/octet-stream', 'User-Agent': common.UA}
        if 'embed.st' in host:
            body = _field(1, seg[-3].encode()) + _field(2, seg[-2].encode()) + _field(3, seg[-1].encode())
        else:
            if any(h in host for h in ('pooembed', 'embedindia', 'taifood-blog')):
                body = _field(1, '/'.join(seg[4:]).encode())
            else:
                body = _field(1, seg[-3].encode()) + _field(2, seg[-2].encode()) + _field(3, seg[-1].encode())
            hdr['indians'] = next((v for k, v in _INDIANS_SECRET.items() if k in host), _INDIANS_DEFAULT)
        # the playlist edges answer an occasional fresh address with 403 (a token an edge does not honour); asking again gives another
        # token, so the address is tried on the spot and a refused one is replaced
        first = None
        for attempt in range(4):
            r = common.post(origin + '/fetch', data=body, headers=hdr)
            if r is None:
                break
            stream = _decode(r)
            if not stream or not stream.startswith('http'):
                break
            piped = common.with_headers(stream, referer=origin + '/', origin=origin)
            first = first or piped
            if '.m3u8' not in stream.lower():
                return piped
            pr = common.get(piped, timeout=6)
            if pr is None or pr.status_code != 403:
                return piped
            common.log('goat: edge refused the address (403), asking again (%d)' % (attempt + 1))
            time.sleep(0.4)
        return first
