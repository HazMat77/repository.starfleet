# -*- coding: utf-8 -*-
"""Debrid services: pairing (device-code / PIN flows), token refresh, host lists, link unrestrict.

Every service implements the same small surface:
    start_pairing() -> dict(url, code, expires_in, interval, state)    ask the service for a code to enter
    poll_pairing(state) -> True | False | None                           True: paired and stored; False: not yet;
                                                                        None: gave up (expired / refused)
    token()          -> a currently valid access token / key or ''
    authorized()     -> bool
    reset()          -> forget the account
    account()        -> {'user': ..., 'premium': bool, 'expires': ...} or {}
    supports(url)    -> True when the service's own host list covers this address (list cached for a day)
    unrestrict(url)  -> direct link or None
Client ids below are the services' public device-flow ids (the same ones other open-source add-ons use)."""
import re
import time
from urllib.parse import urlparse

from starfleetresolve import common
from starfleetresolve.debrid import store

UA = {'User-Agent': 'StarfleetResolve/1.0'}
APP_NAME = 'StarfleetResolve'      # the name AllDebrid and TorBox show on their "authorize this app" page; an app that embeds the resolver sets its own
HOSTS_TTL = 24 * 3600


def _json(r):
    try:
        return r.json() if r is not None else None
    except Exception:
        return None


class Service(object):
    id = ''
    name = ''
    any_link = False        # True: the service takes links beyond its published host list (TorBox: yt-dlp sites)

    # ── account ──
    def token(self):
        return store.get(self.id).get('token', '')

    def authorized(self):
        return bool(self.token())

    def reset(self):
        store.clear(self.id)

    def account(self):
        return {}

    # ── pairing ──
    def start_pairing(self):
        raise NotImplementedError

    def poll_pairing(self, state):
        raise NotImplementedError

    # ── host lists ──
    def _fetch_hosts(self):
        """list of domain strings, or regex strings prefixed 're:'"""
        return []

    def _hosts(self):
        rec = store.get(self.id + '_hosts')
        if rec.get('hosts') and store.now() - rec.get('at', 0) < HOSTS_TTL:
            return rec['hosts']
        try:
            hosts = self._fetch_hosts()
        except Exception:
            hosts = []
        if hosts:
            store.put(self.id + '_hosts', hosts=hosts, at=store.now())
            return hosts
        return rec.get('hosts') or []

    def supports(self, url):
        host = urlparse(url).netloc.lower().split(':')[0]
        if not host:
            return False
        for h in self._hosts():
            if h.startswith('re:'):
                try:
                    if re.search(h[3:], url, re.I):
                        return True
                except re.error:
                    continue
            elif host == h or host.endswith('.' + h):
                return True
        return False

    def unrestrict(self, url):
        raise NotImplementedError

    def magnet_files(self, magnet):
        """[{'name', 'size', 'url'}] for a torrent this service already has cached (instant), else None."""
        return None

    def cached_hashes(self, hashes):
        """The info hashes (of `hashes`) this service has cached, in one bulk call; None when the service cannot say."""
        return None

    def magnet_download(self, magnet, progress_cb=None, timeout=90):
        """Like magnet_files, but a torrent that is not cached is added and waited for (up to `timeout` seconds;
        progress_cb(message, percent) returning False cancels). None when it did not finish."""
        return None


class RealDebrid(Service):
    id, name = 'realdebrid', 'Real-Debrid'
    CLIENT_ID = 'X245A4XAIBGVM'
    OAUTH = 'https://api.real-debrid.com/oauth/v2'
    REST = 'https://api.real-debrid.com/rest/1.0'

    def token(self):
        rec = store.get(self.id)
        if not rec.get('token'):
            return ''
        if rec.get('refresh') and rec.get('expires_at', 0) and store.now() >= rec['expires_at']:
            if not self._refresh(rec):
                return ''
            rec = store.get(self.id)
        return rec.get('token', '')

    def _save_token(self, client_id, client_secret, js):
        store.put(self.id, token=js['access_token'], refresh=js.get('refresh_token', ''), client_id=client_id,
                  client_secret=client_secret, expires_at=store.now() + int(js.get('expires_in', 3600)) - 120)

    def _refresh(self, rec):
        r = common.post(self.OAUTH + '/token', data={'client_id': rec['client_id'], 'client_secret': rec['client_secret'],
                                                      'code': rec['refresh'], 'grant_type': 'http://oauth.net/grant_type/device/1.0'},
                        headers=UA)
        js = _json(r)
        if js and js.get('access_token'):
            self._save_token(rec['client_id'], rec['client_secret'], js)
            return True
        store.clear(self.id)          # refresh refused: pair again
        return False

    def start_pairing(self):
        r = common.get(self.OAUTH + '/device/code', headers=UA, params={'client_id': self.CLIENT_ID, 'new_credentials': 'yes'})
        js = _json(r)
        if not js or 'device_code' not in js:
            return None
        return {'url': js.get('direct_verification_url') or js['verification_url'], 'code': js['user_code'],
                'expires_in': js.get('expires_in', 600), 'interval': js.get('interval', 5), 'state': js['device_code'],
                'display_url': js['verification_url']}

    def poll_pairing(self, state):
        r = common.get(self.OAUTH + '/device/credentials', headers=UA, params={'client_id': self.CLIENT_ID, 'code': state})
        js = _json(r)
        if not js or 'client_secret' not in js:
            return False
        t = common.post(self.OAUTH + '/token', data={'client_id': js['client_id'], 'client_secret': js['client_secret'],
                                                     'code': state, 'grant_type': 'http://oauth.net/grant_type/device/1.0'}, headers=UA)
        tj = _json(t)
        if tj and tj.get('access_token'):
            self._save_token(js['client_id'], js['client_secret'], tj)
            return True
        return None

    def _auth(self):
        return dict(UA, Authorization='Bearer ' + self.token())

    def account(self):
        js = _json(common.get(self.REST + '/user', headers=self._auth())) or {}
        return {'user': js.get('username') or js.get('email'), 'premium': js.get('type') == 'premium',
                'expires': js.get('expiration')} if js else {}

    def _fetch_hosts(self):
        r = common.get(self.REST + '/hosts/regex', headers=UA)
        out = []
        for rx in (_json(r) or []):
            rx = rx[1:-1].replace('\\/', '/').rstrip('\\') if rx.startswith('/') else rx
            out.append('re:' + rx)
        return out

    def unrestrict(self, url):
        r = common.post(self.REST + '/unrestrict/link', data={'link': url}, headers=self._auth())
        js = _json(r) or {}
        return js.get('download') or None


class AllDebrid(Service):
    id, name = 'alldebrid', 'AllDebrid'
    API = 'https://api.alldebrid.com/v4'
    AGENT = 'StarfleetResolve'

    def start_pairing(self):
        js = (_json(common.get('https://api.alldebrid.com/v4.1/pin/get', headers=UA, params={'agent': APP_NAME})) or {}).get('data')
        if not js:
            return None
        return {'url': js['user_url'], 'code': js['pin'], 'expires_in': js.get('expires_in', 600), 'interval': 5,
                'state': {'check': js['check'], 'pin': js['pin']}, 'display_url': js.get('base_url') or js['user_url']}

    def poll_pairing(self, state):
        js = _json(common.post(self.API + '/pin/check', data={'pin': state['pin'], 'check': state['check']}, headers=UA)) or {}
        if js.get('status') != 'success':
            code = (js.get('error') or {}).get('code', '')
            return None if code in ('AUTH_BLOCKED', 'AUTH_USER_BANNED', 'PIN_EXPIRED') else False
        d = js.get('data') or {}
        if d.get('activated') and d.get('apikey'):
            store.put(self.id, token=d['apikey'])
            return True
        return False

    def account(self):
        js = (_json(common.get('https://api.alldebrid.com/v4.1/user', headers=dict(UA, Authorization='Bearer ' + self.token()), params={'agent': self.AGENT})) or {})
        u = (js.get('data') or {}).get('user') or {}
        return {'user': u.get('username'), 'premium': bool(u.get('isPremium')), 'expires': u.get('premiumUntil')} if u else {}

    def _fetch_hosts(self):
        js = _json(common.get(self.API + '/hosts/domains', headers=UA)) or {}
        d = js.get('data') or {}
        return list(d.get('hosts') or []) + list(d.get('redirectors') or [])

    def unrestrict(self, url):
        js = _json(common.get(self.API + '/link/unlock', headers=dict(UA, Authorization='Bearer ' + self.token()), params={'agent': self.AGENT, 'link': url})) or {}
        if js.get('status') == 'success':
            d = js.get('data') or {}
            return d.get('link') or None
        return None


class Premiumize(Service):
    id, name = 'premiumize', 'Premiumize'
    CLIENT_ID = '522962560'
    TOKEN = 'https://www.premiumize.me/token'
    API = 'https://www.premiumize.me/api'

    def start_pairing(self):
        js = _json(common.post(self.TOKEN, data={'response_type': 'device_code', 'client_id': self.CLIENT_ID}, headers=UA))
        if not js or 'device_code' not in js:
            return None
        return {'url': js['verification_uri'], 'code': js['user_code'], 'expires_in': js.get('expires_in', 600),
                'interval': js.get('interval', 5), 'state': js['device_code'], 'display_url': js['verification_uri']}

    def poll_pairing(self, state):
        r = common.post(self.TOKEN, data={'grant_type': 'device_code', 'client_id': self.CLIENT_ID, 'code': state}, headers=UA)
        js = _json(r) or {}
        if js.get('access_token'):
            store.put(self.id, token=js['access_token'])
            return True
        if js.get('error') in ('access_denied', 'expired_token'):
            return None
        return False

    def account(self):
        js = _json(common.post(self.API + '/account/info', data={'access_token': self.token()}, headers=UA)) or {}
        return {'user': js.get('customer_id'), 'premium': bool(js.get('premium_until')),
                'expires': js.get('premium_until')} if js.get('status') == 'success' else {}

    def _fetch_hosts(self):
        js = _json(common.get(self.API + '/services/list', headers=UA, params={'access_token': self.token()})) or {}
        return list(js.get('directdl') or js.get('cache') or [])

    def unrestrict(self, url):
        js = _json(common.post(self.API + '/transfer/directdl', data={'access_token': self.token(), 'src': url}, headers=UA)) or {}
        if js.get('status') == 'success':
            content = js.get('content') or []
            if content:
                return content[0].get('stream_link') or content[0].get('link') or None
        return None


class TorBox(Service):
    id, name = 'torbox', 'TorBox'
    any_link = True
    API = 'https://api.torbox.app/v1/api'

    def start_pairing(self):
        js = (_json(common.get(self.API + '/user/auth/device/start', headers=UA, params={'app': APP_NAME})) or {}).get('data')
        if not js:
            return None
        return {'url': js.get('verification_url_complete') or js['verification_url'], 'code': js['code'],
                'expires_in': js.get('expires_in', 600), 'interval': js.get('interval', 5), 'state': js['device_code'],
                'display_url': js.get('friendly_verification_url') or js['verification_url']}

    def poll_pairing(self, state):
        js = _json(common.post(self.API + '/user/auth/device/token', json={'device_code': state}, headers=UA)) or {}
        d = js.get('data') or {}
        if js.get('success') and d.get('access_token'):
            store.put(self.id, token=d['access_token'])
            return True
        if js.get('error') in ('EXPIRED', 'DEVICE_CODE_EXPIRED', 'ACCESS_DENIED'):
            return None
        return False

    def _auth(self):
        return dict(UA, Authorization='Bearer ' + self.token())

    def account(self):
        js = (_json(common.get(self.API + '/user/me', headers=self._auth())) or {}).get('data') or {}
        return {'user': js.get('email'), 'premium': (js.get('plan') or 0) > 0, 'expires': js.get('premium_expires_at')} if js else {}

    def _fetch_hosts(self):
        js = _json(common.get(self.API + '/webdl/hosters', headers=UA)) or {}
        out = []
        for h in js.get('data') or []:
            if h.get('status', True):
                out.extend(h.get('domains') or [])
        return out

    def unrestrict(self, url):
        # create the web download, then ask for its link (instant for cached / supported hosts)
        js = _json(common.post(self.API + '/webdl/createwebdownload', data={'link': url}, headers=self._auth())) or {}
        d = js.get('data') or {}
        wid = d.get('webdownload_id')
        if not wid:
            return None
        for _ in range(8):
            r = common.get(self.API + '/webdl/requestdl', headers=self._auth(),
                           params={'token': self.token(), 'web_id': wid, 'file_id': 0, 'redirect': 'false'})
            j = _json(r) or {}
            if j.get('success') and j.get('data'):
                return j['data']
            time.sleep(1.0)
        return None


class DebridLink(Service):
    id, name = 'debridlink', 'Debrid-Link'
    CLIENT_ID = 'TH7yOa_pgRD1MRyIs6496Q'
    OAUTH = 'https://debrid-link.com/api/oauth'
    API = 'https://debrid-link.com/api/v2'
    SCOPE = 'get.post.delete.downloader get.post.delete.seedbox get.account'

    def token(self):
        rec = store.get(self.id)
        if not rec.get('token'):
            return ''
        if rec.get('refresh') and rec.get('expires_at', 0) and store.now() >= rec['expires_at']:
            js = _json(common.post(self.OAUTH + '/token', data={'client_id': self.CLIENT_ID, 'refresh_token': rec['refresh'],
                                                                 'grant_type': 'refresh_token'}, headers=UA)) or {}
            if js.get('access_token'):
                store.put(self.id, token=js['access_token'], expires_at=store.now() + int(js.get('expires_in', 3600)) - 120)
                return js['access_token']
            store.clear(self.id)
            return ''
        return rec['token']

    def start_pairing(self):
        js = _json(common.post(self.OAUTH + '/device/code', data={'client_id': self.CLIENT_ID, 'scope': self.SCOPE}, headers=UA))
        if not js or 'device_code' not in js:
            return None
        return {'url': js['verification_url'] + '/' + js['user_code'], 'code': js['user_code'],
                'expires_in': js.get('expires_in', 900), 'interval': max(js.get('interval', 4), 4), 'state': js['device_code'],
                'display_url': js['verification_url']}

    def poll_pairing(self, state):
        r = common.post(self.OAUTH + '/token', data={'client_id': self.CLIENT_ID, 'code': state,
                                                     'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'}, headers=UA)
        js = _json(r) or {}
        if js.get('access_token'):
            store.put(self.id, token=js['access_token'], refresh=js.get('refresh_token', ''),
                      expires_at=store.now() + int(js.get('expires_in', 3600)) - 120)
            return True
        return False if js.get('error', 'authorization_pending') == 'authorization_pending' else None

    def _auth(self):
        return dict(UA, Authorization='Bearer ' + self.token())

    def account(self):
        js = (_json(common.get(self.API + '/account/infos', headers=self._auth())) or {}).get('value') or {}
        return {'user': js.get('email') or js.get('pseudo'), 'premium': js.get('accountType') == 1,
                'expires': js.get('premiumLeft')} if js else {}

    def _fetch_hosts(self):
        js = _json(common.get(self.API + '/downloader/hostnames', headers=UA)) or {}
        return list(js.get('value') or [])

    def unrestrict(self, url):
        js = _json(common.post(self.API + '/downloader/add', data={'url': url}, headers=self._auth())) or {}
        v = js.get('value') or {}
        return v.get('downloadUrl') or None

    def _existing(self, ih):
        """The user's own seedbox item for this torrent, if there is one (it is never removed by us)."""
        js = _json(common.get(self.API + '/seedbox/list?page=0&perPage=100', headers=self._auth())) or {}
        for it in (js.get('value') or []):
            if str(it.get('hashString') or '').lower() == ih.lower():
                return it
        return None

    @staticmethod
    def _files(info):
        return [{'name': (f.get('name') or '').split('/')[-1], 'size': f.get('size') or 0, 'url': f.get('downloadUrl')}
                for f in info.get('files') or [] if f.get('downloadUrl')]

    def _remove(self, tid):
        try:
            common.session().delete(self.API + '/seedbox/%s/remove' % tid, headers=self._auth(), timeout=10)
        except Exception:
            pass

    def cached_hashes(self, hashes):
        out = set()
        for i in range(0, len(hashes), 50):
            chunk = hashes[i:i + 50]
            js = _json(common.get(self.API + '/seedbox/cached', params={'url': ','.join(chunk)}, headers=self._auth()))
            if not isinstance(js, dict) or not js.get('success', True):
                return None
            val = js.get('value')
            if not isinstance(val, dict) or any(not re.fullmatch(r'[0-9a-fA-F]{40}', str(k)) for k in val):
                return None                   # not the shape this expects: say nothing rather than hide every torrent
            out.update(k.lower() for k, v in val.items() if v)
        return out

    def magnet_files(self, magnet):
        m = re.search(r'btih:([0-9a-fA-F]{32,40})', magnet or '')
        if not m:
            return None
        mine = self._existing(m.group(1))
        if mine:                                              # already in the account: use it, leave it alone
            return self._files(mine) if int(mine.get('downloadPercent') or 0) >= 100 else None
        r = common.post(self.API + '/seedbox/add', data={'url': m.group(1).lower(), 'async': 'true'}, headers=self._auth())
        if r is None or r.status_code != 200:
            return None                       # 422: not cached
        v = (_json(r) or {}).get('value') or {}
        tid = v.get('id')
        if not tid or (v.get('downloadPercent') or 0) < 100:
            if tid:
                self._remove(tid)             # we added it just now
            return None
        info = (_json(common.get(self.API + '/seedbox/%s/infos' % tid, headers=self._auth())) or {}).get('value') or {}
        files = self._files(info)
        self._remove(tid)                     # cached check only: take our probe out again
        return files or None

    def magnet_download(self, magnet, progress_cb=None, timeout=90):
        m = re.search(r'btih:([0-9a-fA-F]{32,40})', magnet or '')
        if not m:
            return None
        mine = self._existing(m.group(1))
        created = mine is None
        if mine:
            tid = mine.get('id')
        else:
            r = common.post(self.API + '/seedbox/add', data={'url': magnet, 'async': 'true'}, headers=self._auth())
            v = (_json(r) or {}).get('value') or {}
            tid = v.get('id')
        if not tid:
            return None
        deadline = time.time() + timeout
        while time.time() < deadline:
            info = (_json(common.get(self.API + '/seedbox/%s/infos' % tid, headers=self._auth())) or {}).get('value') or {}
            pct = int(info.get('downloadPercent') or 0)
            if progress_cb and progress_cb('Debrid-Link %d%%' % pct, pct) is False:
                break
            if pct >= 100:
                return self._files(info) or None
            time.sleep(2.0)
        if created:
            self._remove(tid)                 # only an item we added ourselves is ever removed
        return None


class Offcloud(Service):
    id, name = 'offcloud', 'Offcloud'
    OAUTH = 'https://offcloud.com/oauth'
    API = 'https://offcloud.com/api'

    def start_pairing(self):
        r = common.post(self.OAUTH + '/device/code', json={}, headers=UA)
        js = _json(r)
        if not js or 'device_code' not in js:
            return None
        return {'url': js.get('verification_uri_complete') or js['verification_uri'], 'code': js['user_code'],
                'expires_in': js.get('expires_in', 600), 'interval': js.get('interval', 5), 'state': js['device_code'],
                'display_url': js['verification_uri']}

    def poll_pairing(self, state):
        r = common.post(self.OAUTH + '/token', json={'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
                                                      'device_code': state}, headers=UA)
        js = _json(r) or {}
        if js.get('access_token'):
            store.put(self.id, token=js['access_token'])
            return True
        return None if js.get('error') in ('expired_token', 'access_denied') else False

    def _auth(self):
        return dict(UA, Authorization='Bearer ' + self.token())

    def account(self):
        js = _json(common.get(self.API + '/account/info', headers=self._auth())) or {}
        return {'user': js.get('email'), 'premium': True} if js.get('email') else {}

    def _fetch_hosts(self):
        r = common.get(self.API + '/sites', headers=self._auth())
        js = _json(r)
        if not isinstance(js, list):
            return []
        return [x['name'].lower() for x in js if x.get('status') == 'up' and x.get('name')]

    def supports(self, url):
        host = urlparse(url).netloc.lower()
        return any(h in host for h in self._hosts())

    def unrestrict(self, url):
        js = _json(common.post(self.API + '/cloud', json={'url': url}, headers=self._auth())) or {}
        rid = js.get('requestId')
        if not rid:
            return None
        created = (js.get('status') or 'created') == 'created'      # only an item we just created is cleaned up again
        deadline = time.time() + 25
        link = None
        while time.time() < deadline:
            st = _json(common.post(self.API + '/cloud/status', json={'requestId': rid}, headers=self._auth())) or {}
            status = (st.get('status') or {}).get('status')
            if status == 'downloaded':
                ex = _json(common.get(self.API + '/cloud/explore/' + rid, headers=self._auth()))
                if isinstance(ex, list) and ex:
                    link = ex[0]
                break
            if status in ('error', 'canceled'):
                break
            time.sleep(1.0)
        if created:
            common.post(self.API + '/cloud/remove', json={'requests': [rid]}, headers=self._auth())
        return link

    def cached_hashes(self, hashes):
        out = set()
        for i in range(0, len(hashes), 50):
            chunk = hashes[i:i + 50]
            info = _json(common.post(self.API + '/cache/info', json={'urls': ['magnet:?xt=urn:btih:' + h for h in chunk]}, headers=self._auth()))
            if not isinstance(info, list) or len(info) != len(chunk):
                return None
            out.update(h for h, row in zip(chunk, info) if isinstance(row, dict) and row.get('cached'))
        return out

    def magnet_files(self, magnet):
        m = re.search(r'btih:([0-9a-fA-F]{32,40})', magnet or '')
        if not m:
            return None
        link = 'magnet:?xt=urn:btih:' + m.group(1).lower()
        info = _json(common.post(self.API + '/cache/info', json={'urls': [link]}, headers=self._auth()))
        if not (isinstance(info, list) and info and info[0].get('cached')):
            return None
        res = _json(common.post(self.API + '/cache/download', json={'url': link}, headers=self._auth()))
        if not isinstance(res, list):
            return None
        return [{'name': f.get('filename') or '', 'size': f.get('size') or 0, 'url': f.get('url')} for f in res if f.get('url')] or None

    def magnet_download(self, magnet, progress_cb=None, timeout=90):
        m = re.search(r'btih:([0-9a-fA-F]{32,40})', magnet or '')
        if not m:
            return None
        link = 'magnet:?xt=urn:btih:' + m.group(1).lower()
        js = _json(common.post(self.API + '/cloud', json={'url': link}, headers=self._auth())) or {}
        rid = js.get('requestId')
        if not rid:
            return None
        created = (js.get('status') or 'created') == 'created'
        deadline = time.time() + timeout
        while time.time() < deadline:
            st = _json(common.post(self.API + '/cloud/status', json={'requestId': rid}, headers=self._auth())) or {}
            status = (st.get('status') or {}).get('status')
            if progress_cb and progress_cb('Offcloud: %s' % (status or 'queued'), 50) is False:
                break
            if status == 'downloaded':
                ex = _json(common.get(self.API + '/cloud/explore/' + rid, headers=self._auth()))
                if isinstance(ex, list) and ex:
                    return [{'name': u.split('?')[0].rsplit('/', 1)[-1], 'size': 0, 'url': u} for u in ex]
                return None
            if status in ('error', 'canceled'):
                break
            time.sleep(2.0)
        if created:
            common.post(self.API + '/cloud/remove', json={'requests': [rid]}, headers=self._auth())
        return None


class MegaDebrid(Service):
    """Mega-Debrid: no device-code flow, the account is a login + password. They are asked for once (Kodi dialogs),
    kept in this add-on's own profile folder so the session token can be renewed, and used only against mega-debrid.eu."""
    id, name = 'megadebrid', 'Mega-Debrid'
    credentials = ('username', 'password')
    API = 'https://www.mega-debrid.eu/api.php'
    TOKEN_TTL = 2 * 3600

    def _login(self, username, password):
        r = common.post(self.API + '?action=connectUser', data={'login': username, 'password': password}, headers=UA)
        js = _json(r) or {}
        if js.get('response_code') == 'ok' and js.get('token'):
            return js
        return None

    def pair_credentials(self, username, password):
        """True when the login works; the account is then stored."""
        js = self._login(username, password)
        if not js:
            return False
        store.put(self.id, token=js['token'], expires_at=store.now() + self.TOKEN_TTL, login=username, password=password,
                  user=js.get('email') or username, vip_end=js.get('vip_end'))
        return True

    def token(self):
        rec = store.get(self.id)
        if not rec.get('login'):
            return ''
        if rec.get('token') and rec.get('expires_at', 0) > store.now():
            return rec['token']
        js = self._login(rec['login'], rec.get('password', ''))
        if not js:
            return ''
        store.put(self.id, token=js['token'], expires_at=store.now() + self.TOKEN_TTL, vip_end=js.get('vip_end'))
        return js['token']

    def authorized(self):
        return bool(store.get(self.id).get('login'))

    def account(self):
        rec = store.get(self.id)
        if not rec.get('login') or not self.token():
            return {}
        return {'user': rec.get('user') or rec.get('login'), 'premium': True, 'expires': store.get(self.id).get('vip_end')}

    def start_pairing(self):
        return None

    def poll_pairing(self, state):
        return None

    def _fetch_hosts(self):
        js = _json(common.get(self.API + '?action=getHostersList', headers=UA)) or {}
        out = []
        for h in js.get('hosters') or []:
            if h.get('status', 'up') == 'up':
                out += [d.lower() for d in (h.get('domains') or [])]
        return out

    def unrestrict(self, url):
        for attempt in (0, 1):
            tok = self.token()
            if not tok:
                return None
            js = _json(common.post(self.API + '?action=getLink&token=' + tok, data={'link': url}, headers=UA)) or {}
            if js.get('response_code') == 'ok' and js.get('debridLink'):
                link = str(js['debridLink']).strip('"')
                return link if link.startswith('http') else None
            if js.get('response_code') in ('TOKEN_ERROR', 'TOKEN_NOT_VALID') and attempt == 0:
                store.put(self.id, expires_at=0)             # session ended: log in again once
                continue
            return None
        return None


_VIDEO = ('.mkv', '.mp4', '.avi', '.m4v', '.mov', '.ts', '.wmv', '.webm', '.mpg', '.mpeg')


class Putio(Service):
    """Put.io: a cloud seedbox. There is no device-code flow for third parties (an app id must be registered with them), so the
    account is the OAuth token the viewer makes on put.io (Settings > Developers > an app) and pastes once. Torrents only: Put.io
    does not unrestrict hoster links. A torrent that Put.io already holds finishes the moment it is added (its files are
    then listed and a direct address is asked for); anything else is fetched and waited for."""
    id, name = 'putio', 'Put.io'
    paste_token = True
    API = 'https://api.put.io/v2'

    def _auth(self):
        return dict(UA, Authorization='Bearer ' + self.token())

    def pair_token(self, token):
        """True when Put.io accepts the token; the account is then stored."""
        token = (token or '').strip()
        if not token:
            return False
        store.put(self.id, token=token)
        who = self.account()
        if who.get('user'):
            store.put(self.id, user=who['user'])
            return True
        store.clear(self.id)
        return False

    def start_pairing(self):
        return None

    def poll_pairing(self, state):
        return None

    def account(self):
        if not self.token():
            return {}
        js = _json(common.get(self.API + '/account/info', headers=self._auth())) or {}
        info = js.get('info') or {}
        if not info.get('username'):
            return {}
        return {'user': info['username'], 'premium': bool(info.get('account_active', True))}

    def supports(self, url):
        return False

    def unrestrict(self, url):
        return None

    def _add(self, magnet):
        if not re.search(r'btih:([0-9a-fA-F]{32,40})', magnet or ''):
            return None
        js = _json(common.post(self.API + '/transfers/add', data={'url': magnet}, headers=self._auth())) or {}
        t = js.get('transfer') or {}
        return t if t.get('id') else None

    def _transfer(self, tid):
        js = _json(common.get('%s/transfers/%s' % (self.API, tid), headers=self._auth())) or {}
        return js.get('transfer') or {}

    def _walk(self, file_id, depth=0):
        """[{'name', 'size', 'id'}] of the files under a Put.io file / folder id."""
        js = _json(common.get('%s/files/%s' % (self.API, file_id), headers=self._auth())) or {}
        f = js.get('file') or {}
        if not f:
            return []
        if f.get('file_type') != 'FOLDER':
            return [{'name': f.get('name') or '', 'size': f.get('size') or 0, 'id': f['id']}]
        if depth > 3:
            return []
        lst = _json(common.get('%s/files/list?parent_id=%s&per_page=1000' % (self.API, file_id), headers=self._auth())) or {}
        out = []
        for c in lst.get('files') or []:
            if c.get('file_type') == 'FOLDER':
                out += self._walk(c['id'], depth + 1)
            else:
                out.append({'name': c.get('name') or '', 'size': c.get('size') or 0, 'id': c['id']})
        return out

    def _files_of(self, transfer):
        fid = transfer.get('file_id')
        if not fid:
            return None
        out = []
        for f in self._walk(fid):
            if not f['name'].lower().endswith(_VIDEO):
                continue
            js = _json(common.get('%s/files/%s/url' % (self.API, f['id']), headers=self._auth())) or {}
            if js.get('url'):
                out.append({'name': f['name'], 'size': f['size'], 'url': js['url']})
        return out or None

    def magnet_files(self, magnet):
        t = self._add(magnet)
        if not t:
            return None
        deadline = time.time() + 7
        while time.time() < deadline:
            t = self._transfer(t['id']) or t
            if t.get('status') in ('COMPLETED', 'SEEDING'):
                return self._files_of(t)
            if t.get('status') == 'ERROR':
                break
            time.sleep(1.0)
        common.post(self.API + '/transfers/cancel', data={'transfer_ids': t.get('id')}, headers=self._auth())
        return None

    def magnet_download(self, magnet, progress_cb=None, timeout=90):
        t = self._add(magnet)
        if not t:
            return None
        deadline = time.time() + timeout
        while time.time() < deadline:
            t = self._transfer(t['id']) or t
            st = t.get('status')
            pct = int(t.get('percent_done') or 0)
            if progress_cb and progress_cb('Put.io: %s %s%%' % ((st or 'queued').lower(), pct), pct) is False:
                break
            if st in ('COMPLETED', 'SEEDING'):
                return self._files_of(t)
            if st == 'ERROR':
                return None
            time.sleep(2.0)
        return None


class LinkSnappy(Service):
    """LinkSnappy: a login + password account (no device-code flow). The login opens a session cookie that lasts a month; the
    credentials stay in this add-on's profile folder so it can be renewed, and are sent only to linksnappy.com."""
    id, name = 'linksnappy', 'LinkSnappy'
    credentials = ('username', 'password')
    API = 'https://linksnappy.com/api'

    def __init__(self):
        self._sess = None
        self._sess_for = None

    def _session(self):
        """A logged-in requests session, or None."""
        rec = store.get(self.id)
        if not rec.get('login'):
            return None
        key = (rec['login'], rec.get('password'))
        if self._sess is not None and self._sess_for == key and rec.get('expires_at', 0) > store.now():
            return self._sess
        s = self._login(rec['login'], rec.get('password', ''))
        if s is None:
            self._sess = None
            return None
        self._sess, self._sess_for = s, key
        store.put(self.id, expires_at=store.now() + 20 * 86400)
        return s

    def _login(self, username, password):
        if common.requests is None:
            return None
        s = common.requests.Session()
        s.headers['User-Agent'] = UA['User-Agent']
        try:
            js = s.get(self.API + '/AUTHENTICATE', params={'username': username, 'password': password}, timeout=15).json()
        except Exception:
            return None
        if js.get('status') == 'OK' and not js.get('error'):
            return s
        return None

    def pair_credentials(self, username, password):
        """True when the login works; the account is then stored."""
        s = self._login(username, password)
        if s is None:
            return False
        store.put(self.id, login=username, password=password, user=username, expires_at=store.now() + 20 * 86400)
        self._sess, self._sess_for = s, (username, password)
        return True

    def authorized(self):
        return bool(store.get(self.id).get('login'))

    def token(self):
        return 'session' if self.authorized() else ''

    def account(self):
        rec = store.get(self.id)
        if not rec.get('login') or self._session() is None:
            return {}
        return {'user': rec.get('user') or rec['login'], 'premium': True}

    def start_pairing(self):
        return None

    def poll_pairing(self, state):
        return None

    def _call(self, path, **params):
        """The JSON answer of an API call (one fresh login when the session ended), or {}."""
        for attempt in (0, 1):
            s = self._session()
            if s is None:
                return {}
            try:
                js = s.get(self.API + '/' + path, params=params, timeout=25).json()
            except Exception:
                return {}
            if isinstance(js, dict) and js.get('status') == 'ERROR' and attempt == 0 and 'login' in str(js.get('error', '')).lower():
                store.put(self.id, expires_at=0)
                self._sess = None
                continue
            return js if isinstance(js, dict) else {}
        return {}

    def _fetch_hosts(self):
        js = self._call('FILEHOSTSREALTIME')
        out = []
        if js.get('status') == 'OK' and isinstance(js.get('return'), dict):
            for host, info in js['return'].items():
                if str(info.get('Status')) == '0' or host == 'mp3':
                    continue
                out.append(host.lower())
                out += [a.lower() for a in (info.get('alias') or [])]
        return out

    def unrestrict(self, url):
        import json as _j
        js = self._call('linkgen', genLinks=_j.dumps({'link': url}))
        links = js.get('links') or []
        if not links or links[0].get('status') != 'OK':
            return None
        return links[0].get('generated') or None

    # ── torrents ──
    @staticmethod
    def _btih(magnet):
        m = re.search(r'btih:([0-9a-fA-F]{32,40})', magnet or '')
        return m.group(1).lower() if m else ''

    def _cached(self, h):
        js = self._call('torrents/HASHCHECK', hash=h)
        return js.get('status') == 'OK' and js.get('return') == 'CACHED'

    def cached_hashes(self, hashes):
        from concurrent.futures import ThreadPoolExecutor
        hashes = list(hashes)[:60]
        if not hashes or self._session() is None:
            return set()
        with ThreadPoolExecutor(max_workers=8) as ex:
            flags = list(ex.map(self._cached, hashes))
        return set(h for h, ok in zip(hashes, flags) if ok)

    def _folder(self):
        js = self._call('torrents/FOLDERLIST')
        if js.get('status') == 'OK' and not js.get('error'):
            for it in (js.get('return') or [])[::-1]:
                if it.get('type') == 'root' and it.get('text') == 'Downloads':
                    return it.get('id', '')
        return ''

    def _start(self, magnet):
        """The torrent id of a magnet that was added and started, or ''."""
        js = self._call('torrents/ADDMAGNET', magnetlinks=magnet)
        if js.get('status') != 'OK' or js.get('error') is not False:
            return ''
        row = (js.get('return') or [{}])[0]
        tid = row.get('torrentid')
        if not tid or row.get('error'):
            return ''
        fid = self._folder()
        for _ in range(10):
            r = self._call('torrents/START', tid=tid, fid=fid)
            if r.get('error') is False:
                return str(tid)
            if 'in progress' not in str(r.get('error', '')).lower():
                break
            time.sleep(3)
        return str(tid)

    def _final(self, link):
        s = self._session()
        if s is None:
            return link
        try:
            return s.head(link, allow_redirects=True, timeout=15).url or link
        except Exception:
            return link

    def _files(self, tid):
        js = self._call('torrents/FILES', id=tid)
        if js.get('status') != 'OK':
            return None
        found = []

        def walk(d):
            for v in d.values():
                if not isinstance(v, dict):
                    continue
                if v.get('downloadLink'):
                    found.append(v)
                else:
                    walk(v)
        walk(js.get('return') if isinstance(js.get('return'), dict) else js)
        files = []
        for v in found:
            link = v['downloadLink']
            name = v.get('name') or v.get('filename') or link.split('?')[0].rsplit('/', 1)[-1]
            if not name.lower().endswith(_VIDEO):
                continue
            try:
                size = int(v.get('size') or 0)
            except (TypeError, ValueError):
                size = 0
            files.append({'name': name, 'size': size, 'url': self._final(link)})
        return files or None

    def magnet_files(self, magnet):
        h = self._btih(magnet)
        if not h or not self._cached(h):
            return None
        tid = self._start(magnet)
        if not tid:
            return None
        time.sleep(1.0)
        return self._files(tid)

    def magnet_download(self, magnet, progress_cb=None, timeout=90):
        tid = self._start(magnet)
        if not tid:
            return None
        deadline = time.time() + timeout
        while time.time() < deadline:
            st = self._call('torrents/STATUS', tid=tid).get('return') or {}
            try:
                pct = int(float(st.get('percentDone') or 0))
            except (TypeError, ValueError):
                pct = 0
            if progress_cb and progress_cb('LinkSnappy: %s%%' % pct, pct) is False:
                break
            if st.get('status') == 'FINISHED':
                time.sleep(2.0)
                return self._files(tid)
            time.sleep(2.0)
        return None


ALL = [RealDebrid(), AllDebrid(), Premiumize(), TorBox(), DebridLink(), Offcloud(), MegaDebrid(), Putio(), LinkSnappy()]
BY_ID = {s.id: s for s in ALL}
