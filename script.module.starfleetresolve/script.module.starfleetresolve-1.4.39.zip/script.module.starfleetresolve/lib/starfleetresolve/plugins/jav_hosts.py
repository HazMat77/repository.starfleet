# -*- coding: utf-8 -*-
"""Players of the JAV sites that no other resolver reads: JavyNow (the player of masutabe / iqoo / nukistream) and VJAV."""
import re

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver


class JavyNow(Resolver):
    """javynow.com/player/<id>/: the page builds its <source> from a packed script; the address carries its own key and expiry."""
    name = 'javynow'
    domains = ('javynow.com',)
    priority = 'first'

    def resolve(self, url, referer=''):
        m = re.search(r'javynow\.com/(?:player|video)/(\d+)', url)
        if not m:
            return None
        page = 'https://javynow.com/player/%s/' % m.group(1)
        r = common.get(page, referer=referer or 'https://masutabe.info/')
        if r is None or r.status_code != 200:
            return None
        js = common.unpack_js(r.text) or r.text
        s = re.search(r'<source[^>]+src=["\']([^"\']+)["\']', js) or re.search(r'(https?://[^\s"\'<>]+/media=hls/[^\s"\'<>]+)', js)
        if not s:
            return None
        src = s.group(1)
        if src.startswith('//'):
            src = 'https:' + src
        return common.with_headers(src, referer='https://javynow.com/')


class Vjav(Resolver):
    """vjav.com / senzuri.tube /embed/<id>/ (TXXX-network sites): /api/videofile.php lists the file, its address is written in a
    letter-swapped base64."""
    name = 'vjav'
    domains = ('vjav.com', 'senzuri.tube')
    priority = 'first'

    def resolve(self, url, referer=''):
        m = re.search(r'(vjav\.com|senzuri\.tube)/(?:embed|videos?)/(\d+)', url)
        if not m:
            return None
        host, vid = m.group(1), m.group(2)
        r = common.get('https://%s/api/videofile.php?video_id=%s&lifetime=8640000' % (host, vid), referer='https://%s/embed/%s/' % (host, vid))
        if r is None or r.status_code != 200:
            return None
        try:
            from starfleetresolve.ru.lib import helpers
            found = re.findall(r'video_url":"([^"]+)', r.text)            # the raw text: the letter swaps are written as \u04xx escapes
            real = helpers.Tdecode(found[-1]) if found else ''
        except Exception:
            return None
        if not real:
            return None
        if real.startswith('/'):
            real = 'https://%s%s' % (host, real)
        return common.with_headers(real, referer='https://%s/' % host)
