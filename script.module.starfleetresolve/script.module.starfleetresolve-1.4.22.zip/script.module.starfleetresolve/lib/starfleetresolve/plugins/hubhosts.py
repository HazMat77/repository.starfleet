# -*- coding: utf-8 -*-
"""Wrapper links the event / channel hubs hand out: they only name the real player, so the address is rebuilt from them."""
import re
from urllib.parse import parse_qs, urlparse

from starfleetresolve.plugins.base import Resolver


def _resolve_inner(url, referer):
    from starfleetresolve import resolve
    return resolve(url, referer=referer, debrid_links=False)


class HesgoalPlayer(Resolver):
    """hesgoal.team/ntvtvplayer.html?id=<channel>: a page that only frames wideiptv.top/player/<channel>."""
    name = 'hesgoal'
    domains = ('hesgoal.team',)
    priority = 'first'

    def resolve(self, url, referer=''):
        m = re.search(r'[?&]id=([A-Za-z0-9_-]+)', url.split('|')[0])
        return _resolve_inner('https://wideiptv.top/player/%s' % m.group(1), 'https://hesgoal.team/') if m else None


class FrameWrapper(Resolver):
    """hitsportshdd.xyz/fr.php?src=<player url>: a frame wrapper around another player address."""
    name = 'framewrapper'
    domains = ('hitsportshdd.xyz',)
    priority = 'first'

    def resolve(self, url, referer=''):
        src = (parse_qs(urlparse(url.split('|')[0]).query).get('src') or [''])[0]
        return _resolve_inner(src, referer or url) if src.startswith('http') else None
