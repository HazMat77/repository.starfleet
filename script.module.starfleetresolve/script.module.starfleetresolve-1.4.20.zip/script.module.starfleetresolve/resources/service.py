# -*- coding: utf-8 -*-
"""Runs when Kodi starts: checks that the debrid accounts held here still work and, if ResolveURL (or the Starfleet plugin)
was paired again since, takes the new working account over. Then keeps an eye on those two settings files (a stat call every
minute) and checks again the moment one of them changes. Quiet: no dialogs."""
import os
import sys

import xbmc

# a script.module's own `lib` folder is only on the import path for add-ons that import it: this service starts on its own, so on some
# devices (seen on an Android TV box) it did not find its package ("No module named 'starfleetresolve'") and never ran
_LIB = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'lib')
if os.path.isdir(_LIB) and _LIB not in sys.path:
    sys.path.insert(0, _LIB)


def main():
    mon = xbmc.Monitor()
    if mon.waitForAbort(20):                     # let Kodi finish starting before doing network work
        return
    try:
        from starfleetresolve.debrid import selfcheck, importer
        importer.ensure()                        # imports what is new, then starts the check
    except Exception as e:
        xbmc.log('[Starfleet Resolver] startup check failed: %s' % e, xbmc.LOGWARNING)
        return
    last = selfcheck.stamp()
    while not mon.waitForAbort(60):
        cur = selfcheck.stamp()
        if cur != last:
            last = cur
            if mon.waitForAbort(5):              # the other add-on may still be writing
                return
            try:
                importer.import_from_plugin()    # newly paired services
                importer.import_from_resolveurl()
                selfcheck.run_in_background()
            except Exception as e:
                xbmc.log('[Starfleet Resolver] account re-check failed: %s' % e, xbmc.LOGWARNING)


if __name__ == '__main__':
    main()
