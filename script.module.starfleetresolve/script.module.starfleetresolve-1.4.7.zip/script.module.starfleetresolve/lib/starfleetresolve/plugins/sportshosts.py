# -*- coding: utf-8 -*-
"""Sports embed hosts with a fixed, host-specific format (the generic page reader covers the rest)."""
from starfleetresolve import common, pagedecode
from starfleetresolve.plugins.base import Resolver


class GSports(Resolver):
    """gsports.lat event / player pages: the player script travels as <page>?v=font.woff2 (XOR 'gs99' + raw deflate)."""
    name = 'gsports'
    domains = ('gsports.lat',)
    priority = 'first'

    def resolve(self, url, referer=''):
        return pagedecode.font_payload(url.split('|')[0])



class TimEmbed(Resolver):
    """ehgembxe.cfd / epiembeds.online player frames (the TimStreams family): the page carries a byte-array script that asks a
    token address for the signed playlist, which is returned XOR-ed with the token (see pagedecode.array_token)."""
    name = 'timembed'
    domains = ('ehgembxe.cfd', 'epiembeds.online', 'embeds.gay')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        ref = referer if referer.startswith('http') else 'https://timst.top/'
        page = common.text(link, referer=ref)
        return pagedecode.array_token(page, link) if page else None
