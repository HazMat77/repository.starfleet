# -*- coding: utf-8 -*-
"""Bring debrid accounts over from the user's Starfleet plugin settings and from the ResolveURL add-on (both on the same
device) so nothing has to be paired twice. Runs once per session and only fills services that are not paired here yet; an account that was paired
here is never overwritten. Tokens are validated against the service before they are kept, and are never logged.

ResolveURL keeps them in special://profile/addon_data/script.module.resolveurl/settings.xml as
<setting id="<Name>Resolver_<field>">value</setting>."""
import os
import xml.etree.ElementTree as ET

from starfleetresolve import common
from starfleetresolve.debrid import store

RU_ID = 'script.module.resolveurl'

# our service id -> (ResolveURL resolver prefix, {their field: our field})
MAP = {
    'realdebrid': ('RealDebridResolver', {'token': 'token', 'refresh': 'refresh', 'client_id': 'client_id', 'client_secret': 'client_secret'}),
    'alldebrid': ('AllDebridResolver', {'token': 'token'}),
    'premiumize': ('PremiumizeMeResolver', {'token': 'token'}),
    'torbox': ('TorBoxResolver', {'apikey': 'token'}),
    'debridlink': ('DebridLinkResolver', {'token': 'token', 'refresh': 'refresh'}),
    'offcloud': ('OffCloudResolver', {'apikey': 'token'}),
}

# the Starfleet plugin's own settings (what a user typed or paired there) -> our service ids
PLUGIN_ID = 'plugin.video.starfleet'
PLUGIN_KEYS = {
    'realdebrid': 'rd_api_key', 'alldebrid': 'ad_api_key', 'premiumize': 'pm_api_key',
    'torbox': 'tb_api_key', 'debridlink': 'dl_api_key', 'offcloud': 'oc_api_key',
}

_done = []


def _settings_path(addon_id=RU_ID):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath('special://profile/addon_data/%s/settings.xml' % addon_id)
    except Exception:
        return ''


def _read(path):
    """{setting id: text} from a Kodi settings.xml (empty values left out)."""
    try:
        root = ET.parse(path).getroot()
    except Exception:
        return {}
    out = {}
    for el in root.iter('setting'):
        sid, val = el.get('id'), (el.text or '').strip()
        if sid and val:
            out[sid] = val
    return out


def import_from_resolveurl(path=None, validate=True, force=False):
    """-> {service id: 'imported' | 'kept' | 'invalid' | 'none'}. `path` is for tests."""
    from starfleetresolve.debrid.services import BY_ID
    result = {}
    path = path or _settings_path()
    vals = _read(path) if path and os.path.exists(path) else {}
    for sid, (prefix, fields) in MAP.items():
        svc = BY_ID.get(sid)
        if svc is None:
            continue
        if svc.authorized() and not force:
            result[sid] = 'kept'
            continue
        rec = {}
        for theirs, ours in fields.items():
            v = vals.get('%s_%s' % (prefix, theirs))
            if v:
                rec[ours] = v
        if not rec.get('token'):
            result[sid] = 'none'
            continue
        if rec.get('refresh') and sid == 'realdebrid':
            rec['expires_at'] = store.now() + 60          # refreshed on first use (their expiry time is not stored)
        elif rec.get('refresh'):
            rec['expires_at'] = store.now() + 60
        rec['imported_from'] = 'resolveurl'
        store.put(sid, **rec)
        ok = True
        if validate:
            try:
                acct = svc.account() or {}
                ok = bool(acct.get('user')) and bool(svc.authorized())
            except Exception:
                ok = False
        if ok:
            common.log('debrid: %s account imported from ResolveURL' % sid)
            result[sid] = 'imported'
        else:
            store.clear(sid)
            result[sid] = 'invalid'
    result['megadebrid'] = _import_megadebrid(vals, 'MegaDebridResolver_username', 'MegaDebridResolver_password', None,
                                              'resolveurl', validate, force)
    return result


def _import_megadebrid(vals, user_key, pass_key, enabled_key, source, validate, force):
    from starfleetresolve.debrid.services import BY_ID
    svc = BY_ID.get('megadebrid')
    if svc is None:
        return 'none'
    if svc.authorized() and not force:
        return 'kept'
    u, p = vals.get(user_key), vals.get(pass_key)
    if not (u and p):
        return 'none'
    if enabled_key and vals.get(enabled_key) == 'false':
        return 'disabled'
    if validate:
        return 'imported' if svc.pair_credentials(u, p) else 'invalid'
    store.put('megadebrid', login=u, password=p, user=u, token='', expires_at=0, imported_from=source)
    return 'imported'


def import_from_plugin(path=None, validate=True, force=False):
    """The Starfleet plugin's own debrid keys (Settings > Premium Services) -> this module's accounts, so the plugin can
    use the resolver's debrid without asking for another pairing. -> {service id: status} like import_from_resolveurl."""
    from starfleetresolve.debrid.services import BY_ID
    result = {}
    path = path or _settings_path(PLUGIN_ID)
    vals = _read(path) if path and os.path.exists(path) else {}
    for sid, key in PLUGIN_KEYS.items():
        svc = BY_ID.get(sid)
        if svc is None:
            continue
        if svc.authorized() and not force:
            result[sid] = 'kept'
            continue
        tok = vals.get(key)
        if not tok:
            result[sid] = 'none'
            continue
        if vals.get(key.replace('_api_key', '_enabled')) == 'false':      # switched off in the plugin: leave it off
            result[sid] = 'disabled'
            continue
        store.put(sid, token=tok, imported_from='plugin')
        ok = True
        if validate:
            try:
                acct = svc.account() or {}
                ok = bool(acct.get('user')) and bool(svc.authorized())
            except Exception:
                ok = False
        if ok:
            common.log('debrid: %s account imported from the Starfleet plugin' % sid)
            result[sid] = 'imported'
        else:
            store.clear(sid)
            result[sid] = 'invalid'
    result['megadebrid'] = _import_megadebrid(vals, 'md_username', 'md_password', 'md_enabled', 'plugin', validate, force)
    return result


def ensure():
    """Once per process: import whatever is paired in ResolveURL and not yet here."""
    if _done:
        return
    _done.append(1)
    for fn in (import_from_plugin, import_from_resolveurl):      # the plugin's own keys win over ResolveURL's
        try:
            fn()
        except Exception as e:
            common.log('debrid import failed: %s' % e)
