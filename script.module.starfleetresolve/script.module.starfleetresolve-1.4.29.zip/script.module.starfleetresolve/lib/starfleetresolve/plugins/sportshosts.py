# -*- coding: utf-8 -*-
"""Sports embed hosts with a fixed, host-specific format (the generic page reader covers the rest)."""
import re

from starfleetresolve import common, pagedecode
from starfleetresolve.plugins.base import Resolver


class GSports(Resolver):
    """gsports.lat event / player pages: the player script travels as <page>?v=font.woff2 (XOR 'gs99' + raw deflate)."""
    name = 'gsports'
    domains = ('gsports.lat',)
    priority = 'first'

    def resolve(self, url, referer=''):
        return pagedecode.font_payload(url.split('|')[0])



def _urlsafe_b64(piece):
    import base64
    piece = piece.replace('-', '+').replace('_', '/')
    try:
        return base64.b64decode(piece + '=' * (-len(piece) % 4)).decode('utf-8', 'replace')
    except Exception:
        return ''


def decode_piece_player(page):
    """Playlist address a player page assembles at run time: the script keeps the address in url-safe base64 pieces
    (var a='..'; var b='..') and joins decode(a)+decode(b)+... through a one-line helper."""
    import re
    m = re.search(r'function (\w+)\(s\)\{s=s\.replace', page or '')
    if not m:
        return ''
    fn = m.group(1)
    pieces = dict(re.findall(r"var (\w+)='([A-Za-z0-9_\-]+)';", page))
    expr = re.search(r'var \w+=((?:%s\(\w+\)\+?)+);' % re.escape(fn), page)
    if not expr:
        return ''
    names = re.findall(r'%s\((\w+)\)' % re.escape(fn), expr.group(1))
    url = ''.join(_urlsafe_b64(pieces.get(n, '')) for n in names)
    return url if url.startswith('http') else ''


class CdnLive(Resolver):
    """cdnlivetv.tv / cdnlivetv.is channel player pages: the page builds a signed playlist address out of base64 pieces."""
    name = 'cdnlive'
    domains = ('cdnlivetv.tv', 'cdnlivetv.is', 'cdn-live.tv')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        from urllib.parse import urlparse
        host = urlparse(link)
        origin = '%s://%s/' % (host.scheme or 'https', host.netloc)
        # the player pages answer on either spelling of the domain: try the one given, then its sibling
        tried = [link]
        for a, b in (('cdnlivetv.tv', 'cdnlivetv.is'), ('cdnlivetv.is', 'cdnlivetv.tv')):
            if a in link:
                tried.append(link.replace(a, b))
        for cand in tried:
            page = common.text(cand, referer=origin)
            stream = decode_piece_player(page) if page else ''
            if stream:
                piped = common.with_headers(stream, referer=origin)
                if common.playlist_ok(piped):
                    return piped
        return None


class TimEmbed(Resolver):
    """ehgembxe.cfd / epiembeds.online player frames (the TimStreams family): the page carries a byte-array script that asks a
    token address for the signed playlist, which is returned XOR-ed with the token (see pagedecode.array_token)."""
    name = 'timembed'
    domains = ('ehgembxe.cfd', 'epiembeds.online', 'embeds.gay')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        # the BinTV links (/bintv/<id>) answer only to BinTV's own player host, the TimStreams ones to timst.top
        refs = [referer] if referer.startswith('http') else (
            ['https://bintv-sources.pages.dev/', 'https://bintv.cc/'] if '/bintv/' in link else ['https://tim-streams.com/', 'https://timst.top/'])
        for ref in refs:
            page = common.text(link, referer=ref)
            stream = pagedecode.array_token(page, link) if page else None
            if stream:
                return stream
        return None


class StrmFree(Resolver):
    """strmfree.st/embed/<sport>/<game><quality>[<server number>] (the player of the streamfree.top live-sports listing).

    The embed page carries a small table of short-lived signed tokens, one per quality (const _0x...={"1080p":{"_t","_e","_n"}});
    the playlist is <host>/<live-origin | live-cdn | live>/<game><quality><suffix>/index.m3u8 with those three values as its query
    and the embed address as Referer. The game page on streamfree.top is the Referer the embed expects when it is fetched, and
    /get-stream-key/<game> says which CDN edge the game is assigned to."""
    name = 'strmfree'
    domains = ('strmfree.st',)
    priority = 'first'
    _SITE = 'https://streamfree.top'
    _EMBED = 'https://strmfree.st'
    _SLUG = re.compile(r'^(.*?)(540p|720p|1080p|2160p)([2-5])?$', re.I)
    _TOKENS = re.compile(r'const\s+_0x\w*\s*=\s*(\{.*?\});', re.S)
    _SUFFIX = re.compile(r'const\s+SOURCE_SUFFIX\s*=\s*[\'"]([^\'"]*)[\'"]')
    _ORDER = ('2160p', '1080p', '720p', '540p')

    def resolve(self, url, referer=''):
        import json
        from urllib.parse import urlparse, quote
        link = url.split('|')[0]
        m = re.match(r'^/embed/([^/]+)/([^/?#]+)', urlparse(link).path)
        if not m:
            return None
        category, slug = m.group(1), m.group(2)
        sm = self._SLUG.match(slug)
        if not sm:
            return None
        key, quality, suffix = sm.group(1), sm.group(2).lower(), sm.group(3) or ''
        want_cdn = 'server=cdn' in link
        page = '%s/player/%s/%s' % (self._SITE, quote(category, safe=''), quote(key, safe=''))
        hdr = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Sec-Fetch-Dest': 'iframe',
               'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'cross-site', 'Upgrade-Insecure-Requests': '1'}
        html = common.text(link, referer=page, headers=hdr) or common.text(link, referer=self._SITE + '/', headers=hdr)
        tm = self._TOKENS.search(html or '')
        if not tm:
            return None
        try:
            tokens = {k.lower(): v for k, v in json.loads(tm.group(1)).items() if isinstance(v, dict)}
        except ValueError:
            return None
        tok = tokens.get(quality)
        if not tok:                                                       # the quality asked for is not offered: the best one that is
            quality = next((q for q in self._ORDER if q in tokens), '')
            tok = tokens.get(quality)
        if not tok or not all(tok.get(k) for k in ('_t', '_e', '_n')):
            return None
        sfx = self._SUFFIX.search(html)
        variant = '%s%s%s' % (key, quality, sfx.group(1) if sfx else suffix)
        query = '?_t=%s&_e=%s&_n=%s' % (tok['_t'], tok['_e'], tok['_n'])
        edges = [(self._EMBED, 'live-origin'), (self._EMBED, 'live')]
        info = common.get(self._EMBED + '/get-stream-key/' + quote(key, safe=''), referer=self._SITE + '/')
        try:
            info = info.json() if info is not None and info.status_code == 200 else {}
        except ValueError:
            info = {}
        dom = (info.get('server_domain') or '').rstrip('/')
        if info.get('is_external') and info.get('external_url'):
            return common.with_headers(info['external_url'], referer=self._EMBED + '/', origin=self._EMBED)
        if dom and info.get('server_name') not in (None, '', 'origin'):
            edges.insert(0 if want_cdn else 1, (dom if '://' in dom else 'https://' + dom, 'live-cdn'))
        for host, path in edges:
            piped = common.with_headers('%s/%s/%s/index.m3u8%s' % (host, path, variant, query), referer=link, origin=self._EMBED)
            if common.playlist_ok(piped):
                return piped
        return None


class PitSport(Resolver):
    """pitsport.st/programs/<id> (a game or race session) and the embdlol.st/embed/<id> player it uses.

    pitsport.st/api/v1/programs/<id>/play lists the program's players (embdlol.st/embed/<uuid>); the player asks
    POST api.embdlol.st/watch {"watchId": <uuid>} for the playlist, which is only given to requests that name embdlol.st as their
    origin. The segments are video hidden in a WebP picture: the Starfleet add-on's relay unwraps them when the stream is played."""
    name = 'pitsport'
    domains = ('pitsport.st', 'embdlol.st')
    priority = 'first'
    _SITE = 'https://pitsport.st'
    _PLAYER = 'https://embdlol.st'
    _API = 'https://api.embdlol.st'

    def _watch(self, embed_url):
        m = re.search(r'/embed/([A-Za-z0-9\-]+)', embed_url)
        if not m:
            return None
        hdr = {'Origin': self._PLAYER, 'Referer': self._PLAYER + '/'}
        r = common.post(self._API + '/watch', json={'watchId': m.group(1)}, headers=hdr)
        try:
            url = (r.json() or {}).get('url') if r is not None and r.status_code == 200 else ''
        except ValueError:
            url = ''
        if not url or not url.startswith('http'):
            return None
        piped = common.with_headers(url, referer=self._PLAYER + '/', origin=self._PLAYER)
        return piped if common.playlist_ok(piped) else None

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        if 'embdlol.st' in link:
            return self._watch(link)
        m = re.search(r'/programs/(\d+)', link)
        if not m:
            return None
        r = common.get('%s/api/v1/programs/%s/play' % (self._SITE, m.group(1)), referer=self._SITE + '/')
        try:
            data = (r.json() or {}).get('data') or {} if r is not None and r.status_code == 200 else {}
        except ValueError:
            return None
        videos = sorted(data.get('videos') or [], key=lambda v: (not v.get('isDefault'), v.get('sortOrder') or 0))
        for v in videos:
            if v.get('embedUrl'):
                got = self._watch(v['embedUrl'])
                if got:
                    return got
        return None


class Viloud(Resolver):
    """player.viloud.tv/embed/play?url=<playlist>: the page only wraps the playlist that is already in the address."""
    name = 'viloud'
    domains = ('viloud.tv',)
    priority = 'first'

    def resolve(self, url, referer=''):
        from urllib.parse import urlparse, parse_qs, unquote
        q = parse_qs(urlparse(url.split('|')[0]).query)
        stream = unquote((q.get('url') or [''])[0])
        if not stream.startswith('http'):
            return None
        piped = common.with_headers(stream, referer='https://player.viloud.tv/', origin='https://player.viloud.tv')
        return piped if common.playlist_ok(piped) else None


class StreamTP(Resolver):
    """streamtp*.sbs / streamtp-*.click channel pages (global1.php?stream=NAME): a Clappr page with the signed playlist in its script.
    The old addresses only forward to the current one ("nuevoDominio")."""
    name = 'streamtp'
    domains = ('streamtp99a.sbs', 'streamtp-golden1.click')
    priority = 'first'

    def match(self, url):
        from urllib.parse import urlparse
        return 'streamtp' in (urlparse(url.split('|')[0]).netloc or '').lower()

    def resolve(self, url, referer=''):
        from urllib.parse import urlparse
        link = url.split('|')[0]
        p = urlparse(link)
        tail = p.path + (('?' + p.query) if p.query else '')
        tries = [link]
        if 'streamtp99a.sbs' not in p.netloc:
            tries.append('https://streamtp99a.sbs' + tail)      # the old addresses only forward to the current one
        for cur in tries:
            for _ in range(3):
                html = common.text(cur, referer=referer or 'https://streamtp99a.sbs/') or ''
                fwd = re.search(r'nuevoDominio\s*=\s*"(https?://[^"]+)"', html)
                if fwd and 'm3u8' not in html:
                    cur = fwd.group(1).rstrip('/') + tail
                    continue
                for m in re.finditer(r'''https?://[^\s"'<>\\]+\.m3u8[^\s"'<>\\]*''', html):
                    piped = common.with_headers(m.group(0), referer=common.origin_of(cur) + '/', origin=common.origin_of(cur))
                    if common.playlist_ok(piped):
                        return piped
                break
        return None
