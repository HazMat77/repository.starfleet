# -*- coding: utf-8 -*-
"""
resources/lib/personal_sources.py

Search the user's personal cloud storage libraries for a matching title.

Supported services:
  MixDrop  — searches Movies and Porn folders via API
  Streamtape — searches all uploaded files via API (requires login token)

Credentials are stored as constants here since they are specific to this
installation. If credentials change, update the constants below.
"""

import re
import xbmc
from resources.lib import cache as _cache

# ── MixDrop ───────────────────────────────────────────────────────────────────

_MD_EMAIL   = 'hazmatrevelation@gmail.com'
_MD_KEY     = 'KqVDq4GQ363ju4gCV'
_MD_API     = 'https://api.mixdrop.ag'
_MD_FOLDERS = ['Movies', 'Porn', 'TV Shows']   # folder names to search

try:
    import requests as _req
except ImportError:
    _req = None

_session = None

def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _api_get(endpoint, params=None, timeout=10):
    s = _sess()
    if not s:
        return {}
    p = {'email': _MD_EMAIL, 'key': _MD_KEY}
    if params:
        p.update(params)
    r = s.get(_MD_API + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _get_folder_id(name):
    """Resolve a folder name to its MixDrop folder ref. Cached 7 days."""
    ck = 'mixdrop_folder_%s' % name.lower().replace(' ', '_')
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _api_get('/folderlist')
        folders = data.get('result', {})
        if isinstance(folders, list):
            items = folders
        elif isinstance(folders, dict):
            items = folders.get('folders', []) or list(folders.values())
        else:
            items = []
        for f in items:
            if isinstance(f, dict) and f.get('title', '').lower() == name.lower():
                fid = f.get('ref') or f.get('id') or ''
                _cache.set(ck, fid, 7 * 24 * 3600)
                return fid
    except Exception as e:
        xbmc.log('[Personal/MixDrop] folder lookup error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, '', 3600)
    return ''


def _list_folder_files(folder_ref):
    """List files in a MixDrop folder. Cached 1h."""
    ck = 'mixdrop_files_%s' % folder_ref
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _api_get('/folderlist', {'ref': folder_ref})
        result = data.get('result', {})
        files = result.get('files', []) if isinstance(result, dict) else []
        _cache.set(ck, files, 3600)
        return files
    except Exception as e:
        xbmc.log('[Personal/MixDrop] list files error for %s: %s' % (folder_ref, e), xbmc.LOGWARNING)
        _cache.set(ck, [], 3600)
        return []


def _get_stream_url(file_ref):
    """Fetch the direct stream URL for a MixDrop file ref."""
    try:
        data = _api_get('/fileref2', {'ref': file_ref})
        result = data.get('result', {})
        if isinstance(result, dict):
            return result.get('url', '') or result.get('stream', '')
        return ''
    except Exception as e:
        xbmc.log('[Personal/MixDrop] stream URL error for %s: %s' % (file_ref, e), xbmc.LOGWARNING)
        return ''


def _title_matches(filename, title, year=None):
    """Fuzzy match a title against a filename."""
    fname = re.sub(r'\.[a-z0-9]{2,5}$', '', filename, flags=re.IGNORECASE)
    fname_clean = re.sub(r'[._\-]', ' ', fname).lower().strip()
    title_clean = title.lower().strip()
    if title_clean in fname_clean:
        if year:
            return str(year) in fname_clean
        return True
    # word-by-word: all title words must appear in filename
    words = [w for w in title_clean.split() if len(w) > 2]
    if words and all(w in fname_clean for w in words):
        return True
    return False


def search_mixdrop(title, year=None, media_type='movie'):
    """
    Search the user's MixDrop library for files matching title.
    Returns list of {'label': str, 'url': str} source dicts.
    """
    if not _req:
        return []

    folders = _MD_FOLDERS[:] if media_type != 'movie' else ['Movies', 'Porn']

    sources = []
    for folder_name in folders:
        fid = _get_folder_id(folder_name)
        if not fid:
            continue
        files = _list_folder_files(fid)
        for f in files:
            if not isinstance(f, dict):
                continue
            fname = f.get('title') or f.get('name') or ''
            if not fname:
                continue
            if not _title_matches(fname, title, year):
                continue
            fref = f.get('ref') or f.get('fileref') or ''
            if not fref:
                continue
            stream = _get_stream_url(fref)
            if not stream:
                continue
            sources.append({
                'label': '[MixDrop] %s' % fname,
                'url':   stream,
            })

    if sources:
        xbmc.log('[Personal/MixDrop] Found %d match(es) for "%s"' % (len(sources), title),
                 xbmc.LOGINFO)
    return sources


# ── Streamtape ────────────────────────────────────────────────────────────────

_ST_USER = '3002fb47d0df5c2b160d'
_ST_API  = 'https://api.streamtape.com'
_ST_PASS = ''   # set when API password/token is available


def _st_get(endpoint, params=None, timeout=10):
    s = _sess()
    if not s or not _ST_PASS:
        return {}
    p = {'login': _ST_USER, 'key': _ST_PASS}
    if params:
        p.update(params)
    r = s.get(_ST_API + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _list_streamtape_files():
    """List all user files from Streamtape. Cached 1h."""
    ck = 'streamtape_filelist'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _st_get('/file/listfolder', {'folder': ''})
        result = data.get('result', {})
        files = result.get('files', []) if isinstance(result, dict) else []
        _cache.set(ck, files, 3600)
        return files
    except Exception as e:
        xbmc.log('[Personal/Streamtape] list error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, [], 3600)
        return []


def _st_stream_url(file_id):
    """Get direct streamtape URL for a file ID."""
    try:
        data = _st_get('/file/dlticket', {'file': file_id})
        ticket = data.get('result', {}).get('ticket', '')
        if not ticket:
            return ''
        data2 = _st_get('/file/dl', {'file': file_id, 'ticket': ticket})
        return data2.get('result', {}).get('url', '')
    except Exception as e:
        xbmc.log('[Personal/Streamtape] stream URL error: %s' % e, xbmc.LOGWARNING)
        return ''


def search_streamtape(title, year=None, media_type='movie'):
    """
    Search the user's Streamtape library for files matching title.
    Returns list of {'label': str, 'url': str} source dicts.
    Requires _ST_PASS to be set.
    """
    if not _req or not _ST_PASS:
        return []

    sources = []
    files = _list_streamtape_files()
    for f in files:
        if not isinstance(f, dict):
            continue
        fname = f.get('name') or ''
        if not fname or not _title_matches(fname, title, year):
            continue
        fid = f.get('linkid') or f.get('id') or ''
        if not fid:
            continue
        stream = _st_stream_url(fid)
        if not stream:
            continue
        sources.append({
            'label': '[Streamtape] %s' % fname,
            'url':   stream,
        })

    return sources


# ── Unified personal library search ──────────────────────────────────────────

def search_personal(title, year=None, media_type='movie'):
    """Search all personal library services and return combined source list."""
    sources = []
    try:
        sources += search_mixdrop(title, year=year, media_type=media_type)
    except Exception as e:
        xbmc.log('[Personal] MixDrop search error: %s' % e, xbmc.LOGWARNING)
    try:
        sources += search_streamtape(title, year=year, media_type=media_type)
    except Exception as e:
        xbmc.log('[Personal] Streamtape search error: %s' % e, xbmc.LOGWARNING)
    return sources
