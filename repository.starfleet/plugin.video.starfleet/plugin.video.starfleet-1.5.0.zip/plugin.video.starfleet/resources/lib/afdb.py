﻿# -*- coding: utf-8 -*-
"""
resources/lib/afdb.py — Adult Film Database scraper

Source: adultfilmdatabase.com — public metadata catalogue.
No login required. No paywall. Metadata only — no stream URLs.
Stream URLs are supplied externally (StreamTape, DoodStream, etc.)
and resolved at play time via Kodi's ResolveURL/URLResolver addon.

URL patterns discovered:
  Browse films:  /browse.cfm?type=title&sb=videoid&cat=CATEGORY&studio=STUDIO&pg=N
  New releases:  /browse.cfm?type=newreleases
  Popular:       /browse.cfm?type=title&sb=viewcount
  Video detail:  /video/{id}/{slug}/
  Actor browse:  /browse.cfm?type=actor&letter=A
  Actor detail:  /actor/{slug}-{id}/  (slug-id combined, NOT id/slug)
  Studio browse: /browse.cfm?type=studios&letter=A
  Studio films:  /browse.cfm?type=title&studio={name}
  Search:        /advsearch.cfm (POST form)
  Box art front: /Graphics/Boxes/200/Front/{id}.jpg
  Box art back:  /Graphics/Boxes/200/Back/{id}.jpg
  Large front:   /Graphics/Boxes/400/Front/{id}.jpg  (fanart)
  Actor photo:   /Graphics/PornStars/{slug}_{internal_id}.jpg (internal ID ≠ URL ID)

Cache TTLs:
  Film lists / browse pages  → 6h
  Film detail pages          → 24h  (metadata rarely changes)
  Actor lists                → 24h
  Actor detail               → 7d
  Studio lists               → 7d
  Search results             → 1h
"""

import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

import requests
from resources.lib import cache as _cache
_cache.init(_CACHE_DB)

BASE = 'https://www.adultfilmdatabase.com'

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
    'Accept-Language': 'en-CA,en;q=0.9',
    'Referer': BASE + '/',
}

# Image URL builders
def thumb_url(film_id):
    return '%s/Graphics/Boxes/200/Front/%s.jpg' % (BASE, film_id)

def fanart_url(film_id):
    return '%s/Graphics/Boxes/400/Front/%s.jpg' % (BASE, film_id)

def backcover_url(film_id):
    return '%s/Graphics/Boxes/200/Back/%s.jpg' % (BASE, film_id)

def actor_photo_url(actor_id):
    """
    Returns a placeholder thumbnail path. AFDB actor photos are stored at
    /Graphics/PornStars/{slug}_{internal_id}.jpg where internal_id differs
    from the URL actor_id — there is no way to guess it without fetching the
    actor page. The actual URL is extracted by get_actor_detail().
    """
    return ''


def actor_photo_url_large(actor_id):
    return ''


# ── Pre-compiled regex patterns ────────────────────────────────────────────────

# Film card in browse list
_RE_FILM_CARD = re.compile(
    r'href="/video/(\d+)/([^/"]+)/"\s+title="([^"]+)"',
    re.IGNORECASE
)

# Film detail — description: <p itemprop="description">...</p>
_RE_DESCRIPTION = re.compile(
    r'<p\s+itemprop="description"[^>]*>(.*?)</p>',
    re.IGNORECASE | re.DOTALL
)

# Film detail — year: extracted from "Studio: <a ...>Name</a> (YEAR)"
_RE_YEAR = re.compile(
    r'Studio:.*?\((\d{4})\)',
    re.IGNORECASE | re.DOTALL
)

# Film detail — runtime: <span itemprop="duration">Runtime: H:MM:SS</span>
_RE_RUNTIME = re.compile(
    r'itemprop="duration"[^>]*>Runtime:\s*(\d+):(\d+):(\d+)',
    re.IGNORECASE
)

# Film detail — studio: "Studio: <a HREF="...">Studio Name</a>"
_RE_STUDIO = re.compile(
    r'Studio:\s*<a[^>]+>([^<]+)</a>',
    re.IGNORECASE
)

# Film detail — director: plain text after "Director:" label
_RE_DIRECTOR = re.compile(
    r'Director:\s*\n\s*([^\n<]+)',
    re.IGNORECASE
)

# Film detail — rating
_RE_RATING = re.compile(
    r'(?:Rating|Score)[:\s]+([0-9.]+)',
    re.IGNORECASE
)

# Film detail — cast (actor links)
# URL format: /actor/{slug}-{id}/ — Groups: (1)=slug, (2)=actor_id, (3)=name
# (Actor links are absent from most film detail pages on AFDB; kept for completeness)
_RE_CAST = re.compile(
    r'href="/actor/([a-z0-9][a-z0-9-]*)-(\d+)/"\s*>([^<]+)<',
    re.IGNORECASE
)

# Film detail — categories/tags
_RE_CATEGORIES = re.compile(
    r'href="/browse\.cfm\?[^"]*cat=[^"]+"\s*>([^<]+)<',
    re.IGNORECASE
)

# Actor card in browse list — URL format: /actor/{slug}-{id}/
# Groups: (1)=slug, (2)=actor_id, (3)=name
_RE_ACTOR_CARD = re.compile(
    r'href="/actor/([a-z0-9][a-z0-9-]*)-(\d+)/"\s+title="([^"]+)"',
    re.IGNORECASE
)

# Actor card with inline photo — Groups: (1)=slug, (2)=actor_id, (3)=name, (4)=photo_src
_RE_ACTOR_CARD_IMG = re.compile(
    r'href="/actor/([a-z0-9][a-z0-9-]*)-(\d+)/"\s+title="([^"]+)"[^>]*>'
    r'.*?<img[^>]+src="([^"]+)"',
    re.IGNORECASE | re.DOTALL
)

# Actor detail page — photo: <img SRC="/Graphics/PornStars/..." ALIGN="bottom" ...>
_RE_ACTOR_PHOTO = re.compile(
    r'<img\s+SRC="(/Graphics/PornStars/[^"]+)"\s+ALIGN="bottom"',
    re.IGNORECASE
)

# Actor detail page — birthday: "Date of Birth:\n    3/4/1985 ..."
_RE_ACTOR_BDAY = re.compile(
    r'Date of Birth:\s*\n\s*(\d+/\d+/\d{4})',
    re.IGNORECASE
)

# The following actor stats (nationality, height, weight, measurements, hair, eyes,
# ethnicity, bio) are extracted from accordion blocks in _parse_actor_detail() below.
# These stub patterns never match so the generic code paths skip them cleanly.
_RE_ACTOR_BIO           = re.compile(r'(?!)', re.IGNORECASE)
_RE_ACTOR_NATION        = re.compile(r'(?!)', re.IGNORECASE)
_RE_ACTOR_HEIGHT        = re.compile(r'(?!)', re.IGNORECASE)
_RE_ACTOR_WEIGHT        = re.compile(r'(?!)', re.IGNORECASE)
_RE_ACTOR_MEASUREMENTS  = re.compile(r'(?!)', re.IGNORECASE)
_RE_ACTOR_HAIR          = re.compile(r'(?!)', re.IGNORECASE)
_RE_ACTOR_EYES          = re.compile(r'(?!)', re.IGNORECASE)
_RE_ACTOR_ETHNICITY     = re.compile(r'(?!)', re.IGNORECASE)

# Studio name from browse list
_RE_STUDIO_CARD = re.compile(
    r'href="/browse\.cfm\?type=title&amp;studio=([^"]+)"\s*>([^<]+)<',
    re.IGNORECASE
)

# Pagination: number of pages
_RE_PAGES = re.compile(r'pg=(\d+)"[^>]*>\s*(\d+)\s*</a>', re.IGNORECASE)

# Film detail — box art image extracted from page HTML
_RE_BOX_ART = re.compile(
    r'<img[^>]+src="(/Graphics/Boxes/(?:\d+)/Front/[^"]+\.jpg)"',
    re.IGNORECASE
)

# Film detail — scene screenshots
_RE_SCENE_SHOT = re.compile(
    r'<img[^>]+src="(/Graphics/Scenes/[^"]+\.(?:jpg|jpeg|png))"',
    re.IGNORECASE
)

# Strip HTML tags
_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE  = re.compile(r'\s+')


# ── HTTP session ───────────────────────────────────────────────────────────────

_session = None

def _sess():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        a = requests.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=requests.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
    return _session


def _get_html(url, params=None, timeout=12):
    r = _sess().get(url, params=params, timeout=timeout)
    r.raise_for_status()
    return r.text


def _clean(text):
    """Strip HTML tags and normalise whitespace."""
    text = _RE_STRIP_TAGS.sub(' ', text)
    text = _RE_WHITESPACE.sub(' ', text)
    return text.strip()


# ── Browse: Film Lists ─────────────────────────────────────────────────────────

def get_new_releases(page=1):
    ck = 'afdb_new_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/browse.cfm'
    params = {'type': 'newreleases', 'pg': page}
    try:
        html   = _get_html(url, params)
        films  = _parse_film_cards(html)
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[AFDB] get_new_releases error: %s' % e, xbmc.LOGERROR)
        return []


def get_popular(page=1):
    ck = 'afdb_popular_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/browse.cfm'
    params = {'type': 'title', 'sb': 'viewcount', 'pg': page}
    try:
        html  = _get_html(url, params)
        films = _parse_film_cards(html)
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[AFDB] get_popular error: %s' % e, xbmc.LOGERROR)
        return []


def get_by_category(category, page=1):
    ck = 'afdb_cat_%s_%d' % (category.replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/browse.cfm'
    params = {'type': 'title', 'cat': category, 'pg': page}
    try:
        html  = _get_html(url, params)
        films = _parse_film_cards(html)
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[AFDB] get_by_category error: %s' % e, xbmc.LOGERROR)
        return []


def get_by_studio(studio, page=1):
    ck = 'afdb_studio_%s_%d' % (studio.replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/browse.cfm'
    params = {'type': 'title', 'studio': studio, 'pg': page}
    try:
        html  = _get_html(url, params)
        films = _parse_film_cards(html)
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[AFDB] get_by_studio error: %s' % e, xbmc.LOGERROR)
        return []


def get_by_actor(actor_id, actor_slug, page=1):
    ck = 'afdb_actor_films_%s_%d' % (actor_id, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/actor/%s-%s/' % (actor_slug, actor_id)
    try:
        html  = _get_html(url)
        films = _parse_film_cards(html)
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[AFDB] get_by_actor error: %s' % e, xbmc.LOGERROR)
        return []


def search_films(query, page=1):
    ck = 'afdb_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/advsearch.cfm'
    params = {'type': 'title', 'q': query, 'pg': page}
    try:
        html  = _get_html(url, params)
        films = _parse_film_cards(html)
        _cache.set(ck, films, 3600)
        return films
    except Exception as e:
        xbmc.log('[AFDB] search_films error: %s' % e, xbmc.LOGERROR)
        return []


# ── Film Detail ────────────────────────────────────────────────────────────────

def get_film_detail(film_id, film_slug):
    """
    Returns rich metadata dict for a single film:
    {id, slug, title, description, year, runtime, studio, director,
     rating, cast: [{id, slug, name}], categories: [str],
     thumb, fanart, backcover}
    """
    ck = 'afdb_film_%s' % film_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/video/%s/%s/' % (film_id, film_slug)
    try:
        html   = _get_html(url)
        detail = _parse_film_detail(film_id, film_slug, html)
        _cache.set(ck, detail, 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[AFDB] get_film_detail(%s) error: %s' % (film_id, e), xbmc.LOGERROR)
        return _minimal_film(film_id, film_slug)


def _minimal_film(film_id, slug):
    title = slug.replace('-', ' ').title()
    return {
        'id': film_id, 'slug': slug, 'title': title,
        'description': '', 'year': '', 'runtime': 0,
        'studio': '', 'director': '', 'rating': 0.0,
        'cast': [], 'categories': [],
        'thumb': thumb_url(film_id),
        'fanart': fanart_url(film_id),
        'backcover': backcover_url(film_id),
    }


def _parse_film_detail(film_id, slug, html):
    detail = _minimal_film(film_id, slug)

    # Title — from <h1> or <title>
    m = re.search(r'<h1[^>]*>([^<]+)<', html, re.IGNORECASE)
    if m:
        detail['title'] = _clean(m.group(1))

    # Description / synopsis
    m = _RE_DESCRIPTION.search(html)
    if m:
        detail['description'] = _clean(m.group(1))

    # Year
    m = _RE_YEAR.search(html)
    if m:
        detail['year'] = m.group(1)

    # Runtime — H:MM:SS format from itemprop="duration"
    m = _RE_RUNTIME.search(html)
    if m:
        detail['runtime'] = int(m.group(1)) * 60 + int(m.group(2))

    # Studio
    m = _RE_STUDIO.search(html)
    if m:
        detail['studio'] = _clean(m.group(1))

    # Director
    m = _RE_DIRECTOR.search(html)
    if m:
        detail['director'] = _clean(m.group(1))

    # Rating
    m = _RE_RATING.search(html)
    if m:
        try:
            detail['rating'] = float(m.group(1))
        except ValueError:
            pass

    # Cast — groups: (1)=slug, (2)=actor_id, (3)=name
    cast = []
    seen = set()
    for m in _RE_CAST.finditer(html):
        aslug, aid, aname = m.group(1), m.group(2), _clean(m.group(3))
        if aid not in seen:
            seen.add(aid)
            cast.append({'id': aid, 'slug': aslug, 'name': aname})
    detail['cast'] = cast

    # Categories
    cats = []
    seen_cats = set()
    for m in _RE_CATEGORIES.finditer(html):
        cat = _clean(m.group(1))
        if cat and cat not in seen_cats:
            seen_cats.add(cat)
            cats.append(cat)
    detail['categories'] = cats

    # Box art — try to extract from HTML first (avoids 404 on constructed URLs)
    box_m = _RE_BOX_ART.search(html)
    if box_m:
        src = box_m.group(1)
        detail['thumb']  = BASE + src
        detail['fanart'] = BASE + src.replace('/200/', '/400/').replace('/100/', '/400/')
        detail['backcover'] = BASE + src.replace('/Front/', '/Back/')

    # Scene screenshots
    screenshots = []
    seen_shots = set()
    for m in _RE_SCENE_SHOT.finditer(html):
        url = BASE + m.group(1)
        if url not in seen_shots:
            seen_shots.add(url)
            screenshots.append(url)
    detail['screenshots'] = screenshots[:8]

    return detail


# ── Actor Browse & Detail ──────────────────────────────────────────────────────

def get_actors(letter='A'):
    ck = 'afdb_actors_%s' % letter
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/browse.cfm'
    params = {'type': 'actor', 'letter': letter}
    try:
        html   = _get_html(url, params)
        actors = _parse_actor_cards(html)
        _cache.set(ck, actors, 24 * 3600)
        return actors
    except Exception as e:
        xbmc.log('[AFDB] get_actors error: %s' % e, xbmc.LOGERROR)
        return []


def get_actor_detail(actor_id, actor_slug):
    """
    Fetch full actor profile:
    { id, slug, name, photo, photo_large, bio, birthday, nationality,
      height, weight, measurements, hair, eyes, ethnicity, filmcount }
    Cached 7 days — actor profiles rarely change.
    """
    ck = 'afdb_actor_detail_%s' % actor_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/actor/%s-%s/' % (actor_slug, actor_id)
    try:
        html   = _get_html(url)
        detail = _parse_actor_detail(actor_id, actor_slug, html)
        _cache.set(ck, detail, 7 * 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[AFDB] get_actor_detail(%s) error: %s' % (actor_id, e), xbmc.LOGERROR)
        return _minimal_actor(actor_id, actor_slug)


def _minimal_actor(actor_id, slug):
    name = slug.replace('-', ' ').title()
    return {
        'id': actor_id, 'slug': slug, 'name': name,
        'photo':        actor_photo_url(actor_id),
        'photo_large':  actor_photo_url_large(actor_id),
        'bio': '', 'birthday': '', 'nationality': '',
        'height': '', 'weight': '', 'measurements': '',
        'hair': '', 'eyes': '', 'ethnicity': '', 'filmcount': 0,
    }


def _parse_actor_detail(actor_id, slug, html):
    detail = _minimal_actor(actor_id, slug)

    # Name from <h1>
    m = re.search(r'<h1[^>]*>([^<]+)<', html, re.IGNORECASE)
    if m:
        detail['name'] = _clean(m.group(1))

    # Photo — try to find actual src from page first, fall back to guessed path
    m = _RE_ACTOR_PHOTO.search(html)
    if m:
        photo = m.group(1)
        if not photo.startswith('http'):
            photo = BASE + photo
        detail['photo'] = photo
        # Large version: replace /200/ with /400/
        detail['photo_large'] = photo.replace('/200/', '/400/')
    # else keep the guessed URL from _minimal_actor

    # Bio
    m = _RE_ACTOR_BIO.search(html)
    if m:
        detail['bio'] = _clean(m.group(1))[:500]

    # Birthday
    m = _RE_ACTOR_BDAY.search(html)
    if m:
        detail['birthday'] = _clean(m.group(1))

    # Nationality
    m = _RE_ACTOR_NATION.search(html)
    if m:
        detail['nationality'] = _clean(m.group(1))

    # Height
    m = _RE_ACTOR_HEIGHT.search(html)
    if m:
        detail['height'] = _clean(m.group(1))

    # Weight
    m = _RE_ACTOR_WEIGHT.search(html)
    if m:
        detail['weight'] = _clean(m.group(1))

    # Measurements
    m = _RE_ACTOR_MEASUREMENTS.search(html)
    if m:
        detail['measurements'] = _clean(m.group(1))

    # Hair colour
    m = _RE_ACTOR_HAIR.search(html)
    if m:
        detail['hair'] = _clean(m.group(1))

    # Eye colour
    m = _RE_ACTOR_EYES.search(html)
    if m:
        detail['eyes'] = _clean(m.group(1))

    # Ethnicity
    m = _RE_ACTOR_ETHNICITY.search(html)
    if m:
        detail['ethnicity'] = _clean(m.group(1))

    # Appearance block (id02): measurements, height, eye colour, hair colour
    m_app = re.search(
        r'id="id02"[^>]*>.*?<ul[^>]*>(.*?)</ul>',
        html, re.IGNORECASE | re.DOTALL
    )
    if m_app:
        items = re.findall(
            r'<li[^>]*>\s*([^<\n]+?)\s*</li>', m_app.group(1), re.IGNORECASE
        )
        for item in items:
            item = item.strip()
            if re.match(r'\d+[A-Za-z]+-\d+-\d+', item):
                detail['measurements'] = item
            elif re.match(r"\d+'", item):
                detail['height'] = item
            elif 'eyes' in item.lower():
                detail['eyes'] = re.sub(r'\s*eyes?\s*$', '', item, flags=re.IGNORECASE).strip()
            elif 'hair' in item.lower():
                detail['hair'] = re.sub(r'\s*hair\s*$', '', item, flags=re.IGNORECASE).strip()

    # Origin block (id04): ethnicity (1st item), nationality (2nd item)
    m_orig = re.search(
        r'id="id04"[^>]*>.*?<ul[^>]*>(.*?)</ul>',
        html, re.IGNORECASE | re.DOTALL
    )
    if m_orig:
        items = re.findall(
            r'<li[^>]*>\s*([^<\n]+?)\s*</li>', m_orig.group(1), re.IGNORECASE
        )
        clean_items = [i.strip() for i in items if i.strip()]
        if len(clean_items) >= 1:
            detail['ethnicity'] = clean_items[0]
        if len(clean_items) >= 2:
            detail['nationality'] = clean_items[1]

    # Film count from page
    m = re.search(r'(\d+)\s+(?:films?|videos?|movies?)', html, re.IGNORECASE)
    if m:
        try:
            detail['filmcount'] = int(m.group(1))
        except ValueError:
            pass

    return detail


def _parse_actor_cards(html):
    actors = []
    seen   = set()

    # First try: card with inline image (richer parse)
    # Groups: (1)=slug, (2)=actor_id, (3)=name, (4)=photo_src
    for m in _RE_ACTOR_CARD_IMG.finditer(html):
        aslug, aid, aname = m.group(1), m.group(2), _clean(m.group(3))
        raw_photo = m.group(4)
        if not raw_photo.startswith('http'):
            raw_photo = BASE + raw_photo
        if aid not in seen:
            seen.add(aid)
            actors.append({
                'id':          aid,
                'slug':        aslug,
                'name':        aname,
                'photo':       raw_photo,
                'photo_large': raw_photo.replace('/200/', '/400/') if raw_photo else '',
            })

    # Fallback: simple href-only cards — Groups: (1)=slug, (2)=actor_id, (3)=name
    if not actors:
        for m in _RE_ACTOR_CARD.finditer(html):
            aslug, aid, aname = m.group(1), m.group(2), _clean(m.group(3))
            if aid not in seen:
                seen.add(aid)
                actors.append({
                    'id':          aid,
                    'slug':        aslug,
                    'name':        aname,
                    'photo':       '',
                    'photo_large': '',
                })

    actors.sort(key=lambda x: x['name'].lower())
    return actors


# ── Studio Browse ──────────────────────────────────────────────────────────────

def get_studios(letter='A'):
    ck = 'afdb_studios_%s' % letter
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = BASE + '/browse.cfm'
    params = {'type': 'studios', 'letter': letter}
    try:
        html    = _get_html(url, params)
        studios = _parse_studio_cards(html)
        _cache.set(ck, studios, 7 * 24 * 3600)
        return studios
    except Exception as e:
        xbmc.log('[AFDB] get_studios error: %s' % e, xbmc.LOGERROR)
        return []


def _parse_studio_cards(html):
    studios = []
    seen    = set()
    for m in _RE_STUDIO_CARD.finditer(html):
        slug, name = m.group(1), _clean(m.group(2))
        if slug not in seen and name:
            seen.add(slug)
            studios.append({'slug': slug, 'name': name})
    studios.sort(key=lambda x: x['name'].lower())
    return studios


# ── Film card parser (shared across all browse pages) ─────────────────────────

def _parse_film_cards(html):
    films = []
    seen  = set()
    for m in _RE_FILM_CARD.finditer(html):
        fid, fslug, ftitle = m.group(1), m.group(2), _clean(m.group(3))
        if fid not in seen:
            seen.add(fid)
            films.append({
                'id':      fid,
                'slug':    fslug,
                'title':   ftitle,
                'thumb':   thumb_url(fid),
                'fanart':  fanart_url(fid),
            })
    return films


# ── Category list (hardcoded from site — rarely changes) ──────────────────────

CATEGORIES = [
    '4 hour', '70\'s Porn Video', '80\'s Porn Video', '90\'s Porn Video',
    'All Sex', 'Alternative', 'Amateur', 'Anal', 'Asian', 'Athletic',
    'BDSM', 'Big Asses', 'Bisexual', 'Blonde', 'Bondage', 'British',
    'Brunette', 'Busty', 'Casting', 'Classics', 'Compilation', 'Cosplay',
    'Cuckold', 'Double Penetration', 'Ebony', 'European', 'Facials',
    'Feature', 'Femdom', 'Fetish', 'Foot Fetish', 'Gangbang', 'Gay',
    'Gonzo', 'Group Sex', 'Hairy', 'Interracial', 'Latin', 'Lesbian',
    'Massage', 'Masturbation', 'Mature', 'MILF', 'Natural', 'Oral',
    'Orgy', 'Outdoors', 'Parody', 'Petite', 'Plump / BBW', 'POV',
    'Reality', 'Redhead', 'Rough Sex', 'Softcore', 'Squirting',
    'Striptease', 'Swallowing', 'Swingers', 'Threesomes', 'Transsexual',
    'Vintage', 'Virtual Reality', 'Young',
]

ALPHABET = list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
