# -*- coding: utf-8 -*-
"""
resources/lib/torrent_sources.py

Search multiple torrent sites for a title and return magnet links.
Results are used with debrid services (Real-Debrid, AllDebrid, Premiumize, TorBox)
to get instant cached streams — uncached torrents are skipped.

Sources:
  YTS          — JSON API, movies only, high quality
  1337x        — HTML scraping, movies + TV
  The Pirate Bay — JSON API, movies + TV
  Zooqle        — HTML scraping, movies + TV
"""

import re
import xbmc

# Minimum quality filter — only return results at 720p or better
_QUALITY_WHITELIST = re.compile(
    r'\b(?:720p?|1080p?|1080i|2160p?|4k|uhd|3d|bd(?:rip|remux)|bluray|blu[-\s]?ray)\b',
    re.IGNORECASE
)
_QUALITY_BLACKLIST = re.compile(
    r'\b(?:480p?|360p?|240p?|cam|camrip|hdcam|scr|screener|dvdscr|hdrip(?!\s*1080))\b',
    re.IGNORECASE
)

def _meets_quality(title_or_quality):
    """Return True if this torrent meets the 720p+ quality threshold."""
    s = (title_or_quality or '').lower()
    if _QUALITY_BLACKLIST.search(s):
        return False
    return bool(_QUALITY_WHITELIST.search(s))

def _extract_quality(text):
    """Extract a display quality label from a torrent title or quality field."""
    text = text or ''
    for pat, label in [
        (r'\b2160p?\b|\b4k\b|\buhd\b',          '4K'),
        (r'\b1080p?\b|\b1080i\b',                '1080p'),
        (r'\b720p?\b',                            '720p'),
        (r'\b3d\b',                               '3D'),
        (r'\bbluray\b|\bbl(?:u[-\s]?ray)\b',      'Blu-ray'),
    ]:
        if re.search(pat, text, re.IGNORECASE):
            return label
    return ''

try:
    import requests as _req
except ImportError:
    _req = None

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
}

_session = None

def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get(url, timeout=10):
    s = _sess()
    if not s:
        return ''
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _get_json(url, timeout=10):
    s = _sess()
    if not s:
        return None
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _make_magnet(info_hash, name=''):
    """Build a magnet link from an info hash."""
    trackers = [
        'udp://tracker.opentrackr.org:1337/announce',
        'udp://open.tracker.cl:1337/announce',
        'udp://tracker.openbittorrent.com:6969/announce',
    ]
    dn = ('&dn=' + _req.utils.quote(name)) if name and _req else ''
    tr = ''.join('&tr=' + t for t in trackers)
    return 'magnet:?xt=urn:btih:%s%s%s' % (info_hash.lower(), dn, tr)


# ── YTS (yts-official.to) ─────────────────────────────────────────────────────

YTS_BASE = 'https://yts.mx'

def search_yts(title, year=None, limit=5):
    """
    Search YTS JSON API. Returns list of dicts:
      {'title', 'year', 'quality', 'info_hash', 'magnet', 'seeds', 'size'}
    """
    try:
        params = {'query_term': title, 'limit': limit, 'sort_by': 'seeds'}
        if year:
            params['query_term'] = '%s %s' % (title, year)
        data = _get_json(YTS_BASE + '/api/v2/list_movies.json?' +
                         '&'.join('%s=%s' % (k, v) for k, v in params.items()))
        if not data or data.get('status') != 'ok':
            return []
        movies = data.get('data', {}).get('movies') or []
        results = []
        for movie in movies:
            for tor in movie.get('torrents', []):
                ih  = tor.get('hash', '')
                if not ih:
                    continue
                quality = tor.get('quality', '')
                # YTS qualities: 720p, 1080p, 2160p, 3D — all meet threshold
                if not _meets_quality(quality):
                    continue
                results.append({
                    'title':     movie.get('title_english') or movie.get('title', ''),
                    'year':      movie.get('year', ''),
                    'quality':   _extract_quality(quality) or quality,
                    'info_hash': ih,
                    'magnet':    _make_magnet(ih, movie.get('title', '')),
                    'seeds':     tor.get('seeds', 0),
                    'size':      tor.get('size', ''),
                    'source':    'YTS',
                })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YTS error: %s' % e, xbmc.LOGWARNING)
        return []


# ── The Pirate Bay ────────────────────────────────────────────────────────────

TPB_BASE = 'https://apibay.org'

def search_tpb(title, year=None, category=200, limit=10):
    """
    Search TPB via apibay.org JSON API.
    category 200 = Video (all), 201 = Movies, 205 = TV.
    Returns list of dicts: {'title', 'info_hash', 'magnet', 'seeds', 'size', 'source'}
    """
    try:
        query = title
        if year:
            query = '%s %s' % (title, year)
        data = _get_json(TPB_BASE + '/q.php?q=%s&cat=%d' % (
            _req.utils.quote(query) if _req else query, category))
        # apibay returns [{"name":"No results returned","info_hash":"0000..."}] on empty
        if not data or not isinstance(data, list):
            return []
        results = []
        for item in data[:limit]:
            ih = item.get('info_hash', '')
            if not ih or ih == '0000000000000000000000000000000000000000':
                continue
            name = item.get('name', '')
            if not _meets_quality(name):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(item.get('seeders', 0)),
                'size':      item.get('size', ''),
                'source':    'TPB',
            })
        # Sort by seeds descending
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TPB error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 1337x ─────────────────────────────────────────────────────────────────────

LEET_BASE = 'https://1337x.to'

_RE_LEET_ROW = re.compile(
    r'<td[^>]+class="[^"]*coll-1[^"]*"[^>]*>.*?'
    r'href="(/torrent/\d+/[^"]+)"[^>]*>([^<]+)</a>.*?'
    r'<td[^>]+class="[^"]*coll-2[^"]*"[^>]*>(\d+)<.*?'
    r'<td[^>]+class="[^"]*coll-3[^"]*"[^>]*>(\d+)<',
    re.IGNORECASE | re.DOTALL
)
_RE_LEET_MAGNET = re.compile(r'href="(magnet:[^"]+)"', re.IGNORECASE)


def _leet_get_magnet(path):
    """Fetch the detail page for a 1337x torrent and extract the magnet link."""
    try:
        html = _get(LEET_BASE + path, timeout=8)
        m = _RE_LEET_MAGNET.search(html)
        return m.group(1) if m else ''
    except Exception:
        return ''


def search_1337x(title, year=None, limit=5):
    """
    Search 1337x and return list of dicts with magnet links.
    Fetches detail pages for top results to get magnets.
    """
    try:
        query = title.replace(' ', '+')
        if year:
            query += '+' + str(year)
        html = _get(LEET_BASE + '/search/%s/1/' % query, timeout=10)
        results = []
        for m in _RE_LEET_ROW.finditer(html):
            path, name, seeds, leechers = m.group(1), m.group(2), m.group(3), m.group(4)
            if len(results) >= limit:
                break
            name = name.strip()
            if not _meets_quality(name):
                continue
            magnet = _leet_get_magnet(path)
            if not magnet:
                continue
            ih_m = re.search(r'urn:btih:([a-fA-F0-9]{40})', magnet)
            info_hash = ih_m.group(1) if ih_m else ''
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    magnet,
                'seeds':     int(seeds),
                'size':      '',
                'source':    '1337x',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] 1337x error: %s' % e, xbmc.LOGWARNING)
        return []


# ── EZTV (TV shows) ───────────────────────────────────────────────────────────

EZTV_BASE = 'https://eztvx.to'

def search_eztv(title, year=None, limit=5):
    """
    Search EZTV JSON API for TV show episodes.
    Returns list of dicts with magnet links (720p+ only).
    """
    try:
        query = title
        if year:
            query = '%s %s' % (title, year)
        data = _get_json('%s/api/get-torrents?search=%s&limit=%d' % (
            EZTV_BASE,
            _req.utils.quote(query) if _req else query,
            max(limit * 3, 15)  # fetch more since we filter by quality
        ))
        if not data or not isinstance(data.get('torrents'), list):
            return []
        results = []
        for item in data['torrents']:
            name = item.get('filename', '') or item.get('title', '')
            ih   = item.get('hash', '')
            if not ih or not name:
                continue
            if not _meets_quality(name):
                continue
            magnet = item.get('magnet_url', '') or _make_magnet(ih, name)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    magnet,
                'seeds':     int(item.get('seeds', 0)),
                'size':      item.get('size_bytes', ''),
                'source':    'EZTV',
            })
            if len(results) >= limit:
                break
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] EZTV error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitsearch (bitsearch.to) ──────────────────────────────────────────────────

BITSEARCH_BASE = 'https://bitsearch.to'
_BS_CARD  = 'p-6 hover:shadow-md'
_RE_BS_TITLE = re.compile(r'<h3[^>]*>\s*<a[^>]*>\s*(.*?)\s*</a>', re.IGNORECASE | re.DOTALL)
_RE_BS_SEEDS = re.compile(r'font-medium">(\d+)</span>\s*<span>seeders</span>', re.IGNORECASE)
_RE_BS_SIZE  = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_bitsearch(title, year=None, limit=5):
    """Search bitsearch.to DHT index. Returns list of torrent dicts."""
    try:
        import html as _html
        query = title
        if year:
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/search?q=%s&sort=seeders' % (BITSEARCH_BASE, query)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        text = _html.unescape(html_raw)
        results = []
        for card in text.split(_BS_CARD)[1:]:
            if len(results) >= limit:
                break
            try:
                mag_m = re.search(r'href="(magnet:\?[^"]+)"', card, re.IGNORECASE)
                if not mag_m:
                    continue
                magnet = mag_m.group(1).replace('&amp;', '&')
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if not ih_m:
                    continue
                info_hash = ih_m.group(1).lower()
                t_m = _RE_BS_TITLE.search(card)
                name = re.sub(r'\s+', ' ', t_m.group(1)).strip() if t_m else ''
                name = re.sub(r'<[^>]+>', '', name).strip()
                if not name or not _meets_quality(name):
                    continue
                seeds = 0
                s_m = _RE_BS_SEEDS.search(card)
                if s_m:
                    seeds = int(s_m.group(1))
                size = ''
                z_m = _RE_BS_SIZE.search(card)
                if z_m:
                    size = z_m.group(0)
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': info_hash,
                    'magnet':    magnet,
                    'seeds':     seeds,
                    'size':      size,
                    'source':    'Bitsearch',
                })
            except Exception:
                continue
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitsearch error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentGalaxy (tgx.rs) ────────────────────────────────────────────────────

TGX_BASE = 'https://tgx.rs'
_RE_TGX_ROW    = re.compile(r'<div[^>]+class="[^"]*tgxtable[^"]*"[^>]*>(.*?)</div>', re.IGNORECASE | re.DOTALL)
_RE_TGX_MAGNET = re.compile(r'a\s+href="(magnet:[^"]+)"', re.IGNORECASE)
_RE_TGX_SIZE   = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)
_TGX_SKIP_LANG = re.compile(r'\b(FRENCH|TRUEFRENCH|ITALIAN|Ita|SPANISH|DUBBED|LAT|Dublado)\b', re.IGNORECASE)


def search_torrentgalaxy(title, year=None, limit=5):
    """Search TorrentGalaxy (tgx.rs). Returns list of torrent dicts."""
    try:
        query = title
        if year:
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/torrents.php?search=%s' % (TGX_BASE, query)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        for row_m in _RE_TGX_ROW.finditer(html_raw):
            if len(results) >= limit:
                break
            row = row_m.group(1)
            mag_m = _RE_TGX_MAGNET.search(row)
            if not mag_m:
                continue
            magnet = mag_m.group(1)
            if _TGX_SKIP_LANG.search(magnet):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            # Title from dn= param in magnet
            dn_m = re.search(r'[&?]dn=([^&]+)', magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else info_hash
            if not _meets_quality(name):
                continue
            size = ''
            z_m = _RE_TGX_SIZE.search(row)
            if z_m:
                size = z_m.group(0)
            seeds_m = re.search(r'<span[^>]+>(\d+)</span>\s*seeders', row, re.IGNORECASE)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'TGX',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentGalaxy error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Unified search ────────────────────────────────────────────────────────────

def search_all(title, year=None, media_type='movie', max_per_source=5):
    """
    Search all torrent sources in parallel. Returns combined list sorted by seeds.
    media_type: 'movie' or 'tv'
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    tpb_cat = 201 if media_type == 'movie' else 205

    tasks = {
        'YTS':        lambda: search_yts(title, year, max_per_source) if media_type == 'movie' else [],
        'TPB':        lambda: search_tpb(title, year, tpb_cat, max_per_source),
        '1337x':      lambda: search_1337x(title, year, max_per_source),
        'EZTV':       lambda: search_eztv(title, year, max_per_source) if media_type == 'tv' else [],
        'Bitsearch':  lambda: search_bitsearch(title, year, max_per_source),
        'TGX':        lambda: search_torrentgalaxy(title, year, max_per_source),
    }

    all_results = []
    with ThreadPoolExecutor(max_workers=min(len(tasks), 6)) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        for future in as_completed(futures, timeout=8):
            try:
                all_results.extend(future.result())
            except Exception as e:
                xbmc.log('[Starfleet/Torrents] %s search failed: %s' % (futures[future], e),
                         xbmc.LOGWARNING)

    # Deduplicate by info_hash
    seen = set()
    unique = []
    for r in all_results:
        ih = r.get('info_hash', '').lower()
        if ih and ih not in seen:
            seen.add(ih)
            unique.append(r)

    unique.sort(key=lambda x: x.get('seeds', 0), reverse=True)
    return unique
