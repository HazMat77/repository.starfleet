﻿# -*- coding: utf-8 -*-
"""
resources/lib/sports_sources.py

Sports live-stream scraper.

Event sources (priority order):
  1. ESPN API          — NFL, NBA, MLB, NHL, CFB, NCAAB, CFL (official logos + scores)
  2. TheSportsDB       — UFC, Boxing, WWE (free tier, API key 3)
  3. istreameast.cx    — fallback / soccer / F1 / anything else (currently dead — fast-fails)
  4. streamseast.is    — supplementary (merged, deduplicated)
  5. methstreams.gs    — supplementary (merged, deduplicated)
  6. totalsportek24.is — multi-sport (soccer/NFL/NBA/NHL/MLB/UFC/boxing/F1/CFB/NCAAB/WWE)
  7. onhockey.tv       — NHL-specific supplementary

Stream sources (merged):
  1. roxiestreams.info — sport-page links matched by event title (direct m3u8)
  2. streamseast.is    — iframe chain → embed player
  3. methstreams.gs    — supplementary stream source (JS-rendered, slug cross-ref)
  4. totalsportek24.is — multi-sport stream source
  5. onhockey.tv       — NHL-specific stream source (direct + cross-ref by title)

Removed (dead as of 2026):
  - CrackStreams (all mirrors: mx, biz, app, crack.sx — all dead)
  - TotalSportek original (totalsportek.to/.com/.2 — all unreachable)
  - ppv.land / ppv.to (Cloudflare blocks plain requests, removed per user request)
  - Sportsurge (dead code — _SPORTSURGE_BASES undefined, never called)
  - JustWatch Sports (dead code — never called)

Cache: event list 10 min (live data), stream list 5 min
"""

import re
import datetime
import time
import xbmc
import xbmcaddon
import xbmcvfs
from concurrent.futures import ThreadPoolExecutor, as_completed

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

ISE_BASE        = 'https://istreameast.cx'   # dead — fast-fails, kept for path routing
CRACK_BASE      = 'https://crackstreams.mx'
_CRACK_MIRRORS  = ['https://crackstreams.mx', 'https://crackstreams.biz',
                   'https://crackstreams.app', 'https://crack.sx']
METH_BASE       = 'https://methstreams.gs'
ROXIE_BASE      = 'https://roxiestreams.info'
SEAST_BASE      = 'https://streamseast.is'
TSTEK_BASE      = 'https://totalsportek24.is'
ONHOCKEY_BASE   = 'https://onhockey.tv'

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5, redirect=False)
        )
        _session.mount('https://', a)
    return _session


_cf_session = None

def _cf_sess():
    """Return a Cloudflare-bypass session. Tries cloudscraper first, then cfscrape, then plain requests."""
    global _cf_session
    if _cf_session is None:
        # 1. Try cloudscraper (pip install cloudscraper — works on most platforms)
        try:
            import cloudscraper as _cs
            _cf_session = _cs.create_scraper(
                browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
            )
            _cf_session.headers.update(_HEADERS)
            xbmc.log('[Starfleet/Sports] CF bypass: cloudscraper OK', xbmc.LOGINFO)
            return _cf_session
        except Exception:
            pass
        # 2. Try cfscrape from script.module.thecrew (Kodi addon)
        try:
            import sys as _sys
            import xbmcvfs as _vfs
            _kodi_addons = _vfs.translatePath('special://home/addons')
            _sys.path.insert(0, _kodi_addons + '/script.module.thecrew/lib/resources/lib/modules')
            import cfscrape
            _cf_session = cfscrape.create_scraper()
            _cf_session.headers.update(_HEADERS)
            xbmc.log('[Starfleet/Sports] CF bypass: cfscrape OK', xbmc.LOGINFO)
            return _cf_session
        except Exception as e:
            xbmc.log('[Starfleet/Sports] CF bypass unavailable, using plain session: %s' % e, xbmc.LOGWARNING)
            _cf_session = _sess()
    return _cf_session


def _get(url, timeout=12):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _get_json(url, timeout=10):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()


def _ts_to_dt(date_str):
    """Parse ISO 8601 UTC date string to (unix_timestamp, display_string). Returns (0, '') on failure."""
    if not date_str:
        return 0, ''
    try:
        # Normalise: strip timezone marker and fractional seconds
        clean = date_str.strip()
        clean = clean.split('.')[0]          # drop .000
        clean = clean.rstrip('Z')            # drop trailing Z
        if '+' in clean:
            clean = clean.split('+')[0]      # drop +00:00
        # Try with seconds (19 chars) then without (16 chars)
        dt = None
        for fmt, n in (('%Y-%m-%dT%H:%M:%S', 19), ('%Y-%m-%dT%H:%M', 16)):
            try:
                dt = datetime.datetime.strptime(clean[:n], fmt)
                break
            except Exception:
                pass
        if dt is None:
            return 0, date_str
        ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
        return ts, dt.strftime('%b %d %H:%M UTC')
    except Exception:
        return 0, date_str


_RE_SCORE = re.compile(r'\b\d+\s*[-:]\s*\d+\b')


def _strip_score(title):
    """Remove live score like '3 - 2' or '1:0' from a match title for cross-source matching."""
    return _RE_WS.sub(' ', _RE_SCORE.sub('', title)).strip(' -')


def _title_score(title_a, title_b):
    """Return number of significant words (len>=3) from title_a that appear in title_b (case-insensitive).
    Uses >=3 so short but meaningful team name words (Sox, Mets, Cubs, Red, etc.) are counted."""
    words_a = [w.lower() for w in re.split(r'\W+', _strip_score(title_a)) if len(w) >= 3]
    b_lower = _strip_score(title_b).lower()
    return sum(1 for w in words_a if w in b_lower)


def _titles_match(title_a, title_b, threshold=2):
    """Return True if at least `threshold` significant words from title_a appear in title_b."""
    return _title_score(title_a, title_b) >= threshold


# ── Sport categories ──────────────────────────────────────────────────────────

# Fallback icons (ESPN CDN / Wikipedia) used when TSDB API is unavailable
_CATEGORIES = [
    {'slug': 'soccer',   'label': 'Soccer',                    'tsdb': 'Soccer',              'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/fifa.png'},
    {'slug': 'nfl',      'label': 'NFL',                       'tsdb': 'American Football',   'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nfl.png'},
    {'slug': 'nba',      'label': 'NBA',                       'tsdb': 'Basketball',          'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nba.png'},
    {'slug': 'mlb',      'label': 'MLB',                       'tsdb': 'Baseball',            'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/mlb.png'},
    {'slug': 'nhl',      'label': 'NHL',                       'tsdb': 'Ice Hockey',          'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'},
    {'slug': 'ufc',      'label': 'UFC / MMA',                 'tsdb': 'Mixed Martial Arts',  'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ufc.png'},
    {'slug': 'boxing',   'label': 'Boxing',                    'tsdb': 'Boxing',              'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/boxing1519439649.jpg'},
    {'slug': 'tennis',   'label': 'Tennis',                    'tsdb': 'Tennis',              'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/asdh2v1548684497.jpg'},
    {'slug': 'rugby',    'label': 'Rugby',                     'tsdb': 'Rugby',               'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/vbki5v1547214439.jpg'},
    {'slug': 'cricket',  'label': 'Cricket',                   'tsdb': 'Cricket',             'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/cricket1519439826.jpg'},
    {'slug': 'f1',       'label': 'Formula 1',                 'tsdb': 'Motorsport',          'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/f1.png'},
    {'slug': 'motogp',   'label': 'MotoGP',                    'tsdb': 'Motorsport',          'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/motorsport.jpg'},
    {'slug': 'golf',     'label': 'Golf',                      'tsdb': 'Golf',                'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/golf1519439822.jpg'},
    {'slug': 'darts',    'label': 'Darts',                     'tsdb': 'Darts',               'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/darts1519439673.jpg'},
    {'slug': 'snooker',  'label': 'Snooker',                   'tsdb': 'Snooker',             'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/snooker1519439836.jpg'},
    {'slug': 'handball', 'label': 'Handball',                  'tsdb': 'Handball',            'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/handball1519439771.jpg'},
    {'slug': 'volleyball','label': 'Volleyball',               'tsdb': 'Volleyball',          'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/volleyball1519439870.jpg'},
    {'slug': 'cycling',  'label': 'Cycling',                   'tsdb': 'Cycling',             'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/cycling1519439660.jpg'},
    {'slug': 'cfb',      'label': 'College Football (CFB)',     'tsdb': 'American Football',   'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaaf.png'},
    {'slug': 'ncaab',    'label': 'College Basketball (NCAAB)', 'tsdb': 'Basketball',          'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaab.png'},
    {'slug': 'cfl',      'label': 'CFL',                        'tsdb': 'American Football',   'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/cfl.png'},
    {'slug': 'wwe',      'label': 'WWE / Wrestling',            'tsdb': 'Wrestling',           'icon': 'https://r2.thesportsdb.com/images/media/league/badge/r43xns1461424282.png'},
]

# Map slug → TSDB sport name for calendar lookups
_SLUG_TO_TSDB_SPORT = {c['slug']: c['tsdb'] for c in _CATEGORIES}

_TSDB_BASE       = 'https://www.thesportsdb.com/api/v1/json/3'
_TSDB_SPORTS_API = _TSDB_BASE + '/all_sports.php'
_TSDB_DAY_API    = _TSDB_BASE + '/eventsday.php'


def get_sport_categories():
    """Fetch ALL sports from TheSportsDB (cached 24h), merged with our ESPN-backed known sports."""
    ck = 'tsdb_sport_cats_v2'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    # Fetch TSDB sport list
    tsdb_sports = []
    try:
        data = _get_json(_TSDB_SPORTS_API, timeout=8)
        tsdb_sports = data.get('sports') or []
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB all_sports: %s' % e, xbmc.LOGWARNING)

    # Build lookup: tsdb_name → {icon, id}
    tsdb_by_name = {}
    for s in tsdb_sports:
        name = s.get('strSport', '').strip()
        if name:
            tsdb_by_name[name] = {
                'icon': s.get('strSportThumb', ''),
                'id':   s.get('idSport', ''),
            }

    result = []
    seen_tsdb = set()

    # 1. Known slugs first (preserves order + ESPN live-score support)
    for cat in _CATEGORIES:
        tsdb_name = cat.get('tsdb', '')
        if tsdb_name in seen_tsdb:
            continue  # skip duplicates (cfb/cfl/ncaab share tsdb name)
        seen_tsdb.add(tsdb_name)
        tsdb_info = tsdb_by_name.get(tsdb_name, {})
        icon = tsdb_info.get('icon') or cat['icon']
        result.append({
            'slug':       cat['slug'],
            'label':      cat['label'],
            'icon':       icon,
            'tsdb_sport': tsdb_name,
        })

    # 2. Remaining TSDB sports not yet in our list
    for s in tsdb_sports:
        name = s.get('strSport', '').strip()
        if not name or name in seen_tsdb:
            continue
        seen_tsdb.add(name)
        slug = re.sub(r'[^a-z0-9]+', '_', name.lower()).strip('_')
        icon = s.get('strSportThumb', '')
        result.append({
            'slug':       slug,
            'label':      name,
            'icon':       icon,
            'tsdb_sport': name,
        })

    if result:
        _cache.set(ck, result, 86400)
    else:
        # Complete fallback: static list only
        result = [
            {'slug': c['slug'], 'label': c['label'], 'icon': c['icon'], 'tsdb_sport': c.get('tsdb', '')}
            for c in _CATEGORIES
        ]
    return result


def _tsdb_calendar_events(tsdb_sport, date_str):
    """Fetch TheSportsDB events for a sport on date_str (YYYY-MM-DD). tsdb_sport is the TSDB sport name."""
    if not tsdb_sport:
        return []
    try:
        import urllib.parse as _urlparse
        url = '%s?d=%s&s=%s' % (_TSDB_DAY_API, date_str, _urlparse.quote(tsdb_sport))
        data = _get_json(url, timeout=8)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB calendar (%s %s): %s' % (tsdb_sport, date_str, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in (data.get('events') or []):
        date_ev   = ev.get('dateEvent', '')
        time_ev   = (ev.get('strTime') or '00:00:00')[:8]
        timestamp = ev.get('strTimestamp', '')
        if timestamp:
            ts_raw = timestamp.replace(' ', 'T') if 'T' not in timestamp else timestamp
            ts, dt_str = _ts_to_dt(ts_raw)
        else:
            try:
                dt = datetime.datetime.strptime('%s %s' % (date_ev, time_ev), '%Y-%m-%d %H:%M:%S')
                ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
                dt_str = dt.strftime('%b %d %H:%M UTC')
            except Exception:
                ts, dt_str = 0, date_ev

        home  = ev.get('strHomeTeam', '')
        away  = ev.get('strAwayTeam', '')
        title = ('%s vs %s' % (home, away)) if (home and away) else ev.get('strEvent', '')
        logo  = (ev.get('strHomeTeamBadge') or ev.get('strThumb') or ev.get('strBanner') or '')

        events.append({
            'id':          str(ev.get('idEvent', '')),
            'slug':        str(ev.get('idEvent', '')),
            'path':        '',
            'title':       title,
            'match_title': title,
            'datetime':    dt_str,
            'league':      ev.get('strLeague', tsdb_sport),
            'logo':        logo,
            'home_badge':  ev.get('strHomeTeamBadge', ''),
            'away_badge':  ev.get('strAwayTeamBadge', ''),
            'is_live':     False,
            'start_ts':    ts,
            'venue':       ev.get('strVenue', ''),
        })
    return events


def get_onhockey_events():
    """Return all onhockey.tv events with their league field populated."""
    return _onhockey_events()


# ── ESPN API ──────────────────────────────────────────────────────────────────

_ESPN_SPORTS = {
    'nfl':   ('football',   'nfl'),
    'nba':   ('basketball', 'nba'),
    'mlb':   ('baseball',   'mlb'),
    'nhl':   ('hockey',     'nhl'),
    'cfb':   ('football',   'college-football'),
    'ncaab': ('basketball', 'mens-college-basketball'),
    'cfl':   ('football',   'cfl'),
    'soccer': ('soccer',   'fifa.world'),   # FIFA World Cup 2026 (Jun–Jul 2026)
}
# Additional soccer leagues polled after the primary
_ESPN_SOCCER_EXTRA = ['eng.1', 'usa.1', 'uefa.champions', 'uefa.europa']
_ESPN_API = 'https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard'


def _espn_events(sport_slug):
    if sport_slug not in _ESPN_SPORTS:
        return []
    sport, league = _ESPN_SPORTS[sport_slug]
    url = _ESPN_API.format(sport=sport, league=league)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ESPN API (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in data.get('events', []):
        state   = ev.get('status', {}).get('type', {}).get('state', 'pre')
        is_live = (state == 'in')

        comp        = (ev.get('competitions') or [{}])[0]
        competitors = comp.get('competitors', [])
        venue       = comp.get('venue', {}).get('fullName', '')

        match_title = ev.get('name', ev.get('shortName', ''))
        if len(competitors) >= 2:
            teams  = [c.get('team', {}).get('displayName', '') for c in competitors]
            scores = [c.get('score', '') for c in competitors]
            match_title = ' vs '.join(teams)
            title_str   = match_title
            if is_live and all(scores):
                title_str = '%s %s - %s %s' % (teams[0], scores[0], scores[1], teams[1])
        else:
            title_str = match_title

        logo = ''
        if competitors:
            logo = competitors[0].get('team', {}).get('logo', '')

        start_ts, datetime_str = _ts_to_dt(ev.get('date', ''))

        events.append({
            'id':          ev.get('id', ''),
            'slug':        ev.get('id', ''),
            'path':        '',
            'title':       title_str,
            'match_title': match_title,
            'datetime':    datetime_str,
            'league':      sport_slug.upper(),
            'logo':        logo,
            'is_live':     is_live,
            'start_ts':    start_ts,
            'venue':       venue,
        })

    return events


# ── TheSportsDB (UFC / Boxing / WWE) ─────────────────────────────────────────

_TSDB_LEAGUES = {
    'ufc':    '4407',
    'boxing': '4414',
    'wwe':    '4412',
}
_TSDB_NEXT = 'https://www.thesportsdb.com/api/v1/json/3/eventsnextleague.php'


def _tsdb_events(sport_slug):
    league_id = _TSDB_LEAGUES.get(sport_slug)
    if not league_id:
        return []
    url = '%s?id=%s' % (_TSDB_NEXT, league_id)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in (data.get('events') or []):
        date_str = ev.get('dateEvent', '')
        time_str = (ev.get('strTime') or '00:00:00')[:8]
        try:
            dt = datetime.datetime.strptime('%s %s' % (date_str, time_str), '%Y-%m-%d %H:%M:%S')
            start_ts  = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
            datetime_str = dt.strftime('%b %d %H:%M')
        except Exception:
            start_ts, datetime_str = 0, date_str

        title_str = ev.get('strEvent', ev.get('strFilename', ''))
        logo = ev.get('strThumb', '') or ev.get('strBanner', '') or ''

        events.append({
            'id':       str(ev.get('idEvent', '')),
            'slug':     str(ev.get('idEvent', '')),
            'path':     '',
            'title':    title_str,
            'datetime': datetime_str,
            'league':   ev.get('strLeague', sport_slug.upper()),
            'logo':     logo,
            'is_live':  False,
            'start_ts': start_ts,
        })

    return events


# ── istreameast.cx events (fallback) ─────────────────────────────────────────

_RE_ISE_CARD = re.compile(
    r'class="event-card"[^>]*onclick="window\.location\.href=[^\']*\'(/links/([^\']+))\''
    r'[^>]*data-event-id="(\d+)"[^>]*data-start-ts="(\d+)"',
    re.IGNORECASE | re.DOTALL
)
_RE_ISE_LOGO = re.compile(
    r'<img[^>]+src="(https://[^"]+thesportsdb[^"]+|https://[^"]+espncdn[^"]+)"[^>]*alt="([^"]*)"',
    re.IGNORECASE
)
_RE_ISE_TITLE    = re.compile(r'class="event-title"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_DATETIME = re.compile(r'class="event-datetime"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_LEAGUE   = re.compile(r'class="event-league"\s*>(.*?)</div>', re.IGNORECASE | re.DOTALL)
_RE_ISE_STATUS   = re.compile(r'class="event-status\s+([^"]+)"\s*>(.*?)</span>', re.IGNORECASE)


def _parse_ise_block(block):
    m_title = _RE_ISE_TITLE.search(block)
    m_dt    = _RE_ISE_DATETIME.search(block)
    m_lg    = _RE_ISE_LEAGUE.search(block)
    m_st    = _RE_ISE_STATUS.search(block)
    m_logo  = _RE_ISE_LOGO.search(block)

    title    = _clean(m_title.group(1)) if m_title else ''
    dt_str   = _clean(m_dt.group(1))   if m_dt    else ''
    league   = _clean(_RE_STRIP.sub(' ', m_lg.group(1))) if m_lg else ''
    league   = re.sub(r'\s+\d+\s+(?:hours?|minutes?)\s+from\s+now.*', '', league, flags=re.IGNORECASE).strip()
    status_class = m_st.group(1).strip() if m_st else 'upcoming'
    is_live  = 'live' in status_class.lower()
    logo_url = m_logo.group(1) if m_logo else ''
    return title, dt_str, league, logo_url, is_live


def _ise_events(sport_slug):
    url = ISE_BASE + '/schedule/%s' % sport_slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE schedule error (%s): %s' % (sport_slug, e), xbmc.LOGERROR)
        try:
            html = _get(ISE_BASE + '/')
        except Exception:
            return []

    events = []
    seen   = set()

    for m in _RE_ISE_CARD.finditer(html):
        path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
        if event_id in seen:
            continue
        seen.add(event_id)
        block = html[m.end():m.end() + 900]
        title, dt_str, league, logo_url, is_live = _parse_ise_block(block)

        _soccer_words = ('football', 'soccer', 'fifa', 'premier', 'champions', 'mls', 'laliga', 'bundesliga', 'serie')
        if sport_slug == 'soccer':
            if league and not any(w in league.lower() for w in _soccer_words):
                continue
        elif sport_slug != 'nfl' and league and sport_slug.lower() not in league.lower():
            continue

        events.append({
            'id':       event_id,
            'slug':     slug,
            'path':     path,
            'title':    title or slug.replace('-', ' ').title(),
            'datetime': dt_str,
            'league':   league,
            'logo':     logo_url,
            'is_live':  is_live,
            'start_ts': int(start_ts_str),
        })

    return events


# ── streamseast.cx events (supplementary) ────────────────────────────────────

_SEAST_SLUGS = {
    'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'nhl': 'nhl',
    'ufc': 'mma', 'boxing': 'boxing', 'soccer': 'soccer',
    'f1': 'f1', 'cfb': 'nfl', 'wwe': 'wwe',
}

# streamseast.is uses /sport/EVENT_ID/slug links
_RE_SEAST_CARD = re.compile(
    r'href=["\'](/(?:nfl|nba|mlb|nhl|mma|boxing|soccer|f1|wwe)/(\d+)/([^"\'#\s]+))["\']',
    re.IGNORECASE
)


def _seast_events(sport_slug):
    slug = _SEAST_SLUGS.get(sport_slug)
    if not slug:
        return []
    url = SEAST_BASE + '/%s' % slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast schedule error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()

    for m in _RE_SEAST_CARD.finditer(html):
        path, event_id, ev_slug = m.group(1), m.group(2), m.group(3)
        if event_id in seen:
            continue
        seen.add(event_id)
        # Title from slug: "red-sox-vs-angels" → "Red Sox Vs Angels"
        title = ev_slug.replace('-', ' ').title()
        # Try to get live/score indicator from context
        ctx = html[max(0, html.find(path) - 50):html.find(path) + 300]
        is_live = bool(re.search(r'(?:live|LIVE|in\s+progress|Top\s+\d|Bottom\s+\d|End\s+\d)', ctx))
        events.append({
            'id':       'seast_' + event_id,
            'slug':     ev_slug,
            'path':     'streamseast:' + path,
            'title':    title,
            'match_title': title,
            'datetime': '',
            'league':   slug.upper(),
            'logo':     '',
            'is_live':  is_live,
            'start_ts': 0,
        })

    xbmc.log('[Starfleet/Sports] StreamsEast %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _seast_event_streams(event_path):
    """Fetch streamseast.is event page, follow iframe chain to get embeds/m3u8."""
    path = event_path.replace('streamseast:', '')
    url  = SEAST_BASE + path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=SEAST_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen    = set()
    from urllib.parse import urlparse as _up_seast

    _M3U8_PAT = re.compile(
        r'["\']?(https?://[^\s"\'<>{},\)]+\.m3u8[^\s"\'<>{},\)]*)["\']?', re.I)

    def _collect_m3u8(page_html, label='StreamsEast HD'):
        for m3 in _M3U8_PAT.finditer(page_html):
            u = m3.group(1)
            if u not in seen:
                seen.add(u)
                streams.append({'label': label, 'url': u, 'quality': 'HD',
                                'language': '', 'source': 'StreamsEast'})

    # Scan main event page for m3u8
    _collect_m3u8(html)

    # Follow iframes up to 2 levels deep to extract m3u8.
    # Do NOT add embed page URLs (e.g. embedindia.st/embed/..., methstreams.gs/) as
    # streams — those pages are JS-rendered and unplayable in Kodi's video player.
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
    for iframe_url in iframes[:4]:
        if not iframe_url.startswith('http'):
            continue
        try:
            _pp = _up_seast(iframe_url)
            if not _pp.path or _pp.path in ('', '/'):
                continue  # skip bare homepage URLs
        except Exception:
            pass
        try:
            iframe_html = _sess().get(iframe_url, timeout=8,
                                      headers=dict(_HEADERS, Referer=url)).text
        except Exception:
            continue
        _collect_m3u8(iframe_html)
        for inner_m in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)["\']', iframe_html, re.I):
            inner_url = inner_m.group(1)
            if not inner_url.startswith('http'):
                continue
            try:
                _p2 = _up_seast(inner_url)
                if not _p2.path or _p2.path in ('', '/'):
                    continue
            except Exception:
                pass
            try:
                inner2_html = _sess().get(inner_url, timeout=8,
                                          headers=dict(_HEADERS, Referer=iframe_url)).text
            except Exception:
                continue
            _collect_m3u8(inner2_html)

    # Fallback: structured stream table (step 1 of _extract_stream_links) — only if
    # no m3u8 found above. This handles sites that serve clean direct-stream URLs in
    # an HTML table (not JS-rendered embed pages).
    if not streams:
        for s in _extract_stream_links(html, 'streamseast.is', 'StreamsEast'):
            u = s['url']
            if u not in seen:
                seen.add(u)
                streams.append(s)

    xbmc.log('[Starfleet/Sports] StreamsEast streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# ── Official league schedule APIs ─────────────────────────────────────────────

_ESPN_LOGO = 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/{league}/500/{abbrev}.png'


def _espn_logo(league, abbrev):
    """Return ESPN CDN PNG logo URL — Kodi can't render SVG."""
    if not abbrev:
        return ''
    return _ESPN_LOGO.format(league=league, abbrev=abbrev.lower().replace(' ', ''))


def _nhl_official_events():
    """NHL schedule from api-web.nhle.com — returns next ~7 days."""
    today = datetime.date.today().strftime('%Y-%m-%d')
    try:
        data = _get_json('https://api-web.nhle.com/v1/schedule/%s' % today, timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] NHL official: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for week_day in (data.get('gameWeek') or []):
        for gm in (week_day.get('games') or []):
            state   = gm.get('gameState', 'FUT')
            is_live = state in ('LIVE', 'CRIT')
            if state in ('FINAL', 'OFF'):
                continue
            home = gm.get('homeTeam', {})
            away = gm.get('awayTeam', {})
            home_name = ('%s %s' % (home.get('placeName', {}).get('default', ''),
                                    home.get('commonName', {}).get('default', ''))).strip()
            away_name = ('%s %s' % (away.get('placeName', {}).get('default', ''),
                                    away.get('commonName', {}).get('default', ''))).strip()
            match_title = '%s vs %s' % (away_name, home_name)
            title = match_title
            if is_live:
                title = '%s %s - %s %s' % (away_name, away.get('score', 0),
                                            home.get('score', 0), home_name)
            ts, dt_str = _ts_to_dt(gm.get('startTimeUTC', ''))
            home_logo = _espn_logo('nhl', home.get('abbrev', ''))
            away_logo = _espn_logo('nhl', away.get('abbrev', ''))
            events.append({
                'id': str(gm.get('id', '')), 'slug': str(gm.get('id', '')), 'path': '',
                'title': title, 'match_title': match_title, 'datetime': dt_str,
                'league': 'NHL', 'logo': away_logo or home_logo,
                'home_badge': home_logo, 'away_badge': away_logo,
                'is_live': is_live, 'start_ts': ts,
                'venue': gm.get('venue', {}).get('default', ''),
            })
    xbmc.log('[Starfleet/Sports] NHL official: %d events' % len(events), xbmc.LOGINFO)
    return events


def _nba_official_events():
    """NBA today's scoreboard from cdn.nba.com."""
    try:
        data = _get_json(
            'https://cdn.nba.com/static/json/liveData/scoreboard/todaysScoreboard_00.json',
            timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] NBA official: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for gm in (data.get('scoreboard', {}).get('games') or []):
        status  = gm.get('gameStatus', 1)
        is_live = (status == 2)
        if status == 3:
            continue
        home = gm.get('homeTeam', {})
        away = gm.get('awayTeam', {})
        home_name = ('%s %s' % (home.get('teamCity', ''), home.get('teamName', ''))).strip()
        away_name = ('%s %s' % (away.get('teamCity', ''), away.get('teamName', ''))).strip()
        match_title = '%s vs %s' % (away_name, home_name)
        title = match_title
        if is_live:
            title = '%s %s - %s %s' % (away_name, away.get('score', 0),
                                        home.get('score', 0), home_name)
        ts, dt_str = _ts_to_dt(gm.get('gameDateTimeUTC', ''))
        home_logo = _espn_logo('nba', home.get('teamTricode', ''))
        away_logo = _espn_logo('nba', away.get('teamTricode', ''))
        events.append({
            'id': gm.get('gameId', ''), 'slug': gm.get('gameId', ''), 'path': '',
            'title': title, 'match_title': match_title, 'datetime': dt_str,
            'league': 'NBA', 'logo': away_logo or home_logo,
            'home_badge': home_logo, 'away_badge': away_logo,
            'is_live': is_live, 'start_ts': ts, 'venue': '',
        })
    xbmc.log('[Starfleet/Sports] NBA official: %d events' % len(events), xbmc.LOGINFO)
    return events


def _mlb_official_events():
    """MLB schedule from statsapi.mlb.com — next 7 days."""
    today    = datetime.date.today()
    end_date = today + datetime.timedelta(days=6)
    url = ('https://statsapi.mlb.com/api/v1/schedule?sportId=1'
           '&startDate=%s&endDate=%s&hydrate=team,linescore'
           % (today.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')))
    try:
        data = _get_json(url, timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] MLB official: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for day in (data.get('dates') or []):
        for gm in (day.get('games') or []):
            abstract = gm.get('status', {}).get('abstractGameState', 'Preview')
            if abstract == 'Final':
                continue
            is_live   = (abstract == 'Live')
            home      = gm.get('teams', {}).get('home', {})
            away      = gm.get('teams', {}).get('away', {})
            home_name = home.get('team', {}).get('name', '')
            away_name = away.get('team', {}).get('name', '')
            match_title = '%s vs %s' % (away_name, home_name)
            title = match_title
            if is_live:
                title = '%s %s - %s %s' % (away_name, away.get('score', 0),
                                            home.get('score', 0), home_name)
            ts, dt_str = _ts_to_dt(gm.get('gameDate', ''))
            home_abbrev = home.get('team', {}).get('abbreviation', '')
            away_abbrev = away.get('team', {}).get('abbreviation', '')
            home_logo = _espn_logo('mlb', away_abbrev)
            away_logo = _espn_logo('mlb', home_abbrev)
            # Always use match_title (no score) as the event title so stream-site
            # title matching works regardless of live score updates.
            # Live score goes into plot so it still appears in the UI.
            plot = ('🔴 %s - %s (LIVE)' % (away.get('score', 0), home.get('score', 0))
                    if is_live else dt_str)
            events.append({
                'id': str(gm.get('gamePk', '')), 'slug': str(gm.get('gamePk', '')), 'path': '',
                'title': match_title, 'match_title': match_title, 'plot': plot, 'datetime': dt_str,
                'league': 'MLB', 'logo': away_logo or home_logo,
                'home_badge': home_logo, 'away_badge': away_logo,
                'is_live': is_live, 'start_ts': ts,
                'venue': gm.get('venue', {}).get('name', ''),
            })
    xbmc.log('[Starfleet/Sports] MLB official: %d events' % len(events), xbmc.LOGINFO)
    return events


def get_todays_sport_events(sport_slug, tsdb_sport='', max_items=20):
    """Return today's events for a sport, formatted for home carousel items."""
    import time as _time
    events = get_sport_events(sport_slug, tsdb_sport=tsdb_sport)
    now    = _time.time()
    cutoff = now + 86400  # next 24 hours
    items  = []
    for ev in events:
        ts = ev.get('start_ts', 0)
        if not ev.get('is_live') and ts and ts > cutoff:
            continue  # skip games more than 24h away
        logo  = ev.get('home_badge') or ev.get('logo') or ''
        fanart = ev.get('away_badge') or logo
        # For live games, title includes score ("Team A 2 - 1 Team B") which breaks
        # scraper title-matching. Use match_title ("Team A vs Team B") instead.
        display_title = ev.get('match_title') or ev.get('title', '')
        items.append({
            'id':          ev.get('id', ''),
            'title':       display_title,
            'thumb':       logo,
            'fanart':      fanart,
            'plot':        ev.get('league', '') + (' — 🔴 LIVE' if ev.get('is_live') else ''),
            'source':      'sports',
            'sport_slug':  sport_slug,
            'event_id':    ev.get('id', ''),
            'event_path':  ev.get('path', ''),
            'media_type':  'event',
        })
        if len(items) >= max_items:
            break
    return items


# ── Public event API ──────────────────────────────────────────────────────────

def _merge_events(primary, supplementary):
    """Merge supplementary events into primary, deduplicating by title similarity."""
    merged = list(primary)
    primary_titles = [e['title'] for e in primary]

    for ev in supplementary:
        # Check if a similar event already exists
        duplicate = False
        for pt in primary_titles:
            if _titles_match(ev['title'], pt, threshold=2):
                duplicate = True
                break
        if not duplicate:
            merged.append(ev)
            primary_titles.append(ev['title'])

    return merged


def get_sport_events(sport_slug='nfl', tsdb_sport=''):
    # tsdb_sport is the TheSportsDB sport name (e.g. 'Soccer', 'Ice Hockey')
    # Fall back to our static mapping if not provided
    if not tsdb_sport:
        tsdb_sport = _SLUG_TO_TSDB_SPORT.get(sport_slug, '')

    ck = 'sport_ev4_%s' % sport_slug   # v4: TSDB calendar as primary source
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    events = []

    # ── Phase 1: official APIs + TSDB calendar all in parallel ───────────────
    _today = datetime.date.today()
    _dates = [(_today + datetime.timedelta(days=d)).strftime('%Y-%m-%d') for d in range(7)]
    _ph1_ex  = ThreadPoolExecutor(max_workers=12)
    _ph1_futs = {}

    # Official league APIs (primary source for big-4)
    if sport_slug == 'nhl':
        _ph1_futs['official'] = _ph1_ex.submit(_nhl_official_events)
    elif sport_slug == 'nba':
        _ph1_futs['official'] = _ph1_ex.submit(_nba_official_events)
    elif sport_slug == 'mlb':
        _ph1_futs['official'] = _ph1_ex.submit(_mlb_official_events)
    elif sport_slug == 'nfl':
        # NFL.com feeds from ESPN; ESPN scoreboard is the de-facto official source
        _ph1_futs['official'] = _ph1_ex.submit(_espn_events, 'nfl')

    # TSDB calendar covers all other sports + supplements the big-4
    for _d in _dates:
        _ph1_futs['tsdb_%s' % _d] = _ph1_ex.submit(_tsdb_calendar_events, tsdb_sport, _d)

    _ph1_ex.shutdown(wait=False)

    official_events = []
    for _key, _f in _ph1_futs.items():
        try:
            _evs = _f.result(timeout=10)
            if not _evs:
                continue
            if _key == 'official':
                official_events = _evs
            else:
                events = _merge_events(events, _evs)
        except Exception:
            pass

    # Official API result takes precedence: merge TSDB into official (not the other way)
    if official_events:
        events = _merge_events(official_events, events)
    xbmc.log('[Starfleet/Sports] %s: official=%d tsdb=%d' % (
        sport_slug, len(official_events), len(events) - len(official_events)), xbmc.LOGINFO)

    # ── ESPN: adds live scores on top for non-big-4 sports ───────────────────
    espn_found = False
    if sport_slug in _ESPN_SPORTS and sport_slug not in ('nhl', 'nba', 'mlb', 'nfl'):
        espn_evs = _espn_events(sport_slug)
        espn_found = len(espn_evs) > 0
        if espn_evs:
            events = _merge_events(events, espn_evs)

    # For soccer: also poll extra leagues (PL, MLS, UCL, UEL) in parallel
    if sport_slug == 'soccer':
        def _fetch_extra_league(xl):
            try:
                _xdata = _get_json(_ESPN_API.format(sport='soccer', league=xl))
                _xevs  = []
                for ev in _xdata.get('events', []):
                    _st   = ev.get('status', {}).get('type', {}).get('state', 'pre')
                    _comp = (ev.get('competitions') or [{}])[0]
                    _cmps = _comp.get('competitors', [])
                    if len(_cmps) >= 2:
                        _teams = [c.get('team', {}).get('displayName', '') for c in _cmps]
                        _title = ' vs '.join(_teams)
                    else:
                        _title = ev.get('name', ev.get('shortName', ''))
                    _logo = _cmps[0].get('team', {}).get('logo', '') if _cmps else ''
                    _ts, _dt = _ts_to_dt(ev.get('date', ''))
                    _xevs.append({'id': ev.get('id', ''), 'slug': ev.get('id', ''),
                                  'path': '', 'title': _title, 'datetime': _dt,
                                  'league': xl.upper(), 'logo': _logo,
                                  'is_live': (_st == 'in'), 'start_ts': _ts})
                return _xevs
            except Exception:
                return []
        _xl_ex   = ThreadPoolExecutor(max_workers=len(_ESPN_SOCCER_EXTRA))
        _xl_futs = {xl: _xl_ex.submit(_fetch_extra_league, xl) for xl in _ESPN_SOCCER_EXTRA}
        _xl_ex.shutdown(wait=False)
        for xl, fut in _xl_futs.items():
            try:
                _xevs = fut.result(timeout=5)
                if _xevs:
                    events = _merge_events(events, _xevs)
            except Exception:
                pass

    # TSDB league fallback for UFC/Boxing/WWE (next-event API, not calendar)
    if not events and sport_slug in _TSDB_LEAGUES:
        events = _tsdb_events(sport_slug)

    # ISE fallback only when everything above returned nothing
    if not events:
        events = _ise_events(sport_slug)

    # Run supplementary sources in parallel (shutdown(wait=False) avoids blocking on hung futures)
    supplementary_futures = {}
    ex = ThreadPoolExecutor(max_workers=8)
    try:
        supplementary_futures['seast'] = ex.submit(_seast_events, sport_slug)
        if sport_slug in _METH_LEAGUE_PATHS:
            supplementary_futures['meth'] = ex.submit(_meth_events, sport_slug)
        if sport_slug in _TSTEK_SLUGS:
            supplementary_futures['tstek'] = ex.submit(_tstek_events, sport_slug)
        # onhockey covers ALL hockey leagues — run for any hockey sport slug
        _HOCKEY_SLUGS = {'nhl', 'ahl', 'khl', 'shl', 'ohl', 'whl', 'qmjhl',
                         'echl', 'ncaa-hockey', 'pwhl', 'iihf', 'hockey'}
        if sport_slug in _HOCKEY_SLUGS:
            def _onhockey_for_slug(slug=sport_slug):
                evs = _onhockey_events()
                if slug == 'hockey':
                    return evs   # all leagues
                # filter to events whose detected league matches the slug
                slug_upper = slug.upper()
                return [e for e in evs if e.get('league', 'NHL').upper() == slug_upper]
            supplementary_futures['onhockey'] = ex.submit(_onhockey_for_slug)

        for name, fut in supplementary_futures.items():
            try:
                extra = fut.result(timeout=5)
                if extra:
                    events = _merge_events(events, extra)
                    xbmc.log('[Starfleet/Sports] %s merged %d events from %s' % (sport_slug, len(extra), name), xbmc.LOGINFO)
            except Exception as e:
                msg = str(e) or type(e).__name__
                xbmc.log('[Starfleet/Sports] supplementary events error (%s/%s): %s' % (sport_slug, name, msg), xbmc.LOGWARNING)
    finally:
        ex.shutdown(wait=False)  # don't block on any still-running futures

    events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def get_all_events():
    ck = 'sports_events_all'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(ISE_BASE + '/')
        events = []
        seen   = set()

        for m in _RE_ISE_CARD.finditer(html):
            path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[m.end():m.end() + 900]
            title, dt_str, league, logo_url, is_live = _parse_ise_block(block)
            events.append({
                'id':       event_id,
                'slug':     slug,
                'path':     path,
                'title':    title or slug.replace('-', ' ').title(),
                'datetime': dt_str,
                'league':   league,
                'logo':     logo_url,
                'is_live':  is_live,
                'start_ts': int(start_ts_str),
            })

        events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
        _cache.set(ck, events, 10 * 60)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] all events error: %s' % e, xbmc.LOGERROR)
        return []


# ── Stream links ──────────────────────────────────────────────────────────────

# Known streaming embed/player domains — used as fallback link detection
_STREAM_EMBED_DOMAINS = (
    '720pstream', 'livetv', 'streamtape', 'cloudy.pk', 'stopstream',
    'nbaat', 'vecloud', 'embedstream', 'nlstreams', 'theflixer',
    'sportshdlive', 'daddylive', 'sportsurge', 'buffstream', 'atdhe',
    'firstrowsports', 'livesport', 'sportsbay', 'streameast',
    'crackstreams', 'volokit', 'acestream',
)

# istreameast.cx stream table row — flexible: 3 or more TDs, last with <a href>
_RE_ISE_STREAM_ROW = re.compile(
    r'<tr[^>]*>\s*'
    r'<td[^>]*>(.*?)</td>\s*'          # col 1: streamer/name
    r'<td[^>]*>(.*?)</td>\s*'          # col 2: channel/quality
    r'(?:<td[^>]*>.*?</td>\s*)*'       # optional extra cols
    r'<td[^>]*><a[^>]+href="([^"#][^"]*)"[^>]*>',
    re.IGNORECASE | re.DOTALL
)

# Fallback: any external <a> with href on a stream page
_RE_EXT_LINK = re.compile(
    r'<a[^>]+href="(https?://([^/"]+)[^"]*)"[^>]*>([^<]{1,80})</a>',
    re.IGNORECASE
)
# Fallback: iframes with external src
_RE_IFRAME_SRC = re.compile(r'<iframe[^>]+src="(https?://[^"]+)"', re.IGNORECASE)


def _extract_stream_links(html, base_domain, source_label):
    """
    Try structured table parse first, then fall back to link/iframe extraction.
    Returns list of stream dicts.
    """
    streams = []

    # 1. Try structured table rows
    for m in _RE_ISE_STREAM_ROW.finditer(html):
        col1 = _clean(m.group(1))
        col2 = _clean(m.group(2))
        url  = m.group(3).strip()
        if not url or url == '#':
            continue
        label = ('%s %s' % (col1, col2)).strip() or source_label
        streams.append({
            'label':    label,
            'url':      url,
            'quality':  col2,
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 2. Fallback: iframes
    for m in _RE_IFRAME_SRC.finditer(html):
        src = m.group(1).strip()
        if base_domain and base_domain in src:
            continue
        try:
            from urllib.parse import urlparse as _up2
            _pp = _up2(src)
            if not _pp.path or _pp.path in ('', '/'):
                continue  # skip bare homepage URLs (e.g. methstreams.gs/)
        except Exception:
            pass
        streams.append({
            'label':    source_label + ' Embedded',
            'url':      src,
            'quality':  '',
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 3. Fallback: known stream embed domain links
    for m in _RE_EXT_LINK.finditer(html):
        href   = m.group(1).strip()
        domain = m.group(2).lower()
        text   = _clean(m.group(3))
        if base_domain and base_domain in domain:
            continue
        if any(d in domain for d in _STREAM_EMBED_DOMAINS):
            streams.append({
                'label':    text or (source_label + ' Stream'),
                'url':      href,
                'quality':  '',
                'language': '',
                'source':   source_label,
            })

    return streams


def _ise_event_streams(event_path, event_id=''):
    url = ISE_BASE + event_path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=ISE_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE stream page error (%s): %s' % (event_path, e), xbmc.LOGERROR)
        return []

    streams = _extract_stream_links(html, 'istreameast.cx', 'StreamEast')
    xbmc.log('[Starfleet/Sports] ISE streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# Roxiestreams
_ROXIE_SLUGS = {
    'nfl':    'nfl',
    'nba':    'nba',
    'mlb':    'mlb',
    'nhl':    'nhl',
    'ufc':    'fighting',
    'boxing': 'fighting',
    'soccer': 'soccer',
    'wwe':    'wwe',
    'cfb':    'ncaaf',
    'ncaab':  'ncaab',
    'f1':     'f1',
    'cfl':    'cfl',
}

# Match both absolute (https://roxiestreams.info/...) and relative (/...) event links
_RE_ROXIE_EVENT_LINK = re.compile(
    r'<a[^>]+href=["\'](?:https?://roxiestreams\.info)?(/[^"\'#\s]{3,80})["\'][^>]*>\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

_ROXIE_SKIP = frozenset((
    'home', 'menu', 'schedule', 'login', 'register', 'about', 'contact',
    'discord', 'multiview', 'stream request (discord)',
))
_ROXIE_NAV = frozenset((
    'soccer', 'nba', 'nfl', 'nhl', 'fighting', 'motorsports', 'wwe', 'f1',
    'cfl', 'ncaaf', 'ncaab', 'soccer (wc 2026)', 'roxiestreams', 'multiview (new)',
))


def _roxie_streams(sport_slug, event_title=''):
    slug = _ROXIE_SLUGS.get(sport_slug)
    if not slug:
        return []
    listing_url = ROXIE_BASE + '/' + slug
    try:
        html = _get(listing_url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Roxie (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    title_words = [w.lower() for w in re.split(r'\W+', event_title) if len(w) > 3] if event_title else []

    # Find the event page URL that best matches the title
    event_url = None
    best_score = 0
    for m in _RE_ROXIE_EVENT_LINK.finditer(html):
        link_path = m.group(1)
        row_text  = _clean(m.group(2))
        if not row_text or len(row_text) < 4:
            continue
        if row_text.lower() in _ROXIE_SKIP or row_text.lower() in _ROXIE_NAV:
            continue
        if title_words:
            row_lower = row_text.lower()
            score = sum(1 for w in title_words if w in row_lower)
            if score > best_score:
                best_score = score
                event_url = ROXIE_BASE + link_path
        elif event_url is None:
            event_url = ROXIE_BASE + link_path

    if not event_url or (title_words and best_score == 0):
        xbmc.log('[Starfleet/Sports] Roxie %s "%s": no matching event' % (sport_slug, event_title), xbmc.LOGINFO)
        return []

    # Fetch the event page and extract direct m3u8 URLs
    try:
        ev_html = _sess().get(event_url, timeout=10,
                              headers=dict(_HEADERS, Referer=listing_url)).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Roxie event page error (%s): %s' % (event_url, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen = set()
    for m3u8_m in re.finditer(
            r'["\']?(https?://[^\s"\'<>{},\)]+\.m3u8[^\s"\'<>{},\)]*)["\']?',
            ev_html, re.I):
        u = m3u8_m.group(1)
        if u not in seen:
            seen.add(u)
            streams.append({'label': 'Roxie HD', 'url': u, 'quality': 'HD',
                            'language': '', 'source': 'RoxieStreams'})

    # Fallback: known embed domains via _extract_stream_links
    extra = _extract_stream_links(ev_html, 'roxiestreams.info', 'RoxieStreams')
    for s in extra:
        if s['url'] not in seen:
            seen.add(s['url'])
            streams.append(s)

    xbmc.log('[Starfleet/Sports] Roxie %s "%s": %d streams' % (sport_slug, event_title, len(streams)), xbmc.LOGINFO)
    return streams


# ── TotalSportek24 (multi-sport) ─────────────────────────────────────────────

# Maps our internal slugs to TotalSportek24 URL path segments
_TSTEK_SLUGS = {
    'soccer':  'soccer-streams',
    'nfl':     'nfl-streams',
    'nba':     'nba-streams',
    'nhl':     'nhl-streams',
    'mlb':     'mlb-stream',
    'ufc':     'ufc-streams',
    'boxing':  'boxing-streams',
    'f1':      'f1-streams',
    'cfb':     'college-football-streams',
    'ncaab':   'college-basketball-streams',
    'wwe':     'wwe-streams',
    'tennis':  'tennis-streams',
    'rugby':   'rugby-streams',
    'cricket': 'cricket-streams',
    'motogp':  'motogp-streams',
}

# Event card: <a href="/game/..."><div>...<span>TIME UTC</span>...<div class="row my-auto">TITLE</div>...</div></a>
_RE_TSTEK_GAME_CARD = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/game/[^"#\s]{4,120})"[^>]*>'
    r'.*?<span>\s*(\d+:\d+\s*(?:am|pm)[^<]*?)\s*</span>'
    r'.*?<div[^>]+class="row[^"]*my-auto[^"]*"[^>]*>\s*([^<]{3,120}?)\s*</div>',
    re.IGNORECASE | re.DOTALL
)

# Fallback: plain text anchor (older page layout)
_RE_TSTEK_EVENT = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^"#\s]{4,120})"[^>]*>'
    r'\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

# Nav links used to discover which sport sections actually exist on the site
_RE_TSTEK_NAV = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^/"]+/?)"[^>]*>'
    r'\s*([^<]{2,40}?)\s*</a>',
    re.IGNORECASE
)

# Cache the scraped nav/sport-section map across calls
_tstek_sport_urls = {}   # slug → full URL to that sport's schedule page


def _tstek_discover():
    """
    Fetch TotalSportek24 homepage and build a map of sport-slug → URL.
    Caches the result in _tstek_sport_urls for the session.
    """
    global _tstek_sport_urls
    if _tstek_sport_urls:
        return _tstek_sport_urls

    ck = 'tstek_sport_urls'
    cached = _cache.get(ck)
    if cached:
        _tstek_sport_urls = cached
        return _tstek_sport_urls

    try:
        html = _sess().get(TSTEK_BASE + '/', timeout=12,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 homepage error: %s' % e, xbmc.LOGWARNING)
        return {}

    # Build reverse map: url-path-segment → our slug
    reverse = {v: k for k, v in _TSTEK_SLUGS.items()}
    result  = {}

    for m in _RE_TSTEK_NAV.finditer(html):
        href    = m.group(1).rstrip('/')
        segment = href.rstrip('/').rsplit('/', 1)[-1].lower()
        if segment in reverse:
            our_slug = reverse[segment]
            result[our_slug] = href
            xbmc.log('[Starfleet/Sports] TotalSportek24 found sport: %s → %s' % (our_slug, href), xbmc.LOGINFO)

    # Fallback: construct URLs from the known slug map for any missing sports
    for our_slug, tstek_slug in _TSTEK_SLUGS.items():
        if our_slug not in result:
            result[our_slug] = '%s/%s/' % (TSTEK_BASE, tstek_slug)

    _tstek_sport_urls = result
    _cache.set(ck, result, 60 * 60)  # cache 1 hour
    return result


def _tstek_events(sport_slug):
    """Scrape TotalSportek24 for events matching the given sport slug."""
    import calendar as _cal

    ck = 'sports_tstek_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    sport_url = '%s/%s' % (TSTEK_BASE, _TSTEK_SLUGS.get(sport_slug, sport_slug + '-streams'))
    try:
        html = _sess().get(sport_url, timeout=12,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 sport page error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()
    now_utc = datetime.datetime.utcnow()

    # Primary: new card layout with /game/ URLs, inline time and title
    for m in _RE_TSTEK_GAME_CARD.finditer(html):
        href     = m.group(1).strip()
        raw_time = m.group(2).strip()   # e.g. "01:00 am  UTC"
        title    = _clean(m.group(3))
        if not title or href in seen:
            continue
        seen.add(href)

        # Parse UTC time into a timestamp (assume today or tomorrow)
        start_ts = 0
        try:
            time_only = re.search(r'(\d+):(\d+)\s*(am|pm)', raw_time, re.I)
            if time_only:
                hh = int(time_only.group(1)) % 12
                if time_only.group(3).lower() == 'pm':
                    hh += 12
                mm = int(time_only.group(2))
                dt_utc = now_utc.replace(hour=hh, minute=mm, second=0, microsecond=0)
                # If time already passed today, assume it's tomorrow
                if dt_utc < now_utc and (now_utc - dt_utc).seconds > 3600:
                    dt_utc = dt_utc + datetime.timedelta(days=1)
                start_ts = int(_cal.timegm(dt_utc.timetuple()))
        except Exception:
            pass

        events.append({
            'id':       'tstek_' + re.sub(r'\W+', '_', href),
            'slug':     href.replace(TSTEK_BASE, '').strip('/'),
            'path':     'tstek:' + href,
            'title':    title,
            'datetime': raw_time,
            'league':   sport_slug.upper(),
            'logo':     '',
            'is_live':  False,
            'start_ts': start_ts or int(time.time()),
        })

    # Fallback: older plain-text anchor layout
    if not events:
        tstek_seg  = _TSTEK_SLUGS.get(sport_slug, sport_slug)
        is_soccer  = (sport_slug == 'soccer')
        other_segs = set(_TSTEK_SLUGS.values()) - {tstek_seg}
        skip_words = {'schedule', 'fixtures', 'results', 'standings', 'news', 'about',
                      'contact', 'privacy', 'home', 'live', 'stream', 'watch', tstek_seg}
        for m in _RE_TSTEK_EVENT.finditer(html):
            href  = m.group(1).strip()
            title = _clean(m.group(2))
            if not title or len(title) < 5 or href in seen:
                continue
            path_parts = href.replace(TSTEK_BASE, '').strip('/').split('/')
            if is_soccer:
                if path_parts[0].lower() in other_segs:
                    continue
            else:
                if not path_parts or path_parts[0].lower() != tstek_seg.lower():
                    continue
            if title.lower() in skip_words:
                continue
            seen.add(href)
            events.append({
                'id':       'tstek_' + re.sub(r'\W+', '_', href),
                'slug':     href.replace(TSTEK_BASE, '').strip('/'),
                'path':     'tstek:' + href,
                'title':    title,
                'datetime': '',
                'league':   sport_slug.upper(),
                'logo':     '',
                'is_live':  False,
                'start_ts': int(time.time()),
            })

    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] TotalSportek24 %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _tstek_streams(event_path):
    """Scrape stream links from a TotalSportek24 event page."""
    url = event_path.replace('tstek:', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, 'totalsportek24.is', 'TotalSportek')
    xbmc.log('[Starfleet/Sports] TotalSportek24 streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _tstek_streams_by_title(sport_slug, event_title):
    """Cross-reference: find best TotalSportek24 event by title and scrape its streams."""
    try:
        evs = _tstek_events(sport_slug)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tstek_x events error: %s' % e, xbmc.LOGWARNING)
        return []
    best_path, best_score, best_title = None, 0, ''
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
            best_title = ev['title']
    xbmc.log('[Starfleet/Sports] tstek_x "%s" vs %d events: best="%s" score=%d path=%s'
             % (event_title, len(evs), best_title, best_score, best_path), xbmc.LOGINFO)
    if not best_path or best_score < 1:
        return []
    try:
        return _tstek_streams(best_path)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tstek_x streams error: %s' % e, xbmc.LOGWARNING)
        return []


# ── *24all.ir generic helpers ─────────────────────────────────────────────────

def _x24_events(domain, sport_label, path_prefix):
    """Generic scraper for *24all.ir sites (mlb24all.ir, nhl24all.ir, nfl24all.ir, nba24all.ir)."""
    base = 'https://' + domain
    pattern = re.compile(
        r'<a[^>]+href="(https?://' + re.escape(domain) + r'/[^"]+)"[^>]*>([^<]+)</a>',
        re.IGNORECASE
    )
    try:
        html = _sess().get(base + '/', timeout=12,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s fetch error: %s' % (domain, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()
    skip_words = ('home', 'schedule', 'about', 'contact', 'privacy', domain.split('.')[0])

    for m in pattern.finditer(html):
        path  = m.group(1).strip()
        title = _clean(m.group(2))
        if not title or len(title) < 4 or path in seen:
            continue
        if any(s in title.lower() for s in skip_words):
            continue
        seen.add(path)
        events.append({
            'id':       path_prefix + re.sub(r'\W+', '_', path),
            'slug':     re.sub(r'https?://' + re.escape(domain) + r'/', '', path).strip('/'),
            'path':     path_prefix + ':' + path,
            'title':    title,
            'datetime': '',
            'league':   sport_label,
            'logo':     '',
            'is_live':  True,
            'start_ts': 0,
        })

    xbmc.log('[Starfleet/Sports] %s: %d events' % (domain, len(events)), xbmc.LOGINFO)
    return events


def _x24_streams(event_path, path_prefix, domain, source_label):
    """Generic stream scraper for *24all.ir event pages."""
    url = event_path.replace(path_prefix + ':', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer='https://' + domain + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s stream page error (%s): %s' % (domain, event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, domain, source_label)

    # Also pick up any explicit watch/stream/live anchors not caught above
    extra_re = re.compile(
        r'<a[^>]+href="(https?://[^"]+)"[^>]*>(?:[^<]*(?:watch|stream|live)[^<]*)</a>',
        re.IGNORECASE
    )
    for m in extra_re.finditer(html):
        su = m.group(1).strip()
        if not su or domain in su:
            continue
        if not any(s['url'] == su for s in streams):
            streams.append({'label': source_label + ' Stream', 'url': su,
                            'quality': '', 'language': '', 'source': source_label})

    xbmc.log('[Starfleet/Sports] %s streams for %s: %d' % (domain, event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _x24_streams_by_title(event_title, domain, path_prefix, sport_label, source_label):
    """Cross-reference: find best matching event on *24all.ir and scrape its streams."""
    evs = _x24_events(domain, sport_label, path_prefix)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _x24_streams(best_path, path_prefix, domain, source_label)


# ── MethStreams (multi-sport, same slug structure as CrackStreams) ────────────

_METH_LEAGUE_PATHS = {
    'mlb':    '/league/mlbstreams',
    'nfl':    '/league/nflstreams',
    'nba':    '/league/nbastreams',
    'nhl':    '/league/nhlstreams',
    'ufc':    '/league/mmastreams',
    'boxing': '/league/boxingstreams',
    'soccer': '/league/soccerstreams',
    'wwe':    '/league/wwestreams',
    'ncaab':  '/league/ncaab',
    'cfb':    '/league/cfbstreams',
    'f1':     '/league/f1streams',
}

_RE_METH_STREAM_LINK = re.compile(
    r'href=["\'](/stream/([^"\'#\s]{4,80}))["\']', re.IGNORECASE
)


def _meth_events(sport_slug):
    """Scrape MethStreams league page for event slugs."""
    path = _METH_LEAGUE_PATHS.get(sport_slug)
    if not path:
        return []
    ck = 'sports_meth_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html = _sess().get(METH_BASE + path, timeout=10,
                           headers=dict(_HEADERS, Referer=METH_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] MethStreams (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    seen = set()
    for m in _RE_METH_STREAM_LINK.finditer(html):
        link_path = m.group(1)
        game_slug = m.group(2)
        if game_slug in seen:
            continue
        seen.add(game_slug)
        title = game_slug.replace('-', ' ').title()
        events.append({
            'id':       'meth_' + game_slug,
            'slug':     game_slug,
            'path':     'meth:' + METH_BASE + link_path,
            'title':    title,
            'datetime': '',
            'league':   sport_slug.upper(),
            'logo':     '',
            'is_live':  True,
            'start_ts': int(time.time()),
        })

    xbmc.log('[Starfleet/Sports] MethStreams %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    _cache.set(ck, events, 10 * 60)
    return events


def _meth_event_streams(sport_slug, event_title=''):
    """Find the best-matching MethStreams event by title, return its stream page URL as a stream link.
    Note: MethStreams event pages are JS-rendered — no m3u8 in HTML. Returns slug URL as fallback."""
    evs = _meth_events(sport_slug)
    if not evs:
        return []
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = METH_BASE + '/stream/' + ev['slug']
    if not best_path or best_score < 2:
        return []
    return [{'label': 'MethStreams', 'url': best_path,
             'quality': '', 'language': '', 'source': 'MethStreams'}]


# ── mlb24all.ir (MLB-specific) ────────────────────────────────────────────────

_RE_MLB24_EVENT = re.compile(
    r'<a[^>]+href="(https?://mlb24all\.ir/[^"]+)"[^>]*>([^<]+)</a>',
    re.IGNORECASE
)
# Sport-specific wrappers using the generic _x24_* helpers

def _mlb24_events():
    return _x24_events('mlb24all.ir', 'MLB', 'mlb24')

def _mlb24_streams(event_path):
    return _x24_streams(event_path, 'mlb24', 'mlb24all.ir', 'MLB24')

def _mlb24_streams_by_title_inner(event_title):
    return _x24_streams_by_title(event_title, 'mlb24all.ir', 'mlb24', 'MLB', 'MLB24')


# ── mlb66.ir (MLB-specific — dedicated live stream aggregator) ────────────────

def _mlb66_events():
    return _x24_events('mlb66.ir', 'MLB', 'mlb66')

def _mlb66_streams(event_path):
    return _x24_streams(event_path, 'mlb66', 'mlb66.ir', 'MLB66')

def _mlb66_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'mlb66.ir', 'mlb66', 'MLB', 'MLB66')


# ── BuffStreams (baseball section) ────────────────────────────────────────────

BUFFSTREAMS_BASE = 'https://buffstreams.app'

_RE_BUFF_GAME = re.compile(
    r'<a[^>]+href="(/[^"]*(?:baseball|mlb)[^"]*)"[^>]*>\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)


def _buffstreams_mlb_events():
    for path in ('/baseball/', '/baseball', '/'):
        try:
            html = _sess().get(BUFFSTREAMS_BASE + path, timeout=10,
                               headers=dict(_HEADERS, Referer='https://www.google.com/')).text
            events = []
            skip = {'home', 'schedule', 'about', 'contact', 'privacy', 'dmca', 'terms'}
            for m in _RE_BUFF_GAME.finditer(html):
                link = m.group(1).strip()
                title = _clean(m.group(2))
                if not title or title.lower() in skip:
                    continue
                full_url = BUFFSTREAMS_BASE + link
                events.append({
                    'id': 'buff_' + re.sub(r'\W+', '_', link),
                    'slug': link.strip('/'),
                    'path': 'buffstreams:' + full_url,
                    'title': title, 'datetime': '', 'league': 'MLB',
                    'logo': '', 'is_live': True, 'start_ts': 0,
                })
            if events:
                xbmc.log('[Starfleet/Sports] BuffStreams MLB: %d events' % len(events), xbmc.LOGINFO)
                return events
        except Exception as e:
            xbmc.log('[Starfleet/Sports] BuffStreams fetch error (%s): %s' % (path, e), xbmc.LOGWARNING)
    return []


def _buffstreams_streams(event_path):
    url = event_path.replace('buffstreams:', '')
    try:
        html = _sess().get(url, timeout=10,
                           headers=dict(_HEADERS, Referer=BUFFSTREAMS_BASE + '/')).text
        return _extract_stream_links(html, 'buffstreams.app', 'BuffStreams')
    except Exception as e:
        xbmc.log('[Starfleet/Sports] BuffStreams streams error: %s' % e, xbmc.LOGWARNING)
        return []


def _buffstreams_streams_by_title(event_title):
    evs = _buffstreams_mlb_events()
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = ev['path']
    if not best_path or best_score < 2:
        return []
    return _buffstreams_streams(best_path)


# ── DaddyLive (daily multi-sport schedule) ────────────────────────────────────

_DADDYLIVE_BASES = [
    'https://daddylive.eu',
]

_RE_DADDY_EVENT = re.compile(
    r'<a[^>]+href="(/[^"#\s]{4,80})"[^>]*>\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

_DADDY_SPORT_KEYWORDS = {
    'mlb':     ['mlb', 'baseball', 'red sox', 'yankees', 'dodgers', 'cubs', 'mets',
                'braves', 'astros', 'phillies', 'blue jays', 'mariners', 'giants',
                'padres', 'angels', 'tigers', 'twins', 'rays', 'orioles', 'guardians'],
    'nfl':     ['nfl', 'football', 'patriots', 'chiefs', 'bills', 'eagles', 'cowboys'],
    'nba':     ['nba', 'basketball', 'lakers', 'celtics', 'warriors', 'heat', 'bulls'],
    'nhl':     ['nhl', 'hockey', 'bruins', 'rangers', 'leafs', 'canadiens', 'penguins'],
    'soccer':  ['soccer', 'football', 'premier league', 'la liga', 'serie a', 'champions'],
}


def _daddylive_events(sport_slug):
    keywords = _DADDY_SPORT_KEYWORDS.get(sport_slug, [])
    if not keywords:
        return []
    for base in _DADDYLIVE_BASES:
        try:
            html = _sess().get(base + '/schedule.php', timeout=10,
                               headers=dict(_HEADERS, Referer='https://www.google.com/')).text
            events = []
            skip = {'home', 'schedule', 'about', 'contact', 'privacy'}
            for m in _RE_DADDY_EVENT.finditer(html):
                link = m.group(1).strip()
                title = _clean(m.group(2))
                if not title or title.lower() in skip or len(title) < 4:
                    continue
                tl = title.lower()
                if not any(kw in tl for kw in keywords):
                    continue
                full_url = base + link
                events.append({
                    'id': 'daddy_' + re.sub(r'\W+', '_', link),
                    'slug': link.strip('/'),
                    'path': 'daddylive:' + full_url,
                    'title': title, 'datetime': '', 'league': sport_slug.upper(),
                    'logo': '', 'is_live': True, 'start_ts': 0,
                })
            if events:
                xbmc.log('[Starfleet/Sports] DaddyLive %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
                return events
        except Exception as e:
            xbmc.log('[Starfleet/Sports] DaddyLive fetch error (%s): %s' % (base, e), xbmc.LOGWARNING)
    return []


def _daddylive_streams(event_path):
    url = event_path.replace('daddylive:', '')
    base = next((b for b in _DADDYLIVE_BASES if b in url), _DADDYLIVE_BASES[0])
    try:
        html = _sess().get(url, timeout=10,
                           headers=dict(_HEADERS, Referer=base + '/')).text
        streams = _extract_stream_links(html, 'daddylive', 'DaddyLive')
        if not streams:
            # Look for iframe embeds or redirects to player pages
            for m in re.finditer(r'href=["\']([^"\']+channel[^"\']+)["\']', html, re.I):
                chan_url = m.group(1)
                if not chan_url.startswith('http'):
                    chan_url = base + '/' + chan_url.lstrip('/')
                streams.append({'label': 'DaddyLive Channel', 'url': chan_url,
                                'quality': '', 'language': '', 'source': 'DaddyLive'})
        xbmc.log('[Starfleet/Sports] DaddyLive streams: %d' % len(streams), xbmc.LOGINFO)
        return streams
    except Exception as e:
        xbmc.log('[Starfleet/Sports] DaddyLive streams error: %s' % e, xbmc.LOGWARNING)
        return []


def _daddylive_streams_by_title(sport_slug, event_title):
    evs = _daddylive_events(sport_slug)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = ev['path']
    if not best_path or best_score < 2:
        return []
    return _daddylive_streams(best_path)


def _nhl24_events():
    return _x24_events('nhl24all.ir', 'NHL', 'nhl24')

def _nhl24_streams(event_path):
    return _x24_streams(event_path, 'nhl24', 'nhl24all.ir', 'NHL24')

def _nhl24_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'nhl24all.ir', 'nhl24', 'NHL', 'NHL24')


def _nfl24_events():
    return _x24_events('nfl24all.ir', 'NFL', 'nfl24')

def _nfl24_streams(event_path):
    return _x24_streams(event_path, 'nfl24', 'nfl24all.ir', 'NFL24')

def _nfl24_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'nfl24all.ir', 'nfl24', 'NFL', 'NFL24')


def _nba24_events():
    return _x24_events('nba24all.ir', 'NBA', 'nba24')

def _nba24_streams(event_path):
    return _x24_streams(event_path, 'nba24', 'nba24all.ir', 'NBA24')

def _nba24_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'nba24all.ir', 'nba24', 'NBA', 'NBA24')


# ── onhockey.tv (all hockey leagues) ─────────────────────────────────────────

# In-memory cache for inline stream links scraped from schedule_table.php
_ONHOCKEY_STREAM_CACHE = {}

_RE_ONHOCKEY_TBODY   = re.compile(r"<tbody[^>]*class=['\"]([^'\"]*)['\"][^>]*>(.*?)</tbody>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_LEAGUE  = re.compile(r'<b>([A-Z][A-Z0-9 /\-]{1,20})</b>', re.IGNORECASE)
_RE_ONHOCKEY_GAMEROW = re.compile(r"<tr class='game'[^>]*>(.*?)</tr>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_HOUR    = re.compile(r"class='game_hour'[^>]*>(\d+)</text>:(\d+)", re.IGNORECASE)
_RE_ONHOCKEY_TITLE   = re.compile(r"</td><td>([^<\n]{3,100})", re.IGNORECASE)
_RE_ONHOCKEY_GL      = re.compile(r"class='gamelinks'[^>]*>(.*?)</div>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_CHAN    = re.compile(r"href='np_stream400\.php\?channel=([^'\"&]{5,200})'[^>]*(?:title='([^']*)')?", re.IGNORECASE)

_RE_ONHOCKEY_WATCH = re.compile(
    r'<a[^>]+href="(https?://(?!onhockey\.tv)[^"]{10,200})"[^>]*>([^<]*(?:Watch|Stream|Link|HD|Mirror|\d)[^<]*)</a>',
    re.IGNORECASE
)
_RE_ONHOCKEY_NUMBERED = re.compile(
    r'<a[^>]+href="(https?://(?!onhockey\.tv)[^"]{10,200})"[^>]*>\s*(?:(?:Stream|Link|Watch|HD)\s*)?\d+\s*</a>',
    re.IGNORECASE
)


_ONHOCKEY_LEAGUE_KEYWORDS = [
    ('AHL',   ('ahl',)),
    ('KHL',   ('khl',)),
    ('OHL',   ('ohl',)),
    ('WHL',   ('whl',)),
    ('QMJHL', ('qmjhl', 'lhjmq')),
    ('ECHL',  ('echl',)),
    ('SHL',   ('shl',)),
    ('DEL',   ('del ',)),
    ('NCAA',  ('ncaa', 'college hockey', 'university')),
    ('IIHF',  ('iihf', 'world championship', 'world cup of hockey')),
    ('PHF',   ('phf', 'premier hockey')),
    ('PWHL',  ('pwhl',)),
    ('NWHL',  ('nwhl',)),
]


def _onhockey_league(title):
    """Detect hockey league from event title; defaults to NHL."""
    t = title.lower()
    for league, keywords in _ONHOCKEY_LEAGUE_KEYWORDS:
        if any(k in t for k in keywords):
            return league
    return 'NHL'


def _onhockey_events():
    """Scrape onhockey.tv schedule via schedule_table.php (AJAX endpoint).
    Parses tbody/game-row structure, caches inline stream links per event.
    """
    import datetime as _dt
    import calendar as _cal

    global _ONHOCKEY_STREAM_CACHE

    try:
        r = _sess().get(
            ONHOCKEY_BASE + '/schedule_table.php',
            timeout=12,
            headers=dict(_HEADERS,
                         Referer=ONHOCKEY_BASE + '/',
                         **{'X-Requested-With': 'XMLHttpRequest'}),
        )
        r.raise_for_status()
        html = r.text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] onhockey.tv schedule error: %s' % e, xbmc.LOGWARNING)
        return []

    events = []
    _ONHOCKEY_STREAM_CACHE = {}
    current_league = 'NHL'
    # Default to today UTC; updated when we hit a Date row
    _now_utc = _dt.datetime.utcnow()
    current_date = _now_utc.date()
    current_year = _now_utc.year

    for tbody_m in _RE_ONHOCKEY_TBODY.finditer(html):
        tbody_class = tbody_m.group(1)
        tbody_html  = tbody_m.group(2)

        if 'Date' in tbody_class:
            # Parse date like "<b>July 3</b>"
            dm = re.search(r'<b>(\w+ \d+)</b>', tbody_html)
            if dm:
                try:
                    current_date = _dt.datetime.strptime(
                        '%s %d' % (dm.group(1), current_year), '%B %d %Y'
                    ).date()
                except Exception:
                    pass
            continue

        # League name from the bold header in this tbody
        lhdr = _RE_ONHOCKEY_LEAGUE.search(tbody_html)
        if lhdr:
            current_league = lhdr.group(1).strip()

        for game_m in _RE_ONHOCKEY_GAMEROW.finditer(tbody_html):
            row_html = game_m.group(1)

            title_m = _RE_ONHOCKEY_TITLE.search(row_html)
            if not title_m:
                continue
            title = title_m.group(1).strip()
            if not title or len(title) < 3:
                continue
            # Skip TV channel names (e.g. "NHL Network", "ESPN+") — not actual games
            _tl = title.lower()
            if not any(sep in _tl for sep in (' vs ', ' at ', ' @ ', ' v ')):
                continue

            hour_m = _RE_ONHOCKEY_HOUR.search(row_html)
            start_ts = 0
            date_label = ''
            if hour_m:
                try:
                    hh = int(hour_m.group(1))
                    mm = int(hour_m.group(2))
                    dt_utc = _dt.datetime(
                        current_date.year, current_date.month, current_date.day, hh, mm, 0
                    )
                    start_ts = int(_cal.timegm(dt_utc.timetuple()))
                    # Human date label e.g. "Jul 3"
                    date_label = current_date.strftime('%b %-d') if hasattr(current_date, 'strftime') else str(current_date)
                except Exception:
                    pass

            # Extract inline stream links from gamelinks div
            links = []
            gl_m = _RE_ONHOCKEY_GL.search(row_html)
            if gl_m:
                for lm in _RE_ONHOCKEY_CHAN.finditer(gl_m.group(1)):
                    chan = lm.group(1).strip()
                    if chan.startswith('//'):
                        chan = 'https:' + chan
                    elif not chan.startswith('http'):
                        chan = ONHOCKEY_BASE + '/' + chan.lstrip('/')
                    lbl = lm.group(2) or title
                    links.append({
                        'label': '[OnHockey] %s' % lbl,
                        'url': chan,
                        'quality': '', 'language': '', 'source': 'OnHockey.tv',
                    })

            ev_id = 'onhockey_%s_%s_%s' % (
                re.sub(r'\W+', '_', current_league.lower()),
                str(current_date),
                re.sub(r'\W+', '_', title.lower())[:50],
            )

            if links:
                _ONHOCKEY_STREAM_CACHE[ev_id] = links

            events.append({
                'id':         ev_id,
                'slug':       ev_id,
                'path':       'onhockey:' + ev_id,
                'title':      title,
                'date_label': date_label,
                'league':     current_league,
                'logo':       '',
                'is_live':    bool(links),
                'start_ts':   start_ts,
            })

    xbmc.log('[Starfleet/Sports] onhockey.tv: %d events across %d leagues' % (
        len(events), len(set(e['league'] for e in events))), xbmc.LOGINFO)
    return events


def _onhockey_streams(event_path):
    """Return stream links for an onhockey.tv event.
    Checks the in-memory stream cache first (populated by _onhockey_events()).
    Falls back to fetching the game page URL if the path is a full URL.
    """
    ev_id = event_path.replace('onhockey:', '')

    # Try in-memory cache (schedule_table.php inline links)
    cached = _ONHOCKEY_STREAM_CACHE.get(ev_id)
    if cached:
        xbmc.log('[Starfleet/Sports] onhockey.tv cached streams for %s: %d' % (ev_id, len(cached)), xbmc.LOGINFO)
        return cached

    # Fallback: ev_id is a full URL (old-style path)
    if not ev_id.startswith('http'):
        xbmc.log('[Starfleet/Sports] onhockey.tv no streams cached for %s' % ev_id, xbmc.LOGINFO)
        return []

    try:
        html = _sess().get(ev_id, timeout=12,
                           headers=dict(_HEADERS, Referer=ONHOCKEY_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] onhockey.tv stream page error (%s): %s' % (ev_id, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen_urls = set()

    for m in _RE_ONHOCKEY_WATCH.finditer(html):
        su    = m.group(1).strip()
        label = _clean(m.group(2)) or 'OnHockey Stream'
        if su and su not in seen_urls:
            streams.append({'label': label, 'url': su,
                            'quality': '', 'language': '', 'source': 'OnHockey.tv'})
            seen_urls.add(su)

    for m in _RE_ONHOCKEY_NUMBERED.finditer(html):
        su = m.group(1).strip()
        if su and su not in seen_urls:
            streams.append({'label': 'OnHockey Stream', 'url': su,
                            'quality': '', 'language': '', 'source': 'OnHockey.tv'})
            seen_urls.add(su)

    if not streams:
        streams = _extract_stream_links(html, 'onhockey.tv', 'OnHockey.tv')

    xbmc.log('[Starfleet/Sports] onhockey.tv streams for %s: %d' % (ev_id, len(streams)), xbmc.LOGINFO)
    return streams


def _onhockey_streams_by_title(event_title):
    """Cross-reference: find onhockey.tv game by title match and scrape its streams."""
    evs = _onhockey_events()
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _onhockey_streams(best_path)


# ── Public stream API ─────────────────────────────────────────────────────────

def get_event_streams(event_path, event_id='', sport_slug='', title=''):
    """
    Fetch stream links for a specific event.
    Merges ISE streams + Roxiestreams + StreamsEast + MethStreams
    + MLB24/NHL24/NFL24/NBA24 + TotalSportek24 + OnHockey.tv.
    Returns list of: {'label', 'url', 'quality', 'language', 'source'}
    """
    ck = ('sports_streams_%s' % event_id) if event_id else None
    if ck:
        cached = _cache.get(ck)
        if cached is not None:
            return cached

    streams = []

    # Determine event path source by prefix
    is_seast_path    = event_path and event_path.startswith('streamseast:')
    is_meth_path     = event_path and event_path.startswith('meth:')
    is_tstek_path    = event_path and event_path.startswith('tstek:')
    is_onhockey_path = event_path and event_path.startswith('onhockey:')
    is_ise_path      = (event_path and not is_seast_path and not is_meth_path
                        and not is_tstek_path and not is_onhockey_path)

    # Build parallel fetch tasks
    futures = {}
    ex = ThreadPoolExecutor(max_workers=10)
    try:
        if is_ise_path:
            futures['ise']        = ex.submit(_ise_event_streams, event_path, event_id)
        if is_seast_path:
            futures['seast']      = ex.submit(_seast_event_streams, event_path)
        # MethStreams event pages are JS-rendered — no playable URL in HTML, skip as stream source
        if is_tstek_path:
            futures['tstek']      = ex.submit(_tstek_streams, event_path)
        if is_onhockey_path:
            futures['onhockey']   = ex.submit(_onhockey_streams, event_path)
        if sport_slug:
            futures['roxie']      = ex.submit(_roxie_streams, sport_slug, title)
            if not is_seast_path and sport_slug in _SEAST_SLUGS:
                futures['seast_slug'] = ex.submit(_seast_event_streams_by_slug, sport_slug, title)
            # meth_x removed: MethStreams event pages are JS-rendered, no playable stream URL
        if sport_slug == 'nhl' and not is_onhockey_path:
            futures['onhockey_x'] = ex.submit(_onhockey_streams_by_title, title)
        if sport_slug in _TSTEK_SLUGS and not is_tstek_path:
            futures['tstek_x']    = ex.submit(_tstek_streams_by_title, sport_slug, title)

        for name, fut in futures.items():
            try:
                result = fut.result(timeout=12)
                if result:
                    streams += result
            except Exception as e:
                xbmc.log('[Starfleet/Sports] stream source error (%s): %s' % (name, e), xbmc.LOGWARNING)
    finally:
        ex.shutdown(wait=False)

    if ck:
        ttl = 5 * 60 if streams else 2 * 60
        _cache.set(ck, streams, ttl)

    xbmc.log('[Starfleet/Sports] event streams (%s/%s): %d total' % (sport_slug, event_id, len(streams)), xbmc.LOGINFO)
    return streams


def _seast_event_streams_by_slug(sport_slug, event_title):
    """
    Supplementary: fetch StreamsEast schedule for the sport, find matching event, get streams.
    Used when the event did NOT come from StreamsEast.
    """
    try:
        seast_evs = _seast_events(sport_slug)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] seast_event_streams_by_slug error: %s' % e, xbmc.LOGWARNING)
        return []

    best_path  = None
    best_score = 0
    for ev in seast_evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']

    if not best_path or best_score < 2:
        return []

    return _seast_event_streams(best_path)


