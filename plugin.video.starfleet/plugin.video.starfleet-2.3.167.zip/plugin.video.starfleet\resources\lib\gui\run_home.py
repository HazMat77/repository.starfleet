"""
Starfleet Home GUI launcher.
Opens the home window immediately with cached data, then refreshes in the background.
"""
import sys
import os
import json
import threading
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon


def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)

    data_dir  = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(data_dir, exist_ok=True)
    data_file    = os.path.join(data_dir, 'home_data.json')
    version_file = os.path.join(data_dir, 'last_version.txt')
    current_ver  = addon.getAddonInfo('version')

    # Prevent multiple home windows from opening simultaneously.
    # run_home.py is called via RunScript (separate Python process per call), so we
    # use an atomic file lock: O_CREAT|O_EXCL succeeds for exactly one process.
    import time as _time
    window_lock = os.path.join(data_dir, 'window.lock')
    _got_lock = False
    try:
        fd = os.open(window_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
        _got_lock = True
    except FileExistsError:
        try:
            age = _time.time() - os.path.getmtime(window_lock)
            if age < 30:
                xbmc.log('[Starfleet/Home] window already open, skipping', xbmc.LOGINFO)
                return
            # Stale lock — steal it
            os.remove(window_lock)
            fd = os.open(window_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            _got_lock = True
        except Exception:
            xbmc.log('[Starfleet/Home] window already open, skipping', xbmc.LOGINFO)
            return
    except Exception:
        _got_lock = True  # can't create lock — proceed anyway

    empty    = [[], [], [], []]
    contexts = {'default': empty, 'movies': empty, 'tv': empty,
                'sports': empty, 'live': empty, 'adult': empty}

    # Check whether this is a first run / update
    try:
        with open(version_file, 'r') as _f:
            saved_ver = _f.read().strip()
    except Exception:
        saved_ver = ''
    is_new_version = (saved_ver != current_ver)

    # Only one instance should run the heavy refresh at a time.
    # Kodi widget loading can invoke run_home.py 2-3 times simultaneously on startup;
    # on low-RAM devices (FireStick) multiple parallel TMDB+ADE fetches cause freezes.
    lock_file = os.path.join(data_dir, 'refresh.lock')
    refresh_done   = threading.Event()
    refresh_result = [None]

    def _acquire_lock():
        """Return True if this instance gets the refresh lock."""
        try:
            import time as _time
            # Stale lock older than 90s is safe to take over
            if os.path.exists(lock_file):
                age = _time.time() - os.path.getmtime(lock_file)
                if age < 90:
                    return False
            with open(lock_file, 'w') as _lf:
                _lf.write(str(os.getpid()))
            return True
        except Exception:
            return True  # if lock fails, proceed anyway

    def _release_lock():
        try:
            os.remove(lock_file)
        except Exception:
            pass

    got_lock = _acquire_lock()

    def _refresh():
        try:
            from resources.lib import afdb_router as _ar
            _ctx = _ar.get_home_carousel_data()
            refresh_result[0] = _ctx
            _tmp = data_file + '.tmp'
            with open(_tmp, 'w', encoding='utf-8') as _f:
                json.dump(_ctx, _f)
            os.replace(_tmp, data_file)
            _d = _ctx.get('default', empty)
            xbmc.log('[Starfleet/Home] background refresh done: %d/%d/%d/%d' % (
                len(_d[0]), len(_d[1]), len(_d[2]), len(_d[3]) if len(_d) > 3 else 0), xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log('[Starfleet/Home] background refresh error: %s' % _e, xbmc.LOGWARNING)
        finally:
            _release_lock()
            refresh_done.set()

    if got_lock:
        t = threading.Thread(target=_refresh, daemon=True)
        t.start()
    else:
        # Another instance is refreshing — just signal done so splash/window don't wait
        xbmc.log('[Starfleet/Home] refresh lock held by another instance, skipping', xbmc.LOGINFO)
        refresh_done.set()

    if is_new_version:
        # On first run / update, write version immediately and open home with
        # whatever cache exists (or empty). Background refresh pushes data when ready.
        try:
            with open(version_file, 'w') as _f:
                _f.write(current_ver)
        except Exception:
            pass

    if True:  # shared cache-load block for both new and existing versions
        # Normal launch — load from cache instantly so the window is non-empty
        try:
            with open(data_file, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            if isinstance(raw, list):
                contexts['default'] = raw
                contexts['movies']  = raw
                contexts['tv']      = raw
            else:
                for k, v in raw.items():
                    contexts[k] = v
            d = contexts.get('default', empty)
            xbmc.log('[Starfleet/Home] loaded %d/%d/%d/%d films from cache' % (
                len(d[0]), len(d[1]), len(d[2]), len(d[3]) if len(d) > 3 else 0), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Home] no cache yet (%s)' % e, xbmc.LOGINFO)

        # If cache is empty, wait for the background refresh to finish before
        # opening the window — otherwise the home screen shows empty carousels.
        d = contexts.get('default', empty)
        if not any(row for row in d if row):
            xbmc.log('[Starfleet/Home] cache empty — waiting for background refresh', xbmc.LOGINFO)
            refresh_done.wait(timeout=45)
            if refresh_result[0] is not None:
                contexts = refresh_result[0]

    # If refresh finished during the splash, use the fresh data right away
    if refresh_result[0] is not None:
        contexts = refresh_result[0]

    try:
        from resources.lib.gui.home import HomeWindow
        win = HomeWindow('Starfleet-Home.xml', addon_path, 'Default', '1080i',
                         contexts=contexts)

        # If refresh is still running, push data into window when it finishes.
        # _window_closed is set as soon as doModal() returns so _push_when_ready
        # exits within 1 s instead of blocking the CPythonInvoker for up to 120 s.
        _window_closed = threading.Event()

        def _push_when_ready():
            # Poll in 1-second increments so we can bail the moment the window closes.
            for _ in range(120):
                if _window_closed.is_set():
                    return
                if refresh_done.wait(timeout=1):
                    break
            if _window_closed.is_set():
                return
            if refresh_result[0] is not None:
                try:
                    win._contexts = refresh_result[0]
                    win._apply_context(win._current_ctx)
                    xbmc.log('[Starfleet/Home] pushed fresh data to live window', xbmc.LOGINFO)
                except Exception as _pe:
                    xbmc.log('[Starfleet/Home] push error: %s' % _pe, xbmc.LOGWARNING)
            try:
                win.setProperty('sf_loaded', '1')
            except Exception:
                pass

        if not refresh_done.is_set():
            threading.Thread(target=_push_when_ready, daemon=True).start()
        else:
            try:
                win.setProperty('sf_loaded', '1')
            except Exception:
                pass

        # Wait up to 3 s for any startup modal dialogs (e.g. elementum) to clear.
        # Kodi refuses window activation while a modal dialog is active, which causes
        # doModal() to return immediately and leaves the home screen blank.
        _w = 0
        while _w < 3000 and xbmc.getCondVisibility('System.HasModalDialog'):
            xbmc.sleep(100)
            _w += 100

        win.doModal()
        _window_closed.set()   # signal _push_when_ready to exit immediately
        nav_action = win.pending_nav
        # Navigate to section directly — do NOT call ActivateWindow(Home) first.
        # Calling ActivateWindow(Home) triggers Kodi's widget refresh which requests
        # the plugin root URL, causing run_home.py to re-open the home window in a loop.
        if nav_action and not xbmc.Monitor().abortRequested():
            # Wait for the home window's close animation (150 ms) to finish.
            # ActivateWindow(Videos) is refused while the home window is still
            # registered as a modal dialog.  Without this wait the activation is
            # rejected, window.lock is freed, and Kodi's widget system immediately
            # fires another run_home.py — creating an infinite home-screen loop.
            _w = 0
            while _w < 600 and xbmc.getCondVisibility('System.HasModalDialog'):
                xbmc.sleep(50)
                _w += 50
            # "return" tells Kodi: when the user presses Back past the root of this
            # path, activate the Home window — NOT the plugin root URL. Without it,
            # Back from any section re-requests ?content_type=video which re-opens
            # the home window in a loop.
            xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.starfleet/?action=%s,return)' % nav_action)
        # Remove window lock AFTER dispatching navigation so the widget system
        # cannot spawn a second run_home.py before the Videos window opens.
        try:
            os.remove(window_lock)
        except Exception:
            pass
    except Exception as e:
        try:
            os.remove(window_lock)
        except Exception:
            pass
        xbmc.log('[Starfleet/Home] window error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
