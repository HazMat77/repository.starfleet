﻿# -*- coding: utf-8 -*-
"""
resources/lib/sports_sources.py

Sports live-stream scraper.

Event sources (priority order):
  1. ESPN API          — NFL, NBA, MLB, NHL, CFB, NCAAB, CFL (official logos + scores)
  2. TheSportsDB       — UFC, Boxing, WWE (free tier, API key 3)
  3. istreameast.cx    — fallback / soccer / F1 / anything else (currently dead — fast-fails)
  4. streamseast.is    — supplementary (merged, deduplicated)
  5. methstreams.gs    — supplementary (merged, deduplicated)
  6. totalsportek24.is — multi-sport (soccer/NFL/NBA/NHL/MLB/UFC/boxing/F1/CFB/NCAAB/WWE)
  7. onhockey.tv       — NHL-specific supplementary

Stream sources (merged):
  1. streamseast.is    — iframe chain → embed player
  2. methstreams.gs    — supplementary stream source (JS-rendered, slug cross-ref)
  3. totalsportek24.is — multi-sport stream source
  4. onhockey.tv       — NHL-specific stream source (direct + cross-ref by title)

Also merged in via json_data.py (pre-scraped by a standalone orchestrator on
a dedicated PC, pushed to GitHub — see resources/lib/json_data.py's own
docstring): streameast.json, all24.json, daddylive.json, mut.json (mut.st/
MutStreams — added 2026-07-29, resolved via the same embed.st resolver
crackstreams' own standalone scraper used to use — see below), and
sportsbite.json (sportsbite.org — added 2026-07-29; its real backend is a
separate domain, api.watchfooty.st, found live by watching the page's own
network traffic; each match offers both a dead 'hd' source — chains to the
same WASM-blocked embedindia.st below — and a working 'delta' source).

Removed (dead as of 2026):
  - CrackStreams (all mirrors: mx, biz, app, crack.sx — all dead) — live
    in-addon scraping removed first, then its standalone-scraper JSON path
    (crackstreams.json via json_data.py) removed too 2026-08-02: confirmed
    live its current player mechanism pushes video through an opaque blob:
    URL with no plain, network-sniffable .m3u8 request at all (same
    obfuscation pattern as the daddylive adult-channels dead end) — the
    standalone scraper's own resolver could no longer capture anything
    real, confirmed by a live run producing zero events across every
    category.
  - roxiestreams.info (both the live _roxie_streams() scrape here and a
    2026-08-02 standalone-scraper attempt) — confirmed live its m3u8 CDN
    (a formaturamaxi.com.br host) sits behind genuine Cloudflare
    bot-protection that 403s every non-browser client tried (plain
    requests, cloudscraper), independently confirmed to also fail
    real Kodi playback — every link this site produces was found but
    never actually playable.
  - TotalSportek original (totalsportek.to/.com/.2 — all unreachable)
  - ppv.land / ppv.to (Cloudflare blocks plain requests, removed per user
    request). Also investigated: ppv.st/.cx/.is/.lc (all 4 domains are one
    shared backend/frontend) — real event data, but every embed goes
    through embedindia.st's own WASM anti-bot challenge that headless
    Chromium never gets past (confirmed live: zero stream requests ever
    fire) — not wired in anywhere, same class of dead end.
  - Sportsurge (dead code — _SPORTSURGE_BASES undefined, never called)
  - JustWatch Sports (dead code — never called)

Cache: event list 10 min (live data), stream list 5 min
"""

import re
import os
import datetime
import time
import xbmc
import xbmcaddon
import xbmcvfs
from concurrent.futures import ThreadPoolExecutor, as_completed

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

ISE_BASE        = 'https://istreameast.cx'   # dead — fast-fails, kept for path routing
CRACK_BASE      = 'https://crackstreams.mx'
_CRACK_MIRRORS  = ['https://crackstreams.mx', 'https://crackstreams.biz',
                   'https://crackstreams.app', 'https://crack.sx']
METH_BASE       = 'https://methstreams.gs'
ROXIE_BASE      = 'https://roxiestreams.info'
SEAST_BASE      = 'https://streameasti.is'   # streamseast.is is dead (connect timeout) — site moved here
TSTEK_BASE      = 'https://totalsportek24.is'
ONHOCKEY_BASE   = 'https://onhockey.tv'

_session = None

# Set to True to use HTTP session. However it seems that timeout is sometimes ignored when session are used
#  so it is currently set to False
_use_session = False

def _sess():
    global _session, _use_session
    if _use_session:
        if _session is None:
            _session = _req.Session()
            _session.headers.update(_HEADERS)
            a = _req.adapters.HTTPAdapter(
                pool_connections=2, pool_maxsize=6,
                max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5, redirect=False)
            )
            _session.mount('https://', a)
        return _session
    else:
        return _req


_cf_session = None

def _cf_sess():
    """Return a Cloudflare-bypass session: cloudscraper if available, else plain requests."""
    global _cf_session
    if _cf_session is None:
        # 1. Try cloudscraper (pip install cloudscraper — works on most platforms)
        try:
            import cloudscraper as _cs
            _cf_session = _cs.create_scraper(
                browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
            )
            _cf_session.headers.update(_HEADERS)
            xbmc.log('[Starfleet/Sports] CF bypass: cloudscraper OK', xbmc.LOGINFO)
            return _cf_session
        except Exception:
            pass
        xbmc.log('[Starfleet/Sports] CF bypass unavailable, using plain session', xbmc.LOGWARNING)
        _cf_session = _sess()
    return _cf_session


def _get(url, timeout=12):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _get_json(url, timeout=10):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


_TSDB_BASE = 'https://www.thesportsdb.com/api/v1/json/3'


def get_venue_image(venue_id='', team_name=''):
    """
    Venue thumbnail/fanart for an event's backdrop, via TheSportsDB —
    verified live end-to-end: lookupvenue.php?id=<venue_id> when a venue id
    is already known (TSDB-sourced events carry idVenue directly); when it
    isn't (MLB/NBA/NHL's own "official" schedules only give a bare venue
    name string, not an id), falls back to searchteams.php?t=<team_name> to
    get that team's own idVenue, then the same venue lookup — TheSportsDB
    doesn't expose venue search by name on the free tier (confirmed empty
    response live), but every team record carries its home venue's id, so
    looking up by the home team's name works as a reliable equivalent.
    Cached 30 days since venue data is effectively static.
    """
    ck = 'tsdb_venue_%s_%s' % (venue_id, re.sub(r'[^a-z0-9]', '_', team_name.lower())[:60])
    cached = _cache.get(ck)
    if cached is not None:
        return cached or {}

    try:
        import urllib.parse as _up5
        vid = venue_id
        if not vid and team_name:
            data = _get_json('%s/searchteams.php?t=%s' % (_TSDB_BASE, _up5.quote(team_name)), timeout=8)
            teams = data.get('teams') or []
            vid = teams[0].get('idVenue', '') if teams else ''
        if not vid:
            _cache.set(ck, False, 7 * 24 * 3600)
            return {}

        vdata = _get_json('%s/lookupvenue.php?id=%s' % (_TSDB_BASE, vid), timeout=8)
        venues = vdata.get('venues') or []
        if not venues:
            _cache.set(ck, False, 7 * 24 * 3600)
            return {}

        v = venues[0]
        result = {'thumb': v.get('strThumb', ''), 'fanart': v.get('strFanart1') or v.get('strThumb', '')}
        if not result['thumb'] and not result['fanart']:
            _cache.set(ck, False, 7 * 24 * 3600)
            return {}
        _cache.set(ck, result, 30 * 24 * 3600)
        return result
    except Exception as e:
        xbmc.log('[Starfleet/Sports] get_venue_image(venue_id=%r, team_name=%r): %s'
                  % (venue_id, team_name, e), xbmc.LOGWARNING)
        return {}


_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()


def _ts_to_dt(date_str):
    """Parse ISO 8601 UTC date string to (unix_timestamp, display_string). Returns (0, '') on failure."""
    if not date_str:
        return 0, ''
    try:
        # Normalise: strip timezone marker and fractional seconds
        clean = date_str.strip()
        clean = clean.split('.')[0]          # drop .000
        clean = clean.rstrip('Z')            # drop trailing Z
        if '+' in clean:
            clean = clean.split('+')[0]      # drop +00:00
        # Try with seconds (19 chars) then without (16 chars)
        dt = None
        for fmt, n in (('%Y-%m-%dT%H:%M:%S', 19), ('%Y-%m-%dT%H:%M', 16)):
            try:
                dt = datetime.datetime.strptime(clean[:n], fmt)
                break
            except Exception:
                pass
        if dt is None:
            return 0, date_str
        ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
        return ts, dt.strftime('%b %d %H:%M UTC')
    except Exception:
        return 0, date_str


def _us_eastern_offset_seconds(d):
    """UTC offset (seconds) for US Eastern on date `d`, DST-aware via the
    standard 2007+ rule (2nd Sunday in March → 1st Sunday in November)."""
    march1 = datetime.date(d.year, 3, 1)
    dst_start = march1 + datetime.timedelta(days=(6 - march1.weekday()) % 7 + 7)
    nov1 = datetime.date(d.year, 11, 1)
    dst_end = nov1 + datetime.timedelta(days=(6 - nov1.weekday()) % 7)
    return -4 * 3600 if dst_start <= d < dst_end else -5 * 3600


_RE_SCORE = re.compile(r'\b\d+\s*[-:]\s*\d+\b')


def _strip_score(title):
    """Remove live score like '3 - 2' or '1:0' from a match title for cross-source matching."""
    return _RE_WS.sub(' ', _RE_SCORE.sub('', title)).strip(' -')


def _title_score(title_a, title_b):
    """Return number of significant words (len>=3) from title_a that appear in title_b (case-insensitive).
    Uses >=3 so short but meaningful team name words (Sox, Mets, Cubs, Red, etc.) are counted."""
    words_a = [w.lower() for w in re.split(r'\W+', _strip_score(title_a)) if len(w) >= 3]
    b_lower = _strip_score(title_b).lower()
    return sum(1 for w in words_a if w in b_lower)


def _titles_match(title_a, title_b, threshold=2):
    """Return True if at least `threshold` significant words from title_a appear in title_b."""
    return _title_score(title_a, title_b) >= threshold


# ── Sport categories ──────────────────────────────────────────────────────────

# Custom Starfleet-branded league icons (resources/skins/Default/media/sports/)
# — override the generic ESPN/TheSportsDB icon below for whichever slugs have
# one. Resolved to an absolute path (li.setArt()/ListItem accept a local
# filesystem path exactly like a URL — this is a different code path than the
# skin-XML relative "media/x.png" resolution that's confirmed broken
# elsewhere in this addon, so no Window Property workaround is needed here).
# Falls back to the original remote icon if the file is ever missing for any
# reason (e.g. a packaging mistake), so a bad path never blanks out an icon.
_SPORTS_ICON_DIR = os.path.join('resources', 'skins', 'Default', 'media', 'sports')

# Kodi caches every image it renders (Textures13.db) keyed by the exact path
# string, local files included — it does NOT compare file content/mtime, so
# overwriting an icon's PNG bytes at the same path is invisible to Kodi for
# any icon a device already rendered before the update (confirmed live: a
# full icon-set refresh shipped, but only sports the device had never
# browsed before picked up the new art — everything previously viewed kept
# showing the old cached bitmap indefinitely). Bumping this on every real
# icon-set change gives every file a brand-new path Kodi has never cached,
# which is a permanent, self-healing fix — no manual cache-clear step is
# ever needed again for icon updates specifically.
_ICON_SET_VERSION = 2


def _local_sport_icon(filename, fallback_url):
    try:
        addon_path = ADDON.getAddonInfo('path')
        base, ext = os.path.splitext(filename)
        versioned_filename = '%s_v%d%s' % (base, _ICON_SET_VERSION, ext)
        local_path = os.path.join(addon_path, _SPORTS_ICON_DIR, versioned_filename)
        if xbmcvfs.exists(local_path):
            return local_path
    except Exception as e:
        xbmc.log('[Starfleet/Sports] _local_sport_icon(%s): %s' % (filename, e), xbmc.LOGWARNING)
    return fallback_url


# Fallback icons (ESPN CDN / Wikipedia) used when TSDB API is unavailable
_CATEGORIES = [
    {'slug': 'soccer',   'label': 'Soccer',                    'tsdb': 'Soccer',              'icon': _local_sport_icon('soccer.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/fifa.png')},
    {'slug': 'nfl',      'label': 'NFL',                       'tsdb': 'American Football',   'icon': _local_sport_icon('nfl.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nfl.png')},
    {'slug': 'nba',      'label': 'NBA',                       'tsdb': 'Basketball',          'icon': _local_sport_icon('nba.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nba.png')},
    {'slug': 'mlb',      'label': 'MLB',                       'tsdb': 'Baseball',            'icon': _local_sport_icon('mlb.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/mlb.png')},
    {'slug': 'nhl',      'label': 'NHL',                       'tsdb': 'Ice Hockey',          'icon': _local_sport_icon('nhl.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png')},
    {'slug': 'ufc',      'label': 'UFC / MMA',                 'tsdb': 'Mixed Martial Arts',  'icon': _local_sport_icon('ufc.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ufc.png')},
    {'slug': 'boxing',   'label': 'Boxing',                    'tsdb': 'Boxing',              'icon': _local_sport_icon('boxing.png', 'https://www.thesportsdb.com/images/media/sport/thumb/boxing1519439649.jpg')},
    {'slug': 'tennis',   'label': 'Tennis',                    'tsdb': 'Tennis',              'icon': _local_sport_icon('tennis.png', 'https://www.thesportsdb.com/images/media/sport/thumb/asdh2v1548684497.jpg')},
    {'slug': 'rugby',    'label': 'Rugby',                     'tsdb': 'Rugby',               'icon': _local_sport_icon('rugby.png', 'https://www.thesportsdb.com/images/media/sport/thumb/vbki5v1547214439.jpg')},
    {'slug': 'cricket',  'label': 'Cricket',                   'tsdb': 'Cricket',             'icon': _local_sport_icon('cricket.png', 'https://www.thesportsdb.com/images/media/sport/thumb/cricket1519439826.jpg')},
    {'slug': 'f1',       'label': 'Formula 1',                 'tsdb': 'Motorsport',          'icon': _local_sport_icon('f1.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/f1.png')},
    {'slug': 'motogp',   'label': 'MotoGP',                    'tsdb': 'Motorsport',          'icon': _local_sport_icon('motogp.png', 'https://www.thesportsdb.com/images/media/sport/thumb/motorsport.jpg')},
    {'slug': 'golf',     'label': 'Golf',                      'tsdb': 'Golf',                'icon': _local_sport_icon('golf.png', 'https://www.thesportsdb.com/images/media/sport/thumb/golf1519439822.jpg')},
    {'slug': 'darts',    'label': 'Darts',                     'tsdb': 'Darts',               'icon': _local_sport_icon('darts.png', 'https://www.thesportsdb.com/images/media/sport/thumb/darts1519439673.jpg')},
    {'slug': 'snooker',  'label': 'Snooker',                   'tsdb': 'Snooker',             'icon': _local_sport_icon('snooker.png', 'https://www.thesportsdb.com/images/media/sport/thumb/snooker1519439836.jpg')},
    {'slug': 'handball', 'label': 'Handball',                  'tsdb': 'Handball',            'icon': _local_sport_icon('handball.png', 'https://www.thesportsdb.com/images/media/sport/thumb/handball1519439771.jpg')},
    {'slug': 'volleyball','label': 'Volleyball',               'tsdb': 'Volleyball',          'icon': _local_sport_icon('volleyball.png', 'https://www.thesportsdb.com/images/media/sport/thumb/volleyball1519439870.jpg')},
    {'slug': 'cycling',  'label': 'Cycling',                   'tsdb': 'Cycling',             'icon': _local_sport_icon('cycling.png', 'https://www.thesportsdb.com/images/media/sport/thumb/cycling1519439660.jpg')},
    {'slug': 'cfb',      'label': 'College Football (CFB)',     'tsdb': 'American Football',   'icon': _local_sport_icon('cfb.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaaf.png')},
    {'slug': 'ncaab',    'label': 'College Basketball (NCAAB)', 'tsdb': 'Basketball',          'icon': _local_sport_icon('ncaab.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaab.png')},
    {'slug': 'cfl',      'label': 'CFL',                        'tsdb': 'American Football',   'icon': _local_sport_icon('cfl.png', 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/cfl.png')},
    {'slug': 'wwe',      'label': 'WWE / Wrestling',            'tsdb': 'Wrestling',           'icon': _local_sport_icon('wwe.png', 'https://r2.thesportsdb.com/images/media/league/badge/r43xns1461424282.png')},
]

# Map slug → TSDB sport name for calendar lookups
_SLUG_TO_TSDB_SPORT = {c['slug']: c['tsdb'] for c in _CATEGORIES}

_TSDB_BASE       = 'https://www.thesportsdb.com/api/v1/json/3'
_TSDB_SPORTS_API = _TSDB_BASE + '/all_sports.php'
_TSDB_DAY_API    = _TSDB_BASE + '/eventsday.php'


def get_sport_categories():
    """Fetch ALL sports from TheSportsDB (cached 24h), merged with our ESPN-backed known sports.

    Cache key bumped to v4 — v3's cached blob was built with the old
    icon-priority bug still in place (TheSportsDB's own live sport thumbnail
    always won over our curated icon, burying the custom Starfleet-branded
    local icons under a generic stock photo — see the is_local_icon check
    below), so v3 needs one more forced rebuild too, same reasoning as the
    v2->v3 bump above."""
    ck = 'tsdb_sport_cats_v4'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    # Fetch TSDB sport list
    tsdb_sports = []
    try:
        data = _get_json(_TSDB_SPORTS_API, timeout=8)
        tsdb_sports = data.get('sports') or []
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB all_sports: %s' % e, xbmc.LOGWARNING)
    
    # Build lookup: tsdb_name → {icon, id}
    tsdb_by_name = {}
    for s in tsdb_sports:
        name = s.get('strSport', '').strip()
        if name:
            tsdb_by_name[name] = {
                'icon': s.get('strSportThumb', ''),
                'id':   s.get('idSport', ''),
            }
    
    result = []
    seen_tsdb = set()

    # 1. Known slugs first (preserves order + ESPN live-score support).
    # NOTE: several of these intentionally share the same 'tsdb' value
    # (NFL/CFB/CFL are all TheSportsDB's single "American Football" sport,
    # NBA/NCAAB share "Basketball") — that's fine and expected, each is
    # still its own real menu section. seen_tsdb below is ONLY to stop
    # loop 2 (raw TheSportsDB sport list) from adding a redundant generic
    # "American Football"/"Basketball" entry on top of these curated ones —
    # it must NOT skip entries in this curated loop itself. That exact
    # mistake (a bare tsdb_name-seen check gating this loop too) is what
    # silently dropped CFB and CFL from the Sports menu entirely: CFL's
    # own icon/section never appeared, and CFL games ended up folding into
    # whatever + NFL's "American Football" TheSportsDB/ESPN event fetch
    # returned instead, with no way to tell them apart — confirmed live.
    for cat in _CATEGORIES:
        tsdb_name = cat.get('tsdb', '')
        seen_tsdb.add(tsdb_name)
        tsdb_info = tsdb_by_name.get(tsdb_name, {})
        # A local file path (our custom Starfleet-branded icon) always wins
        # over TheSportsDB's own live sport thumbnail — that thumbnail is a
        # generic stock photo for the whole sport (e.g. a random soccer
        # match action shot, not a logo), never something we'd actually
        # want over deliberately-branded art. For every slug that still
        # only has the old generic ESPN/TheSportsDB fallback URL, keep the
        # original behavior of preferring TSDB's own (usually fresher)
        # icon, falling back to ours only when TSDB has none.
        is_local_icon = cat['icon'] and not cat['icon'].startswith('http')
        icon = cat['icon'] if is_local_icon else (tsdb_info.get('icon') or cat['icon'])
        result.append({
            'slug':       cat['slug'],
            'label':      cat['label'],
            'icon':       icon,
            'tsdb_sport': tsdb_name,
        })

    # 2. Remaining TSDB sports not yet in our list
    for s in tsdb_sports:
        name = s.get('strSport', '').strip()
        if not name or name in seen_tsdb:
            continue
        seen_tsdb.add(name)
        slug = re.sub(r'[^a-z0-9]+', '_', name.lower()).strip('_')
        icon = s.get('strSportThumb', '')
        result.append({
            'slug':       slug,
            'label':      name,
            'icon':       icon,
            'tsdb_sport': name,
        })

    if result:
        _cache.set(ck, result, 86400)
    else:
        # Complete fallback: static list only
        result = [
            {'slug': c['slug'], 'label': c['label'], 'icon': c['icon'], 'tsdb_sport': c.get('tsdb', '')}
            for c in _CATEGORIES
        ]
    return result


def _tsdb_calendar_events(tsdb_sport, date_str, max_items):
    """Fetch TheSportsDB events for a sport on date_str (YYYY-MM-DD). tsdb_sport is the TSDB sport name."""
    if not tsdb_sport:
        return []

    # TheSportsDB's free key ("3" in the URL) is a shared public test key with
    # a low, global rate limit — confirmed live: every non-big-4 sport (which
    # has no other official-API source and depends entirely on this call, 7x
    # per category for a week of dates) was getting 429 Too Many Requests on
    # every single date, every time, meaning these categories silently got 0
    # results from their primary source and fell back to weaker/dateless
    # supplementary scrapers. This had no caching at all, so browsing a
    # handful of niche sports back-to-back (exactly how this was found) kept
    # re-hitting the same throttled endpoint. Caching per (sport, date) cuts
    # our own repeat-request volume within a session/short window.
    ck = 'tsdb_cal_%s_%s' % (tsdb_sport, date_str)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        import urllib.parse as _urlparse
        url = '%s?d=%s&s=%s' % (_TSDB_DAY_API, date_str, _urlparse.quote(tsdb_sport))
        data = _get_json(url, timeout=8)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB calendar (%s %s): %s' % (tsdb_sport, date_str, e), xbmc.LOGWARNING)
        # Short negative-cache so a 429 doesn't get re-hit seconds later by
        # the next category browsed in the same session — but short enough
        # to recover quickly once the shared key's rate limit window passes.
        _cache.set(ck, [], 2 * 60)
        return []

    events = []
    for ev in (data.get('events') or []):
        try:
            date_ev   = ev.get('dateEvent', '') or ''
            time_ev   = (ev.get('strTime') or '00:00:00')[:8]
            timestamp = ev.get('strTimestamp', '') or ''
            ts, dt_str = 0, ''
            if timestamp:
                ts_raw = timestamp.replace(' ', 'T') if 'T' not in timestamp else timestamp
                ts, dt_str = _ts_to_dt(ts_raw)
            if not ts and date_ev:
                try:
                    dt = datetime.datetime.strptime('%s %s' % (date_ev, time_ev), '%Y-%m-%d %H:%M:%S')
                    ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
                    dt_str = dt.strftime('%b %d %H:%M UTC')
                except Exception:
                    # Still show a date if we at least have one, even without a time
                    try:
                        dt = datetime.datetime.strptime(date_ev, '%Y-%m-%d')
                        ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
                        dt_str = dt.strftime('%b %d')
                    except Exception:
                        ts, dt_str = 0, date_ev
        except Exception:
            # One malformed record must not sink the rest of this day's events
            ts, dt_str, date_ev = 0, '', ev.get('dateEvent', '') or ''

        home  = ev.get('strHomeTeam', '')
        away  = ev.get('strAwayTeam', '')
        title = ('%s vs %s' % (home, away)) if (home and away) else ev.get('strEvent', '')
        logo  = (ev.get('strHomeTeamBadge') or ev.get('strThumb') or ev.get('strBanner') or '')

        events.append({
            'id':          str(ev.get('idEvent', '')),
            'slug':        str(ev.get('idEvent', '')),
            'path':        '',
            'title':       title,
            'match_title': title,
            'datetime':    dt_str,
            'league':      ev.get('strLeague', tsdb_sport),
            'logo':        logo,
            'home_badge':  ev.get('strHomeTeamBadge', ''),
            'away_badge':  ev.get('strAwayTeamBadge', ''),
            'is_live':     False,
            'start_ts':    ts,
            'venue':       ev.get('strVenue', ''),
            'venue_id':    str(ev.get('idVenue', '') or ''),
            'home_team':   ev.get('strHomeTeam', ''),
        })
        if len(events) >= max_items:
            break
    _cache.set(ck, events, 15 * 60)
    return events


def get_onhockey_events():
    """Return all onhockey.tv events with their league field populated."""
    return _onhockey_events()


# ── ESPN API ──────────────────────────────────────────────────────────────────

_ESPN_SPORTS = {
    'nfl':   ('football',   'nfl'),
    'nba':   ('basketball', 'nba'),
    'mlb':   ('baseball',   'mlb'),
    'nhl':   ('hockey',     'nhl'),
    'cfb':   ('football',   'college-football'),
    'ncaab': ('basketball', 'mens-college-basketball'),
    'cfl':   ('football',   'cfl'),
    'soccer': ('soccer',   'fifa.world'),   # FIFA World Cup 2026 (Jun–Jul 2026)
}
# Additional soccer leagues polled after the primary
_ESPN_SOCCER_EXTRA = ['eng.1', 'usa.1', 'uefa.champions', 'uefa.europa']
_ESPN_API = 'https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard'

# Groups of our sport slugs that all resolve to the SAME single TheSportsDB
# sport calendar (no separate TSDB sport exists per league) — used to strip
# out other leagues' games from TSDB-sourced events once merged in per
# sport_slug (see get_sport_events). NFL/CFB/CFL share "American Football"
# (confirmed live: CFL and European League of Football games leaked
# straight into NFL with no way to tell them apart). NBA/NCAAB share
# "Basketball" and F1/MotoGP share "Motorsport" the exact same way —
# confirmed live (NCAAB was showing random Australian NBL1/Canadian CEBL
# games) but never had an equivalent filter until now.
_AMFOOTBALL_LEAGUE_KEYWORDS = {
    'nfl':    ('nfl',),
    'cfl':    ('cfl',),
    'cfb':    ('ncaa', 'college'),
    'nba':    ('nba',),
    'ncaab':  ('ncaa', 'college'),
    'f1':     ('formula 1', 'f1', 'grand prix'),
    'motogp': ('motogp', 'moto2', 'moto3'),
}


def _espn_events(sport_slug, max_items):
    if sport_slug not in _ESPN_SPORTS:
        return []
    sport, league = _ESPN_SPORTS[sport_slug]
    url = _ESPN_API.format(sport=sport, league=league)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ESPN API (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in data.get('events', []):
        state   = ev.get('status', {}).get('type', {}).get('state', 'pre')
        is_live = (state == 'in')

        comp        = (ev.get('competitions') or [{}])[0]
        competitors = comp.get('competitors', [])
        venue       = comp.get('venue', {}).get('fullName', '')

        match_title = ev.get('name', ev.get('shortName', ''))
        if len(competitors) >= 2:
            teams  = [c.get('team', {}).get('displayName', '') for c in competitors]
            scores = [c.get('score', '') for c in competitors]
            match_title = ' vs '.join(teams)
            title_str   = match_title
            if is_live and all(scores):
                title_str = '%s %s - %s %s' % (teams[0], scores[0], scores[1], teams[1])
        else:
            title_str = match_title

        logo = ''
        if competitors:
            logo = competitors[0].get('team', {}).get('logo', '')

        start_ts, datetime_str = _ts_to_dt(ev.get('date', ''))

        events.append({
            'id':          ev.get('id', ''),
            'slug':        ev.get('id', ''),
            'path':        '',
            'title':       title_str,
            'match_title': match_title,
            'datetime':    datetime_str,
            'league':      sport_slug.upper(),
            'logo':        logo,
            'is_live':     is_live,
            'start_ts':    start_ts,
            'venue':       venue,
        })
        if len(events) >= max_items:
            break

    return events


# ── TheSportsDB (UFC / Boxing / WWE) ─────────────────────────────────────────

_TSDB_LEAGUES = {
    'ufc':    '4407',
    'boxing': '4414',
    'wwe':    '4412',
}
_TSDB_NEXT = 'https://www.thesportsdb.com/api/v1/json/3/eventsnextleague.php'


def _tsdb_events(sport_slug):
    league_id = _TSDB_LEAGUES.get(sport_slug)
    if not league_id:
        return []
    url = '%s?id=%s' % (_TSDB_NEXT, league_id)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in (data.get('events') or []):
        date_str = ev.get('dateEvent', '') or ''
        time_str = (ev.get('strTime') or '00:00:00')[:8]
        try:
            dt = datetime.datetime.strptime('%s %s' % (date_str, time_str), '%Y-%m-%d %H:%M:%S')
            start_ts  = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
            datetime_str = dt.strftime('%b %d %H:%M')
        except Exception:
            # Still show a date if we at least have one, even without a time
            try:
                dt = datetime.datetime.strptime(date_str, '%Y-%m-%d')
                start_ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
                datetime_str = dt.strftime('%b %d')
            except Exception:
                start_ts, datetime_str = 0, date_str

        title_str = ev.get('strEvent', ev.get('strFilename', ''))
        logo = ev.get('strThumb', '') or ev.get('strBanner', '') or ''

        events.append({
            'id':       str(ev.get('idEvent', '')),
            'slug':     str(ev.get('idEvent', '')),
            'path':     '',
            'title':    title_str,
            'datetime': datetime_str,
            'league':   ev.get('strLeague', sport_slug.upper()),
            'logo':     logo,
            'is_live':  False,
            'start_ts': start_ts,
        })

    return events


# ── istreameast.cx events (fallback) ─────────────────────────────────────────

_RE_ISE_CARD = re.compile(
    r'class="event-card"[^>]*onclick="window\.location\.href=[^\']*\'(/links/([^\']+))\''
    r'[^>]*data-event-id="(\d+)"[^>]*data-start-ts="(\d+)"',
    re.IGNORECASE | re.DOTALL
)
_RE_ISE_LOGO = re.compile(
    r'<img[^>]+src="(https://[^"]+thesportsdb[^"]+|https://[^"]+espncdn[^"]+)"[^>]*alt="([^"]*)"',
    re.IGNORECASE
)
_RE_ISE_TITLE    = re.compile(r'class="event-title"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_DATETIME = re.compile(r'class="event-datetime"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_LEAGUE   = re.compile(r'class="event-league"\s*>(.*?)</div>', re.IGNORECASE | re.DOTALL)
_RE_ISE_STATUS   = re.compile(r'class="event-status\s+([^"]+)"\s*>(.*?)</span>', re.IGNORECASE)


def _parse_ise_block(block):
    m_title = _RE_ISE_TITLE.search(block)
    m_dt    = _RE_ISE_DATETIME.search(block)
    m_lg    = _RE_ISE_LEAGUE.search(block)
    m_st    = _RE_ISE_STATUS.search(block)
    m_logo  = _RE_ISE_LOGO.search(block)

    title    = _clean(m_title.group(1)) if m_title else ''
    dt_str   = _clean(m_dt.group(1))   if m_dt    else ''
    league   = _clean(_RE_STRIP.sub(' ', m_lg.group(1))) if m_lg else ''
    league   = re.sub(r'\s+\d+\s+(?:hours?|minutes?)\s+from\s+now.*', '', league, flags=re.IGNORECASE).strip()
    status_class = m_st.group(1).strip() if m_st else 'upcoming'
    is_live  = 'live' in status_class.lower()
    logo_url = m_logo.group(1) if m_logo else ''
    return title, dt_str, league, logo_url, is_live


def _ise_events(sport_slug):
    url = ISE_BASE + '/schedule/%s' % sport_slug
    on_homepage_fallback = False
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE schedule error (%s): %s' % (sport_slug, e), xbmc.LOGERROR)
        try:
            html = _get(ISE_BASE + '/')
            on_homepage_fallback = True
        except Exception:
            return []

    events = []
    seen   = set()

    for m in _RE_ISE_CARD.finditer(html):
        path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
        if event_id in seen:
            continue
        seen.add(event_id)
        block = html[m.end():m.end() + 900]
        title, dt_str, league, logo_url, is_live = _parse_ise_block(block)

        _soccer_words = ('football', 'soccer', 'fifa', 'premier', 'champions', 'mls', 'laliga', 'bundesliga', 'serie')
        if sport_slug == 'soccer':
            if league and not any(w in league.lower() for w in _soccer_words):
                continue
        elif sport_slug != 'nfl' and league and sport_slug.lower() not in league.lower():
            continue
        # The homepage fallback shows whatever's generically prominent on the
        # site (usually MLB), not anything scoped to sport_slug at all —
        # confirmed live: niche sports with no better source (snooker,
        # handball) were all showing the SAME leaked MLB games, because the
        # league-mismatch check above only rejects an event when `league` is
        # actually present, and homepage cards frequently parse with no
        # league at all. On this fallback specifically, require a positive
        # league match instead of just "not a mismatch" — no match, no keep.
        elif on_homepage_fallback:
            if sport_slug == 'soccer':
                if not (league and any(w in league.lower() for w in _soccer_words)):
                    continue
            elif not (league and sport_slug.lower() in league.lower()):
                continue

        events.append({
            'id':       event_id,
            'slug':     slug,
            'path':     path,
            'title':    title or slug.replace('-', ' ').title(),
            'datetime': dt_str,
            'league':   league,
            'logo':     logo_url,
            'is_live':  is_live,
            'start_ts': int(start_ts_str),
        })

    return events


# ── streamseast.cx events (supplementary) ────────────────────────────────────

_SEAST_SLUGS = {
    # site's own nav section slugs (confirmed against streameasti.is directly —
    # irregular pluralization, not a simple "+s" rule)
    'nfl': 'nfls', 'nba': 'nba', 'mlb': 'mlbs', 'nhl': 'nhl',
    'ufc': 'mma', 'boxing': 'boxing', 'soccer': 'soccers',
    'cfb': 'cfb', 'cfl': 'cfls', 'ncaab': 'ncaab', 'wwe': 'wwes',
}

# streameasti.is (formerly streamseast.is, which is now dead — connect
# timeout) uses /section/team-vs-team links — no numeric event id anymore.
_RE_SEAST_CARD = re.compile(
    r'href=["\'](/(?:nfls|nba|mlbs|nhl|mma|boxing|soccers|cfb|cfls|ncaab|wwes)/'
    r'([^"\'#\s/]+))["\']',
    re.IGNORECASE
)

# Game page embeds up to N alternate sources as "source-btn" buttons, each
# with a base64-encoded URL in a data-s attribute, activated by an onclick
# JS function that swaps the player iframe's src. The iframe's OWN src
# attribute is left empty until a button is clicked, so plain
# <iframe src="..."> scraping (the old approach) finds nothing — must read
# data-s off the source-btn elements specifically (the same data-s value is
# also duplicated onto the initial iframe tag itself for the default
# source, which has no "source-btn" class and must NOT be matched here to
# avoid a blank-labeled duplicate).
_RE_SEAST_SOURCE_BTN = re.compile(
    r'source-btn[^>]*data-s=["\']([A-Za-z0-9+/=]+)["\'][^>]*>\s*([^<]{1,40})',
    re.IGNORECASE
)


def _seast_events(sport_slug, max_items=20):
    slug = _SEAST_SLUGS.get(sport_slug)
    if not slug:
        return []
    url = SEAST_BASE + '/%s' % slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast schedule error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()

    _iter_cards = _RE_SEAST_CARD.finditer(html)
    for m in _iter_cards:
        path, ev_slug = m.group(1), m.group(2)
        if ev_slug in seen:
            continue
        seen.add(ev_slug)
        # Title from slug: "red-sox-vs-angels" → "Red Sox Vs Angels"
        title = ev_slug.replace('-', ' ').title()
        # Try to get live/score indicator from context. Widened from 300 to
        # 600 chars — confirmed live the card's own data-ts attribute (see
        # below) sits ~393 chars after the href on a real card, past the
        # old 300-char window entirely; 600 stays well short of bleeding
        # into the NEXT card's own data-ts (~840+ chars away).
        ctx = html[max(0, html.find(path) - 50):html.find(path) + 600]
        is_live = bool(re.search(r'(?:live|LIVE|in\s+progress|Top\s+\d|Bottom\s+\d|End\s+\d)', ctx))
        # Confirmed live: every match-row card carries a real start time via
        # <span class="badge ..." data-ts="1785796800">--</span> right after
        # the title — the page's own JS re-renders that span's text/class
        # client-side based on elapsed time (upcoming countdown -> "LIVE" ->
        # hidden), but the raw data-ts is always present server-side
        # regardless of live state. Was never captured at all before —
        # every StreamsEast event showed no date/time as a result.
        ts_m = re.search(r'data-ts=["\'](\d+)["\']', ctx)
        start_ts = int(ts_m.group(1)) if ts_m else 0
        events.append({
            'id':       'seast_' + ev_slug,
            'slug':     ev_slug,
            'path':     'streamseast:' + path,
            'title':    title,
            'match_title': title,
            'datetime': '',
            'league':   slug.upper(),
            'logo':     '',
            'is_live':  is_live,
            'start_ts': start_ts,
        })
        if len(events) >= max_items:
            break

    xbmc.log('[Starfleet/Sports] StreamsEast %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _seast_event_streams(event_path):
    """Fetch streamseast.is event page, follow iframe chain to get embeds/m3u8."""
    path = event_path.replace('streamseast:', '')
    url  = SEAST_BASE + path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=SEAST_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen    = set()
    from urllib.parse import urlparse as _up_seast

    _M3U8_PAT = re.compile(
        r'["\']?(https?://[^\s"\'<>{},\)]+\.m3u8[^\s"\'<>{},\)]*)["\']?', re.I)

    def _collect_m3u8(page_html, label='StreamsEast HD'):
        for m3 in _M3U8_PAT.finditer(page_html):
            u = m3.group(1)
            if u not in seen:
                seen.add(u)
                streams.append({'label': label, 'url': u, 'quality': 'HD',
                                'language': '', 'source': 'StreamsEast'})

    # Scan main event page for m3u8
    _collect_m3u8(html)

    # Primary source: "source-btn" elements with data-s (base64-encoded embed
    # URL), swapped into the player iframe by an onclick JS handler — this is
    # the site's actual current mechanism (its iframe's own src is always
    # empty in the raw HTML). These decode to embed pages (e.g.
    # embed.st/embed/...), not raw m3u8 — handed to the stream list as-is;
    # ResolveURL resolves them at play time, same as every other embed-host
    # stream in this addon.
    import base64 as _b64_seast
    _seast_link_n = 0
    for sm in _RE_SEAST_SOURCE_BTN.finditer(html):
        b64 = sm.group(1)
        try:
            pad = '=' * (-len(b64) % 4)
            decoded = _b64_seast.b64decode(b64 + pad).decode('utf-8', 'ignore')
        except Exception:
            continue
        if not decoded.startswith('http') or decoded in seen:
            continue
        seen.add(decoded)
        _seast_link_n += 1
        streams.append({
            'label': 'Link %d' % _seast_link_n,
            'url': decoded,
            'quality': '',
            'language': '',
            'source': 'StreamsEast',
        })

    # Follow iframes up to 2 levels deep to extract m3u8.
    # Do NOT add embed page URLs (e.g. embedindia.st/embed/..., methstreams.gs/) as
    # streams — those pages are JS-rendered and unplayable in Kodi's video player.
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
    for iframe_url in iframes[:4]:
        if not iframe_url.startswith('http'):
            continue
        try:
            _pp = _up_seast(iframe_url)
            if not _pp.path or _pp.path in ('', '/'):
                continue  # skip bare homepage URLs
        except Exception:
            pass
        try:
            iframe_html = _sess().get(iframe_url, timeout=8,
                                      headers=dict(_HEADERS, Referer=url)).text
        except Exception:
            continue
        _collect_m3u8(iframe_html)
        for inner_m in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)["\']', iframe_html, re.I):
            inner_url = inner_m.group(1)
            if not inner_url.startswith('http'):
                continue
            try:
                _p2 = _up_seast(inner_url)
                if not _p2.path or _p2.path in ('', '/'):
                    continue
            except Exception:
                pass
            try:
                inner2_html = _sess().get(inner_url, timeout=8,
                                          headers=dict(_HEADERS, Referer=iframe_url)).text
            except Exception:
                continue
            _collect_m3u8(inner2_html)

    # Fallback: structured stream table (step 1 of _extract_stream_links) — only if
    # no m3u8 found above. This handles sites that serve clean direct-stream URLs in
    # an HTML table (not JS-rendered embed pages).
    if not streams:
        for s in _extract_stream_links(html, 'streamseast.is', 'StreamsEast'):
            u = s['url']
            if u not in seen:
                seen.add(u)
                streams.append(s)

    xbmc.log('[Starfleet/Sports] StreamsEast streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# ── Official league schedule APIs ─────────────────────────────────────────────

_ESPN_LOGO = 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/{league}/500/{abbrev}.png'


def _espn_logo(league, abbrev):
    """Return ESPN CDN PNG logo URL — Kodi can't render SVG."""
    if not abbrev:
        return ''
    return _ESPN_LOGO.format(league=league, abbrev=abbrev.lower().replace(' ', ''))


def _nhl_official_events(max_items):
    """NHL schedule from api-web.nhle.com — returns next ~7 days."""
    today = datetime.date.today().strftime('%Y-%m-%d')
    try:
        data = _get_json('https://api-web.nhle.com/v1/schedule/%s' % today, timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] NHL official: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for week_day in (data.get('gameWeek') or []):
        for gm in (week_day.get('games') or []):
            state   = gm.get('gameState', 'FUT')
            is_live = state in ('LIVE', 'CRIT')
            if state in ('FINAL', 'OFF'):
                continue
            home = gm.get('homeTeam', {})
            away = gm.get('awayTeam', {})
            home_name = ('%s %s' % (home.get('placeName', {}).get('default', ''),
                                    home.get('commonName', {}).get('default', ''))).strip()
            away_name = ('%s %s' % (away.get('placeName', {}).get('default', ''),
                                    away.get('commonName', {}).get('default', ''))).strip()
            match_title = '%s vs %s' % (away_name, home_name)
            title = match_title
            if is_live:
                title = '%s %s - %s %s' % (away_name, away.get('score', 0),
                                            home.get('score', 0), home_name)
            ts, dt_str = _ts_to_dt(gm.get('startTimeUTC', ''))
            home_logo = _espn_logo('nhl', home.get('abbrev', ''))
            away_logo = _espn_logo('nhl', away.get('abbrev', ''))
            events.append({
                'id': str(gm.get('id', '')), 'slug': str(gm.get('id', '')), 'path': '',
                'title': title, 'match_title': match_title, 'datetime': dt_str,
                'league': 'NHL', 'logo': away_logo or home_logo,
                'home_badge': home_logo, 'away_badge': away_logo,
                'is_live': is_live, 'start_ts': ts,
                'venue': gm.get('venue', {}).get('default', ''),
                'home_team': home_name,
            })
            if len(events) >= max_items:
                break
    xbmc.log('[Starfleet/Sports] NHL official: %d events' % len(events), xbmc.LOGINFO)
    return events


def _nba_official_events(max_items):
    """NBA today's scoreboard from cdn.nba.com."""
    try:
        data = _get_json(
            'https://cdn.nba.com/static/json/liveData/scoreboard/todaysScoreboard_00.json',
            timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] NBA official: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for gm in (data.get('scoreboard', {}).get('games') or []):
        status  = gm.get('gameStatus', 1)
        is_live = (status == 2)
        if status == 3:
            continue
        home = gm.get('homeTeam', {})
        away = gm.get('awayTeam', {})
        home_name = ('%s %s' % (home.get('teamCity', ''), home.get('teamName', ''))).strip()
        away_name = ('%s %s' % (away.get('teamCity', ''), away.get('teamName', ''))).strip()
        match_title = '%s vs %s' % (away_name, home_name)
        title = match_title
        if is_live:
            title = '%s %s - %s %s' % (away_name, away.get('score', 0),
                                        home.get('score', 0), home_name)
        ts, dt_str = _ts_to_dt(gm.get('gameDateTimeUTC', ''))
        home_logo = _espn_logo('nba', home.get('teamTricode', ''))
        away_logo = _espn_logo('nba', away.get('teamTricode', ''))
        events.append({
            'id': gm.get('gameId', ''), 'slug': gm.get('gameId', ''), 'path': '',
            'title': title, 'match_title': match_title, 'datetime': dt_str,
            'league': 'NBA', 'logo': away_logo or home_logo,
            'home_badge': home_logo, 'away_badge': away_logo,
            'is_live': is_live, 'start_ts': ts, 'venue': '',
            'home_team': home_name,
        })
        if len(events) >= max_items:
            break
    xbmc.log('[Starfleet/Sports] NBA official: %d events' % len(events), xbmc.LOGINFO)
    return events


def _mlb_official_events(max_items):
    """MLB schedule from statsapi.mlb.com — next 7 days."""
    today    = datetime.date.today()
    end_date = today + datetime.timedelta(days=6)
    url = ('https://statsapi.mlb.com/api/v1/schedule?sportId=1'
           '&startDate=%s&endDate=%s&hydrate=team,linescore'
           % (today.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')))
    try:
        data = _get_json(url, timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] MLB official: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for day in (data.get('dates') or []):
        for gm in (day.get('games') or []):
            abstract = gm.get('status', {}).get('abstractGameState', 'Preview')
            if abstract == 'Final':
                continue
            is_live   = (abstract == 'Live')
            home      = gm.get('teams', {}).get('home', {})
            away      = gm.get('teams', {}).get('away', {})
            home_name = home.get('team', {}).get('name', '')
            away_name = away.get('team', {}).get('name', '')
            match_title = '%s vs %s' % (away_name, home_name)
            title = match_title
            if is_live:
                title = '%s %s - %s %s' % (away_name, away.get('score', 0),
                                            home.get('score', 0), home_name)
            ts, dt_str = _ts_to_dt(gm.get('gameDate', ''))
            home_abbrev = home.get('team', {}).get('abbreviation', '')
            away_abbrev = away.get('team', {}).get('abbreviation', '')
            home_logo = _espn_logo('mlb', away_abbrev)
            away_logo = _espn_logo('mlb', home_abbrev)
            # Always use match_title (no score) as the event title so stream-site
            # title matching works regardless of live score updates.
            # Live score goes into plot so it still appears in the UI.
            plot = ('🔴 %s - %s (LIVE)' % (away.get('score', 0), home.get('score', 0))
                    if is_live else dt_str)
            events.append({
                'id': str(gm.get('gamePk', '')), 'slug': str(gm.get('gamePk', '')), 'path': '',
                'title': match_title, 'match_title': match_title, 'plot': plot, 'datetime': dt_str,
                'league': 'MLB', 'logo': away_logo or home_logo,
                'home_badge': home_logo, 'away_badge': away_logo,
                'is_live': is_live, 'start_ts': ts,
                'venue': gm.get('venue', {}).get('name', ''),
                'home_team': home_name,
            })
            if len(events) >= max_items:
                break
    xbmc.log('[Starfleet/Sports] MLB official: %d events' % len(events), xbmc.LOGINFO)
    return events


def get_todays_sport_events(sport_slug, tsdb_sport='', max_items=20):
    """Return today's events for a sport, formatted for home carousel items."""
    import time as _time
    events = get_sport_events(sport_slug, tsdb_sport=tsdb_sport, max_items=max_items)
    now    = _time.time()
    cutoff = now + 86400  # next 24 hours
    items  = []
    for ev in events:
        ts = ev.get('start_ts', 0)
        if not ev.get('is_live') and ts and ts > cutoff:
            continue  # skip games more than 24h away
        logo  = ev.get('home_badge') or ev.get('logo') or ''
        fanart = ev.get('away_badge') or logo
        # For live games, title includes score ("Team A 2 - 1 Team B") which breaks
        # scraper title-matching. Use match_title ("Team A vs Team B") instead.
        display_title = ev.get('match_title') or ev.get('title', '')
        items.append({
            'id':          ev.get('id', ''),
            'title':       display_title,
            'thumb':       logo,
            'fanart':      fanart,
            'plot':        ev.get('league', '') + (' — 🔴 LIVE' if ev.get('is_live') else ''),
            'source':      'sports',
            'sport_slug':  sport_slug,
            'event_id':    ev.get('id', ''),
            'event_path':  ev.get('path', ''),
            'media_type':  'event',
        })
        if len(items) >= max_items:
            break
    return items


# ── Public event API ──────────────────────────────────────────────────────────

def _merge_events(primary, supplementary):
    """Merge supplementary events into primary, deduplicating by title similarity.
    If a duplicate is found but the primary event has no stream path, copy the
    supplementary event's path so streams are not lost (e.g. official MLB schedule
    events have path='' but streamseast/methstreams events carry the stream path).
    """
    merged = list(primary)
    primary_titles = [e['title'] for e in primary]

    for ev in supplementary:
        duplicate = False
        for i, pt in enumerate(primary_titles):
            if _titles_match(ev['title'], pt, threshold=2):
                duplicate = True
                # If primary has no stream path but supplementary does, copy it over
                if not merged[i].get('path') and ev.get('path'):
                    merged[i] = dict(merged[i])
                    merged[i]['path'] = ev['path']
                break
        if not duplicate:
            merged.append(ev)
            primary_titles.append(ev['title'])

    return merged


def get_sport_events(sport_slug='nfl', tsdb_sport='', max_items=20):
    # tsdb_sport is the TheSportsDB sport name (e.g. 'Soccer', 'Ice Hockey')
    # Fall back to our static mapping if not provided
    if not tsdb_sport:
        tsdb_sport = _SLUG_TO_TSDB_SPORT.get(sport_slug, '')

    ck = 'sport_ev4_%s' % sport_slug   # v4: TSDB calendar as primary source
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    # No ESPN/TSDB/official-API path exists for this catch-all — it's built
    # entirely from bosscast/crickfree JSON leftovers not claimed by a named
    # sport, plus hoofoot.ru's own uncategorized Sport labels (Watersports,
    # Softball, Horse Racing, Other — none of which map to an existing slug).
    if sport_slug == 'other_international':
        from resources.lib import json_data as _jd
        events = _jd.get_other_international_events()
        try:
            hoofoot_extra = _hoofoot_other_events()
            if hoofoot_extra:
                events = _merge_events(events, hoofoot_extra)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] hoofoot other_international error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, events, 10 * 60)
        return events

    events = []

    # ── Phase 1: official APIs + TSDB calendar all in parallel ───────────────
    _today = datetime.date.today()
    _dates = [(_today + datetime.timedelta(days=d)).strftime('%Y-%m-%d') for d in range(7)]
    _ph1_ex  = ThreadPoolExecutor(max_workers=12)
    _ph1_futs = {}

    # Official league APIs (primary source for big-4)
    if sport_slug == 'nhl':
        _ph1_futs['official'] = _ph1_ex.submit(_nhl_official_events, max_items)
    elif sport_slug == 'nba':
        _ph1_futs['official'] = _ph1_ex.submit(_nba_official_events, max_items)
    elif sport_slug == 'mlb':
        _ph1_futs['official'] = _ph1_ex.submit(_mlb_official_events, max_items)
    elif sport_slug == 'nfl':
        # NFL.com feeds from ESPN; ESPN scoreboard is the de-facto official source
        _ph1_futs['official'] = _ph1_ex.submit(_espn_events, 'nfl', max_items)

    # TSDB calendar covers all other sports + supplements the big-4
    for _d in _dates:
        _ph1_futs['tsdb_%s' % _d] = _ph1_ex.submit(_tsdb_calendar_events, tsdb_sport, _d, max_items)

    _ph1_ex.shutdown(wait=False)

    official_events = []
    for _key, _f in _ph1_futs.items():
        try:
            _evs = _f.result(timeout=10)
            if not _evs:
                continue
            if _key == 'official':
                official_events = _evs
            else:
                events = _merge_events(events, _evs)
        except Exception:
            pass

    # NFL, CFB, and CFL all share TheSportsDB's single "American Football"
    # sport calendar (there's no separate TSDB sport per league) — confirmed
    # live that this puts CFL games (and even European League of Football
    # games) directly into the NFL listing with no way to tell them apart,
    # since the TSDB-calendar merge above has no per-league awareness at
    # all. Each event does carry its real league name in strLeague though
    # (surfaced here as 'league'), so filter the TSDB-sourced events down to
    # ones that actually match the requested league before they ever reach
    # the official-events merge below. Official-API events (ESPN NFL
    # scoreboard etc.) are already pure for their sport_slug and skip this.
    if sport_slug in _AMFOOTBALL_LEAGUE_KEYWORDS:
        _kws = _AMFOOTBALL_LEAGUE_KEYWORDS[sport_slug]
        events = [
            e for e in events
            if any(kw in (e.get('league', '') or '').lower() for kw in _kws)
        ]

    # Official API result takes precedence: merge TSDB into official (not the other way)
    if official_events:
        events = _merge_events(official_events, events)
    xbmc.log('[Starfleet/Sports] %s: official=%d tsdb=%d' % (
        sport_slug, len(official_events), len(events) - len(official_events)), xbmc.LOGINFO)

    # ── ESPN: adds live scores on top for non-big-4 sports ───────────────────
    espn_found = False
    if sport_slug in _ESPN_SPORTS and sport_slug not in ('nhl', 'nba', 'mlb', 'nfl'):
        espn_evs = _espn_events(sport_slug, max_items)
        espn_found = len(espn_evs) > 0
        if espn_evs:
            events = _merge_events(events, espn_evs)
    
    # For soccer: also poll extra leagues (PL, MLS, UCL, UEL) in parallel
    if sport_slug == 'soccer':
        def _fetch_extra_league(xl):
            try:
                _xdata = _get_json(_ESPN_API.format(sport='soccer', league=xl))
                _xevs  = []
                for ev in _xdata.get('events', []):
                    _st   = ev.get('status', {}).get('type', {}).get('state', 'pre')
                    _comp = (ev.get('competitions') or [{}])[0]
                    _cmps = _comp.get('competitors', [])
                    if len(_cmps) >= 2:
                        _teams = [c.get('team', {}).get('displayName', '') for c in _cmps]
                        _title = ' vs '.join(_teams)
                    else:
                        _title = ev.get('name', ev.get('shortName', ''))
                    _logo = _cmps[0].get('team', {}).get('logo', '') if _cmps else ''
                    _ts, _dt = _ts_to_dt(ev.get('date', ''))
                    _xevs.append({'id': ev.get('id', ''), 'slug': ev.get('id', ''),
                                  'path': '', 'title': _title, 'datetime': _dt,
                                  'league': xl.upper(), 'logo': _logo,
                                  'is_live': (_st == 'in'), 'start_ts': _ts})
                return _xevs
            except Exception:
                return []
        _xl_ex   = ThreadPoolExecutor(max_workers=len(_ESPN_SOCCER_EXTRA))
        _xl_futs = {xl: _xl_ex.submit(_fetch_extra_league, xl) for xl in _ESPN_SOCCER_EXTRA}
        _xl_ex.shutdown(wait=False)
        for xl, fut in _xl_futs.items():
            try:
                _xevs = fut.result(timeout=5)
                if _xevs:
                    events = _merge_events(events, _xevs)
            except Exception:
                pass

    # TSDB league fallback for UFC/Boxing/WWE (next-event API, not calendar)
    if not events and sport_slug in _TSDB_LEAGUES:
        events = _tsdb_events(sport_slug)
    
    # ISE fallback only when everything above returned nothing
    if not events:
        events = _ise_events(sport_slug)
    
    # Run supplementary sources in parallel (shutdown(wait=False) avoids blocking on hung futures)
    supplementary_futures = {}
    ex = ThreadPoolExecutor(max_workers=8)
    try:
        supplementary_futures['seast'] = ex.submit(_seast_events, sport_slug, max_items)
        if sport_slug in _METH_LEAGUE_PATHS:
            supplementary_futures['meth'] = ex.submit(_meth_events, sport_slug, max_items)
        # _tstek_events (totalsportek24.is) submission removed 2026-08-03 —
        # that domain confirmed unreliable (per its own guard comment
        # below), superseded by totalsportek.json (json_data.py), scraped
        # standalone from totalsportek.press instead. _tstek_events()'s own
        # body left in place as unreferenced dead code, same treatment as
        # this file's other removed live-scrape sources.
        # onhockey covers ALL hockey leagues — run for any hockey sport slug
        _HOCKEY_SLUGS = {'nhl', 'ahl', 'khl', 'shl', 'ohl', 'whl', 'qmjhl',
                         'echl', 'ncaa-hockey', 'pwhl', 'iihf', 'hockey'}
        if sport_slug in _HOCKEY_SLUGS:
            def _onhockey_for_slug(slug=sport_slug):
                evs = _onhockey_events()
                if slug == 'hockey':
                    return evs   # all leagues
                # filter to events whose detected league matches the slug
                slug_upper = slug.upper()
                return [e for e in evs if e.get('league', 'NHL').upper() == slug_upper]
            supplementary_futures['onhockey'] = ex.submit(_onhockey_for_slug)

        supplementary_futures['tvnow'] = ex.submit(_tvnow_events_for_sport, sport_slug)

        if sport_slug in _HOOFOOT_SPORT_MAP.values():
            supplementary_futures['hoofoot'] = ex.submit(_hoofoot_events, sport_slug, max_items)

        for name, fut in supplementary_futures.items():
            try:
                extra = fut.result(timeout=5)
                if extra:
                    events = _merge_events(events, extra)
                    xbmc.log('[Starfleet/Sports] %s merged %d events from %s' % (sport_slug, len(extra), name), xbmc.LOGINFO)
            except Exception as e:
                msg = str(e) or type(e).__name__
                xbmc.log('[Starfleet/Sports] supplementary events error (%s/%s): %s' % (sport_slug, name, msg), xbmc.LOGWARNING)
    finally:
        ex.shutdown(wait=False)  # don't block on any still-running futures

    # Fold in the pre-resolved scraper JSON — unions playable links from every
    # matching source into each event instead of leaving them as separate listings.
    from resources.lib import json_data as _jd
    events = _jd.merge_json_events(events, sport_slug)

    events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def get_all_events():
    ck = 'sports_events_all'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(ISE_BASE + '/')
        events = []
        seen   = set()

        for m in _RE_ISE_CARD.finditer(html):
            path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[m.end():m.end() + 900]
            title, dt_str, league, logo_url, is_live = _parse_ise_block(block)
            events.append({
                'id':       event_id,
                'slug':     slug,
                'path':     path,
                'title':    title or slug.replace('-', ' ').title(),
                'datetime': dt_str,
                'league':   league,
                'logo':     logo_url,
                'is_live':  is_live,
                'start_ts': int(start_ts_str),
            })

        events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
        _cache.set(ck, events, 10 * 60)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] all events error: %s' % e, xbmc.LOGERROR)
        return []


# ── Stream links ──────────────────────────────────────────────────────────────

# Known streaming embed/player domains — used as fallback link detection
_STREAM_EMBED_DOMAINS = (
    '720pstream', 'livetv', 'streamtape', 'cloudy.pk', 'stopstream',
    'nbaat', 'vecloud', 'embedstream', 'nlstreams', 'theflixer',
    'sportshdlive', 'daddylive', 'sportsurge', 'buffstream', 'atdhe',
    'firstrowsports', 'livesport', 'sportsbay', 'streameast',
    'crackstreams', 'volokit', 'acestream',
)

# istreameast.cx stream table row — flexible: 3 or more TDs, last with <a href>
_RE_ISE_STREAM_ROW = re.compile(
    r'<tr[^>]*>\s*'
    r'<td[^>]*>(.*?)</td>\s*'          # col 1: streamer/name
    r'<td[^>]*>(.*?)</td>\s*'          # col 2: channel/quality
    r'(?:<td[^>]*>.*?</td>\s*)*'       # optional extra cols
    r'<td[^>]*><a[^>]+href="([^"#][^"]*)"[^>]*>',
    re.IGNORECASE | re.DOTALL
)

# Fallback: any external <a> with href on a stream page
_RE_EXT_LINK = re.compile(
    r'<a[^>]+href="(https?://([^/"]+)[^"]*)"[^>]*>([^<]{1,80})</a>',
    re.IGNORECASE
)
# Fallback: iframes with external src
_RE_IFRAME_SRC = re.compile(r'<iframe[^>]+src="(https?://[^"]+)"', re.IGNORECASE)


def _extract_stream_links(html, base_domain, source_label):
    """
    Try structured table parse first, then fall back to link/iframe extraction.
    Returns list of stream dicts.
    """
    streams = []

    # 1. Try structured table rows
    for m in _RE_ISE_STREAM_ROW.finditer(html):
        col1 = _clean(m.group(1))
        col2 = _clean(m.group(2))
        url  = m.group(3).strip()
        if not url or url == '#':
            continue
        label = ('%s %s' % (col1, col2)).strip() or source_label
        streams.append({
            'label':    label,
            'url':      url,
            'quality':  col2,
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 2. Fallback: iframes
    for m in _RE_IFRAME_SRC.finditer(html):
        src = m.group(1).strip()
        if base_domain and base_domain in src:
            continue
        try:
            from urllib.parse import urlparse as _up2
            _pp = _up2(src)
            if not _pp.path or _pp.path in ('', '/'):
                continue  # skip bare homepage URLs (e.g. methstreams.gs/)
        except Exception:
            pass
        streams.append({
            'label':    source_label + ' Embedded',
            'url':      src,
            'quality':  '',
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 3. Fallback: known stream embed domain links
    for m in _RE_EXT_LINK.finditer(html):
        href   = m.group(1).strip()
        domain = m.group(2).lower()
        text   = _clean(m.group(3))
        if base_domain and base_domain in domain:
            continue
        if any(d in domain for d in _STREAM_EMBED_DOMAINS):
            streams.append({
                'label':    text or (source_label + ' Stream'),
                'url':      href,
                'quality':  '',
                'language': '',
                'source':   source_label,
            })

    return streams


def _ise_event_streams(event_path, event_id=''):
    url = ISE_BASE + event_path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=ISE_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE stream page error (%s): %s' % (event_path, e), xbmc.LOGERROR)
        return []

    streams = _extract_stream_links(html, 'istreameast.cx', 'StreamEast')
    xbmc.log('[Starfleet/Sports] ISE streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# Roxiestreams
_ROXIE_SLUGS = {
    'nfl':    'nfl',
    'nba':    'nba',
    'mlb':    'mlb',
    'nhl':    'nhl',
    'ufc':    'fighting',
    'boxing': 'fighting',
    'soccer': 'soccer',
    'wwe':    'wwe',
    'cfb':    'ncaaf',
    'ncaab':  'ncaab',
    'f1':     'f1',
    'cfl':    'cfl',
}

# Match both absolute (https://roxiestreams.info/...) and relative (/...) event links
_RE_ROXIE_EVENT_LINK = re.compile(
    r'<a[^>]+href=["\'](?:https?://roxiestreams\.info)?(/[^"\'#\s]{3,80})["\'][^>]*>\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

_ROXIE_SKIP = frozenset((
    'home', 'menu', 'schedule', 'login', 'register', 'about', 'contact',
    'discord', 'multiview', 'stream request (discord)',
))
_ROXIE_NAV = frozenset((
    'soccer', 'nba', 'nfl', 'nhl', 'fighting', 'motorsports', 'wwe', 'f1',
    'cfl', 'ncaaf', 'ncaab', 'soccer (wc 2026)', 'roxiestreams', 'multiview (new)',
))


def _roxie_streams(sport_slug, event_title=''):
    slug = _ROXIE_SLUGS.get(sport_slug)
    if not slug:
        return []
    listing_url = ROXIE_BASE + '/' + slug
    try:
        html = _get(listing_url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Roxie (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    title_words = [w.lower() for w in re.split(r'\W+', event_title) if len(w) > 3] if event_title else []

    # Find the event page URL that best matches the title
    event_url = None
    best_score = 0
    for m in _RE_ROXIE_EVENT_LINK.finditer(html):
        link_path = m.group(1)
        row_text  = _clean(m.group(2))
        if not row_text or len(row_text) < 4:
            continue
        if row_text.lower() in _ROXIE_SKIP or row_text.lower() in _ROXIE_NAV:
            continue
        if title_words:
            row_lower = row_text.lower()
            score = sum(1 for w in title_words if w in row_lower)
            if score > best_score:
                best_score = score
                event_url = ROXIE_BASE + link_path
        elif event_url is None:
            event_url = ROXIE_BASE + link_path

    if not event_url or (title_words and best_score == 0):
        xbmc.log('[Starfleet/Sports] Roxie %s "%s": no matching event' % (sport_slug, event_title), xbmc.LOGINFO)
        return []

    # Fetch the event page and extract direct m3u8 URLs
    try:
        ev_html = _sess().get(event_url, timeout=10,
                              headers=dict(_HEADERS, Referer=listing_url)).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Roxie event page error (%s): %s' % (event_url, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen = set()
    for m3u8_m in re.finditer(
            r'["\']?(https?://[^\s"\'<>{},\)]+\.m3u8[^\s"\'<>{},\)]*)["\']?',
            ev_html, re.I):
        u = m3u8_m.group(1)
        if u not in seen:
            seen.add(u)
            streams.append({'label': 'Roxie HD', 'url': u, 'quality': 'HD',
                            'language': '', 'source': 'RoxieStreams'})

    # Fallback: known embed domains via _extract_stream_links
    extra = _extract_stream_links(ev_html, 'roxiestreams.info', 'RoxieStreams')
    for s in extra:
        if s['url'] not in seen:
            seen.add(s['url'])
            streams.append(s)

    xbmc.log('[Starfleet/Sports] Roxie %s "%s": %d streams' % (sport_slug, event_title, len(streams)), xbmc.LOGINFO)
    return streams


# ── TotalSportek24 (multi-sport) ─────────────────────────────────────────────

# Maps our internal slugs to TotalSportek24 URL path segments
_TSTEK_SLUGS = {
    'soccer':  'soccer-streams',
    'nfl':     'nfl-streams',
    'nba':     'nba-streams',
    'nhl':     'nhl-streams',
    'mlb':     'mlb-stream',
    'ufc':     'ufc-streams',
    'boxing':  'boxing-streams',
    'f1':      'f1-streams',
    'cfb':     'college-football-streams',
    'ncaab':   'college-basketball-streams',
    'wwe':     'wwe-streams',
    'tennis':  'tennis-streams',
    'rugby':   'rugby-streams',
    'cricket': 'cricket-streams',
    'motogp':  'motogp-streams',
}

# Event card: <a href="/game/..."><div>...<span>TIME UTC</span>...<div class="row my-auto">TITLE</div>...</div></a>
_RE_TSTEK_GAME_CARD = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/game/[^"#\s]{4,120})"[^>]*>'
    r'.*?<span>\s*(\d+:\d+\s*(?:am|pm)[^<]*?)\s*</span>'
    r'.*?<div[^>]+class="row[^"]*my-auto[^"]*"[^>]*>\s*([^<]{3,120}?)\s*</div>',
    re.IGNORECASE | re.DOTALL
)

# Fallback: plain text anchor (older page layout)
_RE_TSTEK_EVENT = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^"#\s]{4,120})"[^>]*>'
    r'\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

# Nav links used to discover which sport sections actually exist on the site
_RE_TSTEK_NAV = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^/"]+/?)"[^>]*>'
    r'\s*([^<]{2,40}?)\s*</a>',
    re.IGNORECASE
)

# Cache the scraped nav/sport-section map across calls
_tstek_sport_urls = {}   # slug → full URL to that sport's schedule page


def _tstek_discover():
    """
    Fetch TotalSportek24 homepage and build a map of sport-slug → URL.
    Caches the result in _tstek_sport_urls for the session.
    """
    global _tstek_sport_urls
    if _tstek_sport_urls:
        return _tstek_sport_urls

    ck = 'tstek_sport_urls'
    cached = _cache.get(ck)
    if cached:
        _tstek_sport_urls = cached
        return _tstek_sport_urls

    try:
        html = _sess().get(TSTEK_BASE + '/', timeout=5,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 homepage error: %s' % e, xbmc.LOGWARNING)
        return {}

    # Build reverse map: url-path-segment → our slug
    reverse = {v: k for k, v in _TSTEK_SLUGS.items()}
    result  = {}

    for m in _RE_TSTEK_NAV.finditer(html):
        href    = m.group(1).rstrip('/')
        segment = href.rstrip('/').rsplit('/', 1)[-1].lower()
        if segment in reverse:
            our_slug = reverse[segment]
            result[our_slug] = href
            xbmc.log('[Starfleet/Sports] TotalSportek24 found sport: %s → %s' % (our_slug, href), xbmc.LOGINFO)

    # Fallback: construct URLs from the known slug map for any missing sports
    for our_slug, tstek_slug in _TSTEK_SLUGS.items():
        if our_slug not in result:
            result[our_slug] = '%s/%s/' % (TSTEK_BASE, tstek_slug)

    _tstek_sport_urls = result
    _cache.set(ck, result, 60 * 60)  # cache 1 hour
    return result


def _tstek_events(sport_slug, max_items=20):
    """Scrape TotalSportek24 for events matching the given sport slug."""
    import calendar as _cal

    ck = 'sports_tstek_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    sport_url = '%s/%s' % (TSTEK_BASE, _TSTEK_SLUGS.get(sport_slug, sport_slug + '-streams'))
    try:
        html = _sess().get(sport_url, timeout=5,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 sport page error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    # Confirmed live: some of this site's per-sport URLs (cricket, wwe, rugby,
    # ncaab at the time of checking) now silently serve the site's generic
    # "all live games today" page instead of anything actually scoped to that
    # sport — every OTHER sport checked returned 6-27 /game/ links, these
    # returned 78-309, all clearly mismatched (F1/UFC/boxing titles showing
    # up labeled with whatever sport_slug was requested). max_items caps the
    # events list this function returns to ~20 either way, so a plausible vs.
    # polluted page can't be told apart from the final count — check the RAW
    # link count on the page before that cap ever applies.
    _raw_game_link_count = html.count('totalsportek24.is/game/')
    if _raw_game_link_count > 50:
        xbmc.log('[Starfleet/Sports] TotalSportek24 (%s): page has %d game links — '
                  'looks like the generic all-sports page, not scoped content, skipping' %
                  (sport_slug, _raw_game_link_count), xbmc.LOGWARNING)
        _cache.set(ck, [], 30 * 60)
        return []

    events = []
    seen   = set()
    now_utc = datetime.datetime.utcnow()
    
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')
    all_as = soup.find_all('a')
    for a in all_as:
        if a.has_attr('href') and a['href'].find('totalsportek24.is/game/') != -1:
            href = a['href']
            span = a.find('span')
            if span is not None:
                raw_time = span.text.strip()
                rows = a.find_all('div', class_='row')
                if len(rows) == 0:
                    continue
                title = ''
                for row in rows:
                    if len(title) == 0:
                        title = row.text.strip()
                    else:
                        title = title + ' - ' + row.text.strip()
                title = _clean(title)
                
                if not title or href in seen:
                    continue
                seen.add(href)

                # Parse UTC time into a timestamp (assume today or tomorrow)
                start_ts = 0
                try:
                    time_only = re.search(r'(\d+):(\d+)\s*(am|pm)', raw_time, re.I)
                    if time_only:
                        hh = int(time_only.group(1)) % 12
                        if time_only.group(3).lower() == 'pm':
                            hh += 12
                        mm = int(time_only.group(2))
                        dt_utc = now_utc.replace(hour=hh, minute=mm, second=0, microsecond=0)
                        # If time already passed today, assume it's tomorrow
                        if dt_utc < now_utc and (now_utc - dt_utc).seconds > 3600:
                            dt_utc = dt_utc + datetime.timedelta(days=1)
                        start_ts = int(_cal.timegm(dt_utc.timetuple()))
                except Exception:
                    pass

                # TotalSportek24's static HTML carries no live-status badge at all
                # (confirmed live — no "live"/LIVE markup anywhere on the page, it's
                # likely added client-side via JS). Hardcoding is_live=False here
                # meant a fight/game already underway never showed the LIVE tag.
                # Heuristic instead: if the parsed start time has already passed
                # but not too long ago, treat it as live — combat-sports cards
                # (boxing/UFC) commonly run 4+ hours including undercards.
                now_ts = int(time.time())
                is_live = bool(start_ts) and 0 <= (now_ts - start_ts) <= 5 * 3600

                events.append({
                    'id':       'tstek_' + re.sub(r'\W+', '_', href),
                    'slug':     href.replace(TSTEK_BASE, '').strip('/'),
                    'path':     'tstek:' + href,
                    'title':    title,
                    'datetime': raw_time,
                    'league':   sport_slug.upper(),
                    'logo':     '',
                    'is_live':  is_live,
                    'start_ts': start_ts or int(time.time()),
                })
                if len(events) >= max_items:
                    break     

    # Primary: new card layout with /game/ URLs, inline time and title
    if not events:
        _iter_cards = _RE_TSTEK_GAME_CARD.finditer(html)
        for m in _iter_cards:
            href     = m.group(1).strip()
            raw_time = m.group(2).strip()   # e.g. "01:00 am  UTC"
            title    = _clean(m.group(3))
            if not title or href in seen:
                continue
            seen.add(href)

            # Parse UTC time into a timestamp (assume today or tomorrow)
            start_ts = 0
            try:
                time_only = re.search(r'(\d+):(\d+)\s*(am|pm)', raw_time, re.I)
                if time_only:
                    hh = int(time_only.group(1)) % 12
                    if time_only.group(3).lower() == 'pm':
                        hh += 12
                    mm = int(time_only.group(2))
                    dt_utc = now_utc.replace(hour=hh, minute=mm, second=0, microsecond=0)
                    # If time already passed today, assume it's tomorrow
                    if dt_utc < now_utc and (now_utc - dt_utc).seconds > 3600:
                        dt_utc = dt_utc + datetime.timedelta(days=1)
                    start_ts = int(_cal.timegm(dt_utc.timetuple()))
            except Exception:
                pass

            events.append({
                'id':       'tstek_' + re.sub(r'\W+', '_', href),
                'slug':     href.replace(TSTEK_BASE, '').strip('/'),
                'path':     'tstek:' + href,
                'title':    title,
                'datetime': raw_time,
                'league':   sport_slug.upper(),
                'logo':     '',
                'is_live':  False,
                'start_ts': start_ts or int(time.time()),
            })
            if len(events) >= max_items:
                break

    # Fallback: older plain-text anchor layout
    if not events:
        tstek_seg  = _TSTEK_SLUGS.get(sport_slug, sport_slug)
        is_soccer  = (sport_slug == 'soccer')
        other_segs = set(_TSTEK_SLUGS.values()) - {tstek_seg}
        skip_words = {'schedule', 'fixtures', 'results', 'standings', 'news', 'about',
                      'contact', 'privacy', 'home', 'live', 'stream', 'watch', tstek_seg}
        _iter_events = _RE_TSTEK_EVENT.finditer(html)
        for m in _iter_events:
            href  = m.group(1).strip()
            title = _clean(m.group(2))
            if not title or len(title) < 5 or href in seen:
                continue
            path_parts = href.replace(TSTEK_BASE, '').strip('/').split('/')
            if is_soccer:
                if path_parts[0].lower() in other_segs:
                    continue
            else:
                if not path_parts or path_parts[0].lower() != tstek_seg.lower():
                    continue
            if title.lower() in skip_words:
                continue
            seen.add(href)
            events.append({
                'id':       'tstek_' + re.sub(r'\W+', '_', href),
                'slug':     href.replace(TSTEK_BASE, '').strip('/'),
                'path':     'tstek:' + href,
                'title':    title,
                'datetime': '',
                'league':   sport_slug.upper(),
                'logo':     '',
                'is_live':  False,
                'start_ts': int(time.time()),
            })
            if len(events) >= max_items:
                break

    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] TotalSportek24 %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _tstek_streams(event_path):
    """Scrape stream links from a TotalSportek24 event page."""
    url = event_path.replace('tstek:', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, 'totalsportek24.is', 'TotalSportek')
    xbmc.log('[Starfleet/Sports] TotalSportek24 streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _tstek_streams_by_title(sport_slug, event_title):
    """Cross-reference: find best TotalSportek24 event by title and scrape its streams."""
    try:
        evs = _tstek_events(sport_slug)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tstek_x events error: %s' % e, xbmc.LOGWARNING)
        return []
    best_path, best_score, best_title = None, 0, ''
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
            best_title = ev['title']
    xbmc.log('[Starfleet/Sports] tstek_x "%s" vs %d events: best="%s" score=%d path=%s'
             % (event_title, len(evs), best_title, best_score, best_path), xbmc.LOGINFO)
    if not best_path or best_score < 1:
        return []
    try:
        return _tstek_streams(best_path)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tstek_x streams error: %s' % e, xbmc.LOGWARNING)
        return []


# ── *24all.ir generic helpers ─────────────────────────────────────────────────

def _x24_events(domain, sport_label, path_prefix):
    """Generic scraper for *24all.ir sites (mlb24all.ir, nhl24all.ir, nfl24all.ir, nba24all.ir)."""
    base = 'https://' + domain
    pattern = re.compile(
        r'<a[^>]+href="(https?://' + re.escape(domain) + r'/[^"]+)"[^>]*>([^<]+)</a>',
        re.IGNORECASE
    )
    try:
        html = _sess().get(base + '/', timeout=12,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s fetch error: %s' % (domain, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()
    skip_words = ('home', 'schedule', 'about', 'contact', 'privacy', domain.split('.')[0])

    for m in pattern.finditer(html):
        path  = m.group(1).strip()
        title = _clean(m.group(2))
        if not title or len(title) < 4 or path in seen:
            continue
        if any(s in title.lower() for s in skip_words):
            continue
        seen.add(path)
        events.append({
            'id':       path_prefix + re.sub(r'\W+', '_', path),
            'slug':     re.sub(r'https?://' + re.escape(domain) + r'/', '', path).strip('/'),
            'path':     path_prefix + ':' + path,
            'title':    title,
            'datetime': '',
            'league':   sport_label,
            'logo':     '',
            'is_live':  True,
            'start_ts': 0,
        })

    xbmc.log('[Starfleet/Sports] %s: %d events' % (domain, len(events)), xbmc.LOGINFO)
    return events


def _x24_streams(event_path, path_prefix, domain, source_label):
    """Generic stream scraper for *24all.ir event pages."""
    url = event_path.replace(path_prefix + ':', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer='https://' + domain + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s stream page error (%s): %s' % (domain, event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, domain, source_label)

    # Also pick up any explicit watch/stream/live anchors not caught above
    extra_re = re.compile(
        r'<a[^>]+href="(https?://[^"]+)"[^>]*>(?:[^<]*(?:watch|stream|live)[^<]*)</a>',
        re.IGNORECASE
    )
    for m in extra_re.finditer(html):
        su = m.group(1).strip()
        if not su or domain in su:
            continue
        if not any(s['url'] == su for s in streams):
            streams.append({'label': source_label + ' Stream', 'url': su,
                            'quality': '', 'language': '', 'source': source_label})

    xbmc.log('[Starfleet/Sports] %s streams for %s: %d' % (domain, event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _x24_streams_by_title(event_title, domain, path_prefix, sport_label, source_label):
    """Cross-reference: find best matching event on *24all.ir and scrape its streams."""
    evs = _x24_events(domain, sport_label, path_prefix)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _x24_streams(best_path, path_prefix, domain, source_label)


# ── MethStreams (multi-sport, same slug structure as CrackStreams) ────────────

_METH_LEAGUE_PATHS = {
    'mlb':    '/league/mlbstreams',
    'nfl':    '/league/nflstreams',
    'nba':    '/league/nbastreams',
    'nhl':    '/league/nhlstreams',
    'ufc':    '/league/mmastreams',
    'boxing': '/league/boxingstreams',
    'soccer': '/league/soccerstreams',
    'wwe':    '/league/wwestreams',
    'ncaab':  '/league/ncaab',
    'cfb':    '/league/cfbstreams',
    'f1':     '/league/f1streams',
}

_RE_METH_STREAM_LINK = re.compile(
    r'href=["\'](/stream/([^"\'#\s]{4,80}))["\']', re.IGNORECASE
)

# Real per-event schedule: <h2>Saturday, July 25, 2026</h2> day header,
# followed by one <a class="card" href="/stream/slug">...card-title...
# Start time: H:MM AM/PM ET...</a> block per event. The listing-page HTML
# has this the whole time (confirmed live) — the plain-link-only regex
# above was throwing it away, which is why every event here showed no
# date/time and was hardcoded to a fake "always live" status instead.
_RE_METH_DAY_HEADER = re.compile(
    r'<h2>\s*[A-Za-z]+day,\s*([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})\s*</h2>'
)
_RE_METH_CARD = re.compile(
    r'<a class="card" href="(/stream/([^"#\s]{4,80}))">.*?'
    r'<div class="card-title">([^<]*)</div>.*?'
    r'Start time:\s*(\d{1,2}):(\d{2})\s*(AM|PM)\s*ET',
    re.IGNORECASE | re.DOTALL
)


def _meth_events(sport_slug, max_items=20):
    """Scrape MethStreams league page for event slugs."""
    import calendar as _cal
    path = _METH_LEAGUE_PATHS.get(sport_slug)
    if not path:
        return []
    ck = 'sports_meth_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html = _sess().get(METH_BASE + path, timeout=10,
                           headers=dict(_HEADERS, Referer=METH_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] MethStreams (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    seen = set()

    # Build day-header position → date lookup, so each card below can pick
    # up the date of the most recent header preceding it.
    day_headers = []  # list of (pos, date)
    for dm in _RE_METH_DAY_HEADER.finditer(html):
        try:
            month_name, day_num, year = dm.group(1), int(dm.group(2)), int(dm.group(3))
            d = datetime.datetime.strptime('%s %d %d' % (month_name, day_num, year), '%B %d %Y').date()
            day_headers.append((dm.start(), d))
        except Exception:
            continue

    def _date_for_pos(pos):
        best = None
        for hpos, d in day_headers:
            if hpos <= pos:
                best = d
            else:
                break
        return best

    now_ts = int(time.time())
    for cm in _RE_METH_CARD.finditer(html):
        link_path, game_slug, card_title = cm.group(1), cm.group(2), cm.group(3)
        if game_slug in seen:
            continue
        seen.add(game_slug)
        title = _clean(card_title) or game_slug.replace('-', ' ').title()

        start_ts = 0
        d = _date_for_pos(cm.start())
        if d is not None:
            try:
                hh, mm, ampm = int(cm.group(4)), int(cm.group(5)), cm.group(6).upper()
                if ampm == 'PM' and hh != 12:
                    hh += 12
                elif ampm == 'AM' and hh == 12:
                    hh = 0
                offset = _us_eastern_offset_seconds(d)
                start_ts = int(_cal.timegm(datetime.datetime(d.year, d.month, d.day, hh, mm).timetuple())) - offset
            except Exception:
                start_ts = 0

        # Site's own copy says links go live 1h before start; combat/multi-game
        # cards commonly run several hours — same live-window heuristic used
        # for TotalSportek24 above.
        is_live = bool(start_ts) and -3600 <= (now_ts - start_ts) <= 5 * 3600

        events.append({
            'id':       'meth_' + game_slug,
            'slug':     game_slug,
            'path':     'meth:' + METH_BASE + link_path,
            'title':    title,
            'datetime': '',
            'league':   sport_slug.upper(),
            'logo':     '',
            'is_live':  is_live,
            'start_ts': start_ts,
        })
        if len(events) >= max_items:
            break

    # Markup changed / nothing matched the dated-card pattern — fall back to
    # plain link scraping rather than silently returning zero events. No
    # date info available on this path, so leave start_ts/is_live honest
    # (0 / False) instead of the old hardcoded "always live right now".
    if not events:
        for m in _RE_METH_STREAM_LINK.finditer(html):
            link_path, game_slug = m.group(1), m.group(2)
            if game_slug in seen:
                continue
            seen.add(game_slug)
            events.append({
                'id':       'meth_' + game_slug,
                'slug':     game_slug,
                'path':     'meth:' + METH_BASE + link_path,
                'title':    game_slug.replace('-', ' ').title(),
                'datetime': '',
                'league':   sport_slug.upper(),
                'logo':     '',
                'is_live':  False,
                'start_ts': 0,
            })
            if len(events) >= max_items:
                break

    xbmc.log('[Starfleet/Sports] MethStreams %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    _cache.set(ck, events, 10 * 60)
    return events


def _meth_event_streams(sport_slug, event_title=''):
    """Find the best-matching MethStreams event by title, return its stream page URL as a stream link.
    Note: MethStreams event pages are JS-rendered — no m3u8 in HTML. Returns slug URL as fallback."""
    evs = _meth_events(sport_slug)
    if not evs:
        return []
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = METH_BASE + '/stream/' + ev['slug']
    if not best_path or best_score < 2:
        return []
    return [{'label': 'MethStreams', 'url': best_path,
             'quality': '', 'language': '', 'source': 'MethStreams'}]


# ── *24all.ir (mlb24all.ir, nba24all.ir, nhl24all.ir, nfl24all.ir) ────────────
#
# These sites are now client-rendered Angular SPAs — the old anchor-scraping
# approach below (_x24_events/_x24_streams, still used by mlb66.ir) finds
# nothing on them any more since there's no per-game HTML to scrape. Found a
# clean, unauthenticated JSON API instead via live network inspection:
#   GET  https://api.<domain>/api/v3/stateshot
#        -> {teams, games, media_events, flavors, ...} full catalogue
#   POST https://api.<domain>/api/v2/generate_stream_info
#        {media_event_id, flavor_id} -> {url, wait} - a direct, playable HLS
#        master.m3u8 URL, no auth needed for "free.*" flavors (verified live
#        against mlb24all.ir with zero cookies/tokens). "premium.*" flavors
#        need an account token we don't have, so only free ones are tried.

_ALL24_DOMAINS = {
    'mlb': 'mlb24all.ir',
    'nba': 'nba24all.ir',
    'nhl': 'nhl24all.ir',
    'nfl': 'nfl24all.ir',
}


def _all24_stateshot(sport_slug):
    domain = _ALL24_DOMAINS.get(sport_slug)
    if not domain:
        return None
    ck = 'all24_stateshot_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        r = _sess().get('https://api.%s/api/v3/stateshot' % domain, timeout=10, headers=_HEADERS)
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s stateshot error: %s' % (domain, e), xbmc.LOGWARNING)
        return None
    _cache.set(ck, data, 2 * 60)  # scores/live status move fast — keep this short
    return data


def _all24_find_game(data, event_title):
    """Match event_title against team name pairs, preferring a currently-live
    game, then the most recently finished one, then the soonest upcoming."""
    teams = {t['id']: t for t in data.get('teams', [])}
    title_l = (event_title or '').lower()

    def _names(tid):
        t = teams.get(tid) or {}
        return [n for n in (t.get('name'), t.get('short_name'), t.get('abbreviation')) if n]

    candidates = []
    for g in data.get('games', []):
        away_hit = any(n.lower() in title_l for n in _names(g.get('away_team_id')))
        home_hit = any(n.lower() in title_l for n in _names(g.get('home_team_id')))
        if away_hit and home_hit:
            candidates.append(g)
    if not candidates:
        return None

    status_rank = {'L': 0, 'F': 1, 'S': 2}
    candidates.sort(key=lambda g: (status_rank.get(g.get('status'), 3), g.get('datetime') or ''))
    return candidates[0]


def _all24_generate_stream(domain, media_event_id, flavor_id, attempts=2):
    """POST /api/v2/generate_stream_info -> direct m3u8 URL, or None. A 'wait'
    response means the backend is still warming the stream up — retry briefly
    rather than giving up immediately (mirrors the site's own health-check
    retry behavior, seen in its JS)."""
    for i in range(attempts):
        try:
            r = _sess().post(
                'https://api.%s/api/v2/generate_stream_info' % domain,
                json={'media_event_id': media_event_id, 'flavor_id': flavor_id},
                timeout=8, headers=dict(_HEADERS, Origin='https://' + domain, Referer='https://' + domain + '/'))
            data = r.json()
        except Exception as e:
            xbmc.log('[Starfleet/Sports] %s generate_stream_info error: %s' % (domain, e), xbmc.LOGWARNING)
            return None
        if not data.get('wait') and data.get('url'):
            return data['url']
        if i < attempts - 1:
            time.sleep(1.5)
    return None


def _all24_streams_by_title(sport_slug, event_title):
    """Cross-reference: find the matching game on *24all.ir and resolve each
    of its free-flavor media events (e.g. ESPN Home/Away, Sportsnet) to a
    direct stream URL in parallel."""
    domain = _ALL24_DOMAINS.get(sport_slug)
    if not domain:
        return []
    data = _all24_stateshot(sport_slug)
    if not data:
        return []
    game = _all24_find_game(data, event_title)
    if not game:
        return []
    game_id = game['id']
    media_events = [m for m in data.get('media_events', []) if m.get('game_id') == game_id]
    if not media_events:
        return []

    free_flavor_ids = {f['id'] for f in data.get('flavors', [])
                       if f['id'].startswith('free.') and 'vod' not in f['id']}
    me_to_flavor = {}
    for f in data.get('flavors', []):
        if f['id'] not in free_flavor_ids:
            continue
        for me_id in f.get('media_event_ids', []):
            me_to_flavor.setdefault(me_id, f['id'])

    jobs = [(me, me_to_flavor[me['id']]) for me in media_events if me['id'] in me_to_flavor]
    if not jobs:
        return []

    results = [None] * len(jobs)
    with ThreadPoolExecutor(max_workers=len(jobs)) as ex:
        futs = {ex.submit(_all24_generate_stream, domain, me['id'], flavor_id): i
                for i, (me, flavor_id) in enumerate(jobs)}
        for fut in futs:
            i = futs[fut]
            try:
                results[i] = fut.result(timeout=10)
            except Exception as e:
                xbmc.log('[Starfleet/Sports] %s stream job error: %s' % (domain, e), xbmc.LOGWARNING)

    out = []
    for (me, _flavor_id), url in zip(jobs, results):
        if not url:
            continue
        out.append({
            'label': '%s (%s)' % (me.get('title') or 'Stream', me.get('provider') or domain),
            'url': url,
            'quality': '',
            'language': '',
            'source': domain.split('.')[0].upper(),
        })
    xbmc.log('[Starfleet/Sports] %s streams for "%s": %d' % (domain, event_title, len(out)), xbmc.LOGINFO)
    return out


# ── mlb66.ir (MLB-specific — dedicated live stream aggregator) ────────────────

def _mlb66_events():
    return _x24_events('mlb66.ir', 'MLB', 'mlb66')

def _mlb66_streams(event_path):
    return _x24_streams(event_path, 'mlb66', 'mlb66.ir', 'MLB66')

def _mlb66_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'mlb66.ir', 'mlb66', 'MLB', 'MLB66')


# ── BuffStreams (baseball section) ────────────────────────────────────────────

BUFFSTREAMS_BASE = 'https://buffstreams.app'

_RE_BUFF_GAME = re.compile(
    r'<a[^>]+href="(/[^"]*(?:baseball|mlb)[^"]*)"[^>]*>\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)


def _buffstreams_mlb_events():
    for path in ('/baseball/', '/baseball', '/'):
        try:
            html = _sess().get(BUFFSTREAMS_BASE + path, timeout=10,
                               headers=dict(_HEADERS, Referer='https://www.google.com/')).text
            events = []
            skip = {'home', 'schedule', 'about', 'contact', 'privacy', 'dmca', 'terms'}
            for m in _RE_BUFF_GAME.finditer(html):
                link = m.group(1).strip()
                title = _clean(m.group(2))
                if not title or title.lower() in skip:
                    continue
                full_url = BUFFSTREAMS_BASE + link
                events.append({
                    'id': 'buff_' + re.sub(r'\W+', '_', link),
                    'slug': link.strip('/'),
                    'path': 'buffstreams:' + full_url,
                    'title': title, 'datetime': '', 'league': 'MLB',
                    'logo': '', 'is_live': True, 'start_ts': 0,
                })
            if events:
                xbmc.log('[Starfleet/Sports] BuffStreams MLB: %d events' % len(events), xbmc.LOGINFO)
                return events
        except Exception as e:
            xbmc.log('[Starfleet/Sports] BuffStreams fetch error (%s): %s' % (path, e), xbmc.LOGWARNING)
    return []


def _buffstreams_streams(event_path):
    url = event_path.replace('buffstreams:', '')
    try:
        html = _sess().get(url, timeout=10,
                           headers=dict(_HEADERS, Referer=BUFFSTREAMS_BASE + '/')).text
        return _extract_stream_links(html, 'buffstreams.app', 'BuffStreams')
    except Exception as e:
        xbmc.log('[Starfleet/Sports] BuffStreams streams error: %s' % e, xbmc.LOGWARNING)
        return []


def _buffstreams_streams_by_title(event_title):
    evs = _buffstreams_mlb_events()
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = ev['path']
    if not best_path or best_score < 2:
        return []
    return _buffstreams_streams(best_path)


# ── BuffStreams v6 (buffstreams.com.co/v6) — SSR event+mirror-link dump ──────
#
# A different, unrelated site from buffstreams.app above despite the shared
# name. Confirmed live 2026-08-15: the /v6 homepage is a Next.js app, but
# unlike a client-rendered SPA its React Server Components response embeds
# the ENTIRE event list — every currently scheduled/live game across every
# sport the site carries, each already with its own full array of 40-50+
# named mirror links (`"directStreams": [{"link","name","quality",...}]`)
# — right in the initial HTML response, as escaped JSON inside
# `self.__next_f.push([1,"..."])` script chunks. No per-game page fetch or
# API call needed at all: one homepage GET returns both the schedule AND
# every game's full mirror list in one shot.
#
# Those mirror links point to ~15 different third-party sites, each its own
# separate embed technology — not all chased down (out of scope for one
# integration), but one was verified end-to-end: the "ovostreams" mirror's
# ovo-goal.st page embeds an iframe.st player page whose JS computes its
# real HLS source via a purely static, reproducible 6-layer string
# transform (unshuffle -> XOR -> hex-decode -> ROT13 -> reverse -> base64
# decode — the player's own code comment literally calls this "OBFUSCATED
# CONFIGURATION", but it's cosmetic: no browser/JS engine ever needs to run
# it, confirmed live by reimplementing the exact same steps in plain Python
# against the real page's own embedded constants and getting back a
# byte-for-byte match for the URL the site's own JS would have computed).
# That URL is a Cloudflare Worker API endpoint which 403s with no Origin
# header but returns a real `{"success":true,"stream":"https://...m3u8?
# cst=..."}` once an `Origin: <player page's own origin>` header is sent —
# confirmed live end-to-end against a real, then-currently-live Chelsea vs
# Real Sociedad stream, all the way through fetching the resulting .m3u8
# and getting a genuine #EXTM3U live playlist back (not just a 200 on the
# API call).
#
# Every OTHER mirror on a matched game is still tried too, through the
# exact same generic resolveurl/embed_resolver chain this file's other
# sources already use (_sportsurge_try_resolve's own docstring has the
# rationale) — most of them are genuinely JS-gated the same way most of
# SportSurge's mirrors are (confirmed for at least one other mirror here,
# ripple.kora.st, whose iframe src is set via JS post-load with nothing
# static in the HTML — literally `src="about:blank"`), so only whichever
# mirrors actually resolve get shown, same self-correcting "don't hardcode
# a stale allowlist" approach already used throughout this file.

BUFFCOM_BASE = 'https://buffstreams.com.co/v6'

_RE_BUFFCOM_PUSH = re.compile(r'__next_f\.push\(\[1,"((?:[^"\\]|\\.)*)"\]\)')

# The decrypt player's own three embedded constants (see _buffcom_decrypt's
# docstring for what each layer does) — re-extracted fresh from each page's
# own HTML rather than hardcoded, since only the encoded _wd payload is
# guaranteed per-page/per-game; _wk/_wri could plausibly change too.
_RE_WORKER_WD  = re.compile(r'_wd\s*=\s*"([0-9a-fA-F]+)"')
_RE_WORKER_WK  = re.compile(r'_wk\s*=\s*(\d+)')
_RE_WORKER_WRI = re.compile(r'_wri\s*=\s*\[([\d,]+)\]')
_RE_IFRAME_SRC = re.compile(r'<iframe[^>]+src="(https?://[^"]+)"', re.IGNORECASE)


def _buffcom_events():
    """Parse buffstreams.com.co/v6's homepage RSC payload for every
    scheduled/live event across every sport, each already carrying its
    full directStreams mirror list — no second fetch needed."""
    ck = 'buffcom_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _sess().get(BUFFCOM_BASE, timeout=12, headers=_HEADERS).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] buffcom events fetch error: %s' % e, xbmc.LOGWARNING)
        return []
    if not html:
        return []

    import json
    chunks = []
    for m in _RE_BUFFCOM_PUSH.finditer(html):
        try:
            chunks.append(json.loads('"' + m.group(1) + '"'))
        except Exception:
            continue
    full_text = ''.join(chunks)

    # Next.js's RSC stream mixes plain JSON objects (the event/stream data
    # we want) in with its own React-element shorthand syntax that ISN'T
    # valid JSON on its own — a single json.loads() over the whole thing
    # doesn't work, so each self-contained `{"_id":"...", ...}` object is
    # located by a brace-balanced scan (respecting quoted strings, so a
    # literal "}" inside a title/URL string doesn't miscount) and parsed
    # individually instead.
    events = []
    marker = '{"_id":"'
    pos = 0
    while True:
        idx = full_text.find(marker, pos)
        if idx == -1:
            break
        depth, i, in_str, esc, end = 0, idx, False, False, None
        while i < len(full_text):
            c = full_text[i]
            if in_str:
                if esc:
                    esc = False
                elif c == '\\':
                    esc = True
                elif c == '"':
                    in_str = False
            else:
                if c == '"':
                    in_str = True
                elif c == '{':
                    depth += 1
                elif c == '}':
                    depth -= 1
                    if depth == 0:
                        end = i + 1
                        break
            i += 1
        if not end:
            break
        pos = end
        try:
            obj = json.loads(full_text[idx:end])
        except Exception:
            continue
        details = obj.get('details') or {}
        t2, t3 = (details.get('text2') or '').strip(), (details.get('text3') or '').strip()
        title = ('%s vs %s' % (t2, t3)).strip() if t2 or t3 else ''
        streams = obj.get('directStreams') or []
        if not title or not streams:
            continue
        events.append({
            'id':      obj.get('_id', ''),
            'title':   title,
            'league':  (obj.get('category') or '').upper(),
            'streams': streams,
        })
    _cache.set(ck, events, 5 * 60)
    xbmc.log('[Starfleet/Sports] buffcom events: %d' % len(events), xbmc.LOGINFO)
    return events


def _buffcom_decrypt(encoded, xor_key, rev_indices):
    """Plain reimplementation of iframe.st's own client-side `_decrypt()` —
    a purely static, deterministic 6-layer string transform (unshuffle,
    XOR, hex-decode, ROT13, reverse, base64) with no randomness or session
    state involved at all; confirmed live it reproduces byte-for-byte the
    same Cloudflare Worker URL the site's own in-browser JS computes. See
    this section's module-level docstring for the full verification
    story."""
    chars = list(encoded)
    unshuffled = [None] * len(chars)
    for i in range(len(chars)):
        unshuffled[rev_indices[i]] = chars[i]
    xor_encoded = ''.join(unshuffled)

    hex_encoded = ''
    for i in range(0, len(xor_encoded), 2):
        hex_encoded += chr(int(xor_encoded[i:i + 2], 16) ^ xor_key)

    rot13_str = ''
    for i in range(0, len(hex_encoded), 2):
        rot13_str += chr(int(hex_encoded[i:i + 2], 16))

    def _rot13(c):
        code = ord(c)
        if c.isalpha():
            base = 90 if c <= 'Z' else 122
            return chr(code + 13) if base >= (code + 13) else chr(code - 13)
        return c
    reversed_str = ''.join(_rot13(c) for c in rot13_str)

    b64 = reversed_str[::-1]
    pad = len(b64) % 4
    if pad:
        b64 += '=' * (4 - pad)
    import base64
    return base64.b64decode(b64).decode('utf-8', errors='replace')


def _buffcom_resolve_decrypt_worker(url, hop=0):
    """Resolve a mirror page that either IS, or is one hop away from, an
    iframe.st-style HLS player (the `_wd/_wk/_wri` decrypt-worker pattern —
    see this section's module docstring). Returns a real, verified-
    playable m3u8 URL (pipe-tagged with Referer, this codebase's existing
    convention) or None. Caps recursion at one nested-iframe hop — the one
    confirmed chain (ovo-goal.st -> iframe.st) is exactly one hop; deeper
    chains aren't chased, to keep this bounded like the rest of this
    file's per-source resolvers."""
    try:
        html = _sess().get(url, timeout=8, headers=_HEADERS).text
    except Exception:
        return None
    if not html:
        return None

    m_wd, m_wk, m_wri = _RE_WORKER_WD.search(html), _RE_WORKER_WK.search(html), _RE_WORKER_WRI.search(html)
    if not (m_wd and m_wk and m_wri):
        if hop >= 1:
            return None
        m_if = _RE_IFRAME_SRC.search(html)
        if not m_if or m_if.group(1) in ('about:blank', url):
            return None
        return _buffcom_resolve_decrypt_worker(m_if.group(1), hop=hop + 1)

    try:
        rev_indices = [int(x) for x in m_wri.group(1).split(',')]
        worker_url = _buffcom_decrypt(m_wd.group(1), int(m_wk.group(1)), rev_indices)
        if not worker_url.startswith('http'):
            return None
        import urllib.parse as _up6
        origin = '%s://%s' % (_up6.urlsplit(url).scheme, _up6.urlsplit(url).netloc)
        r = _sess().get(worker_url, timeout=8, headers=dict(_HEADERS, Origin=origin, Referer=url))
        data = r.json()
        stream = data.get('stream') if data.get('success') else None
        if not stream:
            return None
        check = _sess().get(stream, timeout=8, headers=dict(_HEADERS, Referer=url))
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            return None
        return '%s|Referer=%s' % (stream, _up6.quote(url, safe=''))
    except Exception as e:
        xbmc.log('[Starfleet/Sports] buffcom decrypt-worker resolve error: %s' % e, xbmc.LOGWARNING)
        return None


def _buffcom_try_resolve(link):
    """Same resolve chain as _sportsurge_try_resolve (ResolveURL, then
    embed_resolver's generic iframe follower), plus this source's own
    bespoke decrypt-worker chain as a further fallback for mirrors that
    route through an iframe.st-style player."""
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(link)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                return r
    except ImportError:
        pass
    except Exception:
        pass
    try:
        from resources.lib import embed_resolver
        stream, referer = embed_resolver.resolve_generic_iframe_chain(link)
        if stream:
            if referer:
                import urllib.parse as _up7
                return '%s|Referer=%s' % (stream, _up7.quote(referer, safe=''))
            return stream
    except Exception:
        pass
    return _buffcom_resolve_decrypt_worker(link)


def _buffcom_streams_for_event(event):
    mirrors = event.get('streams') or []
    if not mirrors:
        return []
    streams = []
    pool = ThreadPoolExecutor(max_workers=min(len(mirrors), 15))
    try:
        futures = {pool.submit(_buffcom_try_resolve, m.get('link', '')): m
                   for m in mirrors if m.get('link')}
        for future in as_completed(futures, timeout=12):
            m = futures[future]
            try:
                resolved = future.result()
            except Exception:
                resolved = None
            if resolved:
                streams.append({
                    'label': m.get('name') or 'BuffStreams', 'url': resolved,
                    'quality': m.get('quality', '') or '', 'language': '',
                    'source': 'BuffStreams',
                })
    except Exception as e:
        xbmc.log('[Starfleet/Sports] buffcom resolve timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)
    return streams


def _buffcom_streams_by_title(event_title):
    evs = _buffcom_events()
    if not evs:
        return []
    best_ev, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_ev = ev
    if not best_ev or best_score < 2:
        return []
    return _buffcom_streams_for_event(best_ev)


# ── DaddyLive (daily multi-sport schedule) ────────────────────────────────────

_DADDYLIVE_BASES = [
    'https://daddylive.eu',
]

_RE_DADDY_EVENT = re.compile(
    r'<a[^>]+href="(/[^"#\s]{4,80})"[^>]*>\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

_DADDY_SPORT_KEYWORDS = {
    'mlb':     ['mlb', 'baseball', 'red sox', 'yankees', 'dodgers', 'cubs', 'mets',
                'braves', 'astros', 'phillies', 'blue jays', 'mariners', 'giants',
                'padres', 'angels', 'tigers', 'twins', 'rays', 'orioles', 'guardians'],
    'nfl':     ['nfl', 'football', 'patriots', 'chiefs', 'bills', 'eagles', 'cowboys'],
    'nba':     ['nba', 'basketball', 'lakers', 'celtics', 'warriors', 'heat', 'bulls'],
    'nhl':     ['nhl', 'hockey', 'bruins', 'rangers', 'leafs', 'canadiens', 'penguins'],
    'soccer':  ['soccer', 'football', 'premier league', 'la liga', 'serie a', 'champions'],
}


def _daddylive_events(sport_slug):
    keywords = _DADDY_SPORT_KEYWORDS.get(sport_slug, [])
    if not keywords:
        return []
    for base in _DADDYLIVE_BASES:
        try:
            html = _sess().get(base + '/schedule.php', timeout=10,
                               headers=dict(_HEADERS, Referer='https://www.google.com/')).text
            events = []
            skip = {'home', 'schedule', 'about', 'contact', 'privacy'}
            for m in _RE_DADDY_EVENT.finditer(html):
                link = m.group(1).strip()
                title = _clean(m.group(2))
                if not title or title.lower() in skip or len(title) < 4:
                    continue
                tl = title.lower()
                if not any(kw in tl for kw in keywords):
                    continue
                full_url = base + link
                events.append({
                    'id': 'daddy_' + re.sub(r'\W+', '_', link),
                    'slug': link.strip('/'),
                    'path': 'daddylive:' + full_url,
                    'title': title, 'datetime': '', 'league': sport_slug.upper(),
                    'logo': '', 'is_live': True, 'start_ts': 0,
                })
            if events:
                xbmc.log('[Starfleet/Sports] DaddyLive %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
                return events
        except Exception as e:
            xbmc.log('[Starfleet/Sports] DaddyLive fetch error (%s): %s' % (base, e), xbmc.LOGWARNING)
    return []


def _daddylive_streams(event_path):
    url = event_path.replace('daddylive:', '')
    base = next((b for b in _DADDYLIVE_BASES if b in url), _DADDYLIVE_BASES[0])
    try:
        html = _sess().get(url, timeout=10,
                           headers=dict(_HEADERS, Referer=base + '/')).text
        streams = _extract_stream_links(html, 'daddylive', 'DaddyLive')
        if not streams:
            # Look for iframe embeds or redirects to player pages
            for m in re.finditer(r'href=["\']([^"\']+channel[^"\']+)["\']', html, re.I):
                chan_url = m.group(1)
                if not chan_url.startswith('http'):
                    chan_url = base + '/' + chan_url.lstrip('/')
                streams.append({'label': 'DaddyLive Channel', 'url': chan_url,
                                'quality': '', 'language': '', 'source': 'DaddyLive'})
        xbmc.log('[Starfleet/Sports] DaddyLive streams: %d' % len(streams), xbmc.LOGINFO)
        return streams
    except Exception as e:
        xbmc.log('[Starfleet/Sports] DaddyLive streams error: %s' % e, xbmc.LOGWARNING)
        return []


def _daddylive_streams_by_title(sport_slug, event_title):
    evs = _daddylive_events(sport_slug)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = ev['path']
    if not best_path or best_score < 2:
        return []
    return _daddylive_streams(best_path)


# NHL24/NFL24/NBA24 (nhl24all.ir/nfl24all.ir/nba24all.ir) are handled by the
# unified _all24_streams_by_title() above, alongside MLB24 — same API family.


# ── onhockey.tv (all hockey leagues) ─────────────────────────────────────────

# In-memory cache for inline stream links scraped from schedule_table.php
_ONHOCKEY_STREAM_CACHE = {}

_RE_ONHOCKEY_TBODY   = re.compile(r"<tbody[^>]*class=['\"]([^'\"]*)['\"][^>]*>(.*?)</tbody>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_LEAGUE  = re.compile(r'<b>([A-Z][A-Z0-9 /\-]{1,20})</b>', re.IGNORECASE)
_RE_ONHOCKEY_GAMEROW = re.compile(r"<tr class='game'[^>]*>(.*?)</tr>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_HOUR    = re.compile(r"class='game_hour'[^>]*>(\d+)</text>:(\d+)", re.IGNORECASE)
_RE_ONHOCKEY_TITLE   = re.compile(r"</td><td>([^<\n]{3,100})", re.IGNORECASE)
_RE_ONHOCKEY_GL      = re.compile(r"class='gamelinks'[^>]*>(.*?)</div>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_CHAN    = re.compile(r"href='np_stream400\.php\?channel=([^'\"&]{5,200})'[^>]*(?:title='([^']*)')?", re.IGNORECASE)

_RE_ONHOCKEY_JS_M3U8 = re.compile(
    r'(?:src|href|file|source)\s*[:=]\s*["\']?(https?://[^"\'>\s]{15,300}\.m3u8[^"\'>\s]*)',
    re.IGNORECASE
)

_RE_ONHOCKEY_WATCH = re.compile(
    r'<a[^>]+href="(https?://(?!onhockey\.tv)[^"]{10,200})"[^>]*>([^<]*(?:Watch|Stream|Link|HD|Mirror|\d)[^<]*)</a>',
    re.IGNORECASE
)
_RE_ONHOCKEY_NUMBERED = re.compile(
    r'<a[^>]+href="(https?://(?!onhockey\.tv)[^"]{10,200})"[^>]*>\s*(?:(?:Stream|Link|Watch|HD)\s*)?\d+\s*</a>',
    re.IGNORECASE
)


_ONHOCKEY_LEAGUE_KEYWORDS = [
    ('AHL',   ('ahl',)),
    ('KHL',   ('khl',)),
    ('OHL',   ('ohl',)),
    ('WHL',   ('whl',)),
    ('QMJHL', ('qmjhl', 'lhjmq')),
    ('ECHL',  ('echl',)),
    ('SHL',   ('shl',)),
    ('DEL',   ('del ',)),
    ('NCAA',  ('ncaa', 'college hockey', 'university')),
    ('IIHF',  ('iihf', 'world championship', 'world cup of hockey')),
    ('PHF',   ('phf', 'premier hockey')),
    ('PWHL',  ('pwhl',)),
    ('NWHL',  ('nwhl',)),
]


def _onhockey_league(title):
    """Detect hockey league from event title; defaults to NHL."""
    t = title.lower()
    for league, keywords in _ONHOCKEY_LEAGUE_KEYWORDS:
        if any(k in t for k in keywords):
            return league
    return 'NHL'


def _onhockey_events():
    """Scrape onhockey.tv schedule via schedule_table.php (AJAX endpoint).
    Parses tbody/game-row structure, caches inline stream links per event.
    """
    import datetime as _dt
    import calendar as _cal

    global _ONHOCKEY_STREAM_CACHE

    try:
        r = _sess().get(
            ONHOCKEY_BASE + '/schedule_table.php',
            timeout=12,
            headers=dict(_HEADERS,
                         Referer=ONHOCKEY_BASE + '/',
                         **{'X-Requested-With': 'XMLHttpRequest'}),
        )
        r.raise_for_status()
        html = r.text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] onhockey.tv schedule error: %s' % e, xbmc.LOGWARNING)
        return []

    events = []
    _ONHOCKEY_STREAM_CACHE = {}
    current_league = 'NHL'
    # Default to today UTC; updated when we hit a Date row
    _now_utc = _dt.datetime.utcnow()
    current_date = _now_utc.date()
    current_year = _now_utc.year

    for tbody_m in _RE_ONHOCKEY_TBODY.finditer(html):
        tbody_class = tbody_m.group(1)
        tbody_html  = tbody_m.group(2)

        if 'Date' in tbody_class:
            # Parse date like "<b>July 3</b>"
            dm = re.search(r'<b>(\w+ \d+)</b>', tbody_html)
            if dm:
                try:
                    current_date = _dt.datetime.strptime(
                        '%s %d' % (dm.group(1), current_year), '%B %d %Y'
                    ).date()
                except Exception:
                    pass
            continue

        # League name from the bold header in this tbody
        lhdr = _RE_ONHOCKEY_LEAGUE.search(tbody_html)
        if lhdr:
            current_league = lhdr.group(1).strip()

        for game_m in _RE_ONHOCKEY_GAMEROW.finditer(tbody_html):
            row_html = game_m.group(1)

            title_m = _RE_ONHOCKEY_TITLE.search(row_html)
            if not title_m:
                continue
            title = title_m.group(1).strip()
            if not title or len(title) < 3:
                continue
            # Skip TV channel names (e.g. "NHL Network", "ESPN+") — not actual games
            _tl = title.lower()
            if not any(sep in _tl for sep in (' vs ', ' at ', ' @ ', ' v ')):
                continue

            hour_m = _RE_ONHOCKEY_HOUR.search(row_html)
            start_ts = 0
            date_label = ''
            if hour_m:
                try:
                    hh = int(hour_m.group(1))
                    mm = int(hour_m.group(2))
                    dt_utc = _dt.datetime(
                        current_date.year, current_date.month, current_date.day, hh, mm, 0
                    )
                    start_ts = int(_cal.timegm(dt_utc.timetuple()))
                    # Human date label e.g. "Jul 3"
                    date_label = current_date.strftime('%b %-d') if hasattr(current_date, 'strftime') else str(current_date)
                except Exception:
                    pass

            # Extract inline stream links from gamelinks div
            links = []
            gl_m = _RE_ONHOCKEY_GL.search(row_html)
            if gl_m:
                for lm in _RE_ONHOCKEY_CHAN.finditer(gl_m.group(1)):
                    chan = lm.group(1).strip()
                    if chan.startswith('//'):
                        chan = 'https:' + chan
                    elif not chan.startswith('http'):
                        chan = ONHOCKEY_BASE + '/' + chan.lstrip('/')
                    lbl = lm.group(2) or title
                    links.append({
                        'label': '[OnHockey] %s' % lbl,
                        'url': chan,
                        'quality': '', 'language': '', 'source': 'OnHockey.tv',
                    })

            ev_id = 'onhockey_%s_%s_%s' % (
                re.sub(r'\W+', '_', current_league.lower()),
                str(current_date),
                re.sub(r'\W+', '_', title.lower())[:50],
            )

            if links:
                _ONHOCKEY_STREAM_CACHE[ev_id] = links

            events.append({
                'id':         ev_id,
                'slug':       ev_id,
                'path':       'onhockey:' + ev_id,
                'title':      title,
                'date_label': date_label,
                'league':     current_league,
                'logo':       '',
                'is_live':    bool(links),
                'start_ts':   start_ts,
            })

    xbmc.log('[Starfleet/Sports] onhockey.tv: %d events across %d leagues' % (
        len(events), len(set(e['league'] for e in events))), xbmc.LOGINFO)
    return events


def _onhockey_streams(event_path):
    """Return stream links for an onhockey.tv event.
    Checks the in-memory stream cache first (populated by _onhockey_events()).
    Falls back to fetching the game page URL if the path is a full URL.
    """
    ev_id = event_path.replace('onhockey:', '')

    # Try in-memory cache (schedule_table.php inline links)
    cached = _ONHOCKEY_STREAM_CACHE.get(ev_id)
    if cached:
        xbmc.log('[Starfleet/Sports] onhockey.tv cached streams for %s: %d' % (ev_id, len(cached)), xbmc.LOGINFO)
        return cached

    # Fallback: ev_id is a full URL (old-style path)
    if not ev_id.startswith('http'):
        xbmc.log('[Starfleet/Sports] onhockey.tv no streams cached for %s' % ev_id, xbmc.LOGINFO)
        return []

    try:
        html = _sess().get(ev_id, timeout=12,
                           headers=dict(_HEADERS, Referer=ONHOCKEY_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] onhockey.tv stream page error (%s): %s' % (ev_id, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen_urls = set()

    # Live/channel pages (e.g. index.php?place=daddylive&channel=NNN) don't list
    # plain <a> stream links like game pages do - the player embeds the .m3u8
    # directly in a JS player config (src/file/source: "...m3u8"). Check this
    # first since it's the primary pattern for this page type.
    m = _RE_ONHOCKEY_JS_M3U8.search(html)
    if m:
        su = m.group(1).strip()
        streams.append({'label': 'OnHockey Live Stream', 'url': su,
                        'quality': 'HLS', 'language': '', 'source': 'OnHockey.tv'})
        seen_urls.add(su)

    for m in _RE_ONHOCKEY_WATCH.finditer(html):
        su    = m.group(1).strip()
        label = _clean(m.group(2)) or 'OnHockey Stream'
        if su and su not in seen_urls:
            streams.append({'label': label, 'url': su,
                            'quality': '', 'language': '', 'source': 'OnHockey.tv'})
            seen_urls.add(su)

    for m in _RE_ONHOCKEY_NUMBERED.finditer(html):
        su = m.group(1).strip()
        if su and su not in seen_urls:
            streams.append({'label': 'OnHockey Stream', 'url': su,
                            'quality': '', 'language': '', 'source': 'OnHockey.tv'})
            seen_urls.add(su)

    if not streams:
        streams = _extract_stream_links(html, 'onhockey.tv', 'OnHockey.tv')

    # Last resort: the player embed may be proxied through onhockey.tv's own
    # domain (e.g. an internal /player.php iframe), which _extract_stream_links
    # deliberately skips since it excludes same-domain iframes. Follow one hop
    # through any same-domain iframe to reach the actual (usually external)
    # player, then look for an m3u8 or external iframe/link there.
    if not streams:
        for im in _RE_IFRAME_SRC.finditer(html):
            isrc = im.group(1).strip()
            if not isrc or isrc == ev_id or 'onhockey.tv' not in isrc:
                continue
            try:
                inner_html = _sess().get(isrc, timeout=10,
                                         headers=dict(_HEADERS, Referer=ev_id)).text
            except Exception:
                continue
            im2 = _RE_ONHOCKEY_JS_M3U8.search(inner_html)
            if im2:
                streams.append({'label': 'OnHockey Live Stream', 'url': im2.group(1).strip(),
                                'quality': 'HLS', 'language': '', 'source': 'OnHockey.tv'})
                break
            streams = _extract_stream_links(inner_html, 'onhockey.tv', 'OnHockey.tv')
            if streams:
                break

    xbmc.log('[Starfleet/Sports] onhockey.tv streams for %s: %d' % (ev_id, len(streams)), xbmc.LOGINFO)
    return streams


def _onhockey_streams_by_title(event_title):
    """Cross-reference: find onhockey.tv game by title match and scrape its streams."""
    evs = _onhockey_events()
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _onhockey_streams(best_path)


# ── DaddyLive.mov 24/7 channels (NHL Network, etc.) ───────────────────────────
#
# NOTE: named "dlchan" (not "daddylive") to avoid colliding with the separate,
# pre-existing daddylive.eu multi-sport event scraper above (_daddylive_events/
# _daddylive_streams) — that one produces 'daddylive:' event paths; this one
# uses 'dlchan:' for the unrelated daddylive.mov 24/7-channel chain.
#
# Chain: daddylive.mov's per-channel page (/live/stream=Channel+Name) embeds a
# static JSON list of mirror URLs for that channel — the #video-player iframe
# itself is populated client-side by JS and is NOT usable from a plain fetch,
# but the underlying mirror-URL list is present in the raw HTML regardless.
# One mirror tier (logic.icelanders.st-style hosts) further obfuscates its own
# inline <script> with a simple XOR/subtract cipher hiding a signed,
# short-lived .m3u8 URL — decode it locally instead of needing a real browser.
# The signed URL expires (embedded unix ts a few hours out), so this must be
# re-resolved on every play — never cache the final .m3u8 long-term.

DLCHAN_BASE = 'https://daddylive.mov'

# Obfuscated blob: var _xx=[n,n,...],_yy=KEY,_zz=SUB, ... window["ev"+"al"](...)
_RE_DLCHAN_XOR_BLOB = re.compile(
    r'var\s+_[a-zA-Z0-9]+\s*=\s*\[([\d,\s]+)\]\s*,\s*_[a-zA-Z0-9]+\s*=\s*(\d+)\s*,\s*_[a-zA-Z0-9]+\s*=\s*(\d+)'
)

_RE_DLCHAN_SIGNED_M3U8 = re.compile(r'SIGNED_URL\s*=\s*"(https?://[^"]+?\.m3u8[^"]*)"')
_RE_DLCHAN_ANY_M3U8    = re.compile(r'https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*')


def _decode_dlchan_xor_blob(html):
    """Decode the site's obfuscated inline script: an int array XORed with a
    key then offset-subtracted (mod 256). Returns decoded JS text, or '' if
    the pattern isn't present (site may have changed the cipher again)."""
    m = _RE_DLCHAN_XOR_BLOB.search(html)
    if not m:
        return ''
    try:
        arr = [int(x) for x in m.group(1).replace(' ', '').split(',') if x]
        key = int(m.group(2))
        sub = int(m.group(3))
        return ''.join(chr(((c ^ key) - sub + 256) % 256) for c in arr)
    except Exception:
        return ''


_RE_DLCHAN_B64_DECODE_FN = re.compile(
    r'function\s+(\w+)\(\w+\)\s*\{\s*\w+\s*=\s*\w+\.replace\(/-/g,\s*[\'"]\+[\'"]\)'
    r'\.replace\(/_/g,\s*[\'"]/[\'"]\)', re.IGNORECASE
)


def _b64url_decode(s):
    import base64 as _b64
    s = s.replace('-', '+').replace('_', '/')
    s += '=' * (-len(s) % 4)
    return _b64.b64decode(s).decode('utf-8', errors='ignore')


def _decode_dlchan_fragment_concat(html):
    """Some mirror hosts (e.g. cdnlivetv.tv, first seen on the MLB Network
    mirror) don't use the single XOR-blob obfuscation _decode_dlchan_xor_blob
    handles — instead the stream URL is split into many small pieces, each
    independently base64-url-safe-encoded into its own var, then assembled
    via a decode-and-concatenate expression: var url=fn(v1)+fn(v2)+...+fn(vN).
    Since the real URL never appears as plaintext anywhere in the page, the
    plain-text .m3u8 regex search can never find it — this must be decoded
    piece by piece instead. Returns the assembled URL, or '' if not present."""
    fn_m = _RE_DLCHAN_B64_DECODE_FN.search(html)
    if not fn_m:
        return ''
    fn_name = fn_m.group(1)

    assembly_m = re.search(
        r'=\s*((?:%s\(\w+\)\s*\+\s*)+%s\(\w+\))\s*;' % (re.escape(fn_name), re.escape(fn_name)),
        html
    )
    if not assembly_m:
        return ''

    var_names = re.findall(r'%s\((\w+)\)' % re.escape(fn_name), assembly_m.group(1))
    if not var_names:
        return ''

    parts = []
    for vn in var_names:
        vm = re.search(r'\b%s\s*=\s*[\'"]([^\'"]+)[\'"]' % re.escape(vn), html)
        if not vm:
            return ''  # one missing fragment means we can't trust the reconstruction
        try:
            parts.append(_b64url_decode(vm.group(1)))
        except Exception:
            return ''

    url = ''.join(parts)
    return url if url.startswith('http') else ''


_TVNOW_STREAM_API = 'https://chat.cfbu247.sbs/api/resolve-dlstream/%s'
_RE_TVNOW_EMBED_SLUG = re.compile(r'tvnow247\.top/embed/([^/?#"\']+)', re.IGNORECASE)


def _tvnow_api_resolve_mirror(mirror_url):
    """Some daddylive.mov mirrors point straight back at tvnow247.top's own
    /embed/<slug> page — which is a client-rendered SPA with nothing usable
    in its static HTML (its player only gets a stream after a JS bundle
    calls out to an API). That API is a plain JSON endpoint, discovered via
    live network inspection of tvnow247.top/assets/streamService-*.js:
    GET https://chat.cfbu247.sbs/api/resolve-dlstream/<numeric channel_id>
    -> {"m3u8" or "proxyPlaylistUrl": "..."}. Far more reliable than trying
    to scrape the SPA shell itself. Returns None if this isn't a tvnow247
    embed mirror, or the channel has no live upstream right now."""
    sm = _RE_TVNOW_EMBED_SLUG.search(mirror_url)
    if not sm:
        return None
    slug = sm.group(1)
    try:
        from resources.lib import live_sources as _ls
        channel_id = next(
            (c['id'] for c in _ls.get_tvnow_channels() if c.get('slug') == slug), None)
    except Exception:
        channel_id = None
    if not channel_id:
        return None
    from resources.lib import dns_fallback as _dnsf
    try:
        # chat.cfbu247.sbs fails to resolve on some local/ISP DNS resolvers
        # even though it's live (confirmed via a public DNS resolver) —
        # _dnsf.get transparently retries via DNS-over-HTTPS on a local
        # resolution failure instead of just giving up.
        r = _dnsf.get(_TVNOW_STREAM_API % channel_id, timeout=6, headers=_HEADERS)
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tvnow stream API error (%s): %s' % (channel_id, e), xbmc.LOGWARNING)
        return None
    playlist_url = data.get('proxyPlaylistUrl') or data.get('m3u8')
    if not playlist_url:
        return None
    # The API happily returns a token even for a channel with no live upstream
    # right now (chunk.tvdaily.xyz then 502s on it) — verify it actually
    # serves before handing it to the player, same reasoning as the mirror
    # fallback fix below: better to report "no stream" than a guaranteed crash.
    try:
        check = _dnsf.get(playlist_url, timeout=6, headers=_HEADERS)
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            return None
    except Exception:
        return None
    return playlist_url


def _dlchan_resolve_mirror(mirror_url):
    """Turn one mirror-tier URL into a playable stream URL, or None.
    Handles the XOR-obfuscated JWPlayer embed pattern; falls back to a plain
    .m3u8 search for simpler mirror hosts."""
    tvnow_resolved = _tvnow_api_resolve_mirror(mirror_url)
    if tvnow_resolved:
        return tvnow_resolved

    try:
        html = _sess().get(mirror_url, timeout=6, headers=dict(
            _HEADERS, Referer=DLCHAN_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] dlchan mirror error (%s): %s' % (mirror_url, e), xbmc.LOGWARNING)
        return None

    decoded = _decode_dlchan_xor_blob(html)
    sm = _RE_DLCHAN_SIGNED_M3U8.search(decoded)
    candidate = sm.group(1) if sm else None
    if not candidate:
        sm2 = _RE_DLCHAN_ANY_M3U8.search(html)
        candidate = sm2.group(0) if sm2 else None
    if not candidate:
        # Neither the XOR blob nor a plaintext .m3u8 was present — try the
        # fragment-concatenation pattern (confirmed live on cdnlivetv.tv).
        candidate = _decode_dlchan_fragment_concat(html) or None
    if not candidate:
        return None

    # The signed CDN (fiveo4.casadenoval.uk and siblings) started rejecting
    # plain requests with a bare 403 even with a correct Referer and matching
    # signed token/timestamp — confirmed live that this isn't expiry or a
    # cookie/session requirement, it's the absence of the Sec-Fetch-*
    # "fetch metadata" headers a real browser always sends and curl/requests
    # never do by default. Adding them is enough; no TLS-fingerprint wall
    # like Cloudflare Turnstile. Verify with them before accepting the
    # mirror, and carry them along on the URL Kodi's player actually opens
    # (its own HTTP client won't send them either otherwise) via the same
    # 'url|Header=value&Header2=value' pipe-syntax used elsewhere in this
    # file for Referer/User-Agent.
    verify_headers = dict(
        _HEADERS,
        Referer=mirror_url,
        **{
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
        }
    )
    try:
        check = _sess().get(candidate, timeout=6, headers=verify_headers)
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            xbmc.log('[Starfleet/Sports] dlchan candidate failed verify (%s): HTTP %s' %
                      (mirror_url, check.status_code), xbmc.LOGWARNING)
            return None
    except Exception as e:
        xbmc.log('[Starfleet/Sports] dlchan candidate verify error (%s): %s' % (mirror_url, e), xbmc.LOGWARNING)
        return None

    import urllib.parse as _up3
    return '%s|Referer=%s&Sec-Fetch-Dest=empty&Sec-Fetch-Mode=cors&Sec-Fetch-Site=cross-site' % (
        candidate, _up3.quote(mirror_url, safe='')
    )


_RE_DLCHAN_TITLE = re.compile(r'<title>\s*([^<]+?)\s*</title>', re.IGNORECASE)
_RE_DLCHAN_TITLE_SUFFIX = re.compile(
    r'\s+(?:Live\s+Stream\s+(?:Online\s+)?Free|Watch\s+Live\s+Online\s+Free|'
    r'Live\s+TV\s+Watch\s+Free|Live\s+Stream\s+Online|Online\s+Live|'
    r'Live\s+Stream|Live\s+TV|Live).*$', re.IGNORECASE
)
_RE_DLCHAN_TITLE_PREFIX = re.compile(r'^(?:Free|Watch)\s+', re.IGNORECASE)


def _dlchan_find_mirrors(html, channel_name):
    # Mirror-list entries aren't all the same shape — some are
    # {"name":"X","url":"Y"}, others {"name":"X","id":0,"url":"Y"} (extra
    # fields in between) — so tolerate anything up to the next "url" key
    # without crossing into a different object ({[^{}]*?} stays bounded).
    rx = re.compile(
        r'"name"\s*:\s*"%s"\s*,[^{}]*?"url"\s*:\s*"([^"]+)"' % re.escape(channel_name),
        re.IGNORECASE
    )
    mirrors = []
    seen = set()
    for m in rx.finditer(html):
        u = m.group(1)
        if u not in seen:
            seen.add(u)
            mirrors.append(u)
    return mirrors


def _dlchan_stream_url(channel_id, channel_name=None):
    """Resolve a daddylive.mov channel id (e.g. 'NHL-Network', or a bare
    numeric id like '399') to a live stream URL. Not cacheable long-term —
    mirror URLs are short-lived.

    channel_name: pass this explicitly whenever the caller already knows the
    real display name (e.g. from tvnow247.top's own channel/schedule data,
    which gives {channel_id, channel_name} pairs directly). The page's mirror
    list is keyed by human-readable name, not id, so for purely-numeric ids
    the name MUST come from somewhere — and the page's own <title> tag turns
    out to use wildly inconsistent templates ("Free X Live...", "Watch X
    Online...", "X Live Stream Free...") that are unreliable to parse. Only
    fall back to guessing from the id/title when the caller has no name.
    """
    guessed_name = channel_id.replace('-', ' ').strip()
    lookup_name = channel_name.strip() if channel_name else guessed_name
    page_url = '%s/live/stream=%s' % (DLCHAN_BASE, guessed_name.replace(' ', '+'))

    try:
        html = _sess().get(page_url, timeout=8, headers=dict(
            _HEADERS, Referer=DLCHAN_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] dlchan channel page error (%s): %s' % (lookup_name, e), xbmc.LOGWARNING)
        return None

    mirrors = _dlchan_find_mirrors(html, lookup_name)

    # No caller-supplied name and the id-based guess didn't match: fall back
    # to the page's own <title> tag as a last resort (unreliable — templates
    # vary — but better than nothing for ids with no other name source).
    if not mirrors and not channel_name:
        tm = _RE_DLCHAN_TITLE.search(html)
        if tm:
            real_name = _RE_DLCHAN_TITLE_SUFFIX.sub('', tm.group(1)).strip()
            real_name = _RE_DLCHAN_TITLE_PREFIX.sub('', real_name).strip()
            if real_name and real_name.lower() != lookup_name.lower():
                mirrors = _dlchan_find_mirrors(html, real_name)
                if mirrors:
                    lookup_name = real_name

    channel_name = lookup_name
    if not mirrors:
        xbmc.log('[Starfleet/Sports] dlchan: no mirrors found for %s' % channel_name, xbmc.LOGWARNING)
        return None

    # Prefer known-decodable hosts first, then try the rest in listed order.
    mirrors.sort(key=lambda u: 0 if 'icelanders' in u else 1)

    for mirror_url in mirrors[:3]:
        resolved = _dlchan_resolve_mirror(mirror_url)
        if resolved:
            return resolved

    # Nothing decoded from any mirror. Previously this handed back the raw
    # (unresolved) mirror page URL on the theory that ResolveURL "might know
    # it" — in practice ResolveURL has no matching resolver for these mirror
    # hosts, so Kodi's player received a plain HTML page and crashed
    # immediately ("error probing input format"). Returning None instead lets
    # callers correctly drop this channel from the stream list rather than
    # offering a guaranteed-broken option.
    xbmc.log('[Starfleet/Sports] dlchan: all mirrors unresolvable for %s' % channel_name, xbmc.LOGWARNING)
    return None


def _dlchan_streams(event_path):
    """event_path format: 'dlchan:<channel-id>' e.g. 'dlchan:NHL-Network'."""
    channel_id = event_path.replace('dlchan:', '', 1)
    url = _dlchan_stream_url(channel_id)
    if not url:
        return []
    return [{
        'label': 'DaddyLive — Live 24/7',
        'url': url,
        'quality': '',
        'language': '',
        'source': 'DaddyLive',
    }]


def _dlchan_multi_streams(event_path):
    """event_path format: 'dlchan_multi:<id1>|<id2>|<id3>', where each entry
    is either a bare id/slug ('MLB-Network') or 'id=Real Channel Name' when
    the caller already knows the exact name (preferred — the id-guess and
    <title>-tag fallback inside _dlchan_stream_url are both unreliable for
    purely numeric ids). Resolves each in parallel, returns one stream entry
    per id labeled Link 1/Link 2/Link 3 (etc)."""
    entries = event_path.replace('dlchan_multi:', '', 1).split('|')
    entries = [e for e in entries if e]
    if not entries:
        return []

    def _split(entry):
        if '=' in entry:
            cid, name = entry.split('=', 1)
            return cid, name
        return entry, None

    results = [None] * len(entries)
    with ThreadPoolExecutor(max_workers=len(entries)) as ex:
        futs = {}
        for i, entry in enumerate(entries):
            cid, name = _split(entry)
            futs[ex.submit(_dlchan_stream_url, cid, name)] = i
        for fut in futs:
            i = futs[fut]
            try:
                results[i] = fut.result(timeout=10)
            except Exception as e:
                xbmc.log('[Starfleet/Sports] dlchan_multi error (%s): %s' % (entries[i], e), xbmc.LOGWARNING)

    streams = []
    for i, url in enumerate(results):
        if url:
            streams.append({
                'label': 'Link %d' % (i + 1),
                'url': url,
                'quality': '',
                'language': '',
                'source': 'DaddyLive',
            })
    return streams


# ── tvnow247.top events (schedule.json — same DaddyLive channel_id scheme) ────
#
# tvnow247.top (aka tv247us.live) publishes a clean JSON schedule at
# /schedule.json: {date_label: {category_label: [{time, event, channels:[
# {channel_id, channel_name}], channels2:[...]}]}}. Its channel_ids are the
# SAME numbering as daddylive.mov (verified: channel_id 663 = "NHL Network
# USA" on both), so events resolve through the existing _dlchan_stream_url
# chain — no separate resolver needed, just category → sport_slug tagging
# and a dlchan_multi: path per event (one link per listed channel/mirror).

_TVNOW_SCHEDULE_URL = 'https://tvnow247.top/schedule.json'

# category label keyword (lowercased) → sport_slug, matched against this
# addon's existing sport categories (sports_router / _CATEGORIES above)
_TVNOW_CATEGORY_SPORT_MAP = [
    ('soccer', 'soccer'), ('football ⚽', 'soccer'), ('premier league', 'soccer'),
    ('hockey', 'nhl'), ('nhl', 'nhl'),
    ('basketball', 'nba'), ('nba', 'nba'),
    ('baseball', 'mlb'), ('mlb', 'mlb'),
    ('nfl', 'nfl'), ('american football', 'nfl'),
    ('ufc', 'ufc'), ('mma', 'ufc'),
    ('boxing', 'boxing'),
    ('tennis', 'tennis'), ('atp', 'tennis'), ('wta', 'tennis'),
    ('cricket', 'cricket'),
    ('rugby', 'rugby'),
    ('darts', 'darts'),
    ('golf', 'golf'),
    ('snooker', 'snooker'),
    ('handball', 'handball'),
    ('volleyball', 'volleyball'),
    ('cycling', 'cycling'),
    ('f1', 'f1'), ('formula 1', 'f1'), ('formula1', 'f1'),
    ('motogp', 'motogp'),
    # deliberately NOT ('motorsport', 'f1') — confirmed live: tvnow's generic
    # "Motorsport" category mixes Formula E/DTM/Rally/GT4/Stock Car/etc.
    # together, not just F1, so attributing the whole bucket to F1 was
    # wrong. Left uncategorized (None) rather than guessed incorrectly.
    ('nascar', 'f1'),
    ('college football', 'cfb'), ('cfb', 'cfb'),
    ('college basketball', 'ncaab'), ('ncaab', 'ncaab'),
    ('cfl', 'cfl'),
    ('wwe', 'wwe'), ('wrestling', 'wwe'),
]


def _tvnow_detect_sport(category_label):
    lbl = (category_label or '').lower()
    for kw, slug in _TVNOW_CATEGORY_SPORT_MAP:
        if kw in lbl:
            return slug
    return None


def _tvnow_events():
    """Fetch + flatten tvnow247.top's schedule.json into a list of event dicts,
    each tagged with a best-guess sport_slug (None if uncategorizable — e.g.
    PPV motorsport/wrestling one-offs, TV show listings). Cached 15 min."""
    ck = 'tvnow_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    events = []
    try:
        r = _sess().get(_TVNOW_SCHEDULE_URL, timeout=12, headers=_HEADERS)
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tvnow schedule fetch error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, [], 5 * 60)
        return []

    for _date_label, cats in (data or {}).items():
        if not isinstance(cats, dict):
            continue
        # _date_label looks like "Saturday 25th July 2026 - Schedule Time UK
        # GMT" — extract day/month/year once per date group and combine with
        # each event's own "HH:MM" time field to get a real timestamp.
        # Previously this was never parsed at all (start_ts hardcoded to 0),
        # so every tvnow-sourced event showed as TBD even when correctly
        # categorized. Treated as UTC (site labels it GMT year-round; no
        # confirmed BST adjustment, same precision limitation already
        # accepted elsewhere for HH:MM-only sources).
        day_ts_base = None
        m_date = re.search(r'(\d{1,2})\w{0,2}\s+([A-Za-z]+)\s+(\d{4})', _date_label)
        if m_date:
            try:
                day_dt = datetime.datetime.strptime(
                    '%s %s %s' % (m_date.group(1), m_date.group(2), m_date.group(3)), '%d %B %Y')
                day_ts_base = int((day_dt - datetime.datetime(1970, 1, 1)).total_seconds())
            except Exception:
                day_ts_base = None

        for cat_label, evs in cats.items():
            sport_slug = _tvnow_detect_sport(cat_label)
            for ev in (evs or []):
                channels = ev.get('channels') or []
                # 'id=Name' when the schedule gives us a channel_name (it always
                # does) — _dlchan_stream_url needs the real name for numeric
                # ids since the page's own <title> tag is unreliable to parse.
                entries = [
                    '%s=%s' % (c['channel_id'], c['channel_name']) if c.get('channel_name')
                    else c['channel_id']
                    for c in channels if c.get('channel_id')
                ]
                if not entries:
                    continue
                cid0 = channels[0]['channel_id']
                title = ev.get('event', '')
                if not title:
                    continue

                start_ts = 0
                if day_ts_base is not None:
                    m_time = re.match(r'^(\d{1,2}):(\d{2})$', (ev.get('time') or '').strip())
                    if m_time:
                        start_ts = day_ts_base + int(m_time.group(1)) * 3600 + int(m_time.group(2)) * 60

                events.append({
                    'id':         'tvnow_%s' % cid0,
                    'slug':       'tvnow_%s' % cid0,
                    'path':       'dlchan_multi:' + '|'.join(entries),
                    'title':      title,
                    'league':     cat_label,
                    'sport_slug': sport_slug,
                    'logo':       '',
                    'is_live':    False,
                    'start_ts':   start_ts,
                    'date_label': ev.get('time', ''),
                })

    xbmc.log('[Starfleet/Sports] tvnow: %d events across %d categorized' % (
        len(events), sum(1 for e in events if e['sport_slug'])), xbmc.LOGINFO)
    _cache.set(ck, events, 15 * 60)
    return events


def _tvnow_events_for_sport(sport_slug):
    """Events from tvnow247.top's schedule tagged as belonging to sport_slug —
    used to supplement get_sport_events() with a real event listing (not just
    a stream-source fallback)."""
    try:
        return [e for e in _tvnow_events() if e.get('sport_slug') == sport_slug]
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tvnow_events_for_sport error: %s' % e, xbmc.LOGWARNING)
        return []


def _tvnow_streams_by_title(event_title):
    """Cross-reference: find a tvnow247.top event by title match (any sport)
    and resolve all its listed channels as stream options."""
    try:
        evs = _tvnow_events()
    except Exception:
        return []
    best, best_score = None, 0
    for e in evs:
        score = _title_score(event_title, e['title'])
        if score > best_score:
            best_score = score
            best = e
    if not best or best_score < 2:
        return []
    return _dlchan_multi_streams(best['path'])


# ── streame.center resolver ───────────────────────────────────────────────────
#
# streame.center is a shared backend embed host that several front-end sites
# (powerstreams.site, realsportshd.buzz, and likely others) point at for many
# sports, not just MLB — but none of those front-ends expose a scrapable
# schedule of their own (one 403s outright, the other is a static link
# directory with no game listing). Rather than write a discovery scraper per
# front-end, this is applied as a universal post-processing step in
# get_event_streams: whenever ANY existing source (CrackStreams, StreamsEast,
# etc, across every sport they already cover) happens to hand back a
# streame.center-hosted embed link, resolve it here instead of returning the
# dead embed page. That gets every sport's coverage for free instead of one
# per-site scraper each.
#
# Chain: <front-end>/.../NN.html -> iframe streame.center/embed/chNN.php ->
# iframe streame.center/embed/hls.php?stream=<id> -> that page's own inline
# script already contains a plaintext base64 'input' blob (no JS/decryption
# needed on our end) which a plain POST to decrypt.php exchanges for a
# direct, real HLS URL — verified live, no WASM/P2P wall like embed.st.
# The resolved URL only actually serves segments with a matching Referer
# header, so that's carried along via Kodi's 'url|Referer=' pipe syntax.

_RE_STREAMECENTER_CH    = re.compile(r'streame\.center/embed/ch\d+\.php')
_RE_STREAMECENTER_HLS   = re.compile(r'streame\.center/embed/hls\.php\?[^"\'\s]+')
_RE_STREAMECENTER_INPUT = re.compile(r'input\s*:\s*"([^"]+)"')
_RE_STREAMECENTER_ANY   = re.compile(r'streame\.center/embed/\S+?\.php(?:\?[^"\'\s<]*)?')

# Confirmed white-label front-ends that just iframe straight through to a
# streame.center channel (same "NN.html"/"NN.php" per-game index across all
# three — one shared backend, several branded wrapper sites).
_STREAMECENTER_WRAPPER_HOSTS = ('powerstreams.site', 'realsportshd.buzz', 'crack-streams.site', 'streame.center')


def _resolve_streame_center(url):
    """Turn a streame.center embed URL — or one of its known wrapper front-
    ends (powerstreams.site/realsportshd.buzz/crack-streams.site, which just
    iframe straight to a streame.center channel) — into a direct, playable
    HLS URL tagged with the Referer it needs to actually serve. Returns None
    if this isn't a recognized link or resolution fails at any hop."""
    if not any(h in url for h in _STREAMECENTER_WRAPPER_HOSTS):
        return None

    if 'streame.center' not in url:
        # Wrapper front-end page — fetch it and pull out the streame.center
        # iframe it embeds, then continue exactly as if we'd started there.
        try:
            wrapper_html = _sess().get(url, timeout=8, headers=dict(_HEADERS, Referer=url)).text
        except Exception as e:
            xbmc.log('[Starfleet/Sports] streame.center wrapper fetch error (%s): %s' % (url, e), xbmc.LOGWARNING)
            return None
        m = _RE_STREAMECENTER_ANY.search(wrapper_html)
        if not m:
            return None
        url = 'https://' + m.group(0)

    try:
        html = _sess().get(url, timeout=8, headers=dict(_HEADERS, Referer='https://streame.center/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] streame.center fetch error (%s): %s' % (url, e), xbmc.LOGWARNING)
        return None

    hls_url = url
    if 'hls.php' not in url:
        m = _RE_STREAMECENTER_HLS.search(html)
        if not m:
            return None
        hls_url = 'https://' + m.group(0)
        try:
            html = _sess().get(hls_url, timeout=8, headers=dict(_HEADERS, Referer=url)).text
        except Exception as e:
            xbmc.log('[Starfleet/Sports] streame.center hls fetch error: %s' % e, xbmc.LOGWARNING)
            return None

    m = _RE_STREAMECENTER_INPUT.search(html)
    if not m:
        return None
    try:
        r = _sess().post('https://streame.center/embed/decrypt.php', data={'input': m.group(1)},
                          timeout=8, headers=dict(_HEADERS, Referer=hls_url))
        m3u8 = r.text.strip()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] streame.center decrypt error: %s' % e, xbmc.LOGWARNING)
        return None
    if not m3u8.startswith('http'):
        return None
    return m3u8 + '|Referer=https://streame.center/'


# ── daddylive.li sports events (live, in-addon — no scraper-PC dependency) ────
#
# Ported 2026-08-10 from the standalone scraper-PC fix for this exact site.
# daddylive.li's own schedule API only ever sets time=='Live' on events under
# its "Popular Live Events" bucket — every sport's own category listing keeps
# showing the original scheduled clock time even hours after the game
# started — but "Popular Live Events" entries use path-style PPV embed ids
# (admin/ppv-..., delta/...) whose embed.st hop now serves an ad-interstitial
# iframe (/ad.html) instead of the real player iframe in its static HTML,
# breaking the plain-HTTP resolve chain for every one of them. The SAME game
# is *also* listed under its own sport's category with ordinary numeric
# channel ids (e.g. "845" = NBC Universo) that still resolve fine — confirmed
# live end-to-end (3/3 real m3u8s resolved for a currently-live MLB game via
# that duplicate). So: the "Live" flag only decides WHICH games to list, and
# the actual channel list always comes from whichever same-game duplicate
# (matched by normalized team-name set, any category) has the most channels.
#
# No browser needed anywhere in this chain — confirmed live 2026-08-03 that
# daddylive.li's embed.php pages block Playwright outright via an anti-debug
# script, but a plain requests.get() never triggers it, and the real resolve
# chain is 3 static-HTML hops + one window.atob() base64 decode.

_DL_EVENTS_URL = 'https://daddylive.li/api/events'
_DL_API_BASE   = 'https://daddylive.li'

_DL_CAT_MAP = {
    'baseball': 'mlb', 'mlb': 'mlb',
    'football': 'soccer', 'soccer': 'soccer',
    'basketball': 'nba', 'nba': 'nba', 'wnba': 'wnba',
    'hockey': 'nhl', 'nhl': 'nhl',
    'nfl': 'nfl', 'american football': 'nfl',
    'ufc': 'ufc', 'mma': 'ufc', 'boxing': 'boxing',
    'wrestling': 'wwe', 'wwe': 'wwe', 'aew': 'wwe',
    'tennis': 'tennis', 'golf': 'golf', 'cricket': 'cricket',
    'rugby': 'rugby', 'motorsport': 'motorsports',
    'f1': 'motorsports', 'formula': 'motorsports',
    'darts': 'darts', 'cfl': 'cfl',
}

_RE_DL_CAT_PREFIX = re.compile(r'^[^:]+:\s*')
_RE_DL_IFRAME_SRC = re.compile(r'<iframe[^>]+src="([^"]+)"', re.IGNORECASE)
_RE_DL_ATOB_CALL  = re.compile(r"atob\(['\"]([A-Za-z0-9+/=]{20,})['\"]\)")


def _dl_map_sport_category(cat_text, event_title=''):
    blob = ('%s %s' % (cat_text or '', event_title or '')).lower()
    m = re.match(r'^([^:]+):', event_title or '')
    if m:
        blob = m.group(1).lower() + ' ' + blob
    for key, slug in _DL_CAT_MAP.items():
        if key in blob:
            return slug
    return None


def _dl_norm_teams(title):
    import unicodedata
    t = _RE_DL_CAT_PREFIX.sub('', title or '')
    t = ''.join(c for c in unicodedata.normalize('NFKD', t) if not unicodedata.combining(c))
    t = ''.join(c for c in t if ord(c) < 128)
    t = re.sub(r'[^a-z0-9\s]', ' ', t.lower())
    return frozenset(t.split())


def _dl_resolve_embed(embed_url, timeout_s=15):
    """3 static-HTML hops + one atob() decode, no browser needed. Returns a
    playable URL (Referer/User-Agent pipe-tagged for Kodi's player) or None."""
    try:
        r1 = _sess().get(embed_url, timeout=timeout_s, headers=dict(_HEADERS, Referer=_DL_API_BASE + '/'))
        m1 = _RE_DL_IFRAME_SRC.search(r1.text)
        if not m1:
            return None
        hop2_url = m1.group(1)

        r2 = _sess().get(hop2_url, timeout=timeout_s, headers=dict(_HEADERS, Referer=embed_url))
        m2 = _RE_DL_IFRAME_SRC.search(r2.text)
        if not m2:
            return None
        hop3_url = m2.group(1)

        r3 = _sess().get(hop3_url, timeout=timeout_s, headers=dict(_HEADERS, Referer=hop2_url))
        m3 = _RE_DL_ATOB_CALL.search(r3.text)
        if not m3:
            return None
        import base64 as _b64
        m3u8 = _b64.b64decode(m3.group(1)).decode('utf-8', 'ignore')
        if not m3u8.startswith('http'):
            return None

        check = _sess().get(m3u8, timeout=timeout_s, headers=dict(_HEADERS, Referer=hop3_url))
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            return None

        import urllib.parse as _up_dl
        return '%s|Referer=%s&User-Agent=%s' % (
            m3u8, _up_dl.quote(hop3_url, safe=''), _up_dl.quote(_HEADERS['User-Agent'], safe='')
        )
    except Exception as e:
        xbmc.log('[Starfleet/Sports] daddylive embed resolve error: %s' % e, xbmc.LOGWARNING)
        return None


def _dl_schedule():
    """Fetch + cache daddylive.li's full day schedule (10 min, matches this
    file's event-list cache convention)."""
    ck = 'dlsports_schedule_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        r = _sess().get(_DL_EVENTS_URL, timeout=12, headers=_HEADERS)
        days = r.json()
        if not isinstance(days, list):
            days = []
    except Exception as e:
        xbmc.log('[Starfleet/Sports] daddylive schedule fetch error: %s' % e, xbmc.LOGWARNING)
        days = []
    _cache.set(ck, days, 10 * 60)
    return days


_RE_DL_DAY_DATE = re.compile(r'(\d{1,2})\w{0,2}\s+([A-Za-z]+)\s+(\d{4})')
# How long after its scheduled kickoff a game is still treated as "live" —
# generous enough to cover MLB extra innings / NHL overtime / a delayed
# start without matching yesterday's already-finished games.
_DL_LIVE_WINDOW_AFTER_SECS = 5 * 3600
# daddylive's own listed kickoff can genuinely run a bit later than this
# addon's own (ESPN-derived) event data — confirmed live: a real MLB game
# already showing "LIVE NOW" on the Sports screen was still 12 minutes
# ahead of daddylive's own listed start time for the exact same game. A
# small pre-game allowance avoids missing an event purely because the two
# sources' clocks don't quite agree, without being wide enough to start
# matching a genuinely different, much-later game with the same category.
_DL_LIVE_WINDOW_BEFORE_SECS = 45 * 60


def _dl_live_index():
    """Build (slug, normalized-teams) -> best-channeled duplicate index, plus
    the list of events considered live right now, from the cached schedule.
    Cached alongside the schedule fetch itself (same 10 min window) so
    get_sport_events() and get_event_streams() share one fetch+parse.

    Confirmed live 2026-08-14: daddylive.li's explicit time=='Live' flag is
    now only ever set on its curated "Popular Live Events" bucket, which at
    any given moment might contain as few as 1-2 games total across EVERY
    sport combined — a real MLB game with 4 real channels, listed under its
    own "Baseball (MLB)" category, still showed its original scheduled
    clock time ("22:40") hours after first pitch, so it never made it into
    live_events at all even though best_by_key already had its full channel
    list. Matches this addon's own already-documented finding above ("every
    sport's own category listing keeps showing the original scheduled clock
    time even hours after the game started") but that comment only explains
    why the channel LIST still needs the best-of-any-category lookup — it
    doesn't fix the separate problem that the "Live" flag alone decides
    which games are even attempted, effectively making almost all sports
    invisible whenever that curated bucket is this sparse. Same date-header
    parsing convention as _tvnow_schedule() above (day label + HH:MM,
    treated as UTC — the site labels it GMT year-round)."""
    ck = 'dlsports_index_v2'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    now_utc_ts = int((datetime.datetime.utcnow() - datetime.datetime(1970, 1, 1)).total_seconds())

    days = _dl_schedule()
    best_by_key = {}
    live_events = []
    seen_live_keys = set()
    for day in days:
        cats = day.get('categories') or {}
        if not isinstance(cats, dict):
            continue

        day_ts_base = None
        m_date = _RE_DL_DAY_DATE.search(day.get('day') or '')
        if m_date:
            try:
                day_dt = datetime.datetime.strptime(
                    '%s %s %s' % (m_date.group(1), m_date.group(2), m_date.group(3)), '%d %B %Y')
                day_ts_base = int((day_dt - datetime.datetime(1970, 1, 1)).total_seconds())
            except Exception:
                day_ts_base = None

        for cat_name, evs in cats.items():
            for ev in evs or []:
                title = (ev.get('event') or '').strip()
                if not title:
                    continue
                slug = _dl_map_sport_category(cat_name, title)
                if not slug:
                    continue
                key = (slug, _dl_norm_teams(title))
                chans = ev.get('channels') or []
                prev = best_by_key.get(key)
                if prev is None or len(chans) > len(prev.get('channels') or []):
                    best_by_key[key] = ev

                ev_time = (ev.get('time') or '').strip()
                is_live = ev_time.lower() == 'live'
                if not is_live and day_ts_base is not None:
                    m_time = re.match(r'^(\d{1,2}):(\d{2})$', ev_time)
                    if m_time:
                        start_ts = day_ts_base + int(m_time.group(1)) * 3600 + int(m_time.group(2)) * 60
                        is_live = -_DL_LIVE_WINDOW_BEFORE_SECS <= (now_utc_ts - start_ts) <= _DL_LIVE_WINDOW_AFTER_SECS
                if is_live and key not in seen_live_keys:
                    seen_live_keys.add(key)
                    live_events.append((slug, key, title))

    result = (best_by_key, live_events)
    _cache.set(ck, result, 10 * 60)
    return result


def _dl_streams_by_title(sport_slug, event_title):
    """Cross-reference: this addon's OWN event (from ESPN/official APIs/etc,
    already listed in get_sport_events()) against daddylive.li's currently-
    Live events for the same sport, by fuzzy title match — DaddyLive never
    gets its own separate listing, it only contributes source options onto
    whatever event the user already opened, same pattern as
    _tvnow_streams_by_title / _onhockey_streams_by_title below."""
    if not event_title:
        return []
    try:
        best_by_key, live_events = _dl_live_index()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] daddylive index error: %s' % e, xbmc.LOGWARNING)
        return []

    best_key, best_score = None, 0
    for slug, key, title in live_events:
        if slug != sport_slug:
            continue
        score = _title_score(event_title, title)
        if score > best_score:
            best_score = score
            best_key = key
    if not best_key or best_score < 2:
        return []

    best_ev = best_by_key.get(best_key)
    chans = (best_ev.get('channels') or []) if best_ev else []
    if not chans:
        return []

    streams = []
    # Same 'with ThreadPoolExecutor(...) as ex' issue already fixed
    # elsewhere this session — breaking out of the loop early (once 3
    # streams resolve) still left the pool's own __exit__ waiting on every
    # OTHER still-running channel resolve before this function could
    # return. as_completed + shutdown(wait=False) caps it properly.
    ex = ThreadPoolExecutor(max_workers=min(len(chans), 6))
    futs = {}
    for ch in chans:
        url = (ch.get('url') or '').strip()
        if not url:
            continue
        futs[ex.submit(_dl_resolve_embed, url)] = ch.get('channel_name') or 'Stream'
    try:
        for fut in as_completed(futs, timeout=18):
            label = futs[fut]
            try:
                resolved = fut.result()
            except Exception:
                resolved = None
            if resolved:
                streams.append({
                    'label': label,
                    'url': resolved,
                    'quality': '',
                    'language': '',
                    'source': 'DaddyLive',
                })
            if len(streams) >= 3:
                break
    except Exception:
        pass
    finally:
        ex.shutdown(wait=False)
    return streams


# ── falconstreams.app (Next.js aggregator, dozens of mirror links per match) ──
#
# Added 2026-08-10. Its homepage server-renders a "Streaming Now" section
# (no browser/JS needed — the game cards are plain static HTML with a real
# href per match) and each match page embeds a matchData JSON blob (React
# Server Component payload, quote-escaped in the raw HTML) listing dozens of
# candidate mirror links per game across many differently-named front-ends
# (prostreams.best, streamrush.top, worldstreams.cc, 1ststreams.space, etc —
# mostly clones of the same handful of backends, going by identical URL date
# slugs across them). Confirmed live: at least one of them (prostreams.best)
# resolves through the EXACT SAME iframe->iframe->atob() chain as
# daddylive.li above (same CDN even — hamis.*.st/premiumtv/... -> atob() ->
# xameleon.*.top/.../index.m3u8) — no separate resolver needed, _dl_resolve_
# embed() already handles it since that function doesn't care which site an
# embed URL came from. No per-domain special-casing: just throw every
# candidate link at the same resolver in parallel and keep whichever ones
# actually decode to a real, verified m3u8 (most won't — dead/seized domains,
# different chains entirely — that's expected, same "resolve what resolves"
# treatment as everywhere else in this file).

_FALCON_BASE = 'https://falconstreams.app'
_FALCON_HOME = _FALCON_BASE + '/v3'

_RE_FALCON_CARD = re.compile(
    r'aria-label="Watch ([^"]+?) live stream[^"]*"[^>]*?href="(/live/([a-z0-9-]+)/match/[a-z0-9-]+/[a-f0-9]+)"'
)
_RE_FALCON_LINK = re.compile(r'\\"link\\":\\"(https?://[^"\\]+)')

_FALCON_LEAGUE_KEYWORDS = {
    # 'wnba' must be checked before 'nba' — it's a substring match otherwise
    'wnba': 'wnba', 'mlb': 'mlb', 'nba': 'nba', 'nfl': 'nfl', 'nhl': 'nhl',
    'ufc': 'ufc', 'mma': 'ufc', 'boxing': 'boxing',
    'f1': 'motorsports', 'formula': 'motorsports', 'motogp': 'motorsports',
    'tennis': 'tennis', 'golf': 'golf', 'cricket': 'cricket', 'rugby': 'rugby',
    'wwe': 'wwe', 'aew': 'wwe',
    # soccer league slugs (no single generic 'soccer' league name on this site)
    'liga': 'soccer', 'league': 'soccer', 'cup': 'soccer', 'premier': 'soccer',
    'friendly': 'soccer', 'mls': 'soccer', 'seria': 'soccer', 'bundesliga': 'soccer',
}


def _falcon_map_league(league_slug):
    blob = (league_slug or '').replace('-', ' ').lower()
    for kw, slug in _FALCON_LEAGUE_KEYWORDS.items():
        if kw in blob:
            return slug
    return None


def _falcon_events():
    """Fetch + cache (10 min) FalconStreams' homepage 'Streaming Now' list —
    only whatever's currently featured, same "Live flag decides which games,
    not the whole schedule" shape as daddylive.li above."""
    ck = 'falcon_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _sess().get(_FALCON_HOME, timeout=12, headers=_HEADERS).text
        events = []
        for title, href, league in _RE_FALCON_CARD.findall(html):
            slug = _falcon_map_league(league)
            if not slug:
                continue
            events.append({'slug': slug, 'title': title, 'href': href})
    except Exception as e:
        xbmc.log('[Starfleet/Sports] falconstreams events error: %s' % e, xbmc.LOGWARNING)
        events = []
    _cache.set(ck, events, 10 * 60)
    return events


def _falcon_match_links(href):
    """Fetch + cache (10 min) one match page's full candidate mirror-link
    list."""
    ck = 'falcon_links_%s' % href
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _sess().get(_FALCON_BASE + href, timeout=12, headers=_HEADERS).text
        links = list(dict.fromkeys(_RE_FALCON_LINK.findall(html)))  # de-dup, keep order
    except Exception as e:
        xbmc.log('[Starfleet/Sports] falconstreams match links error (%s): %s' % (href, e), xbmc.LOGWARNING)
        links = []
    _cache.set(ck, links, 10 * 60)
    return links


def _falcon_link_mismatched(url, team_words):
    """True if the URL's own path names a specific team-vs-team matchup that
    shares no words with the target event — defensive filter for
    FalconStreams' own directStreams data occasionally mixing in an
    unrelated match's link under the current match's entry. Confirmed live
    2026-08-13: the "Sportszone" mirror entry for a Miami Marlins vs
    Pittsburgh Pirates match page pointed at a completely unrelated
    mirassol-vs-corinthians SOCCER match, sitting right inside that match's
    own matchData.directStreams array — a data bug on FalconStreams' end,
    not a link-extraction scoping issue in this addon's regex. Since the
    resolver has no way to inspect actual video content, this URL-slug
    sanity check is the only defense available. Links with no descriptive
    "-vs-" slug (the numeric ?p=NNNN style mirrors) carry no team info to
    check and are always left alone."""
    import urllib.parse as _up_falcon
    path = _up_falcon.urlparse(url).path.lower()
    if '-vs-' not in path and '/vs/' not in path:
        return False
    slug_words = set(re.sub(r'[^a-z0-9]+', ' ', path).split()) - {'vs'}
    return bool(slug_words) and not (slug_words & team_words)


def _falcon_streams_by_title(sport_slug, event_title):
    """Cross-reference: this addon's OWN event against FalconStreams' current
    Streaming Now list by fuzzy title match, then try every candidate mirror
    link through the shared daddylive resolver — same title-match-onto-
    existing-event pattern as _dl_streams_by_title above, no separate
    listing of its own."""
    if not event_title:
        return []
    try:
        events = _falcon_events()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] falconstreams index error: %s' % e, xbmc.LOGWARNING)
        return []

    best_ev, best_score = None, 0
    for ev in events:
        if ev['slug'] != sport_slug:
            continue
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_ev = ev
    if not best_ev or best_score < 2:
        return []

    try:
        links = _falcon_match_links(best_ev['href'])
    except Exception as e:
        xbmc.log('[Starfleet/Sports] falconstreams links error: %s' % e, xbmc.LOGWARNING)
        return []
    if not links:
        return []

    team_words = _dl_norm_teams(best_ev['title']) - {'vs'}
    links = [u for u in links if not _falcon_link_mismatched(u, team_words)]
    if not links:
        return []

    streams = []
    with ThreadPoolExecutor(max_workers=min(len(links), 10)) as ex:
        futs = {ex.submit(_dl_resolve_embed, url): url for url in links}
        for fut in futs:
            if len(streams) >= 3:
                break
            url = futs[fut]
            try:
                resolved = fut.result(timeout=18)
            except Exception:
                resolved = None
            if resolved:
                import urllib.parse as _up_falcon
                host = _up_falcon.urlparse(url).netloc
                streams.append({
                    'label': 'FalconStreams (%s)' % host,
                    'url': resolved,
                    'quality': '',
                    'language': '',
                    'source': 'FalconStreams',
                })
    return streams


# ── timstreams.st (clean JSON API — needs no new resolver at all) ────────────
#
# Added 2026-08-10. Its own /api/live-upcoming endpoint is a clean, documented
# REST API (no obfuscation on the schedule side at all) returning real events
# plus a genres/sub_categories list baked right into the same response. Each
# event's streams[].url points at a small embed wrapper (cdx-08192.website
# seen live, likely rotates) whose player init script turns out to be the
# EXACT SAME int-array XOR-cipher (key, then offset, mod 256) already
# decoded by _decode_dlchan_xor_blob()/_dlchan_resolve_mirror() above for
# daddylive.mov's 24/7 channels — confirmed live byte-for-byte identical
# formula. So this needs zero new resolver code: just fetch the schedule and
# hand each stream URL to the resolver that's already shipped.

_TIM_BASE = 'https://timstreams.st'
_TIM_API  = _TIM_BASE + '/api/live-upcoming'

# Genre id -> our sport slug (from the API's own /api/live-upcoming 'genres'
# list). Genre 7 "Basketball" covers both NBA and WNBA with no sub-category
# to tell them apart, so that one's resolved by team-name keyword instead.
_TIM_GENRE_MAP = {
    1: 'soccer', 2: 'motorsports', 3: 'ufc', 4: 'boxing', 5: 'boxing',
    6: 'wwe', 8: 'nfl', 9: 'mlb', 10: 'tennis', 11: 'nhl', 12: 'darts',
    13: 'cricket', 15: 'rugby', 16: 'rugby',
}
_TIM_WNBA_KEYWORDS = (
    'wnba', 'storm', 'sky', 'sparks', 'liberty', 'aces', 'lynx',
    'fever', 'mystics', 'mercury', 'sun', 'wings', 'dream', 'tempo',
)


def _tim_map_genre(genre_id, title):
    if genre_id == 7:
        t = (title or '').lower()
        return 'wnba' if any(k in t for k in _TIM_WNBA_KEYWORDS) else 'nba'
    return _TIM_GENRE_MAP.get(genre_id)


def _tim_events():
    """Fetch + cache (10 min) timstreams.st's live/upcoming event list."""
    ck = 'tim_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    events = []
    try:
        data = _sess().get(_TIM_API, timeout=12, headers=dict(_HEADERS, Referer=_TIM_BASE + '/')).json()
        for ev in data.get('events') or []:
            title = ev.get('name') or ''
            if not title:
                continue
            slug = _tim_map_genre(ev.get('genre'), title)
            if not slug:
                continue
            stream_urls = [s.get('url') for s in (ev.get('streams') or []) if s.get('url')]
            if not stream_urls:
                continue
            events.append({'slug': slug, 'title': title, 'streams': stream_urls})
    except Exception as e:
        xbmc.log('[Starfleet/Sports] timstreams events error: %s' % e, xbmc.LOGWARNING)
        events = []
    _cache.set(ck, events, 10 * 60)
    return events


def _tim_streams_by_title(sport_slug, event_title):
    """Cross-reference by fuzzy title match, same pattern as the DaddyLive/
    FalconStreams sources above — no separate listing of its own."""
    if not event_title:
        return []
    try:
        events = _tim_events()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] timstreams index error: %s' % e, xbmc.LOGWARNING)
        return []

    best_ev, best_score = None, 0
    for ev in events:
        if ev['slug'] != sport_slug:
            continue
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_ev = ev
    if not best_ev or best_score < 2:
        return []

    streams = []
    with ThreadPoolExecutor(max_workers=min(len(best_ev['streams']), 6)) as ex:
        futs = {ex.submit(_dlchan_resolve_mirror, u): u for u in best_ev['streams']}
        for fut in futs:
            if len(streams) >= 3:
                break
            try:
                resolved = fut.result(timeout=15)
            except Exception:
                resolved = None
            if resolved:
                streams.append({
                    'label': 'TimStreams',
                    'url': resolved,
                    'quality': '',
                    'language': '',
                    'source': 'TimStreams',
                })
    return streams


# ── v2.sportsurge.net (Cloudflare Turnstile-gated aggregator) ─────────────────
#
# This site has the real, complete per-game provider table (StreamEast,
# CrackStreams, all the branded resellers, etc) — but it's behind Cloudflare
# Turnstile, which genuinely can't be solved by a script (verified multiple
# ways: cloudscraper's own challenge detectors don't even recognize this
# page's current markup; TLS-fingerprint spoofing still gets the challenge
# page). The one legitimate way through: a real browser passes Turnstile on
# its own, and the cf_clearance cookie it earns is reusable for a while
# (Cloudflare issues it per-session, not per-request). The user pastes that
# cookie (DevTools -> Application -> Cookies -> cf_clearance) into this
# addon's settings; while it's still valid, this scrapes the real listing
# and provider table. Once it expires this source just finds nothing, same
# as any other source with nothing to offer — no crash, no error shown.

_SPORTSURGE_BASE = 'https://v2.sportsurge.net'
_SPORTSURGE_SLUGS = {
    'nfl': 'list6-nfl', 'nba': 'list6-basketball', 'mlb': 'list6-baseball',
    'nhl': 'list6-hockey', 'boxing': 'list6-boxing', 'mma': 'list6-mma',
    'wwe': 'list6-wwe', 'cfb': 'list6-cfb', 'cfl': 'list6-cfl',
    'ncaab': 'list6-ncaab', 'wnba': 'list6-wnba', 'f1': 'list6-f1',
}

# Confirmed live 2026-08-09 both of these were completely broken (0 matches
# each) against the site's CURRENT html — not a Cloudflare/cookie problem,
# a real markup drift. Game rows now use class="match-row" (no "row "
# prefix the old regex required, with extra data-category/data-search
# attributes in between class and title that broke the old immediately-
# adjacent match too). Stream rows dropped the old '<h4>name</h4>' entirely
# in favor of double-quoted data-href + a nested
# <span class="stream-row-site-name">name</span> — found by directly
# inspecting a real, live watch page (MLB Guardians @ White Sox) after a
# user report that a genuinely live game wasn't showing up; confirmed the
# game and its real stream list (24 sources, including Streameast) really
# are on the page, the old regexes just couldn't see any of it.
_RE_SPORTSURGE_GAME = re.compile(
    r'href="(watch-\d+-[^"]+)"\s+class="match-row"[^>]*?title="([^"]+)"'
)
_RE_SPORTSURGE_ROW = re.compile(
    r'data-href="([^"]+)"[^>]*>.*?<span class="stream-row-site-name">([^<]+)</span>',
    re.DOTALL
)


_SPORTSURGE_AUTO_COOKIE_URL = 'https://hazmat77.github.io/repository.starfleet/data/sportsurge_cookie.json'


def _sportsurge_auto_cookie():
    """The scraper-PC-refreshed cf_clearance+UA pair (scraper_sportsurge_
    cookie.py — real headed Chrome, refreshed every ~2h, confirmed live to
    reliably pass v2.sportsurge.net's Cloudflare Managed Challenge, which no
    headless/automated approach could). Cached 30 min so ordinary sports
    browsing doesn't refetch this on every single menu click. Returns
    ('', '') on any failure so the caller falls back to the manually-pasted
    Settings value cleanly."""
    ck = 'sportsurge_auto_cookie_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    result = ('', '')
    try:
        r = _req.get(_SPORTSURGE_AUTO_COOKIE_URL, timeout=8)
        r.raise_for_status()
        data = r.json()
        cf = (data.get('cf_clearance') or '').strip()
        ua = (data.get('user_agent') or '').strip()
        if cf:
            result = (cf, ua)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] sportsurge auto-cookie fetch error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, result, 30 * 60)
    return result


def _sportsurge_get(path):
    """GET a v2.sportsurge.net path using a cf_clearance cookie — prefers
    the auto-refreshed one (see _sportsurge_auto_cookie) and falls back to
    the manually-pasted Settings value if that's unavailable. Returns None
    if neither is configured, or the cookie is expired/invalid (still gets
    the Cloudflare challenge page back) — callers must treat that exactly
    like any other source finding nothing, not an error."""
    cookie, ua = _sportsurge_auto_cookie()
    if not cookie:
        cookie = (ADDON.getSetting('sportsurge_cf_cookie') or '').strip()
        ua = (ADDON.getSetting('sportsurge_ua') or '').strip()
    if not cookie:
        return None
    ua = ua or _HEADERS['User-Agent']
    url = path if path.startswith('http') else _SPORTSURGE_BASE + '/' + path.lstrip('/')
    try:
        r = _sess().get(url, cookies={'cf_clearance': cookie},
                         headers=dict(_HEADERS, **{'User-Agent': ua}), timeout=12)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] sportsurge fetch error: %s' % e, xbmc.LOGWARNING)
        return None
    if r.status_code != 200 or 'Just a moment' in r.text[:2000]:
        xbmc.log('[Starfleet/Sports] sportsurge cf_clearance cookie missing/expired', xbmc.LOGWARNING)
        return None
    return r.text


_RE_SPORTSURGE_SOCCER_GAME = re.compile(
    r'href="(https?://soccersurge\.io/watch-\d+-[^"]+)"[^>]*?class="match-row"'
    r'[^>]*?data-category="26"[^>]*?title="([^"]+)"'
)


def _sportsurge_soccer_events():
    """Soccer isn't its own list6-* page on v2.sportsurge.net like every
    other sport here (confirmed live: list6-soccer/list6-football both
    just 301-redirect back to the homepage, 0 real content). Soccer games
    only appear mixed into the homepage's own combined listing
    (v2.sportsurge.net/), each row tagged data-category="26" and linking to
    a COMPLETELY DIFFERENT domain (soccersurge.io) instead of a relative
    v2.sportsurge.net path like every other sport uses — _sportsurge_get
    already passes an absolute http(s) URL through unchanged, so no other
    plumbing needed to change. soccersurge.io itself isn't behind the same
    Cloudflare challenge v2.sportsurge.net is (confirmed live: 200 with no
    cookie at all), so its own watch pages don't need the cf_clearance
    cookie either — only the initial v2.sportsurge.net homepage fetch does."""
    ck = 'sportsurge_events_soccer'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    html = _sportsurge_get('')
    if not html:
        return []
    events = []
    seen = set()
    for href, title in _RE_SPORTSURGE_SOCCER_GAME.findall(html):
        if href in seen:
            continue
        seen.add(href)
        events.append({
            'id': 'sportsurge_' + href, 'slug': href, 'path': 'sportsurge:' + href,
            'title': title, 'league': 'SOCCER', 'logo': '',
            'is_live': True, 'start_ts': 0, 'datetime': '',
        })
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] sportsurge soccer: %d events' % len(events), xbmc.LOGINFO)
    return events


def _sportsurge_events(sport_slug):
    if sport_slug == 'soccer':
        return _sportsurge_soccer_events()
    seg = _SPORTSURGE_SLUGS.get(sport_slug)
    if not seg:
        return []
    ck = 'sportsurge_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    html = _sportsurge_get(seg)
    if not html:
        return []
    events = []
    seen = set()
    for path, title in _RE_SPORTSURGE_GAME.findall(html):
        if path in seen:
            continue
        seen.add(path)
        events.append({
            'id': 'sportsurge_' + path, 'slug': path, 'path': 'sportsurge:' + path,
            'title': title, 'league': sport_slug.upper(), 'logo': '',
            'is_live': True, 'start_ts': 0, 'datetime': '',
        })
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] sportsurge %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _sportsurge_try_resolve(href):
    """Actually resolve href to a real playable stream using the exact same
    chain sports_router._play_stream() uses at play time (ResolveURL, then
    embed_resolver's generic iframe-chain follower — the latter is what
    already handles resports.cfd's 3-hop wrapper live). Returns a
    pipe-tagged 'url|Referer=...' string (this codebase's existing
    convention for a pre-resolved stream, same as DaddyLive/FalconStreams)
    or None if nothing on this addon's Python-only resolve chain can
    extract a real stream from it — which is exactly what makes most of
    SportSurge's ~20 embed rows (Stream 1/2/3, Alpha, NBCSports, etc.) dead
    links here: they need real JS execution this addon can't do."""
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(href)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                return r
    except ImportError:
        pass
    except Exception:
        pass

    try:
        from resources.lib import embed_resolver
        stream, referer = embed_resolver.resolve_generic_iframe_chain(href)
        if stream:
            if referer:
                from urllib.parse import quote as _uq
                return '%s|Referer=%s' % (stream, _uq(referer, safe=''))
            return stream
    except Exception:
        pass
    return None


def _sportsurge_streams_for_path(path):
    html = _sportsurge_get(path)
    if not html:
        return []
    candidates, seen = [], set()
    for href, name in _RE_SPORTSURGE_ROW.findall(html):
        if href in seen:
            continue
        seen.add(href)
        candidates.append((href, name.strip()))
    if not candidates:
        return []

    # Only show rows that actually resolve to a real stream — per explicit
    # instruction, better than a hardcoded name whitelist (resports/bally)
    # since it self-corrects if those break or a new working source shows
    # up, instead of silently going stale. Resolved concurrently with a
    # tight 10s overall cap (matches this session's "reasonable timeout"
    # standard for the unified search) — not a 'with' block, same reason as
    # every other pool in this codebase: shutdown(wait=False) so a
    # straggler resolve can't hold the picker open past the cutoff.
    streams = []
    pool = ThreadPoolExecutor(max_workers=min(len(candidates), 15))
    try:
        futures = {pool.submit(_sportsurge_try_resolve, href): (href, name) for href, name in candidates}
        for future in as_completed(futures, timeout=10):
            href, name = futures[future]
            try:
                resolved = future.result()
            except Exception:
                resolved = None
            if resolved:
                streams.append({
                    'label': name, 'url': resolved, 'quality': '', 'language': '',
                    'source': 'SportSurge',
                })
    except Exception as e:
        xbmc.log('[Starfleet/Sports] sportsurge resolve timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)
    return streams


def _sportsurge_streams_by_title(sport_slug, event_title):
    evs = _sportsurge_events(sport_slug)
    if not evs:
        return []
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path = ev['slug']
    if not best_path or best_score < 2:
        return []
    return _sportsurge_streams_for_path(best_path)


# ── livetv902.me (livetv.sx family) ───────────────────────────────────────────
#
# Chain (verified live against a real CFL game, 2026-07-23): the site's own
# webmaster export page lists every currently-scheduled event across every
# sport it carries (competition + sport label + team names + a
# /gowm.php?lid=X&eid=Y link). That eid alone is enough to pull a per-event
# "other links" page (/player/links/ru/<eid>) listing several numbered
# mirrors, each either type=alieztv or type=ifr. The alieztv ones resolve
# through a small, stable chain (webplayer2.php -> an emb.aplNNN.me embed
# page -> a literal, unobfuscated `pl.init('//host/hls/....m3u8?cst=...')`
# call in plain JS) straight to a real, playable HLS URL — no WASM/P2P wall
# like embed.st, no decode needed, just two regexes. The ifr-type mirrors
# were also checked and route through a different, deeper chain
# (shd247.world -> getembed.live) that wasn't confirmed working — skipped
# for now rather than guessing. Listing times are in Moscow time (site's
# own locale); not converted here, used only for matching, not display.

LIVETV902_BASE = 'https://livetv902.me'

_RE_LIVETV902_ROW = re.compile(
    r'<span class="cmp">([^<]*)</span>\s*<br>\s*<span class="spr">([^<]*)</span>.*?'
    r'href="/gowm\.php\?lid=(\d+)&eid=(\d+)"[^>]*>([^<]+)</a>',
    re.DOTALL
)
_RE_LIVETV902_LINK = re.compile(
    r'href="//livetv902\.me/webplayer2\.php\?t=(alieztv|ifr)&c=(\d+)&lang=ru&eid=(\d+)&lid=(\d+)&'
)
_RE_LIVETV902_EMBED = re.compile(r'(emb\.apl\d+\.me)/player/live\.php\?id=(\d+)')
_RE_LIVETV902_M3U8   = re.compile(r"pl\.init\('(//[^']+\.m3u8[^']*)'\)")


def _livetv902_events():
    ck = 'livetv902_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _sess().get(LIVETV902_BASE + '/export/webmasters.php?lang=en',
                            timeout=10, headers=_HEADERS).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] livetv902 events error: %s' % e, xbmc.LOGWARNING)
        return []
    events = []
    for m in _RE_LIVETV902_ROW.finditer(html):
        comp, sport, lid, eid, title = m.groups()
        events.append({
            'competition': _clean(comp),
            'sport':       _clean(sport),
            'lid':         lid,
            'eid':         eid,
            'title':       _clean(title).replace('–', 'vs').replace('-', 'vs'),
        })
    xbmc.log('[Starfleet/Sports] livetv902: %d events' % len(events), xbmc.LOGINFO)
    _cache.set(ck, events, 5 * 60)
    return events


def _livetv902_resolve_alieztv(c_val, lid, eid):
    """webplayer2.php (alieztv) -> emb.aplNNN.me embed -> plain m3u8.

    Uses its own throwaway requests session, not the module's shared _sess()
    — confirmed live that resolving multiple candidates for the same event
    back-to-back on one shared/reused session made this site intermittently
    stop returning the embed iframe at all (same URL, same params, only
    difference was session reuse), while fresh independent sessions were
    reliable across repeated tests. Cheap enough per-call to not matter."""
    referer = '%s/player/links/ru/%s' % (LIVETV902_BASE, eid)
    url = '%s/webplayer2.php?t=alieztv&c=%s&lang=ru&eid=%s&lid=%s&ci=497&si=27' % (
        LIVETV902_BASE, c_val, eid, lid)
    sess = _req.Session()
    try:
        html = sess.get(url, timeout=8, headers=dict(_HEADERS, Referer=referer)).text
    except Exception:
        return None
    m = _RE_LIVETV902_EMBED.search(html)
    if not m:
        return None
    embed_host, embed_id = m.groups()
    embed_url = 'https://%s/player/live.php?id=%s&w=700&h=480' % (embed_host, embed_id)
    try:
        html2 = sess.get(embed_url, timeout=8, headers=dict(_HEADERS, Referer=url)).text
    except Exception:
        return None
    m2 = _RE_LIVETV902_M3U8.search(html2)
    if not m2:
        return None
    m3u8 = 'https:' + m2.group(1)
    try:
        check = sess.get(m3u8, timeout=8, headers=dict(_HEADERS, Referer=embed_url))
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            return None
    except Exception:
        return None
    import urllib.parse as _up4
    return m3u8 + '|Referer=%s' % _up4.quote(embed_url, safe='')


def _livetv902_streams_by_title(event_title):
    """Find the best-matching event across every sport this site carries,
    then resolve every alieztv mirror it offers (not just the first) —
    returns one stream entry per working mirror, labeled Link 1/2/3."""
    try:
        events = _livetv902_events()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] livetv902_streams_by_title error: %s' % e, xbmc.LOGWARNING)
        return []

    best_eid, best_score = None, 0
    for ev in events:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_eid = ev['eid']
    if not best_eid or best_score < 2:
        return []

    try:
        links_html = _req.get(
            '%s/player/links/ru/%s?t=%d' % (LIVETV902_BASE, best_eid, int(time.time())),
            timeout=8, headers=dict(_HEADERS, Referer=LIVETV902_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] livetv902 links page error: %s' % e, xbmc.LOGWARNING)
        return []

    candidates = [(c, lid) for (t, c, _eid, lid) in _RE_LIVETV902_LINK.findall(links_html)
                  if t == 'alieztv']
    if not candidates:
        return []

    streams = [None] * len(candidates)
    with ThreadPoolExecutor(max_workers=len(candidates)) as ex:
        futs = {ex.submit(_livetv902_resolve_alieztv, c, lid, best_eid): i
                for i, (c, lid) in enumerate(candidates)}
        for fut in futs:
            i = futs[fut]
            try:
                streams[i] = fut.result(timeout=10)
            except Exception:
                pass

    return [
        {'label': 'Link %d' % (i + 1), 'url': u, 'quality': '', 'language': '', 'source': 'LiveTV'}
        for i, u in enumerate(streams) if u
    ]


# ── hoofoot.ru (livetv.sx-family aggregator, own clean HLS proxy) ─────────────
#
# Own frontend over the same backend data as livetv902.me above (confirmed
# live: team logos served from cdn.livetv902.me), but exposed as a much
# cleaner JSON API instead of raw HTML tables. Both /api/events and
# /api/main-server?id=<eventId> return {"iv":..., "encrypted":...} — looks
# like a real barrier, but the site's own schedule.js ships the decryption
# key in plain text (literally commented "CORRECT ENCRYPTION KEY" — see
# resources/lib/aes128.py, a hand-rolled AES-128-CBC decrypt-only
# implementation added purely because Kodi's bundled Python has no
# pycryptodome/cryptography to reach for). Decrypted per-event channel URLs
# are one of: a YouTube embed (trivial), or a same-domain /ltv?id=... or
# /gl?id=... path that is ALREADY a real, directly playable HLS URL
# (confirmed live: /ltv returns a plain media playlist, /gl returns a proper
# HLS master playlist referencing further /gl variants) — no further
# resolution step needed either way, no browser required. Raw event
# Date/Time fields are Moscow time (confirmed live: every currently-"Live"
# event's raw time sits ~3h ahead of true UTC), same as livetv902's own
# export page above.

HOOFOOT_BASE        = 'https://hoofoot.ru'
_HOOFOOT_KEY         = bytes.fromhex('a7f3e9c2d4b8f1a6c3e7d9b2f4a8c1e5')
_HOOFOOT_MSK_OFFSET  = 3 * 3600  # Moscow = UTC+3 year-round (no DST since 2014)

# Sport-events-only scope (per explicit instruction): hoofoot's own "Sport"
# label -> our category slug. Deliberately excluded from this map: 'TV Show'
# (separate TMDB-matched feed, out of scope this round), 'Gambling' (not a
# sport). Labels with no matching category ('Watersports', 'Softball',
# 'Horse Racing', 'Other') aren't dropped — they feed the existing
# Other/International catch-all instead, via _hoofoot_other_events() below.
_HOOFOOT_SPORT_MAP = {
    'Football':   'soccer',
    'Baseball':   'mlb',
    'Basketball': 'nba',
    'Ice Hockey': 'nhl',
    'Tennis':     'tennis',
    'Handball':   'handball',
    'Cricket':    'cricket',
    'Volleyball': 'volleyball',
    'Cycling':    'cycling',
    'Golf':       'golf',
    'Snooker':    'snooker',
    'Fighting':   'ufc',
}


def _hoofoot_decrypt(payload):
    import json as _json_hf
    import base64 as _b64_hf
    from resources.lib import aes128 as _aes128_hf
    iv = _b64_hf.b64decode(payload['iv'])
    ct = _b64_hf.b64decode(payload['encrypted'])
    return _json_hf.loads(_aes128_hf.decrypt_cbc(_HOOFOOT_KEY, iv, ct).decode('utf-8'))


def _hoofoot_all_events():
    ck = 'hoofoot_events_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        r = _sess().get(HOOFOOT_BASE + '/api/events', timeout=10, headers=_HEADERS)
        data = _hoofoot_decrypt(r.json())
    except Exception as e:
        xbmc.log('[Starfleet/Sports] hoofoot events error: %s' % e, xbmc.LOGWARNING)
        return []

    events = []
    for e in data.get('events', []) or []:
        sport = e.get('Sport', '')
        try:
            dt = datetime.datetime.strptime('%s %s' % (e['Date'], e['Time']), '%Y-%m-%d %H:%M')
            start_ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds()) - _HOOFOOT_MSK_OFFSET
        except Exception:
            start_ts = 0
        eid = e.get('id', '')
        title = _clean((e.get('Match') or '').replace('–', 'vs'))
        events.append({
            'id':          'hoofoot_%s' % eid,
            'eid':         eid,
            'slug':        eid,
            'path':        'hoofoot:%s' % eid,
            'title':       title,
            'match_title': title,
            'datetime':    '',
            'league':      e.get('League') or '',
            'logo':        e.get('HomeTeamImage') or '',
            'is_live':     e.get('Status') == 'Live',
            'start_ts':    start_ts,
            'raw_sport':   sport,
        })
    xbmc.log('[Starfleet/Sports] hoofoot: %d events' % len(events), xbmc.LOGINFO)
    _cache.set(ck, events, 5 * 60)
    return events


def _hoofoot_events(sport_slug, max_items=20):
    events = _hoofoot_all_events()
    matching = [e for e in events if _HOOFOOT_SPORT_MAP.get(e['raw_sport']) == sport_slug]
    return matching[:max_items]


def _hoofoot_other_events():
    """Events whose raw Sport label has no matching category slug — folded
    into the Other/International catch-all rather than dropped entirely."""
    events = _hoofoot_all_events()
    return [e for e in events
            if e['raw_sport'] not in _HOOFOOT_SPORT_MAP
            and e['raw_sport'] not in ('TV Show', 'Gambling')]


def _hoofoot_event_streams(event_path):
    eid = event_path.replace('hoofoot:', '')
    try:
        r = _sess().get(
            HOOFOOT_BASE + '/api/main-server?id=%s' % eid, timeout=10,
            headers=dict(_HEADERS, Referer=HOOFOOT_BASE + '/iptv/live-player?id=%s' % eid))
        data = _hoofoot_decrypt(r.json())
    except Exception as e:
        xbmc.log('[Starfleet/Sports] hoofoot stream error (%s): %s' % (eid, e), xbmc.LOGWARNING)
        return []

    streams = []
    for i, ch in enumerate(data.get('channels', []) or []):
        main = ch.get('Main') or ''
        if not main:
            continue
        if main.startswith('/'):
            main = HOOFOOT_BASE + main
        streams.append({
            'label':    ch.get('language') or ('Link %d' % (i + 1)),
            'url':      main,
            'quality':  ch.get('speed', ''),
            'language': ch.get('language', ''),
            'source':   'Hoofoot',
        })
    return streams


# ── Public stream API ─────────────────────────────────────────────────────────

def get_event_streams(event_path, event_id='', sport_slug='', title=''):
    """
    Fetch stream links for a specific event.
    Merges ISE streams + Roxiestreams + StreamsEast + MethStreams
    + MLB24/NHL24/NFL24/NBA24 + TotalSportek24 + OnHockey.tv.
    Returns list of: {'label', 'url', 'quality', 'language', 'source'}
    """
    ck = ('sports_streams_%s' % event_id) if event_id else None
    if ck:
        cached = _cache.get(ck)
        if cached is not None:
            return cached

    streams = []

    # Determine event path source by prefix
    is_seast_path    = event_path and event_path.startswith('streamseast:')
    is_meth_path     = event_path and event_path.startswith('meth:')
    is_tstek_path    = event_path and event_path.startswith('tstek:')
    is_onhockey_path   = event_path and event_path.startswith('onhockey:')
    is_dlchan_path     = event_path and event_path.startswith('dlchan:')
    is_dlchan_multi    = event_path and event_path.startswith('dlchan_multi:')
    is_hoofoot_path    = event_path and event_path.startswith('hoofoot:')
    is_ise_path      = (event_path and not is_seast_path and not is_meth_path
                        and not is_tstek_path and not is_onhockey_path
                        and not is_dlchan_path and not is_dlchan_multi
                        and not is_hoofoot_path)

    # Build parallel fetch tasks
    futures = {}
    ex = ThreadPoolExecutor(max_workers=10)
    try:
        if is_ise_path:
            futures['ise']        = ex.submit(_ise_event_streams, event_path, event_id)
        # _seast_event_streams removed: it hands back raw embed.st page URLs
        # with no resolution step (relies on ResolveURL, which doesn't support
        # embed.st — that's the whole reason EmbedResolver exists), so these
        # never actually played. streameast.json now covers the same site
        # with properly-resolved links, picked up via json_data below.
        # MethStreams event pages are JS-rendered — no playable URL in HTML, skip as stream source
        # _tstek_streams / _tstek_streams_by_title removed 2026-08-03 —
        # totalsportek24.is superseded by totalsportek.json (json_data
        # below), scraped standalone from totalsportek.press instead; see
        # this file's get_sport_events() for the matching supplementary
        # source removal. Function bodies left in place as dead code.
        if is_onhockey_path:
            futures['onhockey']   = ex.submit(_onhockey_streams, event_path)
        if is_dlchan_path:
            futures['dlchan']     = ex.submit(_dlchan_streams, event_path)
        if is_dlchan_multi:
            futures['dlchan_multi'] = ex.submit(_dlchan_multi_streams, event_path)
        if is_hoofoot_path:
            futures['hoofoot'] = ex.submit(_hoofoot_event_streams, event_path)
        # _roxie_streams removed 2026-08-02 — confirmed live its m3u8 CDN
        # (a formaturamaxi.com.br host) sits behind genuine Cloudflare
        # bot-protection that 403s every non-browser client tried
        # (plain requests, cloudscraper) AND was independently confirmed
        # not to play in real Kodi either — the URL this function scrapes
        # was never actually playable, just successfully found.
        # _seast_event_streams_by_slug removed: streamseasti.is is now covered
        # by the streameast.json scraper output, picked up via json_data below.
        # meth_x removed: MethStreams event pages are JS-rendered, no playable stream URL
        if sport_slug == 'nhl' and not is_onhockey_path:
            futures['onhockey_x'] = ex.submit(_onhockey_streams_by_title, title)
        # _crack_streams_by_title removed: CrackStreams is now covered by the
        # crackstreams.json scraper output, picked up via json_data below.
        if title and not is_dlchan_multi:
            futures['tvnow_x']    = ex.submit(_tvnow_streams_by_title, title)
        if title and (sport_slug in _SPORTSURGE_SLUGS or sport_slug == 'soccer'):
            futures['sportsurge'] = ex.submit(_sportsurge_streams_by_title, sport_slug, title)
        if title:
            futures['livetv902'] = ex.submit(_livetv902_streams_by_title, title)
        if title:
            futures['buffcom'] = ex.submit(_buffcom_streams_by_title, title)
        # dlsports removed 2026-08-14: confirmed live embed.st (daddylive's
        # hop-2 mirror) now builds its stream URL via JS execution with
        # nothing static left to scrape, so _dl_streams_by_title always
        # returned 0 here — daddylive.json (json_data.py, via the
        # scraper-PC's Playwright-fallback resolver) covers this now. See
        # json_data.py's own _JSON_SOURCES comment for the full story.
        if title and sport_slug:
            futures['falcon']   = ex.submit(_falcon_streams_by_title, sport_slug, title)
            futures['tim']      = ex.submit(_tim_streams_by_title, sport_slug, title)
        if title and sport_slug in _ALL24_DOMAINS:
            futures['all24'] = ex.submit(_all24_streams_by_title, sport_slug, title)

        for name, fut in futures.items():
            try:
                result = fut.result(timeout=12)
                if result:
                    streams += result
            except Exception as e:
                xbmc.log('[Starfleet/Sports] stream source error (%s): %s' % (name, e), xbmc.LOGWARNING)
    finally:
        ex.shutdown(wait=False)

    # Links already unioned onto this event by json_data.merge_json_events()
    # during the listing phase (get_sport_events) — picked up here by id so
    # get_event_streams never has to re-fetch or re-match the JSON sources.
    if event_id:
        json_links = _cache.get('json_ev_links_%s' % event_id)
        if json_links:
            seen = {s.get('url') for s in streams}
            streams += [l for l in json_links if l.get('url') not in seen]

    # Post-process: any source above may have handed back a raw streame.center
    # embed link, or one of its wrapper front-ends (dead on their own) —
    # resolve those to the real playable URL, in parallel, regardless of
    # which source or sport it came from.
    streamecenter_idx = [i for i, s in enumerate(streams)
                         if any(h in s.get('url', '') for h in _STREAMECENTER_WRAPPER_HOSTS)]
    if streamecenter_idx:
        with ThreadPoolExecutor(max_workers=len(streamecenter_idx)) as rex:
            refuts = {rex.submit(_resolve_streame_center, streams[i]['url']): i for i in streamecenter_idx}
            for fut in refuts:
                i = refuts[fut]
                try:
                    resolved = fut.result(timeout=10)
                except Exception as e:
                    xbmc.log('[Starfleet/Sports] streame.center resolve error: %s' % e, xbmc.LOGWARNING)
                    resolved = None
                streams[i]['url'] = resolved
        streams = [s for s in streams if s['url']]

    if ck:
        ttl = 5 * 60 if streams else 2 * 60
        _cache.set(ck, streams, ttl)

    xbmc.log('[Starfleet/Sports] event streams (%s/%s): %d total' % (sport_slug, event_id, len(streams)), xbmc.LOGINFO)
    return streams


def _seast_event_streams_by_slug(sport_slug, event_title):
    """
    Supplementary: fetch StreamsEast schedule for the sport, find matching event, get streams.
    Used when the event did NOT come from StreamsEast.
    """
    try:
        seast_evs = _seast_events(sport_slug)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] seast_event_streams_by_slug error: %s' % e, xbmc.LOGWARNING)
        return []

    best_path  = None
    best_score = 0
    for ev in seast_evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']

    if not best_path or best_score < 2:
        return []

    return _seast_event_streams(best_path)


# ── CrackStreams ──────────────────────────────────────────────────────────────

CRACK_BASE = 'https://crackstreams.mx'

_CRACK_LEAGUE_MAP = {
    'nfl':    'nflstreams',
    'nba':    'nbastreams',
    'mlb':    'mlbstreams',
    'nhl':    'nhlstreams',
    'soccer': 'soccerstreams',
    'mma':    'mmastreams',
    'boxing': 'boxingcasino',
}

_RE_CRACK_ALL_STREAMS = re.compile(r'const\s+allStreams\s*=\s*(\[.*?\]);', re.DOTALL)
_RE_CRACK_M3U8 = re.compile(r'(https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*)')


def _crack_slug_candidates(event_title):
    """CrackStreams event pages live at /stream/<away-team>-vs-<home-team> —
    but the site's own /league/<sport>streams listing pages are 404s (the
    real path is /category/<sport>/, confirmed live), and even the correct
    category page has no server-rendered event links to scrape (JS-rendered
    like most of this ecosystem now). Rather than reverse-engineer another
    discovery API, build the slug directly from the two team names in the
    title — verified this matches the site's real URLs exactly for a live
    game. Team order in the given title isn't guaranteed, so try both."""
    parts = re.split(r'\s+vs\.?\s+', event_title, flags=re.IGNORECASE)
    def _slug(s):
        return re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-')
    if len(parts) != 2:
        return [_slug(event_title)]
    a, b = _slug(parts[0]), _slug(parts[1])
    return ['%s-vs-%s' % (a, b), '%s-vs-%s' % (b, a)]


def _crack_resolve_embed(embed_url):
    """Try to extract an m3u8 from an embed page. Returns None on failure."""
    try:
        html = _sess().get(
            embed_url, timeout=8,
            headers=dict(_HEADERS, Referer=CRACK_BASE + '/')
        ).text
        m = _RE_CRACK_M3U8.search(html)
        if m:
            return m.group(1)
    except Exception:
        pass
    return None


def _crack_streams_for_url(event_url):
    """Fetch a CrackStreams event page and return resolved stream dicts."""
    import json as _json
    try:
        html = _sess().get(
            event_url, timeout=8,
            headers=dict(_HEADERS, Referer=CRACK_BASE + '/')
        ).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] CrackStreams event page error: %s' % e, xbmc.LOGWARNING)
        return []
    m = _RE_CRACK_ALL_STREAMS.search(html)
    if not m:
        xbmc.log('[Starfleet/Sports] CrackStreams: no allStreams found at %s' % event_url, xbmc.LOGWARNING)
        return []
    try:
        raw = _json.loads(m.group(1))
    except Exception:
        return []
    results = []
    for i, s in enumerate(raw):
        embed_url = s.get('value', '').strip()
        label     = s.get('label', 'Link %d' % (i + 1))
        if not embed_url:
            continue
        resolved  = _crack_resolve_embed(embed_url) or embed_url
        results.append({'url': resolved, 'label': label, 'source': 'crack', 'quality': 'HD'})
    return results


def _crack_streams_by_title(sport_slug, event_title):
    """Try CrackStreams' predictable /stream/<team>-vs-<team> URL directly —
    see _crack_slug_candidates for why this bypasses event-listing scraping."""
    if sport_slug not in _CRACK_LEAGUE_MAP:
        return []
    for slug in _crack_slug_candidates(event_title):
        url = CRACK_BASE + '/stream/' + slug
        streams = _crack_streams_for_url(url)
        if streams:
            xbmc.log('[Starfleet/Sports] CrackStreams matched "%s" -> %s' % (event_title, url), xbmc.LOGINFO)
            return streams
    return []
