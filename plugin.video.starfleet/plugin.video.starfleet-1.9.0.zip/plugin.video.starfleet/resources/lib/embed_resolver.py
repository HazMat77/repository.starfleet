# -*- coding: utf-8 -*-
"""
resources/lib/embed_resolver.py

Internal resolver for embed player URLs that ResolveURL cannot handle.
Covers the embed domains seen in adult stream scrapers:
  - my.embedseek.online/#hash
  - p.easyvidplayer.com/#hash
  - mixdrop.ag/e/ID
  - doodstream.com/e/ID  (bonus)
  - streamtape.com/e/ID  (bonus)

Attempts to extract a direct HLS/MP4 URL from the embed page without
a JavaScript engine by pattern-matching known JavaScript source patterns.
"""

import re
import base64
import xbmc

try:
    import requests as _req
except ImportError:
    _req = None

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)

_session = None

def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update({'User-Agent': _UA})
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=1, backoff_factor=0.3)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _fetch(url, referer='', timeout=10):
    s = _sess()
    if not s:
        return ''
    headers = {}
    if referer:
        headers['Referer'] = referer
    try:
        r = s.get(url, headers=headers, timeout=timeout)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Embed] fetch error %s: %s' % (url[:60], e), xbmc.LOGWARNING)
        return ''


# ── Generic source-extraction patterns ───────────────────────────────────────

_SOURCE_RE = [
    # JWPlayer / VideoJS / plyr style: file: "URL"
    re.compile(r'''["']?file["']?\s*:\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    # HTML5 <source src="URL">
    re.compile(r'''<source[^>]+src=["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    # Hls.js: Hls.loadSource("URL")
    re.compile(r'''loadSource\(["'](https?://[^"']+\.m3u8[^"']*)["']''', re.I),
    # var src = "URL"
    re.compile(r'''(?:var\s+)?(?:src|source|url|stream)\s*=\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    # Generic: "https://...m3u8" anywhere in the page
    re.compile(r'''["'](https?://[^\s"'<>]+\.m3u8[^\s"'<>]*)["']''', re.I),
    # Generic MP4
    re.compile(r'''["'](https?://[^\s"'<>]+\.mp4[^\s"'<>]*)["']''', re.I),
]


def _extract_from_html(html):
    """Try all patterns to find a direct stream URL in HTML/JS source."""
    for pattern in _SOURCE_RE:
        m = pattern.search(html)
        if m:
            url = m.group(1).replace('\\/', '/').strip()
            if url.startswith('http'):
                return url
    return ''


def _try_atob_fragment(fragment):
    """Attempt base64-decode of the URL fragment to find a stream URL."""
    if not fragment:
        return ''
    for pad in ('', '=', '==', '==='):
        try:
            decoded = base64.b64decode(fragment + pad).decode('utf-8', errors='ignore')
            if decoded.startswith('http'):
                return decoded
        except Exception:
            continue
    return ''


# ── MixDrop embed resolver ─────────────────────────────────────────────────────

_MD_V_RE  = re.compile(r'MDCore\.(?:v|wurl|url)\s*=\s*["\'](https?://[^"\']+)["\']', re.I)
_MD_V2_RE = re.compile(r'MDCore\.\w+\s*=\s*["\']([a-zA-Z0-9_/-]+)["\']', re.I)
_MD_CDN   = re.compile(
    r'(?:mxcontent|mixdrop|mxtapes|mxvideo)\.(?:net|co|ag|com)/[^\s"\'<>]+\.(?:mp4|m3u8)[^\s"\'<>]*',
    re.I
)


def _resolve_mixdrop(url):
    """Extract direct stream from a mixdrop.ag/e/ID embed page."""
    html = _fetch(url, referer='https://mixdrop.ag/')
    if not html:
        return ''

    # Direct MDCore.wurl / MDCore.url with full HTTPS
    m = _MD_V_RE.search(html)
    if m:
        stream = m.group(1).replace('\\/', '/')
        xbmc.log('[Embed] MixDrop direct URL: %s' % stream[:60], xbmc.LOGINFO)
        return stream

    # CDN URL anywhere in page
    m = _MD_CDN.search(html)
    if m:
        stream = 'https://' + m.group(0).replace('\\/', '/')
        xbmc.log('[Embed] MixDrop CDN URL: %s' % stream[:60], xbmc.LOGINFO)
        return stream

    # Fall back to generic extractor
    return _extract_from_html(html)


# ── DoodStream resolver ────────────────────────────────────────────────────────

def _resolve_dood(url):
    """Extract stream from doodstream.com embed."""
    html = _fetch(url, referer='https://doodstream.com/')
    if not html:
        return ''
    # DoodStream specific pattern
    m = re.search(r"dsplayer\.hotlink\s*=\s*[\"'](https?://[^\"']+)[\"']", html, re.I)
    if m:
        return m.group(1)
    # Pass data and md5 to construct URL
    m2 = re.search(r"""/pass_md5/([^"']+)["']""", html, re.I)
    if m2:
        pass_url = 'https://doodstream.com/pass_md5/' + m2.group(1)
        token_html = _fetch(pass_url, referer=url)
        if token_html and token_html.startswith('http'):
            return token_html.strip() + '?token=dood&expiry=99999'
    return _extract_from_html(html)


# ── Streamtape resolver ────────────────────────────────────────────────────────

def _resolve_streamtape(url):
    """Extract stream from streamtape.com embed."""
    html = _fetch(url, referer='https://streamtape.com/')
    if not html:
        return ''
    # Streamtape obfuscated pattern
    m = re.search(
        r'id="ideoooo[^"]*"[^>]*>[^<]*<[^>]+>([^<]+)<',
        html, re.I
    )
    if m:
        partial = m.group(1).strip()
        if partial:
            return 'https:' + partial
    return _extract_from_html(html)


# ── Ply4me resolver ───────────────────────────────────────────────────────────

_PLY4ME_SRC_RE = [
    re.compile(r'''["']?(?:file|src|source|url)["']?\s*:\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''atob\(\s*["']([A-Za-z0-9+/=]+)["']\s*\)''', re.I),
]


def _resolve_ply4me(url):
    """Extract direct stream from a ply4me embed page."""
    html = _fetch(url, referer=url)
    if not html:
        return ''
    for pat in _PLY4ME_SRC_RE:
        m = pat.search(html)
        if m:
            val = m.group(1).strip()
            if val.startswith('http'):
                return val.replace('\\/', '/')
            try:
                decoded = base64.b64decode(val + '==').decode('utf-8', errors='ignore')
                if decoded.startswith('http'):
                    return decoded
            except Exception:
                pass
    return _extract_from_html(html)


# ── Embed-page resolver (embedseek, easyvidplayer, generic) ──────────────────

def _resolve_generic_embed(url):
    """Resolve a generic embed page (embedseek.online, easyvidplayer.com, etc.)."""
    fragment = url.split('#', 1)[1] if '#' in url else ''

    # Try fetching the embed page
    html = _fetch(url, referer=url.split('#')[0])
    if html:
        direct = _extract_from_html(html)
        if direct:
            xbmc.log('[Embed] Generic direct URL: %s' % direct[:60], xbmc.LOGINFO)
            return direct

    # If page had no direct URL, try base64-decoding the fragment
    if fragment:
        decoded = _try_atob_fragment(fragment)
        if decoded:
            # Decoded fragment may itself be an embed URL — recurse once
            if decoded.startswith('http'):
                if any(ext in decoded for ext in ('.m3u8', '.mp4')):
                    return decoded
                return _resolve_generic_embed(decoded)

    return ''


# ── Public entry point ────────────────────────────────────────────────────────

def resolve(url):
    """
    Attempt to resolve an embed URL to a direct stream URL.
    Returns the resolved URL, or '' if resolution failed.

    Call this BEFORE passing to ResolveURL so that unsupported embed
    domains are handled internally.
    """
    if not url:
        return ''

    url_lower = url.lower()

    try:
        if 'mixdrop.' in url_lower:
            return _resolve_mixdrop(url)

        if 'doodstream.' in url_lower or 'dood.watch' in url_lower or 'd0o0d.' in url_lower:
            return _resolve_dood(url)

        if 'streamtape.' in url_lower and '/e/' in url_lower:
            return _resolve_streamtape(url)

        if any(d in url_lower for d in ('ply4me.com', 'ply4me.to', 'ply4.me')):
            return _resolve_ply4me(url)

        # Embed player domains that use #hash fragments or JS source patterns
        if any(d in url_lower for d in [
            'embedseek.', 'easyvidplayer.', 'embedgram.', 'embedrise.',
            'vidmoly.', 'vidhide.', 'vidplay.', 'filemoon.', 'voe.sx',
            'callistanise.', 'noodlemagazine.', 'tubezaur.', 'cdnzz.',
            'highstream.', 'vidlox.', 'fembed.', 'hqq.', 'waaw.',
        ]):
            return _resolve_generic_embed(url)

    except Exception as e:
        xbmc.log('[Embed] resolve error for %s: %s' % (url[:60], e), xbmc.LOGWARNING)

    return ''
