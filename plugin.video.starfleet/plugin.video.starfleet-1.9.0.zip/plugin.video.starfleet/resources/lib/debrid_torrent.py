# -*- coding: utf-8 -*-
"""
resources/lib/debrid_torrent.py

Convert magnet links to playable stream URLs via debrid services.
Only uses CACHED torrents (instant availability) — never starts a download.

Supported services (checked in priority order from settings):
  Real-Debrid  — instant availability check → addMagnet → select → unrestrict
  AllDebrid    — instant check → upload magnet → get links → unlock
  Premiumize   — cache check → directdl with magnet src
  TorBox       — check cached → create torrent → request DL link

Public API:
  get_debrid_streams(title, year, media_type) → [{'label', 'url', 'info_hash'}]
"""

import re
import time
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()

try:
    import requests as _req
except ImportError:
    _req = None

_HEADERS = {'User-Agent': 'plugin.video.starfleet/1.1'}

# ── Credentials (read fresh each call so settings changes take effect) ────────

def _rd_key():  return ADDON.getSetting('rd_api_key').strip()
def _ad_key():  return ADDON.getSetting('ad_api_key').strip()
def _pm_key():  return ADDON.getSetting('pm_api_key').strip()
def _tb_key():  return ADDON.getSetting('tb_api_key').strip()
def _rd_on():   return ADDON.getSetting('rd_enabled') == 'true' and bool(_rd_key())
def _ad_on():   return ADDON.getSetting('ad_enabled') == 'true' and bool(_ad_key())
def _pm_on():   return ADDON.getSetting('pm_enabled') == 'true' and bool(_pm_key())
def _tb_on():   return ADDON.getSetting('tb_enabled') == 'true' and bool(_tb_key())

RD_BASE = 'https://api.real-debrid.com/rest/1.0'
AD_BASE = 'https://api.alldebrid.com/v4'
PM_BASE = 'https://www.premiumize.me/api'
TB_BASE = 'https://api.torbox.app/v1/api'

_session = None

def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(pool_connections=2, pool_maxsize=4,
                                      max_retries=_req.adapters.Retry(total=1))
        _session.mount('https://', a)
    return _session


def _rd_auth():
    return {**_HEADERS, 'Authorization': 'Bearer %s' % _rd_key()}

def _tb_auth():
    return {**_HEADERS, 'Authorization': 'Bearer %s' % _tb_key()}


# ── Real-Debrid magnet flow ───────────────────────────────────────────────────

def _rd_instant_hashes(hashes):
    """Return set of hashes that RD has cached."""
    if not hashes or not _rd_on():
        return set()
    try:
        s = _sess()
        if not s:
            return set()
        chunk = '/'.join(hashes[:40])
        r = s.get(RD_BASE + '/torrents/instantAvailability/%s' % chunk,
                  headers=_rd_auth(), timeout=10)
        if r.status_code != 200:
            return set()
        data = r.json()
        cached = set()
        for ih, val in data.items():
            if val and isinstance(val, dict) and val.get('rd'):
                cached.add(ih.lower())
        return cached
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] RD instant check error: %s' % e, xbmc.LOGWARNING)
        return set()


def _rd_add_magnet_and_get_links(magnet):
    """Add a cached magnet to RD and return list of direct download URLs."""
    try:
        s = _sess()
        if not s:
            return []
        # 1. Add magnet
        r = s.post(RD_BASE + '/torrents/addMagnet',
                   data={'magnet': magnet},
                   headers=_rd_auth(), timeout=10)
        if r.status_code not in (200, 201):
            return []
        torrent_id = r.json().get('id', '')
        if not torrent_id:
            return []

        # 2. Select all files
        s.post(RD_BASE + '/torrents/selectFiles/%s' % torrent_id,
               data={'files': 'all'},
               headers=_rd_auth(), timeout=10)

        # 3. Get torrent info — for cached torrents this is near-instant
        for _ in range(6):
            r2 = s.get(RD_BASE + '/torrents/info/%s' % torrent_id,
                       headers=_rd_auth(), timeout=10)
            if r2.status_code == 200:
                info = r2.json()
                if info.get('status') == 'downloaded':
                    links = info.get('links', [])
                    if links:
                        return links
            time.sleep(1)
        return []
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] RD add magnet error: %s' % e, xbmc.LOGERROR)
        return []


def _rd_unrestrict(link):
    """Unrestrict a single RD link to a direct stream URL."""
    try:
        s = _sess()
        if not s:
            return ''
        r = s.post(RD_BASE + '/unrestrict/link',
                   data={'link': link},
                   headers=_rd_auth(), timeout=10)
        if r.status_code == 200:
            return r.json().get('download', '')
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] RD unrestrict error: %s' % e, xbmc.LOGWARNING)
    return ''


def rd_magnet_to_stream(magnet, info_hash=''):
    """
    Full RD flow: instant check → add → select → unrestrict → return stream URL.
    Returns '' if not cached or any step fails.
    """
    if not _rd_on():
        return ''
    if info_hash:
        cached = _rd_instant_hashes([info_hash])
        if info_hash.lower() not in cached:
            xbmc.log('[Starfleet/Debrid] RD: %s not in cache' % info_hash[:10], xbmc.LOGINFO)
            return ''
    links = _rd_add_magnet_and_get_links(magnet)
    if not links:
        return ''
    # Unrestrict the first (largest/best) link
    stream = _rd_unrestrict(links[0])
    if stream:
        xbmc.log('[Starfleet/Debrid] RD stream: %s' % stream[:60], xbmc.LOGINFO)
    return stream


# ── AllDebrid magnet flow ─────────────────────────────────────────────────────

def _ad_instant_hashes(hashes):
    """Return set of hashes AllDebrid has cached."""
    if not hashes or not _ad_on():
        return set()
    try:
        s = _sess()
        if not s:
            return set()
        params = {'agent': 'starfleet', 'apikey': _ad_key()}
        params.update({'magnets[]': hashes[:10]})
        r = s.get(AD_BASE + '/magnet/instant', params=params, timeout=10)
        if r.status_code != 200:
            return set()
        data = r.json()
        if data.get('status') != 'success':
            return set()
        cached = set()
        for item in data.get('data', {}).get('magnets', []):
            if item.get('instant'):
                ih = item.get('hash', '').lower()
                if ih:
                    cached.add(ih)
        return cached
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] AD instant check error: %s' % e, xbmc.LOGWARNING)
        return set()


def ad_magnet_to_stream(magnet, info_hash=''):
    """AllDebrid: upload magnet → get links → unlock first link."""
    if not _ad_on():
        return ''
    if info_hash:
        cached = _ad_instant_hashes([info_hash])
        if info_hash.lower() not in cached:
            return ''
    try:
        s = _sess()
        if not s:
            return ''
        base_params = {'agent': 'starfleet', 'apikey': _ad_key()}

        # Upload magnet
        r = s.post(AD_BASE + '/magnet/upload',
                   params=base_params,
                   data={'magnets[]': magnet}, timeout=10)
        if r.status_code != 200:
            return ''
        data = r.json()
        if data.get('status') != 'success':
            return ''
        magnet_id = data.get('data', {}).get('magnets', [{}])[0].get('id', '')
        if not magnet_id:
            return ''

        # Get files
        r2 = s.get(AD_BASE + '/magnet/files',
                   params={**base_params, 'id[]': magnet_id}, timeout=10)
        if r2.status_code != 200:
            return ''
        files_data = r2.json()
        links = []
        for mg in files_data.get('data', {}).get('magnets', []):
            for f in mg.get('files', []):
                lnk = f.get('l', '') or f.get('link', '')
                if lnk:
                    links.append(lnk)
        if not links:
            return ''

        # Unlock first link
        r3 = s.get(AD_BASE + '/link/unlock',
                   params={**base_params, 'link': links[0]}, timeout=10)
        if r3.status_code == 200:
            data3 = r3.json()
            if data3.get('status') == 'success':
                stream = data3.get('data', {}).get('link', '')
                if stream:
                    xbmc.log('[Starfleet/Debrid] AD stream: %s' % stream[:60], xbmc.LOGINFO)
                    return stream
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] AD magnet error: %s' % e, xbmc.LOGERROR)
    return ''


# ── Premiumize magnet flow ────────────────────────────────────────────────────

def _pm_check_cache(info_hash):
    """Return True if Premiumize has this hash cached."""
    if not info_hash or not _pm_on():
        return False
    try:
        s = _sess()
        if not s:
            return False
        r = s.post(PM_BASE + '/cache/check',
                   data={'apikey': _pm_key(), 'items[]': info_hash},
                   timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                return bool(data.get('response', [False])[0])
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] PM cache check error: %s' % e, xbmc.LOGWARNING)
    return False


def pm_magnet_to_stream(magnet, info_hash=''):
    """Premiumize: directdl with magnet as src → return first stream_link."""
    if not _pm_on():
        return ''
    if info_hash and not _pm_check_cache(info_hash):
        return ''
    try:
        s = _sess()
        if not s:
            return ''
        r = s.post(PM_BASE + '/transfer/directdl',
                   data={'apikey': _pm_key(), 'src': magnet},
                   timeout=15)
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                content = data.get('content', [])
                for item in content:
                    stream = item.get('stream_link') or item.get('link', '')
                    if stream:
                        xbmc.log('[Starfleet/Debrid] PM stream: %s' % stream[:60], xbmc.LOGINFO)
                        return stream
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] PM magnet error: %s' % e, xbmc.LOGERROR)
    return ''


# ── TorBox magnet flow ────────────────────────────────────────────────────────

def _tb_check_cache(info_hash):
    """Return True if TorBox has this hash cached."""
    if not info_hash or not _tb_on():
        return False
    try:
        s = _sess()
        if not s:
            return False
        r = s.get(TB_BASE + '/torrents/checkcached',
                  params={'hash': info_hash, 'format': 'object', 'list_files': False},
                  headers=_tb_auth(), timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data.get('success'):
                return bool(data.get('data'))
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] TB cache check error: %s' % e, xbmc.LOGWARNING)
    return False


def tb_magnet_to_stream(magnet, info_hash=''):
    """TorBox: create torrent → request DL link."""
    if not _tb_on():
        return ''
    if info_hash and not _tb_check_cache(info_hash):
        return ''
    try:
        s = _sess()
        if not s:
            return ''

        # Add torrent
        r = s.post(TB_BASE + '/torrents/createtorrent',
                   data={'magnet': magnet, 'seed': 1, 'allow_zip': False},
                   headers=_tb_auth(), timeout=15)
        if r.status_code not in (200, 201):
            return ''
        data = r.json()
        if not data.get('success'):
            return ''
        torrent_id = data.get('data', {}).get('torrent_id', '')
        if not torrent_id:
            return ''

        # Request DL link
        r2 = s.get(TB_BASE + '/torrents/requestdl',
                   params={'token': _tb_key(), 'torrent_id': torrent_id,
                           'file_id': 0, 'zip': False},
                   headers=_tb_auth(), timeout=15)
        if r2.status_code == 200:
            data2 = r2.json()
            if data2.get('success'):
                stream = data2.get('data', '')
                if isinstance(stream, str) and stream:
                    xbmc.log('[Starfleet/Debrid] TB stream: %s' % stream[:60], xbmc.LOGINFO)
                    return stream
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] TB magnet error: %s' % e, xbmc.LOGERROR)
    return ''


# ── Public: search torrents + resolve via debrid ──────────────────────────────

def get_debrid_streams(title, year=None, media_type='movie', imdb_id=None,
                       season=None, episode=None):
    """
    Search torrent sources for title, check debrid caches, and return
    a list of playable stream dicts:
      [{'label': 'Debrid 1 (RD - YTS 1080p)', 'url': 'https://...', 'info_hash': '...'}]

    Only cached/instant results are included — no downloads are started.
    """
    from resources.lib import torrent_sources as _ts

    torrents = _ts.search_all(title, year, media_type, max_per_source=5,
                              imdb_id=imdb_id, season=season, episode=episode)
    if not torrents:
        xbmc.log('[Starfleet/Debrid] 0 torrents found for "%s"' % title, xbmc.LOGWARNING)
        return []

    # Filter out fake/non-video torrents by checking only the dn= display name,
    # not the full magnet (which would false-positive on tracker .com domains).
    _BAD_EXT = re.compile(r'\.(?:exe|zip|rar|bat|com|msi|dmg|apk|iso|7z|tar|gz)\b', re.IGNORECASE)
    def _is_fake(magnet):
        try:
            import urllib.parse as _ul
            dn = _ul.parse_qs(_ul.urlparse(magnet).query).get('dn', [''])[0]
        except Exception:
            dn = magnet
        return bool(_BAD_EXT.search(dn))
    torrents = [t for t in torrents if not _is_fake(t.get('magnet', ''))]
    if not torrents:
        xbmc.log('[Starfleet/Debrid] all torrents filtered as fake/non-video for "%s"' % title, xbmc.LOGWARNING)
        return []

    # For adult searches, filter out TV episode results (S01E01 naming pattern)
    if media_type == 'adult':
        import urllib.parse as _ul2
        _TV_EP = re.compile(r'\bS\d{1,2}E\d{1,2}\b', re.IGNORECASE)
        def _is_tv_ep(magnet):
            try:
                dn = _ul2.parse_qs(_ul2.urlparse(magnet).query).get('dn', [''])[0]
            except Exception:
                dn = magnet
            return bool(_TV_EP.search(dn))
        pre = len(torrents)
        torrents = [t for t in torrents if not _is_tv_ep(t.get('magnet', ''))]
        if pre != len(torrents):
            xbmc.log('[Starfleet/Debrid] adult filter: removed %d TV episode results' % (pre - len(torrents)), xbmc.LOGINFO)

    xbmc.log('[Starfleet/Debrid] %d torrents found for "%s"' % (len(torrents), title), xbmc.LOGINFO)

    any_debrid = any([_rd_on(), _ad_on(), _pm_on(), _tb_on()])

    # No debrid configured — return magnets directly for Elementum/Quasar
    if not any_debrid:
        results = []
        for i, torrent in enumerate(torrents[:15], 1):
            magnet = torrent.get('magnet', '')
            if not magnet:
                continue
            quality = torrent.get('quality', '')
            source  = torrent.get('source', '')
            label = '[Torrent] %s' % (('%s %s' % (source, quality)).strip() or 'Torrent %d' % i)
            results.append({'label': label, 'url': magnet, 'info_hash': torrent.get('info_hash', '')})
        xbmc.log('[Starfleet/Debrid] no debrid configured — returning %d magnet links' % len(results), xbmc.LOGINFO)
        return results

    # Collect hashes for bulk cache checks
    hashes = [t['info_hash'].lower() for t in torrents if t.get('info_hash')]

    rd_cached = _rd_instant_hashes(hashes) if _rd_on() else set()
    ad_cached = _ad_instant_hashes(hashes) if _ad_on() else set()

    results = []
    debrid_num = 1

    for torrent in torrents:
        ih = torrent.get('info_hash', '').lower()
        magnet = torrent.get('magnet', '')
        if not ih or not magnet:
            continue

        quality = torrent.get('quality', '')
        source  = torrent.get('source', '')
        label_base = '%s %s' % (source, quality) if quality else source

        for svc_name, svc_fn, cached_set, needs_set in [
            ('RD',  rd_magnet_to_stream,  rd_cached, True),
            ('AD',  ad_magnet_to_stream,  ad_cached, True),
            ('PM',  pm_magnet_to_stream,  set(),     False),
            ('TB',  tb_magnet_to_stream,  set(),     False),
        ]:
            checks = {'RD': _rd_on, 'AD': _ad_on, 'PM': _pm_on, 'TB': _tb_on}
            if not checks[svc_name]():
                continue
            if needs_set and ih not in cached_set:
                continue
            stream_url = svc_fn(magnet, ih)
            if stream_url:
                results.append({
                    'label':     'Debrid %d (%s - %s)' % (debrid_num, svc_name, label_base),
                    'url':       stream_url,
                    'info_hash': ih,
                })
                debrid_num += 1
                break

    # Debrid configured but nothing cached — offer raw magnets as fallback
    if not results:
        xbmc.log('[Starfleet/Debrid] debrid configured but 0 cached — falling back to magnets', xbmc.LOGWARNING)
        for i, torrent in enumerate(torrents[:10], 1):
            magnet = torrent.get('magnet', '')
            if not magnet:
                continue
            quality = torrent.get('quality', '')
            source  = torrent.get('source', '')
            label = '[Torrent] %s' % (('%s %s' % (source, quality)).strip() or 'Torrent %d' % i)
            results.append({'label': label, 'url': magnet, 'info_hash': torrent.get('info_hash', '')})

    return results
