﻿# -*- coding: utf-8 -*-
"""
resources/lib/dispatcher.py

Central action dispatcher. Imported once and kept alive by
reuselanguageinvoker — all subsequent navigation calls reuse
this module without re-importing or re-executing top-level code.

All heavy imports are inside elif branches (lazy) so only the
modules needed for the current action are loaded per call.
"""

import sys
from urllib.parse import parse_qsl, urlencode, unquote_plus
import xbmc
import xbmcplugin


def _build_url(base, params):
    return base + '?' + urlencode({k: str(v) for k, v in params.items()})


def run(handle, base_url, query_string):
    params = dict(parse_qsl(query_string.lstrip('?')))
    action = params.get('action', 'main_menu')

    def p(k, d=''):
        return unquote_plus(params.get(k, d))

    def build_url(ps):
        return _build_url(base_url, ps)

    # ── Playback actions — resolved URL, no endOfDirectory ────────────────────
    if action == 'play_live_dai':
        from resources.lib.router import play_live_dai
        play_live_dai(handle, p('asset_key'), p('title'), p('channel_id'))
        return

    if action == 'play_direct':
        from resources.lib.router import play_direct
        play_direct(handle, p('stream_url'), p('ch_id'), p('source'), p('title'))
        return

    if action == 'radio_play':
        from resources.lib.radio_router import radio_play
        radio_play(handle, p('station_uuid'), p('stream_url'), p('title'))
        return

    if action == 'afdb_play':
        from resources.lib.afdb_router import afdb_play
        afdb_play(handle, p('stream_url'), p('film_id'))
        return

    if action == 'play_xxxclub_magnet':
        from resources.lib.afdb_router import play_xxxclub_magnet
        play_xxxclub_magnet(handle, p('magnet'), p('title'))
        return

    if action == 'adult_stream_play':
        from resources.lib.afdb_router import adult_stream_play
        adult_stream_play(handle, p('stream_url'), p('title'))
        return

    if action == 'adult_stream_sources':
        from resources.lib.afdb_router import adult_stream_sources
        adult_stream_sources(handle, build_url, p('film_id'), p('title'), p('film_url'))
        return

    if action == 'afdb_play_search':
        from resources.lib.afdb_router import afdb_play_search
        afdb_play_search(handle, p('film_id'), p('film_slug'), p('film_title'))
        return

    if action == 'sports_event_play':
        from resources.lib.sports_router import sports_event_play
        sports_event_play(handle, p('event_id'), p('event_path'), p('sport_slug'), p('title'))
        return

    if action == 'free_play':
        from resources.lib.free_router import free_play
        free_play(handle, p('tmdb_id'), p('title'), p('year'), p('media_type'), p('svc_label'), p('archive_id'), p('stream_url'))
        return

    if action == 'meta_movie_play':
        from resources.lib.metadata_router import movie_play
        movie_play(handle, p('tmdb_id'), p('title'), p('imdb_id'), p('year'))
        return

    if action == 'meta_ep_play':
        from resources.lib.metadata_router import episode_play
        episode_play(handle, p('tmdb_id'), p('season_num'), p('episode_num'), p('title'), p('year'))
        return

    if action == 'live_unified_play':
        from resources.lib import unified_live
        from resources.lib import api as _api
        tva_channels = _api.get_live_channels()
        channels     = unified_live.get_all_channels(tva_channels=tva_channels)
        ch_key       = p('ch_key')
        ch_title     = p('ch_title')
        match        = next((c for c in channels if c['key'] == ch_key), None)
        if match:
            source_entry, play_action = unified_live.pick_source_and_play(handle, match)
            if source_entry and play_action == 'play_live_dai':
                from resources.lib.router import play_live_dai
                play_live_dai(handle, source_entry.get('asset_key', ''), ch_title, source_entry.get('channel_id', ''))
            elif source_entry:
                from resources.lib.router import play_direct
                play_direct(handle, source_entry['stream_url'],
                            source_entry['ch_id'], source_entry['source'], ch_title)
            else:
                xbmcplugin.setResolvedUrl(handle, False, __import__('xbmcgui').ListItem())
        else:
            xbmcplugin.setResolvedUrl(handle, False, __import__('xbmcgui').ListItem())
        return

    # ── Favorites utility actions (RunPlugin — no directory) ─────────────────
    if action == 'favorites_add':
        from resources.lib.favorites import favorites_add_action
        favorites_add_action(p('media_type'), p('tmdb_id'), p('title'),
                             year=p('year'), imdb_id=p('imdb_id'),
                             thumb=p('thumb'), fanart=p('fanart'))
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'favorites_remove':
        from resources.lib.favorites import favorites_remove_action
        favorites_remove_action(p('media_type'), p('tmdb_id'),
                                refresh=bool(p('refresh')))
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'favorites_clear_confirm':
        from resources.lib.favorites import favorites_clear_confirm
        favorites_clear_confirm()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    # ── Utility actions — no directory listing ────────────────────────────────
    if action == 'set_adult_pin':
        from resources.lib.pin_lock import set_pin
        set_pin()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action in ('lock_adult', 'adult_lock'):
        from resources.lib.pin_lock import lock_session
        lock_session()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'resolver_status':
        from resources.lib.resolvers import show_account_status
        show_account_status()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'open_settings':
        import xbmcaddon
        xbmcaddon.Addon('plugin.video.starfleet').openSettings()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'live_pluto_refresh':
        from resources.lib import live_sources
        live_sources.refresh_pluto()
        from resources.lib.router import list_live_pluto
        list_live_pluto(handle, build_url)
        xbmcplugin.endOfDirectory(handle)
        return

    if action == 'live_refresh_all':
        from resources.lib import unified_live, live_sources
        unified_live.invalidate()
        live_sources.refresh_pluto()
        from resources.lib.router import list_live_all
        list_live_all(handle, build_url)
        xbmcplugin.endOfDirectory(handle)
        return

    # ── Main menu — opens custom home window ──────────────────────────────────
    if action == 'main_menu':
        from resources.lib.setup import check_and_guide
        check_and_guide()
        import os as _os
        import xbmcaddon as _xa
        _addon_path = _xa.Addon().getAddonInfo('path')
        _run_script = _os.path.join(_addon_path, 'resources', 'lib', 'gui', 'run_home.py')
        _xml_path   = _os.path.join(_addon_path, 'resources', 'skins', 'Default', '1080i', 'Starfleet-Home.xml')
        if _os.path.isfile(_run_script) and _os.path.isfile(_xml_path):
            import xbmcvfs as _xbmcvfs
            import time as _time
            _data_dir   = _xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
            _win_lock   = _os.path.join(_data_dir, 'window.lock')
            # Treat locks older than 30 s as stale (script was killed by Kodi without cleanup).
            _nav_lock   = _os.path.join(_data_dir, 'nav.lock')
            _home_open = False
            if _os.path.exists(_win_lock):
                try:
                    _age = _time.time() - _os.path.getmtime(_win_lock)
                    if _age < 30:
                        _home_open = True
                    else:
                        xbmc.log('[Starfleet/Home] stale window.lock (age %.0fs) — removing' % _age, xbmc.LOGWARNING)
                        _os.remove(_win_lock)
                except Exception:
                    _home_open = False
            if not _home_open and _os.path.exists(_nav_lock):
                try:
                    _age = _time.time() - _os.path.getmtime(_nav_lock)
                    if _age < 8:
                        _home_open = True
                    else:
                        _os.remove(_nav_lock)
                except Exception:
                    pass
            if _home_open:
                # Nav transition in progress — home.py fires ActivateWindow(Videos,
                # target_url) ~600 ms after home closes.  Return an empty succeeded
                # listing so Videos shows nothing (no error → no retry loop, and
                # DialogBusy dismisses cleanly so ActivateWindow is not blocked).
                xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
            else:
                # Write window.lock as placeholder before RunScript so concurrent
                # root-URL refreshes from Kodi's history builder don't open a second home.
                try:
                    open(_win_lock, 'w').write('opening')
                except Exception:
                    pass
                xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
                xbmc.executebuiltin('RunScript(%s)' % _run_script)
        else:
            xbmc.log('[Starfleet/Home] skin not found, falling back to menu', xbmc.LOGWARNING)
            from resources.lib.router import main_menu as _main_menu
            _main_menu(handle, build_url)
            xbmcplugin.endOfDirectory(handle)
        return

    # ── Directory actions — all end with endOfDirectory ───────────────────────
    _dispatch_directory(action, handle, build_url, p, params)
    xbmcplugin.endOfDirectory(handle)


def _dispatch_directory(action, handle, build_url, p, params):
    """All directory-listing actions dispatched here."""
    # ── Favorites ─────────────────────────────────────────────────────────────
    if action == 'favorites_menu':
        from resources.lib.favorites import favorites_menu
        favorites_menu(handle, build_url)

    elif action == 'favorites_movies':
        from resources.lib.favorites import favorites_movies
        favorites_movies(handle, build_url)

    elif action == 'favorites_tv':
        from resources.lib.favorites import favorites_tv
        favorites_tv(handle, build_url)

    # ── Live TV ───────────────────────────────────────────────────────────────
    elif action == 'live_menu':
        from resources.lib.router import live_menu
        live_menu(handle, build_url)

    elif action == 'live_all':
        from resources.lib.router import list_live_all
        list_live_all(handle, build_url)

    elif action == 'live_tva':
        from resources.lib.router import list_live_tva
        list_live_tva(handle, build_url)

    elif action == 'live_samsung':
        from resources.lib.router import list_live_samsung
        list_live_samsung(handle, build_url)

    elif action == 'live_samsung_group':
        from resources.lib.router import list_live_samsung_group
        list_live_samsung_group(handle, build_url, p('group'))

    elif action == 'live_plex':
        from resources.lib.router import list_live_plex
        list_live_plex(handle, build_url)

    elif action == 'live_plex_group':
        from resources.lib.router import list_live_plex_group
        list_live_plex_group(handle, build_url, p('group'))

    elif action == 'live_pluto':
        from resources.lib.router import list_live_pluto
        list_live_pluto(handle, build_url)

    elif action == 'live_toutv':
        from resources.lib.router import list_live_toutv
        list_live_toutv(handle, build_url)

    elif action == 'live_news':
        from resources.lib.router import list_live_news
        list_live_news(handle, build_url)

    elif action == 'live_pluto_group':
        from resources.lib.router import list_live_pluto_group
        list_live_pluto_group(handle, build_url, p('group'))

    elif action == 'export_iptv':
        from resources.lib.router import export_iptv
        export_iptv(handle, build_url)

    # ── Metadata — Movies ─────────────────────────────────────────────────────
    elif action == 'meta_movies_menu':
        from resources.lib.metadata_router import movies_menu
        movies_menu(handle, build_url)

    elif action == 'meta_movies_by_date':
        from resources.lib.metadata_router import movies_by_date
        movies_by_date(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movies_popular':
        from resources.lib.metadata_router import movies_popular
        movies_popular(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movies_top':
        from resources.lib.metadata_router import movies_top_rated
        movies_top_rated(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movies_new':
        from resources.lib.metadata_router import movies_now_playing
        movies_now_playing(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movies_upcoming':
        from resources.lib.metadata_router import movies_upcoming
        movies_upcoming(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movie_genres':
        from resources.lib.metadata_router import movie_genres
        movie_genres(handle, build_url)

    elif action == 'meta_movies_by_genre':
        from resources.lib.metadata_router import movies_by_genre
        movies_by_genre(handle, build_url, p('genre_id'), p('genre_name'), int(p('page', '1')))

    elif action == 'meta_movies_search':
        from resources.lib.metadata_router import movies_search
        movies_search(handle, build_url)

    elif action == 'meta_movie_detail':
        from resources.lib.metadata_router import movie_detail
        movie_detail(handle, build_url, p('tmdb_id'))

    # ── Metadata — TV Shows ───────────────────────────────────────────────────
    elif action == 'meta_tv_menu':
        from resources.lib.metadata_router import tv_menu
        tv_menu(handle, build_url)

    elif action == 'meta_tv_popular':
        from resources.lib.metadata_router import tv_popular
        tv_popular(handle, build_url, int(p('page', '1')))

    elif action == 'meta_tv_top':
        from resources.lib.metadata_router import tv_top_rated
        tv_top_rated(handle, build_url, int(p('page', '1')))

    elif action == 'meta_tv_airing':
        from resources.lib.metadata_router import tv_airing_today
        tv_airing_today(handle, build_url, int(p('page', '1')))

    elif action == 'meta_tv_genres':
        from resources.lib.metadata_router import tv_genres
        tv_genres(handle, build_url)

    elif action == 'meta_tv_by_genre':
        from resources.lib.metadata_router import tv_by_genre
        tv_by_genre(handle, build_url, p('genre_id'), p('genre_name'), int(p('page', '1')))

    elif action == 'meta_tv_search':
        from resources.lib.metadata_router import tv_search
        tv_search(handle, build_url)

    elif action == 'meta_tv_show':
        from resources.lib.metadata_router import tv_show_detail
        tv_show_detail(handle, build_url, p('tmdb_id'))

    elif action == 'meta_tv_episodes':
        from resources.lib.metadata_router import tv_season_episodes
        tv_season_episodes(handle, build_url, p('tmdb_id'), p('season_num'),
                           p('tvdb_id'), p('show_title'), p('show_fanart'))

    elif action == 'meta_person':
        from resources.lib.metadata_router import person_movies
        person_movies(handle, build_url, p('name'), p('media_type'))

    # ── Radio ─────────────────────────────────────────────────────────────────
    elif action == 'radio_menu':
        from resources.lib.radio_router import radio_menu
        radio_menu(handle, build_url)

    elif action == 'radio_countries':
        from resources.lib.radio_router import radio_countries
        radio_countries(handle, build_url)

    elif action == 'radio_states':
        from resources.lib.radio_router import radio_states
        radio_states(handle, build_url, p('country'))

    elif action == 'radio_cities':
        from resources.lib.radio_router import radio_cities
        radio_cities(handle, build_url, p('country'), p('state'))

    elif action == 'radio_stations_city':
        from resources.lib.radio_router import radio_stations_city
        radio_stations_city(handle, build_url, p('country'), p('state'), p('city'))

    elif action == 'radio_stations_state':
        from resources.lib.radio_router import radio_stations_state
        radio_stations_state(handle, build_url, p('country'), p('state'))

    elif action == 'radio_search':
        from resources.lib.radio_router import radio_search
        radio_search(handle, build_url)

    # ── Adult ─────────────────────────────────────────────────────────────────
    elif action == 'adult_menu':
        from resources.lib.pin_lock import pin_required, prompt_pin
        from resources.lib.afdb_router import adult_menu
        if pin_required() and not prompt_pin():
            import xbmcplugin as _xp
            _xp.endOfDirectory(handle, succeeded=False)
            return
        adult_menu(handle, build_url)

    elif action == 'xxxclub_browse':
        from resources.lib.afdb_router import xxxclub_browse
        xxxclub_browse(handle, build_url, cursor=p('cursor', ''))

    elif action == 'afdb_new':
        from resources.lib.afdb_router import afdb_new
        afdb_new(handle, build_url, int(p('page', '1')))

    elif action == 'afdb_popular':
        from resources.lib.afdb_router import afdb_popular
        afdb_popular(handle, build_url, int(p('page', '1')))

    elif action == 'afdb_categories':
        from resources.lib.afdb_router import afdb_categories
        afdb_categories(handle, build_url)

    elif action == 'afdb_by_category':
        from resources.lib.afdb_router import afdb_by_category
        afdb_by_category(handle, build_url, p('category'), int(p('page', '1')))

    elif action == 'afdb_studios':
        from resources.lib.afdb_router import afdb_studios
        afdb_studios(handle, build_url, p('letter', 'A'))

    elif action == 'afdb_by_studio':
        from resources.lib.afdb_router import afdb_by_studio
        afdb_by_studio(handle, build_url, p('studio'), p('studio_name'), int(p('page', '1')))

    elif action == 'afdb_actors':
        from resources.lib.afdb_router import afdb_actors
        afdb_actors(handle, build_url, p('letter', 'A'))

    elif action == 'afdb_actor_detail':
        from resources.lib.afdb_router import afdb_actor_detail
        afdb_actor_detail(handle, build_url, p('actor_id'), p('actor_slug'), p('actor_name'))

    elif action == 'afdb_actor_films':
        from resources.lib.afdb_router import afdb_actor_films
        afdb_actor_films(handle, build_url, p('actor_id'), p('actor_slug'),
                         p('actor_name'), int(p('page', '1')))

    elif action == 'afdb_search':
        from resources.lib.afdb_router import afdb_search
        afdb_search(handle, build_url)

    elif action == 'adult_movies_menu':
        from resources.lib.afdb_router import adult_movies_menu
        adult_movies_menu(handle, build_url)

    elif action == 'adult_browse_new_releases':
        from resources.lib.afdb_router import adult_browse_new_releases
        adult_browse_new_releases(handle, build_url, int(p('page', '1')))

    elif action == 'adult_browse_recently_added':
        from resources.lib.afdb_router import adult_browse_recently_added
        adult_browse_recently_added(handle, build_url, int(p('page', '1')))

    elif action == 'adult_browse_bestsellers':
        from resources.lib.afdb_router import adult_browse_bestsellers
        adult_browse_bestsellers(handle, build_url, int(p('page', '1')))

    elif action == 'adult_ade_play':
        from resources.lib.afdb_router import adult_ade_play
        adult_ade_play(handle, p('ade_id'), p('ade_slug', ''), p('title', ''))

    elif action == 'adult_favorites_list':
        from resources.lib.adult_favorites import adult_favorites_list
        adult_favorites_list(handle, build_url)

    elif action == 'adult_favorites_add':
        import urllib.parse as _up2
        from resources.lib.adult_favorites import adult_favorites_add_action
        adult_favorites_add_action(p('ade_id'), p('title', ''), p('thumb', ''), p('fanart', ''))
        import xbmcplugin as _xp2
        _xp2.endOfDirectory(handle, succeeded=False)
        return

    elif action == 'adult_favorites_remove':
        from resources.lib.adult_favorites import adult_favorites_remove_action
        adult_favorites_remove_action(p('ade_id'), p('title', ''))
        import xbmcplugin as _xp3
        _xp3.endOfDirectory(handle, succeeded=False)
        return

    elif action == 'adult_movies_library':
        from resources.lib.afdb_router import adult_movies_library
        adult_movies_library(handle, build_url, int(p('page', '1')))

    elif action == 'adult_trailers':
        from resources.lib.afdb_router import adult_trailers
        adult_trailers(handle, build_url, int(p('page', '1')))

    elif action == 'adult_streams':
        from resources.lib.afdb_router import adult_streams
        adult_streams(handle, build_url, int(p('page', '1')), xclub_cursor=p('xclub_cursor', ''))

    elif action == 'adult_free_streams':
        from resources.lib.afdb_router import adult_free_streams
        adult_free_streams(handle, build_url, int(p('page', '1')))

    elif action == 'adult_free_sites':
        from resources.lib.afdb_router import adult_free_sites
        adult_free_sites(handle, build_url)

    elif action == 'adult_panda_genres':
        from resources.lib.afdb_router import adult_panda_genres
        adult_panda_genres(handle, build_url)

    elif action == 'adult_panda_movies':
        from resources.lib.afdb_router import adult_panda_movies
        adult_panda_movies(handle, build_url, p('genre_url'), p('genre_name', ''),
                           int(p('page', '1')))

    elif action == 'adult_panda_play':
        from resources.lib.afdb_router import adult_panda_play
        adult_panda_play(handle, p('slug'), p('film_url'), p('title', ''))

    elif action == 'adult_hqp_categories':
        from resources.lib.afdb_router import adult_hqp_categories
        adult_hqp_categories(handle, build_url)

    elif action == 'adult_hqp_movies':
        from resources.lib.afdb_router import adult_hqp_movies
        adult_hqp_movies(handle, build_url, p('cat_url'), p('cat_name', ''),
                         int(p('page', '1')))

    elif action == 'adult_hqp_play':
        from resources.lib.afdb_router import adult_hqp_play
        adult_hqp_play(handle, p('slug'), p('film_url'), p('title', ''))

    elif action == 'sports_menu':
        from resources.lib.sports_router import sports_menu
        sports_menu(handle, build_url)

    elif action == 'sports_events':
        from resources.lib.sports_router import sports_events
        sports_events(handle, build_url, p('sport_slug'), p('sport_label'), p('sport_icon'), p('tsdb_sport', ''))

    elif action == 'hockey_menu':
        from resources.lib.sports_router import hockey_menu
        hockey_menu(handle, build_url)

    elif action == 'hockey_league_events':
        from resources.lib.sports_router import hockey_league_events
        hockey_league_events(handle, build_url, p('league', 'NHL'))

    elif action == 'free_menu':
        from resources.lib.free_router import free_menu
        free_menu(handle, build_url)

    elif action == 'free_services':
        from resources.lib.free_router import free_services
        free_services(handle, build_url, p('media_type', 'movies'))

    elif action == 'free_browse':
        from resources.lib.free_router import free_browse
        free_browse(handle, build_url, p('service_id'), p('media_type', 'movies'),
                    int(p('page', '1')))

    elif action == 'afdb_detail':
        from resources.lib.afdb_router import afdb_detail
        afdb_detail(handle, build_url, p('film_id'), p('film_slug'), p('film_title'))

    else:
        from resources.lib.router import main_menu
        main_menu(handle, build_url)
