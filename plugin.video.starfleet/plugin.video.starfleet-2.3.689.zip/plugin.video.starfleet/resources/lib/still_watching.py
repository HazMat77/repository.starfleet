# -*- coding: utf-8 -*-
"""
resources/lib/still_watching.py

"Are you still watching?": after 4 episodes or 2 movies in a row that played to their end with nobody touching the remote, a prompt
asks for an answer. With no answer within a minute Kodi quits (on a box that lets it go to sleep). Same rule as the HazMat TV app.
Setting still_watching (default on). The service (service.py) runs StillPlayer, which follows Kodi's player.
"""
import time
import xbmc
import xbmcaddon
import xbmcgui

EPISODES = 4
MOVIES = 2
ANSWER_SECONDS = 60


def _log(msg):
    xbmc.log('[Starfleet/StillWatching] %s' % msg, xbmc.LOGINFO)


def enabled():
    try:
        return xbmcaddon.Addon('plugin.video.starfleet').getSetting('still_watching') != 'false'
    except Exception:
        return True


class StillPlayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self._started = 0.0
        self._episode = False
        self._episodes = 0
        self._movies = 0

    def _reset(self):
        self._episodes = 0
        self._movies = 0

    def onAVStarted(self):
        self._started = time.time()
        try:
            self._episode = bool(xbmc.getInfoLabel('VideoPlayer.Episode')) or xbmc.getInfoLabel('VideoPlayer.DBType') == 'episode'
        except Exception:
            self._episode = False

    def onPlayBackStopped(self):
        self._reset()                               # somebody stopped it: they are there

    def onPlayBackEnded(self):
        try:
            if not (self._started and enabled()):
                return
            ran = time.time() - self._started
            quiet = xbmc.getGlobalIdleTime() >= ran - 10      # no key, click or touch since the video began
            self._started = 0.0
            if not quiet:
                self._reset()
                return
            if self._episode:
                self._episodes += 1
            else:
                self._movies += 1
            if self._episodes >= EPISODES or self._movies >= MOVIES:
                self._ask()
        except Exception as e:
            _log('%s' % e)

    def _ask(self):
        self._reset()
        dlg = xbmcgui.Dialog()
        _log('asking')
        if dlg.yesno('Are you still watching?', 'Nothing has been pressed for a while.\n\nChoose Yes to keep watching, or Kodi closes in a minute.',
                     nolabel='Close Kodi', yeslabel='Still watching', autoclose=ANSWER_SECONDS * 1000):
            return
        _log('no answer, closing')
        xbmc.executebuiltin('Quit')
