﻿# -*- coding: utf-8 -*-
"""
resources/lib/embed_sources.py

Embed-provider scrapers using IMDB IDs — no debrid required.
Works like The Crew's source modules: finds content on hosting sites,
returns embed or direct stream URLs for playback via ResolveURL.

Sources:
  VidSrc.to   — rcp-chain: data-hash → /rcp/{hash} → video host URL
  VidSrc.me   — alternative VidSrc mirror
  Autoembed   — direct IMDB-ID URL, returns direct streams or host URLs
  SuperEmbed  — multiembed.mov, IMDB-based

IMPORTANT: every provider must only return results with PLAYABLE URLs.
Never return an embed page URL (multiembed.mov, autoembed.co, vidsrc.to)
as a result — Kodi cannot play a webpage.
"""

import re
import xbmc

try:
    import requests as _req
except ImportError:
    _req = None

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)
_HEADERS = {
    'User-Agent': _UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
}

_session = None


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=0, redirect=False)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get(url, timeout=10, referer='', allow_redirects=True):
    s = _sess()
    if not s:
        return ''
    try:
        headers = {}
        if referer:
            headers['Referer'] = referer
        r = s.get(url, headers=headers, timeout=timeout, allow_redirects=allow_redirects)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Embed] GET %s: %s' % (url[:60], e), xbmc.LOGINFO)
        return ''


def _get_with_final_url(url, timeout=10, referer=''):
    """Fetch URL and return (text, final_url_after_redirects)."""
    s = _sess()
    if not s:
        return '', url
    try:
        headers = {}
        if referer:
            headers['Referer'] = referer
        r = s.get(url, headers=headers, timeout=timeout, allow_redirects=True)
        return r.text, r.url
    except Exception as e:
        xbmc.log('[Starfleet/Embed] GET+final %s: %s' % (url[:60], e), xbmc.LOGINFO)
        return '', url


_STREAM_RE = [
    re.compile(r'''["']?file["']?\s*:\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''<source[^>]+src=["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''loadSource\s*\(\s*["'](https?://[^"']+\.m3u8[^"']*)["']''', re.I),
    re.compile(r'''["'](https?://[^\s"'<>]+\.m3u8[^\s"'<>]*)["']''', re.I),
    re.compile(r'''["'](https?://[^\s"'<>]+\.mp4[^\s"'<>]*)["']''', re.I),
]


def _extract_stream(html):
    for pat in _STREAM_RE:
        m = pat.search(html)
        if m:
            url = m.group(1).replace('\\/', '/').strip()
            if url.startswith('http'):
                return url
    return ''


# Known video host domains — these are playable via our resolvers or ResolveURL
_KNOWN_HOSTS = [
    'streamtape.', 'mixdrop.', 'doodstream.', 'dood.watch',
    'streamvid.', 'vidhide.', 'vidmoly.', 'voe.sx',
    'upstream.to', 'vidlox.', 'highstream.', 'filemoon.',
]


def _is_known_host(url):
    url_lower = url.lower()
    return any(h in url_lower for h in _KNOWN_HOSTS)


def _is_direct_stream(url):
    """True if the URL is a direct playable stream or a known resolvable host."""
    url_lower = url.lower()
    if any(ext in url_lower for ext in ('.m3u8', '.mp4', '.mkv')):
        return True
    return _is_known_host(url)


# ── VidSrc.me (vidsrcme.ru) ───────────────────────────────────────────────────
# vidsrc.icu is dead; vidsrc.me redirects to vidsrcme.ru which has the same
# data-hash / /rcp/ chain but on domain cloudorchestranova.com for the RCP step.

_VIDSRC_BASE = 'https://vidsrcme.ru'


def search_vidsrc(imdb_id, media_type='movie', season=None, episode=None):
    """Search vidsrcme.ru for stream sources using IMDB ID."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/embed/tv?imdb=%s&season=%s&episode=%s' % (_VIDSRC_BASE, imdb_id, season, episode)
        else:
            url = '%s/embed/movie?imdb=%s' % (_VIDSRC_BASE, imdb_id)

        html = _get(url, timeout=12)
        if not html:
            return []

        # Extract player_iframe src — already a full RCP URL on the real RCP host
        rcp_domain = ''
        first_rcp_url = ''
        iframe_m = re.search(r'<iframe[^>]+id=["\']player_iframe["\'][^>]+src=["\']([^"\']+)["\']', html, re.I)
        if not iframe_m:
            iframe_m = re.search(r'src=["\']([^"\']*\/rcp\/[^"\']+)["\']', html, re.I)
        if iframe_m:
            first_rcp_url = iframe_m.group(1)
            if first_rcp_url.startswith('//'):
                first_rcp_url = 'https:' + first_rcp_url
            dm = re.match(r'(https?://[^/]+)', first_rcp_url)
            if dm:
                rcp_domain = dm.group(1)

        results = []

        # Follow the primary RCP iframe
        if first_rcp_url:
            rcp_html, rcp_final = _get_with_final_url(first_rcp_url, timeout=10, referer=url)
            stream = _extract_stream(rcp_html) if rcp_html else ''
            if stream:
                results.append({'label': 'VidSrc S1', 'url': stream})
            elif _is_known_host(rcp_final):
                results.append({'label': 'VidSrc S1', 'url': rcp_final})

        # Try additional server hashes (skip first — already followed via iframe)
        if rcp_domain:
            hashes = re.findall(r'data-hash=["\']([A-Za-z0-9+/=]{10,})["\']', html, re.I)
            for i, h in enumerate(hashes[1:3], 2):
                alt_url = '%s/rcp/%s' % (rcp_domain, h)
                alt_html, alt_final = _get_with_final_url(alt_url, timeout=8, referer=url)
                alt_stream = _extract_stream(alt_html) if alt_html else ''
                if alt_stream:
                    results.append({'label': 'VidSrc S%d' % i, 'url': alt_stream})
                elif _is_known_host(alt_final):
                    results.append({'label': 'VidSrc S%d' % i, 'url': alt_final})

        xbmc.log('[Starfleet/Embed] VidSrc: %d results for %s' % (len(results), imdb_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] VidSrc error: %s' % e, xbmc.LOGINFO)
        return []


# ── Autoembed ─────────────────────────────────────────────────────────────────

_AUTOEMBED_BASE = 'https://autoembed.co'


def search_autoembed(imdb_id, media_type='movie', season=None, episode=None):
    """Search autoembed.co for stream sources using IMDB ID."""
    if not imdb_id:
        return []
    try:
        # Correct autoembed.co URL format
        if media_type == 'tv' and season and episode:
            url = '%s/tv/imdb_id/%s/%s/%s' % (_AUTOEMBED_BASE, imdb_id, season, episode)
        else:
            url = '%s/movie/imdb_id/%s' % (_AUTOEMBED_BASE, imdb_id)

        html, final_url = _get_with_final_url(url, timeout=12)
        if not html:
            return []

        # If the redirect landed on a direct stream, return it
        if _is_direct_stream(final_url) and final_url != url:
            return [{'label': 'Autoembed', 'url': final_url}]

        # Try direct stream extraction
        stream = _extract_stream(html)
        if stream:
            return [{'label': 'Autoembed [Direct]', 'url': stream}]

        # Look for server list with embed/stream links
        results = []
        server_links = re.findall(
            r'href=["\']([^"\']+(?:/stream/|/embed/|/e/)[^"\']+)["\']', html, re.I
        )
        for srv_url in server_links[:3]:
            if srv_url.startswith('/'):
                srv_url = _AUTOEMBED_BASE + srv_url
            if not srv_url.startswith('http'):
                continue
            # Only follow if it's a known host (immediately playable)
            if _is_known_host(srv_url):
                results.append({'label': 'Autoembed', 'url': srv_url})
                continue
            # Otherwise fetch and try to extract a stream
            srv_html, srv_final = _get_with_final_url(srv_url, referer=url, timeout=8)
            if _is_direct_stream(srv_final) and srv_final != srv_url:
                results.append({'label': 'Autoembed', 'url': srv_final})
            elif srv_html:
                s = _extract_stream(srv_html)
                if s:
                    results.append({'label': 'Autoembed', 'url': s})

        # Don't add raw autoembed page URL as fallback — Kodi can't play it
        xbmc.log('[Starfleet/Embed] Autoembed: %d results for %s' % (len(results), imdb_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] Autoembed error: %s' % e, xbmc.LOGINFO)
        return []


# ── SuperEmbed (multiembed.mov) ───────────────────────────────────────────────

def search_superembed(imdb_id, media_type='movie', season=None, episode=None):
    """Search multiembed.mov for stream sources using IMDB ID."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = 'https://multiembed.mov/?video_id=%s&tmdb=0&s=%s&e=%s' % (imdb_id, season, episode)
        else:
            url = 'https://multiembed.mov/?video_id=%s&tmdb=0' % imdb_id

        html, final_url = _get_with_final_url(url, timeout=12)
        if not html:
            return []

        # If redirected to a direct stream, return it
        if _is_direct_stream(final_url) and final_url != url:
            return [{'label': 'SuperEmbed', 'url': final_url}]

        # Try direct stream extraction
        stream = _extract_stream(html)
        if stream:
            return [{'label': 'SuperEmbed [Direct]', 'url': stream}]

        # Look for server links (known video hosts only)
        results = []
        # Pattern: server buttons with href/data-href pointing to known hosts
        all_links = re.findall(r'href=["\']([^"\']{8,})["\']', html, re.I)
        all_links += re.findall(r'data-href=["\']([^"\']{8,})["\']', html, re.I)
        all_links += re.findall(r'data-src=["\']([^"\']{8,})["\']', html, re.I)

        for link in all_links:
            if link.startswith('//'):
                link = 'https:' + link
            if not link.startswith('http'):
                continue
            if _is_known_host(link):
                results.append({'label': 'SuperEmbed', 'url': link})
            elif _is_direct_stream(link) and 'multiembed' not in link.lower():
                results.append({'label': 'SuperEmbed [Direct]', 'url': link})
            if len(results) >= 2:
                break

        # IMPORTANT: DO NOT add multiembed.mov URL as fallback — it's a webpage, not a stream
        xbmc.log('[Starfleet/Embed] SuperEmbed: %d results for %s' % (len(results), imdb_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] SuperEmbed error: %s' % e, xbmc.LOGINFO)
        return []


# ── VidSrc.me / VidSrc.xyz ───────────────────────────────────────────────────

_VIDSRCME_MIRRORS = [
    'https://vidsrcme.ru',   # direct; vidsrc.me redirects here
    'https://vidsrc.me',
]


def search_vidsrcme(imdb_id, media_type='movie', season=None, episode=None):
    """VidSrc.me mirrors — alternative IMDB-based embed providers."""
    if not imdb_id:
        return []
    try:
        for base in _VIDSRCME_MIRRORS:
            try:
                if media_type == 'tv' and season and episode:
                    url = '%s/embed/tv?imdb=%s&season=%s&episode=%s' % (base, imdb_id, season, episode)
                else:
                    url = '%s/embed/movie?imdb=%s' % (base, imdb_id)

                html, final_url = _get_with_final_url(url, timeout=10)
                if not html:
                    continue

                if _is_direct_stream(final_url) and final_url != url:
                    return [{'label': 'VidSrc.me', 'url': final_url}]

                stream = _extract_stream(html)
                if stream:
                    return [{'label': 'VidSrc.me [Direct]', 'url': stream}]

                # Look for iframe/server links pointing to known video hosts
                results = []
                for link in re.findall(r'(?:src|href)=["\']([^"\']{10,})["\']', html, re.I):
                    if link.startswith('//'):
                        link = 'https:' + link
                    if not link.startswith('http'):
                        continue
                    if _is_known_host(link):
                        results.append({'label': 'VidSrc.me', 'url': link})
                    if len(results) >= 2:
                        break
                if results:
                    return results
            except Exception:
                continue

        xbmc.log('[Starfleet/Embed] VidSrc.me: 0 results for %s' % imdb_id, xbmc.LOGINFO)
        return []
    except Exception as e:
        xbmc.log('[Starfleet/Embed] VidSrc.me error: %s' % e, xbmc.LOGINFO)
        return []


# ── 2embed.cc ─────────────────────────────────────────────────────────────────

_2EMBED_MIRRORS = [
    'https://www.2embed.cc',
    'https://2embed.org',
]


def search_2embed(imdb_id, media_type='movie', season=None, episode=None):
    """2embed.cc — IMDB-based embed provider."""
    if not imdb_id:
        return []
    try:
        for base in _2EMBED_MIRRORS:
            try:
                if media_type == 'tv' and season and episode:
                    url = '%s/embedtvfull/%s?s=%s&e=%s' % (base, imdb_id, season, episode)
                else:
                    url = '%s/embed/%s' % (base, imdb_id)

                html, final_url = _get_with_final_url(url, timeout=10)
                if not html:
                    continue

                if _is_direct_stream(final_url) and final_url != url:
                    return [{'label': '2Embed', 'url': final_url}]

                stream = _extract_stream(html)
                if stream:
                    return [{'label': '2Embed [Direct]', 'url': stream}]

                results = []
                for link in re.findall(r'(?:src|href|data-src)=["\']([^"\']{10,})["\']', html, re.I):
                    if link.startswith('//'):
                        link = 'https:' + link
                    if not link.startswith('http'):
                        continue
                    if _is_known_host(link):
                        results.append({'label': '2Embed', 'url': link})
                    if len(results) >= 2:
                        break
                if results:
                    return results
            except Exception:
                continue

        xbmc.log('[Starfleet/Embed] 2embed: 0 results for %s' % imdb_id, xbmc.LOGINFO)
        return []
    except Exception as e:
        xbmc.log('[Starfleet/Embed] 2embed error: %s' % e, xbmc.LOGINFO)
        return []


# ── MoviesAPI.club ────────────────────────────────────────────────────────────

def search_moviesapi(imdb_id, media_type='movie', season=None, episode=None):
    """moviesapi.club — returns JSON with HLS stream URL directly."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = 'https://moviesapi.club/tv/%s-%s-%s' % (imdb_id, season, episode)
        else:
            url = 'https://moviesapi.club/movie/%s' % imdb_id

        html, final_url = _get_with_final_url(url, timeout=10)
        if not html:
            return []

        if _is_direct_stream(final_url) and final_url != url:
            return [{'label': 'MoviesAPI', 'url': final_url}]

        # MoviesAPI often embeds the stream URL in a JSON blob in the page
        stream = _extract_stream(html)
        if stream:
            return [{'label': 'MoviesAPI [Direct]', 'url': stream}]

        # Try parsing JSON blobs
        for jm in re.finditer(r'\{[^{}]{20,}\}', html):
            try:
                import json as _json
                obj = _json.loads(jm.group(0))
                for k in ('hls', 'stream', 'file', 'url', 'src', 'source'):
                    v = obj.get(k, '')
                    if v and isinstance(v, str) and v.startswith('http') and _is_direct_stream(v):
                        return [{'label': 'MoviesAPI', 'url': v}]
            except Exception:
                continue

        xbmc.log('[Starfleet/Embed] MoviesAPI: 0 results for %s' % imdb_id, xbmc.LOGINFO)
        return []
    except Exception as e:
        xbmc.log('[Starfleet/Embed] MoviesAPI error: %s' % e, xbmc.LOGINFO)
        return []


# ── MovieBox Pro (aoneroom.com) ───────────────────────────────────────────────
#
# Reverse-engineered from phisher98/cloudstream-extensions-phisher
# MovieBoxProvider.kt — signed HMAC-MD5 API, anonymous JWT, direct HLS/MP4 streams.
#
# API hosts (round-robin pool):
#   https://api3.aoneroom.com  (primary)
#   https://api4.aoneroom.com / api5 / api6  (fallbacks)
#
# Auth: every request needs x-client-token + x-tr-signature headers.
# The server returns an anonymous JWT in the x-user response header which is
# then cached and sent as  Authorization: Bearer {token}  on subsequent calls.
# No account or subscription required.

_MB_HOSTS = [
    'https://api3.aoneroom.com',
    'https://api4.aoneroom.com',
    'https://api5.aoneroom.com',
    'https://api6.aoneroom.com',
]

_MB_BEARER = [None]   # list so inner functions can mutate without 'global'
_MB_DEV_ID = [None]


def _mb_device():
    if _MB_DEV_ID[0] is None:
        import os
        _MB_DEV_ID[0] = os.urandom(16).hex()
    return _MB_DEV_ID[0]


def _mb_secret():
    import base64
    # Double base64-encoded key (as stored in the CloudStream extension)
    return base64.b64decode(
        base64.b64decode('NzZpUmwwN3MweFNOOWpxbUVXQXQ3OUVCSlp1bElRSXNWNjRGWnIyTw==')
    )


def _mb_md5(data):
    import hashlib
    return hashlib.md5(data if isinstance(data, bytes) else data.encode('utf-8')).hexdigest()


def _mb_client_token():
    import time
    ts = str(int(time.time() * 1000))
    return '%s,%s' % (ts, _mb_md5(ts[::-1]))


def _mb_signature(method, accept, content_type, url, body=None):
    import hashlib, hmac, base64, time
    from urllib.parse import urlparse, parse_qs
    ts = int(time.time() * 1000)
    p = urlparse(url)
    if p.query:
        params = parse_qs(p.query, keep_blank_values=True)
        qs = '&'.join('%s=%s' % (k, v[0]) for k, v in sorted(params.items()))
        canon_url = '%s?%s' % (p.path, qs)
    else:
        canon_url = p.path
    if body:
        bb = body.encode('utf-8') if isinstance(body, str) else body
        bb = bb[:102400]
        body_hash = _mb_md5(bb)
        body_len  = str(len(bb))
    else:
        body_hash = ''
        body_len  = ''
    canonical = '%s\n%s\n%s\n%s\n%s\n%s\n%s' % (
        method.upper(), accept or '', content_type or '',
        body_len, ts, body_hash, canon_url
    )
    mac = hmac.new(_mb_secret(), canonical.encode('utf-8'), hashlib.md5)
    sig = base64.b64encode(mac.digest()).decode()
    return '%d|2|%s' % (ts, sig)


def _mb_headers(method, url, body=None, token=None):
    import json
    ct = 'application/json; charset=utf-8' if body else 'application/json'
    h = {
        'user-agent': (
            'com.community.oneroom/50020088 '
            '(Linux; U; Android 13; en_US; Google Pixel 7; '
            'Build/TQ3A.230901.001; Cronet/145.0.7582.0)'
        ),
        'accept': 'application/json',
        'content-type': ct,
        'connection': 'keep-alive',
        'x-client-token': _mb_client_token(),
        'x-tr-signature': _mb_signature(method, 'application/json', ct, url, body),
        'x-client-info': json.dumps({
            'package_name':  'com.community.oneroom',
            'version_name':  '3.0.13.0325.03',
            'version_code':  50020088,
            'os': 'android', 'os_version': '13',
            'device_id':     _mb_device(),
            'install_store': 'ps',
            'system_language': 'en',
            'net':      'NETWORK_WIFI',
            'region':   'US',
            'timezone': 'America/New_York',
            'sp_code':  '',
        }),
        'x-client-status': '0',
    }
    if token:
        h['Authorization'] = 'Bearer %s' % token
    return h


def _mb_request(method, url, body=None, token=None, timeout=12):
    """Signed MovieBox API call → (parsed_json_or_None, new_token_or_None)."""
    import json
    s = _sess()
    if not s:
        return None, None
    try:
        hdrs = _mb_headers(method, url, body, token)
        if method.upper() == 'POST' and body:
            body_b = body.encode('utf-8') if isinstance(body, str) else body
            r = s.post(url, data=body_b, headers=hdrs, timeout=timeout)
        else:
            r = s.get(url, headers=hdrs, timeout=timeout)
        new_token = None
        x_user = r.headers.get('x-user', '')
        if x_user:
            try:
                new_token = json.loads(x_user).get('token')
            except Exception:
                pass
        return r.json(), new_token
    except Exception as e:
        xbmc.log('[Starfleet/MovieBox] %s %.50s: %s' % (method, url, e), xbmc.LOGINFO)
        return None, None


def _mb_get_token():
    """Fetch an anonymous Bearer JWT from the MovieBox API (cached per session)."""
    if _MB_BEARER[0]:
        return _MB_BEARER[0]
    url = '%s/wefeed-mobile-bff/tab/ranking-list?tabId=0&categoryType=4516404531735022304&page=1&perPage=1' % _MB_HOSTS[0]
    _, tok = _mb_request('GET', url)
    if tok:
        _MB_BEARER[0] = tok
    return _MB_BEARER[0]


def _mb_find_subject(host, keyword, media_type, token=None):
    """Search MovieBox by keyword → first matching subjectId string."""
    import json
    target_type = 1 if media_type != 'tv' else 2
    url  = '%s/wefeed-mobile-bff/subject-api/search/v2' % host
    body = json.dumps({'page': 1, 'perPage': 20, 'keyword': keyword})
    data, new_tok = _mb_request('POST', url, body=body, token=token)
    if new_tok:
        _MB_BEARER[0] = new_tok
    if not data:
        return None
    kw = keyword.lower()
    groups = (data.get('data') or {}).get('results') or []
    # Prefer title-matching subjects
    for group in groups:
        for subj in group.get('subjects', []):
            if subj.get('subjectType', 1) != target_type:
                continue
            sid = subj.get('subjectId', '')
            if sid and kw in subj.get('title', '').lower():
                return sid
    # Fallback: first subject of the right type
    for group in groups:
        for subj in group.get('subjects', []):
            if subj.get('subjectType', 1) == target_type:
                sid = subj.get('subjectId', '')
                if sid:
                    return sid
    return None


def _mb_tmdb_title(imdb_id):
    """Resolve IMDB ID → (title, year) via TMDB find endpoint."""
    s = _sess()
    if not s:
        return None, None
    try:
        r = s.get(
            'https://api.themoviedb.org/3/find/%s' % imdb_id,
            params={'api_key': '1865f43a0549ca50d341dd9ab8b29f49',
                    'external_source': 'imdb_id'},
            timeout=8
        )
        fd = r.json()
        hits = (fd.get('movie_results') or fd.get('tv_results')
                or fd.get('tv_episode_results') or [])
        if hits:
            title = hits[0].get('title') or hits[0].get('name', '')
            date  = hits[0].get('release_date', '') or hits[0].get('first_air_date', '')
            year  = int(date[:4]) if date else None
            return title, year
    except Exception as e:
        xbmc.log('[Starfleet/MovieBox] TMDB find: %s' % e, xbmc.LOGINFO)
    return None, None


def search_moviebox(imdb_id, media_type='movie', season=None, episode=None,
                    title=None, year=None):
    """
    MovieBox Pro (aoneroom.com) — HMAC-signed API returning direct HLS/MP4 streams.
    No account required: uses anonymous JWT auto-fetched from the API.
    title/year are optional; they are resolved from TMDB if absent.
    """
    if not imdb_id:
        return []
    try:
        host  = _MB_HOSTS[0]
        token = _mb_get_token()

        if not title:
            title, year = _mb_tmdb_title(imdb_id)
        if not title:
            return []

        subject_id = _mb_find_subject(host, title, media_type, token=token)
        if not subject_id:
            xbmc.log('[Starfleet/MovieBox] no subject for "%s" (%s)' % (title, imdb_id),
                     xbmc.LOGINFO)
            return []

        se = int(season)  if season  else 0
        ep = int(episode) if episode else 0
        url  = ('%s/wefeed-mobile-bff/subject-api/play-info'
                '?subjectId=%s&se=%s&ep=%s' % (host, subject_id, se, ep))
        data, new_tok = _mb_request('GET', url, token=token)
        if new_tok:
            _MB_BEARER[0] = new_tok

        streams = (data.get('data') or {}).get('streams') or [] if data else []
        results = []
        for st in streams:
            stream_url = st.get('url', '')
            if not stream_url:
                continue
            sign_cookie  = st.get('signCookie', '')
            resolutions  = st.get('resolutions', '')
            qual = resolutions.split(',')[0] if resolutions else ''
            label = 'MovieBox [%sp]' % qual if qual else 'MovieBox'
            if sign_cookie:
                stream_url = '%s|Cookie=%s' % (stream_url, sign_cookie)
            results.append({'label': label, 'url': stream_url})

        xbmc.log('[Starfleet/MovieBox] %d streams for "%s" (subjectId=%s)' % (
            len(results), title, subject_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/MovieBox] error: %s' % e, xbmc.LOGINFO)
        return []


# ── NowTV / myfilestorage.xyz ─────────────────────────────────────────────────

_NOWTV_BASE = 'https://myfilestorage.xyz'


def search_nowtv(imdb_id, media_type='movie', season=None, episode=None):
    """NowTV (myfilestorage.xyz) — direct MP4 URL probe by IMDB ID."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/tv/%s/s%se%s.mp4' % (
                _NOWTV_BASE, imdb_id, str(season), str(episode).zfill(2)
            )
        else:
            url = '%s/%s.mp4' % (_NOWTV_BASE, imdb_id)

        s = _sess()
        if not s:
            return []
        status = 0
        final_url = url
        try:
            r = s.head(url, timeout=8, allow_redirects=True)
            status = r.status_code
            final_url = r.url
        except Exception:
            pass
        if status == 405:
            try:
                r2 = s.get(url, timeout=8, stream=True)
                status = r2.status_code
                final_url = r2.url
                r2.close()
            except Exception:
                pass
        if status == 200:
            return [{'label': 'NowTV', 'url': final_url}]
        return []
    except Exception as e:
        xbmc.log('[Starfleet/Embed] NowTV error: %s' % e, xbmc.LOGINFO)
        return []


# ── SmashyStream ──────────────────────────────────────────────────────────────

_SMASHYSTREAM_BASE = 'https://embed.smashystream.com'


def search_smashystream(imdb_id, media_type='movie', season=None, episode=None):
    """SmashyStream — IMDB-based embed with multiple server links."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/playere.php?imdb=%s&s=%s&ep=%s' % (
                _SMASHYSTREAM_BASE, imdb_id, season, episode
            )
        else:
            url = '%s/playere.php?imdb=%s' % (_SMASHYSTREAM_BASE, imdb_id)

        html = _get(url, timeout=12, referer='https://smashystream.com/')
        if not html:
            return []

        # Parse server anchor tags with data-url attribute
        server_urls = re.findall(
            r'<a[^>]+data-url=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*server',
            html, re.I
        )
        if not server_urls:
            server_urls = re.findall(
                r'class=["\'][^"\']*server[^"\']*["\'][^>]*data-url=["\']([^"\']+)["\']',
                html, re.I
            )
        if not server_urls:
            server_urls = re.findall(r'data-url=["\']([^"\']{10,})["\']', html, re.I)

        results = []
        for srv_url in server_urls[:4]:
            if srv_url.startswith('//'):
                srv_url = 'https:' + srv_url
            if not srv_url.startswith('http'):
                continue
            if _is_direct_stream(srv_url):
                results.append({'label': 'SmashyStream', 'url': srv_url})
                continue
            if _is_known_host(srv_url):
                results.append({'label': 'SmashyStream', 'url': srv_url})
                continue
            srv_html = _get(srv_url, timeout=10, referer=url)
            if srv_html:
                stream = _extract_stream(srv_html)
                if stream:
                    results.append({'label': 'SmashyStream', 'url': stream})

        xbmc.log('[Starfleet/Embed] SmashyStream: %d results for %s' % (len(results), imdb_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] SmashyStream error: %s' % e, xbmc.LOGINFO)
        return []


# ── Ridomovies ────────────────────────────────────────────────────────────────

_RIDOMOVIES_BASE = 'https://ridomovies.tv'


def _ridomovies_api(path, timeout=8):
    """Fetch a Ridomovies JSON API endpoint."""
    url = '%s/core/api/%s' % (_RIDOMOVIES_BASE, path.lstrip('/'))
    s = _sess()
    if not s:
        return None
    try:
        r = s.get(url, headers={
            'Referer': _RIDOMOVIES_BASE + '/',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json',
        }, timeout=timeout)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Embed] Ridomovies API %s: %s' % (path[:50], e), xbmc.LOGINFO)
        return None


def _ridomovies_extract_iframe(iframe_url):
    """Fetch iframe (closeload.top or similar) and decode base64 M3U8."""
    import base64
    html = _get(iframe_url, timeout=10, referer=_RIDOMOVIES_BASE + '/')
    if not html:
        return ''
    m = re.search(r'atob\s*\(\s*["\']([A-Za-z0-9+/=]{20,})["\']', html)
    if m:
        try:
            decoded = base64.b64decode(m.group(1)).decode('utf-8', errors='ignore')
            stream = _extract_stream(decoded)
            if stream:
                return stream
        except Exception:
            pass
    return _extract_stream(html)


def search_ridomovies(imdb_id, media_type='movie', season=None, episode=None):
    """Ridomovies.tv — JSON API search → iframe chain → M3U8."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            data = _ridomovies_api('tv-shows?q=%s' % imdb_id)
        else:
            data = _ridomovies_api('movies?q=%s' % imdb_id)
        if not data:
            return []

        items = data.get('data', {})
        if isinstance(items, dict):
            items = items.get('items', [])
        if not items:
            return []

        movie = None
        for item in items:
            if imdb_id in str(item):
                movie = item
                break
        if not movie:
            movie = items[0]

        movie_id = movie.get('id', '')
        if not movie_id:
            return []

        if media_type == 'tv' and season and episode:
            seas_data = _ridomovies_api('tv-shows/%s/seasons' % movie_id)
            seasons = (seas_data or {}).get('data', {})
            if isinstance(seasons, dict):
                seasons = seasons.get('items', [])
            season_id = None
            for s_item in (seasons or []):
                if str(s_item.get('number', '')) == str(season):
                    season_id = s_item.get('id')
                    break
            if not season_id and seasons and int(season) <= len(seasons):
                season_id = seasons[int(season) - 1].get('id')
            if not season_id:
                return []
            eps_data = _ridomovies_api('seasons/%s/episodes' % season_id)
            eps = (eps_data or {}).get('data', {})
            if isinstance(eps, dict):
                eps = eps.get('items', [])
            episode_id = None
            for ep in (eps or []):
                if str(ep.get('number', '')) == str(episode):
                    episode_id = ep.get('id')
                    break
            if not episode_id:
                return []
            videos_data = _ridomovies_api('episodes/%s/videos' % episode_id)
        else:
            videos_data = _ridomovies_api('movies/%s/videos' % movie_id)

        videos = (videos_data or {}).get('data', {})
        if isinstance(videos, dict):
            videos = videos.get('items', [])

        results = []
        for video in (videos or [])[:3]:
            embed_url = video.get('url', '') or video.get('embed', '')
            if not embed_url:
                continue
            if embed_url.startswith('//'):
                embed_url = 'https:' + embed_url
            if _is_direct_stream(embed_url):
                results.append({'label': 'Ridomovies', 'url': embed_url})
                continue
            stream = _ridomovies_extract_iframe(embed_url)
            if stream:
                results.append({'label': 'Ridomovies', 'url': stream})

        xbmc.log('[Starfleet/Embed] Ridomovies: %d results for %s' % (len(results), imdb_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] Ridomovies error: %s' % e, xbmc.LOGINFO)
        return []


# ── Flixon ────────────────────────────────────────────────────────────────────

_FLIXON_BASE = 'https://flixon.lol'


def _flixon_decode(html):
    """Decode Flixon JS obfuscation (char-code array or atob) to extract stream URL."""
    import base64
    m = re.search(r'String\.fromCharCode\(([0-9,\s]+)\)', html)
    if m:
        try:
            chars = [int(x.strip()) for x in m.group(1).split(',') if x.strip()]
            decoded = ''.join(chr(c) for c in chars)
            stream = _extract_stream(decoded)
            if stream:
                return stream
        except Exception:
            pass
    m = re.search(r'atob\s*\(\s*["\']([A-Za-z0-9+/=]{20,})["\']', html)
    if m:
        try:
            decoded = base64.b64decode(m.group(1)).decode('utf-8', errors='ignore')
            stream = _extract_stream(decoded)
            if stream:
                return stream
        except Exception:
            pass
    return ''


def search_flixon(imdb_id, media_type='movie', season=None, episode=None):
    """Flixon.lol — IMDB-based with JS deobfuscation fallback."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/tv/%s/%s/%s' % (_FLIXON_BASE, imdb_id, season, episode)
        else:
            url = '%s/movie/%s' % (_FLIXON_BASE, imdb_id)

        html = _get(url, timeout=12, referer='https://flixon.lol/')
        if not html:
            return []

        stream = _extract_stream(html) or _flixon_decode(html)
        if stream:
            return [{'label': 'Flixon', 'url': stream}]

        for iframe_m in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I):
            iframe_url = iframe_m.group(1)
            if iframe_url.startswith('//'):
                iframe_url = 'https:' + iframe_url
            if not iframe_url.startswith('http'):
                continue
            if _is_direct_stream(iframe_url):
                return [{'label': 'Flixon', 'url': iframe_url}]
            if _is_known_host(iframe_url):
                return [{'label': 'Flixon', 'url': iframe_url}]
            iframe_html = _get(iframe_url, timeout=10, referer=url)
            if iframe_html:
                stream = _extract_stream(iframe_html) or _flixon_decode(iframe_html)
                if stream:
                    return [{'label': 'Flixon', 'url': stream}]

        xbmc.log('[Starfleet/Embed] Flixon: 0 results for %s' % imdb_id, xbmc.LOGINFO)
        return []
    except Exception as e:
        xbmc.log('[Starfleet/Embed] Flixon error: %s' % e, xbmc.LOGINFO)
        return []


# ── VidLink.pro ───────────────────────────────────────────────────────────────

_VIDLINK_BASE = 'https://vidlink.pro'


def search_vidlink(imdb_id, media_type='movie', season=None, episode=None):
    """VidLink.pro — TMDB/IMDB embed, no-ads, direct stream extraction."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/tv/%s/%s/%s' % (_VIDLINK_BASE, imdb_id, season, episode)
        else:
            url = '%s/movie/%s' % (_VIDLINK_BASE, imdb_id)

        html = _get(url, timeout=12, referer='https://vidlink.pro/')
        if not html:
            return []

        stream = _extract_stream(html)
        if stream:
            return [{'label': 'VidLink', 'url': stream}]

        for iframe_m in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I):
            iframe_url = iframe_m.group(1)
            if iframe_url.startswith('//'):
                iframe_url = 'https:' + iframe_url
            if not iframe_url.startswith('http'):
                continue
            if _is_direct_stream(iframe_url):
                return [{'label': 'VidLink', 'url': iframe_url}]
            if _is_known_host(iframe_url):
                return [{'label': 'VidLink', 'url': iframe_url}]
            inner_html = _get(iframe_url, timeout=10, referer=url)
            if inner_html:
                stream = _extract_stream(inner_html)
                if stream:
                    return [{'label': 'VidLink', 'url': stream}]

        xbmc.log('[Starfleet/Embed] VidLink: 0 results for %s' % imdb_id, xbmc.LOGINFO)
        return []
    except Exception as e:
        xbmc.log('[Starfleet/Embed] VidLink error: %s' % e, xbmc.LOGINFO)
        return []


# ── Unified embed search ──────────────────────────────────────────────────────

def search_embed_providers(imdb_id, media_type='movie', season=None, episode=None,
                           title=None, year=None):
    """
    Search all embed providers in parallel.
    Returns list of {'label': str, 'url': str}.
    Only runs for movie/tv — adult is handled separately.
    All returned URLs are either direct streams (.m3u8/.mp4) or known
    video host URLs (streamtape, mixdrop, etc.) — never bare embed page URLs.
    title/year are optional hints used by providers that need a keyword search
    (e.g. MovieBox) when a title cannot be derived from the IMDB ID alone.
    """
    if not imdb_id or media_type == 'adult':
        return []

    from concurrent.futures import ThreadPoolExecutor, as_completed

    # Dead as of 2026-07: vidsrc.icu, autoembed.co, moviesapi.club, flixon.lol,
    # smashystream (redirects to React SPA anyembed.xyz), ridomovies (403).
    tasks = {
        'VidSrc':     lambda: search_vidsrc(imdb_id, media_type, season, episode),
        'VidSrcMe':   lambda: search_vidsrcme(imdb_id, media_type, season, episode),
        'SuperEmbed': lambda: search_superembed(imdb_id, media_type, season, episode),
        '2Embed':     lambda: search_2embed(imdb_id, media_type, season, episode),
        'NowTV':      lambda: search_nowtv(imdb_id, media_type, season, episode),
        'MovieBox':   lambda: search_moviebox(imdb_id, media_type, season, episode,
                                              title=title, year=year),
        'VidLink':    lambda: search_vidlink(imdb_id, media_type, season, episode),
    }

    results = []
    with ThreadPoolExecutor(max_workers=7) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        try:
            for future in as_completed(futures, timeout=28):
                name = futures[future]
                try:
                    r = future.result()
                    results.extend(r)
                except Exception as e:
                    xbmc.log('[Starfleet/Embed] %s failed: %s' % (name, e), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Embed] providers timeout: %s' % e, xbmc.LOGINFO)

    xbmc.log('[Starfleet/Embed] Total embed results: %d for %s' % (len(results), imdb_id), xbmc.LOGINFO)
    return results
