# -*- coding: utf-8 -*-
"""
resources/lib/ade.py — Adult DVD Empire metadata scraper

Used as a fallback metadata source when a film title has no match in AFDB.
Returns film dicts in the same format as afdb.py so callers need no changes.

URL patterns:
  Search:  GET https://www.adultdvdempire.com/allsearch/search?q=TITLE&type=product
  Detail:  https://www.adultdvdempire.com/{id}/{slug}/
  Covers:  https://imgs-akamai.adi2cdn.com/images/size/300xN/...  (thumbnail)
           https://imgs-akamai.adi2cdn.com/images/size/600xN/...  (fanart)

Cache TTLs:
  Search results  → 6 h
  Film detail     → 24 h
"""

import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

import requests
from resources.lib import cache as _cache
_cache.init(_CACHE_DB)

BASE = 'https://www.adultdvdempire.com'

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': BASE + '/',
}

# ── Pre-compiled patterns ──────────────────────────────────────────────────────

_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE  = re.compile(r'\s+')

# Search result card — href="/ID/slug/" title="TITLE"
_RE_SEARCH_CARD = re.compile(
    r'href="/([\d]+)/([a-z0-9][a-z0-9-]*)/?"[^>]*>\s*<img[^>]+src="([^"]+)"',
    re.IGNORECASE
)
# Title from search card alt text or nearby anchor
_RE_SEARCH_TITLE = re.compile(
    r'<a[^>]+href="/([\d]+)/([a-z0-9][a-z0-9-]*)/?[^"]*"[^>]*class="[^"]*title[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE
)
# Fallback: item-title link
_RE_SEARCH_TITLE2 = re.compile(
    r'class="[^"]*item-title[^"]*"[^>]*href="/([\d]+)/([a-z0-9][a-z0-9-]*)/?[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE
)
# Product image on search/detail
_RE_PRODUCT_IMG = re.compile(
    r'<img[^>]+(?:class="[^"]*(?:cover|product|main-image)[^"]*"|id="[^"]*cover[^"]*")[^>]+src="([^"]+)"',
    re.IGNORECASE
)
# Any CDN image (akamai / adi2cdn)
_RE_CDN_IMG = re.compile(
    r'src="(https?://[a-z0-9.-]*(?:adi2cdn|adultempire|adultdvdempire)[^"]+(?:\.jpg|\.jpeg|\.png|\.webp))"',
    re.IGNORECASE
)

# Detail page patterns
_RE_SYNOPSIS = re.compile(
    r'(?:synopsis|description)[^>]*>.*?<(?:p|div)[^>]*>(.*?)</(?:p|div)>',
    re.IGNORECASE | re.DOTALL
)
_RE_SYNOPSIS2 = re.compile(
    r'<(?:p|div)[^>]*class="[^"]*synopsis[^"]*"[^>]*>(.*?)</(?:p|div)>',
    re.IGNORECASE | re.DOTALL
)
_RE_STUDIO = re.compile(
    r'(?:Studio|Label|Distributor)[:\s]*<[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_DIRECTOR = re.compile(
    r'(?:Director)[:\s]*<[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_YEAR = re.compile(
    r'(?:Release\s*Date|Date)[:\s]*.*?(\d{4})',
    re.IGNORECASE
)
_RE_RUNTIME = re.compile(
    r'(?:Run\s*Time|Runtime|Length)[:\s]*(\d+)',
    re.IGNORECASE
)
_RE_RATING = re.compile(
    r'(?:rating|score)[^>]*>\s*([0-9.]+)\s*(?:out\s*of|/)?',
    re.IGNORECASE
)
_RE_CAST = re.compile(
    r'href="/\d+/[^/]+/pornstar/[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_GENRES = re.compile(
    r'href="/\d+/[^/]*/category/[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_TITLE = re.compile(
    r'<h1[^>]*>([^<]+)<',
    re.IGNORECASE
)


# ── HTTP session ───────────────────────────────────────────────────────────────

_session = None

def _sess():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        a = requests.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=requests.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
    return _session


def _get(url, params=None, timeout=12):
    r = _sess().get(url, params=params, timeout=timeout)
    r.raise_for_status()
    return r.text


def _clean(text):
    text = _RE_STRIP_TAGS.sub(' ', text)
    return _RE_WHITESPACE.sub(' ', text).strip()


def _fanart_from_thumb(thumb):
    """Upscale CDN thumb URL to a larger fanart version."""
    if not thumb:
        return thumb
    # adi2cdn: replace /300xN/ with /600xN/
    t = re.sub(r'/(\d+)x(\d+)/', lambda m: '/%dx%d/' % (max(600, int(m.group(1))*2), max(600, int(m.group(2))*2)), thumb)
    # Generic: replace common small-size markers
    t = re.sub(r'_(?:small|thumb|300|200)(\.[a-z]+)$', r'_large\1', t, flags=re.IGNORECASE)
    return t


# ── Trailer / browse helpers ───────────────────────────────────────────────────

_RE_YT_ID = re.compile(
    r'(?:youtube\.com/embed/|youtu\.be/|youtube\.com/watch\?v=)([a-zA-Z0-9_-]{11})',
    re.IGNORECASE,
)
_RE_VIMEO_ID = re.compile(r'vimeo\.com/(?:video/)?(\d+)', re.IGNORECASE)
_RE_MP4_TRAILER = re.compile(
    r'href="([^"]+\.mp4)"[^>]*>[^<]*trailer', re.IGNORECASE
)

_RE_BROWSE_CARD = re.compile(
    r'href="/([\d]+)/([a-z0-9][a-z0-9-]*)/?[^"]*"[^>]*class="[^"]*(?:title|product-title)[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE,
)
_RE_BROWSE_CARD2 = re.compile(
    r'class="[^"]*(?:title|product-title)[^"]*"[^>]*href="/([\d]+)/([a-z0-9][a-z0-9-]*)/?[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE,
)


def _extract_trailer(html):
    """Return a playable trailer URL from an ADE detail page, or ''."""
    m = _RE_YT_ID.search(html)
    if m:
        return 'https://www.youtube.com/watch?v=%s' % m.group(1)
    m = _RE_VIMEO_ID.search(html)
    if m:
        return 'https://vimeo.com/%s' % m.group(1)
    m = _RE_MP4_TRAILER.search(html)
    if m:
        return m.group(1)
    return ''


def get_trailer_url(title):
    """
    Search ADE for `title` and return a trailer URL (YouTube/Vimeo/mp4),
    or '' if none found. Result cached 12 h.
    """
    ck = 'ade_trailer_%s' % re.sub(r'[^a-z0-9]', '_', title.lower())[:80]
    cached = _cache.get(ck)
    if cached is not None:
        return cached or ''

    film = search_by_title(title)
    if not film:
        _cache.set(ck, False, 12 * 3600)
        return ''

    try:
        html = _get('%s/%s/%s/' % (BASE, film['id'], film['slug']))
        trailer = _extract_trailer(html)
        _cache.set(ck, trailer or False, 12 * 3600)
        return trailer
    except Exception as e:
        xbmc.log('[ADE] trailer error for "%s": %s' % (title, e), xbmc.LOGWARNING)
        _cache.set(ck, False, 12 * 3600)
        return ''


def _parse_browse_page(html):
    """Parse a browse/listing page, returning a list of film stub dicts."""
    films = []
    seen  = set()

    def _add(fid, fslug, ftitle):
        if fid in seen or not fid or not fslug or not ftitle:
            return
        seen.add(fid)
        d = _minimal(fid, fslug)
        d['title'] = _clean(ftitle)
        # Find nearest CDN thumb
        pos = html.find('/%s/%s/' % (fid, fslug))
        if pos >= 0:
            region = html[max(0, pos - 300): pos + 1500]
            m = _RE_CDN_IMG.search(region)
            if m:
                d['thumb']  = m.group(1)
                d['fanart'] = _fanart_from_thumb(d['thumb'])
        films.append(d)

    for m in _RE_BROWSE_CARD.finditer(html):
        _add(m.group(1), m.group(2), m.group(3))
    for m in _RE_BROWSE_CARD2.finditer(html):
        _add(m.group(1), m.group(2), m.group(3))
    return films


def browse_new_releases(page=1):
    """
    Fetch ADE new releases listing, return list of film stub dicts.
    Cached 6 h per page.
    """
    ck = 'ade_new_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []

    url = BASE + '/new-releases/'
    if page > 1:
        url = '%s/new-releases/page/%d/' % (BASE, page)

    try:
        html  = _get(url)
        films = _parse_browse_page(html)
        _cache.set(ck, films or False, 6 * 3600)
        xbmc.log('[ADE] browse_new_releases page=%d → %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[ADE] browse_new_releases error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, False, 3600)
        return []


# ── Public API ─────────────────────────────────────────────────────────────────

def search_by_title(title):
    """
    Search ADE for `title`. Returns a metadata dict (same format as afdb.py)
    for the best-matching result, or None if nothing found.
    Result is cached for 6 hours.
    """
    ck = 'ade_search_%s' % re.sub(r'[^a-z0-9]', '_', title.lower())[:80]
    cached = _cache.get(ck)
    if cached is not None:
        return cached if cached else None  # None stored as sentinel for miss

    try:
        html = _get(BASE + '/allsearch/search', params={'q': title, 'type': 'product'})
    except Exception as e:
        xbmc.log('[ADE] search error for "%s": %s' % (title, e), xbmc.LOGWARNING)
        return None

    film = _parse_search_result(html, title)
    # Cache the result (or False as a negative sentinel to avoid repeat misses)
    _cache.set(ck, film if film else False, 6 * 3600)

    if film:
        xbmc.log('[ADE] search "%s" → "%s"' % (title, film.get('title', '')), xbmc.LOGINFO)
    else:
        xbmc.log('[ADE] search "%s" → no match' % title, xbmc.LOGINFO)

    return film


def get_film_detail(film_id, film_slug):
    """
    Fetch full ADE detail page for a known film.
    Returns metadata dict or a minimal fallback. Cached 24 h.
    """
    ck = 'ade_detail_%s' % film_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = '%s/%s/%s/' % (BASE, film_id, film_slug)
    try:
        html = _get(url)
        detail = _parse_detail(film_id, film_slug, html)
        _cache.set(ck, detail, 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[ADE] detail(%s) error: %s' % (film_id, e), xbmc.LOGWARNING)
        return _minimal(film_id, film_slug)


# ── Parsers ────────────────────────────────────────────────────────────────────

def _minimal(film_id, slug):
    return {
        'id':          film_id,
        'slug':        slug,
        'title':       slug.replace('-', ' ').title(),
        'description': '',
        'year':        '',
        'runtime':     0,
        'studio':      '',
        'director':    '',
        'rating':      0.0,
        'cast':        [],
        'categories':  [],
        'thumb':       '',
        'fanart':      '',
        'backcover':   '',
        'source':      'ade',
    }


def _parse_search_result(html, query):
    """
    Parse the first relevant movie from an ADE search results page.
    Returns a metadata dict populated from the first match, or None.
    """
    # Try title-linked approach first: find an anchor with /ID/slug/ that has a title
    # ADE search pages have items like:
    #   <a href="/12345/movie-title/" class="item-title ...">Movie Title</a>
    #   (with a nearby product image)

    from urllib.parse import quote_plus
    import unicodedata

    def _norm(t):
        t = t.lower()
        t = ''.join(c for c in unicodedata.normalize('NFD', t)
                    if unicodedata.category(c) != 'Mn')
        t = re.sub(r'[^a-z0-9 ]', '', t)
        return re.sub(r'\s+', ' ', t).strip()

    norm_q = _norm(query)

    # Collect all candidate cards: (film_id, slug, title, thumb)
    candidates = []

    # Pattern 1: explicit item-title anchor
    for m in _RE_SEARCH_TITLE.finditer(html):
        fid, fslug, ftitle = m.group(1), m.group(2), _clean(m.group(3))
        candidates.append((fid, fslug, ftitle))
    # Pattern 2: reversed attr order
    for m in _RE_SEARCH_TITLE2.finditer(html):
        fid, fslug, ftitle = m.group(1), m.group(2), _clean(m.group(3))
        if not any(c[0] == fid for c in candidates):
            candidates.append((fid, fslug, ftitle))

    # Fallback: any /ID/slug/ href with a title attr
    if not candidates:
        for m in re.finditer(
            r'href="/([\d]+)/([a-z0-9][a-z0-9-]*/?)?"[^>]*title="([^"]+)"',
            html, re.IGNORECASE
        ):
            fid, fslug, ftitle = m.group(1), m.group(2).rstrip('/'), _clean(m.group(3))
            if fid and not any(c[0] == fid for c in candidates):
                candidates.append((fid, fslug, ftitle))

    if not candidates:
        return None

    # Pick best match by normalised title similarity
    best = None
    best_score = 0
    for fid, fslug, ftitle in candidates:
        norm_t = _norm(ftitle)
        if norm_t == norm_q:
            best = (fid, fslug, ftitle)
            break
        # Word-overlap score
        q_words = set(norm_q.split())
        t_words = set(norm_t.split())
        score   = len(q_words & t_words) / max(len(q_words), 1)
        if score > best_score:
            best_score = score
            best = (fid, fslug, ftitle)

    if not best or best_score < 0.5:
        return None

    film_id, film_slug, film_title = best

    # Extract thumbnail from page (CDN images near the result)
    thumb = ''
    # Find CDN images associated with best result
    # Narrow the search to a region near the match
    match_pos = html.find('/%s/%s/' % (film_id, film_slug))
    if match_pos >= 0:
        region = html[max(0, match_pos - 500): match_pos + 2000]
        m = _RE_CDN_IMG.search(region)
        if m:
            thumb = m.group(1)
    if not thumb:
        m = _RE_CDN_IMG.search(html)
        if m:
            thumb = m.group(1)

    detail = _minimal(film_id, film_slug)
    detail['title'] = film_title
    detail['thumb'] = thumb
    detail['fanart'] = _fanart_from_thumb(thumb)
    return detail


def _parse_detail(film_id, film_slug, html):
    detail = _minimal(film_id, film_slug)

    # Title
    m = _RE_TITLE.search(html)
    if m:
        detail['title'] = _clean(m.group(1))

    # Cover image — product / cover img first, then any CDN img
    thumb = ''
    m = _RE_PRODUCT_IMG.search(html)
    if m:
        thumb = m.group(1)
    if not thumb:
        m = _RE_CDN_IMG.search(html)
        if m:
            thumb = m.group(1)
    if thumb:
        detail['thumb']  = thumb
        detail['fanart'] = _fanart_from_thumb(thumb)

    # Synopsis
    m = _RE_SYNOPSIS2.search(html)
    if not m:
        m = _RE_SYNOPSIS.search(html)
    if m:
        detail['description'] = _clean(m.group(1))[:800]

    # Studio
    m = _RE_STUDIO.search(html)
    if m:
        detail['studio'] = _clean(m.group(1))

    # Director
    m = _RE_DIRECTOR.search(html)
    if m:
        detail['director'] = _clean(m.group(1))

    # Year
    m = _RE_YEAR.search(html)
    if m:
        detail['year'] = m.group(1)

    # Runtime (minutes)
    m = _RE_RUNTIME.search(html)
    if m:
        try:
            detail['runtime'] = int(m.group(1))
        except ValueError:
            pass

    # Rating
    m = _RE_RATING.search(html)
    if m:
        try:
            detail['rating'] = float(m.group(1))
        except ValueError:
            pass

    # Cast
    cast = []
    seen = set()
    for m in _RE_CAST.finditer(html):
        name = _clean(m.group(1))
        if name and name not in seen:
            seen.add(name)
            cast.append({'id': '', 'slug': '', 'name': name})
    detail['cast'] = cast

    # Genres / categories
    cats = []
    seen_c = set()
    for m in _RE_GENRES.finditer(html):
        cat = _clean(m.group(1))
        if cat and cat not in seen_c:
            seen_c.add(cat)
            cats.append(cat)
    detail['categories'] = cats

    return detail
