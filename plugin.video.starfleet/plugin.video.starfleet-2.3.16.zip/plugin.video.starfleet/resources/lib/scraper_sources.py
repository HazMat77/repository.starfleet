# -*- coding: utf-8 -*-
"""
resources/lib/scraper_sources.py

Free streaming scrapers for movies, TV shows, and adult content.
Covers sites from the user-supplied list that are not already handled
by free_sources.py (Popcornflix/Tubi) or adult_streams.py.

Sources:
  cuevana3.eu     — Spanish-language streaming, iframe embeds
  hdtodayz.to     — General streaming aggregator, iframe embeds
  netmirror.app   — Mirror/aggregator, embed players
  zaxflix.com     — WordPress streaming, iframe embeds
  rarefilmm.com   — Classic/rare film archive, direct links
  1shows.org      — TV shows + movies, WordPress streaming
  456movie.nl     — General streaming, iframe embeds
  msearch.vercel.app — Meta-search aggregator (JSON API)

Each site scraper:
  1. Hits the site's search endpoint with the query title
  2. Parses film cards from the results HTML
  3. Fetches each film's detail page to extract embed/stream URLs
  4. Returns a list of film dicts compatible with adult_streams.py format:
     { 'id', 'title', 'title_norm', 'thumb', 'description', 'url',
       'source', 'streams': [{'label', 'url'}] }

search_all_scrapers(title, media_type) runs all scrapers in parallel and
returns a flat list of stream dicts: [{'label', 'url', 'source'}].
"""

import re
import unicodedata
import xbmc
import xbmcaddon
import xbmcvfs

ADDON     = xbmcaddon.Addon()
_PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

try:
    import requests as _requests
    from resources.lib import cache as _cache
    _cache.init(_CACHE_DB)
    _HAS_REQUESTS = True
except Exception:
    _HAS_REQUESTS = False

CUEVANA3_BASE  = 'https://www.cuevana3.eu'
HDTODAYZ_BASE  = 'https://hdtodayz.to'
NETMIRROR_BASE = 'https://netmirror.app'
ZAXFLIX_BASE   = 'https://zaxflix.com'
RAREFILMM_BASE = 'https://rarefilmm.com'
SHOWS1_BASE    = 'https://www.1shows.org'
M456_BASE      = 'https://456movie.nl'
MSEARCH_BASE   = 'https://msearch.vercel.app'

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
}

_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE = re.compile(r'\s+')
_RE_NONALNUM   = re.compile(r'[^a-z0-9 ]')
_STREAM_SKIP   = re.compile(
    r'(?:rapidgator|nitroflare|keep2share|uploaded\.net|frdl\.io|'
    r'facebook\.com|twitter\.com|google\.com|youtube\.com)',
    re.IGNORECASE
)

_session = None


def _sess():
    global _session
    if not _HAS_REQUESTS:
        return None
    if _session is None:
        _session = _requests.Session()
        _session.headers.update(_HEADERS)
        a = _requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=12,
            max_retries=_requests.adapters.Retry(total=0)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get(url, timeout=(6, 12)):
    s = _sess()
    if not s:
        return ''
    try:
        r = s.get(url, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] GET failed (%s): %s' % (url[:70], e), xbmc.LOGWARNING)
        return ''


def _get_json(url, timeout=(6, 12)):
    s = _sess()
    if not s:
        return None
    try:
        r = s.get(url, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] JSON GET failed (%s): %s' % (url[:70], e), xbmc.LOGWARNING)
        return None


def _clean(text):
    text = _RE_STRIP_TAGS.sub(' ', text)
    return _RE_WHITESPACE.sub(' ', text).strip()


def _og(html, prop):
    """Extract og: meta property value."""
    m = re.search(
        r'<meta[^>]+property=["\']og:%s["\'][^>]+content=["\']([^"\']+)["\']' % re.escape(prop),
        html, re.IGNORECASE
    )
    if not m:
        m = re.search(
            r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:%s["\']' % re.escape(prop),
            html, re.IGNORECASE
        )
    return _clean(m.group(1)) if m else ''


def _norm_title(title):
    title = title.lower()
    title = ''.join(
        c for c in unicodedata.normalize('NFD', title)
        if unicodedata.category(c) != 'Mn'
    )
    title = _RE_NONALNUM.sub('', title)
    return _RE_WHITESPACE.sub(' ', title).strip()


def _extract_embeds(html):
    """Extract all playable iframe/embed/data-* URLs from an HTML page."""
    seen, embeds = set(), []

    # iframes
    for m in re.finditer(
        r'<iframe[^>]+(?:src|data-src)=["\']([^"\']{10,})["\']', html, re.IGNORECASE
    ):
        url = m.group(1).strip()
        if not url.startswith('http') or url in seen:
            continue
        if _STREAM_SKIP.search(url):
            continue
        seen.add(url)
        dom = re.search(r'https?://(?:www\.)?([^./]+)', url)
        label = dom.group(1).capitalize() if dom else 'Embed'
        embeds.append({'label': label, 'url': url})

    # data-* stream attributes (DooPlay / TPostMv themes)
    for m in re.finditer(
        r'data-(?:fl-url|src|embed|player|lazy-src)=["\']([^"\']{10,})["\']',
        html, re.IGNORECASE
    ):
        url = m.group(1).strip()
        if not url.startswith('http') or url in seen:
            continue
        if _STREAM_SKIP.search(url):
            continue
        seen.add(url)
        dom = re.search(r'https?://(?:www\.)?([^./]+)', url)
        label = dom.group(1).capitalize() if dom else 'Stream'
        embeds.append({'label': label, 'url': url})

    # Direct video file links (mp4 / m3u8 / mkv)
    for m in re.finditer(
        r'["\' ](https?://[^"\'<\s]+\.(?:mp4|m3u8|mkv|avi|mov)[^"\'<\s]*)["\' ]',
        html, re.IGNORECASE
    ):
        url = m.group(1).strip()
        if url in seen:
            continue
        seen.add(url)
        embeds.append({'label': 'Direct', 'url': url})

    return embeds


def _h1_title(html):
    m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
    return _clean(m.group(1)) if m else ''


def _strip_site_suffix(title):
    return re.sub(r'\s*[|\-–—].*$', '', title).strip()


def _cache_get(key):
    try:
        return _cache.get(key)
    except Exception:
        return None


def _cache_set(key, value, ttl):
    try:
        _cache.set(key, value, ttl)
    except Exception:
        pass


def _pfetch(stubs, fn, limit=5):
    """Fetch up to limit stubs concurrently, return non-None results."""
    from concurrent.futures import ThreadPoolExecutor
    batch = stubs[:limit]
    if not batch:
        return []
    with ThreadPoolExecutor(max_workers=min(len(batch), 5)) as pool:
        results = list(pool.map(fn, batch, timeout=20))
    return [r for r in results if r and r.get('streams')]


# ── cuevana3.eu ───────────────────────────────────────────────────────────────

_RE_CUEVANA_CARD = re.compile(
    r'href="(https?://(?:www\.)?cuevana3\.[a-z]+/(?:peliculas?|movies?|series?|ver)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_CUEVANA_SKIP = {
    'page', 'category', 'tag', 'search', 'genre', 'actor', 'director',
    'year', 'country', 'tipo', 'fecha', 'calidad', 'idioma',
}


def _cuevana3_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (CUEVANA3_BASE, _q(title)))
    stubs, seen = [], set()
    for m in _RE_CUEVANA_CARD.finditer(html):
        url, slug = m.group(1), m.group(2)
        if slug not in _CUEVANA_SKIP and slug not in seen:
            seen.add(slug)
            stubs.append({'url': url, 'slug': slug})
    return stubs


def _cuevana3_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_cuevana3_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    title = re.sub(r'^(?:ver|watch)\s+', '', title, flags=re.IGNORECASE).strip()
    embeds = _extract_embeds(html)
    film = {
        'id': 'cuevana3_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'cuevana3', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_cuevana3(title, media_type='movie'):
    try:
        stubs = _cuevana3_search_stubs(title)
        return _pfetch(stubs, _cuevana3_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] cuevana3 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── hdtodayz.to ───────────────────────────────────────────────────────────────

_RE_HDTODAYZ_CARD = re.compile(
    r'href="(https?://hdtodayz\.to/(?:movie|watch|tv)?/?([a-z0-9][a-z0-9-]+)[^"]*)"',
    re.IGNORECASE
)
_HDTODAYZ_SKIP = {
    'page', 'category', 'tag', 'genre', 'actor', 'director', 'country',
    'year', 'search', 'watchlist', 'request', 'contact',
}


def _hdtodayz_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (HDTODAYZ_BASE, _q(title)))
    stubs, seen = [], set()
    for m in _RE_HDTODAYZ_CARD.finditer(html):
        url, slug = m.group(1), m.group(2)
        if slug not in _HDTODAYZ_SKIP and slug not in seen:
            seen.add(slug)
            stubs.append({'url': url, 'slug': slug})
    return stubs


def _hdtodayz_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_hdtodayz_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': 'hdtodayz_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'hdtodayz', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_hdtodayz(title, media_type='movie'):
    try:
        stubs = _hdtodayz_search_stubs(title)
        return _pfetch(stubs, _hdtodayz_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] hdtodayz error: %s' % e, xbmc.LOGWARNING)
        return []


# ── netmirror.app ─────────────────────────────────────────────────────────────

_RE_NETMIRROR_CARD = re.compile(
    r'href="(https?://(?:www\.)?netmirror\.app/(?:movie|show|watch|film)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_RE_NETMIRROR_CARD_ALT = re.compile(
    r'href="(https?://(?:www\.)?netmirror\.app/([a-z0-9][a-z0-9/-]+)[^"]*)"',
    re.IGNORECASE
)
_NETMIRROR_SKIP = {
    'page', 'category', 'tag', 'genre', 'search', 'about',
    'contact', 'privacy', 'dmca', 'sitemap',
}


def _netmirror_search_stubs(title):
    from urllib.parse import quote as _q
    for search_url in [
        '%s/search?q=%s' % (NETMIRROR_BASE, _q(title)),
        '%s/?s=%s' % (NETMIRROR_BASE, _q(title)),
    ]:
        html = _get(search_url)
        if not html:
            continue
        stubs, seen = [], set()
        for pattern in (_RE_NETMIRROR_CARD, _RE_NETMIRROR_CARD_ALT):
            for m in pattern.finditer(html):
                url, slug = m.group(1), m.group(2).strip('/')
                slug_key = slug.split('/')[0]
                if slug_key not in _NETMIRROR_SKIP and slug not in seen:
                    seen.add(slug)
                    stubs.append({'url': url, 'slug': re.sub(r'[^a-z0-9-]', '-', slug_key)})
        if stubs:
            return stubs
    return []


def _netmirror_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_netmirror_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': 'netmirror_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'netmirror', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_netmirror(title, media_type='movie'):
    try:
        stubs = _netmirror_search_stubs(title)
        return _pfetch(stubs, _netmirror_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] netmirror error: %s' % e, xbmc.LOGWARNING)
        return []


# ── zaxflix.com ───────────────────────────────────────────────────────────────

_RE_ZAXFLIX_CARD = re.compile(
    r'href="(https?://(?:www\.)?zaxflix\.com/(?:film|movie|serie|show|watch|ver)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_RE_ZAXFLIX_CARD_ALT = re.compile(
    r'href="(https?://(?:www\.)?zaxflix\.com/([a-z0-9][a-z0-9-]+)/?)"',
    re.IGNORECASE
)
_ZAXFLIX_SKIP = {
    'page', 'category', 'tag', 'genre', 'search', 'about', 'contact',
    'privacy', 'dmca', 'sitemap', 'login', 'register',
}


def _zaxflix_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (ZAXFLIX_BASE, _q(title)))
    stubs, seen = [], set()
    for pattern in (_RE_ZAXFLIX_CARD, _RE_ZAXFLIX_CARD_ALT):
        for m in pattern.finditer(html):
            url, slug = m.group(1), m.group(2)
            if slug not in _ZAXFLIX_SKIP and slug not in seen:
                seen.add(slug)
                stubs.append({'url': url, 'slug': slug})
    return stubs


def _zaxflix_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_zaxflix_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': 'zaxflix_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'zaxflix', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_zaxflix(title, media_type='movie'):
    try:
        stubs = _zaxflix_search_stubs(title)
        return _pfetch(stubs, _zaxflix_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] zaxflix error: %s' % e, xbmc.LOGWARNING)
        return []


# ── rarefilmm.com ─────────────────────────────────────────────────────────────
# Classic/rare film archive. Film pages often have direct MP4/embed links.

_RE_RAREFILMM_RESULT = re.compile(
    r'<h2[^>]+class="[^"]*entry-title[^"]*"[^>]*>\s*<a[^>]+href="([^"]+)"',
    re.IGNORECASE
)
_RE_RAREFILMM_RESULT_ALT = re.compile(
    r'href="(https?://rarefilmm\.com/\d{4}/\d{2}/[^"/?#]+/?)(?:")',
    re.IGNORECASE
)
_RE_RAREFILMM_STREAM = re.compile(
    r'(https?://[^"\'<\s]+\.(?:mp4|m3u8|mkv|avi|mov)(?:\?[^"\'<\s]*)?)',
    re.IGNORECASE
)
_RE_RAREFILMM_ARCHIVE = re.compile(
    r'href="(https?://(?:archive\.org|ia800[^.]+\.us\.archive\.org)/[^"]+\.(?:mp4|mkv|ogv))"',
    re.IGNORECASE
)


def search_rarefilmm(title, media_type='movie'):
    from urllib.parse import quote as _q
    try:
        html = _get('%s/?s=%s' % (RAREFILMM_BASE, _q(title)))
        film_urls = []
        seen = set()
        for pattern in (_RE_RAREFILMM_RESULT, _RE_RAREFILMM_RESULT_ALT):
            for m in pattern.finditer(html):
                u = m.group(1)
                if u not in seen and 'rarefilmm.com' in u:
                    seen.add(u)
                    film_urls.append(u)

        results = []
        for film_url in film_urls[:5]:
            try:
                detail_html = _get(film_url)
                if not detail_html:
                    continue
                film_title = _h1_title(detail_html) or _strip_site_suffix(_og(detail_html, 'title')) or ''
                if not film_title:
                    continue
                thumb   = _og(detail_html, 'image')
                streams = []
                for sm in _RE_RAREFILMM_STREAM.finditer(detail_html):
                    su = sm.group(1)
                    if su not in {s['url'] for s in streams}:
                        streams.append({'label': 'RareFilmm Direct', 'url': su})
                for sm in _RE_RAREFILMM_ARCHIVE.finditer(detail_html):
                    su = sm.group(1)
                    if su not in {s['url'] for s in streams}:
                        streams.append({'label': 'Archive.org', 'url': su})
                streams.extend(_extract_embeds(detail_html))
                if streams:
                    results.append({
                        'id':          'rarefilmm_%s' % re.sub(r'[^a-z0-9]', '_', film_title.lower())[:40],
                        'title':       film_title,
                        'title_norm':  _norm_title(film_title),
                        'thumb':       thumb,
                        'description': _og(detail_html, 'description')[:300],
                        'url':         film_url,
                        'source':      'rarefilmm',
                        'streams':     streams,
                    })
            except Exception as de:
                xbmc.log('[Starfleet/Scrapers] rarefilmm detail error: %s' % de, xbmc.LOGWARNING)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] rarefilmm search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 1shows.org ────────────────────────────────────────────────────────────────

_RE_1SHOWS_CARD = re.compile(
    r'href="(https?://(?:www\.)?1shows\.org/(?:[a-z0-9-]+/)*([a-z0-9][a-z0-9-]+)/?)"',
    re.IGNORECASE
)
_1SHOWS_SKIP = {
    'page', 'category', 'tag', 'genre', 'country', 'year', 'actor',
    'search', 'watchlist', 'request', 'contact', 'dmca', 'privacy',
    'movies', 'series', 'shows', 'home',
}


def _1shows_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (SHOWS1_BASE, _q(title)))
    stubs, seen = [], set()
    for m in _RE_1SHOWS_CARD.finditer(html):
        url, slug = m.group(1), m.group(2)
        if slug not in _1SHOWS_SKIP and slug not in seen:
            seen.add(slug)
            stubs.append({'url': url, 'slug': slug})
    return stubs


def _1shows_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_1shows_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': '1shows_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': '1shows', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_1shows(title, media_type='movie'):
    try:
        stubs = _1shows_search_stubs(title)
        return _pfetch(stubs, _1shows_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] 1shows error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 456movie.nl ───────────────────────────────────────────────────────────────

_RE_456_CARD = re.compile(
    r'href="(https?://(?:www\.)?456movie\.nl/(?:movie|film|series|watch)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_RE_456_CARD_ALT = re.compile(
    r'href="(https?://(?:www\.)?456movie\.nl/([a-z0-9][a-z0-9-]+)/?)"',
    re.IGNORECASE
)
_456_SKIP = {
    'page', 'category', 'tag', 'genre', 'search', 'about', 'contact',
    'privacy', 'dmca', 'sitemap', 'movies', 'series', 'home',
}


def _456_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (M456_BASE, _q(title)))
    stubs, seen = [], set()
    for pattern in (_RE_456_CARD, _RE_456_CARD_ALT):
        for m in pattern.finditer(html):
            url, slug = m.group(1), m.group(2)
            if slug not in _456_SKIP and slug not in seen:
                seen.add(slug)
                stubs.append({'url': url, 'slug': slug})
    return stubs


def _456_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_456movie_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': '456movie_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': '456movie', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_456movie(title, media_type='movie'):
    try:
        stubs = _456_search_stubs(title)
        return _pfetch(stubs, _456_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] 456movie error: %s' % e, xbmc.LOGWARNING)
        return []


# ── msearch.vercel.app ────────────────────────────────────────────────────────
# Meta-search aggregator. Tries JSON API first, falls back to HTML scrape.

_RE_MSEARCH_STREAM = re.compile(
    r'(https?://[^"\'<\s]+\.(?:mp4|m3u8|mkv)[^"\'<\s]*)',
    re.IGNORECASE
)


def search_msearch(title, media_type='movie'):
    from urllib.parse import quote as _q
    try:
        # Try JSON API endpoint (common for Vercel Next.js apps)
        data = _get_json('%s/api/search?q=%s&type=%s' % (MSEARCH_BASE, _q(title), media_type))
        if data and isinstance(data, (list, dict)):
            results_raw = data if isinstance(data, list) else (
                data.get('results') or data.get('data') or data.get('items') or []
            )
            films = []
            for item in results_raw[:8]:
                film_title = (
                    item.get('title') or item.get('name') or item.get('t') or ''
                )
                if not film_title:
                    continue
                streams = []
                for key in ('stream', 'url', 'src', 'link', 'video'):
                    su = item.get(key, '')
                    if su and su.startswith('http') and su not in {s['url'] for s in streams}:
                        streams.append({'label': 'MSearch', 'url': su})
                for su in (item.get('sources') or item.get('streams') or []):
                    u = su if isinstance(su, str) else su.get('url', '')
                    if u and u not in {s['url'] for s in streams}:
                        streams.append({'label': 'MSearch', 'url': u})
                if streams:
                    films.append({
                        'id': 'msearch_%s' % re.sub(r'[^a-z0-9]', '_', film_title.lower())[:40],
                        'title': film_title, 'title_norm': _norm_title(film_title),
                        'thumb': item.get('poster') or item.get('thumb') or item.get('image') or '',
                        'description': item.get('plot') or item.get('description') or '',
                        'url': item.get('url') or MSEARCH_BASE, 'source': 'msearch',
                        'streams': streams,
                    })
            if films:
                return films

        # Fallback: HTML scrape
        html = _get('%s/search?q=%s' % (MSEARCH_BASE, _q(title)))
        if not html:
            html = _get('%s/?s=%s' % (MSEARCH_BASE, _q(title)))
        if html:
            streams = []
            for m in _RE_MSEARCH_STREAM.finditer(html):
                su = m.group(1)
                if su not in {s['url'] for s in streams}:
                    streams.append({'label': 'MSearch', 'url': su})
            embeds = _extract_embeds(html)
            streams.extend(embeds)
            if streams:
                return [{
                    'id': 'msearch_results', 'title': title,
                    'title_norm': _norm_title(title), 'thumb': '',
                    'description': '', 'url': MSEARCH_BASE,
                    'source': 'msearch', 'streams': streams,
                }]
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] msearch error: %s' % e, xbmc.LOGWARNING)
    return []


# ── Title matching ────────────────────────────────────────────────────────────

def _title_matches(norm_query, norm_film):
    """Return True if the normalised query matches a film title closely enough."""
    if not norm_query or not norm_film:
        return False
    if norm_query == norm_film:
        return True
    q_words = norm_query.split()
    f_words = norm_film.split()
    if len(q_words) >= 2 and all(w in norm_film for w in q_words):
        return True
    if len(f_words) >= 2 and all(w in norm_query for w in f_words):
        return True
    return False


# ── Unified search ────────────────────────────────────────────────────────────

def search_all_scrapers(title, media_type='movie'):
    """
    Search all scraper sources in parallel for the given title.
    Works for media_type 'movie', 'tv', or 'adult' — no content is filtered
    at the scraper level; resolution happens via ResolveURL at play time.

    Returns list of {'label', 'url', 'source'} stream dicts.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    if not _HAS_REQUESTS or not title:
        return []

    norm_query = _norm_title(title)

    tasks = {
        'cuevana3':  lambda: search_cuevana3(title, media_type),
        'hdtodayz':  lambda: search_hdtodayz(title, media_type),
        'netmirror': lambda: search_netmirror(title, media_type),
        'zaxflix':   lambda: search_zaxflix(title, media_type),
        'rarefilmm': lambda: search_rarefilmm(title, media_type),
        '1shows':    lambda: search_1shows(title, media_type),
        '456movie':  lambda: search_456movie(title, media_type),
        'msearch':   lambda: search_msearch(title, media_type),
    }

    streams    = []
    seen_urls  = set()

    with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        try:
            for future in as_completed(futures, timeout=35):
                name = futures[future]
                try:
                    films = future.result() or []
                    for film in films:
                        if not film:
                            continue
                        # Accept if title matches OR if scraper already filtered by search
                        if _title_matches(norm_query, film.get('title_norm', '')):
                            for s in film.get('streams', []):
                                if s.get('url') and s['url'] not in seen_urls:
                                    seen_urls.add(s['url'])
                                    streams.append({
                                        'label':  '[%s] %s' % (name.upper(), s.get('label', 'Stream')),
                                        'url':    s['url'],
                                        'source': name,
                                    })
                except Exception as e:
                    xbmc.log('[Starfleet/Scrapers] %s search error: %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Scrapers] search_all_scrapers timeout: %s' % e, xbmc.LOGWARNING)

    xbmc.log(
        '[Starfleet/Scrapers] search_all_scrapers "%s" (%s) → %d streams'
        % (title, media_type, len(streams)),
        xbmc.LOGINFO
    )
    return streams
