# -*- coding: utf-8 -*-
"""Public BitTorrent tracker list for magnet links.

A magnet that only carries an info-hash (or just a few trackers) starts slowly and, for older releases, may never
find peers. add_to_magnet() adds a current list of working public trackers to it; get() returns that list.

The list is the community-maintained "trackers best" file (https://github.com/ngosang/trackerslist, refreshed
daily). It is downloaded at most once a day into the addon's profile folder; if it cannot be fetched the last
copy is used, and if there is none the built-in list below. The fetch never blocks for more than a few seconds
and never raises.
"""
import os
import re
import time
from urllib.parse import quote

try:
    import xbmc
    import xbmcvfs
except ImportError:                      # plain Python (tests)
    xbmc = xbmcvfs = None

_URLS = ('https://ngosang.github.io/trackerslist/trackers_best.txt',
         'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt',
         'https://cdn.jsdelivr.net/gh/ngosang/trackerslist@master/trackers_best.txt')
_MAX_AGE = 24 * 3600
_MAX_TRACKERS = 40

# last-resort list (also kept in the list when the download works: a few of these are not in the daily file)
_BUILTIN = (
    'udp://tracker.opentrackr.org:1337/announce',
    'udp://open.stealth.si:80/announce',
    'udp://tracker.torrent.eu.org:451/announce',
    'udp://open.tracker.cl:1337/announce',
    'udp://exodus.desync.com:6969/announce',
    'udp://tracker.openbittorrent.com:6969/announce',
    'udp://tracker.dler.com:6969/announce',
    'udp://open.demonii.com:1337/announce',
    'udp://tracker.tiny-vps.com:6969/announce',
    'udp://tracker.moeking.me:6969/announce',
)

_mem = {'t': 0.0, 'list': None}


def _log(msg):
    if xbmc:
        try:
            xbmc.log('[Starfleet/Trackers] %s' % msg, xbmc.LOGINFO)
        except Exception:
            pass


def _cache_path():
    try:
        base = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/')
        if not os.path.isdir(base):
            os.makedirs(base)
        return os.path.join(base, 'trackers_best.txt')
    except Exception:
        return None


def _parse(text):
    out = []
    for line in (text or '').splitlines():
        line = line.strip()
        if re.match(r'^(udp|http|https|ws|wss)://\S+$', line) and line not in out:
            out.append(line)
    return out


def _download(timeout=4):
    try:
        import requests
    except ImportError:
        return None
    for url in _URLS:
        try:
            r = requests.get(url, timeout=timeout, headers={'User-Agent': 'Mozilla/5.0'})
            if r.status_code == 200:
                got = _parse(r.text)
                if len(got) >= 5:
                    return got
        except Exception:
            continue
    return None


def get(refresh=False):
    """Tracker announce URLs, best first (daily list, then the built-in extras), at most 40."""
    now = time.time()
    if _mem['list'] and not refresh and now - _mem['t'] < 3600:
        return list(_mem['list'])
    path = _cache_path()
    fresh = None
    try:
        age = now - os.path.getmtime(path) if path and os.path.exists(path) else None
    except OSError:
        age = None
    if path and age is not None and age < _MAX_AGE and not refresh:
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                fresh = _parse(fh.read())
        except Exception:
            fresh = None
    if not fresh:
        fresh = _download()
        if fresh:
            _log('downloaded %d trackers' % len(fresh))
            if path:
                try:
                    with open(path, 'w', encoding='utf-8') as fh:
                        fh.write('\n'.join(fresh) + '\n')
                except Exception:
                    pass
        elif path and os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as fh:
                    fresh = _parse(fh.read())
            except Exception:
                fresh = None
    merged = []
    for t in list(fresh or []) + list(_BUILTIN):
        if t not in merged:
            merged.append(t)
    merged = merged[:_MAX_TRACKERS]
    _mem['list'], _mem['t'] = merged, now
    return list(merged)


def add_to_magnet(magnet, min_existing=6):
    """The same magnet with the public trackers added (only when it carries fewer than `min_existing`)."""
    if not magnet or not magnet.startswith('magnet:'):
        return magnet
    have = re.findall(r'[?&]tr=([^&]+)', magnet)
    if len(have) >= min_existing:
        return magnet
    try:
        from urllib.parse import unquote
        known = {unquote(h).lower() for h in have}
        extra = ''.join('&tr=' + quote(t, safe='') for t in get() if t.lower() not in known)
        return magnet + extra
    except Exception:
        return magnet
