# -*- coding: utf-8 -*-
"""
service.py — Kodi background service entry point (xbmc.python.service,
start="startup" in addon.xml). Runs for the whole Kodi session, unlike
default.py's plugin:// invocations which are fresh, short-lived processes
(this addon explicitly sets reuselanguageinvoker=false) — see
resources/lib/local_proxy.py's own docstring for why that distinction is
exactly what OK.ru playback needed.
"""
import xbmc

try:
    from resources.lib import tls_speed
    tls_speed.install()
except Exception:
    pass

try:                                          # the checked IPTV playlists were removed: free the lists they had downloaded (once)
    import os
    import shutil
    import xbmcvfs
    _old = xbmcvfs.translatePath('special://profile/addon_data/script.module.starfleetscrapers/m3ulists/')
    if os.path.isdir(_old):
        shutil.rmtree(_old, ignore_errors=True)
except Exception:
    pass

from resources.lib import local_proxy

# One scheduler for every background job (resources/lib/bg_scheduler.py): two threads instead of about ten, heavy jobs one at a
# time, none while something plays (unless essential) and none while the device is short of memory.
try:
    import threading
    from resources.lib import bg_scheduler as _sched

    def _job(module, attr, *a):
        def _fn():
            import importlib
            return getattr(importlib.import_module(module), attr)(*a)
        return _fn

    _sched.add('connections', _job('resources.lib.torrent_sources', 'prewarm'), first=1, every=None, playing_ok=True)
    _sched.add('update-check', _job('resources.lib.dep_check', 'run'), first=3, every=None, playing_ok=True)
    _sched.add('memory-log', _job('resources.lib.memguard', 'tick'), first=30, every=lambda r: r or 120, heavy=False,
               playing_ok=True, low_mem_ok=True)
    _sched.add('my-teams', _job('resources.lib.myteams_alerts', 'tick'), first=45, every=lambda r: r or 480,
               playing_ok=True, low_mem_ok=True)
    _sched.add('tracker-sync', _job('resources.lib.tracker_sync', 'tick'), first=40, every=lambda r: r or 900)
    _sched.add('requests-warm', _job('resources.lib.request_sources', 'warm'), first=60, every=None)
    _sched.add('simkl-flush', _job('resources.lib.simkl_sync', 'flush_pending'), first=120, every=20 * 60, playing_ok=True)
    _sched.add('adult-prewarm', _job('resources.lib.adult_prewarm', 'tick'), first=90, every=lambda r: r or 300)
    _sched.add('new-episodes', _job('resources.lib.airing_prep', 'tick'), first=15 * 60, every=30 * 60)   # not at launch: it asks the debrid services
    threading.Thread(target=_sched.run, args=(xbmc.Monitor(),), daemon=True).start()
except Exception as _e:
    xbmc.log('[Starfleet] background scheduler did not start: %s' % _e, xbmc.LOGWARNING)

local_proxy.run_service(xbmc.Monitor())
