# -*- coding: utf-8 -*-
"""
resources/lib/afdb_router.py — Adult Film Database section

Menu structure:
  🔞 Adult
    ├── 🆕 New Releases
    ├── 🏆 Most Popular
    ├── 🎭 Browse by Category
    ├── 🎬 Browse by Studio  (A-Z)
    ├── 👤 Browse by Actor   (A-Z)
    └── 🔍 Search

Each film item opens a detail page with:
  - Full description / synopsis
  - Cast list (each actor is browsable)
  - Studio, Director, Year, Runtime, Rating
  - Front cover as thumbnail
  - Large front cover as fanart
  - Back cover as additional art
  - Categories as genre tags

Playback:
  - No stream URL yet → shows "Add stream source" dialog
  - When a stream URL is supplied (StreamTape, DoodStream, etc.)
    it is passed to ResolveURL/URLResolver for resolution
  - Falls back to direct play if ResolveURL not installed
"""

import re as _re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon


def _extract_year(title):
    """Pull the most recent 4-digit year from a title string (1980–2099)."""
    years = _re.findall(r'\b(19[89]\d|20[0-9]\d)\b', title or '')
    return max(int(y) for y in years) if years else 0

from resources.lib import afdb
from resources.lib import cache as _cache
from concurrent.futures import ThreadPoolExecutor

ADDON     = xbmcaddon.Addon()
PAGE_SIZE = 30


# ── Helpers ───────────────────────────────────────────────────────────────────

def _add_dir(handle, build_url, label, params, thumb='', plot=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_film(handle, build_url, film):
    """Add a film as a directly-playable item with the richest available metadata.

    Priority chain:
      thumb  : ADE CDN (highest quality) → AFDB 400 px front → AFDB 200 px front
      fanart : AFDB 400 px front cover (always available by URL pattern)
      banner : AFDB back cover
      landscape / extra fanarts : AFDB scene screenshots
      metadata : AFDB detail (year/studio/director/cast/categories/synopsis)
                 ADE detail (fills any gaps + adds runtime/rating)
    """
    import re as _re

    # 1. Seed from the slim card dict (id, slug, title, thumb from list page)
    d = dict(film)

    # 2. Merge AFDB full detail (prewarm cache)
    full_afdb = _cache.get('afdb_film_%s' % film.get('id', ''))
    if full_afdb:
        for k, v in full_afdb.items():
            if v and not d.get(k):
                d[k] = v
        # Screenshots live only in full detail — always take them
        if full_afdb.get('screenshots'):
            d['screenshots'] = full_afdb['screenshots']

    # 3. Merge ADE search result → higher-quality CDN thumb + description gap-fill
    _ade_ck = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', d.get('title', '').lower())[:80]
    ade_search = _cache.get(_ade_ck)
    ade_film_id = ''
    if ade_search and isinstance(ade_search, dict):
        ade_film_id = ade_search.get('id', '')
        # ADE CDN thumb is typically 600-1200 px — prefer over AFDB 200 px
        if ade_search.get('thumb') and ade_search.get('fanart'):
            d.setdefault('ade_thumb',  ade_search['thumb'])
            d.setdefault('ade_fanart', ade_search['fanart'])
        for k in ('description', 'year', 'studio', 'director'):
            if not d.get(k) and ade_search.get(k):
                d[k] = ade_search[k]
        if not d.get('cast') and ade_search.get('cast'):
            d['cast'] = ade_search['cast']

    # 4. Merge ADE full detail → runtime, rating, genres, cast, synopsis
    if ade_film_id:
        ade_detail = _cache.get('ade_detail_%s' % ade_film_id)
        if ade_detail and isinstance(ade_detail, dict):
            for k in ('description', 'year', 'studio', 'director', 'runtime', 'rating'):
                if not d.get(k) and ade_detail.get(k):
                    d[k] = ade_detail[k]
            if not d.get('categories') and ade_detail.get('categories'):
                d['categories'] = ade_detail['categories']
            if not d.get('cast') and ade_detail.get('cast'):
                d['cast'] = ade_detail['cast']
            # ADE CDN thumb from detail (wider search in full page)
            if ade_detail.get('thumb') and not d.get('ade_thumb'):
                d['ade_thumb']  = ade_detail['thumb']
                d['ade_fanart'] = ade_detail.get('fanart', ade_detail['thumb'])

    # 5. Build best-available artwork URLs
    film_id   = film.get('id', '')
    # Thumb: ADE CDN (highest quality) → AFDB 200px front → whatever card supplied
    best_thumb = (
        d.get('ade_thumb')
        or (afdb.thumb_url(film_id) if film_id else '')
        or d.get('thumb', '')
    )
    fanart = (
        d.get('ade_fanart')
        or (afdb.thumb_url(film_id) if film_id else '')
        or d.get('fanart', best_thumb)
    )
    backcover    = d.get('backcover', '')
    screenshots  = d.get('screenshots', [])

    li = xbmcgui.ListItem(label=d['title'])

    # 6. Set Kodi metadata
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(d['title'])
        tag.setPlot(d.get('description', ''))
        if str(d.get('year', '')).isdigit():
            tag.setYear(int(d['year']))
        if d.get('studio'):
            tag.setStudios([d['studio']])
        if d.get('categories'):
            tag.setGenres(d['categories'])
        if d.get('director'):
            tag.setDirectors([d['director']])
        if d.get('rating'):
            try:
                tag.setRating(float(d['rating']))
            except (ValueError, TypeError):
                pass
        if d.get('runtime'):
            try:
                tag.setDuration(int(d['runtime']) * 60)
            except (ValueError, TypeError):
                pass
        tag.setMpaa('Adults Only')
        # Cast — merge AFDB actor IDs with ADE names, attach cached photos
        cast_list = []
        seen_names = set()
        for c in (d.get('cast') or []):
            name = c.get('name', '')
            if not name or name in seen_names:
                continue
            seen_names.add(name)
            photo = ''
            actor_id = c.get('id', '')
            if actor_id:
                actor_detail = _cache.get('afdb_actor_detail_%s' % actor_id)
                photo = (actor_detail or {}).get('photo', '')
            cast_list.append(xbmcgui.Actor(name, '', 0, photo))
        if cast_list:
            tag.setCast(cast_list)
    except Exception:
        info = {
            'title':    d['title'],
            'plot':     d.get('description', ''),
            'year':     int(d['year']) if str(d.get('year', '')).isdigit() else 0,
            'studio':   d.get('studio', ''),
            'genre':    ', '.join(d.get('categories', [])),
            'director': d.get('director', ''),
            'rating':   float(d.get('rating', 0) or 0),
            'duration': int(d.get('runtime', 0) or 0) * 60,
            'mpaa':     'Adults Only',
        }
        li.setInfo('video', info)

    # 7. Artwork — richest possible set
    art = {
        'thumb':   best_thumb,
        'poster':  best_thumb,
        'fanart':  fanart,
    }
    if backcover:
        art['banner'] = backcover
    if screenshots:
        art['landscape'] = screenshots[0]
    # Additional fanart slots (Kodi 18+) — scene shots after the front-cover fanart
    for i, shot in enumerate(screenshots[:4], 2):
        art['fanart%d' % i] = shot

    li.setArt(art)

    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle, build_url({
        'action':     'afdb_play_search',
        'film_id':    film['id'],
        'film_slug':  film.get('slug', ''),
        'film_title': film['title'],
    }), li, False)


def _need_fetch(key):
    return _cache.get(key) is None


def _progress(msg):
    d = xbmcgui.DialogProgress()
    d.create('Starfleet', msg)
    return d


def _next_page(handle, build_url, action, page, extra=None):
    params = {'action': action, 'page': page + 1}
    if extra:
        params.update(extra)
    _add_dir(handle, build_url,
             label='~~ Next Page (%d) ~~' % (page + 1),
             params=params)


# ── Adult Main Menu ───────────────────────────────────────────────────────────

def _prewarm_film_details(films):
    """
    Fire-and-forget background pre-fetch of full AFDB film detail
    (description, cast, studio, director, rating, photos) for each
    slim result in a list view. User sees instant detail loads with
    no loading dialog on subsequent clicks.
    Only fetches films whose detail cache is cold.
    Max 5 concurrent requests to avoid hammering AFDB.
    """
    cold = [
        (f['id'], f['slug']) for f in films
        if f.get('id') and _need_fetch('afdb_film_%s' % f['id'])
    ]
    if not cold:
        return

    def _fetch(film_id, film_slug):
        try:
            afdb.get_film_detail(film_id, film_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for film_id, film_slug in cold:
        pool.submit(_fetch, film_id, film_slug)
    pool.shutdown(wait=False)   # never blocks the UI


def _prewarm_actor_details(films):
    """
    Pre-fetch actor photos and profiles for cast members found in
    a list of film results. Pulls actor detail for any actor whose
    photo cache is cold so browsing cast is instant.
    Capped at 10 actors to avoid excessive requests.
    """
    seen     = set()
    to_fetch = []

    for film in films:
        for actor in film.get('cast', [])[:5]:  # top 5 cast per film
            aid = actor.get('id', '')
            if aid and aid not in seen:
                seen.add(aid)
                if _need_fetch('afdb_actor_detail_%s' % aid):
                    to_fetch.append((aid, actor.get('slug', '')))
            if len(to_fetch) >= 10:
                break
        if len(to_fetch) >= 10:
            break

    if not to_fetch:
        return

    def _fetch(actor_id, actor_slug):
        try:
            afdb.get_actor_detail(actor_id, actor_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for actor_id, actor_slug in to_fetch:
        pool.submit(_fetch, actor_id, actor_slug)
    pool.shutdown(wait=False)


def _filter_films_with_sources(films):
    """
    Filter a film list to only those that have at least one cached stream source.
    Uses the adult_streams title-cache only — no new HTTP requests.
    Films not yet in any cache pass through (graceful degradation on first load).
    Background prewarm is launched for unchecked films so next load is filtered.
    """
    try:
        from resources.lib import adult_streams as _as
        _as.prewarm_title_index()   # ensure index is built from cached data

        checked = []
        unchecked = []
        for film in films:
            result = _as.has_cached_source(film.get('title', ''))
            if result is None:
                unchecked.append(film)   # not yet in any cache — show it this time
            elif result:
                checked.append(film)     # confirmed has a source
            # else: confirmed has NO source — drop it

        # Background: pre-check unchecked films so next load can filter them
        if unchecked:
            def _prewarm_check():
                for f in unchecked:
                    try:
                        _as.search_by_title(f['title'])
                    except Exception:
                        pass
            import threading
            threading.Thread(target=_prewarm_check, daemon=True).start()

        return checked + unchecked
    except Exception as e:
        xbmc.log('[AFDB] source filter error: %s' % e, xbmc.LOGWARNING)
        return films   # fail open


def adult_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Adult')
    xbmcplugin.setContent(handle, 'movies')

    _add_dir(handle, build_url, 'Movies',
             {'action': 'adult_movies_library', 'page': 1},
             plot='All movies — sources checked, sorted by most recent year')

    _add_dir(handle, build_url, 'Scenes',
             {'action': 'adult_hqp_categories'},
             plot='Browse HD scenes by category on HQ Porner')

    _add_dir(handle, build_url, 'Search',
             {'action': 'adult_search_unified'},
             plot='Search by movie title, performer name, or scene type (e.g. anal)')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_free_sites(handle, build_url):
    """Top-level menu listing all browsable free adult sites."""
    xbmcplugin.setPluginCategory(handle, 'Free Adult Sites')
    xbmcplugin.setContent(handle, 'files')

    _add_dir(handle, build_url, 'PandaMovies — Browse by Genre',
             {'action': 'adult_panda_genres'},
             plot='Browse adult movies on PandaMovies by genre category')

    _add_dir(handle, build_url, 'HQ Porner — Browse by Category',
             {'action': 'adult_hqp_categories'},
             plot='Browse HD adult movies on HQ Porner by category')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_panda_genres(handle, build_url):
    """List all genre categories from PandaMovies."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'PandaMovies — Genres')
    xbmcplugin.setContent(handle, 'files')

    dlg = _progress('Loading PandaMovies genres...')
    genres = _as.get_panda_genres()
    dlg.close()

    if not genres:
        xbmcgui.Dialog().notification('PandaMovies', 'No genres found', xbmcgui.NOTIFICATION_INFO)
        return

    for g in genres:
        _add_dir(handle, build_url, g['name'],
                 {'action': 'adult_panda_movies', 'genre_url': g['url'], 'page': 1,
                  'genre_name': g['name']},
                 plot='Browse %s movies on PandaMovies' % g['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def adult_panda_movies(handle, build_url, genre_url, genre_name='', page=1):
    """List movies from a PandaMovies genre page."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'PandaMovies — %s' % (genre_name or 'Movies'))
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading movies...')
    films = _as.get_panda_movies(genre_url, page=page)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('PandaMovies', 'No movies found', xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'mpaa': 'Adults Only'})
        if film.get('thumb'):
            li.setArt({'thumb': film['thumb'], 'poster': film['thumb'], 'fanart': film['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_panda_play', 'slug': film['slug'],
                       'film_url': film['url'], 'title': film['title']}),
            li, False
        )

    _next_page(handle, build_url, 'adult_panda_movies', page,
               extra={'genre_url': genre_url, 'genre_name': genre_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_panda_play(handle, slug, film_url, title=''):
    """Fetch PandaMovies detail, show stream picker, play via ResolveURL."""
    from resources.lib import adult_streams as _as

    dlg = _progress('Finding streams...')
    film = _as.get_panda_movie_detail(slug, film_url)
    dlg.close()

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification('PandaMovies', 'No streams found for: %s' % title,
                                       xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    film_title = title or film.get('title', '')
    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('PandaMovies', 'Could not resolve stream',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved, label=film_title)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie', 'mpaa': 'Adults Only'})
    if '.m3u8' in resolved.lower():
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in resolved.lower():
        li.setMimeType('video/mp4')
    xbmcplugin.setResolvedUrl(handle, True, li)


def adult_hqp_categories(handle, build_url):
    """List all categories from HQ Porner."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'HQ Porner — Categories')
    xbmcplugin.setContent(handle, 'files')

    dlg = _progress('Loading HQ Porner categories...')
    cats = _as.get_hqporner_categories()
    dlg.close()

    if not cats:
        xbmcgui.Dialog().notification('HQ Porner', 'No categories found', xbmcgui.NOTIFICATION_INFO)
        return

    for c in cats:
        _add_dir(handle, build_url, c['name'],
                 {'action': 'adult_hqp_movies', 'cat_url': c['url'], 'page': 1,
                  'cat_name': c['name']},
                 plot='Browse %s movies on HQ Porner' % c['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def adult_hqp_movies(handle, build_url, cat_url, cat_name='', page=1):
    """List movies from an HQ Porner category page."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'HQ Porner — %s' % (cat_name or 'Movies'))
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading movies...')
    films = _as.get_hqporner_movies(cat_url, page=page)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('HQ Porner', 'No movies found', xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'mpaa': 'Adults Only'})
        if film.get('thumb'):
            li.setArt({'thumb': film['thumb'], 'poster': film['thumb'], 'fanart': film['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_hqp_play', 'slug': film['slug'],
                       'film_url': film['url'], 'title': film['title']}),
            li, False
        )

    _next_page(handle, build_url, 'adult_hqp_movies', page,
               extra={'cat_url': cat_url, 'cat_name': cat_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_hqp_play(handle, slug, film_url, title=''):
    """Fetch HQ Porner detail, show stream picker, play."""
    from resources.lib import adult_streams as _as

    dlg = _progress('Finding streams...')
    film = _as.get_hqporner_movie_detail(slug, film_url)
    dlg.close()

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification('HQ Porner', 'No streams found for: %s' % title,
                                       xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    film_title = title or film.get('title', '')
    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('HQ Porner', 'Could not resolve stream',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved, label=film_title)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie', 'mpaa': 'Adults Only'})
    if '.m3u8' in resolved.lower():
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in resolved.lower():
        li.setMimeType('video/mp4')
    xbmcplugin.setResolvedUrl(handle, True, li)


# ── Adult Trailers ────────────────────────────────────────────────────────────

def adult_trailers(handle, build_url, page=1):
    """
    Show ADE new-release trailers as directly-playable items.
    Fetches up to 24 new releases, resolves trailer URLs in parallel,
    and shows only entries that have a playable trailer (YouTube/Vimeo/mp4).
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from resources.lib import ade as _ade

    xbmcplugin.setPluginCategory(handle, '🎬 Trailers')
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading trailers...')
    films = _ade.browse_new_releases(page=page)
    if dlg:
        dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No trailers found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    # Resolve trailer URLs in parallel — each film needs a detail fetch
    def _get_trailer(film):
        try:
            detail = _ade.get_film_detail(film['id'], film.get('slug', ''))
            trailer = detail.get('trailer', '') if detail else ''
            return film, trailer
        except Exception:
            return film, ''

    trailer_items = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(_get_trailer, f): f for f in films[:24]}
        for fut in as_completed(futures, timeout=20):
            try:
                film, trailer_url = fut.result()
                if trailer_url:
                    trailer_items.append((film, trailer_url))
            except Exception:
                pass

    if not trailer_items:
        xbmcgui.Dialog().notification('Adult', 'No trailers available right now',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    # Sort by film title
    trailer_items.sort(key=lambda x: x[0].get('title', '').lower())

    for film, trailer_url in trailer_items:
        title = film.get('title', 'Unknown')
        thumb = film.get('thumb', '') or film.get('fanart', '')
        year  = film.get('year', '')
        studio = film.get('studio', '')

        label = '[Trailer] %s' % title
        if year:
            label += ' (%s)' % year

        li = xbmcgui.ListItem(label=label)
        info = {'title': title, 'mediatype': 'movie'}
        if year:
            try:
                info['year'] = int(year)
            except (ValueError, TypeError):
                pass
        if studio:
            info['studio'] = studio
        li.setInfo('video', info)
        if thumb:
            li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_direct', 'stream_url': trailer_url, 'title': title}),
            li, False
        )

    if len(films) >= 24:
        _next_page(handle, build_url, 'adult_trailers', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Adult Movies Library ──────────────────────────────────────────────────────

def adult_movies_library(handle, build_url, page=1):
    """
    Full adult movie library with deep metadata prewarm.

    Cold visit (first time):
      Phase 1  ~3-5 s  : Parallel AFDB + ADE catalogue fetch
      Phase 2  ~15-25 s: Chunk-parallel AFDB detail + ADE detail prewarm
                         (12 concurrent; dialog shows progress percentage)
      Phase 3  instant  : Source filter (cache) + year sort

    Warm visit (subsequent):
      All three phases complete in <2 s — list renders with full metadata.
    """
    import re as _re
    import time as _time
    from resources.lib import adult_streams as _as

    xbmcplugin.setPluginCategory(handle, 'Adult Movies — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet', 'Populating list....grab a tissue')
    dlg.update(3, 'Fetching movie catalogue...')

    # ── Phase 1: Catalogue fetch ──────────────────────────────────────────────
    all_films_map = {}
    afdb_pg_offset = (page - 1) * 3
    pop_pg_offset  = (page - 1) * 2

    def _fetch_new(pg):
        try:
            return afdb.get_new_releases(page=pg) or []
        except Exception:
            return []

    def _fetch_pop(pg):
        try:
            return afdb.get_popular(page=pg) or []
        except Exception:
            return []

    def _fetch_ade_new(pg):
        try:
            from resources.lib import ade as _ade
            return _ade.browse_new_releases(page=pg) or []
        except Exception:
            return []

    with ThreadPoolExecutor(max_workers=8) as pool:
        futs = [
            pool.submit(_fetch_new, afdb_pg_offset + 1),
            pool.submit(_fetch_new, afdb_pg_offset + 2),
            pool.submit(_fetch_new, afdb_pg_offset + 3),
            pool.submit(_fetch_pop, pop_pg_offset + 1),
            pool.submit(_fetch_pop, pop_pg_offset + 2),
            pool.submit(_fetch_ade_new, page),
        ]
        for fut in futs:
            try:
                for film in (fut.result(timeout=20) or []):
                    fid = film.get('id', '')
                    if not fid:
                        fid = '%s_%s' % (film.get('source', 'ade'), film.get('slug', ''))
                    if fid and fid not in all_films_map:
                        all_films_map[fid] = film
            except Exception:
                pass

    if dlg.iscanceled():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    films     = list(all_films_map.values())
    total     = len(films)
    dlg.update(14, 'Loading artwork & metadata for %d movies...' % total)

    # ── Phase 2: Deep prewarm — AFDB detail + ADE search + ADE detail ─────────
    # Runs in chunks of 12 concurrent requests so the dialog stays responsive.
    CHUNK_SIZE = 12

    def _prewarm_film(film):
        """Fetch AFDB detail + ADE search + ADE full detail for one film."""
        fid   = film.get('id', '')
        fslug = film.get('slug', '')
        title = film.get('title', '')

        # AFDB detail (title, year, studio, director, cast, genres, description,
        #              front/back cover URLs, scene screenshots)
        if fid and _need_fetch('afdb_film_%s' % fid):
            try:
                afdb.get_film_detail(fid, fslug)
            except Exception:
                pass

        # ADE: search → detail (CDN thumb, runtime, rating, synopsis, trailer)
        if title:
            _ade_ck = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', title.lower())[:80]
            ade_cached = _cache.get(_ade_ck)
            if ade_cached is None:
                try:
                    from resources.lib import ade as _ade
                    ade_meta = _ade.search_by_title(title)
                    if ade_meta and ade_meta.get('id'):
                        _ade.get_film_detail(ade_meta['id'], ade_meta.get('slug', ''))
                except Exception:
                    pass
            elif isinstance(ade_cached, dict) and ade_cached.get('id'):
                # Search cached but detail may not be — fetch detail if cold
                ade_id = ade_cached['id']
                if _cache.get('ade_detail_%s' % ade_id) is None:
                    try:
                        from resources.lib import ade as _ade
                        _ade.get_film_detail(ade_id, ade_cached.get('slug', ''))
                    except Exception:
                        pass

    for chunk_start in range(0, total, CHUNK_SIZE):
        if dlg.iscanceled():
            break
        chunk = films[chunk_start: chunk_start + CHUNK_SIZE]
        with ThreadPoolExecutor(max_workers=len(chunk)) as pool:
            futs_chunk = [pool.submit(_prewarm_film, f) for f in chunk]
            for fut in futs_chunk:
                try:
                    fut.result(timeout=30)
                except Exception:
                    pass
        done = min(chunk_start + CHUNK_SIZE, total)
        pct  = 14 + int(72 * done / max(total, 1))
        dlg.update(pct, 'Metadata loaded: %d / %d' % (done, total))

    if dlg.iscanceled():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    # ── Phase 3: Source filter + year sort ────────────────────────────────────
    dlg.update(87, 'Checking source availability...')
    _as.prewarm_title_index()
    films = _filter_films_with_sources(films)

    dlg.update(95, 'Sorting by year...')

    def _year_key(f):
        y = f.get('year', '') or ''
        try:
            return int(str(y)[:4]) if str(y).isdigit() else 0
        except Exception:
            return 0

    films.sort(key=_year_key, reverse=True)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification(
            'Adult', 'Sources still loading — check back in a moment',
            xbmcgui.NOTIFICATION_INFO, 4000)

    for film in films:
        _add_film(handle, build_url, film)

    # Background: pre-warm stream sources for the top films so clicks are instant
    def _bg_source_prewarm():
        for f in films[:20]:
            try:
                _as.search_by_title(f.get('title', ''))
            except Exception:
                pass

    import threading
    threading.Thread(target=_bg_source_prewarm, daemon=True).start()

    _prewarm_actor_details(films[:20])

    _next_page(handle, build_url, 'adult_movies_library', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── New Releases ──────────────────────────────────────────────────────────────

def afdb_new(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🆕 New Releases')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_new_%d' % page)
    dlg  = _progress('Loading new releases...') if cold else None
    films = afdb.get_new_releases(page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    _prewarm_film_details(films)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_new', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Most Popular ──────────────────────────────────────────────────────────────

def afdb_popular(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🏆 Most Popular')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_popular_%d' % page)
    dlg  = _progress('Loading popular films...') if cold else None
    films = afdb.get_popular(page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_popular', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Categories ────────────────────────────────────────────────────────────────

def afdb_categories(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎭 Categories')
    xbmcplugin.setContent(handle, 'files')

    for cat in sorted(afdb.CATEGORIES):
        _add_dir(handle, build_url, cat,
                 {'action': 'afdb_by_category', 'category': cat, 'page': 1},
                 plot='Browse %s films' % cat)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def afdb_by_category(handle, build_url, category, page=1):
    xbmcplugin.setPluginCategory(handle, '🎭 %s' % category)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_cat_%s_%d' % (category.replace(' ', '_'), page))
    dlg  = _progress('Loading %s...' % category) if cold else None
    films = afdb.get_by_category(category, page=page)
    if dlg: dlg.close()

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_category', page,
                   extra={'category': category})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Studios ───────────────────────────────────────────────────────────────────

def afdb_studios(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '🎬 Studios — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_studios', 'letter': l})

    cold = _need_fetch('afdb_studios_%s' % letter)
    dlg  = _progress('Loading studios...') if cold else None
    studios = afdb.get_studios(letter)
    if dlg: dlg.close()

    for s in studios:
        _add_dir(handle, build_url, s['name'],
                 {'action': 'afdb_by_studio', 'studio': s['slug'],
                  'studio_name': s['name'], 'page': 1},
                 plot='Films from %s' % s['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_by_studio(handle, build_url, studio, studio_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '🎬 %s' % (studio_name or studio))
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_studio_%s_%d' % (studio.replace(' ', '_'), page))
    dlg  = _progress('Loading studio films...') if cold else None
    films = afdb.get_by_studio(studio, page=page)
    if dlg: dlg.close()

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_studio', page,
                   extra={'studio': studio, 'studio_name': studio_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Actors ────────────────────────────────────────────────────────────────────

def afdb_actors(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '👤 Actors — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_actors', 'letter': l})

    cold = _need_fetch('afdb_actors_%s' % letter)
    dlg  = _progress('Loading actors...') if cold else None
    actors = afdb.get_actors(letter)
    if dlg: dlg.close()

    for actor in actors:
        li = xbmcgui.ListItem(label=actor['name'])
        li.setInfo('video', {'title': actor['name']})
        li.setArt({
            'thumb':  actor.get('photo', ''),
            'icon':   actor.get('photo', ''),
            'poster': actor.get('photo', ''),
            'fanart': actor.get('photo_large', actor.get('photo', '')),
        })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'afdb_actor_detail',
                       'actor_id': actor['id'],
                       'actor_slug': actor['slug'],
                       'actor_name': actor['name']}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_detail(handle, build_url, actor_id, actor_slug, actor_name=''):
    """
    Show actor profile page:
    - Photo as full-screen poster/fanart
    - Bio, measurements, nationality, hair, eyes, ethnicity
    - Filmography link
    """
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'files')

    cold = afdb._cache.get('afdb_actor_detail_%s' % actor_id) is None
    dlg  = _progress('Loading %s...' % actor_name) if cold else None
    actor = afdb.get_actor_detail(actor_id, actor_slug)
    if dlg: dlg.close()

    # Build rich plot string from all available fields
    plot_parts = []
    if actor.get('birthday'):
        plot_parts.append('Born: %s' % actor['birthday'])
    if actor.get('nationality'):
        plot_parts.append('Nationality: %s' % actor['nationality'])
    if actor.get('ethnicity'):
        plot_parts.append('Ethnicity: %s' % actor['ethnicity'])
    if actor.get('measurements'):
        plot_parts.append('Measurements: %s' % actor['measurements'])
    if actor.get('height'):
        plot_parts.append('Height: %s' % actor['height'])
    if actor.get('weight'):
        plot_parts.append('Weight: %s' % actor['weight'])
    if actor.get('hair'):
        plot_parts.append('Hair: %s' % actor['hair'])
    if actor.get('eyes'):
        plot_parts.append('Eyes: %s' % actor['eyes'])
    if actor.get('bio'):
        plot_parts.append('\n%s' % actor['bio'])
    plot = '\n'.join(plot_parts)

    # Profile card item
    li = xbmcgui.ListItem(label='ℹ️  %s — Profile' % actor['name'])
    li.setInfo('video', {
        'title': actor['name'],
        'plot':  plot,
    })
    li.setArt({
        'thumb':   actor.get('photo', ''),
        'poster':  actor.get('photo', ''),
        'fanart':  actor.get('photo_large', actor.get('photo', '')),
        'banner':  actor.get('photo_large', actor.get('photo', '')),
    })
    xbmcplugin.addDirectoryItem(handle, build_url({'action': 'afdb_actor_detail',
                                                    'actor_id': actor_id,
                                                    'actor_slug': actor_slug,
                                                    'actor_name': actor['name']}),
                                li, False)

    # Filmography link
    _add_dir(handle, build_url,
             label='🎬  Filmography (%s films)' % (actor.get('filmcount') or ''),
             params={'action': 'afdb_actor_films',
                     'actor_id': actor_id,
                     'actor_slug': actor_slug,
                     'actor_name': actor['name'],
                     'page': 1},
             thumb=actor.get('photo', ''),
             plot='Browse all films featuring %s' % actor['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_films(handle, build_url, actor_id, actor_slug,
                     actor_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_actor_films_%s_%d' % (actor_id, page))
    dlg  = _progress('Loading films...') if cold else None
    films = afdb.get_by_actor(actor_id, actor_slug, page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No films found for %s' % actor_name,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_actor_films', page,
                   extra={'actor_id': actor_id, 'actor_slug': actor_slug,
                          'actor_name': actor_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Search ────────────────────────────────────────────────────────────────────

def afdb_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search Adult Film Database')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '🔍 Search: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    dlg   = _progress('Searching...')
    films = afdb.search_films(query)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        _add_film(handle, build_url, film)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Unified Search ────────────────────────────────────────────────────────────

def adult_search_unified(handle, build_url):
    """
    Single search box for: movie title, performer name, or scene type/tag.
    - If query matches an AFDB category → show films for that category
    - If query matches performer names → show matching actor filmographies
    - Otherwise → search AFDB titles + free stream sites by title
    """
    kb = xbmc.Keyboard('', 'Search movies, performers, scenes...')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, 'Search: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    query_lower = query.lower()

    # Check if query matches an AFDB category (scene type / tag search)
    category_match = None
    try:
        for cat in afdb.CATEGORIES:
            if query_lower in cat.lower() or cat.lower() in query_lower:
                category_match = cat
                break
    except Exception:
        pass

    if category_match:
        dlg = _progress('Searching "%s"...' % category_match)
        films = afdb.get_by_category(category_match, page=1)
        dlg.close()
        films = _filter_films_with_sources(films)
        for film in films:
            _add_film(handle, build_url, film)
        if films:
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
            return

    # Performer / actor search — search AFDB actor pages by walking A-Z
    # (AFDB has no actor search API; we skip this for now and rely on title search)
    actor_films = []

    # Title search across AFDB + free stream sites
    dlg = _progress('Searching "%s"...' % query)
    afdb_films = []
    try:
        afdb_films = afdb.search_films(query)
    except Exception:
        pass

    # Merge: actor films + AFDB title results (deduplicated by id)
    seen_ids = set()
    all_films = []
    for film in (actor_films + afdb_films):
        fid = film.get('id', '')
        if fid and fid not in seen_ids:
            seen_ids.add(fid)
            all_films.append(film)
    dlg.close()

    # If no AFDB results, search XXXClub torrents + free stream sites directly
    if not all_films:
        from resources.lib import adult_streams as _as
        from resources.lib import torrent_sources as _ts
        dlg = _progress('Searching "%s"...' % query)
        torrent_results = _ts.search_xxxclub(query, limit=20, media_type='adult')
        stream_results = _as.search_by_title(query)
        dlg.close()

        # Show XXXClub torrent results as individual playable items
        for t in torrent_results:
            label = '[COLOR cyan][XC][/COLOR] %s  [COLOR grey][%s][/COLOR]' % (
                t['title'], t.get('size', ''))
            li = xbmcgui.ListItem(label=label)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(t['title'])
                tag.setPlot('[XXXClub] Seeds: %d' % t.get('seeds', 0))
                tag.setMpaa('Adults Only')
            except Exception:
                li.setInfo('video', {'title': t['title'], 'mpaa': 'Adults Only'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(
                handle,
                build_url({'action': 'play_xxxclub_magnet',
                           'magnet': t['magnet'],
                           'title': t['title']}),
                li, False
            )

        # Show free stream results as individual playable items
        for s in stream_results:
            lbl = s.get('label') or query
            li = xbmcgui.ListItem(label='[COLOR yellow][Stream][/COLOR] %s' % lbl)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(lbl)
                tag.setMpaa('Adults Only')
            except Exception:
                li.setInfo('video', {'title': lbl, 'mpaa': 'Adults Only'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, s['url'], li, False)

        if torrent_results or stream_results:
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
            return

        xbmcgui.Dialog().notification('Adult', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
        return

    all_films = _filter_films_with_sources(all_films)
    for film in all_films:
        _add_film(handle, build_url, film)

    _prewarm_film_details(all_films)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Film Detail / Play ────────────────────────────────────────────────────────

def afdb_detail(handle, build_url, film_id, film_slug, film_title=''):
    """Legacy detail view — redirects to afdb_play_search."""
    afdb_play_search(handle, film_id, film_slug, film_title)


def afdb_play_search(handle, film_id, film_slug, film_title=''):
    """
    Browse AFDB for metadata → search ALL scrapers in parallel
    (trailer, personal, debrid, free streams, XXXClub, all torrent sources)
    → source picker dialog → play via ResolveURL.

    Source order: Trailer, personal, debrid [yellow], free streams,
    XXXClub [cyan], general torrents [orange].
    """
    from resources.lib import adult_streams as _as
    from resources.lib import ade as _ade
    from resources.lib import torrent_sources as _ts

    # Resolve title
    title = film_title
    year  = None
    if not title:
        cold = _need_fetch('afdb_film_%s' % film_id)
        dlg  = _progress('Loading...') if cold else None
        film_detail = afdb.get_film_detail(film_id, film_slug)
        if dlg: dlg.close()
        title = film_detail.get('title', '')
        year  = film_detail.get('year') or None
        if not film_detail.get('description') and title:
            try:
                _ade.search_by_title(title)
            except Exception:
                pass

    if not title:
        xbmcgui.Dialog().notification('Starfleet', 'Film title not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet', 'Grab a tissue, sources loading...')

    from concurrent.futures import ThreadPoolExecutor as _TPE

    def _free():
        return _as.search_by_title(title)

    def _personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(title, year=year, media_type='adult')
        except Exception:
            return []

    def _debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            raw = _dt.get_debrid_streams(title, year=year, media_type='adult')
            for s in raw:
                s['label'] = '[COLOR yellow]%s[/COLOR]' % s['label']
                s['is_debrid'] = True
            return raw
        except Exception:
            return []

    def _trailer():
        try:
            url = _ade.get_trailer_url(title)
            if url:
                return [{'label': '[Trailer]', 'url': url, 'is_trailer': True}]
        except Exception:
            pass
        return []

    def _xxxclub():
        try:
            results = _ts.search_xxxclub(title, limit=5, media_type='adult')
            out = []
            for t in results:
                qual = ''
                for tag in ('2160p', '4K', '1080p', '720p', '480p'):
                    if tag.lower() in t.get('title', '').lower():
                        qual = '  [COLOR lime][%s][/COLOR]' % tag
                        break
                seeds = ('  [COLOR grey]↑%d[/COLOR]' % t['seeds']) if t.get('seeds') else ''
                size  = ('  [COLOR grey][%s][/COLOR]' % t['size']) if t.get('size') else ''
                lbl = '[COLOR cyan][XXXClub][/COLOR] %s%s%s%s' % (
                    t.get('title', title), qual, size, seeds)
                out.append({'label': lbl, 'url': t['magnet']})
            return out
        except Exception:
            return []

    def _torrents():
        try:
            results = _ts.search_all(title, year=year, media_type='adult')
            out = []
            for t in results:
                qual = ''
                for tag in ('2160p', '4K', '1080p', '720p', '480p'):
                    if tag.lower() in t.get('title', '').lower():
                        qual = '  [COLOR lime][%s][/COLOR]' % tag
                        break
                seeds = ('  [COLOR grey]↑%d[/COLOR]' % t['seeds']) if t.get('seeds') else ''
                size  = ('  [COLOR grey][%s][/COLOR]' % t['size']) if t.get('size') else ''
                src   = t.get('source', '')
                src_tag = ('  [COLOR darkgrey]%s[/COLOR]' % src) if src else ''
                url   = t.get('magnet', '')
                if url:
                    lbl = '[COLOR orange][Torrent][/COLOR] %s%s%s%s%s' % (
                        t.get('title', title), qual, size, seeds, src_tag)
                    out.append({'label': lbl, 'url': url})
            return out
        except Exception:
            return []

    trailers = personals = debrids = frees = xxxclub = torrents = []
    try:
        with _TPE(max_workers=6) as _pool:
            _f_trailer  = _pool.submit(_trailer)
            _f_personal = _pool.submit(_personal)
            _f_debrid   = _pool.submit(_debrid)
            _f_free     = _pool.submit(_free)
            _f_xxxclub  = _pool.submit(_xxxclub)
            _f_torrents = _pool.submit(_torrents)
            try: trailers  = _f_trailer.result(timeout=15)
            except Exception: pass
            try: personals = _f_personal.result(timeout=15)
            except Exception: pass
            try: debrids   = _f_debrid.result(timeout=25)
            except Exception: pass
            try: frees     = _f_free.result(timeout=30)
            except Exception: pass
            try: xxxclub   = _f_xxxclub.result(timeout=25)
            except Exception: pass
            try: torrents  = _f_torrents.result(timeout=35)
            except Exception: pass
    finally:
        dlg.close()

    # Order: trailer, personal, debrid, free, XXXClub, torrents
    streams = trailers + personals + debrids + frees + xxxclub + torrents

    if not streams:
        xbmcgui.Dialog().notification(
            'Starfleet', 'No streams found for: %s' % title,
            xbmcgui.NOTIFICATION_WARNING, 5000
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = ['%s — %s' % (s['label'], s.get('url', '')[:40]) if s.get('is_trailer')
                   else s['label']
                   for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    elif '.mkv' in _url_lc:
        li.setMimeType('video/x-matroska')
    xbmcplugin.setResolvedUrl(handle, True, li)


_THUMB_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
)

def _thumb_ref(thumb, film_url=''):
    """Append Referer + User-Agent headers so Kodi can fetch images from protected CDNs."""
    if not thumb or '|' in thumb:
        return thumb
    import re as _re
    m = _re.match(r'(https?://[^/]+)', film_url or thumb)
    ref = (m.group(1) + '/') if m else ''
    if ref:
        return '%s|Referer=%s&User-Agent=%s' % (thumb, ref, _THUMB_UA)
    return '%s|User-Agent=%s' % (thumb, _THUMB_UA)


def _ade_enrich_background(films):
    """
    Fire-and-forget: fetch ADE metadata for free-stream films that have
    no thumbnail or description, so the next page load shows enriched data.
    Capped at 10 films per call to avoid hammering ADE.
    """
    from resources.lib import ade as _ade
    from concurrent.futures import ThreadPoolExecutor

    cold = [f for f in films
            if not f.get('thumb') or not f.get('description')][:10]
    if not cold:
        return

    def _fetch(film):
        try:
            _ade.search_by_title(film['title'])
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=4)
    for f in cold:
        pool.submit(_fetch, f)
    pool.shutdown(wait=False)


def adult_streams(handle, build_url, page=1):
    """
    Browse adult movies. Shows XXXClub torrents (fast) plus a Free Streams folder.
    Stream sources are loaded on-demand to avoid blocking the UI.
    """
    xbmcplugin.setPluginCategory(handle, 'Adult Movies — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    # Show Kodi's built-in busy spinner immediately — it renders on the UI thread
    # without waiting for Python to yield, preventing the frozen-screen effect.
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    from resources.lib import torrent_sources as _ts
    xxxclub_torrents = []
    try:
        xxxclub_torrents, _ = _ts.browse_xxxclub(cursor=str(page))
        xbmc.log('[Starfleet] XXXClub page=%d returned %d items' % (page, len(xxxclub_torrents)), xbmc.LOGWARNING)
        xxxclub_torrents.sort(key=lambda t: _extract_year(t.get('title', '')), reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet] XXXClub failed: %s' % e, xbmc.LOGWARNING)
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    # ── XXXClub torrents ──────────────────────────────────────────────────────
    for t in xxxclub_torrents:
        yr = _extract_year(t.get('title', ''))
        yr_tag = '  [COLOR grey](%d)[/COLOR]' % yr if yr else ''
        label = '[COLOR cyan][XC][/COLOR] %s%s  [COLOR grey][%s][/COLOR]' % (t['title'], yr_tag, t['size'])
        li = xbmcgui.ListItem(label=label)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(t['title'])
            tag.setPlot('[XXXClub] %s' % t['size'])
            tag.setMpaa('Adults Only')
            if yr:
                tag.setYear(yr)
        except Exception:
            info = {'title': t['title'], 'plot': '[XXXClub] %s' % t['size'], 'mpaa': 'Adults Only'}
            if yr:
                info['year'] = yr
            li.setInfo('video', info)
        if t.get('thumb'):
            li.setArt({'thumb': t['thumb'], 'poster': t['thumb'], 'icon': t['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_xxxclub_magnet',
                       'magnet': t['magnet'],
                       'title':  t['title']}),
            li, False
        )

    _next_page(handle, build_url, 'adult_streams', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_free_streams(handle, build_url, page=1):
    """
    Browse free adult stream sources (loaded on-demand to avoid UI freeze).
    """
    from resources.lib import adult_streams as _as
    import re as _re

    xbmcplugin.setPluginCategory(handle, 'Free Streams — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading free streams...')
    films = _as.get_all_stream_stubs(page=page)
    dlg.close()

    for film in (films or []):
        ade_key = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', film['title'].lower())[:80]
        ade_meta = _cache.get(ade_key)
        if ade_meta and isinstance(ade_meta, dict):
            if not film.get('thumb') and ade_meta.get('thumb'):
                film['thumb'] = ade_meta['thumb']
            if not film.get('description') and ade_meta.get('description'):
                film['description'] = ade_meta['description']

        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setPlot(film.get('description', ''))
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'plot': film.get('description', ''), 'mpaa': 'Adults Only'})

        if film.get('thumb'):
            thumb = _thumb_ref(film['thumb'], film.get('url', ''))
            li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb, 'icon': thumb})

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_stream_sources',
                       'film_id': film['id'],
                       'film_url': film.get('url', ''),
                       'title': film['title']}),
            li, False
        )

    if films:
        _ade_enrich_background(films)

    _next_page(handle, build_url, 'adult_free_streams', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_stream_sources(handle, build_url, film_id, title='', film_url=''):
    """
    Show a dialog listing all stream sources for a film, then play the chosen one.
    Always searches debrid/torrents regardless of whether free streams are cached.
    Fetches the detail page on demand if not cached (stub-based listing).
    """
    from resources.lib import adult_streams as _as
    from concurrent.futures import ThreadPoolExecutor

    # 1. Try merged cache (set by get_all_streams legacy path)
    film = _cache.get('fstreams_merged_%s' % film_id)

    # 2. Try per-source detail cache
    if not film:
        _PREFIX_CACHE = {
            'freeo_':   'fstreams_freeo_detail_%s',
            'xxxms_':   'fstreams_xxxms_detail_%s',
            'wpw_':     'fstreams_wpw_detail_%s',
            'wpf_':     'fstreams_wpf_detail_%s',
            'spn_':     'fstreams_spn_detail_%s',
            'xmovix_':  'fstreams_xmovix_detail_%s',
        }
        for prefix, ck_tpl in _PREFIX_CACHE.items():
            if film_id.startswith(prefix):
                slug = film_id[len(prefix):]
                film = _cache.get(ck_tpl % slug)
                break

    # 3. Fetch detail page on demand (stub listing path — no detail cached yet)
    if not film or not film.get('streams'):
        try:
            fetched = _as.fetch_film_detail_on_demand(film_id, film_url)
            if fetched and fetched.get('streams'):
                film = fetched
        except Exception as e:
            xbmc.log('[Starfleet/Streams] on-demand detail fetch error: %s' % e, xbmc.LOGWARNING)

    film_title  = title or (film.get('title', '') if film else '')
    cached_streams = (film.get('streams') or []) if film else []

    if not film_title:
        xbmcgui.Dialog().notification('Starfleet', 'Film title not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    def _personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(film_title, media_type='adult')
        except Exception:
            return []

    def _debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            raw = _dt.get_debrid_streams(film_title, media_type='adult')
            for s in raw:
                s['label'] = '[COLOR yellow]%s[/COLOR]' % s['label']
            return raw
        except Exception as e:
            xbmc.log('[Starfleet/Streams] debrid error: %s' % e, xbmc.LOGWARNING)
            return []

    def _site_search():
        # Always search the free streaming sites by title so AFDB browse/search
        # results also get free scraper streams, not just debrid results.
        if cached_streams:
            return cached_streams  # already have them from scraper cache
        try:
            return _as.search_by_title(film_title)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] site search error: %s' % e, xbmc.LOGWARNING)
            return []

    with ThreadPoolExecutor(max_workers=3) as pool:
        f_personal = pool.submit(_personal)
        f_debrid   = pool.submit(_debrid)
        f_sites    = pool.submit(_site_search)
        try:
            personals = f_personal.result(timeout=15)
        except Exception:
            personals = []
        try:
            debrids = f_debrid.result(timeout=40)
        except Exception:
            debrids = []
        try:
            site_free = f_sites.result(timeout=40)
        except Exception:
            site_free = []

    streams = personals + debrids + site_free

    if not streams:
        xbmcgui.Dialog().notification('Starfleet', 'No streams found for: %s' % film_title,
                                       xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    elif '.mkv' in _url_lc:
        li.setMimeType('video/x-matroska')
    xbmcplugin.setResolvedUrl(handle, True, li)


def adult_stream_play(stream_url, title=''):
    """Resolve a stream URL and return the playable URL, or '' on failure.
    Callers pass the returned URL to setResolvedUrl(handle, True, ListItem(path=url))."""
    if not stream_url:
        return ''

    # Route magnet URIs through Elementum
    if stream_url.startswith('magnet:'):
        from urllib.parse import quote as _uq
        elementum_url = 'plugin://plugin.video.elementum/play?uri=%s' % _uq(stream_url)
        xbmc.log('[Starfleet/Streams] Routing magnet via Elementum: ' + elementum_url[:80], xbmc.LOGINFO)
        return elementum_url

    resolved_url = stream_url

    # Step 1: internal resolver for embed domains ResolveURL doesn't cover
    try:
        from resources.lib import embed_resolver as _er
        internal = _er.resolve(stream_url)
        if internal:
            xbmc.log('[Starfleet/Streams] InternalResolver: %s' % internal[:80], xbmc.LOGINFO)
            resolved_url = internal
    except Exception as e:
        xbmc.log('[Starfleet/Streams] InternalResolver error: %s' % e, xbmc.LOGWARNING)

    # Step 2: ResolveURL for hosters it supports (DoodStream, MixDrop, etc.)
    if resolved_url == stream_url:
        try:
            import resolveurl
            if resolveurl.HostedMediaFile(stream_url).valid_url():
                hmf = resolveurl.HostedMediaFile(stream_url)
                resolved_url = hmf.resolve()
                xbmc.log('[Starfleet/Streams] ResolveURL: %s' % (resolved_url or 'failed')[:80], xbmc.LOGINFO)
        except ImportError:
            xbmc.log('[Starfleet/Streams] ResolveURL not installed', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        return ''

    # JS embed with unresolved # fragment — Kodi can't play it
    if resolved_url == stream_url and '#' in resolved_url:
        return ''

    return resolved_url


def afdb_play(handle, stream_url, film_id=''):
    """
    Resolve and play a stream URL via ResolveURL if available,
    otherwise direct play.
    """
    if not stream_url:
        xbmcgui.Dialog().ok(
            'Starfleet — No Stream Source',
            'No stream URL has been assigned to this film yet.\n\n'
            'To add playback support:\n'
            '1. Find the film on a hoster (StreamTape, DoodStream, etc.)\n'
            '2. The stream URL will be passed here automatically\n'
            '   once a source plugin or scraper provides it.\n\n'
            'Metadata from Adult Film Database is ready and waiting.'
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    resolved_url = stream_url

    # Try ResolveURL addon first (supports 50+ hosters)
    try:
        import resolveurl
        if resolveurl.HostedMediaFile(stream_url).valid_url():
            hmf = resolveurl.HostedMediaFile(stream_url)
            resolved_url = hmf.resolve()
            xbmc.log('[AFDB] ResolveURL resolved: %s' % resolved_url[:80],
                     xbmc.LOGINFO)
    except ImportError:
        xbmc.log('[AFDB] ResolveURL not installed — playing directly',
                 xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[AFDB] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        xbmcgui.Dialog().notification('Adult', 'Could not resolve stream URL',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved_url)
    xbmcplugin.setResolvedUrl(handle, True, li)


# ── XXXClub Browse ────────────────────────────────────────────────────────────

def xxxclub_browse(handle, build_url, cursor=''):
    """
    Browse latest torrents from XXXClub.to.
    Each item is directly playable via debrid (magnet → debrid → stream).
    """
    from resources.lib import torrent_sources as _ts

    xbmcplugin.setPluginCategory(handle, '🔞 XXXClub — Latest')
    xbmcplugin.setContent(handle, 'movies')

    dlg = xbmcgui.DialogProgress()
    dlg.create('XXXClub', 'Fetching latest torrents...')

    torrents, next_cursor = _ts.browse_xxxclub(cursor=cursor)
    dlg.close()

    if not torrents:
        xbmcgui.Dialog().notification('XXXClub', 'No results found', xbmcgui.NOTIFICATION_INFO)
        return

    for t in torrents:
        li = xbmcgui.ListItem(label='%s  [COLOR grey][%s][/COLOR]' % (t['title'], t['size']))
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(t['title'])
            tag.setPlot('[COLOR grey]%s[/COLOR]' % t['size'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': t['title'], 'plot': t['size'], 'mpaa': 'Adults Only'})
        if t.get('thumb'):
            li.setArt({'thumb': t['thumb'], 'poster': t['thumb'], 'icon': t['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_xxxclub_magnet',
                       'magnet': t['magnet'],
                       'title':  t['title']}),
            li, False
        )

    if next_cursor:
        _add_dir(handle, build_url, '» Next Page',
                 {'action': 'xxxclub_browse', 'cursor': next_cursor},
                 plot='Load next page')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def play_xxxclub_magnet(handle, magnet, title=''):
    """Resolve a XXXClub magnet via debrid and play it."""
    from resources.lib import debrid_torrent as _dt

    dlg = xbmcgui.DialogProgress()
    dlg.create('XXXClub', 'Resolving via debrid...')

    try:
        import urllib.parse as _ul, re as _re
        qs = _ul.parse_qs(_ul.urlparse(magnet).query)
        info_hash = _re.search(r'btih:([a-fA-F0-9]{40})', magnet)
        info_hash = info_hash.group(1).lower() if info_hash else ''

        stream_url = None
        for fn in (_dt.rd_magnet_to_stream, _dt.ad_magnet_to_stream,
                   _dt.pm_magnet_to_stream, _dt.tb_magnet_to_stream):
            try:
                result = fn(magnet, info_hash)
                if result:
                    stream_url = result
                    break
            except Exception:
                continue
    finally:
        dlg.close()

    if not stream_url:
        # No debrid — route via Elementum by resolving directly to the plugin URL
        import urllib.parse as _ul2
        elem_url = 'plugin://plugin.video.elementum/play?uri=' + _ul2.quote(magnet, safe='')
        xbmc.log('[Starfleet] XXXClub no debrid, routing via Elementum: %s' % elem_url[:80], xbmc.LOGINFO)
        li = xbmcgui.ListItem(path=elem_url, label=title or 'XXXClub')
        xbmcplugin.setResolvedUrl(handle, True, li)
        return

    li = xbmcgui.ListItem(path=stream_url, label=title)
    xbmcplugin.setResolvedUrl(handle, True, li)
