# -*- coding: utf-8 -*-
"""DLHD / DaddyLive channel resolver for the site's current "six player" layout.

watch.php?id=<N> lists up to six player buttons (/stream/, /cast/, /watch/, /plus/,
/casting/, /player/ + stream-<N>.php). Each one is a different wrapper around the same
channel, so each needs its own small decoder:

  stream / watch   iframe -> page with  const SRC = "<m3u8>"
  cast             iframe -> page with  window._econfig='<4-chunk shuffled base64 json>'
  plus             iframe -> page with  var a=[bytes], k1, k2   (xor/sub obfuscated JS blob)
  casting          iframe -> iframe -> const streamUrls = ["<m3u8>", ...]
  player           open-ended hop chain (data-encoded base64, eval(atob()), f.src=..., iframes)

resolve_channel() returns the first playable result as
    {'url': 'https://...m3u8|Referer=..&Origin=..&User-Agent=..', 'player': 'cast', 'embed': url}
or None.  Network only, no JS execution.
"""
import base64
import html as _html
import json
import math
import re
import threading
from urllib.parse import urljoin, urlparse, parse_qsl, quote_plus

import requests
import xbmc

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
DEFAULT_BASE = 'https://dlive.sx'
_TIMEOUT = (4, 9)
# dlive.sx throttles bursts (a handful of parallel resolves is enough to make it drop
# connections), so cap how many channel resolves hit it at once.
_GATE = threading.BoundedSemaphore(3)


def _log(msg):
    xbmc.log('[Starfleet/DLHD] %s' % msg, xbmc.LOGINFO)


def _origin(url):
    u = urlparse(url)
    return '%s://%s' % (u.scheme or 'https', u.netloc)


def _fetch(url, referer=None):
    headers = {'User-Agent': UA}
    if referer:
        headers['Referer'] = referer
    for attempt in (0, 1):
        try:
            return requests.get(url, headers=headers, timeout=_TIMEOUT).text
        except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError):
            # dlive.sx drops the odd connect under load; one quick retry is enough
            if attempt:
                raise


def _iframe_src(page, page_url):
    m = re.search(r'<iframe[^>]+src="([^"]+)"', page, re.I)
    if not m:
        return None
    return urljoin(page_url, _html.unescape(m.group(1)).strip())


# ── decoders ─────────────────────────────────────────────────────────────────

def decode_econfig(encoded):
    """base64 -> text split into 4 chunks -> each chunk loses its 4th char and is
    base64-decoded -> chunks re-ordered [2,0,3,1] and joined -> base64 json."""
    s = base64.b64decode(encoded).decode('utf-8')
    size = math.ceil(len(s) / 4)
    chunks = [s[i * size:(i + 1) * size] for i in range(4)]
    order = [2, 0, 3, 1]
    out = [''] * 4
    for i in range(4):
        c = chunks[i]
        c = c[:3] + c[4:]
        out[order[i]] = base64.b64decode(c).decode('utf-8')
    return json.loads(base64.b64decode(''.join(out)).decode('utf-8'))


def decode_payload(page):
    """`var d=[n,n,...], k1=<int>, k2=<int>` -> chr(((n ^ k1) - k2) mod 256) text that
    holds the signed playlist URL."""
    m = re.search(r'var\s+\w+\s*=\s*\[([\d,\s]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)', page)
    if not m:
        return None
    k1, k2 = int(m.group(2)), int(m.group(3))
    text = ''.join(chr(((int(n) ^ k1) - k2 + 256) % 256) for n in m.group(1).split(',') if n.strip())
    m = re.search(r'SIGNED_URL\s*=\s*"([^"]+)"', text) or re.search(r'\burl\s*=\s*"([^"]+)"', text)
    return m.group(1).replace('\\/', '/') if m else None


def _b64_url(encoded):
    try:
        text = base64.b64decode(encoded + '=' * (-len(encoded) % 4)).decode('utf-8', 'ignore')
    except Exception:
        return None
    m = re.search(r"atob\('([^']+)'\)", text)
    if m:
        return _b64_url(m.group(1))
    m = re.search(r'(?:https?:)?//[^\s"\'<>]+', text)
    return m.group(0) if m else None


def _next_hop(page, page_url):
    m = re.search(r'data-encoded="([^"]+)"', page)
    if m and _b64_url(m.group(1)):
        return urljoin(page_url, _b64_url(m.group(1)))
    m = re.search(r'"([A-Za-z0-9+/=]{40,})"\s*;\s*eval\(atob', page)
    if m and _b64_url(m.group(1)):
        return urljoin(page_url, _b64_url(m.group(1)))
    m = re.search(r"iframe\.src\s*=\s*'([^']+)'\s*\+\s*encodeURIComponent", page)
    if m:
        chan = re.sub(r'[/\\.?&=]', '', dict(parse_qsl(urlparse(page_url).query)).get('id', '').strip())
        if chan:
            return urljoin(page_url, m.group(1) + quote_plus(chan))
    m = (re.search(r'f\.src\s*=\s*"([^"]+)"', page) or
         re.search(r'<ifr(?:\'\+\')?ame[^>]+src="((?:https?:)?//[^"]+)"', page, re.I))
    if m:
        return urljoin(page_url, _html.unescape(m.group(1)).strip())
    return None


# ── per-player resolvers: (player_url, referer) -> (stream_url, embed_url) | None ──

def _r_src(player_url, referer):          # stream, watch
    embed = _iframe_src(_fetch(player_url, referer), player_url)
    if not embed:
        return None
    m = re.search(r'const\s+SRC\s*=\s*"([^"]+)"', _fetch(embed, player_url))
    return (m.group(1).replace('\\/', '/'), embed) if m else None


def _r_cast(player_url, referer):
    embed = _iframe_src(_fetch(player_url, referer), player_url)
    if not embed:
        return None
    m = re.search(r"window\._econfig\s*=\s*'([^']+)'", _fetch(embed, player_url))
    if not m:
        return None
    cfg = decode_econfig(m.group(1))
    url = cfg.get('stream_url_nop2p') or cfg.get('stream_url')
    return (url, embed) if url else None


def _r_plus(player_url, referer):
    embed = _iframe_src(_fetch(player_url, referer), player_url)
    if not embed:
        return None
    url = decode_payload(_fetch(embed, player_url))
    return (url, embed) if url else None


def _r_casting(player_url, referer):
    outer = _iframe_src(_fetch(player_url, referer), player_url)
    if not outer:
        return None
    embed = _iframe_src(_fetch(outer, player_url), outer)
    if not embed:
        return None
    m = re.search(r'const\s+streamUrls\s*=\s*(\[[^\]]*\])', _fetch(embed, outer))
    if not m:
        return None
    urls = json.loads(m.group(1))
    return (urls[0], embed) if urls else None


def _r_chain(player_url, referer):        # player
    url = player_url
    for _ in range(10):
        page = _fetch(url, referer)
        stream = decode_payload(page)
        if stream:
            return stream, url
        nxt = _next_hop(page, url)
        if not nxt:
            return None
        referer = None if 'referrerpolicy="no-referrer"' in page else _origin(url) + '/'
        url = nxt
    return None


PLAYERS = {'stream': _r_src, 'watch': _r_src, 'cast': _r_cast, 'plus': _r_plus,
           'casting': _r_casting, 'player': _r_chain}
# Probe-able players first (their playlist URLs can be fetched any number of times), then
# cast, whose playlist URL is single-use (?s=..&e=..): a probe would burn it before Kodi
# opens it, so it is handed back unverified and only used when nothing else is live.
_ORDER = ('stream', 'plus', 'casting', 'player', 'watch', 'cast')
_SINGLE_USE = ('cast',)


def _headers_suffix(embed_url):
    org = _origin(embed_url)
    return '|Referer=%s/&Origin=%s&User-Agent=%s' % (org, org, quote_plus(UA))


def _playable(stream_url, embed_url):
    """Cheap check that the playlist answers 200 with #EXTM3U (these URLs are signed and
    some players hand out dead ones)."""
    try:
        org = _origin(embed_url)
        r = requests.get(stream_url, headers={'User-Agent': UA, 'Referer': org + '/', 'Origin': org},
                         timeout=(4, 8))
        return r.status_code == 200 and '#EXTM3U' in r.text[:400]
    except Exception:
        return False


def resolve_channel(channel_id, base=DEFAULT_BASE, verify=True, prefer=None):
    """Try the channel's players in turn; first one that yields a live playlist wins."""
    with _GATE:
        return _resolve_channel(channel_id, base, verify, prefer)


def _resolve_channel(channel_id, base, verify, prefer):
    base = base.rstrip('/')
    host = urlparse(base).netloc
    watch_url = '%s/watch.php?id=%s' % (base, channel_id)
    try:
        page = _fetch(watch_url, base + '/')
    except requests.exceptions.ConnectionError:
        raise          # host down: let the caller mark it so nothing else waits on it
    except Exception as e:
        _log('watch page %s: %s' % (channel_id, e))
        return None
    found = {}
    for href, _title in re.findall(r'data-url="([^"]+)"\s+title="([^"]+)"', page):
        folder = urlparse(href).path.strip('/').split('/')[0]
        if folder in PLAYERS and folder not in found:
            found[folder] = urljoin(watch_url, _html.unescape(href).strip())
    if not found:
        found['cast'] = '%s/cast/stream-%s.php' % (base, channel_id)
    order = [f for f in ((prefer,) if prefer else ()) + _ORDER if f in found]
    for folder in dict.fromkeys(order):
        try:
            res = PLAYERS[folder](found[folder], watch_url)
        except requests.exceptions.ConnectionError as e:
            if host in str(e):
                raise      # the site itself is unreachable - no point trying the other players
            _log('%s player %s: %s' % (channel_id, folder, str(e)[:100]))
            continue
        except Exception as e:
            _log('%s player %s: %s' % (channel_id, folder, e))
            continue
        if not res:
            continue
        stream_url, embed = res
        if stream_url.startswith('//'):
            stream_url = 'https:' + stream_url
        if verify and folder not in _SINGLE_USE and not _playable(stream_url, embed):
            _log('%s player %s: playlist not live' % (channel_id, folder))
            continue
        return {'url': stream_url + _headers_suffix(embed), 'player': folder, 'embed': embed}
    return None


def channel_id_from_url(url):
    """Pull the channel number out of any dlive/DLHD URL form we handle."""
    if not url:
        return None
    m = re.search(r'stream-(\d+)\.php', url) or re.search(r'[?&]id=(\d+)', url) \
        or re.search(r'channel[=/](\d+)', url)
    return m.group(1) if m else None
