# -*- coding: utf-8 -*-
"""
resources/lib/debug_log.py

"Send Debug Log" — Settings > General button. Built 2026-08-16 after ADB
access to a Firestick's own kodi.log turned out to be blocked (confirmed
live: both a direct `adb pull` and `adb shell run-as` failed with
Permission denied / package not debuggable — Android's scoped storage on
that device won't let an external ADB shell read another app's private
files, and the device isn't rooted). The same restriction is already
documented in dispatcher.py's own clear_cache action for the exact same
reason (can't clear another app's cache file over ADB either).

The one place that ISN'T restricted is the running Kodi process itself —
it already has full read access to its own log via special://logpath/,
since that's a normal in-app file read, not cross-app ADB access. So
instead of trying to get a file OFF the device, this reads the log from
inside the app and uploads it, leaving the user with just a short URL to
read off their screen and paste wherever they're asking for help.

Redaction: kodi.log can contain this addon's own outbound request logging,
which in turn can carry real debrid/premium-service credentials (Real-
Debrid/AllDebrid/Premiumize/TorBox API keys, MDBList/Trakt/SIMKL tokens,
Easynews login) in query strings or Authorization headers. Uploading that
verbatim to a public, unauthenticated paste service would hand out live
credentials to anyone who finds the link — so every known credential
pattern is stripped before anything leaves the device, not after.

Paste service: paste.rs (plain HTTP POST of the raw body, plain-text URL
back — no account, no API key of its own, widely documented/stable
contract). NOT live-tested from the dev sandbox this was built in — that
environment couldn't reach paste.rs at all (DNS failure) and separately
would have needed explicit approval to POST to a third-party paste service
even for a test string, so the very first real call is whatever the user
runs on their own device.
"""

import re
import xbmc
import xbmcvfs
import requests as _req

_HEADERS = {'User-Agent': 'Mozilla/5.0'}

# Matches the VALUE half of key=value pairs for every credential-shaped
# field name this addon's own settings.xml stores (Real-Debrid/AllDebrid/
# Premiumize/TorBox/MDBList/Trakt/SIMKL/Easynews) plus generic
# token/secret/password/signature names any future source might log.
_RE_REDACT_KV = re.compile(
    r'((?:api[_-]?key|apikey|token|access_token|refresh_token|auth_token|'
    r'client_secret|client_id|secret|password|passwd|pass|sig|signature|'
    r'session|sessionid|cookie)=)[^&\s"\'<>]+',
    re.IGNORECASE)
_RE_REDACT_HEADER = re.compile(r'(Authorization:\s*).*', re.IGNORECASE)
_RE_REDACT_BEARER = re.compile(r'\bBearer\s+[A-Za-z0-9._\-]+', re.IGNORECASE)

# Keep the upload focused and bounded — a debug-logging session can grow
# to many MB, and the interesting part for a fresh bug report is always
# whatever just happened, not the whole session history.
_MAX_BYTES = 800 * 1024


def _redact(text):
    text = _RE_REDACT_KV.sub(r'\1REDACTED', text)
    text = _RE_REDACT_HEADER.sub(r'\1REDACTED', text)
    text = _RE_REDACT_BEARER.sub('Bearer REDACTED', text)
    return text


def _read_recent_log():
    path = xbmcvfs.translatePath('special://logpath/kodi.log')
    try:
        f = xbmcvfs.File(path)
        size = f.size()
        if size > _MAX_BYTES:
            f.seek(size - _MAX_BYTES, 0)
        data = f.readBytes() if size > _MAX_BYTES else f.readBytes()
        f.close()
        text = bytes(data).decode('utf-8', 'ignore')
        if size > _MAX_BYTES:
            # Drop a possibly-truncated first line from the seek point.
            text = text.split('\n', 1)[-1]
        return text
    except Exception as e:
        xbmc.log('[Starfleet/DebugLog] read failed: %s' % e, xbmc.LOGERROR)
        return None


def upload_debug_log():
    """Read this device's own kodi.log, redact known credential patterns,
    upload to paste.rs, return the resulting URL (or None on failure)."""
    raw = _read_recent_log()
    if not raw:
        return None
    redacted = _redact(raw)
    try:
        r = _req.post('https://paste.rs/', data=redacted.encode('utf-8', 'ignore'),
                       headers=_HEADERS, timeout=20)
        r.raise_for_status()
        url = r.text.strip()
        if not url.startswith('http'):
            xbmc.log('[Starfleet/DebugLog] unexpected paste.rs response: %s' % url[:200],
                      xbmc.LOGERROR)
            return None
        xbmc.log('[Starfleet/DebugLog] uploaded: %s' % url, xbmc.LOGINFO)
        return url
    except Exception as e:
        xbmc.log('[Starfleet/DebugLog] upload failed: %s' % e, xbmc.LOGERROR)
        return None
