"""
Starfleet Home GUI launcher.
Opens the home window immediately with cached data, then refreshes in the background.
"""
import sys
import os
import json
import threading
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon


def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)

    data_dir  = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(data_dir, exist_ok=True)
    data_file    = os.path.join(data_dir, 'home_data.json')
    version_file = os.path.join(data_dir, 'last_version.txt')
    current_ver  = addon.getAddonInfo('version')

    empty    = [[], [], []]
    contexts = {'default': empty, 'movies': empty, 'tv': empty,
                'sports': empty, 'live': empty, 'adult': empty}

    # Check whether this is a first run / update
    try:
        with open(version_file, 'r') as _f:
            saved_ver = _f.read().strip()
    except Exception:
        saved_ver = ''
    is_new_version = (saved_ver != current_ver)

    # Only one instance should run the heavy refresh at a time.
    # Kodi widget loading can invoke run_home.py 2-3 times simultaneously on startup;
    # on low-RAM devices (FireStick) multiple parallel TMDB+ADE fetches cause freezes.
    lock_file = os.path.join(data_dir, 'refresh.lock')
    refresh_done   = threading.Event()
    refresh_result = [None]

    def _acquire_lock():
        """Return True if this instance gets the refresh lock."""
        try:
            import time as _time
            # Stale lock older than 90s is safe to take over
            if os.path.exists(lock_file):
                age = _time.time() - os.path.getmtime(lock_file)
                if age < 90:
                    return False
            with open(lock_file, 'w') as _lf:
                _lf.write(str(os.getpid()))
            return True
        except Exception:
            return True  # if lock fails, proceed anyway

    def _release_lock():
        try:
            os.remove(lock_file)
        except Exception:
            pass

    got_lock = _acquire_lock()

    def _refresh():
        try:
            from resources.lib import afdb_router as _ar
            _ctx = _ar.get_home_carousel_data()
            refresh_result[0] = _ctx
            _tmp = data_file + '.tmp'
            with open(_tmp, 'w', encoding='utf-8') as _f:
                json.dump(_ctx, _f)
            os.replace(_tmp, data_file)
            _d = _ctx.get('default', empty)
            xbmc.log('[Starfleet/Home] background refresh done: %d/%d/%d' % (
                len(_d[0]), len(_d[1]), len(_d[2])), xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log('[Starfleet/Home] background refresh error: %s' % _e, xbmc.LOGWARNING)
        finally:
            _release_lock()
            refresh_done.set()

    if got_lock:
        t = threading.Thread(target=_refresh, daemon=True)
        t.start()
    else:
        # Another instance is refreshing — just signal done so splash/window don't wait
        xbmc.log('[Starfleet/Home] refresh lock held by another instance, skipping', xbmc.LOGINFO)
        refresh_done.set()

    if is_new_version:
        # Install required dependencies in the background while showing splash
        def _install_deps():
            try:
                import xbmcaddon as _xba
                for addon_id in ('repository.elementumorg', 'plugin.video.elementum',
                                 'inputstream.adaptive'):
                    try:
                        _xba.Addon(addon_id)
                    except Exception:
                        xbmc.log('[Starfleet/Home] installing missing dependency: %s' % addon_id, xbmc.LOGINFO)
                        xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
                        xbmc.sleep(2000)
            except Exception as _ie:
                xbmc.log('[Starfleet/Home] dependency install error: %s' % _ie, xbmc.LOGWARNING)

        threading.Thread(target=_install_deps, daemon=True).start()

        # Show splash while widgets load — closes early if data arrives
        messages = [
            'Initialising Starfleet…',
            'Calibrating warp drive…',
            'Engaging deflector array…',
            'Installing Elementum Org repository…',
            'Installing Elementum torrent player…',
            'Installing InputStream Adaptive…',
            'Syncing star charts…',
            'Loading your content…',
            'Almost ready…',
        ]
        dlg      = xbmcgui.DialogProgress()
        dlg.create('Starfleet', messages[0])
        total_ms = 30000
        step_ms  = 300
        steps    = total_ms // step_ms
        for i in range(steps):
            if dlg.iscanceled() or refresh_done.is_set():
                break
            pct = int((i / steps) * 100)
            dlg.update(pct, messages[(i // 4) % len(messages)])
            xbmc.sleep(step_ms)
        dlg.update(100, 'Ready!')
        xbmc.sleep(300)
        dlg.close()
        try:
            with open(version_file, 'w') as _f:
                _f.write(current_ver)
        except Exception:
            pass
    else:
        # Normal launch — load from cache instantly so the window is non-empty
        try:
            with open(data_file, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            if isinstance(raw, list):
                contexts['default'] = raw
                contexts['movies']  = raw
                contexts['tv']      = raw
            else:
                for k, v in raw.items():
                    contexts[k] = v
            d = contexts.get('default', empty)
            xbmc.log('[Starfleet/Home] loaded %d/%d/%d films from cache' % (
                len(d[0]), len(d[1]), len(d[2])), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Home] no cache yet (%s), showing empty home' % e, xbmc.LOGINFO)

    # If refresh finished during the splash, use the fresh data right away
    if refresh_result[0] is not None:
        contexts = refresh_result[0]

    try:
        from resources.lib.gui.home import HomeWindow
        win = HomeWindow('Starfleet-Home.xml', addon_path, 'Default', '1080i',
                         contexts=contexts)

        # If refresh is still running, push data into window when it finishes
        def _push_when_ready():
            refresh_done.wait(timeout=120)
            if refresh_result[0] is not None:
                try:
                    win._contexts = refresh_result[0]
                    xbmc.log('[Starfleet/Home] TMDB rows: pushed to live window', xbmc.LOGINFO)
                except Exception:
                    pass
            try:
                win.setProperty('sf_loaded', '1')
            except Exception:
                pass

        if not refresh_done.is_set():
            threading.Thread(target=_push_when_ready, daemon=True).start()
        else:
            try:
                win.setProperty('sf_loaded', '1')
            except Exception:
                pass

        win.doModal()
        nav_action = win.pending_nav
        del win
        if nav_action:
            for _ in range(40):
                xbmc.sleep(50)
                if not xbmc.getCondVisibility('System.HasModalDialog'):
                    break
            xbmc.sleep(200)
            xbmc.executebuiltin('ActivateWindow(Home)')
            xbmc.sleep(250)
            xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.starfleet/?action=%s)' % nav_action)
    except Exception as e:
        xbmc.log('[Starfleet/Home] window error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
