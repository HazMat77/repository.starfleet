"""
Starfleet Home GUI launcher. Pre-fetches data BEFORE opening the window
so onInit can populate controls synchronously on the GUI thread.
"""
import sys
import os
import xbmc
import xbmcaddon
import xbmcgui

def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)

    # Show busy dialog while we fetch data
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    rows = [[], [], []]
    try:
        from resources.lib import afdb_router as _ar
        rows = _ar.get_home_carousel_data()
        xbmc.log('[Starfleet/Home] pre-fetched %d/%d/%d films' % (
            len(rows[0]), len(rows[1]), len(rows[2])), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/Home] pre-fetch error: %s' % e, xbmc.LOGERROR)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    try:
        from resources.lib.gui.home import HomeWindow
        win = HomeWindow('Starfleet-Home.xml', addon_path, 'Default', '1080i',
                         film_rows=rows)
        win.doModal()
        del win
    except Exception as e:
        xbmc.log('[Starfleet/Home] window error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

if __name__ == '__main__':
    main()
