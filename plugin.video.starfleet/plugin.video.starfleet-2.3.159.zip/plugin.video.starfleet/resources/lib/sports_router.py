﻿# -*- coding: utf-8 -*-
"""
resources/lib/sports_router.py

Kodi UI for the Sports section.

Menu:
  Sports → [NFL, NBA, MLB, NHL, UFC, Boxing, Soccer, F1, CFB, NCAAB, CFL, WWE]
         → Today's Games  (event list for the selected sport)
         → click game → dialog: Link 1, Link 2, ... → play
"""

import time as _time
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmcplugin


def _fmt_local_time(start_ts):
    """Convert UTC unix timestamp → human-readable local device time string."""
    if not start_ts:
        return ''
    try:
        local = _time.localtime(int(start_ts))
        now   = _time.localtime()
        # 12-hour clock, no leading zero
        t_str = _time.strftime('%I:%M %p', local).lstrip('0') or _time.strftime('%I:%M %p', local)
        # Day label
        if local.tm_year == now.tm_year and local.tm_yday == now.tm_yday:
            day = 'Today'
        elif local.tm_year == now.tm_year and local.tm_yday == now.tm_yday + 1:
            day = 'Tomorrow'
        else:
            # Cross-platform: avoid %-d (Linux) / %#d (Windows) — just use tm_mday
            day = '%s %s %d' % (_time.strftime('%a', local), _time.strftime('%b', local), local.tm_mday)
        return '%s %s' % (day, t_str)
    except Exception:
        return ''

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')


def _progress(msg):
    d = xbmcgui.DialogProgress()
    d.create('Starfleet Sports', msg)
    d.update(5)
    return d


# ── Sport categories ──────────────────────────────────────────────────────────

def sports_menu(handle, build_url):
    """Top-level sports menu: show each sport category as a folder."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '🏟️  Sports')
    xbmcplugin.setContent(handle, 'files')

    # Hockey hub — all leagues from onhockey.tv
    hockey_li = xbmcgui.ListItem(label='🏒  Hockey')
    hockey_li.setArt({'thumb': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png',
                      'icon':  'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'})
    hockey_li.setInfo('video', {'title': '🏒  Hockey'})
    xbmcplugin.addDirectoryItem(handle, build_url({'action': 'hockey_menu'}), hockey_li, True)

    cats = _ss.get_sport_categories()

    for cat in cats:
        li = xbmcgui.ListItem(label=cat['label'])
        li.setArt({'thumb': cat['icon'], 'icon': cat['icon']})
        li.setInfo('video', {'title': cat['label']})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':      'sports_events',
                       'sport_slug':  cat['slug'],
                       'sport_label': cat['label'],
                       'sport_icon':  cat['icon'],
                       'tsdb_sport':  cat.get('tsdb_sport', '')}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Events list for a sport ───────────────────────────────────────────────────

def sports_events(handle, build_url, sport_slug, sport_label='', sport_icon='', tsdb_sport=''):
    """List today's and upcoming events for a sport category."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '🏟️  %s' % (sport_label or sport_slug.upper()))
    xbmcplugin.setContent(handle, 'files')

    cold = _cache.get('sport_ev4_%s' % sport_slug) is None
    dlg  = _progress('Loading %s events...' % (sport_label or sport_slug.upper())) if cold else None
    events = _ss.get_sport_events(sport_slug, tsdb_sport=tsdb_sport)
    if dlg:
        dlg.close()

    if not events:
        xbmcgui.Dialog().notification(
            'Starfleet Sports',
            'No events found for %s' % sport_slug.upper(),
            xbmcgui.NOTIFICATION_INFO
        )
        return

    xbmc.log('[Starfleet/Sports] rendering %d %s events, first start_ts=%s' % (
        len(events), sport_slug, events[0].get('start_ts', 'MISSING') if events else 'N/A'), xbmc.LOGINFO)
    for ev in events:
        local_time = _fmt_local_time(ev.get('start_ts', 0))
        if ev.get('is_live'):
            time_tag = '[COLOR red]🔴 LIVE[/COLOR]'
        elif local_time:
            time_tag = '[COLOR yellow]%s[/COLOR]' % local_time
        else:
            time_tag = ''

        label = '%s  %s' % (time_tag, ev['title']) if time_tag else ev['title']

        league = ev.get('league', '')
        plot_parts = []
        if league and league.upper() != sport_slug.upper():
            plot_parts.append(league)
        if local_time and not ev.get('is_live'):
            plot_parts.append(local_time)
        if ev.get('is_live'):
            score_str = ev.get('plot', '')
            if score_str:
                plot_parts.append('🔴 ' + score_str)
            else:
                plot_parts.append('🔴 LIVE NOW')
        if ev.get('venue'):
            plot_parts.append('📍 ' + ev['venue'])
        plot = ' • '.join(plot_parts)

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': ev['title'],
            'plot':  plot,
        })

        # Home team badge → thumb/icon; away badge → fanart (shown as background)
        home_badge = ev.get('home_badge', '') or ev.get('logo', '') or sport_icon
        away_badge = ev.get('away_badge', '') or home_badge
        li.setArt({'thumb': home_badge, 'icon': home_badge, 'fanart': away_badge})

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':      'sports_event_play',
                       'event_id':    ev['id'],
                       'event_path':  ev['path'],
                       'sport_slug':  sport_slug,
                       'title':       ev['title']}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Play an event — show stream picker dialog ─────────────────────────────────

def sports_event_play(handle, event_id='', event_path='', sport_slug='', title=''):
    """
    Fetch available stream links for the event and show a dialog picker.
    Merges ISE streams (event_path) + Roxiestreams (sport_slug).
    """
    from resources.lib import sports_sources as _ss

    dlg = _progress('Fetching stream links...')
    streams = _ss.get_event_streams(event_path, event_id, sport_slug, title)
    dlg.close()

    if not streams:
        xbmcgui.Dialog().ok(
            'Starfleet Sports — %s' % title,
            'No stream links available yet.\n\n'
            'This event may not have started, or stream links will appear '
            'a few minutes before/after kick-off.\n\n'
            'Try again when the event is live.'
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # Build dialog options — show source + quality
    def _fmt_option(i, s):
        src  = s.get('source', '')
        lbl  = s.get('label', 'Stream')
        qual = s.get('quality', '')
        parts = ['[%s]' % src] if src else []
        parts.append(lbl)
        if qual and qual not in lbl:
            parts.append('(%s)' % qual)
        return '%d. %s' % (i + 1, ' '.join(parts))

    options = [_fmt_option(i, s) for i, s in enumerate(streams)]

    if len(streams) == 1:
        chosen_url = streams[0]['url']
    else:
        idx = xbmcgui.Dialog().select(
            '%s — Choose stream' % title, options
        )
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen_url = streams[idx]['url']

    _play_stream(handle, chosen_url, title)


def _play_stream(handle, url, title=''):
    """Resolve the URL via resolveurl/resolvers then set as resolved URL."""
    resolved = url

    # Try ResolveURL if available
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                resolved = r
    except ImportError:
        pass
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    li = xbmcgui.ListItem(label=title, path=resolved)
    li.setInfo('video', {'title': title})
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle, True, li)


# ── Hockey hub (onhockey.tv — all leagues) ────────────────────────────────────

_HOCKEY_ICON = 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'

# All leagues onhockey.tv covers — always shown even with 0 current games
_HOCKEY_ALL_LEAGUES = [
    'NHL', 'AHL', 'KHL', 'OHL', 'WHL', 'QMJHL', 'ECHL',
    'SHL', 'DEL', 'Liiga', 'Czech', 'Slovak', 'EIHL',
    'NCAA', 'IIHF', 'PWHL', 'NWHL', 'PHF',
    'AIHL', 'NZIHL',
]


def hockey_menu(handle, build_url):
    """List all leagues from onhockey.tv as browsable folders."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '🏒  Hockey')
    xbmcplugin.setContent(handle, 'files')

    dlg    = _progress('Loading hockey schedule...')
    events = _ss.get_onhockey_events()
    dlg.close()

    # Count games per league from schedule
    league_counts = {}
    for ev in events:
        lg = ev.get('league', 'NHL')
        league_counts[lg] = league_counts.get(lg, 0) + 1

    # Build final league list: known ones first (in order), then any from schedule not in list
    shown = set()
    leagues = []
    for lg in _HOCKEY_ALL_LEAGUES:
        leagues.append((lg, league_counts.get(lg, 0)))
        shown.add(lg)
    for lg in sorted(league_counts):
        if lg not in shown:
            leagues.append((lg, league_counts[lg]))

    for lg, count in leagues:
        if count > 0:
            label = '%s  (%d upcoming)' % (lg, count)
        else:
            label = '%s  — off season' % lg
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': _HOCKEY_ICON, 'icon': _HOCKEY_ICON})
        li.setInfo('video', {'title': lg, 'plot': '%d games in current schedule' % count})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'hockey_league_events', 'league': lg}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def hockey_league_events(handle, build_url, league='NHL'):
    """List upcoming games for a specific hockey league from onhockey.tv."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '🏒  %s' % league)
    xbmcplugin.setContent(handle, 'files')

    dlg    = _progress('Loading %s schedule...' % league)
    events = _ss.get_onhockey_events()
    dlg.close()

    league_events = [e for e in events if e.get('league', 'NHL') == league]

    if not league_events:
        xbmcgui.Dialog().notification(
            'Starfleet', 'No %s games scheduled right now' % league, xbmcgui.NOTIFICATION_INFO
        )
        return

    for ev in league_events:
        start_ts   = ev.get('start_ts', 0)
        date_label = ev.get('date_label', '')
        local_time = _fmt_local_time(start_ts) if start_ts else ''

        if ev.get('is_live'):
            time_tag = '[COLOR red]🔴 LIVE[/COLOR]'
        elif local_time:
            time_tag = '[COLOR yellow]%s[/COLOR]' % local_time
        elif date_label:
            time_tag = '[COLOR grey]%s[/COLOR]' % date_label
        else:
            time_tag = ''

        label = '%s  %s' % (time_tag, ev['title']) if time_tag else ev['title']
        plot  = local_time or date_label or ('🔴 LIVE NOW' if ev.get('is_live') else '')

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': ev['title'], 'plot': plot})
        li.setArt({'thumb': _HOCKEY_ICON, 'icon': _HOCKEY_ICON})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'sports_event_play',
                       'event_id':   ev['id'],
                       'event_path': ev['path'],
                       'sport_slug': 'hockey',
                       'title':      ev['title']}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
