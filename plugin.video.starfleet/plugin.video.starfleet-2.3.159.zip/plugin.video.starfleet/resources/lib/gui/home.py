"""
Starfleet Home Window.
Data is pre-loaded before doModal() so onInit populates on the GUI thread safely.
Rows swap based on which nav button is focused: Movies → New/Popular/Top Rated,
TV Shows → Popular TV Shows (3 rows), default → New Releases/TV Shows/Trending.
"""
import xbmc
import xbmcgui
import xbmcaddon

try:
    _ADDON = xbmcaddon.Addon('plugin.video.starfleet')
except Exception:
    _ADDON = None

_ID_PLAY    = 20
_ID_INFO    = 21
_ID_NAV_MOV = 41
_ID_NAV_TV  = 42
_ID_NAV_SPT = 43
_ID_NAV_LIV = 44
_ID_NAV_ADU = 45
_ID_ROW0    = 100
_ID_ROW1    = 200
_ID_ROW2    = 300
_ID_ROW3    = 400

_NAV_IDS = (_ID_NAV_MOV, _ID_NAV_TV, _ID_NAV_SPT, _ID_NAV_LIV, _ID_NAV_ADU)

# Row labels per context (4 rows)
_CONTEXT_LABELS = {
    'default': ['New Releases', 'TV Shows',           'Trending',     'Popular Movies'],
    'movies':  ['New Releases', 'Popular Movies',     'Top Rated',    'Upcoming'],
    'tv':      ['Popular TV',   'Top Rated TV',       'Airing Today', 'On The Air'],
    'sports':  ['Soccer Today', 'NBA & NHL Today',    'MLB & NFL Today', ''],
    'live':    ['Favorite Movies', 'Favorite TV Shows', '', ''],
    'adult':   ['New Releases', 'Recently Added',     'Adult Favorites', ''],
}


class HomeWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        # Accept either old film_rows= or new contexts=
        self._contexts   = kwargs.pop('contexts', None)
        film_rows        = kwargs.pop('film_rows', None)
        if self._contexts is None:
            rows = film_rows or [[], [], [], []]
            self._contexts = {'default': rows, 'movies': rows, 'tv': rows}
        self._current_ctx = 'default'
        self._film_rows   = self._contexts.get('default', [[], [], [], []])
        self._hero_row    = 0
        self._hero_pos    = 0
        self.pending_nav  = None   # set by _nav(); read by run_home.py after doModal()
        super(HomeWindow, self).__init__(*args, **kwargs)

    # ---------------------------------------------------------------- lifecycle

    def onInit(self):
        try:
            try:
                _adult_on = xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
            except Exception:
                _adult_on = False
            self.setProperty('sf_adult_enabled', 'true' if _adult_on else 'false')
            self._apply_context('default')
            if self._film_rows and self._film_rows[0]:
                self._set_hero(self._film_rows[0][0])
            else:
                self.setProperty('sf_hero_title', 'Welcome to Starfleet')
        except Exception as e:
            xbmc.log('[Starfleet/Home] onInit: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                   xbmcgui.ACTION_STOP, xbmcgui.ACTION_PARENT_DIR):
            self.close()
        elif aid in (xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT,
                     xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN):
            self._update_hero_from_focus()

    def onFocus(self, cid):
        try:
            if cid == _ID_NAV_MOV:
                self._switch_context('movies')
            elif cid == _ID_NAV_TV:
                self._switch_context('tv')
            elif cid == _ID_NAV_SPT:
                self._switch_context('sports')
            elif cid == _ID_NAV_LIV:
                self._switch_context('live')
            elif cid == _ID_NAV_ADU:
                self._switch_context('adult')
            self._update_hero_from_focus()
        except Exception as e:
            xbmc.log('[Starfleet/Home] onFocus %d: %s' % (cid, e), xbmc.LOGERROR)

    def onClick(self, cid):
        try:
            if cid == _ID_PLAY:
                self._play_hero()
            elif cid == _ID_INFO:
                self._show_info()
            elif cid == _ID_NAV_MOV:
                self._nav('meta_movies_menu')
            elif cid == _ID_NAV_TV:
                self._nav('meta_tv_menu')
            elif cid == _ID_NAV_SPT:
                self._nav('sports_menu')
            elif cid == _ID_NAV_LIV:
                self._nav('live_menu')
            elif cid == _ID_NAV_ADU:
                self._nav('adult_menu')
            elif cid == 46:
                try:
                    xbmcaddon.Addon('plugin.video.starfleet').openSettings()
                except Exception:
                    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=open_settings)')
                try:
                    _adult_on = xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
                    self.setProperty('sf_adult_enabled', 'true' if _adult_on else 'false')
                except Exception:
                    pass
            elif cid in (_ID_ROW0, _ID_ROW1, _ID_ROW2, _ID_ROW3):
                self._play_row_item(cid)
        except Exception as e:
            xbmc.log('[Starfleet/Home] onClick %d: %s' % (cid, e), xbmc.LOGERROR)

    # ---------------------------------------------------------------- context

    def _switch_context(self, ctx):
        if ctx == self._current_ctx:
            return
        self._current_ctx = ctx
        self._film_rows   = self._contexts.get(ctx, self._contexts.get('default', [[], [], [], []]))
        self._hero_row    = 0
        self._hero_pos    = 0
        self._apply_context(ctx)

    def _apply_context(self, ctx):
        labels = _CONTEXT_LABELS.get(ctx, _CONTEXT_LABELS['default'])
        for i, lbl in enumerate(labels):
            self.setProperty('sf_row%d_label' % i, lbl)
        self._film_rows = self._contexts.get(ctx, self._contexts.get('default', [[], [], [], []]))
        self._populate_carousels()
        if self._film_rows and self._film_rows[0]:
            self._set_hero(self._film_rows[0][0])

    # ---------------------------------------------------------------- populate

    def _populate_carousels(self):
        for row_idx, list_id in enumerate([_ID_ROW0, _ID_ROW1, _ID_ROW2, _ID_ROW3]):
            films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
            ctrl  = self.getControl(list_id)
            ctrl.reset()
            for film in films:
                li = xbmcgui.ListItem(label=film.get('title', ''))
                li.setArt({
                    'thumb':  film.get('thumb', ''),
                    'fanart': film.get('fanart', film.get('thumb', '')),
                })
                li.setProperty('film_id',    str(film.get('id', film.get('tmdb_id', ''))))
                li.setProperty('film_source', film.get('source', 'tmdb'))
                li.setProperty('film_media',  film.get('media_type', 'movie'))
                ctrl.addItem(li)

    def _set_hero(self, film):
        title  = film.get('title', '')
        year   = str(film.get('year', ''))
        rating = str(film.get('rating', ''))
        meta   = '  |  '.join(p for p in [year, '★ ' + rating if rating else ''] if p)
        media  = film.get('media_type', 'movie')
        badge  = 'TV SHOW' if media == 'tv' else 'MOVIE'
        self.setProperty('sf_hero_title',  title)
        self.setProperty('sf_hero_meta',   meta)
        self.setProperty('sf_hero_plot',   film.get('plot', film.get('overview', '')))
        self.setProperty('sf_hero_fanart', film.get('fanart', film.get('thumb', '')))
        self.setProperty('sf_hero_badge',  badge)

    def _update_hero_from_focus(self):
        try:
            rmap = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2, _ID_ROW3: 3}
            cid  = self.getFocusId()
            if cid in rmap:
                row   = rmap[cid]
                ctrl  = self.getControl(cid)
                pos   = ctrl.getSelectedPosition()
                films = self._film_rows[row] if row < len(self._film_rows) else []
                if films and 0 <= pos < len(films):
                    if row != self._hero_row or pos != self._hero_pos:
                        self._hero_row = row
                        self._hero_pos = pos
                        self._set_hero(films[pos])
        except Exception:
            pass

    # ---------------------------------------------------------------- actions

    def _play_hero(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        pos = self._hero_pos if self._hero_pos < len(films) else 0
        self._play_film(films[pos])

    def _play_row_item(self, cid):
        rmap = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2, _ID_ROW3: 3}
        row  = rmap[cid]
        try:
            ctrl  = self.getControl(cid)
            pos   = ctrl.getSelectedPosition()
            films = self._film_rows[row] if row < len(self._film_rows) else []
            if films and 0 <= pos < len(films):
                self._play_film(films[pos])
        except Exception as e:
            xbmc.log('[Starfleet/Home] _play_row_item: %s' % e, xbmc.LOGERROR)

    def _play_film(self, film):
        import urllib.parse as _up
        source  = film.get('source', 'tmdb')
        media   = film.get('media_type', 'movie')
        tmdb_id = str(film.get('tmdb_id', film.get('id', '')))
        title   = _up.quote(film.get('title', ''))
        year    = _up.quote(str(film.get('year', '')))

        # For TV shows: close the home window and navigate into the show page
        if source == 'tmdb' and media == 'tv':
            self._nav('meta_tv_show&tmdb_id=%s' % tmdb_id)
            return

        # All playback actions: use xbmc.Player().play() so the home window stays in doModal().
        # ActivateWindow(Videos,...) must NOT be used from within doModal — when setResolvedUrl(False)
        # is returned, Kodi navigates to the parent plugin URL which re-opens the home window.
        li = xbmcgui.ListItem(film.get('title', ''))
        li.setProperty('IsPlayable', 'true')

        if source == 'ade':
            # Call directly in a thread — never go through the plugin URL resolver
            # because setResolvedUrl(False) causes Kodi to navigate to plugin:// root
            # which re-opens the home window in a cascade.
            ade_id_raw   = str(film.get('ade_id', film.get('id', '')))
            ade_slug_raw = str(film.get('ade_slug', ''))
            film_title   = film.get('title', '')
            import threading
            def _ade_thread(aid=ade_id_raw, aslug=ade_slug_raw, t=film_title):
                try:
                    from resources.lib.afdb_router import adult_ade_play_direct
                    adult_ade_play_direct(aid, aslug, t)
                except Exception as exc:
                    xbmc.log('[Starfleet/Home] ade direct play error: %s' % exc, xbmc.LOGERROR)
            threading.Thread(target=_ade_thread, daemon=True).start()
            return

        if source == 'tmdb':
            url = 'plugin://plugin.video.starfleet/?action=meta_movie_play&tmdb_id=%s&title=%s&year=%s' % (tmdb_id, title, year)
        elif source == 'sports':
            event_id   = _up.quote(str(film.get('event_id', '')))
            event_path = _up.quote(str(film.get('event_path', '')))
            sport_slug = film.get('sport_slug', '')
            url = 'plugin://plugin.video.starfleet/?action=sports_event_play&event_id=%s&event_path=%s&sport_slug=%s&title=%s' % (event_id, event_path, sport_slug, title)
        elif source == 'pandamovies':
            slug = film.get('slug', '')
            film_url = _up.quote(film.get('url', ''))
            url = 'plugin://plugin.video.starfleet/?action=adult_panda_play&slug=%s&film_url=%s&title=%s' % (slug, film_url, title)
        elif source == 'hqporner':
            slug = film.get('slug', '')
            film_url = _up.quote(film.get('url', ''))
            url = 'plugin://plugin.video.starfleet/?action=adult_hqp_play&slug=%s&film_url=%s&title=%s' % (slug, film_url, title)
        else:
            film_id = str(film.get('id', ''))
            slug    = film.get('slug', '')
            url = 'plugin://plugin.video.starfleet/?action=afdb_play_search&film_id=%s&film_slug=%s&film_title=%s' % (film_id, slug, title)

        xbmc.Player().play(url, li)

    def _show_info(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        film = films[self._hero_pos] if self._hero_pos < len(films) else films[0]
        xbmcgui.Dialog().textviewer(
            film.get('title', 'Info'),
            film.get('plot', film.get('overview', 'No description available.'))
        )

    def _nav(self, action):
        self.pending_nav = action
        self.close()
