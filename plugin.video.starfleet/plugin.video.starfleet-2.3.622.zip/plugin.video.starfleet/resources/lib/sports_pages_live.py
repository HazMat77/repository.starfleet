# -*- coding: utf-8 -*-
"""Schedule-page providers for live sports, looked up per game.

Each provider publishes one HTML schedule page per league. Nothing is scraped when the sports lists are drawn;
when a game is opened `links_for(sport_slug, title)` fetches that league's page from every provider that has one
(in parallel, short timeouts), keeps the rows that are this game, and returns their page URLs. sports_starfleet_live
then resolves each page URL to a playable stream (`resolve_page`).

Providers (current domains come from data/live_sites.json when it lists them, else the defaults below)
    se   StreamEast        podium rows; a page has numbered server buttons that fill an iframe
    vg   StreamEast (vg)   <a class="ev ..."> rows
    ps   PlayoffsStream    block buttons
    p7   720pStream        match cards
    ih   iHDStreams        "Watch <teams> Live Stream" links
    fs   FSportsHD         media-body rows
    g2   GStream24         table rows with a WATCH link
    vk   VoloKit           table rows
    bf   BuffStreams       competition cards
"""
import base64
import html as _html
import re
import time
from concurrent.futures import ThreadPoolExecutor, wait as _wait
from urllib.parse import urljoin, urlparse

import requests
import xbmc

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
_TIMEOUT = 7


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/LivePages] %s' % msg, level)


def _get(url, referer=None, timeout=_TIMEOUT):
    h = {'User-Agent': UA}
    if referer:
        h['Referer'] = referer
    r = requests.get(url, headers=h, timeout=timeout)
    r.raise_for_status()
    return r.text


# ── row parsers: html -> [(title, href)] ─────────────────────────────────────

def _p_se(page, base):
    out = []
    for block in re.findall(r'(?s)<li[^>]*\bclass=["\'][^"\']*\bf1-podium--item\b[^"\']*["\'][^>]*>(.*?)</li>', page):
        m = re.search(r'(?s)<a\s+href=["\']([^"\']+)["\'].*?d-md-inline[^>]*>\s*([^<]+?)\s*</span>', block)
        if m:
            out.append((_html.unescape(m.group(2)).strip(), urljoin(base, _html.unescape(m.group(1)).strip())))
    return out


def _p_vg(page, base):
    out = []
    for cls, href, title, _blk in re.findall(r'<a class="ev (?:ev-match|ev-plain)([^"]*)" href="([^"]+)" title="([^"]+)"[^>]*>(.*?)</a>', page, re.S):
        if 'is-post' in cls:
            continue
        out.append((_html.unescape(title).strip(), urljoin(base, href)))
    return out


def _p_ps(page, base):
    return [(_html.unescape(t).strip(), urljoin(base, h)) for h, t in re.findall(
        r'(?s)<a class="btn btn-info btn-block"[^>]+href="([^"]+)"[^>]*>.*?<div class="text-center">[^<]*</div>'
        r'.*?<div[^>]+d-none d-md-inline[^>]*>([^<]+)</div>', page)]


def _p_p7(page, base):
    out = []
    for href, _tb, teams in re.findall(r'<a class="match-card" href="([^"]+)">\s*<div class="match-time">(.*?)</div>\s*<div class="match-teams">(.*?)</div>', page, re.S):
        names = [_html.unescape(t).strip() for t in re.findall(r'<strong>([^<]+)</strong>', teams) if t.strip()]
        if names:
            out.append((' vs '.join(names), urljoin(base, href)))
    return out


def _p_ih(page, base):
    return [(_html.unescape(t).strip(), urljoin(base, h)) for h, t in re.findall(r'<a href="([^"]+)"[^>]+title="Watch ([^"]+?) Live Stream', page)]


def _p_fs(page, base):
    out = []
    for href, teams, _blk in re.findall(r'<div class="media-body">\s*<a href=["\']([^"\']+)["\'][^>]*>.*?<h4[^>]*>\s*([^<]+?)\s*</h4>(.*?)</a>', page, re.S):
        if 'Click Here' in teams:
            continue
        out.append((_html.unescape(teams).strip(), urljoin(base, href)))
    return out


def _p_g2(page, base):
    out = []
    for _d, _lg, event, _t, status, href in re.findall(
            r'(?s)<tr>\s*<td>\s*([^<]*?)\s*</td>\s*<td>\s*<img[^>]+alt="([^"]*)"[^>]*>\s*</td>\s*<td>\s*([^<]*?)\s*</td>\s*'
            r'<td>\s*([^<]*?)\s*</td>\s*<td[^>]*>\s*([^<]*?)\s*</td>\s*<td>\s*<a href="([^"]+)"[^>]*>\s*WATCH\s*</a>', page):
        if _html.unescape(status).strip().lower() == 'ended':
            continue
        out.append((_html.unescape(event).strip(), urljoin(base, _html.unescape(href).strip())))
    return out


def _p_vk(page, base):
    out = []
    for m in re.finditer(r'(?s)padding:0">([^<]*).*?href="([^"]*)', page):
        t, h = _html.unescape(m.group(1)).strip(), m.group(2)
        if t and h:
            out.append((t, urljoin(base, h)))
    return out


def _p_bf(page, base):
    out = []
    for teams, href in re.findall(r'(?s)<a[^>]+class="competition"[^>]+title="([^"]+)"[^>]+href="([^"]+)"', page):
        out.append((_html.unescape(teams).replace('Buffstreams ', '').strip(), urljoin(base, href)))
    for href, block in re.findall(r'(?s)<a class="d-block competition p-4"[^>]*href="([^"]+)">\s*<div>\s*(.*?)\s*</div>', page):
        text = _html.unescape(re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', block))).strip()
        text = re.sub(r'\s*-\s*\d{1,2}:\d{2}\s*[AP]M\s*ET$', '', text)
        out.append((text, urljoin(base, href)))
    return out


def _p_sc(page, base):
    """streamcenter game cards: one row per source link of a card."""
    out = []
    for card in re.findall(r'(?is)<article\s+class=["\']game-card-row["\'][^>]*>(.*?)</article>', page):
        t = re.search(r'(?is)<h3[^>]*>\s*(.*?)\s*</h3>', card)
        if not t:
            continue
        name = re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', t.group(1)))).strip()
        name = re.sub(r'\s+vs\.?\s+', ' vs ', name)
        for href in re.findall(r'(?is)<a\s+class=["\']game-card-open-link["\'][^>]+href=["\']([^"\']+)["\']', card):
            href = _html.unescape(href).strip()
            out.append((name, ('https:' + href) if href.startswith('//') else urljoin(base, href)))
    return out


def _p_sh(page, base):
    out = []
    for event, _lg, _t, href in re.findall(
            r'(?s)<tr>\s*<td[^>]*><strong>([^<]+)</strong></td>.*?<td[^>]*><strong>([^<]+)<strong></td>.*?'
            r'<td[^>]*><strong>([^<]+)</strong></td>.*?<a href="([^"]+)"', page):
        out.append((_html.unescape(event).strip(), urljoin(base, href)))
    return out


def _p_sf(page, base):
    out = []
    for art in re.findall(r'<article.*?</article>', page, re.S):
        m = re.search(r'<h2 class="entry-title"[^>]*><a href="([^"]+)"[^>]*>([^<]+)</a></h2>', art, re.S)
        if m:
            out.append((_html.unescape(m.group(2)).strip(), m.group(1)))
    return out


def _p_rp(page, base):
    out = []
    for art in re.findall(r'<article id="post-\d+".*?</article>', page, re.S):
        m = re.search(r'<h3>\s*<a href="([^"]+)">([^<]+)</a>\s*</h3>', art, re.S)
        if m:
            out.append((_html.unescape(m.group(2)).strip(), m.group(1)))
    return out


def _p_ss(page, base):
    out = []
    for m in re.finditer(r'<a class="row MaclariListele[^"]*"\s+href="([^"]+)"[^>]*>(.*?)</a>', page, re.S):
        href, block = m.group(1), m.group(2)
        teams = re.findall(r'team-name-event-row.*?<span[^>]*>\s*([^<]+?)\s*</span>', block, re.S)
        if len(teams) >= 2:
            out.append(('%s vs %s' % (_html.unescape(teams[0]).strip(), _html.unescape(teams[1]).strip()), urljoin(base, href)))
        else:
            h4 = re.search(r'<h4[^>]*>\s*([^<]+?)\s*</h4>', block, re.S)
            if h4:
                out.append((_html.unescape(h4.group(1)).strip(), urljoin(base, href)))
    return out


def _p_eh(page, base):
    """rockylive/embedhd: {"days":[{"items":[{title, category, status, streams:[{link}]}]}]}"""
    import json as _json
    out = []
    for day in (_json.loads(page).get('days') or []):
        for ev in day.get('items') or []:
            title = (ev.get('title') or '').replace(' - ', ' vs ')
            for st in ev.get('streams') or []:
                if st.get('link'):
                    out.append((title, st['link']))
    return out


def _p_tm(page, base):
    """timst channels JSON: {"channels":[{"name","streams":[{"url"}]}]}"""
    import json as _json
    out = []
    for ch in (_json.loads(page).get('channels') or []):
        for st in ch.get('streams') or []:
            if st.get('url'):
                out.append((ch.get('name') or '', st['url']))
    return out


# code -> (label, base, {sport slug: path}, parser)
_PROVIDERS = {
    'se': ('StreamEast', 'https://streameast.cool',
           {'nhl': 'nhlstreams', 'nfl': 'nflstreams', 'nba': 'nbastreams', 'mlb': 'mlbstreams', 'ufc': 'mmastreams',
            'boxing': 'boxingstreams', 'cfb': 'cfbstreams', 'ncaab': 'ncaabstreams', 'wwe': 'wwestreams3'}, _p_se),
    'vg': ('StreamEast VG', 'https://streameast.vg',
           {'nhl': 'nhl', 'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'ufc': 'mma', 'boxing': 'boxing', 'cfb': 'college-football', 'wwe': 'wwe'}, _p_vg),
    'ps': ('PlayoffsStream', 'https://playoffsstream.com',
           {'nhl': 'nhl-streams', 'nfl': 'nfl-streams', 'nba': 'nba-streams', 'mlb': 'mlb-streams', 'ufc': 'ufc-streams',
            'boxing': 'boxing-streams', 'cfb': 'ncaaf-streams', 'ncaab': 'ncaam-streams'}, _p_ps),
    'p7': ('720pStream', 'https://720pstream.cx',
           {'nhl': 'nhl-online', 'nfl': 'nfl-online', 'nba': 'nba-online', 'mlb': 'mlb-online', 'ufc': 'mma-online',
            'boxing': 'boxing-online', 'cfb': 'ncaaf-online', 'ncaab': 'ncaam-online', 'soccer': 'soccer-online'}, _p_p7),
    'ih': ('iHDStreams', 'https://ihdstreams.top',
           {'nhl': '?sport=NHL', 'nfl': '?sport=NFL', 'nba': '?sport=NBA', 'mlb': 'index.php?sport=MLB', 'ufc': '?sport=UFC',
            'boxing': '?sport=Boxing', 'cfb': '?sport=CFB', 'ncaab': '?sport=NCAAB', 'soccer': '?sport=Soccer', 'wwe': '?sport=WWE'}, _p_ih),
    'fs': ('FSportsHD', 'https://fsportshdz.xyz',
           {'nfl': 'nflstreams.php', 'ufc': 'mmastreams.php', 'soccer': 'footballstreams.php'}, _p_fs),
    'g2': ('GStream24', 'https://gstream24.fun',
           {'nhl': 'sport/nhl/', 'nfl': 'sport/nfl/', 'nba': 'sport/nba/', 'mlb': 'sport/mlb/', 'ufc': 'sport/ufc/',
            'boxing': 'sport/boxing/', 'cfb': 'sport/college-football/', 'ncaab': 'sport/mens-college-basketball/'}, _p_g2),
    'vk': ('VoloKit', 'http://volokit2.fun',
           {'nhl': 'sport/nhl', 'nfl': 'sport/nfl', 'nba': 'sport/nba/', 'mlb': 'sport/mlb/', 'ufc': 'sport/ufc/',
            'boxing': 'sport/boxing/', 'cfb': 'sport/college-football', 'ncaab': 'sport/mens-college-basketball/'}, _p_vk),
    'bf': ('BuffStreams', 'https://mybuffstreams.plus',
           {'nhl': 'nhlstreams', 'nfl': 'nflstreams', 'nba': 'nbastreams', 'mlb': 'mlb-live-streams', 'ufc': 'mmastreams',
            'boxing': 'boxingstreams', 'cfb': 'cfbstreams', 'ncaab': 'ncaastreams', 'soccer': 'soccer-live-streams',
            'wwe': 'wwestreams', 'f1': 'f1streams2'}, _p_bf),
    'sc': ('StreamCenter', 'https://streamcenter.st/game-cards/embed',
           {'nhl': '?sport=hockey', 'nfl': '?sport=football', 'cfb': '?sport=football', 'nba': '?sport=basketball',
            'ncaab': '?sport=basketball', 'mlb': '?sport=baseball', 'soccer': '?sport=soccer'}, _p_sc),
    'sh': ('StreamHD', 'https://streamhd247.click', {'*': 'index.html'}, _p_sh),
    'sf': ('Streamsify', 'https://streamsify.xyz', {'*': ''}, _p_sf),
    'ss': ('SportSurge', 'https://isportsurge.ws', {'*': 'index8'}, _p_ss),
    'eh': ('RockyLive', 'https://rockylive.st', {'*': 'api-event.php'}, _p_eh),
    'tm': ('TimStreams', 'https://timst.cfd', {'*': 'api/channels'}, _p_tm),
}
# sports some providers cover that the first table left out (their league pages)
for _c, _extra in {
        'vg': {'f1': 'f1', 'motogp': 'f1'},
        'ih': {'f1': '?sport=F1'},
        'g2': {'f1': 'sport/race/', 'motogp': 'sport/race/'},
        'vk': {'f1': 'sport/race/', 'motogp': 'sport/race/'},
        'se': {'f1': 'f1streams3'},
        'fs': {'motogp': 'motogpstreams.php', 'f1': 'f1streams.php'},
}.items():
    _PROVIDERS[_c][2].update(_extra)
LABEL = {k: v[0] for k, v in _PROVIDERS.items()}


def _cache():
    from resources.lib import sports_sources as _ss
    return _ss._cache


def _rows(code, sport_slug):
    label, base, paths, parser = _PROVIDERS[code]
    path = paths.get(sport_slug)
    if path is None:
        path = paths.get('*')
    if path is None:
        return []
    ck = 'livepages_%s_%s' % (code, '*' if '*' in paths and sport_slug not in paths else sport_slug)
    c = _cache()
    hit = c.get(ck)
    if hit is not None:
        return hit
    url = base.rstrip('/') + '/' + path.lstrip('/')
    try:
        text = _get_tim(url, base) if code == 'tm' else _get(url, referer=base + '/')
        rows = parser(text, base + '/')
    except Exception as e:
        _log('%s %s listing: %s' % (code, sport_slug, str(e)[:80]))
        rows = []
    c.set(ck, rows, 120 if rows else 60)
    return rows


def links_for(sport_slug, title, match_fn, deadline=6.0):
    """[(provider code, {'label', 'url'})] for the rows of every provider that are this game."""
    codes = [k for k, v in _PROVIDERS.items() if sport_slug in v[2] or '*' in v[2]]
    if not codes:
        return []
    ex = ThreadPoolExecutor(max_workers=len(codes))
    futs = {ex.submit(_rows, k, sport_slug): k for k in codes}
    ex.shutdown(wait=False)
    done, _pending = _wait(list(futs), timeout=deadline)
    out, seen = [], set()
    for f in done:
        code = futs[f]
        try:
            rows = f.result()
        except Exception:
            continue
        for t, href in rows:
            if href in seen or not match_fn(title, t):
                continue
            seen.add(href)
            out.append((code, {'label': LABEL[code], 'url': href}))
    return out


def _aes_tables():
    sbox = [0] * 256
    p = q = 1
    while True:
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        q ^= q << 1; q ^= q << 2; q ^= q << 4; q &= 0xFF
        if q & 0x80:
            q ^= 0x09
        x = q ^ (q << 1 | q >> 7) & 0xFF ^ (q << 2 | q >> 6) & 0xFF ^ (q << 3 | q >> 5) & 0xFF ^ (q << 4 | q >> 4) & 0xFF
        sbox[p] = (x ^ 0x63) & 0xFF
        if p == 1:
            break
    sbox[0] = 0x63
    inv = [0] * 256
    for i, v in enumerate(sbox):
        inv[v] = i
    return sbox, inv


_SBOX, _RSBOX = _aes_tables()


def _xt(a):
    a <<= 1
    return (a ^ 0x11B) & 0xFF if a & 0x100 else a


def _gm(a, b):
    r = 0
    for _ in range(8):
        if b & 1:
            r ^= a
        a = _xt(a)
        b >>= 1
    return r


def _aes128_decrypt_block(key, block):
    w = [list(key[4 * i:4 * i + 4]) for i in range(4)]
    rcon = 1
    for i in range(4, 44):
        t = list(w[i - 1])
        if i % 4 == 0:
            t = [_SBOX[b] for b in t[1:] + t[:1]]
            t[0] ^= rcon
            rcon = _xt(rcon)
        w.append([w[i - 4][j] ^ t[j] for j in range(4)])
    rk = [sum((w[r * 4 + c] for c in range(4)), []) for r in range(11)]

    def inv_shift(st):
        o = st[:]
        for r in range(1, 4):
            row = [st[r + 4 * c] for c in range(4)]
            row = row[-r:] + row[:-r]
            for c in range(4):
                o[r + 4 * c] = row[c]
        return o

    def inv_mix(st):
        o = [0] * 16
        for c in range(4):
            a = st[4 * c:4 * c + 4]
            o[4 * c] = _gm(a[0], 14) ^ _gm(a[1], 11) ^ _gm(a[2], 13) ^ _gm(a[3], 9)
            o[4 * c + 1] = _gm(a[0], 9) ^ _gm(a[1], 14) ^ _gm(a[2], 11) ^ _gm(a[3], 13)
            o[4 * c + 2] = _gm(a[0], 13) ^ _gm(a[1], 9) ^ _gm(a[2], 14) ^ _gm(a[3], 11)
            o[4 * c + 3] = _gm(a[0], 11) ^ _gm(a[1], 13) ^ _gm(a[2], 9) ^ _gm(a[3], 14)
        return o

    st = [block[i] ^ rk[10][i] for i in range(16)]
    for rnd in range(9, 0, -1):
        st = [_RSBOX[b] for b in inv_shift(st)]
        st = inv_mix([st[i] ^ rk[rnd][i] for i in range(16)])
    st = [_RSBOX[b] for b in inv_shift(st)]
    return [st[i] ^ rk[0][i] for i in range(16)]


def _solve_shield(page):
    """Cookie (name, value) for the host's JavaScript challenge page."""
    text = re.sub(r'\\x([0-9A-Fa-f]{2})', lambda m: chr(int(m.group(1), 16)), page)
    ck = re.search(r'document\.cookie\s*=\s*"([A-Za-z0-9_-]+)=', text)
    b1 = re.search(r'b1\s*=\s*atob\("([^"]+)"\)', text)
    c3 = re.search(r'c3\s*=\s*toNumbers\("([0-9a-fA-F]{32})"\)', text)
    arr = re.search(r'var\s+_0x\w+\s*=\s*\[(.*?)\];', text, re.S)
    if not (ck and b1 and c3 and arr):
        return None
    key = None
    for item in re.findall(r'"([A-Za-z0-9+/=]{40,})"', arr.group(1)):
        try:
            cand = base64.b64decode(item).decode()
            if re.fullmatch(r'[0-9a-fA-F]{32}', cand):
                key = bytes.fromhex(cand)
        except Exception:
            pass
    if not key:
        return None
    iv = bytes.fromhex(base64.b64decode(b1.group(1)).decode())
    pt = _aes128_decrypt_block(list(key), list(bytes.fromhex(c3.group(1))))
    return ck.group(1), bytes(x ^ y for x, y in zip(pt, iv)).hex()


def _get_tim(url, base):
    h = {'User-Agent': UA, 'Referer': base + '/', 'Accept': 'application/json, text/plain, */*', 'Accept-Encoding': 'identity'}
    sess = requests.Session()
    r = sess.get(url, headers=h, timeout=_TIMEOUT)
    body = r.content.decode('utf-8', 'replace')
    try:
        r.json()
        return body
    except Exception:
        pass
    solved = _solve_shield(body)
    if not solved:
        raise ValueError('challenge not understood')
    sess.cookies.set(solved[0], solved[1], domain=urlparse(base).netloc, path='/')
    r = sess.get(url, headers=h, timeout=_TIMEOUT)
    return r.content.decode('utf-8', 'replace')


# ── page url -> stream ───────────────────────────────────────────────────────

_RE_BTN = re.compile(r'(?s)id="stream-btn-(\d+)"[^>]*?>(.*?)</div>')
_RE_TMPL = re.compile(
    r"getElementById\(['\"](?:wp_player|cx-iframe)['\"]\)\.src\s*=\s*['\"]([^'\"]+)['\"]\s*\+\s*streamId(?:\s*\+\s*['\"]([^'\"]*)['\"])?")


def _iframe_of(page_url, page, referer):
    """The player iframe of a provider page (numbered server buttons fill it from a template)."""
    tmpl = _RE_TMPL.search(page)
    servers = _RE_BTN.findall(page)
    if tmpl and servers:
        return tmpl.group(1) + servers[0][0] + (tmpl.group(2) or '')
    m = re.search(r'(?is)<iframe[^>]+src=["\']([^"\']+)', page)
    return m.group(1) if m else None


_GOAT_HOSTS = ('embed.st', 'embedsports', 'pooembed', 'embedindia', 'taifood-blog')


def _pipe_for(src, page_url):
    p = urlparse(page_url)
    origin = '%s://%s' % (p.scheme, p.netloc)
    return '%s|User-Agent=%s&Referer=%s&Origin=%s' % (
        src, requests.utils.quote(UA, safe=''), requests.utils.quote(origin + '/', safe=''), requests.utils.quote(origin, safe=''))


def _decode_array_payload(page):
    """Pages that hide a stream address in a number array, XOR key and offset (decoded here, not run)."""
    m = re.search(r'var\s+\w+\s*=\s*\[([\d,\s]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*""\s*,\s*\w+\s*;', page, re.S)
    if not m:
        return None
    arr = [int(n) for n in m.group(1).split(',') if n.strip()]
    k1, k2 = int(m.group(2)), int(m.group(3))
    text = ''.join(chr(((n ^ k1) - k2 + 256) & 255) for n in arr)
    mm = re.search(r'(?:\burl|SIGNED_URL)\s*=\s*"([^"]+)"', text)
    if not mm:
        return None
    return re.sub(r'(?<!:)/{2,}', '/', mm.group(1).replace('\\/', '/'))


def resolve_page(page_url):
    """Provider page -> ('stream', piped_url) for a decoded playlist, or ('embed', url) when the page leads to a player
    host the caller should resolve. Follows up to five page / iframe hops."""
    cur, ref = page_url, page_url
    for _hop in range(5):
        page = _get(cur, referer=ref)
        # stream address hidden in a number array
        arr = _decode_array_payload(page)
        if arr and arr.startswith('http'):
            return 'stream', _pipe_for(arr, cur)
        # base64 iframe address (rockystream / rockylive and relatives)
        m = re.search(r'atob\(["\']([A-Za-z0-9+/=]{16,})["\']\)', page)
        if m:
            try:
                dec = base64.b64decode(m.group(1)).decode('utf-8', 'ignore').strip()
            except Exception:
                dec = ''
            if dec.startswith('http'):
                if '.m3u8' in dec:
                    return 'stream', _pipe_for(dec, cur)
                if any(h in dec for h in _GOAT_HOSTS):
                    return 'embed', dec
                cur, ref = dec, cur
                continue
        # plain playlist address in the page
        for pat in (r'const\s+streamUrls\s*=\s*(\[.*?\]);', r'const\s+streamUrl\s*=\s*"([^"]*)"', r'var\s+streamUrl\s*=\s*"([^"]+)"',
                    r'(?:const|var|let)\s+source\s*=\s*["\']([^"\']+)', r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)'):
            mm = re.search(pat, page)
            if not mm:
                continue
            val = mm.group(1)
            if val.startswith('['):
                import json as _json
                try:
                    urls = [u for u in _json.loads(val) if u]
                except Exception:
                    urls = []
                val = urls[0] if urls else ''
            val = val.replace('\\/', '/')
            if val.startswith('http'):
                return 'stream', _pipe_for(val, cur)
        # streams-center style: an encrypted token the site decrypts for us
        mm = re.search(r'input:\s*"([^"]+)"', page)
        if mm:
            p = urlparse(cur)
            try:
                resp = requests.post('%s://%s/embed/decrypt.php' % (p.scheme, p.netloc), data={'input': mm.group(1)}, timeout=_TIMEOUT,
                                     headers={'User-Agent': UA, 'Referer': cur}).text.strip()
            except Exception:
                resp = ''
            if resp.startswith('http'):
                if '.m3u8' in resp:
                    return 'stream', _pipe_for(resp, cur)
                cur, ref = resp, cur
                continue
        nxt = _iframe_of(cur, page, ref)
        if not nxt:
            return None
        nxt = _html.unescape(nxt).strip()
        if nxt.startswith('https:///'):
            nxt = 'https://' + urlparse(cur).netloc + '/' + nxt[len('https:///'):]
        elif nxt.startswith('//'):
            nxt = 'https:' + nxt
        nxt = urljoin(cur, nxt)
        if any(h in urlparse(nxt).netloc.lower() for h in _GOAT_HOSTS):
            return 'embed', nxt
        cur, ref = nxt, cur
    return None
