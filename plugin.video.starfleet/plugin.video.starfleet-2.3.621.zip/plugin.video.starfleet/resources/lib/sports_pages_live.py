# -*- coding: utf-8 -*-
"""Schedule-page providers for live sports, looked up per game.

Each provider publishes one HTML schedule page per league. Nothing is scraped when the sports lists are drawn;
when a game is opened `links_for(sport_slug, title)` fetches that league's page from every provider that has one
(in parallel, short timeouts), keeps the rows that are this game, and returns their page URLs. sports_starfleet_live
then resolves each page URL to a playable stream (`resolve_page`).

Providers (current domains come from data/live_sites.json when it lists them, else the defaults below)
    se   StreamEast        podium rows; a page has numbered server buttons that fill an iframe
    vg   StreamEast (vg)   <a class="ev ..."> rows
    ps   PlayoffsStream    block buttons
    p7   720pStream        match cards
    ih   iHDStreams        "Watch <teams> Live Stream" links
    fs   FSportsHD         media-body rows
    g2   GStream24         table rows with a WATCH link
    vk   VoloKit           table rows
    bf   BuffStreams       competition cards
"""
import base64
import html as _html
import re
import time
from concurrent.futures import ThreadPoolExecutor, wait as _wait
from urllib.parse import urljoin, urlparse

import requests
import xbmc

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
_TIMEOUT = 7


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/LivePages] %s' % msg, level)


def _get(url, referer=None, timeout=_TIMEOUT):
    h = {'User-Agent': UA}
    if referer:
        h['Referer'] = referer
    r = requests.get(url, headers=h, timeout=timeout)
    r.raise_for_status()
    return r.text


# ── row parsers: html -> [(title, href)] ─────────────────────────────────────

def _p_se(page, base):
    out = []
    for block in re.findall(r'(?s)<li[^>]*\bclass=["\'][^"\']*\bf1-podium--item\b[^"\']*["\'][^>]*>(.*?)</li>', page):
        m = re.search(r'(?s)<a\s+href=["\']([^"\']+)["\'].*?d-md-inline[^>]*>\s*([^<]+?)\s*</span>', block)
        if m:
            out.append((_html.unescape(m.group(2)).strip(), urljoin(base, _html.unescape(m.group(1)).strip())))
    return out


def _p_vg(page, base):
    out = []
    for cls, href, title, _blk in re.findall(r'<a class="ev (?:ev-match|ev-plain)([^"]*)" href="([^"]+)" title="([^"]+)"[^>]*>(.*?)</a>', page, re.S):
        if 'is-post' in cls:
            continue
        out.append((_html.unescape(title).strip(), urljoin(base, href)))
    return out


def _p_ps(page, base):
    return [(_html.unescape(t).strip(), urljoin(base, h)) for h, t in re.findall(
        r'(?s)<a class="btn btn-info btn-block"[^>]+href="([^"]+)"[^>]*>.*?<div class="text-center">[^<]*</div>'
        r'.*?<div[^>]+d-none d-md-inline[^>]*>([^<]+)</div>', page)]


def _p_p7(page, base):
    out = []
    for href, _tb, teams in re.findall(r'<a class="match-card" href="([^"]+)">\s*<div class="match-time">(.*?)</div>\s*<div class="match-teams">(.*?)</div>', page, re.S):
        names = [_html.unescape(t).strip() for t in re.findall(r'<strong>([^<]+)</strong>', teams) if t.strip()]
        if names:
            out.append((' vs '.join(names), urljoin(base, href)))
    return out


def _p_ih(page, base):
    return [(_html.unescape(t).strip(), urljoin(base, h)) for h, t in re.findall(r'<a href="([^"]+)"[^>]+title="Watch ([^"]+?) Live Stream', page)]


def _p_fs(page, base):
    out = []
    for href, teams, _blk in re.findall(r'<div class="media-body">\s*<a href=["\']([^"\']+)["\'][^>]*>.*?<h4[^>]*>\s*([^<]+?)\s*</h4>(.*?)</a>', page, re.S):
        if 'Click Here' in teams:
            continue
        out.append((_html.unescape(teams).strip(), urljoin(base, href)))
    return out


def _p_g2(page, base):
    out = []
    for _d, _lg, event, _t, status, href in re.findall(
            r'(?s)<tr>\s*<td>\s*([^<]*?)\s*</td>\s*<td>\s*<img[^>]+alt="([^"]*)"[^>]*>\s*</td>\s*<td>\s*([^<]*?)\s*</td>\s*'
            r'<td>\s*([^<]*?)\s*</td>\s*<td[^>]*>\s*([^<]*?)\s*</td>\s*<td>\s*<a href="([^"]+)"[^>]*>\s*WATCH\s*</a>', page):
        if _html.unescape(status).strip().lower() == 'ended':
            continue
        out.append((_html.unescape(event).strip(), urljoin(base, _html.unescape(href).strip())))
    return out


def _p_vk(page, base):
    out = []
    for m in re.finditer(r'(?s)padding:0">([^<]*).*?href="([^"]*)', page):
        t, h = _html.unescape(m.group(1)).strip(), m.group(2)
        if t and h:
            out.append((t, urljoin(base, h)))
    return out


def _p_bf(page, base):
    out = []
    for teams, href in re.findall(r'(?s)<a[^>]+class="competition"[^>]+title="([^"]+)"[^>]+href="([^"]+)"', page):
        out.append((_html.unescape(teams).replace('Buffstreams ', '').strip(), urljoin(base, href)))
    for href, block in re.findall(r'(?s)<a class="d-block competition p-4"[^>]*href="([^"]+)">\s*<div>\s*(.*?)\s*</div>', page):
        text = _html.unescape(re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', block))).strip()
        text = re.sub(r'\s*-\s*\d{1,2}:\d{2}\s*[AP]M\s*ET$', '', text)
        out.append((text, urljoin(base, href)))
    return out


# code -> (label, base, {sport slug: path}, parser)
_PROVIDERS = {
    'se': ('StreamEast', 'https://streameast.cool',
           {'nhl': 'nhlstreams', 'nfl': 'nflstreams', 'nba': 'nbastreams', 'mlb': 'mlbstreams', 'ufc': 'mmastreams',
            'boxing': 'boxingstreams', 'cfb': 'cfbstreams', 'ncaab': 'ncaabstreams', 'wwe': 'wwestreams3'}, _p_se),
    'vg': ('StreamEast VG', 'https://streameast.vg',
           {'nhl': 'nhl', 'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'ufc': 'mma', 'boxing': 'boxing', 'cfb': 'college-football', 'wwe': 'wwe'}, _p_vg),
    'ps': ('PlayoffsStream', 'https://playoffsstream.com',
           {'nhl': 'nhl-streams', 'nfl': 'nfl-streams', 'nba': 'nba-streams', 'mlb': 'mlb-streams', 'ufc': 'ufc-streams',
            'boxing': 'boxing-streams', 'cfb': 'ncaaf-streams', 'ncaab': 'ncaam-streams'}, _p_ps),
    'p7': ('720pStream', 'https://720pstream.cx',
           {'nhl': 'nhl-online', 'nfl': 'nfl-online', 'nba': 'nba-online', 'mlb': 'mlb-online', 'ufc': 'mma-online',
            'boxing': 'boxing-online', 'cfb': 'ncaaf-online', 'ncaab': 'ncaam-online', 'soccer': 'soccer-online'}, _p_p7),
    'ih': ('iHDStreams', 'https://ihdstreams.top',
           {'nhl': '?sport=NHL', 'nfl': '?sport=NFL', 'nba': '?sport=NBA', 'mlb': 'index.php?sport=MLB', 'ufc': '?sport=UFC',
            'boxing': '?sport=Boxing', 'cfb': '?sport=CFB', 'ncaab': '?sport=NCAAB', 'soccer': '?sport=Soccer', 'wwe': '?sport=WWE'}, _p_ih),
    'fs': ('FSportsHD', 'https://fsportshdz.xyz',
           {'nfl': 'nflstreams.php', 'ufc': 'mmastreams.php', 'soccer': 'footballstreams.php'}, _p_fs),
    'g2': ('GStream24', 'https://gstream24.fun',
           {'nhl': 'sport/nhl/', 'nfl': 'sport/nfl/', 'nba': 'sport/nba/', 'mlb': 'sport/mlb/', 'ufc': 'sport/ufc/',
            'boxing': 'sport/boxing/', 'cfb': 'sport/college-football/', 'ncaab': 'sport/mens-college-basketball/'}, _p_g2),
    'vk': ('VoloKit', 'http://volokit2.fun',
           {'nhl': 'sport/nhl', 'nfl': 'sport/nfl', 'nba': 'sport/nba/', 'mlb': 'sport/mlb/', 'ufc': 'sport/ufc/',
            'boxing': 'sport/boxing/', 'cfb': 'sport/college-football', 'ncaab': 'sport/mens-college-basketball/'}, _p_vk),
    'bf': ('BuffStreams', 'https://mybuffstreams.plus',
           {'nhl': 'nhlstreams', 'nfl': 'nflstreams', 'nba': 'nbastreams', 'mlb': 'mlb-live-streams', 'ufc': 'mmastreams',
            'boxing': 'boxingstreams', 'cfb': 'cfbstreams', 'ncaab': 'ncaastreams', 'soccer': 'soccer-live-streams', 'wwe': 'wwestreams'}, _p_bf),
}
LABEL = {k: v[0] for k, v in _PROVIDERS.items()}


def _cache():
    from resources.lib import sports_sources as _ss
    return _ss._cache


def _rows(code, sport_slug):
    label, base, paths, parser = _PROVIDERS[code]
    path = paths.get(sport_slug)
    if not path:
        return []
    ck = 'livepages_%s_%s' % (code, sport_slug)
    c = _cache()
    hit = c.get(ck)
    if hit is not None:
        return hit
    url = base.rstrip('/') + '/' + path.lstrip('/')
    try:
        rows = parser(_get(url, referer=base + '/'), base + '/')
    except Exception as e:
        _log('%s %s listing: %s' % (code, sport_slug, str(e)[:80]))
        rows = []
    c.set(ck, rows, 120 if rows else 60)
    return rows


def links_for(sport_slug, title, match_fn, deadline=6.0):
    """[(provider code, {'label', 'url'})] for the rows of every provider that are this game."""
    codes = [k for k, v in _PROVIDERS.items() if sport_slug in v[2]]
    if not codes:
        return []
    ex = ThreadPoolExecutor(max_workers=len(codes))
    futs = {ex.submit(_rows, k, sport_slug): k for k in codes}
    ex.shutdown(wait=False)
    done, _pending = _wait(list(futs), timeout=deadline)
    out, seen = [], set()
    for f in done:
        code = futs[f]
        try:
            rows = f.result()
        except Exception:
            continue
        for t, href in rows:
            if href in seen or not match_fn(title, t):
                continue
            seen.add(href)
            out.append((code, {'label': LABEL[code], 'url': href}))
    return out


# ── page url -> stream ───────────────────────────────────────────────────────

_RE_BTN = re.compile(r'(?s)id="stream-btn-(\d+)"[^>]*?>(.*?)</div>')
_RE_TMPL = re.compile(
    r"getElementById\(['\"](?:wp_player|cx-iframe)['\"]\)\.src\s*=\s*['\"]([^'\"]+)['\"]\s*\+\s*streamId(?:\s*\+\s*['\"]([^'\"]*)['\"])?")


def _iframe_of(page_url, page, referer):
    """The player iframe of a provider page (numbered server buttons fill it from a template)."""
    tmpl = _RE_TMPL.search(page)
    servers = _RE_BTN.findall(page)
    if tmpl and servers:
        return tmpl.group(1) + servers[0][0] + (tmpl.group(2) or '')
    m = re.search(r'(?is)<iframe[^>]+src=["\']([^"\']+)', page)
    return m.group(1) if m else None


def resolve_page(page_url):
    """Provider page -> (kind, value): ('stream', piped_url) for a decoded playlist, ('embed', url) when the page leads
    to another embed host that the caller should resolve."""
    page = _get(page_url, referer=page_url)
    iframe = _iframe_of(page_url, page, page_url)
    if not iframe:
        return None
    iframe = _html.unescape(iframe).strip()
    if iframe.startswith('//'):
        iframe = 'https:' + iframe
    iframe = urljoin(page_url, iframe)
    host = urlparse(iframe).netloc.lower()
    if 'embed.st' in host or 'embedsports' in host or 'pooembed' in host or 'embedindia' in host:
        return 'embed', iframe
    html2 = _get(iframe, referer=page_url)
    src = None
    m = re.search(r"atob\(['\"]([A-Za-z0-9+/=]+)['\"]\)", html2)
    if m:
        try:
            src = base64.b64decode(m.group(1)).decode('utf-8', 'ignore')
        except Exception:
            src = None
    if not src:
        m = re.search(r'(?:const|var|let)\s+source\s*=\s*["\']([^"\']+)', html2)
        src = m.group(1) if m else None
    if not src:
        m = re.search(r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)', html2)
        src = m.group(1) if m else None
    if not src or not src.startswith('http'):
        nxt = re.search(r'(?is)<iframe[^>]+src=["\']([^"\']+)', html2)
        if nxt:
            u = urljoin(iframe, _html.unescape(nxt.group(1)).strip())
            return 'embed', u
        return None
    origin = '%s://%s' % (urlparse(iframe).scheme, urlparse(iframe).netloc)
    return 'stream', '%s|User-Agent=%s&Referer=%s&Origin=%s' % (
        src, requests.utils.quote(UA, safe=''), requests.utils.quote(origin + '/', safe=''), requests.utils.quote(origin, safe=''))
