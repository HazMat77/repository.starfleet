# -*- coding: utf-8 -*-
"""
resources/lib/profiles_ui.py

The dialogs for viewer profiles (see profiles.py): switching, creating, editing, deleting, profile PINs and the Parent PIN. They
are used by the Profile button on Home (which passes its own themed selector as `pick`) and by Settings > Profiles (which uses
Kodi's plain select dialog).

Rules the dialogs apply
  * a profile with its own PIN asks for it before it is entered;
  * when a Parent PIN exists, a restricted profile (kids / hidden Adult section / rating cap) must enter it to open Settings,
    to create, edit or delete profiles, and to switch to a profile that is not restricted;
  * with no Parent PIN nothing is locked - PINs are optional.
"""
import xbmc
import xbmcgui

from resources.lib import profiles as pf


from resources.lib import screen_time as _st
def _pick_default(title, options):
    return xbmcgui.Dialog().select(title, options)


def _ask_pin(heading):
    """The digits typed (hidden), or None when cancelled."""
    kb = xbmc.Keyboard('', heading, True)
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else None


def _new_pin(heading):
    """A new PIN typed twice; '' when cancelled or they differ (with a notice)."""
    a = _ask_pin(heading)
    if not a:
        return ''
    if not a.isdigit() or len(a) < 4:
        xbmcgui.Dialog().ok('Starfleet', 'A PIN is at least 4 digits.')
        return ''
    b = _ask_pin('Enter it again')
    if b != a:
        xbmcgui.Dialog().ok('Starfleet', 'The two PINs did not match.')
        return ''
    return a


def parent_gate(reason='do that'):
    """True when this may go ahead: the active profile is unrestricted, no Parent PIN is set, or the Parent PIN was entered."""
    try:
        if not pf.is_restricted() or not pf.has_parent_pin():
            return True
    except Exception:
        return True
    pin = _ask_pin('Parent PIN (to %s)' % reason)
    if pin is not None and pf.check_parent_pin(pin):
        return True
    if pin is not None:
        xbmcgui.Dialog().notification('Starfleet', 'Incorrect PIN', xbmcgui.NOTIFICATION_ERROR, 3000)
    return False


def _label(p, active_id=None):
    mark = '● ' if p['id'] == active_id else ''
    tags = []
    if p.get('kind') == 'kids':
        tags.append('Kids')
    if p.get('pin'):
        tags.append('PIN')
    return '%s%s%s' % (mark, p['name'], (' (%s)' % ', '.join(tags)) if tags else '')


def switch_to(p):
    """Switch to profile dict `p` after its PIN and the Parent PIN rules. Returns True when the switch happened."""
    if p['id'] == pf.active_id():
        return False
    cur = pf.active()
    if pf.is_restricted(cur) and not pf.is_restricted(p) and pf.has_parent_pin() and not parent_gate('switch to %s' % p['name']):
        return False
    if p.get('pin'):
        pin = _ask_pin('PIN for %s' % p['name'])
        if pin is None:
            return False
        if not pf.check_profile_pin(p['id'], pin):
            xbmcgui.Dialog().notification('Starfleet', 'Incorrect PIN', xbmcgui.NOTIFICATION_ERROR, 3000)
            return False
    pf.switch(p['id'])
    xbmcgui.Dialog().notification('Starfleet', 'Now watching as %s' % p['name'], xbmcgui.NOTIFICATION_INFO, 3000)
    return True


def switch_flow(pick=None):
    """Choose a profile and switch to it. Returns True when the active profile changed."""
    pick = pick or _pick_default
    profs = pf.all_profiles()
    act = pf.active_id()
    i = pick("Who's watching?", [_label(p, act) for p in profs])
    if not isinstance(i, int) or i < 0:
        return False
    return switch_to(profs[i])


def create_flow(pick=None):
    """Create a profile (name, Adult or Kids, limits, optional PIN), then offer to switch to it. Returns True if it switched."""
    pick = pick or _pick_default
    if not parent_gate('create a profile'):
        return False
    kb = xbmc.Keyboard('', 'Profile name')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return False
    name = kb.getText().strip()
    k = pick('Profile type', ['Adult - no limits', 'Kids - hidden Adult section and a content limit'])
    if not isinstance(k, int) or k < 0:
        return False
    kind = 'kids' if k == 1 else 'adult'
    hide_adult = max_rating = None
    if kind == 'kids':
        hide_adult = xbmcgui.Dialog().yesno('Starfleet', 'Hide the Adult section for %s?' % name, yeslabel='Hide it', nolabel='Keep it')
        r = pick('What can %s watch?' % name, [label for _code, label in pf.RATINGS[1:]])
        max_rating = pf.RATINGS[1:][r][0] if isinstance(r, int) and r >= 0 else '14'
    else:
        hide_adult = xbmcgui.Dialog().yesno('Starfleet', 'Hide the Adult section for %s?' % name, yeslabel='Hide it', nolabel='Keep it')
    pin = ''
    if xbmcgui.Dialog().yesno('Starfleet', 'Lock the %s profile with a PIN?\n\nOptional: without one anybody can switch to it.' % name,
                              yeslabel='Set a PIN', nolabel='No PIN'):
        pin = _new_pin('Choose a PIN (4 digits or more)')
    prof = pf.create(name, kind, hide_adult, max_rating, pin)
    if xbmcgui.Dialog().yesno('Starfleet', 'Switch to %s now?' % name, yeslabel='Switch', nolabel='Later'):
        pf.switch(prof['id'])
        xbmcgui.Dialog().notification('Starfleet', 'Now watching as %s' % name, xbmcgui.NOTIFICATION_INFO, 3000)
        if xbmcgui.Dialog().yesno('Starfleet', 'Pair %s\'s own SIMKL account now?\n\nProgress then follows %s separately. '
                                  'You can also do it later in Settings.' % (name, name), yeslabel='Pair SIMKL', nolabel='Later'):
            try:
                from resources.lib import simkl_auth
                simkl_auth.pair_with_simkl()
            except Exception as e:
                xbmc.log('[Starfleet/Profiles] pair simkl: %s' % e, xbmc.LOGWARNING)
        return True
    return False


def edit_flow(pick=None):
    """Edit or delete a profile. Returns True when the active profile's settings changed (the caller may refresh Home)."""
    pick = pick or _pick_default
    if not parent_gate('change profiles'):
        return False
    profs = pf.all_profiles()
    act = pf.active_id()
    i = pick('Edit which profile?', [_label(p, act) for p in profs])
    if not isinstance(i, int) or i < 0:
        return False
    p = profs[i]
    changed = False
    while True:
        p = pf.get(p['id'])
        if not p:
            return changed
        opts = ['Name: %s' % p['name'],
                'Type: %s' % ('Kids' if p['kind'] == 'kids' else 'Adult'),
                'Adult section: %s' % ('hidden' if p.get('hide_adult') else 'shown'),
                'Content limit: %s' % pf.rating_label(p.get('max_rating', 'none')),
                'Profile PIN: %s' % ('set (change or remove)' if p.get('pin') else 'none (set one)'),
                'Screen time: %s' % (_st.summary(p) or 'no limit'),
                'Sections hidden: %s' % (', '.join(l for k, l in pf.SECTIONS if k in (p.get('hidden_sections') or [])) or 'none'),
                'Genres hidden: %s' % (('%d' % len(p.get('hidden_genres') or [])) if p.get('hidden_genres') else 'none'),
                'Delete this profile']
        c = pick(p['name'], opts)
        if not isinstance(c, int) or c < 0:
            return changed
        if c == 0:
            kb = xbmc.Keyboard(p['name'], 'Profile name')
            kb.doModal()
            if kb.isConfirmed() and kb.getText().strip():
                pf.update(p['id'], name=kb.getText().strip()[:24])
        elif c == 1:
            t = pick('Profile type', ['Adult - no limits', 'Kids - hidden Adult section and a content limit'])
            if isinstance(t, int) and t >= 0:
                kind = 'kids' if t == 1 else 'adult'
                fields = {'kind': kind}
                if kind == 'kids':                       # moving to Kids applies the usual Kids limits
                    fields.update(hide_adult=True, max_rating=p.get('max_rating') if p.get('max_rating', 'none') != 'none' else '14')
                pf.update(p['id'], **fields)
        elif c == 2:
            pf.update(p['id'], hide_adult=not p.get('hide_adult'))
        elif c == 3:
            r = pick('Content limit for %s' % p['name'], [label for _code, label in pf.RATINGS])
            if isinstance(r, int) and r >= 0:
                pf.update(p['id'], max_rating=pf.RATINGS[r][0])
        elif c == 4:
            if p.get('pin'):
                a = pick('Profile PIN', ['Change the PIN', 'Remove the PIN'])
                if a == 1:
                    pf.set_profile_pin(p['id'], '')
                elif a == 0:
                    pin = _new_pin('New PIN (4 digits or more)')
                    if pin:
                        pf.set_profile_pin(p['id'], pin)
            else:
                pin = _new_pin('Choose a PIN (4 digits or more)')
                if pin:
                    pf.set_profile_pin(p['id'], pin)
        elif c == 5:
            m = pick('Daily watching time for %s' % p['name'], ['No daily limit' if x == 0 else _st.amount_label(x) for x in _st.DAILY_CHOICES])
            if isinstance(m, int) and m >= 0:
                b = pick('Bedtime for %s (watching starts again at %s)' % (p['name'], _st.hour_label(_st.WAKE_HOUR)),
                         ['No bedtime' if x < 0 else _st.hour_label(x) for x in _st.BED_CHOICES])
                if isinstance(b, int) and b >= 0:
                    pf.update(p['id'], daily_minutes=_st.DAILY_CHOICES[m], bed_hour=_st.BED_CHOICES[b])
        elif c == 6:
            have = p.get('hidden_sections') or []
            pre = [i for i, (k, _l) in enumerate(pf.SECTIONS) if k in have]
            sel = xbmcgui.Dialog().multiselect('Sections to hide for %s' % p['name'], [l for _k, l in pf.SECTIONS], preselect=pre)
            if sel is not None:
                pf.update(p['id'], hidden_sections=[pf.SECTIONS[i][0] for i in sel])
        elif c == 7:
            have = p.get('hidden_genres') or []
            pre = [i for i, g in enumerate(pf.GENRES) if g[0] in have]
            sel = xbmcgui.Dialog().multiselect('Genres to hide for %s' % p['name'], [g[1] for g in pf.GENRES], preselect=pre)
            if sel is not None:
                pf.update(p['id'], hidden_genres=[pf.GENRES[i][0] for i in sel])
        elif c == 8:
            if p['id'] == pf.active_id():
                xbmcgui.Dialog().ok('Starfleet', 'Switch to another profile first: the one in use cannot be deleted.')
            elif len(pf.all_profiles()) <= 1:
                xbmcgui.Dialog().ok('Starfleet', 'There has to be at least one profile.')
            elif xbmcgui.Dialog().yesno('Starfleet', 'Delete %s and everything saved for them (progress, favourites, teams)?\n\n'
                                        'This cannot be undone.' % p['name'], yeslabel='Delete', nolabel='Keep'):
                pf.delete(p['id'])
                return changed
        changed = changed or p['id'] == pf.active_id()


def parent_pin_flow(remove=False):
    """Set, change or remove the Parent PIN (the one a restricted profile needs for Settings and profile changes)."""
    if pf.has_parent_pin():
        pin = _ask_pin('Current Parent PIN')
        if pin is None:
            return
        if not pf.check_parent_pin(pin):
            xbmcgui.Dialog().notification('Starfleet', 'Incorrect PIN', xbmcgui.NOTIFICATION_ERROR, 3000)
            return
    if remove:
        pf.set_parent_pin('')
        xbmcgui.Dialog().notification('Starfleet', 'Parent PIN removed', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    new = _new_pin('New Parent PIN (4 digits or more)')
    if new:
        pf.set_parent_pin(new)
        xbmcgui.Dialog().notification('Starfleet', 'Parent PIN set', xbmcgui.NOTIFICATION_INFO, 3000)


def manage_flow(pick=None):
    """The Profiles menu: switch, create, edit, Parent PIN. Returns True when the active profile changed."""
    pick = pick or _pick_default
    switched = False
    while True:
        opts = ['Switch profile', 'Create a profile', 'Edit or delete a profile',
                'Parent PIN: %s' % ('set (change or remove)' if pf.has_parent_pin() else 'none (set one)')]
        c = pick('Profiles (now: %s)' % pf.active()['name'], opts)
        if not isinstance(c, int) or c < 0:
            return switched
        if c == 0:
            switched = switch_flow(pick) or switched
            if switched:
                return True
        elif c == 1:
            switched = create_flow(pick) or switched
            if switched:
                return True
        elif c == 2:
            edit_flow(pick)
        elif c == 3:
            if pf.has_parent_pin():
                a = pick('Parent PIN', ['Change the PIN', 'Remove the PIN'])
                if a == 0:
                    parent_pin_flow()
                elif a == 1:
                    parent_pin_flow(remove=True)
            else:
                parent_pin_flow()
