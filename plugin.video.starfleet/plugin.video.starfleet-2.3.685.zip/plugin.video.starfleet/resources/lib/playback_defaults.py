# -*- coding: utf-8 -*-
"""
resources/lib/playback_defaults.py

English audio first and subtitles off when a video starts (Settings > General), the way the HazMat TV player starts: when a stream offers
several audio languages the English one is selected (any other track can still be picked from Kodi's audio menu), and subtitles start off
until they are switched on from the subtitle menu. Nothing is touched when the stream has only one audio track or no English track.
"""
import threading
import xbmc
import xbmcaddon


def _on(setting):
    try:
        return xbmcaddon.Addon('plugin.video.starfleet').getSetting(setting) == 'true'
    except Exception:
        return False


class DefaultsPlayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)

    def onAVStarted(self):
        try:
            if not self.isPlayingVideo():
                return
            if _on('play_english_audio'):
                self._english()
            if _on('play_subs_off'):
                self.showSubtitles(False)
        except Exception as e:
            xbmc.log('[Starfleet/PlaybackDefaults] %s' % e, xbmc.LOGWARNING)

    def _english(self):
        langs = [str(x or '').lower() for x in self.getAvailableAudioStreams()]
        if len(langs) < 2:
            return
        isen = [i for i, x in enumerate(langs) if x.startswith('en') or x in ('eng', 'english')]
        if not isen:
            return
        cur = langs[0]
        try:
            info = xbmc.getInfoLabel('VideoPlayer.AudioLanguage').lower()
            cur = info or cur
        except Exception:
            pass
        if cur.startswith('en') or cur in ('eng', 'english'):
            return
        self.setAudioStream(isen[0])
