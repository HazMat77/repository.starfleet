# -*- coding: utf-8 -*-
"""
resources/lib/hue.py

Philips Hue, over the bridge's local API (plain HTTP on the home network; nothing goes through the internet except the optional bridge
lookup at discovery.meethue.com). Link once with the bridge's button, pick a room, then the lights of that room dim or turn off while a
video plays and come back exactly as they were when it pauses or ends. Lights that were off are left alone. Same behaviour as the HazMat TV
app's Hue setting. The service (service.py) runs HuePlayer, which follows Kodi's player events.

Settings (Settings > Hue Lights): hue_enabled, hue_mode (0 = dim, 1 = lights off), hue_level (brightness while dimmed, percent); the bridge
address, user name and room are kept in hue.json in the add-on's data folder.
"""
import json
import os
import threading
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import requests as _req

_ADDON_ID = 'plugin.video.starfleet'
_LOCK = threading.RLock()
_saved = None                      # light id -> its state as it was before dimming (only the lights that were on)
_pending = None                    # the timer that restores the lights a few seconds after playback stops


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/Hue] %s' % msg, level)


# ── settings ────────────────────────────────────────────────────────────────────────────────────────────────────────

def _addon():
    return xbmcaddon.Addon(_ADDON_ID)


def _path():
    d = xbmcvfs.translatePath('special://userdata/addon_data/%s/' % _ADDON_ID)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'hue.json')


def _cfg():
    try:
        with open(_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _set(**kw):
    d = _cfg()
    d.update(kw)
    try:
        with open(_path(), 'w', encoding='utf-8') as f:
            json.dump(d, f)
    except Exception as e:
        _log('could not save: %s' % e, xbmc.LOGWARNING)


def is_linked():
    c = _cfg()
    return bool(c.get('ip') and c.get('user'))


def enabled():
    try:
        return _addon().getSetting('hue_enabled') == 'true' and is_linked() and bool(_cfg().get('group'))
    except Exception:
        return False


def _mode_off():
    return _addon().getSetting('hue_mode') == '1'


def _level():
    try:
        return max(1, min(100, int(_addon().getSetting('hue_level') or 15)))
    except Exception:
        return 15


# ── bridge ──────────────────────────────────────────────────────────────────────────────────────────────────────────

def _base():
    c = _cfg()
    return 'http://%s/api/%s' % (c.get('ip', ''), c.get('user', ''))


def _get(url):
    try:
        r = _req.get(url, timeout=5)
        return r.json() if r.status_code == 200 else None
    except Exception:
        return None


def _put(url, body):
    try:
        _req.put(url, data=json.dumps(body), timeout=5)
    except Exception:
        pass


def discover():
    """The bridge addresses Philips knows for this network (empty when offline or none)."""
    try:
        r = _req.get('https://discovery.meethue.com', timeout=8)
        return [b['internalipaddress'] for b in r.json() if b.get('internalipaddress')]
    except Exception:
        return []


def link(ip):
    """(True, '') once linked; else (False, why). The bridge only accepts it within 30 seconds of its round button being pressed."""
    try:
        r = _req.post('http://%s/api' % ip, data=json.dumps({'devicetype': 'starfleet_kodi#kodi'}), timeout=6)
        first = r.json()[0]
        if 'success' in first:
            _set(ip=ip.strip(), user=first['success']['username'])
            return True, ''
        return False, first.get('error', {}).get('description', 'Not linked')
    except Exception as e:
        return False, 'No answer from %s (%s)' % (ip, e)


def groups():
    """[(id, name, [light ids])] for the rooms and zones of the bridge."""
    o = _get('%s/groups' % _base()) or {}
    out = []
    for gid, g in o.items():
        if g.get('type') in ('Room', 'Zone'):
            out.append((gid, g.get('name', gid), list(g.get('lights') or [])))
    return sorted(out, key=lambda x: x[1].lower())


# ── playback ────────────────────────────────────────────────────────────────────────────────────────────────────────

def _room_lights():
    gid = _cfg().get('group')
    for g, _name, lights in groups():
        if g == gid:
            return lights
    return []


def enter():
    """Dim or switch off the chosen room's lights that are on, remembering how they were."""
    global _saved
    with _LOCK:
        if not enabled() or _saved is not None:
            return
        before = {}
        for lid in _room_lights():
            st = (_get('%s/lights/%s' % (_base(), lid)) or {}).get('state') or {}
            if st.get('on') and st.get('reachable', True):
                before[lid] = st
        if not before:
            return
        _saved = before
        for lid in before:
            change = {'transitiontime': 20}
            if _mode_off():
                change['on'] = False
            else:
                change['bri'] = max(1, min(254, _level() * 254 // 100))
            _put('%s/lights/%s/state' % (_base(), lid), change)


def leave():
    """Put the lights back as they were (nothing happens when they were not touched)."""
    global _saved
    with _LOCK:
        before, _saved = _saved, None
        if not before:
            return
        for lid, st in before.items():
            back = {'on': True, 'transitiontime': 20, 'bri': st.get('bri', 254)}
            cm = st.get('colormode')
            if cm == 'ct' and 'ct' in st:
                back['ct'] = st['ct']
            elif cm == 'xy' and 'xy' in st:
                back['xy'] = st['xy']
            elif cm == 'hs':
                back['hue'], back['sat'] = st.get('hue', 0), st.get('sat', 0)
            _put('%s/lights/%s/state' % (_base(), lid), back)


def playing(on, immediate=False):
    """Playback started or stopped. Starting dims at once; stopping waits a few seconds first, so a stall or a channel change does not flash
    the lights up, and closing the player (immediate) restores them right away."""
    global _pending
    if not enabled() and _saved is None:
        return
    if _pending is not None:
        _pending.cancel()
        _pending = None

    def _go():
        try:
            enter() if on else leave()
        except Exception as e:
            _log('%s' % e, xbmc.LOGWARNING)

    if on or immediate:
        threading.Thread(target=_go, daemon=True, name='starfleet-hue').start()
    else:
        _pending = threading.Timer(6.0, _go)
        _pending.daemon = True
        _pending.start()


class HuePlayer(xbmc.Player):
    """Follows Kodi's player: video playing -> lights down; paused or stopped -> lights back."""

    def __init__(self):
        xbmc.Player.__init__(self)

    def _video(self):
        try:
            return self.isPlayingVideo()
        except Exception:
            return False

    def onAVStarted(self):
        if self._video():
            playing(True)

    def onPlayBackResumed(self):
        if self._video():
            playing(True)

    def onPlayBackPaused(self):
        playing(False)

    def onPlayBackStopped(self):
        playing(False, immediate=True)

    def onPlayBackEnded(self):
        playing(False)

    def onPlayBackError(self):
        playing(False, immediate=True)


# ── settings actions ────────────────────────────────────────────────────────────────────────────────────────────────

def setup():
    """Settings > Hue Lights > Link bridge: find (or type) the bridge address, press its button, then pick the room."""
    dlg = xbmcgui.Dialog()
    ips = discover()
    ip = ''
    if len(ips) == 1:
        ip = ips[0]
    elif ips:
        i = dlg.select('Hue bridge', ips)
        ip = ips[i] if i >= 0 else ''
    if not ip:
        ip = dlg.input('Hue bridge address (e.g. 192.168.1.20)', type=xbmcgui.INPUT_ALPHANUM).strip()
    if not ip:
        return
    dlg.ok('Hue', 'Press the round button on top of the bridge, then press OK within 30 seconds.')
    ok, why = False, ''
    for _ in range(12):
        ok, why = link(ip)
        if ok or 'link button' not in why.lower():
            break
        time.sleep(2)
    if not ok:
        dlg.notification('Starfleet', 'Hue: %s' % why, xbmcgui.NOTIFICATION_ERROR, 5000)
        return
    choose_room()


def choose_room():
    gs = groups()
    if not gs:
        xbmcgui.Dialog().notification('Starfleet', 'No rooms found on the bridge', xbmcgui.NOTIFICATION_ERROR, 4000)
        return
    i = xbmcgui.Dialog().select('Which room dims while a video plays?', [n for _g, n, _l in gs])
    if i < 0:
        return
    _set(group=gs[i][0], groupName=gs[i][1])
    _addon().setSetting('hue_room', gs[i][1])
    xbmcgui.Dialog().notification('Starfleet', 'Hue room: %s' % gs[i][1], xbmcgui.NOTIFICATION_INFO, 3000)


def test():
    dlg = xbmcgui.Dialog()
    if not is_linked():
        dlg.notification('Starfleet', 'Link a bridge first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    if not _cfg().get('group'):
        dlg.notification('Starfleet', 'Choose a room first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    enter()
    if _saved is None:
        dlg.notification('Starfleet', 'No light is on in %s, so nothing to dim' % _cfg().get('groupName', 'the room'), xbmcgui.NOTIFICATION_INFO, 4000)
        return
    xbmc.sleep(4000)
    leave()
    dlg.notification('Starfleet', 'Done - the lights are back as they were', xbmcgui.NOTIFICATION_INFO, 3000)


def unlink():
    leave()
    try:
        os.remove(_path())
    except OSError:
        pass
    try:
        _addon().setSetting('hue_room', '')
    except Exception:
        pass
