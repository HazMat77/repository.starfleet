﻿# -*- coding: utf-8 -*-
"""
resources/lib/adult_streams.py — Adult streaming scrapers

Sources:
  freeomovie.to      — WordPress blog. Film list on homepage/pages.
                       Stream URLs in var TABS = [...] in page <script>.
  xxxmoviestream.org — DooPlay WordPress theme. Films under /movies/.
                       Stream URLs in data-fl-url="..." attributes.
  pornwatch.ws       — DooPlay theme. Film cards use data-movie-id + oldtitle.
                       Stream URLs in data-fl-url="..." on detail pages.
  watchpornfree.info — TPostMv theme. Film cards in <li class="TPostMv">.
                       Stream URLs in data-fl-url="..." on detail pages.
  speedporn.net      — Slug-number URLs. Stream URLs in data-fl-url="...".

Each scraper returns a list of film dicts:
  { 'id', 'title', 'title_norm', 'thumb', 'description', 'url',
    'source', 'streams': [{'label', 'url'}] }

get_all_streams() merges all sources and deduplicates by normalised title.
Merged films carry streams from all matching sources.
"""

import re
import unicodedata
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

import requests
from resources.lib import cache as _cache
_cache.init(_CACHE_DB)

FREEO_BASE  = 'https://www.freeomovie.to'
XXXMS_BASE  = 'https://xxxmoviestream.org'
WPW_BASE    = 'https://pornwatch.ws'
WPF_BASE    = 'https://watchpornfree.info'
SPN_BASE    = 'https://speedporn.net'
XXXSC_BASE  = 'https://xxxscenes.net'
XMOVIX_BASE = 'https://hd.xmovix.net'
PANDA_BASE  = 'https://pandamovies.org'
HQPORN_BASE = 'https://hqporner.com'

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE  = re.compile(r'\s+')

# ── HTTP session ──────────────────────────────────────────────────────────────

_session = None
_cf_session = None

def _sess():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        a = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=10,
            max_retries=requests.adapters.Retry(total=0)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _cf_sess():
    """cfscrape session for Cloudflare-protected sites."""
    global _cf_session
    if _cf_session is None:
        try:
            import sys as _sys
            _sys.path.insert(0, r'C:\Users\danlo\AppData\Roaming\Kodi\addons\script.module.thecrew\lib\resources\lib\modules')
            import cfscrape
            _cf_session = cfscrape.create_scraper()
        except Exception as e:
            xbmc.log('[Starfleet/Streams] cfscrape unavailable: %s' % e, xbmc.LOGWARNING)
            _cf_session = _sess()
    return _cf_session


def _get(url, timeout=(5, 8)):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _clean(text):
    text = _RE_STRIP_TAGS.sub(' ', text)
    return _RE_WHITESPACE.sub(' ', text).strip()


def _og(html, prop):
    """Extract og: meta property value."""
    m = re.search(
        r'<meta[^>]+property=["\']og:%s["\'][^>]+content=["\']([^"\']+)["\']' % re.escape(prop),
        html, re.IGNORECASE
    )
    if not m:
        m = re.search(
            r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:%s["\']' % re.escape(prop),
            html, re.IGNORECASE
        )
    return _clean(m.group(1)) if m else ''


# ── Title normalisation for deduplication ─────────────────────────────────────

_RE_NONALNUM = re.compile(r'[^a-z0-9 ]')

def _norm_title(title):
    """Lowercase, strip accents and punctuation, collapse spaces."""
    title = title.lower()
    # Remove accents
    title = ''.join(
        c for c in unicodedata.normalize('NFD', title)
        if unicodedata.category(c) != 'Mn'
    )
    title = _RE_NONALNUM.sub('', title)
    return _RE_WHITESPACE.sub(' ', title).strip()


# ── freeomovie.to ──────────────────────────────────────────────────────────────

_RE_FREEO_LINKS = re.compile(
    r'href="(https?://(?:www\.)?freeomovie\.to/([a-z0-9][a-z0-9-]+)/)"',
    re.IGNORECASE
)
_FREEO_SKIP = {
    'page', 'category', 'tag', 'author', 'feed', 'wp-json',
    'contact-us', 'legal-notice', 'privacy-policy', 'about',
    'wp-content', 'wp-includes', 'sitemap',
}
_RE_FREEO_TABS = re.compile(r'var\s+TABS\s*=\s*(\[.*?\]);', re.DOTALL)
_RE_FREEO_TITLE = re.compile(
    r'<h1[^>]*>Watch\s+(.*?)\s+(?:free\s+online\s+porn|porn\s+movie|watch\s+online)',
    re.IGNORECASE
)


def _freeo_film_list(page=1):
    ck = 'fstreams_freeo_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = FREEO_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html = _get(url)
        films = []
        seen  = set()
        for m in _RE_FREEO_LINKS.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in _FREEO_SKIP or slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] freeomovie page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] freeomovie list error: %s' % e, xbmc.LOGERROR)
        return []


def _freeo_film_detail(slug, film_url):
    ck = 'fstreams_freeo_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(film_url)

        # Title: try <h1> first, then og:title
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            raw = _clean(m.group(1))
            # Strip "Watch X free online porn" prefix/suffix
            raw = re.sub(r'^Watch\s+', '', raw, flags=re.IGNORECASE)
            raw = re.sub(r'\s+(?:free\s+online\s+porn|porn\s+movie.*|online\s+free.*)$', '',
                         raw, flags=re.IGNORECASE)
            title = raw.strip()
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()

        thumb = _og(html, 'image')
        desc  = _og(html, 'description')

        # Stream URLs from var TABS = [...]
        streams = []
        m = _RE_FREEO_TABS.search(html)
        if m:
            import json
            try:
                tabs = json.loads(m.group(1))
                for tab in tabs:
                    if tab.get('url') and tab.get('label'):
                        streams.append({'label': tab['label'], 'url': tab['url']})
            except (ValueError, KeyError):
                pass

        film = {
            'id':         'freeo_%s' % slug,
            'slug':       slug,
            'title':      title or slug.replace('-', ' ').title(),
            'title_norm': _norm_title(title or slug.replace('-', ' ')),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'freeomovie',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] freeomovie detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_freeo_films(page=1):
    """Return list of film dicts from freeomovie.to, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _freeo_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(lambda s: _freeo_film_detail(s['slug'], s['url']), stubs))
    return [d for d in results if d]


# ── xxxmoviestream.org ────────────────────────────────────────────────────────

_RE_XXXMS_CARD = re.compile(
    r'href="(https?://xxxmoviestream\.org/movies/([a-z0-9][a-z0-9-]+)/)"\s*>\s*<img',
    re.IGNORECASE
)
_RE_XXXMS_STREAMS = re.compile(
    r'data-fl-url="(https?://[^"]+)"',
    re.IGNORECASE
)
# Filter out obviously non-player stream URLs
_XXXMS_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)',
    re.IGNORECASE
)


def _xxxms_film_list(page=1):
    ck = 'fstreams_xxxms_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = XXXMS_BASE + ('/movies/' if page == 1 else '/movies/page/%d/' % page)
    try:
        html = _get(url)
        films = []
        seen  = set()
        for m in _RE_XXXMS_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                films.append({'slug': slug, 'url': film_url})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] xxxmoviestream page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxmoviestream list error: %s' % e, xbmc.LOGERROR)
        return []


def _xxxms_film_detail(slug, film_url):
    ck = 'fstreams_xxxms_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html  = _get(film_url)

        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()

        thumb = _og(html, 'image')
        desc  = _og(html, 'description')

        # Stream URLs from data-fl-url="..." attributes
        seen_urls = set()
        streams   = []
        for m in _RE_XXXMS_STREAMS.finditer(html):
            stream_url = m.group(1)
            # Skip file hosters and duplicate/dynamic placeholder lines
            if _XXXMS_STREAM_SKIP.search(stream_url):
                continue
            if 'deadUrl' in stream_url:
                continue
            if stream_url in seen_urls:
                continue
            seen_urls.add(stream_url)
            # Derive a label from the domain
            domain = re.search(r'https?://(?:www\.)?([^./]+)', stream_url)
            label = domain.group(1).capitalize() if domain else 'Stream'
            streams.append({'label': label, 'url': stream_url})

        film = {
            'id':         'xxxms_%s' % slug,
            'slug':       slug,
            'title':      title or slug.replace('-', ' ').title(),
            'title_norm': _norm_title(title or slug.replace('-', ' ')),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'xxxmoviestream',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxmoviestream detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_xxxms_films(page=1):
    """Return list of film dicts from xxxmoviestream.org, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _xxxms_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(lambda s: _xxxms_film_detail(s['slug'], s['url']), stubs))
    return [d for d in results if d]


# ── pornwatch.ws ──────────────────────────────────────────────────────────────
# DooPlay theme: film cards use data-movie-id="N" + oldtitle="TITLE" + <img src>
# Detail pages use data-fl-url="..." for stream URLs.

_RE_WPW_CARD = re.compile(
    r'data-movie-id="\d+"[^>]*>.*?'
    r'href="(https?://pornwatch\.ws/([a-z0-9][a-z0-9-]+)/)"[^>]*'
    r'oldtitle="([^"]+)"[^>]*>.*?'
    r'<img[^>]+src="([^"]+)"',
    re.IGNORECASE | re.DOTALL
)
_RE_WPW_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_WPW_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _wpw_film_list(page=1):
    ck = 'fstreams_wpw_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = WPW_BASE + ('/movies-2/' if page == 1 else '/movies-2/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_WPW_CARD.finditer(html):
            film_url, slug, title, thumb = m.group(1), m.group(2), m.group(3), m.group(4)
            if slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url, 'title': title, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] pornwatch page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] pornwatch list error: %s' % e, xbmc.LOGERROR)
        return []


def _wpw_film_detail(slug, film_url, title='', thumb=''):
    ck = 'fstreams_wpw_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        for m in _RE_WPW_STREAMS.finditer(html):
            su = m.group(1)
            if _WPW_STREAM_SKIP.search(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'wpw_%s' % slug,
            'slug':       slug,
            'title':      title,
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'pornwatch',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] pornwatch detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_wpw_films(page=1):
    """Return list of film dicts from pornwatch.ws, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _wpw_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(
            lambda s: _wpw_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')), stubs))
    return [d for d in results if d]


# ── watchpornfree.info ────────────────────────────────────────────────────────
# TPostMv theme: film cards in <li class="TPostMv"> with href and img alt.
# Detail pages use data-fl-url="..." for stream URLs.

_RE_WPF_CARD = re.compile(
    r'<li[^>]+class="TPostMv"[^>]*>.*?'
    r'<a[^>]+href="(https?://watchpornfree\.info/([a-z0-9][a-z0-9-]+)[^"]*)"[^>]*>.*?'
    r'<img[^>]+src="([^"]+)"[^>]+alt="([^"]*)"',
    re.IGNORECASE | re.DOTALL
)
_RE_WPF_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_WPF_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _wpf_film_list(page=1):
    ck = 'fstreams_wpf_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = WPF_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_WPF_CARD.finditer(html):
            film_url, slug, thumb, alt = m.group(1), m.group(2), m.group(3), m.group(4)
            if slug in seen:
                continue
            seen.add(slug)
            # alt is "Watch TITLE Porn Online Free" — strip prefix/suffix
            title = re.sub(r'^Watch\s+', '', alt, flags=re.IGNORECASE)
            title = re.sub(r'\s+(?:Porn|Online|Free|Watch).*$', '', title, flags=re.IGNORECASE).strip()
            if not title:
                title = slug.replace('-', ' ').title()
            films.append({'slug': slug, 'url': film_url, 'title': title, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] watchpornfree page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] watchpornfree list error: %s' % e, xbmc.LOGERROR)
        return []


def _wpf_film_detail(slug, film_url, title='', thumb=''):
    ck = 'fstreams_wpf_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
            title = re.sub(r'^Watch\s+', '', title, flags=re.IGNORECASE)
            title = re.sub(r'\s+(?:Porn|Online|Free).*$', '', title, flags=re.IGNORECASE).strip()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        for m in _RE_WPF_STREAMS.finditer(html):
            su = m.group(1)
            if _WPF_STREAM_SKIP.search(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'wpf_%s' % slug,
            'slug':       slug,
            'title':      title,
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'watchpornfree',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] watchpornfree detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_wpf_films(page=1):
    """Return list of film dicts from watchpornfree.info, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _wpf_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(
            lambda s: _wpf_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')), stubs))
    return [d for d in results if d]


# ── speedporn.net ─────────────────────────────────────────────────────────────
# Slug-number URLs: /slug-N/ pattern on homepage.
# Detail pages use data-fl-url="..." for stream URLs.

_RE_SPN_CARD = re.compile(
    r'href="(https?://speedporn\.net/([a-z0-9][a-z0-9-]+-\d+)/)"',
    re.IGNORECASE
)
_RE_SPN_IMG = re.compile(r'<img[^>]+src="([^"]+)"', re.IGNORECASE)
_RE_SPN_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_SPN_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _spn_film_list(page=1):
    ck = 'fstreams_spn_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = SPN_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_SPN_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in seen:
                continue
            seen.add(slug)
            # Thumbnail: look for img in the vicinity (next 300 chars)
            idx   = m.end()
            chunk = html[idx:idx + 300]
            im    = _RE_SPN_IMG.search(chunk)
            thumb = im.group(1) if im else ''
            films.append({'slug': slug, 'url': film_url, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] speedporn page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] speedporn list error: %s' % e, xbmc.LOGERROR)
        return []


def _spn_film_detail(slug, film_url, thumb=''):
    ck = 'fstreams_spn_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()
        if not title:
            # Derive from slug: strip trailing -number
            title = re.sub(r'-\d+$', '', slug).replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        for m in _RE_SPN_STREAMS.finditer(html):
            su = m.group(1)
            if _SPN_STREAM_SKIP.search(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'spn_%s' % slug,
            'slug':       slug,
            'title':      title,
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'speedporn',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] speedporn detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_spn_films(page=1):
    """Return list of film dicts from speedporn.net, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _spn_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(
            lambda s: _spn_film_detail(s['slug'], s['url'], s.get('thumb', '')), stubs))
    return [d for d in results if d]


# ── xxxscenes.net ─────────────────────────────────────────────────────────────
# WordPress-based scene/video aggregator. Cards use href slug pattern.
# Stream URLs in data-fl-url="..." or iframe src on detail pages.

_RE_XXXSC_CARD = re.compile(
    r'href="(https?://xxxscenes\.net/([a-z0-9][a-z0-9-]+)/)"[^>]*>\s*<img',
    re.IGNORECASE
)
_RE_XXXSC_IMG = re.compile(
    r'<img[^>]+(?:data-src|src)="(https?://[^"]+(?:\.jpg|\.jpeg|\.png|\.webp)[^"]*)"',
    re.IGNORECASE
)
_RE_XXXSC_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_XXXSC_SKIP_SLUGS = {
    'page', 'category', 'tag', 'author', 'feed', 'wp-json',
    'contact-us', 'privacy-policy', 'about', 'sitemap',
}
_XXXSC_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _xxxsc_film_list(page=1):
    ck = 'fstreams_xxxsc_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = XXXSC_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_XXXSC_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in _XXXSC_SKIP_SLUGS or slug in seen:
                continue
            seen.add(slug)
            # thumbnail: scan the next 400 chars after the card anchor
            chunk = html[m.start():m.start() + 600]
            im    = _RE_XXXSC_IMG.search(chunk)
            thumb = im.group(1) if im else ''
            films.append({'slug': slug, 'url': film_url, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] xxxscenes page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxscenes list error: %s' % e, xbmc.LOGERROR)
        return []


def _xxxsc_film_detail(slug, film_url, thumb=''):
    ck = 'fstreams_xxxsc_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html  = _get(film_url)

        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()
        if not title:
            title = slug.replace('-', ' ').title()

        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')

        seen_urls = set()
        streams   = []
        for m in _RE_XXXSC_STREAMS.finditer(html):
            su = m.group(1)
            if _XXXSC_STREAM_SKIP.search(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            label = dom.group(1).capitalize() if dom else 'Stream'
            streams.append({'label': label, 'url': su})

        # Also pick up iframe embeds
        for m in re.finditer(r'<iframe[^>]+src="(https?://[^"]+)"', html, re.IGNORECASE):
            su = m.group(1)
            if su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            label = dom.group(1).capitalize() if dom else 'Embed'
            streams.append({'label': label, 'url': su})

        film = {
            'id':          'xxxsc_%s' % slug,
            'slug':        slug,
            'title':       title,
            'title_norm':  _norm_title(title),
            'thumb':       thumb,
            'description': desc,
            'url':         film_url,
            'source':      'xxxscenes',
            'streams':     streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxscenes detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_xxxsc_films(page=1):
    """Return list of film dicts from xxxscenes.net, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _xxxsc_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(
            lambda s: _xxxsc_film_detail(s['slug'], s['url'], s.get('thumb', '')), stubs))
    return [d for d in results if d]


def _search_xxxsc_films(title):
    """Search xxxscenes.net via /?s=title and return matched film dicts."""
    from urllib.parse import quote as _quote
    try:
        html = _get(XXXSC_BASE + '/?s=' + _quote(title))
        stubs, seen = [], set()
        for m in _RE_XXXSC_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in _XXXSC_SKIP_SLUGS and slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url, 'thumb': ''})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxsc search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _xxxsc_film_detail(s['slug'], s['url'], s.get('thumb', '')))


# ── Fast stub catalogue (list pages only, no detail fetches) ─────────────────

# ── xmovix.net scraper ───────────────────────────────────────────────────────

def _xmovix_depack(html_code):
    """Deobfuscate Dean Edwards P,A,C,K,E,D JS to extract stream URLs."""
    m = re.search(
        r"eval\(function\(p,a,c,k,e,d\)\{.*?\}\('(.*?)',(\d+),(\d+),'(.*?)'\.split\('\|'\)\)\)",
        html_code, re.DOTALL
    )
    if not m:
        return ''
    p_str, a_str, _, k_str = m.groups()
    a, k = int(a_str), k_str.split('|')
    def replace(mw):
        w = mw.group(0)
        try:
            n = 0
            for ch in w:
                n = n * a + (int(ch) if ch.isdigit() else ord(ch) - 87)
            return k[n] if n < len(k) and k[n] else w
        except Exception:
            return w
    return re.sub(r'[0-9a-z]+', replace, p_str)


def _xmovix_film_list(page=1):
    ck = 'fstreams_xmovix_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        url = XMOVIX_BASE + ('/' if page == 1 else '/page/%d/' % page)
        html = _cf_sess().get(url, timeout=12).text
        films = []
        for film_url, img in re.findall(
            r'href="(https://hd\.xmovix\.net/movies/[^"]+\.html)"[^>]*>\s*<img\s+data-src="([^"]+)"',
            html
        ):
            slug_m = re.search(r'/(\d+[^/]+)\.html', film_url)
            slug = slug_m.group(1) if slug_m else re.sub(r'[^a-z0-9]+', '-', film_url.lower())
            img_slug = re.search(r'/thumbs/([^.]+)\.', img)
            eng_title = img_slug.group(1).replace('-', ' ').title() if img_slug else slug
            films.append({'slug': slug, 'url': film_url, 'thumb': img, 'title': eng_title})
        _cache.set(ck, films, 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xmovix list error (page %d): %s' % (page, e), xbmc.LOGWARNING)
        return []


def _xmovix_film_detail(slug, film_url, thumb='', title_hint=''):
    ck = 'fstreams_xmovix_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _cf_sess().get(film_url, timeout=12).text
        embed_urls = re.findall(r's2\.src\s*=\s*["\' ](https://filmcdm\.top/[^"\' ]+)["\' ]', html)
        if not embed_urls:
            return None
        embed_html = _cf_sess().get(embed_urls[0], timeout=12).text
        title_m = re.search(r'<title>([^<]+)</title>', embed_html)
        title = title_m.group(1).strip() if title_m else title_hint
        title = re.sub(r'\s*\(\d{3,4}p?\)\s*$', '', title).strip() or title_hint
        unpacked = _xmovix_depack(embed_html)
        m3u8_urls = re.findall(r'https://[^"\' ]+\.m3u8[^"\' ]*', unpacked)
        if not m3u8_urls:
            return None
        film = {
            'id': 'xmovix_%s' % slug, 'slug': slug,
            'title': title, 'title_norm': _norm_title(title),
            'thumb': thumb, 'description': '', 'url': film_url,
            'source': 'xmovix',
            'streams': [{'label': 'xmovix HLS', 'url': m3u8_urls[0]}],
        }
        _cache.set(ck, film, 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xmovix detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_xmovix_films(title):
    """Search hd.xmovix.net via /?s=title using cfscrape and return matched film dicts."""
    from urllib.parse import quote as _quote
    try:
        html = _cf_sess().get(XMOVIX_BASE + '/?s=' + _quote(title), timeout=12).text
        stubs, seen = [], set()
        for film_url, img in re.findall(
            r'href="(https://hd\.xmovix\.net/movies/[^"]+\.html)"[^>]*>\s*<img\s+(?:data-src|src)="([^"]+)"',
            html
        ):
            slug_m = re.search(r'/(\d+[^/]+)\.html', film_url)
            slug = slug_m.group(1) if slug_m else re.sub(r'[^a-z0-9]+', '-', film_url.lower())
            if slug in seen:
                continue
            seen.add(slug)
            img_slug = re.search(r'/thumbs/([^.]+)\.', img)
            title_hint = img_slug.group(1).replace('-', ' ').title() if img_slug else slug
            stubs.append({'slug': slug, 'url': film_url, 'thumb': img, 'title': title_hint})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xmovix search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _xmovix_film_detail(s['slug'], s['url'], s.get('thumb', ''), s.get('title', '')))


def get_all_stream_stubs(page=1):
    """
    Return a deduplicated list of film stubs using ONLY list page data.
    No detail page fetches — title+thumb from the list page, no stream URLs.
    Detail is fetched on demand when the user clicks a film.
    Sources processed in fixed order so newest films appear first.
    """
    from concurrent.futures import ThreadPoolExecutor

    def _freeo_stubs(pg):
        items = _freeo_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = slug.replace('-', ' ').title()
            result.append({
                'id': 'freeo_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': '', 'description': '', 'url': s['url'],
                'source': 'freeomovie', 'streams': [],
            })
        return result

    def _xxxms_stubs(pg):
        items = _xxxms_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = slug.replace('-', ' ').title()
            result.append({
                'id': 'xxxms_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': '', 'description': '', 'url': s['url'],
                'source': 'xxxmoviestream', 'streams': [],
            })
        return result

    def _wpw_stubs(pg):
        items = _wpw_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = s.get('title') or slug.replace('-', ' ').title()
            result.append({
                'id': 'wpw_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'pornwatch', 'streams': [],
            })
        return result

    def _wpf_stubs(pg):
        items = _wpf_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = s.get('title') or slug.replace('-', ' ').title()
            result.append({
                'id': 'wpf_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'watchpornfree', 'streams': [],
            })
        return result

    def _spn_stubs(pg):
        items = _spn_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = re.sub(r'-\d+$', '', slug).replace('-', ' ').title()
            result.append({
                'id': 'spn_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'speedporn', 'streams': [],
            })
        return result

    def _xxxsc_stubs(pg):
        items = _xxxsc_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = slug.replace('-', ' ').title()
            result.append({
                'id': 'xxxsc_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'xxxscenes', 'streams': [],
            })
        return result

    def _xmovix_stubs(pg):
        items = _xmovix_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = s.get('title') or slug.replace('-', ' ').title()
            result.append({
                'id': 'xmovix_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'xmovix', 'streams': [],
            })
        return result

    stub_fns = [_freeo_stubs, _xxxms_stubs, _wpw_stubs, _wpf_stubs, _spn_stubs, _xxxsc_stubs, _xmovix_stubs]

    # Submit all in parallel but collect in fixed order (newest-first per source)
    with ThreadPoolExecutor(max_workers=len(stub_fns)) as pool:
        futures = [pool.submit(fn, page) for fn in stub_fns]
        source_results = []
        for fn, future in zip(stub_fns, futures):
            try:
                source_results.append(future.result(timeout=12))
            except Exception as e:
                xbmc.log('[Starfleet/Streams] stub error (%s): %s' % (fn.__name__, e), xbmc.LOGWARNING)
                source_results.append([])

    # Merge sources in order: if the same film appears in multiple sources, keep first occurrence
    # but enrich thumb from later sources. This preserves newest-first ordering.
    by_norm = {}
    for source_films in source_results:
        for film in source_films:
            nt = film['title_norm']
            if not nt:
                continue
            if nt not in by_norm:
                by_norm[nt] = dict(film)
            else:
                if not by_norm[nt].get('thumb') and film.get('thumb'):
                    by_norm[nt]['thumb'] = film['thumb']

    return list(by_norm.values())


def fetch_film_detail_on_demand(film_id, film_url=''):
    """
    Fetch a single film's detail page on demand (when not in cache).
    film_id format: 'freeo_slug', 'xxxms_slug', 'wpw_slug', 'wpf_slug', 'spn_slug'.
    film_url is optional; derived from film_id+slug if not provided.
    Returns a film dict with streams, or None on failure.
    """
    if film_id.startswith('freeo_'):
        slug = film_id[6:]
        url = film_url or (FREEO_BASE + '/' + slug + '/')
        return _freeo_film_detail(slug, url)
    elif film_id.startswith('xxxms_'):
        slug = film_id[6:]
        url = film_url or (XXXMS_BASE + '/movies/' + slug + '/')
        return _xxxms_film_detail(slug, url)
    elif film_id.startswith('wpw_'):
        slug = film_id[4:]
        url = film_url or (WPW_BASE + '/' + slug + '/')
        return _wpw_film_detail(slug, url)
    elif film_id.startswith('wpf_'):
        slug = film_id[4:]
        url = film_url or (WPF_BASE + '/' + slug + '/')
        return _wpf_film_detail(slug, url)
    elif film_id.startswith('spn_'):
        slug = film_id[4:]
        url = film_url or (SPN_BASE + '/' + slug + '/')
        return _spn_film_detail(slug, url)
    elif film_id.startswith('xxxsc_'):
        slug = film_id[6:]
        url = film_url or (XXXSC_BASE + '/' + slug + '/')
        return _xxxsc_film_detail(slug, url)
    elif film_id.startswith('xmovix_'):
        slug = film_id[7:]
        url = film_url or (XMOVIX_BASE + '/movies/hd-1080p/' + slug + '.html')
        return _xmovix_film_detail(slug, url)
    return None


# ── Merged + deduplicated stream catalogue ────────────────────────────────────

def get_all_streams(page=1):
    """
    Return a merged, deduplicated list of films from all 5 sources.
    Films with the same normalised title are merged into one entry with
    streams combined from every matching source.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    sources = [
        get_freeo_films,
        get_xxxms_films,
        get_wpw_films,
        get_wpf_films,
        get_spn_films,
        get_xxxsc_films,
    ]

    all_films = []
    with ThreadPoolExecutor(max_workers=len(sources)) as pool:
        futures = {pool.submit(fn, page): fn.__name__ for fn in sources}
        try:
            for future in as_completed(futures, timeout=25):
                name = futures[future]
                try:
                    results = future.result()
                    all_films.extend(results)
                    xbmc.log('[Starfleet/Streams] %s: %d films on page %d' % (name, len(results), page), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log('[Starfleet/Streams] source error (%s): %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            # One source timed out — use what we have rather than crashing
            xbmc.log('[Starfleet/Streams] get_all_streams partial timeout: %s' % e, xbmc.LOGWARNING)

    # Deduplicate by normalised title — merge streams from duplicates
    by_norm = {}
    for film in all_films:
        nt = film['title_norm']
        if not nt:
            continue
        if nt not in by_norm:
            by_norm[nt] = dict(film)
            by_norm[nt]['streams'] = list(film['streams'])
        else:
            seen_urls = {s['url'] for s in by_norm[nt]['streams']}
            for s in film['streams']:
                if s['url'] not in seen_urls:
                    by_norm[nt]['streams'].append(s)
                    seen_urls.add(s['url'])
            # Prefer richer metadata (longer description, non-empty thumb)
            if not by_norm[nt].get('thumb') and film.get('thumb'):
                by_norm[nt]['thumb'] = film['thumb']
            if len(film.get('description', '')) > len(by_norm[nt].get('description', '')):
                by_norm[nt]['description'] = film['description']

    merged_list = list(by_norm.values())

    # Cache each merged film under its own id so adult_stream_sources can retrieve it
    for film in merged_list:
        film_id = film.get('id', '')
        if film_id:
            _cache.set('fstreams_merged_%s' % film_id, film, 24 * 3600)

    return merged_list


# ── Title-based stream search (AFDB → scrapers pipeline) ─────────────────────

def _title_matches(norm_query, norm_film):
    """True if the normalised AFDB title matches a scraper film title closely enough."""
    if not norm_query or not norm_film:
        return False
    if norm_query == norm_film:
        return True
    q_words = norm_query.split()
    f_words = norm_film.split()
    # All query words present in film title
    if len(q_words) >= 2 and all(w in norm_film for w in q_words):
        return True
    # Film title fully contained in query — require at least 3 film words OR
    # film covers >= 60% of query word count to avoid 2-word matches on long titles
    if len(f_words) >= 3 and all(w in norm_query for w in f_words):
        return True
    if len(f_words) >= 2 and all(w in norm_query for w in f_words):
        coverage = len(f_words) / max(len(q_words), 1)
        if coverage >= 0.6:
            return True
    return False


def _pfetch(stubs, fn, limit=5):
    """Fetch up to limit stubs concurrently."""
    from concurrent.futures import ThreadPoolExecutor
    batch = stubs[:limit]
    if not batch:
        return []
    with ThreadPoolExecutor(max_workers=min(len(batch), 5)) as p:
        results = list(p.map(fn, batch))
    return [d for d in results if d]


def _search_freeo_films(title):
    """Search freeomovie.to via /?s=title and return matched film dicts."""
    from urllib.parse import quote as _quote
    try:
        html = _get(FREEO_BASE + '/?s=' + _quote(title))
        stubs, seen = [], set()
        for m in _RE_FREEO_LINKS.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in _FREEO_SKIP and slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] freeo search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _freeo_film_detail(s['slug'], s['url']))


def _search_xxxms_films(title):
    """Search xxxmoviestream.org via /?s=title and return matched film dicts."""
    from urllib.parse import quote as _quote
    try:
        html = _get(XXXMS_BASE + '/?s=' + _quote(title))
        stubs, seen = [], set()
        for m in _RE_XXXMS_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxms search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _xxxms_film_detail(s['slug'], s['url']))


def _search_wpw_films(title):
    """Search pornwatch.ws via /?s=title and return matched film dicts."""
    from urllib.parse import quote as _quote
    _wpw_re = re.compile(r'href="(https?://pornwatch\.ws/([a-z0-9][a-z0-9-]+)/)"', re.IGNORECASE)
    try:
        html = _get(WPW_BASE + '/?s=' + _quote(title))
        stubs, seen = [], set()
        for m in _wpw_re.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] wpw search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _wpw_film_detail(s['slug'], s['url'], '', ''))


def _search_wpf_films(title):
    """Search watchpornfree.info via /?s=title and return matched film dicts."""
    from urllib.parse import quote as _quote
    try:
        html = _get(WPF_BASE + '/?s=' + _quote(title))
        stubs, seen = [], set()
        for m in _RE_WPF_CARD.finditer(html):
            film_url, slug, thumb, alt = m.group(1), m.group(2), m.group(3), m.group(4)
            if slug not in seen:
                seen.add(slug)
                t = re.sub(r'^Watch\s+', '', alt, flags=re.IGNORECASE)
                t = re.sub(r'\s+(?:Porn|Online|Free|Watch).*$', '', t, flags=re.IGNORECASE).strip()
                stubs.append({'slug': slug, 'url': film_url, 'title': t or slug.replace('-', ' ').title(), 'thumb': thumb})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] wpf search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _wpf_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')))


def _search_spn_films(title):
    """Search speedporn.net via /?s=title and return matched film dicts."""
    from urllib.parse import quote as _quote
    try:
        html = _get(SPN_BASE + '/?s=' + _quote(title))
        stubs, seen = [], set()
        for m in _RE_SPN_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] spn search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _spn_film_detail(s['slug'], s['url'], ''))


# ── pandamovies.org ────────────────────────────────────────────────────────────

# Panda list page: anchor with title= attribute inside ml-item cards
_RE_PANDA_CARD = re.compile(
    r'href="(https?://pandamovies\.org/(watch-[a-z0-9][a-z0-9-]+-(?:movie|scene|online)-[a-z-]*))"[^>]*title="([^"]+)"',
    re.IGNORECASE
)
# Panda detail page: stream tabs loaded by ddajaxtabs — <a href="EMBED_URL"> preceded by img or "Server"
_RE_PANDA_STREAM = re.compile(
    r'<a[^>]+href="(https?://(?!pandamovies)[^"]+)"[^>]*>\s*(?:<img[^>]*>|\s*(?:Server|Play|S)\s*\d)',
    re.IGNORECASE
)


def _panda_genres():
    """Return list of (name, url) tuples from pandamovies.org. Cached 24h.
    Pandamovies uses year/category sub-paths; we expose their top-level sections
    (homepage, xxxscenes, most-viewed, and recent years) as browsable genres.
    """
    ck = 'panda_genres'
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    try:
        html = _get(PANDA_BASE + '/')
        genres = []
        seen = set()
        # Try to find navigation genre/category links
        for m in re.finditer(
            r'href="(https?://pandamovies\.org/(?:genre|category|tag)/([^/"]+)/?)"[^>]*>([^<]+)<',
            html, re.IGNORECASE
        ):
            url, slug, name = m.group(1), m.group(2), m.group(3).strip()
            if url not in seen and name and len(name) > 1:
                seen.add(url)
                genres.append({'name': name.title(), 'url': url})
        # Also expose known top-level sections
        for path, name in [('/', 'All Movies'), ('/xxxscenes/', 'Scenes'), ('/most-viewed', 'Most Viewed')]:
            url = PANDA_BASE + path
            if url not in seen:
                seen.add(url)
                genres.insert(0 if name == 'All Movies' else len(genres),
                              {'name': name, 'url': url})
        # Add year pages found in navigation
        for m in re.finditer(
            r'href="(https?://pandamovies\.org/release-year/(\d{4})/?)"',
            html, re.IGNORECASE
        ):
            url, year = m.group(1), m.group(2)
            if url not in seen:
                seen.add(url)
                genres.append({'name': year, 'url': url})
        _cache.set(ck, genres or [], 24 * 3600)
        return genres
    except Exception as e:
        xbmc.log('[Starfleet/Panda] genres error: %s' % e, xbmc.LOGWARNING)
        return []


def _panda_movies_for_genre(genre_url, page=1):
    """Return list of film stubs for a pandamovies.org genre page. Cached 4h."""
    ck = 'panda_genre_%s_%d' % (re.sub(r'[^a-z0-9]', '_', genre_url.lower())[-40:], page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = genre_url
    if page > 1:
        url = url.rstrip('/') + '/page/%d' % page
    try:
        html = _get(url)
        films = []
        seen = set()
        for m in _RE_PANDA_CARD.finditer(html):
            film_url, slug, title = m.group(1), m.group(2).strip('/'), m.group(3)
            if slug and slug not in seen:
                seen.add(slug)
                thumb = ''
                reg = html[max(0, m.start()-200):m.end()+500]
                ti = re.search(r'<img[^>]+(?:data-lazy-src|src)="([^"]+)"', reg, re.IGNORECASE)
                if ti:
                    thumb = ti.group(1)
                films.append({'slug': slug, 'url': film_url, 'title': title,
                              'title_norm': _norm_title(title), 'thumb': thumb,
                              'source': 'pandamovies', 'streams': []})
        _cache.set(ck, films, 4 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Panda] genre list error: %s' % e, xbmc.LOGWARNING)
        return []


def _panda_film_detail(slug, url):
    """Fetch pandamovies.org detail page, extract DoodStream/MixDrop/StreamTape links."""
    ck = 'panda_detail_%s' % re.sub(r'[^a-z0-9]', '_', slug)[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html = _get(url)
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)<', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        thumb = ''
        mi = re.search(r'property="og:image"[^>]+content="([^"]+)"', html, re.IGNORECASE)
        if mi:
            thumb = mi.group(1)
        _PANDA_SKIP = re.compile(
            r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share|localnews|fallback)', re.I)
        streams = []
        seen_s = set()
        for sm in _RE_PANDA_STREAM.finditer(html):
            stream_url = sm.group(1)
            if not stream_url or stream_url in seen_s:
                continue
            if _PANDA_SKIP.search(stream_url):
                continue
            seen_s.add(stream_url)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', stream_url)
            label = '[Panda] %s' % (dom.group(1).capitalize() if dom else 'Server')
            streams.append({'label': label, 'url': stream_url})
        film = {
            'id':         'panda_' + slug,
            'slug':       slug,
            'title':      title or slug.replace('-', ' ').title(),
            'title_norm': _norm_title(title or slug),
            'thumb':      thumb,
            'description': '',
            'url':        url,
            'source':     'pandamovies',
            'streams':    streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Panda] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_panda_films(title):
    """Search pandamovies.org and return matched film dicts with streams."""
    from urllib.parse import quote as _quote
    try:
        html = _get(PANDA_BASE + '/?s=' + _quote(title))
        stubs, seen = [], set()
        for m in _RE_PANDA_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2).strip('/')
            if slug and slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Panda] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _panda_film_detail(s['slug'], s['url']))


# ── hqporner.com ───────────────────────────────────────────────────────────────

def _hqporner_categories():
    """Return list of (name, url) tuples from hqporner.com categories. Cached 24h."""
    ck = 'hqporner_cats'
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    try:
        html = _get(HQPORN_BASE + '/categories')
        cats = []
        seen = set()
        for m in re.finditer(
            r'class="click-trigger"[^>]+href="(/category/[^"]+)"[^>]*>([^<]+)<',
            html, re.IGNORECASE
        ):
            path, name = m.group(1), m.group(2).strip().title()
            url = HQPORN_BASE + path
            if url not in seen:
                seen.add(url)
                cats.append({'name': name, 'url': url})
        # Also try reverse attr order
        for m in re.finditer(
            r'href="(/category/[^"]+)"[^>]*class="click-trigger"[^>]*>([^<]+)<',
            html, re.IGNORECASE
        ):
            path, name = m.group(1), m.group(2).strip().title()
            url = HQPORN_BASE + path
            if url not in seen:
                seen.add(url)
                cats.append({'name': name, 'url': url})
        _cache.set(ck, cats, 24 * 3600)
        return cats
    except Exception as e:
        xbmc.log('[Starfleet/HQP] categories error: %s' % e, xbmc.LOGWARNING)
        return []


def _hqporner_movies(category_url, page=1):
    """Return film stubs for an hqporner.com category page. Cached 4h."""
    ck = 'hqporner_cat_%s_%d' % (re.sub(r'[^a-z0-9]', '_', category_url)[-40:], page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = category_url
    if page > 1:
        url = url.rstrip('/') + '/page/%d' % page
    try:
        html = _get(url)
        films = []
        seen = set()
        for m in re.finditer(
            r'href="(/hdporn/([^"]+\.html))"[^>]*class="[^"]*click-trigger[^"]*"',
            html, re.IGNORECASE
        ):
            path = m.group(1)
            slug = path.strip('/').split('/')[-1]
            film_url = HQPORN_BASE + path
            if slug and slug not in seen:
                seen.add(slug)
                # grab thumbnail from surrounding context
                reg = html[max(0, m.start()-600):m.end()+200]
                ti = re.search(r'<img[^>]+src="(https?://[^"]+(?:bigcdn|hqporner)[^"]+)"', reg, re.IGNORECASE)
                thumb = ti.group(1) if ti else ''
                title_m = re.search(r'(?:title|alt)="([^"]+)"', reg, re.IGNORECASE)
                title = title_m.group(1).strip().title() if title_m else slug.replace('-', ' ').title()
                films.append({'slug': slug, 'url': film_url, 'title': title,
                              'title_norm': _norm_title(title), 'thumb': thumb,
                              'source': 'hqporner', 'streams': []})
        _cache.set(ck, films, 4 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/HQP] movies error: %s' % e, xbmc.LOGWARNING)
        return []


def _hqporner_film_detail(slug, url):
    """Fetch hqporner.com detail page and extract direct MP4 video URL."""
    ck = 'hqporner_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)<', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        thumb = ''
        mi = re.search(r'property="og:image"[^>]+content="([^"]+)"', html, re.IGNORECASE)
        if not mi:
            mi = re.search(r'content="([^"]+)"[^>]+property="og:image"', html, re.IGNORECASE)
        if mi:
            thumb = mi.group(1)

        streams = []
        # HQPorner embeds via mydaddy.cc player which has bigcdn.cc MP4s in its JS
        mydaddy = re.findall(r'//mydaddy\.cc/video/[a-f0-9]+/', html, re.IGNORECASE)
        for ifr_path in mydaddy[:1]:
            ifr_url = 'https:' + ifr_path
            try:
                ifr_html = _sess().get(ifr_url, headers={'Referer': HQPORN_BASE + '/'}, timeout=(5, 8)).text
                # Extract highest quality bigcdn.cc MP4 URL from escaped JS
                # e.g.: src=\"//s84.bigcdn.cc/pubs/.../1080.mp4\"
                best = None
                for src_m in re.finditer(
                    r'src=\\["\'](//[a-z0-9]+\.bigcdn\.cc/pubs/[^"\'\\]+\.mp4)[\\"\']',
                    ifr_html, re.IGNORECASE
                ):
                    candidate = src_m.group(1)
                    if best is None:
                        best = candidate
                    elif '1080' in candidate:
                        best = candidate
                    elif '720' in candidate and '1080' not in best:
                        best = candidate
                if best:
                    best_url = ('https:' + best) if best.startswith('//') else best
                    streams.append({'label': '[HQPorner] MP4', 'url': best_url})
            except Exception:
                pass

        film = {
            'id':         'hqp_' + slug,
            'slug':       slug,
            'title':      title or slug.replace('-', ' ').title(),
            'title_norm': _norm_title(title or slug),
            'thumb':      thumb,
            'description': '',
            'url':        url,
            'source':     'hqporner',
            'streams':    streams,
        }
        if streams:
            _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/HQP] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_hqporner_films(title):
    """Search hqporner.com and return matched film dicts with streams."""
    from urllib.parse import quote as _quote
    try:
        html = _get(HQPORN_BASE + '/?search=' + _quote(title))
        stubs, seen = [], set()
        for m in re.finditer(
            r'href="(/hdporn/[^"]+)"[^>]*class="[^"]*click-trigger[^"]*"',
            html, re.IGNORECASE
        ):
            path = m.group(1)
            slug = path.strip('/').split('/')[-1]
            film_url = HQPORN_BASE + path
            if slug and slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
        if not stubs:
            for m in re.finditer(r'href="(/hdporn/[^"]+\.html)"', html, re.IGNORECASE):
                path = m.group(1)
                slug = path.strip('/').split('/')[-1]
                film_url = HQPORN_BASE + path
                if slug and slug not in seen:
                    seen.add(slug)
                    stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/HQP] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _hqporner_film_detail(s['slug'], s['url']))


# ── Public browse helpers (used by afdb_router for category browsing) ─────────

def get_panda_genres():
    return _panda_genres()

def get_panda_movies(genre_url, page=1):
    return _panda_movies_for_genre(genre_url, page)

def get_panda_movie_detail(slug, url):
    return _panda_film_detail(slug, url)

def get_hqporner_categories():
    return _hqporner_categories()

def get_hqporner_movies(category_url, page=1):
    return _hqporner_movies(category_url, page)

def get_hqporner_movie_detail(slug, url):
    return _hqporner_film_detail(slug, url)


def search_by_title(title, page=1):
    """
    Search all adult scrapers + scraper_sources for streams matching `title`.
    Uses each site's own search endpoint (/?s=title) rather than page 1 catalog,
    so films anywhere in the archive can be found, not just the most recent.
    scraper_sources (cuevana3, hdtodayz, netmirror, zaxflix, rarefilmm, 1shows,
    456movie, msearch) are also searched as supplementary sources.
    Returns list of {'label': str, 'url': str} dicts.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    norm_query = _norm_title(title)
    if not norm_query:
        return []

    search_fns = [
        _search_freeo_films,
        _search_xxxms_films,
        _search_wpf_films,
        _search_spn_films,
        _search_xxxsc_films,
        _search_xmovix_films,
        _search_panda_films,
        _search_hqporner_films,
    ]

    streams   = []
    seen_urls = set()

    with ThreadPoolExecutor(max_workers=min(len(search_fns), 8)) as pool:
        futures = {pool.submit(fn, title): fn.__name__ for fn in search_fns}
        try:
            for future in as_completed(futures, timeout=30):
                name = futures[future]
                try:
                    films = future.result() or []
                    for film in films:
                        if not film:
                            continue
                        if _title_matches(norm_query, film.get('title_norm', '')):
                            for s in film.get('streams', []):
                                if s.get('url') and s['url'] not in seen_urls:
                                    seen_urls.add(s['url'])
                                    streams.append({'label': s.get('label', name), 'url': s['url']})
                            xbmc.log('[Starfleet/Streams] title match "%s" in %s' % (film.get('title', ''), name), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log('[Starfleet/Streams] search error (%s): %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] search_by_title timeout: %s' % e, xbmc.LOGWARNING)

    # Also search scraper_sources (movies/TV streaming sites) as supplementary adult sources
    try:
        from resources.lib.scraper_sources import search_all_scrapers as _sc_search
        sc_streams = _sc_search(title, media_type='adult')
        for s in sc_streams:
            if s.get('url') and s['url'] not in seen_urls:
                seen_urls.add(s['url'])
                streams.append({'label': s.get('label', s.get('source', 'Scrapers')), 'url': s['url']})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] scraper_sources adult search error: %s' % e, xbmc.LOGWARNING)

    xbmc.log('[Starfleet/Streams] search_by_title "%s" → %d streams' % (title, len(streams)), xbmc.LOGINFO)
    return streams


# ── Source availability index (for AFDB listing filter) ──────────────────────

_title_index = None   # set of normalised titles known to have sources (None = not built yet)


def prewarm_title_index():
    """
    Build (or return cached) a set of normalised titles known to have at least
    one cached stream source. Uses only already-cached data — no HTTP requests.
    Cached in module memory between calls (reuselanguageinvoker keeps it warm).
    """
    global _title_index
    if _title_index is not None:
        return

    from resources.lib import cache as _c
    index = set()

    # Walk cache keys for all 5 scrapers' film lists (pages 1-5 to be thorough)
    _PREFIXES = [
        ('fstreams_freeo_list_%d',   'fstreams_freeo_detail_%s',   'freeo_'),
        ('fstreams_xxxms_list_%d',   'fstreams_xxxms_detail_%s',   'xxxms_'),
        ('fstreams_wpw_list_%d',     'fstreams_wpw_detail_%s',     'wpw_'),
        ('fstreams_wpf_list_%d',     'fstreams_wpf_detail_%s',     'wpf_'),
        ('fstreams_spn_list_%d',     'fstreams_spn_detail_%s',     'spn_'),
        ('fstreams_xxxsc_list_%d',   'fstreams_xxxsc_detail_%s',   'xxxsc_'),
        ('fstreams_xmovix_list_%d',  'fstreams_xmovix_detail_%s',  'xmovix_'),
        ('panda_genre_%s_1',         'panda_detail_%s',            'panda_'),
        ('hqporner_cat_%s_1',        'hqporner_detail_%s',         'hqp_'),
    ]

    for list_tpl, detail_tpl, prefix in _PREFIXES:
        for pg in range(1, 6):
            film_list = _c.get(list_tpl % pg)
            if not film_list:
                continue
            for item in film_list:
                # film_list items are {'slug': ..., 'url': ...} dicts
                slug = item.get('slug', '') if isinstance(item, dict) else str(item)
                if not slug:
                    continue
                detail = _c.get(detail_tpl % slug)
                if detail and detail.get('streams'):
                    t = detail.get('title', '')
                    if t:
                        index.add(_norm_title(t))

    # Also check the merged cache from get_all_streams
    for pg in range(1, 6):
        merged = _c.get('fstreams_merged_list_%d' % pg)
        if not merged:
            continue
        if isinstance(merged, list):
            for film in merged:
                if film.get('streams') and film.get('title'):
                    index.add(_norm_title(film['title']))

    _title_index = index


def has_cached_source(title):
    """
    Check if a title has a known cached stream source.
    Returns True if confirmed source exists, False if confirmed absent,
    None if the title index is empty (no data cached yet — first load).
    """
    global _title_index
    if _title_index is None:
        return None
    if not _title_index:
        return None   # empty index = no scrape data yet, let everything through
    norm = _norm_title(title)
    return norm in _title_index
