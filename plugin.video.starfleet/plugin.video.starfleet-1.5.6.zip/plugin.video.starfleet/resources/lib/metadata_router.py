# -*- coding: utf-8 -*-
"""
resources/lib/metadata_router.py

TV Shows and Movies sections powered by TMDB + TVDB.

Menu structure:
  📺 TV Shows
    ├── 🔥 Popular
    ├── ⭐ Top Rated
    ├── 🎭 Browse by Genre
    ├── 🔍 Search
    └── [Show] → Seasons → Episodes

  🎬 Movies
    ├── 🔥 Popular
    ├── ⭐ Top Rated
    ├── 🆕 Now Playing
    ├── 🎭 Browse by Genre
    └── 🔍 Search
"""

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import metadata as meta
from concurrent.futures import ThreadPoolExecutor

ADDON     = xbmcaddon.Addon()
PAGE_SIZE = 20


# ── Helpers ───────────────────────────────────────────────────────────────────

def _add_dir(handle, build_url, label, params, thumb='', plot='', fanart=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    if fanart:
        li.setArt({'fanart': fanart})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_playable(handle, build_url, label, params, art=None, info=None):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', info or {'title': label})
    li.setProperty('IsPlayable', 'true')
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, False)


def _movie_art(m):
    return {
        'thumb':  m.get('thumb', ''),
        'poster': m.get('thumb', ''),
        'fanart': m.get('fanart', ''),
        'banner': m.get('fanart', ''),
    }


def _movie_info(m):
    return {
        'title':    m.get('title', ''),
        'year':     int(m['year']) if str(m.get('year', '')).isdigit() else 0,
        'rating':   float(m.get('rating', 0)),
        'plot':     m.get('overview', ''),
        'genre':    ', '.join(m.get('genres', [])),
        'studio':   ', '.join(m.get('studios', [])),
        'director': m.get('director', ''),
        'duration': int(m.get('runtime', 0)) * 60,
        'cast':     [c['name'] for c in m.get('cast', [])],
        'trailer':  m.get('trailer', ''),
        'mpaa':     '',
        'mediatype': 'movie',
    }


def _tv_info(s):
    return {
        'title':     s.get('title', ''),
        'year':      int(s['year']) if str(s.get('year', '')).isdigit() else 0,
        'rating':    float(s.get('rating', 0)),
        'plot':      s.get('overview', ''),
        'genre':     ', '.join(s.get('genres', [])),
        'studio':    ', '.join(s.get('networks', [])),
        'cast':      [c['name'] for c in s.get('cast', [])],
        'trailer':   s.get('trailer', ''),
        'mediatype': 'tvshow',
    }


def _need_fetch(key):
    from resources.lib import cache as _cache
    return _cache.get(key) is None


def _progress(msg):
    d = xbmcgui.DialogProgress()
    d.create('TVA+', msg)
    return d


def _next_page(handle, build_url, action, page, extra=None):
    params = {'action': action, 'page': page + 1}
    if extra:
        params.update(extra)
    _add_dir(handle, build_url,
             label='~~ Next Page (%d) ~~' % (page + 1),
             params=params)


# ── Movie Menus ───────────────────────────────────────────────────────────────

def _prewarm_movie_details(films):
    """
    Fire-and-forget background pre-fetch of full movie detail for
    each slim result in a list view. By the time the user clicks
    any item, the detail is already cached — no loading dialog shown.
    Only fetches items whose detail cache is currently cold.
    """
    cold_ids = [
        m['tmdb_id'] for m in films
        if _need_fetch('tmdb_movie_%s' % m['tmdb_id'])
    ]
    if not cold_ids:
        return
    def _fetch(tmdb_id):
        try:
            meta.get_movie_detail(tmdb_id)
        except Exception:
            pass
    pool = ThreadPoolExecutor(max_workers=5)
    for tmdb_id in cold_ids:
        pool.submit(_fetch, tmdb_id)
    pool.shutdown(wait=False)   # fire and forget — never blocks the UI


def _prewarm_tv_details(shows):
    """Same pattern for TV show detail pages."""
    cold_ids = [
        s['tmdb_id'] for s in shows
        if _need_fetch('tmdb_tv_%s' % s['tmdb_id'])
    ]
    if not cold_ids:
        return
    def _fetch(tmdb_id):
        try:
            meta.get_tv_detail(tmdb_id)
        except Exception:
            pass
    pool = ThreadPoolExecutor(max_workers=5)
    for tmdb_id in cold_ids:
        pool.submit(_fetch, tmdb_id)
    pool.shutdown(wait=False)


def movies_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎬 Movies')
    xbmcplugin.setContent(handle, 'movies')

    _add_dir(handle, build_url, '🔥  Popular',
             {'action': 'meta_movies_popular', 'page': 1},
             plot='Most popular movies right now')
    _add_dir(handle, build_url, '⭐  Top Rated',
             {'action': 'meta_movies_top', 'page': 1},
             plot='Highest rated movies of all time')
    _add_dir(handle, build_url, '🆕  Now Playing',
             {'action': 'meta_movies_new', 'page': 1},
             plot='Movies currently in theatres')
    _add_dir(handle, build_url, '📈  Trending Now',
             {'action': 'meta_movies_upcoming', 'page': 1},
             plot='Top movies trending this week (mirrors IMDB Movie Meter)')
    _add_dir(handle, build_url, '🎭  Browse by Genre',
             {'action': 'meta_movie_genres'},
             plot='Browse movies by genre')
    _add_dir(handle, build_url, '🔍  Search',
             {'action': 'meta_movies_search'},
             plot='Search movies by title')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_popular(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🔥 Popular Movies')
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_popular_%d' % page)
    dlg   = _progress('Loading popular movies...') if cold else None
    films = meta.get_movies_popular(page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_popular', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_top_rated(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '⭐ Top Rated Movies')
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_top_rated_%d' % page)
    dlg   = _progress('Loading top rated movies...') if cold else None
    films = meta.get_movies_top_rated(page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_top', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_now_playing(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🆕 Now Playing')
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_new_%d' % page)
    dlg   = _progress('Loading now playing...') if cold else None
    films = meta.get_movies_new(page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_new', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_upcoming(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '📈 Trending This Week')
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_trending_%d' % page)
    dlg   = _progress('Loading new releases...') if cold else None
    films = meta.get_movies_upcoming(page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_upcoming', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movie_genres(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎭 Movie Genres')
    xbmcplugin.setContent(handle, 'files')

    cold   = _need_fetch('tmdb_movie_genres')
    dlg    = _progress('Loading genres...') if cold else None
    genres = meta.get_movie_genres()
    if dlg: dlg.close()

    for g in genres:
        _add_dir(handle, build_url,
                 label=g['name'],
                 params={'action': 'meta_movies_by_genre',
                         'genre_id': g['id'], 'genre_name': g['name'], 'page': 1},
                 plot='Browse %s movies' % g['name'])
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def movies_by_genre(handle, build_url, genre_id, genre_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '🎭 %s' % genre_name)
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_genre_%s_%d' % (genre_id, page))
    dlg   = _progress('Loading %s...' % genre_name) if cold else None
    films = meta.get_movies_by_genre(genre_id, page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_by_genre', page,
                   extra={'genre_id': genre_id, 'genre_name': genre_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search Movies')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '🔍 Movies: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    dlg   = _progress('Searching...')
    films = meta.search_movies(query)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Movies', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def movie_detail(handle, build_url, tmdb_id):
    """Load full movie metadata and show detail view with cast."""
    cold   = _need_fetch('tmdb_movie_%s' % tmdb_id)
    dlg    = _progress('Loading movie info...') if cold else None
    film   = meta.get_movie_detail(tmdb_id)
    if dlg: dlg.close()

    if not film:
        xbmcgui.Dialog().notification('Movies', 'Could not load metadata',
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    xbmcplugin.setPluginCategory(handle, film.get('title', ''))
    xbmcplugin.setContent(handle, 'movies')

    art  = _movie_art(film)
    info = _movie_info(film)

    # Play item
    li = xbmcgui.ListItem(label='▶  Play — %s' % film.get('title', ''))
    li.setInfo('video', info)
    li.setArt(art)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({'action': 'meta_movie_play',
                   'tmdb_id': tmdb_id,
                   'title': film.get('title', ''),
                   'imdb_id': film.get('imdb_id', ''),
                   'year': str(film.get('year', '') or '')}),
        li, False
    )

    # Trailer button (only if TMDB returned a trailer key)
    if film.get('trailer'):
        tli = xbmcgui.ListItem(label='🎬  Watch Trailer')
        tli.setInfo('video', {'title': 'Trailer: %s' % film.get('title', '')})
        tli.setArt(art)
        tli.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle, film['trailer'], tli, False)

    # Cast list
    for actor in film.get('cast', []):
        li = xbmcgui.ListItem(label='👤  %s  as  %s' % (
            actor['name'], actor.get('character', '')))
        li.setInfo('video', {'title': actor['name']})
        li.setArt({'thumb': actor.get('photo', ''),
                   'icon':  actor.get('photo', ''),
                   'fanart': film.get('fanart', '')})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'meta_person',
                       'name': actor['name'],
                       'media_type': 'movie'}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def _render_movie_list(handle, build_url, films):
    """Render a list of slim movie dicts as Kodi items. Click → source picker.
    If full detail is already cached (from a prior prewarm), uses cast/genre/director."""
    from resources.lib import cache as _rcache
    for m in films:
        full = _rcache.get('tmdb_movie_%s' % m['tmdb_id'])
        d    = full if full else m

        label = d['title']
        if d.get('year'):
            label += '  (%s)' % d['year']
        if d.get('rating'):
            label += '  ★%.1f' % d['rating']

        li = xbmcgui.ListItem(label=label)

        info = {
            'title':     d['title'],
            'year':      int(d['year']) if str(d.get('year', '')).isdigit() else 0,
            'rating':    float(d.get('rating', 0)),
            'plot':      d.get('overview', ''),
            'mediatype': 'movie',
        }
        if d.get('genres'):
            info['genre'] = ', '.join(d['genres'])
        if d.get('director'):
            info['director'] = d['director']
        if d.get('runtime'):
            info['duration'] = int(d['runtime']) * 60
        if d.get('trailer'):
            info['trailer'] = d['trailer']

        li.setInfo('video', info)

        art = {
            'thumb':  d.get('thumb', ''),
            'poster': d.get('thumb', ''),
            'fanart': d.get('fanart', ''),
        }
        if full and full.get('backdrops'):
            art['extrafanart'] = full['backdrops'][0]
        li.setArt(art)

        # Cast via InfoTagVideo when full detail available
        if full and full.get('cast'):
            try:
                tag = li.getVideoInfoTag()
                actors = []
                for c in full['cast']:
                    a = xbmcgui.Actor(c['name'], c.get('character', ''),
                                      0, c.get('photo', ''))
                    actors.append(a)
                tag.setCast(actors)
            except Exception:
                pass

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':   'meta_movie_play',
                       'tmdb_id':  m['tmdb_id'],
                       'title':    m['title'],
                       'imdb_id':  m.get('imdb_id', ''),
                       'year':     str(m.get('year', '') or '')}),
            li, False
        )


# ── TV Show Menus ─────────────────────────────────────────────────────────────

def tv_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '📺 TV Shows')
    xbmcplugin.setContent(handle, 'tvshows')

    _add_dir(handle, build_url, '🔥  Popular',
             {'action': 'meta_tv_popular', 'page': 1},
             plot='Most popular TV shows right now')
    _add_dir(handle, build_url, '⭐  Top Rated',
             {'action': 'meta_tv_top', 'page': 1},
             plot='Highest rated TV shows of all time')
    _add_dir(handle, build_url, '🎭  Browse by Genre',
             {'action': 'meta_tv_genres'},
             plot='Browse TV shows by genre')
    _add_dir(handle, build_url, '🔍  Search',
             {'action': 'meta_tv_search'},
             plot='Search TV shows by title')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_popular(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🔥 Popular TV Shows')
    xbmcplugin.setContent(handle, 'tvshows')

    cold  = _need_fetch('tmdb_tv_popular_%d' % page)
    dlg   = _progress('Loading popular shows...') if cold else None
    shows = meta.get_tv_popular(page=page)
    if dlg: dlg.close()

    _render_tv_list(handle, build_url, shows)
    _prewarm_tv_details(shows)
    if len(shows) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_tv_popular', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_top_rated(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '⭐ Top Rated TV Shows')
    xbmcplugin.setContent(handle, 'tvshows')

    cold  = _need_fetch('tmdb_tv_top_%d' % page)
    dlg   = _progress('Loading top rated shows...') if cold else None
    shows = meta.get_tv_top_rated(page=page)
    if dlg: dlg.close()

    _render_tv_list(handle, build_url, shows)
    _prewarm_tv_details(shows)
    if len(shows) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_tv_top', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_genres(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎭 TV Genres')
    xbmcplugin.setContent(handle, 'files')

    cold   = _need_fetch('tmdb_tv_genres')
    dlg    = _progress('Loading genres...') if cold else None
    genres = meta.get_tv_genres()
    if dlg: dlg.close()

    for g in genres:
        _add_dir(handle, build_url,
                 label=g['name'],
                 params={'action': 'meta_tv_by_genre',
                         'genre_id': g['id'], 'genre_name': g['name'], 'page': 1},
                 plot='Browse %s shows' % g['name'])
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def tv_by_genre(handle, build_url, genre_id, genre_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '🎭 %s' % genre_name)
    xbmcplugin.setContent(handle, 'tvshows')

    cold  = _need_fetch('tmdb_tv_genre_%s_%d' % (genre_id, page))
    dlg   = _progress('Loading %s...' % genre_name) if cold else None
    shows = meta.get_tv_by_genre(genre_id, page=page)
    if dlg: dlg.close()

    _render_tv_list(handle, build_url, shows)
    _prewarm_tv_details(shows)
    if len(shows) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_tv_by_genre', page,
                   extra={'genre_id': genre_id, 'genre_name': genre_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search TV Shows')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '🔍 TV: %s' % query)
    xbmcplugin.setContent(handle, 'tvshows')

    dlg   = _progress('Searching...')
    shows = meta.search_tv(query)
    dlg.close()

    if not shows:
        xbmcgui.Dialog().notification('TV Shows', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    _render_tv_list(handle, build_url, shows)
    _prewarm_tv_details(shows)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def tv_show_detail(handle, build_url, tmdb_id):
    """Load full show info and list seasons."""
    cold  = _need_fetch('tmdb_tv_%s' % tmdb_id)
    dlg   = _progress('Loading show info...') if cold else None
    show  = meta.get_tv_detail(tmdb_id)
    if dlg: dlg.close()

    if not show:
        xbmcgui.Dialog().notification('TV Shows', 'Could not load metadata',
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    xbmcplugin.setPluginCategory(handle, show.get('title', ''))
    xbmcplugin.setContent(handle, 'seasons')

    seasons = show.get('seasons', [])
    if len(seasons) == 1:
        # Only one season — go straight to episodes
        tv_season_episodes(handle, build_url, tmdb_id,
                           seasons[0]['season'],
                           show.get('tvdb_id', ''),
                           show.get('title', ''),
                           show.get('fanart', ''))
        return

    # Pre-warm first season's episodes in background
    if seasons:
        first = seasons[0]
        def _prewarm_first_season():
            try:
                meta.get_episodes(tmdb_id, first['season'],
                                  show.get('tvdb_id') or None)
            except Exception:
                pass
        if _need_fetch('tmdb_season_%s_%s' % (tmdb_id, first['season'])):
            ThreadPoolExecutor(max_workers=1).submit(_prewarm_first_season)

    for s in seasons:
        label = '%s  (%d episodes)' % (s['name'], s.get('episode_count', 0))
        li    = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':   s['name'],
            'season':  s['season'],
            'plot':    s.get('overview', ''),
            'mediatype': 'season',
        })
        li.setArt({
            'thumb':  s.get('thumb', '') or show.get('thumb', ''),
            'poster': s.get('thumb', '') or show.get('thumb', ''),
            'fanart': show.get('fanart', ''),
        })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'meta_tv_episodes',
                       'tmdb_id':    tmdb_id,
                       'season_num': s['season'],
                       'tvdb_id':    show.get('tvdb_id', ''),
                       'show_title': show.get('title', ''),
                       'show_fanart': show.get('fanart', '')}),
            li, True
        )
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_season_episodes(handle, build_url, tmdb_id, season_num,
                       tvdb_id='', show_title='', show_fanart=''):
    """List all episodes in a season."""
    xbmcplugin.setPluginCategory(
        handle, '%s — Season %s' % (show_title, season_num))
    xbmcplugin.setContent(handle, 'episodes')

    cold     = _need_fetch('tmdb_season_%s_%s' % (tmdb_id, season_num))
    dlg      = _progress('Loading episodes...') if cold else None
    episodes = meta.get_episodes(tmdb_id, season_num, tvdb_id or None)
    if dlg: dlg.close()

    if not episodes:
        xbmcgui.Dialog().notification('TV Shows', 'No episodes found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    for ep in episodes:
        label = 'S%02dE%02d — %s' % (
            int(season_num), ep['episode'], ep.get('title', ''))
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':       ep.get('title', ''),
            'plot':        ep.get('overview', ''),
            'season':      int(season_num),
            'episode':     ep['episode'],
            'aired':       ep.get('aired', ''),
            'rating':      float(ep.get('rating', 0)),
            'duration':    int(ep.get('runtime', 0)) * 60,
            'tvshowtitle': show_title,
            'mediatype':   'episode',
        })
        li.setArt({
            'thumb':  ep.get('still', ''),
            'icon':   ep.get('still', ''),
            'fanart': show_fanart,
        })
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':      'meta_ep_play',
                       'tmdb_id':     tmdb_id,
                       'season_num':  season_num,
                       'episode_num': ep['episode'],
                       'title':       '%s S%02dE%02d' % (
                           show_title, int(season_num), ep['episode'])}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_EPISODE)


def _render_tv_list(handle, build_url, shows):
    for s in shows:
        label = s['title']
        if s.get('year'):
            label += '  (%s)' % s['year']
        if s.get('rating'):
            label += '  ★%.1f' % s['rating']

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':     s['title'],
            'year':      int(s['year']) if str(s.get('year', '')).isdigit() else 0,
            'rating':    float(s.get('rating', 0)),
            'plot':      s.get('overview', ''),
            'mediatype': 'tvshow',
        })
        li.setArt({
            'thumb':  s.get('thumb', ''),
            'poster': s.get('thumb', ''),
            'fanart': s.get('fanart', ''),
        })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'meta_tv_show',
                       'tmdb_id': s['tmdb_id']}),
            li, True
        )


# ── Playback placeholders (stream URL supplied externally) ────────────────────

def _unified_source_search(handle, title, year=None, media_type='movie'):
    """
    Search free sources AND torrent/debrid in parallel.
    Shows a unified source picker dialog, then plays the chosen stream.
    Free sources appear first (no subscription required), debrid after.
    """
    from concurrent.futures import ThreadPoolExecutor

    pd = xbmcgui.DialogProgress()
    pd.create('Starfleet', 'Searching sources for "%s"...' % title)
    pd.update(5)

    def _search_free():
        try:
            from resources.lib import free_sources as _fs
            return _fs.search_free_streams(title, year=year, media_type=media_type)
        except Exception as e:
            xbmc.log('[Starfleet] free_sources search error: %s' % e, xbmc.LOGERROR)
            return []

    def _search_debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            return _dt.get_debrid_streams(title, year=year, media_type=media_type)
        except Exception as e:
            xbmc.log('[Starfleet] debrid_torrent error: %s' % e, xbmc.LOGERROR)
            return []

    def _search_personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(title, year=year, media_type=media_type)
        except Exception as e:
            xbmc.log('[Starfleet] personal_sources error: %s' % e, xbmc.LOGERROR)
            return []

    with ThreadPoolExecutor(max_workers=3) as pool:
        f_personal = pool.submit(_search_personal)
        f_free     = pool.submit(_search_free)
        f_debrid   = pool.submit(_search_debrid)
        pd.update(30)
        try:
            personal_results = f_personal.result(timeout=15)
        except Exception:
            personal_results = []
        try:
            free_results = f_free.result(timeout=30)
        except Exception:
            free_results = []
        pd.update(70)
        try:
            debrid_results = f_debrid.result(timeout=30)
        except Exception:
            debrid_results = []

    pd.close()

    # Personal library first (user's own files), then free, then debrid
    debrid_sources = [
        {'label': '[Debrid] %s' % s['label'], 'url': s['url']}
        for s in debrid_results
    ]
    all_sources = personal_results + free_results + debrid_sources

    if not all_sources:
        xbmcgui.Dialog().notification(
            'Starfleet',
            'No sources found for "%s"' % title,
            xbmcgui.NOTIFICATION_WARNING,
            5000
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(all_sources) == 1:
        chosen = all_sources[0]
    else:
        idx = xbmcgui.Dialog().select(
            '"%s" — Choose source' % title,
            [s['label'] for s in all_sources]
        )
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = all_sources[idx]

    chosen_url = chosen['url']

    # Resolve archive:// protocol to a real MP4 URL
    if chosen_url.startswith('archive://'):
        archive_id = chosen_url[len('archive://'):]
        pd2 = xbmcgui.DialogProgress()
        pd2.create('Starfleet', 'Resolving Archive.org stream...')
        pd2.update(50)
        try:
            from resources.lib import free_sources as _fs
            chosen_url = _fs.resolve_archive_stream(archive_id)
        except Exception as e:
            xbmc.log('[Starfleet] Archive.org resolve error: %s' % e, xbmc.LOGERROR)
            chosen_url = ''
        finally:
            pd2.close()
        if not chosen_url:
            xbmcgui.Dialog().notification(
                'Starfleet', 'Could not resolve Archive.org stream',
                xbmcgui.NOTIFICATION_WARNING, 4000
            )
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return

    li = xbmcgui.ListItem(path=chosen_url)
    li.setInfo('video', {'title': title})
    xbmcplugin.setResolvedUrl(handle, True, li)


def movie_play(handle, tmdb_id='', title='', imdb_id='', year=''):
    """Search free + torrent/debrid sources for a movie and show a picker."""
    if not title:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    _unified_source_search(handle, title, year=year or None, media_type='movie')


def episode_play(handle, tmdb_id='', season_num=1, episode_num=1, title='', year=''):
    """Search free + torrent/debrid sources for a TV episode and show a picker."""
    if not title:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    # title is already "Show S01E01" (set by tv_season_episodes)
    _unified_source_search(handle, title, year=year or None, media_type='tv')


# ── Person / Actor search ─────────────────────────────────────────────────────

def person_movies(handle, build_url, name, media_type='movie'):
    """Search for movies/shows featuring an actor by name."""
    xbmcplugin.setPluginCategory(handle, '👤 %s' % name)
    xbmcplugin.setContent(handle, 'movies' if media_type == 'movie' else 'tvshows')

    dlg   = _progress('Searching for %s...' % name)
    if media_type == 'movie':
        results = meta.search_movies(name)
    else:
        results = meta.search_tv(name)
    dlg.close()

    if media_type == 'movie':
        _render_movie_list(handle, build_url, results)
    else:
        _render_tv_list(handle, build_url, results)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
