# -*- coding: utf-8 -*-
"""
resources/lib/geo_spoof.py

Canadian geo-bypass for TVA, TVA Sports, CBC, Radio-Canada, Global News
and any other geo-locked Canadian channel in Starfleet.

Two-layer approach
──────────────────
Layer 1 — Header spoof (zero-cost, works for API / auth layer):
  Injects X-Forwarded-For + companion headers with a real Canadian ISP
  IP address.  Services that geo-check on the HTTP layer (Brightcove
  auth, CBC Gem API, Global News Corus API, Google DAI) will see a
  Canadian IP without any real network hop.

Layer 2 — TCP proxy (needed when CDN validates the real source IP):
  Routes Python requests through a user-supplied HTTP or SOCKS5 proxy
  hosted in Canada.  Combine with a cheap Canadian VPS ($3–5/mo) or
  a residential proxy service for full CDN-level bypass.

Stream URL decoration
─────────────────────
`decorate_url(url)` appends |X-Forwarded-For=IP to the final HLS URL.
Kodi passes these |headers to:
  • Its built-in HTTP client (for plain .m3u8 streams)
  • inputstream.adaptive manifest + segment fetches (via stream_headers
    property set in _hls_item() in router.py)

Settings keys (settings.xml category "Canadian Channels"):
  geo_bypass_enabled   bool   master switch (default false)
  geo_bypass_ip_idx    enum   selects which Canadian ISP IP to use
  geo_bypass_proxy     text   e.g. socks5://user:pass@host:port
                              or   http://host:port
"""
import threading
import requests
import xbmc
import xbmcaddon

_ADDON = xbmcaddon.Addon()

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)

# Canadian ISP IPs — index order MUST match the settings.xml enum values string
_CA_IPS = [
    ('Videotron (Québec — best for TVA/RDS)',   '24.48.0.1'),
    ('Bell Canada (Ontario)',                     '70.26.0.1'),
    ('Rogers (Ontario)',                          '99.228.0.1'),
    ('Shaw / Rogers (BC / Alberta)',              '184.162.0.1'),
    ('Telus (BC / Alberta)',                      '184.64.0.1'),
    ('Cogeco (Québec / Ontario)',                 '207.172.0.1'),
]

_session      = None
_session_lock = threading.Lock()


# ── Public helpers ────────────────────────────────────────────────────────────

def is_enabled():
    """Return True when the geo-bypass master switch is on in settings."""
    return _ADDON.getSetting('geo_bypass_enabled') == 'true'


def ca_ip():
    """Return the selected Canadian ISP IP string."""
    try:
        idx = int(_ADDON.getSetting('geo_bypass_ip_idx') or '0')
        return _CA_IPS[min(idx, len(_CA_IPS) - 1)][1]
    except Exception:
        return _CA_IPS[0][1]


def geo_headers(ip=None):
    """Return dict of all Canadian IP spoofing headers."""
    ip = ip or ca_ip()
    return {
        'X-Forwarded-For':  ip,
        'X-Real-IP':        ip,
        'CF-Connecting-IP': ip,
        'True-Client-IP':   ip,
        'X-Originating-IP': ip,
    }


def session():
    """
    Return the shared geo-bypass requests.Session.
    Thread-safe, lazily built, process-lifetime cache.
    Call invalidate() after the user changes settings.
    """
    global _session
    if _session is None:
        with _session_lock:
            if _session is None:
                _session = _build_session()
    return _session


def invalidate():
    """Force a fresh session on next call (e.g. after settings change)."""
    global _session
    with _session_lock:
        _session = None


def decorate_url(url):
    """
    Append Canadian IP headers to a stream URL using Kodi's | notation:
      https://cdn.example.com/live.m3u8|X-Forwarded-For=24.48.0.1&...

    Kodi's built-in HLS player and inputstream.adaptive both honour these
    headers when fetching the manifest and every segment from the CDN.

    Returns url unchanged when geo-bypass is disabled or url is empty.
    """
    if not is_enabled() or not url:
        return url
    ip  = ca_ip()
    sep = '&' if '|' in url else '|'
    return (
        '%s%sX-Forwarded-For=%s&True-Client-IP=%s&User-Agent=%s'
        % (url, sep, ip, ip, requests.utils.quote(_UA))
    )


def stream_headers_str():
    """
    Return a header string suitable for
    li.setProperty('inputstream.adaptive.stream_headers', ...).
    Empty string when geo-bypass is disabled.
    """
    if not is_enabled():
        return ''
    ip = ca_ip()
    return 'X-Forwarded-For=%s&True-Client-IP=%s&User-Agent=%s' % (
        ip, ip, requests.utils.quote(_UA)
    )


# ── Internal ──────────────────────────────────────────────────────────────────

def _build_session():
    s = requests.Session()
    s.headers.update({
        'User-Agent':      _UA,
        'Accept':          'application/json, text/plain, */*',
        'Accept-Language': 'en-CA,en;q=0.9,fr-CA;q=0.8',
    })
    ip = ca_ip()
    s.headers.update(geo_headers(ip))
    xbmc.log('[GeoBypass] Session built — Canadian IP: %s' % ip, xbmc.LOGINFO)

    proxy = (_ADDON.getSetting('geo_bypass_proxy') or '').strip()
    if proxy:
        s.proxies = {'http': proxy, 'https': proxy}
        log_p = proxy.split('@')[-1] if '@' in proxy else proxy
        xbmc.log('[GeoBypass] Proxy tunnel: %s' % log_p, xbmc.LOGINFO)

    adapter = requests.adapters.HTTPAdapter(
        pool_connections=4, pool_maxsize=10,
        max_retries=requests.adapters.Retry(total=2, backoff_factor=0.3),
    )
    s.mount('https://', adapter)
    s.mount('http://',  adapter)
    return s
