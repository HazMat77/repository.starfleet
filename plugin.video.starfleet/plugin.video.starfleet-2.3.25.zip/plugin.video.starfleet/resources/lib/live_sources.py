﻿# -*- coding: utf-8 -*-
"""
resources/lib/live_sources.py  — Unified free live TV channel loader

Sources:
  Starfleet / Québecor  — Google DAI session tokens (handled in api.py)
  Samsung TV+      — community M3U  i.mjh.nz/SamsungTVPlus/ca.m3u8   (24h cache)
  Plex FAST        — community M3U  i.mjh.nz/Plex/all.m3u8            (24h cache)
  Pluto TV         — boot.pluto.tv JWT API + channel list              (1h cache)

Performance optimisations applied:
  ✓ Pre-compiled regex patterns (compiled once at import time)
  ✓ Persistent SQLite connection via cache.py (single connect per process)
  ✓ In-memory hot cache for same-session repeated reads
  ✓ Pluto: metadata cached separately from stream URL (JWT not baked into cache)
  ✓ Progress dialog suppressed on cache hits
  ✓ Lazy session creation
  ✓ Compact JSON serialisation (no whitespace)
  ✓ Differentiated timeouts: 4s cache probe, 12s network fetch, 6s stream resolve
"""

import re
import time
import uuid
import threading

import xbmc
import xbmcaddon
import xbmcvfs
import requests

ADDON    = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

# Initialise cache (done once; subsequent calls are no-ops)
import xbmc as _xbmc
_PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

from resources.lib import cache as _cache
_cache.init(_CACHE_DB)

# ── Pre-compiled M3U regex ────────────────────────────────────────────────────
_RE_NAME  = re.compile(r',(.+)$')
_RE_LOGO  = re.compile(r'tvg-logo="([^"]*)"')
_RE_GROUP = re.compile(r'group-title="([^"]*)"')
_RE_ID    = re.compile(r'tvg-id="([^"]*)"')

# ── Community M3U endpoints ───────────────────────────────────────────────────
# Primary: BuddyChewChew/app-m3u-generator — daily-updated GitHub-hosted M3U
#   Samsung 288 ch, Plex 460 ch — confirmed working 2026-06-27
# Fallback: i.mjh.nz — removed M3U format mid-2026 (now XMLTV EPG only),
#   kept here in case they restore it.
_BUDDY_BASE = 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists'

SAMSUNG_CA_URLS = [
    _BUDDY_BASE + '/samsungtvplus_ca.m3u',
    'https://i.mjh.nz/SamsungTVPlus/ca.m3u8',
    'https://i.mjh.nz/SamsungTVPlus/all.m3u8',
]
PLEX_ALL_URLS = [
    _BUDDY_BASE + '/plex_ca.m3u',
    'https://i.mjh.nz/Plex/all.m3u8',
    'https://i.mjh.nz/Plex/ca.m3u8',
]
MJH_SAMSUNG_EPG = 'https://i.mjh.nz/SamsungTVPlus/ca.xml'
MJH_PLEX_EPG    = 'https://i.mjh.nz/Plex/ca.xml'

# ── Pluto TV ─────────────────────────────────────────────────────────────────
PLUTO_BOOT = (
    'https://boot.pluto.tv/v4/start'
    '?appName=web&appVersion=9.19.0&deviceVersion=126.0.0'
    '&deviceType=web&deviceMake=chrome&deviceModel=web'
    '&clientID={cid}&clientModelNumber=1.0.0'
    '&serverSideAds=false&marketingRegion=CA'
)
PLUTO_STITCH = (
    'https://cfd-v4-service-channel-stitcher-use1-1.prd.pluto.tv'
    '/v2/stitch/hls/channel/{ch_id}/master.m3u8'
    '?appName=web&appVersion=9.19.0&deviceVersion=126.0.0'
    '&deviceType=web&deviceMake=chrome&deviceModel=web'
    '&clientID={cid}&clientModelNumber=1.0.0'
    '&country=CA&marketingRegion=CA&serverSideAds=false&jwt={jwt}'
)

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-CA,en;q=0.9,fr-CA;q=0.8',
}

# ── HTTP session (lazy, thread-safe) ─────────────────────────────────────────
_session     = None
_session_lock = threading.Lock()

def _sess():
    global _session
    if _session is None:
        with _session_lock:
            if _session is None:
                s = requests.Session()
                s.headers.update(HEADERS)
                a = requests.adapters.HTTPAdapter(
                    pool_connections=4, pool_maxsize=10,
                    max_retries=requests.adapters.Retry(total=2, backoff_factor=0.3)
                )
                s.mount('https://', a)
                _session = s
    return _session


# ── M3U parser (optimised) ────────────────────────────────────────────────────

def _parse_m3u(text, source_label):
    channels = []
    lines    = text.splitlines()
    n        = len(lines)
    i        = 0
    while i < n:
        line = lines[i]
        if line.startswith('#EXTINF:'):
            m_name  = _RE_NAME.search(line)
            m_logo  = _RE_LOGO.search(line)
            m_group = _RE_GROUP.search(line)
            m_id    = _RE_ID.search(line)

            name  = m_name.group(1).strip()  if m_name  else 'Unknown'
            logo  = m_logo.group(1)          if m_logo  else ''
            group = m_group.group(1)         if m_group else source_label
            ch_id = m_id.group(1)            if m_id    else name

            # Next non-comment line is the stream URL
            i += 1
            while i < n and lines[i].startswith('#'):
                i += 1
            url = lines[i].strip() if i < n else ''

            if url and not url.startswith('#') and url.startswith('http'):
                channels.append({
                    'id':         ch_id,
                    'title':      name,
                    'group':      group,
                    'source':     source_label,
                    'thumbnail':  logo,
                    'stream_url': url,
                })
        i += 1
    return channels


# ── Samsung TV+ ───────────────────────────────────────────────────────────────

def get_samsung_channels():
    cached = _cache.get('samsung_ca')
    if cached is not None:
        return cached

    for url in SAMSUNG_CA_URLS:
        try:
            r = _sess().get(url, timeout=12)
            if r.status_code == 200 and '#EXTINF' in r.text:
                channels = _parse_m3u(r.text, 'Samsung TV+')
                if channels:
                    _cache.set('samsung_ca', channels, 24 * 3600)
                    xbmc.log('[Starfleet] Samsung: %d channels' % len(channels), xbmc.LOGINFO)
                    return channels
        except Exception as e:
            xbmc.log('[Starfleet] Samsung error (%s): %s' % (url, e), xbmc.LOGERROR)
    xbmc.log('[Starfleet] Samsung TV+: all M3U sources unavailable', xbmc.LOGWARNING)
    return []


def get_samsung_epg_url():
    return MJH_SAMSUNG_EPG


# ── Plex FAST ─────────────────────────────────────────────────────────────────

def get_plex_channels():
    cached = _cache.get('plex_all')
    if cached is not None:
        return cached

    for url in PLEX_ALL_URLS:
        try:
            r = _sess().get(url, timeout=12)
            if r.status_code == 200 and '#EXTINF' in r.text:
                channels = _parse_m3u(r.text, 'Plex')
                if channels:
                    _cache.set('plex_all', channels, 24 * 3600)
                    xbmc.log('[Starfleet] Plex: %d channels' % len(channels), xbmc.LOGINFO)
                    return channels
        except Exception as e:
            xbmc.log('[Starfleet] Plex error (%s): %s' % (url, e), xbmc.LOGERROR)
    xbmc.log('[Starfleet] Plex FAST: all M3U sources unavailable', xbmc.LOGWARNING)
    return []


def get_plex_epg_url():
    return MJH_PLEX_EPG


# ── Pluto TV ──────────────────────────────────────────────────────────────────

def _get_pluto_cid():
    cached = _cache.get('pluto_cid')
    if cached:
        return cached
    cid = str(uuid.uuid4())
    _cache.set('pluto_cid', cid, 365 * 24 * 3600)
    return cid


PLUTO_CHANNELS_URL = 'https://api.pluto.tv/v2/channels.json'


def _boot_pluto():
    """
    Fetch Pluto boot response to obtain JWT session token.
    Returns (jwt, []) — channel list is now fetched separately.
    Caches JWT independently.
    """
    cid = _get_pluto_cid()
    try:
        r = _sess().get(PLUTO_BOOT.format(cid=cid), timeout=12)
        r.raise_for_status()
        data = r.json()

        jwt = (data.get('sessionToken') or
               data.get('stitcherParams', {}).get('jwt', ''))
        if jwt:
            _cache.set('pluto_jwt', jwt, 20 * 3600)
        return jwt, []
    except Exception as e:
        xbmc.log('[Starfleet] Pluto boot error: %s' % e, xbmc.LOGERROR)
        return None, []


def _fetch_pluto_channel_list():
    """
    Fetch the Pluto TV channel list from the v2 JSON API.
    Returns list of channel dicts or [] on failure.
    The boot EPG field now only returns the current/starting channel;
    the dedicated channel list endpoint returns all ~200 channels.
    """
    try:
        r = _sess().get(PLUTO_CHANNELS_URL, timeout=12)
        r.raise_for_status()
        raw = r.json()
        meta = []
        for ch in raw:
            ch_id = ch.get('_id') or ch.get('id', '')
            name  = ch.get('name') or ch.get('title', '')
            if not ch_id or not name:
                continue
            # Logo: v2 API uses featuredImage or thumbnail dict
            logo = (
                (ch.get('featuredImage') or {}).get('path', '') or
                (ch.get('thumbnail') or {}).get('path', '') or
                ''
            )
            group = ch.get('category') or ch.get('genre', 'General')
            meta.append({
                'id':        ch_id,
                'title':     name,
                'group':     group,
                'thumbnail': logo,
                'source':    'Pluto TV',
            })
        xbmc.log('[Starfleet] Pluto: %d channels from v2 API' % len(meta), xbmc.LOGINFO)
        return meta
    except Exception as e:
        xbmc.log('[Starfleet] Pluto channel list error: %s' % e, xbmc.LOGERROR)
        return []


def get_pluto_channels():
    """
    Return Pluto channel metadata. Stream URLs built at play time using
    current JWT (not baked into cache), so stale JWT only breaks playback
    not the channel listing.
    """
    meta = _cache.get('pluto_meta')
    if meta is None:
        meta = _fetch_pluto_channel_list()
        if not meta:
            return []
        _cache.set('pluto_meta', meta, 6 * 3600)

    # Attach stream URLs using current (possibly cached) JWT
    cid = _get_pluto_cid()
    jwt = _cache.get('pluto_jwt')
    if not jwt:
        jwt, _ = _boot_pluto()

    channels = []
    for ch in meta:
        stream = PLUTO_STITCH.format(ch_id=ch['id'], cid=cid, jwt=jwt or '') if jwt else ''
        channels.append(dict(ch, stream_url=stream))
    return channels


def get_pluto_stream(channel_id):
    """Build a fresh Pluto stream URL — called at play time."""
    cid = _get_pluto_cid()
    jwt = _cache.get('pluto_jwt')
    if not jwt:
        jwt, _ = _boot_pluto()
    if not jwt:
        return None
    return PLUTO_STITCH.format(ch_id=channel_id, cid=cid, jwt=jwt)


def refresh_pluto():
    _cache.delete(['pluto_jwt', 'pluto_meta', 'pluto_cid'])
    return get_pluto_channels()


def refresh_pluto_channels():
    """Alias kept for backwards compatibility."""
    return refresh_pluto()


# ── OnHockey.tv Live Channels (NHL Network + other hockey TV) ────────────────

_ONHOCKEY_BASE = 'https://onhockey.tv'

# Paths to try for the live-channels section of the site
_ONHOCKEY_LIVE_PATHS = ['/nhl-network', '/live', '/channels', '/live-tv', '/network']

# Regex: find offsite stream/embed links on an onhockey.tv live channel page
_RE_OHK_IFRAME = re.compile(
    r'<iframe[^>]+src="(https?://(?!onhockey\.tv)[^"]{10,300})"',
    re.IGNORECASE
)
_RE_OHK_STREAM = re.compile(
    r'(?:src|href|file|source)\s*[:=]\s*["\']?(https?://[^"\'>\s]{15,300}\.m3u8[^"\'>\s]*)',
    re.IGNORECASE
)
_RE_OHK_CHAN_LINK = re.compile(
    r'<a[^>]+href="(https?://onhockey\.tv/([^"#\s]{3,80}))"[^>]*>\s*([^<]{3,80}?)\s*</a>',
    re.IGNORECASE
)

_LIVE_CHAN_SKIP = {
    'home', 'schedule', 'scores', 'standings', 'news', 'about', 'contact',
    'privacy', 'faq', 'login', 'register', 'reddit', 'discord', 'nhl', 'ahl',
}


def _onhockey_scrape_stream(page_url):
    """Fetch an onhockey.tv channel page and return the first usable stream URL."""
    try:
        r = requests.get(page_url, timeout=12, headers={
            'User-Agent': HEADERS['User-Agent'],
            'Referer': _ONHOCKEY_BASE + '/',
        })
        if r.status_code >= 400:
            return None
        html = r.text
    except Exception:
        return None

    # Priority 1: direct HLS .m3u8 in JS/JSON
    m = _RE_OHK_STREAM.search(html)
    if m:
        return m.group(1).strip()

    # Priority 2: iframe src (player embed)
    m = _RE_OHK_IFRAME.search(html)
    if m:
        return m.group(1).strip()

    return None


def get_onhockey_live_channels():
    """
    Scrape onhockey.tv for live TV channel streams (NHL Network, etc.).
    Returns list of channel dicts compatible with the unified live TV system.
    """
    ck = 'onhockey_live_ch'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    channels = []

    # Strategy 1: try dedicated live-TV section paths
    html = None
    for path in _ONHOCKEY_LIVE_PATHS:
        try:
            r = requests.get(_ONHOCKEY_BASE + path, timeout=10, headers={
                'User-Agent': HEADERS['User-Agent'],
                'Referer': 'https://www.google.com/',
            })
            if r.status_code < 400 and len(r.text) > 500:
                html = r.text
                break
        except Exception:
            pass

    if html:
        # Collect all internal channel links from the live page
        seen = set()
        for m in _RE_OHK_CHAN_LINK.finditer(html):
            href, slug, label = m.group(1).strip(), m.group(2).strip('/'), m.group(3).strip()
            if not label or slug.split('/')[0].lower() in _LIVE_CHAN_SKIP:
                continue
            if href in seen:
                continue
            seen.add(href)
            stream = _onhockey_scrape_stream(href)
            if stream:
                channels.append({
                    'id':         'onhockey_' + re.sub(r'\W+', '_', slug),
                    'title':      label,
                    'group':      'Hockey',
                    'source':     'OnHockey.tv',
                    'thumbnail':  '',
                    'stream_url': stream,
                })

    # Strategy 2: always try the NHL Network page directly if not already found
    nhl_net_names = {'nhl network', 'nhlnetwork', 'nhl net'}
    already_have_nhl_net = any(
        c['title'].lower().replace(' ', '') in {'nhlnetwork', 'nhlnet'}
        for c in channels
    )
    if not already_have_nhl_net:
        for path in ('/nhl-network', '/nhlnetwork', '/nhl-network-live', '/channels/nhl-network'):
            stream = _onhockey_scrape_stream(_ONHOCKEY_BASE + path)
            if stream:
                channels.append({
                    'id':         'onhockey_nhl_network',
                    'title':      'NHL Network',
                    'group':      'Hockey',
                    'source':     'OnHockey.tv',
                    'thumbnail':  'https://upload.wikimedia.org/wikipedia/en/thumb/1/1f/NHL_Network_logo.svg/200px-NHL_Network_logo.svg.png',
                    'stream_url': stream,
                })
                break

    xbmc.log('[Starfleet] OnHockey.tv live channels: %d' % len(channels), xbmc.LOGINFO)
    _cache.set(ck, channels, 30 * 60)
    return channels


# ── Radio-Canada / ICI Tou.tv Live Channels ──────────────────────────────────

# Official Akamaized HLS streams for Radio-Canada's free OTA channels.
# These are geo-accessible without authentication (public broadcast streams).
_RCAV_BASE = 'https://rcavlive.akamaized.net/hls/live'

_TOUTV_LIVE_CHANNELS = [
    {
        'id': 'ici-tele',
        'title': 'ICI Radio-Canada Télé',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/ICI_Radio-Canada_T%C3%A9l%C3%A9_logo.svg/200px-ICI_Radio-Canada_T%C3%A9l%C3%A9_logo.svg.png',
        'stream_url': _RCAV_BASE + '/704024/xcantelefr/master.m3u8',
    },
    {
        'id': 'ici-rdi',
        'title': 'ICI RDI',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/ICI_RDI_2021.svg/200px-ICI_RDI_2021.svg.png',
        'stream_url': _RCAV_BASE + '/704025/xcanrdifr/master.m3u8',
    },
    {
        'id': 'ici-artv',
        'title': 'ICI Artv',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/ARTV_logo.svg/200px-ARTV_logo.svg.png',
        'stream_url': _RCAV_BASE + '/704026/xcanartvfr/master.m3u8',
    },
    {
        'id': 'ici-explora',
        'title': 'ICI Explora',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Explora_logo.svg/200px-Explora_logo.svg.png',
        'stream_url': _RCAV_BASE + '/704027/xcanexplorafr/master.m3u8',
    },
    {
        'id': 'ici-tele-reg-qc',
        'title': 'ICI Télé (Québec régional)',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/ICI_Radio-Canada_T%C3%A9l%C3%A9_logo.svg/200px-ICI_Radio-Canada_T%C3%A9l%C3%A9_logo.svg.png',
        'stream_url': _RCAV_BASE + '/704052/xquebtelefr/master.m3u8',
    },
    {
        'id': 'ici-tele-reg-mtl',
        'title': 'ICI Télé (Montréal)',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/ICI_Radio-Canada_T%C3%A9l%C3%A9_logo.svg/200px-ICI_Radio-Canada_T%C3%A9l%C3%A9_logo.svg.png',
        'stream_url': _RCAV_BASE + '/704032/xmontelefr/master.m3u8',
    },
    {
        'id': 'noovo',
        'title': 'Noovo',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/Noovo_Logo.svg/200px-Noovo_Logo.svg.png',
        'stream_url': 'https://noovotv-live.akamaized.net/hls/live/2034490/noovotv/master.m3u8',
    },
    {
        'id': 'noovo-info',
        'title': 'Noovo Info',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/Noovo_Logo.svg/200px-Noovo_Logo.svg.png',
        'stream_url': 'https://noovotv-live.akamaized.net/hls/live/2034491/noovoinfo/master.m3u8',
    },
]


def get_toutv_live_channels():
    """Return Radio-Canada / ICI Tou.tv live channel list (static HLS streams)."""
    results = []
    for ch in _TOUTV_LIVE_CHANNELS:
        results.append(dict(ch, source='Tou.tv'))
    return results


# ── Free Worldwide News & Channels ───────────────────────────────────────────

_NEWS_CHANNELS = [
    # ── Global News ──────────────────────────────────────────────────────────
    {
        'id': 'aljazeera-en', 'title': 'Al Jazeera English', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/AJE_Logo.svg/200px-AJE_Logo.svg.png',
        'stream_url': 'https://live-hls-web-aje.getaj.net/AJE/index.m3u8',
    },
    {
        'id': 'france24-en', 'title': 'France 24 English', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/France_24_logo.svg/200px-France_24_logo.svg.png',
        'stream_url': 'https://f24hls-i.akamaihd.net/hls/live/221147/F24_EN_HI_HLS/master.m3u8',
    },
    {
        'id': 'dw-news', 'title': 'DW News (English)', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_symbol_2012.svg/200px-Deutsche_Welle_symbol_2012.svg.png',
        'stream_url': 'https://dwamdstream104.akamaized.net/hls/live/2015530/dwstream104/index.m3u8',
    },
    {
        'id': 'france24-fr', 'title': 'France 24 Français', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/France_24_logo.svg/200px-France_24_logo.svg.png',
        'stream_url': 'https://f24hls-i.akamaihd.net/hls/live/221143/F24_FR_HI_HLS/master.m3u8',
    },
    {
        'id': 'france24-ar', 'title': 'France 24 Arabic', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/France_24_logo.svg/200px-France_24_logo.svg.png',
        'stream_url': 'https://f24hls-i.akamaihd.net/hls/live/221149/F24_AR_HI_HLS/master.m3u8',
    },
    {
        'id': 'dw-arabic', 'title': 'DW Arabic', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_symbol_2012.svg/200px-Deutsche_Welle_symbol_2012.svg.png',
        'stream_url': 'https://dwamdstream106.akamaized.net/hls/live/2015534/dwstream106/index.m3u8',
    },
    {
        'id': 'dw-spanish', 'title': 'DW Español', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_symbol_2012.svg/200px-Deutsche_Welle_symbol_2012.svg.png',
        'stream_url': 'https://dwamdstream108.akamaized.net/hls/live/2015536/dwstream108/index.m3u8',
    },
    {
        'id': 'nasa-tv', 'title': 'NASA TV', 'group': 'Science & Space',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/NASA_logo.svg/200px-NASA_logo.svg.png',
        'stream_url': 'https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8',
    },
    {
        'id': 'bloomberg-us', 'title': 'Bloomberg Television', 'group': 'Business News',
        'thumbnail': 'https://assets.bbhub.io/company/sites/51/2019/08/bloomberg-square-logo.png',
        'stream_url': 'https://bloomberg-bloomberg.d.pluto.tv/hls/live/2038009/bloomberg/master.m3u8',
    },
    {
        'id': 'cgtn-en', 'title': 'CGTN (China Global TV)', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/CGTN_logo_2016.svg/200px-CGTN_logo_2016.svg.png',
        'stream_url': 'https://livenews.cgtn.com/media_live/W010096/playlist.m3u8',
    },
    {
        'id': 'abc-australia', 'title': 'ABC News Australia', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/ABC_News_%28Australia%29_logo_2014.svg/200px-ABC_News_%28Australia%29_logo_2014.svg.png',
        'stream_url': 'https://abcnewslive.akamaized.net/hls/live/2038056/abcnews/master.m3u8',
    },
    {
        'id': 'euronews-en', 'title': 'Euronews English', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/0/0e/Euronews_logo.svg',
        'stream_url': 'https://euronews-euronews-1-gb.samsung.wurl.com/manifest/playlist.m3u8',
    },
    {
        'id': 'ntn24', 'title': 'NTN24 (Latinoamérica)', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/NTN24.svg/200px-NTN24.svg.png',
        'stream_url': 'https://ntn24web.ultrastream.tv/ntn24/smil:live.smil/playlist.m3u8',
    },
    # ── Free Entertainment ────────────────────────────────────────────────────
    {
        'id': 'pluto-tv-movies', 'title': 'Pluto TV Movies', 'group': 'Movies',
        'thumbnail': 'https://images.pluto.tv/channels/5b2ebbc17f9b1c1e34c71063/colorLogoPNG.png',
        'stream_url': 'https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/channel/5b2ebbc17f9b1c1e34c71063/master.m3u8?deviceId=starfleet&deviceType=web&sid=starfleet',
    },
    {
        'id': 'classic-tv', 'title': 'Classic TV (Shout! Factory)', 'group': 'Entertainment',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Shout_Factory_TV_logo.png/200px-Shout_Factory_TV_logo.png',
        'stream_url': 'https://shout-sftvfastprimary.top.comcast.net/out/u/sftvprimary.m3u8',
    },
    {
        'id': 'looney-tunes', 'title': 'Boomerang (Classic Cartoons)', 'group': 'Kids',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Boomerang_2015_logo.svg/200px-Boomerang_2015_logo.svg.png',
        'stream_url': 'https://boomerang-fastonly.warnermediacdn.com/hls/live/2023800/boomerang_fastonly/master.m3u8',
    },
    {
        'id': 'bbc-reel', 'title': 'BBC World Service Radio', 'group': 'Radio/Audio',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/BBC_Logo_2021.svg/200px-BBC_Logo_2021.svg.png',
        'stream_url': 'https://stream.live.vc.bbcmedia.co.uk/bbc_world_service',
    },
    {
        'id': 'nasa-public', 'title': 'NASA TV Public', 'group': 'Science & Space',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/NASA_logo.svg/200px-NASA_logo.svg.png',
        'stream_url': 'https://ntv2.akamaized.net/hls/live/2014076/NASA-NTV2-HLS/master.m3u8',
    },
]


def get_news_channels():
    """Return hardcoded list of free worldwide news and entertainment channels."""
    results = []
    for ch in _NEWS_CHANNELS:
        results.append(dict(ch, source='Free News'))
    return results


def prewarm_news():
    pass  # static list, no prewarm needed


# ── EPG helpers ───────────────────────────────────────────────────────────────

def get_epg_urls():
    """
    Return dict of source -> XMLTV EPG URL.
    Used by the EPG export feature and pvr.iptvsimple integration.
    """
    return {
        'Samsung TV+': MJH_SAMSUNG_EPG,
        'Plex':        MJH_PLEX_EPG,
        # Pluto: EPG embedded in boot response (channel timeline arrays)
        # Starfleet:  EPG not yet captured — needs browser endpoint discovery
    }


def get_combined_m3u(include_tva_channels=None):
    """
    Generate a combined M3U playlist for ALL sources.
    This can be pointed at by pvr.iptvsimple for a full EPG experience.
    include_tva_channels: list of {'title', 'asset_key', 'thumbnail'} dicts
    """
    lines = ['#EXTM3U']

    # TVA / DAI channels — use plugin:// URL so DAI token is fetched at play time
    if include_tva_channels:
        for ch in include_tva_channels:
            plugin_url = (
                'plugin://plugin.video.starfleet/'
                '?action=play_live_dai'
                '&asset_key=%s&title=%s' % (ch['asset_key'],
                                             requests.utils.quote(ch['title']))
            )
            lines.append(
                '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Starfleet",\t%s'
                % (ch['asset_key'], ch.get('thumbnail',''), ch['title'])
            )
            lines.append(plugin_url)

    # Samsung
    for ch in get_samsung_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Samsung TV+",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch['stream_url'])

    # Plex
    for ch in get_plex_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Plex",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch['stream_url'])

    # Pluto
    for ch in get_pluto_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Pluto TV",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch.get('stream_url', ''))

    return '\n'.join(lines)
