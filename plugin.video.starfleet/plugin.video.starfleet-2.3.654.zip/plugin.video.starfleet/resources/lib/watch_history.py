# -*- coding: utf-8 -*-
"""
resources/lib/watch_history.py

Lightweight watch-progress tracker stored as JSON in the addon data directory.

Schema per entry:
  {
    "imdb_id":  "tt1234567",          # movie
    "season":   2,                    # tv (0 = movie)
    "episode":  4,                    # tv (0 = movie)
    "title":    "Breaking Bad",
    "watched":  true,                 # played past 90%
    "resume_s": 1234.5,               # resume point in seconds
    "total_s":  3600.0,
    "ts":       1719600000            # unix timestamp of last play
  }

Key = "tt1234567" for movies, "tt1234567:S02E04" for episodes.
"""

import json
import os
import re
import time
import threading
import xbmc
import xbmcvfs

_LOCK = threading.Lock()

# Every adult-source key prefix this addon ever passes as "imdb_id" — none
# of these are real IMDB ids, just opaque per-source identifiers (see each
# call site in afdb_router.py). Used to gate the Settings > Adult Section
# "Track adult watched progress" toggle (default off, per direct request)
# without touching any of those ~13 call sites individually.
_ADULT_KEY_PREFIXES = (
    'ade:', 'afdb:', 'javseen:', 'javleak:', 'javhd:', 'jav_torrent:',
    'mythav:', 'panda:', 'hqp:',
)


def _is_adult_key(imdb_id):
    return bool(imdb_id) and imdb_id.startswith(_ADULT_KEY_PREFIXES)


def _adult_tracking_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_track_watched') == 'true'
    except Exception:
        return False

def _db_path():
    from resources.lib import profiles as _profiles          # each viewer profile has its own history
    return _profiles.data_path('watch_history.json')


def _load():
    # Deliberately re-reads the file on every call rather than caching in
    # a module-level dict — confirmed live as a real bug: mark_played()/
    # toggle_watched() run inside a fresh, short-lived Python process each
    # time (every plugin:// invocation, e.g. RunPlugin or Player().play(),
    # spins up a new one), so they always see fresh state. But this
    # addon's Home/CategoryListWindow GUI runs as ONE long-lived script
    # process for the whole session (doModal() calls stay in-process
    # rather than re-invoking the plugin), so a cached dict loaded once
    # here would keep returning the pre-toggle/pre-playback state for the
    # rest of the session even after a separate process wrote a real
    # update to disk — exactly why a checkmark never appeared after
    # marking something watched and fully reopening the list. The file is
    # tiny (a personal watch-history log), so re-reading it every call
    # costs nothing worth trading correctness for.
    p = _db_path()
    try:
        if xbmcvfs.exists(p):
            with open(p, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    except Exception as e:
        # Confirmed live as a real data-loss path: a truncated/corrupt file
        # here (e.g. from a process killed mid-write during v2.3.346's
        # CPU-starvation bug) used to be silently swallowed and treated as
        # "empty" -- the very next mark_played() would then _save() that
        # empty dict right back over the file, permanently erasing every
        # entry that was actually still sitting there, just past a broken
        # byte or two. Now the corrupt file is preserved alongside a fresh
        # empty one instead of being silently overwritten into oblivion,
        # and this logs at LOGERROR (not LOGWARNING) so it's actually
        # visible rather than easy to miss.
        xbmc.log('[Starfleet/WatchHistory] load error (preserving corrupt file): %s' % e,
                 xbmc.LOGERROR)
        try:
            backup = p + '.corrupt-%d' % int(time.time())
            if xbmcvfs.exists(p) and not xbmcvfs.exists(backup):
                xbmcvfs.copy(p, backup)
        except Exception as e2:
            xbmc.log('[Starfleet/WatchHistory] could not back up corrupt file: %s' % e2,
                     xbmc.LOGERROR)
        return {}


def _save(db):
    # Atomic write: a process killed mid-write (e.g. Kodi terminating a
    # hung script, same class of issue v2.3.346's CPU-starvation bug could
    # trigger) leaves the temp file broken, never the real one -- the
    # real watch_history.json is only ever replaced in one atomic
    # filesystem rename, so it's always either the old complete version or
    # the new complete version, never a half-written in-between state.
    p = _db_path()
    tmp = p + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(db, f, indent=2)
        os.replace(tmp, p)
    except Exception as e:
        xbmc.log('[Starfleet/WatchHistory] save error: %s' % e, xbmc.LOGWARNING)


def _key(imdb_id, season=0, episode=0):
    if season and episode:
        return '%s:S%02dE%02d' % (imdb_id, int(season), int(episode))
    return imdb_id or ''


# ── Public API ────────────────────────────────────────────────────────────────

def mark_played(imdb_id, title='', season=0, episode=0,
                resume_s=0.0, total_s=0.0, watched=False, tmdb_id=None):
    """Record a play event. Call this when playback ends.

    tmdb_id, when supplied for a movie (season/episode both 0), also writes
    a second entry under key 'tmdb:<id>'. TMDB's list endpoints (Popular/
    Top Rated/etc) never expose imdb_id, only tmdb_id, so list-render code
    can't cheaply resolve the imdb_id-keyed entry above without an extra
    per-item detail API call. The duplicate tmdb-keyed entry lets
    get_progress('tmdb:%s' % tmdb_id) be checked with zero extra network
    calls, while the real imdb_id entry (and SIMKL sync, which needs a real
    imdb_id) stays exactly as before.
    """
    if not imdb_id:
        return
    if _is_adult_key(imdb_id) and not _adult_tracking_enabled():
        return
    k = _key(imdb_id, season, episode)
    with _LOCK:
        db = _load()
        prev = db.get(k, {})
        entry = {
            'imdb_id':  imdb_id,
            'tmdb_id':  tmdb_id or prev.get('tmdb_id', ''),
            'season':   int(season),
            'episode':  int(episode),
            'title':    title or prev.get('title', ''),
            'watched':  watched or prev.get('watched', False),
            'resume_s': resume_s,
            'total_s':  total_s or prev.get('total_s', 0.0),
            'ts':       int(time.time()),
        }
        if total_s and total_s > 0:
            pct = resume_s / total_s
            if pct >= 0.9:
                entry['watched'] = True
                entry['resume_s'] = 0.0  # don't resume if finished
        db[k] = entry
        if tmdb_id and not season and not episode:
            db['tmdb:%s' % tmdb_id] = dict(entry, imdb_id=imdb_id)
        _save(db)
    xbmc.log('[Starfleet/WatchHistory] marked %s watched=%s resume=%.0fs' % (
        k, entry['watched'], entry['resume_s']), xbmc.LOGINFO)

    if entry['watched']:
        # Fire to every paired service independently — each is self-gating
        # via its own is_paired() check, and these are non-destructive
        # server-side syncs, so a user who paired multiple services gets
        # all of them kept in sync rather than only the first that
        # succeeds. Three separate try/except blocks so one provider's
        # failure never blocks another's — this local watch_history write
        # always happens regardless of any of them.
        try:
            from resources.lib import simkl_sync
            if season and episode:
                simkl_sync.mark_watched_episode(imdb_id=imdb_id, title=title,
                                                season=season, episode=episode)
            else:
                simkl_sync.mark_watched_movie(imdb_id=imdb_id, title=title)
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] simkl_sync error: %s' % e, xbmc.LOGWARNING)
        try:
            from resources.lib import mdblist_sync
            if season and episode:
                mdblist_sync.mark_watched_episode(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                                  season=season, episode=episode)
            else:
                mdblist_sync.mark_watched_movie(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title)
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] mdblist_sync error: %s' % e, xbmc.LOGWARNING)
        try:
            from resources.lib import trakt_sync
            if season and episode:
                trakt_sync.mark_watched_episode(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                                season=season, episode=episode)
            else:
                trakt_sync.mark_watched_movie(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title)
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] trakt_sync error: %s' % e, xbmc.LOGWARNING)
        try:
            from resources.lib import wetrakr_sync
            if season and episode:
                wetrakr_sync.mark_watched_episode(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                                  season=season, episode=episode)
            else:
                wetrakr_sync.mark_watched_movie(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title)
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] wetrakr_sync error: %s' % e, xbmc.LOGWARNING)


def get_progress(imdb_id, season=0, episode=0):
    """
    Return (watched: bool, resume_s: float, percent: float).
    Returns (False, 0.0, 0.0) if not found.
    """
    if not imdb_id:
        return False, 0.0, 0.0
    k = _key(imdb_id, season, episode)
    with _LOCK:
        db = _load()
        entry = db.get(k)
    if not entry:
        return (_remote_watched(imdb_id, season, episode), 0.0, 0.0)
    resume_s = entry.get('resume_s', 0.0)
    total_s  = entry.get('total_s', 0.0)
    pct = (resume_s / total_s * 100) if total_s > 0 else 0.0
    if entry.get('manual'):                          # marked by hand on this device: that choice stands
        return entry.get('watched', False), resume_s, pct
    watched = entry.get('watched', False) or (resume_s == 0 and _remote_watched(imdb_id, season, episode))
    return watched, resume_s, pct


def _remote_watched(imdb_id, season=0, episode=0):
    """Watched on the paired SIMKL account (another device, another app, before this add-on kept a history)? Adult keys never
    reach SIMKL; nothing is asked when no account is paired."""
    try:
        if not re.match(r'^tt\d+$', str(imdb_id or '')):
            return False
        from resources.lib import simkl_auth, trakt_auth
        if simkl_auth.is_paired():
            from resources.lib import simkl_sync
            return simkl_sync.is_watched_remote(imdb_id=imdb_id, season=season, episode=episode)
        if trakt_auth.is_paired():
            from resources.lib import trakt_sync
            return trakt_sync.is_watched_remote(imdb_id=imdb_id, season=season, episode=episode)
        return False
    except Exception:
        return False


def _push_manual(imdb_id, tmdb_id, title, season, episodes, watched):
    """The viewer marked something watched / unwatched by hand: tell every paired tracker (SIMKL, Trakt, MDBList, WeTrakr), so
    a mark made here is on the account and shows on every other device. `episodes` is a list of episode numbers of `season`;
    for a film both are empty. Unmarking needs the tracker to support it (SIMKL and Trakt do; the other two only take marks).
    Never raises and never blocks (each tracker sends on its own thread)."""
    imdb_id = imdb_id if re.match(r'^tt\d+$', str(imdb_id or '')) else ''
    if not (imdb_id or tmdb_id):
        return
    pairs = [(int(season), int(e)) for e in (episodes or [])] if season and episodes else None
    movie = not pairs
    mods = []
    for name in ('simkl_sync', 'trakt_sync', 'mdblist_sync', 'wetrakr_sync'):
        try:
            mods.append(__import__('resources.lib.' + name, fromlist=['x']))
        except Exception:
            pass
    for m in mods:
        try:
            if watched:
                if movie:
                    m.mark_watched_movie(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title)
                else:
                    m.mark_show_watched(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title, season_episode_pairs=pairs)
            elif hasattr(m, 'unmark_watched_movie'):
                if movie:
                    m.unmark_watched_movie(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title)
                else:
                    m.unmark_show_watched(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title, season_episode_pairs=pairs)
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] manual mark -> %s: %s' % (m.__name__, e), xbmc.LOGWARNING)


def get_progress_bulk(keys):
    """Same lookup as get_progress(), but for many keys at once against a
    SINGLE file read instead of one per key — get_progress() deliberately
    re-reads the file every call (see _load()'s own docstring for why that's
    correct for the common one-lookup-per-process case), but a caller
    building a big list (e.g. Adult Full Library, ~9,500 items) calling it
    in a loop was confirmed live to turn into thousands of disk reads/JSON
    parses executed AFTER the loading dialog had already closed — a real,
    silent multi-second stall with no visual indicator, easily read as the
    screen having frozen or the load having failed. keys is an iterable of
    plain imdb_id strings (season/episode already folded in via _key() by
    the caller, if needed); returns {key: (watched, resume_s, pct)}."""
    with _LOCK:
        db = _load()
    out = {}
    for k in keys:
        entry = db.get(k)
        if not entry:
            imdb, season, episode = _split_key(k)
            out[k] = (_remote_watched(imdb, season, episode) if imdb else False, 0.0, 0.0)
            continue
        resume_s = entry.get('resume_s', 0.0)
        total_s  = entry.get('total_s', 0.0)
        pct = (resume_s / total_s * 100) if total_s > 0 else 0.0
        out[k] = (entry.get('watched', False), resume_s, pct)
    return out


def _split_key(k):
    """(imdb, season, episode) from a history key as _key() builds it ('tt123' or 'tt123:S01E02')."""
    m = re.match(r'^(tt\d+)(?::S(\d+)E(\d+))?$', str(k))
    if not m:
        return '', 0, 0
    return m.group(1), int(m.group(2) or 0), int(m.group(3) or 0)


def is_watched(imdb_id, season=0, episode=0):
    watched, _, _ = get_progress(imdb_id, season, episode)
    return watched


def get_resume(imdb_id, season=0, episode=0):
    """Return (resume_s, total_s) for building a ListItem's ResumeTime/
    TotalTime properties. Separate from get_progress() (which doesn't
    expose total_s) so its existing 3-tuple return doesn't have to change
    and break the several call sites that already unpack it. Returns
    (0.0, 0.0) when there's nothing saved — mark_played() already zeroes
    resume_s once a title crosses the 90%-played 'watched' threshold, so
    a finished title naturally resumes from the start next time too."""
    if not imdb_id:
        return 0.0, 0.0
    k = _key(imdb_id, season, episode)
    with _LOCK:
        db = _load()
        entry = db.get(k)
    if not entry:
        return 0.0, 0.0
    return entry.get('resume_s', 0.0), entry.get('total_s', 0.0)


def _remote_progress_provider():
    """Pick the single remote sync provider to consult for cross-device
    resume, in this deliberate priority order — do NOT merge/compare
    progress across multiple paired providers, only ever the one highest-
    priority paired one:

        SIMKL (if paired) -> else MDBList (if paired) -> else Trakt
        (if paired) -> else WeTrakr (if paired) -> else None (existing
        local-only behavior)

    Why this order: SIMKL is this addon's existing, most-tested continue-
    watching driver (real production history), so it stays first. MDBList
    is being added second, per this session's explicit request, so it's
    the first fallback. Trakt is being wired into sync for the first time
    ever in this addon (trakt_auth.py's own docstring used to say "nothing
    in the addon consumes the paired tokens yet") — zero production
    history — so it goes last, only consulted when neither of the other
    two is set up. WeTrakr goes after Trakt for the same "just wired in,
    zero production history" reason, and in practice never actually
    contributes here anyway — its real API has no GET endpoint to query
    saved progress from at all (see wetrakr_sync.py's docstring), so its
    get_playback_progress() is a permanent no-op stub; kept in the chain
    only so a future WeTrakr API update adding real query support would
    just start working without another code change here. Change this
    order here (and in continue_watching.py's matching provider-selection
    helper) if that priority should ever change; every other call site
    just asks "which provider is active" rather than hardcoding the order
    itself."""
    from resources.lib import simkl_auth, mdblist_auth, trakt_auth, wetrakr_auth
    from resources.lib import simkl_sync, mdblist_sync, trakt_sync, wetrakr_sync
    if simkl_auth.is_paired():
        return simkl_sync
    if mdblist_auth.is_paired():
        return mdblist_sync
    if trakt_auth.is_paired():
        return trakt_sync
    if wetrakr_auth.is_paired():
        return wetrakr_sync
    return None


def apply_resume(li, imdb_id, season=0, episode=0, tmdb_id=None):
    """Set ResumeTime/TotalTime on a ListItem right before it's played so
    Kodi's player seeks to the saved position instead of always starting
    at 0:00 — the actual missing piece behind Continue Watching: progress
    was tracked and displayed, but never applied to seek playback. No-op
    when there's no saved progress for this key.

    If a remote sync provider is paired, also checks whether a DIFFERENT
    device saved further progress on this exact title and prefers
    whichever position is further along - this is the actual cross-device
    resume payoff, not just a same-device convenience. Exactly ONE
    provider is consulted per check, picked by _remote_progress_provider()
    above (SIMKL > MDBList > Trakt > local-only) — never merged/compared
    across multiple paired providers. One real, unavoidable limitation:
    every provider's saved position is a percentage, not seconds, so
    converting it back needs a known total duration - if this device has
    never played this title before (no local total_s yet), there's nothing
    to multiply the percentage against, and the remote progress is skipped
    rather than guessed at. Once this device has played it at least once
    (local total_s gets recorded either way), remote progress from any
    other device becomes usable here from then on."""
    if _is_adult_key(imdb_id) and not _adult_tracking_enabled():
        return
    try:
        resume_s, total_s = get_resume(imdb_id, season, episode)

        try:
            provider = _remote_progress_provider()
            if provider is not None:
                remote_pct = provider.get_playback_progress(
                    imdb_id=imdb_id, tmdb_id=tmdb_id, season=season, episode=episode)
                if remote_pct is not None and total_s > 0 and remote_pct < 90:
                    remote_resume_s = total_s * remote_pct / 100.0
                    if remote_resume_s > resume_s:
                        resume_s = remote_resume_s
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] remote progress check error: %s' % e,
                     xbmc.LOGWARNING)

        if resume_s > 0 and total_s > 0:
            li.setProperty('ResumeTime', str(resume_s))
            li.setProperty('TotalTime', str(total_s))
    except Exception as e:
        xbmc.log('[Starfleet/WatchHistory] apply_resume error: %s' % e, xbmc.LOGWARNING)


def toggle_watched(imdb_id, title='', season=0, episode=0, tmdb_id=None):
    """Manual 'Mark as Watched/Unwatched' context-menu toggle — distinct from
    the automatic playback-based mark_played() above. Not gated by the
    "Track adult watched progress" toggle below — that only controls
    AUTOMATIC playback tracking; a manual mark/unmark is an explicit
    user action for organizing a favorites list, orthogonal to it."""
    if not imdb_id:
        return False
    k = _key(imdb_id, season, episode)
    shown = get_progress(imdb_id, season, episode)[0]       # what the tick shows now (this device's history or the account's)
    with _LOCK:
        db = _load()
        prev = db.get(k, {})
        new_watched = not shown
        entry = {
            'imdb_id':  imdb_id,
            'tmdb_id':  tmdb_id or prev.get('tmdb_id', ''),
            'season':   int(season),
            'episode':  int(episode),
            'title':    title or prev.get('title', ''),
            'watched':  new_watched,
            'manual':   True,
            'resume_s': 0.0 if new_watched else prev.get('resume_s', 0.0),
            'total_s':  prev.get('total_s', 0.0),
            'ts':       int(time.time()),
        }
        db[k] = entry
        if tmdb_id and not season and not episode:
            db['tmdb:%s' % tmdb_id] = dict(entry, imdb_id=imdb_id)
        _save(db)
    if not _is_adult_key(imdb_id):
        _push_manual(imdb_id, tmdb_id, entry['title'], season, [episode] if (season and episode) else [], new_watched)
    return new_watched


def mark_season_watched(imdb_id, season, episode_numbers, title='', tmdb_id=None):
    """Bulk 'Mark Season as Watched/Unwatched' — per direct request, so a
    whole season can be toggled from the season picker itself instead of
    one episode at a time. Sets EVERY episode in episode_numbers to the
    SAME target state in one write, rather than toggling each
    independently against its own prior state. The target is decided once,
    up front: if every given episode is already watched, this UNMARKS the
    whole season; otherwise it marks every episode watched (a season
    that's mostly done needs one long-press to finish it, not one per
    remaining episode). Returns the new state (True = now all watched)."""
    if not imdb_id or not episode_numbers:
        return False
    shown = get_progress_bulk([_key(imdb_id, season, ep) for ep in episode_numbers])
    all_watched = all(v[0] for v in shown.values())          # as the ticks show them (history or the account)
    with _LOCK:
        db = _load()
        new_watched = not all_watched
        ts = int(time.time())
        for ep in episode_numbers:
            k = _key(imdb_id, season, ep)
            prev = db.get(k, {})
            db[k] = {
                'imdb_id':  imdb_id,
                'tmdb_id':  tmdb_id or prev.get('tmdb_id', ''),
                'season':   int(season),
                'episode':  int(ep),
                'title':    prev.get('title', '') or title,
                'watched':  new_watched,
                'manual':   True,
                'resume_s': 0.0 if new_watched else prev.get('resume_s', 0.0),
                'total_s':  prev.get('total_s', 0.0),
                'ts':       ts,
            }
        _save(db)
    if not _is_adult_key(imdb_id):
        _push_manual(imdb_id, tmdb_id, title, season, list(episode_numbers), new_watched)
    return new_watched


def mark_episodes_watched(imdb_id, season_episode_pairs, title='', tmdb_id=None):
    """Force EVERY given (season, episode) pair to watched=True in one
    write, spanning as many different seasons as needed — unlike
    mark_season_watched, this is NOT a toggle: it always marks forward,
    never unmarks. Built for continue_watching.dismiss_show(), which
    needs to guarantee a show has genuinely nothing left to anchor a new
    "next episode" on — calling the toggle-based mark_season_watched
    once per season independently would risk UNMARKING a season that
    happened to already be fully watched (exactly the season a real
    Continue Watching entry is usually paused just past), which is the
    opposite of what "dismiss this show for good" means."""
    if not imdb_id or not season_episode_pairs:
        return
    with _LOCK:
        db = _load()
        ts = int(time.time())
        for season, ep in season_episode_pairs:
            k = _key(imdb_id, season, ep)
            prev = db.get(k, {})
            db[k] = {
                'imdb_id':  imdb_id,
                'tmdb_id':  tmdb_id or prev.get('tmdb_id', ''),
                'season':   int(season),
                'episode':  int(ep),
                'title':    prev.get('title', '') or title,
                'watched':  True,
                'resume_s': 0.0,
                'total_s':  prev.get('total_s', 0.0),
                'ts':       ts,
            }
        _save(db)


def clear_non_adult():
    """Wipes every movie/TV entry (anything NOT one of the adult-source
    prefixes above) — used by simkl_auth.py's post-pairing prompt to let a
    user start fresh with SIMKL as the sole source of truth for Continue
    Watching, without touching unrelated adult-content progress (SIMKL
    doesn't track adult content at all — see simkl_sync.py's _real_imdb()
    filter — so there'd be nothing for it to replace there anyway). Returns
    the number of entries removed."""
    with _LOCK:
        db = _load()
        keep = {k: e for k, e in db.items() if _is_adult_key(k)}
        removed = len(db) - len(keep)
        _save(keep)
    return removed


def progress_label(imdb_id, season=0, episode=0):
    """Return a short label suffix like ' [✓]' or ' [47%]' or ''."""
    watched, resume_s, pct = get_progress(imdb_id, season, episode)
    if watched:
        return ' [W]'
    if resume_s > 60:
        return ' [%.0f%%]' % pct
    return ''


def start_playback_monitor(imdb_id, title='', season=0, episode=0, tmdb_id=None,
                           on_finished=None):
    """
    Spawn a daemon thread that watches Kodi's player and records progress
    when playback stops.  Call this right after launching playback.

    on_finished(finished: bool), if given, is called once playback stops —
    'finished' uses the same >=90%-played threshold as the 'watched' flag,
    so a manual early stop never triggers it. Used for TV auto-play-next:
    this module deliberately stays agnostic to what "next" even means (no
    tmdb_id/season/episode-list lookups here), so the caller — which
    already knows that context — decides what to do via the callback.
    """
    if _is_adult_key(imdb_id) and not _adult_tracking_enabled():
        return

    def _monitor():
        player = xbmc.Player()
        monitor = xbmc.Monitor()

        # Wait up to 15s for playback to start
        for _ in range(150):
            if player.isPlaying():
                break
            if monitor.waitForAbort(0.1):
                return

        if not player.isPlaying():
            return

        start_total = player.getTotalTime()
        start_pos   = player.getTime()
        start_pct   = (start_pos / start_total * 100) if start_total > 0 else 0.0
        try:
            from resources.lib import simkl_sync
            simkl_sync.scrobble_start(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                      season=season, episode=episode, progress=start_pct)
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] simkl scrobble_start error: %s' % e, xbmc.LOGWARNING)
        try:
            from resources.lib import mdblist_sync
            mdblist_sync.scrobble_start(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                        season=season, episode=episode, progress=start_pct)
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] mdblist scrobble_start error: %s' % e, xbmc.LOGWARNING)
        try:
            from resources.lib import trakt_sync
            trakt_sync.scrobble_start(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                      season=season, episode=episode, progress=start_pct)
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] trakt scrobble_start error: %s' % e, xbmc.LOGWARNING)
        try:
            from resources.lib import wetrakr_sync
            wetrakr_sync.scrobble_start(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                        season=season, episode=episode, progress=start_pct)
        except Exception as e:
            xbmc.log('[Starfleet/WatchHistory] wetrakr scrobble_start error: %s' % e, xbmc.LOGWARNING)

        # Poll until playback ends, capturing position on EVERY iteration
        # while still playing — confirmed live as the real reason both
        # "mark watched after actually finishing" and TV auto-play-next
        # silently never fired: this used to only call getTotalTime()/
        # getTime() once, AFTER the loop exited (i.e. after isPlaying()
        # already went False). Kodi's Player API throws once playback has
        # actually stopped ("no active file"), which the except below
        # swallowed into total_s=resume_s=0.0 every single time — so
        # `if total_s > 0` below, and finished's own total_s>0 check in
        # metadata_router.py's _on_finished, were both permanently False
        # regardless of how the episode/movie actually ended. Now total_s/
        # resume_s hold whatever was last read WHILE playing, which is
        # still accurate — Kodi only pauses/stops in whole seconds, this
        # loop only misses at most the last ~5s of a normal finish.
        total_s = resume_s = 0.0
        last_ping = time.time()
        while player.isPlaying() and not monitor.abortRequested():
            try:
                total_s  = player.getTotalTime()
                resume_s = player.getTime()
            except Exception:
                pass
            # WeTrakr shows a live "Now Playing" session from periodic updates (about every 30 s, not while paused)
            if total_s > 0 and time.time() - last_ping >= 30:
                last_ping = time.time()
                if not xbmc.getCondVisibility('Player.Paused'):
                    try:
                        from resources.lib import wetrakr_sync
                        wetrakr_sync.scrobble_progress(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                                       season=season, episode=episode,
                                                       progress=resume_s / total_s * 100)
                    except Exception as e:
                        xbmc.log('[Starfleet/WatchHistory] wetrakr progress error: %s' % e, xbmc.LOGWARNING)
            monitor.waitForAbort(5)

        if total_s > 0:
            mark_played(imdb_id, title=title, season=season, episode=episode,
                        resume_s=resume_s, total_s=total_s, tmdb_id=tmdb_id)
            pct = resume_s / total_s * 100
            try:
                from resources.lib import simkl_sync
                if pct >= 80:
                    simkl_sync.scrobble_stop(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                             season=season, episode=episode, progress=pct)
                else:
                    simkl_sync.scrobble_pause(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                              season=season, episode=episode, progress=pct)
            except Exception as e:
                xbmc.log('[Starfleet/WatchHistory] simkl scrobble end error: %s' % e, xbmc.LOGWARNING)
            try:
                from resources.lib import mdblist_sync
                if pct >= 80:
                    mdblist_sync.scrobble_stop(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                               season=season, episode=episode, progress=pct)
                else:
                    mdblist_sync.scrobble_pause(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                                season=season, episode=episode, progress=pct)
            except Exception as e:
                xbmc.log('[Starfleet/WatchHistory] mdblist scrobble end error: %s' % e, xbmc.LOGWARNING)
            try:
                from resources.lib import trakt_sync
                if pct >= 80:
                    trakt_sync.scrobble_stop(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                             season=season, episode=episode, progress=pct)
                else:
                    trakt_sync.scrobble_pause(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                              season=season, episode=episode, progress=pct)
            except Exception as e:
                xbmc.log('[Starfleet/WatchHistory] trakt scrobble end error: %s' % e, xbmc.LOGWARNING)
            try:
                from resources.lib import wetrakr_sync
                if pct >= 80:
                    wetrakr_sync.scrobble_stop(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                               season=season, episode=episode, progress=pct)
                    # optional 1-10 rating prompt - on its own thread so auto-play-next is never held up by a dialog
                    threading.Thread(target=wetrakr_sync.prompt_rating, daemon=True,
                                     kwargs=dict(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                                 season=season, episode=episode)).start()
                else:
                    wetrakr_sync.scrobble_pause(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
                                                season=season, episode=episode, progress=pct)
            except Exception as e:
                xbmc.log('[Starfleet/WatchHistory] wetrakr scrobble end error: %s' % e, xbmc.LOGWARNING)

        if on_finished:
            finished = total_s > 0 and (resume_s / total_s) >= 0.9
            try:
                on_finished(finished)
            except Exception as e:
                xbmc.log('[Starfleet/WatchHistory] on_finished callback: %s' % e, xbmc.LOGWARNING)

    t = threading.Thread(target=_monitor, daemon=True)
    t.start()
