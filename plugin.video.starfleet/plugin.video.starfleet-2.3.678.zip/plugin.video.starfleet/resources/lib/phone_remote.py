# -*- coding: utf-8 -*-
"""
resources/lib/phone_remote.py

Phone as remote: while it is on (Settings > Phone Remote), the service answers on the home network with a small page. A phone that opens
the address (or scans its QR code) gets a search box, the trending titles and the episodes of a show; choosing something sends it to Kodi,
which opens it and plays it. Every request carries a 4-digit pairing code (shown in Settings), nothing leaves the home network, and it is
off until switched on. Same page and rules as the HazMat TV app's phone remote. Voice search: the phone keyboard's own microphone key
dictates into the search box.
"""
import json
import os
import random
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse

import xbmc
import xbmcaddon
import xbmcgui

BASE_PORT = 8765
_server = None
_port = 0
_fail = 0
_locked_until = 0.0


def _log(msg):
    xbmc.log('[Starfleet/PhoneRemote] %s' % msg, xbmc.LOGINFO)


def _addon():
    return xbmcaddon.Addon('plugin.video.starfleet')


def enabled():
    try:
        return _addon().getSetting('phone_remote') == 'true'
    except Exception:
        return False


def code():
    """The 4-digit pairing code (made the first time it is asked for)."""
    a = _addon()
    c = a.getSetting('phone_remote_code')
    if not (c and c.isdigit() and len(c) == 4):
        c = '%04d' % random.SystemRandom().randrange(10000)
        a.setSetting('phone_remote_code', c)
    return c


def new_code():
    _addon().setSetting('phone_remote_code', '')
    return code()


def address():
    """This device's address on the home network (None without one)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
        return ip if ip and not ip.startswith('127.') else None
    except Exception:
        return None
    finally:
        s.close()


def url():
    ip = address()
    if not ip or not _port:
        return None
    return 'http://%s:%d/?k=%s' % (ip, _port, code())


# ── data (TMDB through the add-on's own metadata module) ───────────────────────────────────────────────────────────

def _items(movies, shows):
    out, seen = [], set()
    for tv, lst in ((False, movies), (True, shows)):
        for m in (lst or [])[:14]:
            tid = str(m.get('tmdb_id') or '')
            if not tid or (tid, tv) in seen or m.get('media_type') == 'person':
                continue
            seen.add((tid, tv))
            out.append({'id': tid, 'tv': tv, 'title': m.get('title') or m.get('name') or '', 'year': m.get('year') or '', 'poster': m.get('thumb') or ''})
    return out


def _api(path, q):
    if path != '/api/play':
        from resources.lib import metadata as md
    if path == '/api/search':
        text = (q.get('q') or '').strip()
        if len(text) < 2:
            return []
        return _items(md.search_movies(text), md.search_tv(text))
    if path == '/api/trending':
        return _items(md.get_movies_trending(), md.get_tv_popular())
    if path == '/api/seasons':
        show = md.get_tv_detail(q.get('id', '')) or {}
        return [s.get('season') for s in show.get('seasons', []) if s.get('season') not in (None, 0, '0')]
    if path == '/api/episodes':
        eps = md.get_episodes(q.get('id', ''), int(q.get('s') or 1)) or []
        return [{'n': e.get('episode'), 'name': e.get('title') or ''} for e in eps]
    if path == '/api/play':
        tid = q.get('id', '')
        if not tid:
            return {'error': 'No title'}
        tv = q.get('tv') == '1'
        s, e = int(q.get('s') or 0), int(q.get('e') or 0)
        if tv and not (s and e):
            return {'error': 'Pick an episode'}
        title = q.get('title', '')
        if tv:
            query = 'action=meta_ep_play&tmdb_id=%s&season_num=%d&episode_num=%d&title=%s&year=%s' % (
                tid, s, e, quote('%s S%02dE%02d' % (title, s, e)), q.get('year', ''))
        else:
            query = 'action=meta_movie_play&tmdb_id=%s&title=%s&year=%s' % (tid, quote(title), q.get('year', ''))
        xbmc.executebuiltin('PlayMedia(plugin://plugin.video.starfleet/?%s)' % query)
        return {'ok': True}
    return {'error': 'Unknown'}


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, status, ctype, body):
        data = body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global _fail, _locked_until
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path in ('/', '/index.html'):
            return self._send(200, 'text/html; charset=utf-8', PAGE)
        if not u.path.startswith('/api/'):
            return self._send(404, 'text/plain', 'Not found')
        now = time.time()
        if now < _locked_until:
            return self._send(429, 'application/json', '{"error":"Too many wrong codes - wait a minute"}')
        if q.get('k') != code():
            _fail += 1
            if _fail >= 10:
                _fail, _locked_until = 0, now + 60
            return self._send(403, 'application/json', '{"error":"Wrong code"}')
        _fail = 0
        try:
            body = _api(u.path, q)
        except Exception as e:
            _log('%s: %s' % (u.path, e))
            body = {'error': 'Failed'}
        self._send(200, 'application/json', json.dumps(body))


def start():
    global _server, _port
    if _server or not enabled():
        return
    for p in range(BASE_PORT, BASE_PORT + 10):
        try:
            _server = ThreadingHTTPServer(('0.0.0.0', p), _Handler)
            _port = p
            break
        except OSError:
            continue
    if not _server:
        _log('no free port')
        return
    _server.daemon_threads = True
    threading.Thread(target=_server.serve_forever, daemon=True, name='starfleet-phone-remote').start()
    _log('listening on %d' % _port)


def stop():
    global _server, _port
    if _server:
        try:
            _server.shutdown()
            _server.server_close()
        except Exception:
            pass
    _server, _port = None, 0


def sync():
    """Start or stop the server to match the setting (called at start-up and when settings change)."""
    if enabled():
        start()
    else:
        stop()


def show_link():
    """Settings > Phone Remote > Show the address: the QR code and the code to type."""
    if not enabled():
        xbmcgui.Dialog().ok('Phone remote', 'Switch "Phone as remote" on first.')
        return
    sync()
    link = url()
    if not link:
        xbmcgui.Dialog().ok('Phone remote', 'No home network found (is this device on Wi-Fi or Ethernet?).')
        return
    from resources.lib.gui import qr_dialog as _q
    path = _q.make_qr(link, 'starfleet_phone_remote_qr.png')
    if not path:
        xbmcgui.Dialog().textviewer('Phone remote', 'Open this on your phone (same Wi-Fi):\n\n%s\n\nCode: %s' % (link.split('?')[0], code()))
        return
    dlg = _q.QRDialog(path, 'Phone remote', 'Scan with the phone camera, or open %s' % link.split('?')[0], code=code())
    dlg.update('Search on the phone, choose a title: it plays here.')
    dlg.doModal()


PAGE = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Starfleet remote</title><style>
body{margin:0;background:#0f171e;color:#e6edf3;font-family:system-ui,sans-serif}
header{position:sticky;top:0;background:#161b22;padding:12px;border-bottom:1px solid #30363d}
input{width:100%;box-sizing:border-box;padding:12px;border-radius:8px;border:1px solid #30363d;background:#0f171e;color:#e6edf3;font-size:17px}
#msg{padding:10px 14px;color:#ff8c00}
.card{display:flex;gap:12px;padding:10px 14px;border-bottom:1px solid #21262d;align-items:center}
.card img{width:56px;height:84px;object-fit:cover;border-radius:6px;background:#21262d}
.card .t{flex:1}.card .t b{display:block;font-size:16px}.card .t span{color:#8b949e;font-size:13px}
button{background:#ff8c00;border:0;color:#0f171e;font-weight:700;padding:10px 14px;border-radius:8px;font-size:15px}
button.s{background:#21262d;color:#e6edf3;font-weight:500;margin:4px 4px 0 0;padding:8px 12px}
.eps{padding:6px 14px 12px}
</style></head><body>
<header><input id="q" placeholder="Search a movie or show (tap the keyboard's mic to speak)..." autocomplete="off" enterkeyhint="search"></header>
<div id="msg"></div><div id="list"></div>
<script>
var K=new URLSearchParams(location.search).get('k')||sessionStorage.getItem('k')||'';
if(!K){K=prompt('Code shown on the TV (Settings > Phone Remote)')||''}
sessionStorage.setItem('k',K);
var list=document.getElementById('list'),msg=document.getElementById('msg'),timer=null;
function api(p,a){var u='/api/'+p+'?k='+encodeURIComponent(K);for(var x in a||{})u+='&'+x+'='+encodeURIComponent(a[x]);return fetch(u).then(function(r){return r.json()})}
function say(t){msg.textContent=t||''}
function el(tag,txt,cls){var e=document.createElement(tag);if(txt!=null)e.textContent=txt;if(cls)e.className=cls;return e}
function show(items){list.innerHTML='';if(items.error){say(items.error);return}say(items.length?'':'Nothing found');
items.forEach(function(h){var c=el('div',null,'card'),i=el('img');if(h.poster)i.src=h.poster;c.appendChild(i);
var t=el('div',null,'t');t.appendChild(el('b',h.title));t.appendChild(el('span',(h.tv?'Show':'Movie')+(h.year?' - '+h.year:'')));c.appendChild(t);
var b=el('button',h.tv?'Episodes':'Play on TV');b.onclick=function(){h.tv?episodes(h,c):play(h,0,0)};c.appendChild(b);list.appendChild(c)})}
function play(h,s,e){api('play',{id:h.id,tv:h.tv?1:0,s:s,e:e,title:h.title,year:h.year}).then(function(r){say(r.ok?'Sent to Kodi: '+h.title+(s?' S'+s+'E'+e:''):(r.error||'Failed'))})}
function episodes(h,card){var old=card.nextSibling;if(old&&old.className==='eps'){old.remove();return}
var box=el('div',null,'eps');card.after(box);api('seasons',{id:h.id}).then(function(ss){if(!ss.length){box.appendChild(el('span','No seasons listed'));return}
ss.forEach(function(n){var b=el('button','Season '+n,'s');b.onclick=function(){box.querySelectorAll('.ep').forEach(function(x){x.remove()});
api('episodes',{id:h.id,s:n}).then(function(es){es.forEach(function(x){var e=el('button',x.n+'. '+x.name,'s ep');e.style.display='block';e.style.width='100%';e.style.textAlign='left';e.onclick=function(){play(h,n,x.n)};box.appendChild(e)})})};box.appendChild(b)})})}
document.getElementById('q').addEventListener('input',function(e){clearTimeout(timer);var v=e.target.value;timer=setTimeout(function(){v.length<2?trending():api('search',{q:v}).then(show)},350)});
function trending(){say('Trending');api('trending').then(function(r){show(r);if(!r.error)say('Trending this week')})}
trending();
</script></body></html>"""
