"""
Starfleet Browse Window — horizontal-row poster grid for movie/TV sections.
Uses the same proven list-control approach as the home carousel.
"""
import xbmc
import xbmcgui
import xbmcaddon

try:
    _ADDON = xbmcaddon.Addon('plugin.video.starfleet')
except Exception:
    _ADDON = None

_ID_NAV_MOV = 41
_ID_NAV_TV  = 42
_ID_NAV_SPT = 43
_ID_NAV_LIV = 44
_ID_NAV_ADU = 45

# 4 horizontal list rows; each holds up to 15 items
_ROW_IDS    = [100, 200, 300, 400]
_ROW_SIZE   = 15


class BrowseWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        self._items = kwargs.pop('items', [])
        self._title = kwargs.pop('title', '')
        super(BrowseWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            self.setProperty('sf_browse_title', self._title)
            self._populate()
            self.setFocusId(_ROW_IDS[0])
        except Exception as e:
            xbmc.log('[Starfleet/Browse] onInit: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                   xbmcgui.ACTION_STOP, xbmcgui.ACTION_PARENT_DIR):
            self.close()

    def onClick(self, cid):
        try:
            if cid in _ROW_IDS:
                row_idx = _ROW_IDS.index(cid)
                ctrl    = self.getControl(cid)
                pos     = ctrl.getSelectedPosition()
                abs_pos = row_idx * _ROW_SIZE + pos
                if 0 <= abs_pos < len(self._items):
                    self._play_film(self._items[abs_pos])
            elif cid == _ID_NAV_MOV:
                self._nav('meta_movies_menu')
            elif cid == _ID_NAV_TV:
                self._nav('meta_tv_menu')
            elif cid == _ID_NAV_SPT:
                self._nav('sports_menu')
            elif cid == _ID_NAV_LIV:
                self._nav('live_menu')
            elif cid == _ID_NAV_ADU:
                self._nav('adult_movies_library')
        except Exception as e:
            xbmc.log('[Starfleet/Browse] onClick %d: %s' % (cid, e), xbmc.LOGERROR)

    def _populate(self):
        # Fetch up to 4 pages worth so all 4 rows have content
        items = self._items
        for row_idx, list_id in enumerate(_ROW_IDS):
            chunk = items[row_idx * _ROW_SIZE : (row_idx + 1) * _ROW_SIZE]
            ctrl  = self.getControl(list_id)
            ctrl.reset()
            for item in chunk:
                li = xbmcgui.ListItem(label=item.get('title', ''))
                li.setArt({
                    'thumb':  item.get('thumb', ''),
                    'fanart': item.get('fanart', item.get('thumb', '')),
                })
                ctrl.addItem(li)
            xbmc.log('[Starfleet/Browse] row %d: %d items' % (row_idx, len(chunk)), xbmc.LOGINFO)

    def _play_film(self, film):
        media   = film.get('media_type', 'movie')
        tmdb_id = str(film.get('tmdb_id', film.get('id', '')))
        if media == 'tv':
            cmd = "ActivateWindow(Videos,plugin://plugin.video.starfleet/?action=meta_tv_show&tmdb_id=%s)" % tmdb_id
        else:
            cmd = "ActivateWindow(Videos,plugin://plugin.video.starfleet/?action=meta_movie_detail&tmdb_id=%s)" % tmdb_id
        xbmc.executebuiltin(cmd)

    def _nav(self, action):
        xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.starfleet/?action=%s)' % action)
