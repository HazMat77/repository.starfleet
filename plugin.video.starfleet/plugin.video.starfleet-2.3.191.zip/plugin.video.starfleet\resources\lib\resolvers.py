﻿# -*- coding: utf-8 -*-
"""
resources/lib/resolvers.py

Premium link resolver integration.

Supported services:
  Real-Debrid   — https://real-debrid.com  (API v2)
  AllDebrid     — https://alldebrid.com    (API v4)
  Premiumize    — https://premiumize.me    (API v3)
  ResolveURL    — Kodi addon fallback      (50+ hosters)

Resolution priority (configurable in Settings → Premium Services):
  1. Real-Debrid  (if enabled + key set)
  2. AllDebrid    (if enabled + key set)
  3. Premiumize   (if enabled + key set)
  4. ResolveURL   (if installed)
  5. Direct URL   (fallback — plays as-is)

Each resolver checks if the URL is supported before attempting,
so unsupported URLs fall through cleanly to the next resolver.
"""

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

# ── Credentials & settings ────────────────────────────────────────────────────

def _rd_key():   return ADDON.getSetting('rd_api_key').strip()
def _ad_key():   return ADDON.getSetting('ad_api_key').strip()
def _pm_key():   return ADDON.getSetting('pm_api_key').strip()
def _tb_key():   return ADDON.getSetting('tb_api_key').strip()
def _rd_on():    return ADDON.getSetting('rd_enabled')  == 'true' and bool(_rd_key())
def _ad_on():    return ADDON.getSetting('ad_enabled')  == 'true' and bool(_ad_key())
def _pm_on():    return ADDON.getSetting('pm_enabled')  == 'true' and bool(_pm_key())
def _tb_on():    return ADDON.getSetting('tb_enabled')  == 'true' and bool(_tb_key())
def _priority(): return int(ADDON.getSetting('resolver_priority') or 4)

import requests as _req

_HEADERS = {'User-Agent': 'plugin.video.starfleet/1.0'}


# ── Real-Debrid ───────────────────────────────────────────────────────────────

RD_BASE = 'https://api.real-debrid.com/rest/1.0'

def _rd_unrestrict(url):
    """
    POST to Real-Debrid /unrestrict/link → returns direct download URL.
    Supports: 1Fichier, Mega, Rapidgator, Uptobox, and 200+ others.
    """
    try:
        r = _req.post(
            RD_BASE + '/unrestrict/link',
            data={'link': url},
            headers={**_HEADERS, 'Authorization': 'Bearer %s' % _rd_key()},
            timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            link = data.get('download', '')
            if link:
                xbmc.log('[Starfleet] Real-Debrid resolved: %s' % link[:60], xbmc.LOGINFO)
                return link
            xbmc.log('[Starfleet] Real-Debrid: no download link in response', xbmc.LOGWARNING)
        elif r.status_code == 401:
            xbmc.log('[Starfleet] Real-Debrid: invalid API key', xbmc.LOGERROR)
        elif r.status_code == 403:
            xbmc.log('[Starfleet] Real-Debrid: hoster not supported or traffic exhausted',
                     xbmc.LOGWARNING)
        else:
            xbmc.log('[Starfleet] Real-Debrid HTTP %d: %s' % (r.status_code, r.text[:100]),
                     xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] Real-Debrid error: %s' % e, xbmc.LOGERROR)
    return None


def _rd_supported_hosts():
    """Cache of hosts RD supports — checked once per session."""
    try:
        r = _req.get(
            RD_BASE + '/hosts/domains',
            headers={**_HEADERS, 'Authorization': 'Bearer %s' % _rd_key()},
            timeout=8
        )
        if r.status_code == 200:
            return r.json()   # list of domain strings
    except Exception:
        pass
    return []


# ── AllDebrid ─────────────────────────────────────────────────────────────────

AD_BASE = 'https://api.alldebrid.com/v4'

def _ad_unrestrict(url):
    """POST to AllDebrid /link/unlock → returns direct stream URL."""
    try:
        r = _req.get(
            AD_BASE + '/link/unlock',
            params={'agent': 'starfleet', 'apikey': _ad_key(), 'link': url},
            headers=_HEADERS,
            timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                link = data.get('data', {}).get('link', '')
                if link:
                    xbmc.log('[Starfleet] AllDebrid resolved: %s' % link[:60], xbmc.LOGINFO)
                    return link
            else:
                err = data.get('error', {}).get('message', 'unknown error')
                xbmc.log('[Starfleet] AllDebrid error: %s' % err, xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] AllDebrid error: %s' % e, xbmc.LOGERROR)
    return None


# ── Premiumize ────────────────────────────────────────────────────────────────

PM_BASE = 'https://www.premiumize.me/api'

def _pm_unrestrict(url):
    """POST to Premiumize /transfer/directdl → returns direct stream URL."""
    try:
        r = _req.post(
            PM_BASE + '/transfer/directdl',
            data={'apikey': _pm_key(), 'src': url},
            headers=_HEADERS,
            timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                # Premiumize returns a list of content items
                content = data.get('content', [])
                if content:
                    link = content[0].get('stream_link') or content[0].get('link', '')
                    if link:
                        xbmc.log('[Starfleet] Premiumize resolved: %s' % link[:60],
                                 xbmc.LOGINFO)
                        return link
            else:
                xbmc.log('[Starfleet] Premiumize: %s' % data.get('message', ''),
                         xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] Premiumize error: %s' % e, xbmc.LOGERROR)
    return None


# ── TorBox ────────────────────────────────────────────────────────────────────

TB_BASE = 'https://api.torbox.app/v1/api'

def _tb_unrestrict(url):
    """POST to TorBox /link/unblock → returns direct stream URL."""
    try:
        r = _req.post(
            TB_BASE + '/link/unblock',
            json={'link': url},
            headers={**_HEADERS, 'Authorization': 'Bearer %s' % _tb_key()},
            timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            if data.get('success'):
                # TorBox returns data as a direct URL string
                link = data.get('data', '')
                if isinstance(link, dict):
                    link = link.get('url', link.get('link', ''))
                if link:
                    xbmc.log('[Starfleet] TorBox resolved: %s' % str(link)[:60], xbmc.LOGINFO)
                    return link
                xbmc.log('[Starfleet] TorBox: success but no link in response', xbmc.LOGWARNING)
            else:
                detail = data.get('detail', 'unknown error')
                xbmc.log('[Starfleet] TorBox: %s' % detail, xbmc.LOGWARNING)
        elif r.status_code == 401:
            xbmc.log('[Starfleet] TorBox: invalid API key', xbmc.LOGERROR)
        else:
            xbmc.log('[Starfleet] TorBox HTTP %d: %s' % (r.status_code, r.text[:100]),
                     xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] TorBox error: %s' % e, xbmc.LOGERROR)
    return None


# ── ResolveURL (Kodi addon fallback) ─────────────────────────────────────────

def _resolveurl(url):
    """Try Kodi's ResolveURL addon as last-resort resolver."""
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            resolved = hmf.resolve()
            if resolved:
                xbmc.log('[Starfleet] ResolveURL resolved: %s' % str(resolved)[:60],
                         xbmc.LOGINFO)
                return resolved
    except ImportError:
        xbmc.log('[Starfleet] ResolveURL not installed', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet] ResolveURL error: %s' % e, xbmc.LOGWARNING)
    return None


# ── Main public resolver ──────────────────────────────────────────────────────

def resolve(url):
    """
    Attempt to resolve a URL through enabled premium services in priority order.
    Returns resolved direct URL, or original URL if nothing resolves it.

    Priority order (from Settings → Premium Services):
      0 = Real-Debrid first
      1 = AllDebrid first
      2 = Premiumize first
      3 = TorBox first
      4 = ResolveURL auto (tries all enabled, no preference)
    """
    if not url:
        return url

    # Direct URLs (already a stream — m3u8, mp4, etc.) skip resolvers
    if _is_direct(url):
        xbmc.log('[Starfleet] Direct URL — skipping resolvers', xbmc.LOGINFO)
        return url

    priority = _priority()

    # Build ordered resolver list based on settings priority
    resolvers = []

    _all_premium = [
        ('Real-Debrid', _rd_unrestrict, _rd_on),
        ('AllDebrid',   _ad_unrestrict, _ad_on),
        ('Premiumize',  _pm_unrestrict, _pm_on),
        ('TorBox',      _tb_unrestrict, _tb_on),
    ]

    if priority < len(_all_premium):
        # Put chosen resolver first, then the rest
        chosen = _all_premium[priority]
        if chosen[2]():
            resolvers.append((chosen[0], chosen[1]))
        for name, fn, check in _all_premium:
            if name != chosen[0] and check():
                resolvers.append((name, fn))
    else:
        # ResolveURL auto — try all enabled premium services first
        for name, fn, check in _all_premium:
            if check():
                resolvers.append((name, fn))

    # Always add ResolveURL as final fallback
    resolvers.append(('ResolveURL', _resolveurl))

    for name, fn in resolvers:
        xbmc.log('[Starfleet] Trying resolver: %s for %s' % (name, url[:60]), xbmc.LOGINFO)
        result = fn(url)
        if result:
            return result

    # Nothing resolved — return original URL and let Kodi try directly
    xbmc.log('[Starfleet] No resolver succeeded — playing direct: %s' % url[:60],
             xbmc.LOGWARNING)
    return url


def _is_direct(url):
    """Return True if the URL looks like a direct streamable file."""
    direct_exts   = ('.m3u8', '.mp4', '.mkv', '.avi', '.mov', '.ts',
                     '.mpd', '.f4v', '.flv', '.webm')
    direct_hosts  = ('akamaized.net', 'cdn.', 'cloudfront.net',
                     'dai.google.com', 'pluto.tv', 'plex.tv',
                     'samsung.com', 'plutotv.com')
    url_lower = url.lower()
    if any(url_lower.endswith(ext) or (ext + '?') in url_lower
           for ext in direct_exts):
        return True
    if any(h in url_lower for h in direct_hosts):
        return True
    return False


# ── Account info helpers (for settings display) ───────────────────────────────

def check_rd():
    """Return Real-Debrid account info dict or None."""
    if not _rd_on():
        return None
    try:
        r = _req.get(
            RD_BASE + '/user',
            headers={**_HEADERS, 'Authorization': 'Bearer %s' % _rd_key()},
            timeout=8
        )
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None


def check_ad():
    """Return AllDebrid user info dict or None."""
    if not _ad_on():
        return None
    try:
        r = _req.get(
            AD_BASE + '/user',
            params={'agent': 'starfleet', 'apikey': _ad_key()},
            headers=_HEADERS,
            timeout=8
        )
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                return data.get('data', {}).get('user', {})
    except Exception:
        pass
    return None


def check_pm():
    """Return Premiumize account info dict or None."""
    if not _pm_on():
        return None
    try:
        r = _req.get(
            PM_BASE + '/account/info',
            params={'apikey': _pm_key()},
            headers=_HEADERS,
            timeout=8
        )
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                return data
    except Exception:
        pass
    return None


def check_tb():
    """Return TorBox user info dict or None."""
    if not _tb_on():
        return None
    try:
        r = _req.get(
            TB_BASE + '/user/me',
            params={'settings': 'false'},
            headers={**_HEADERS, 'Authorization': 'Bearer %s' % _tb_key()},
            timeout=8
        )
        if r.status_code == 200:
            data = r.json()
            if data.get('success'):
                return data.get('data', {})
    except Exception:
        pass
    return None


def show_account_status():
    """Show a dialog with status of all enabled premium services."""
    lines = ['[B]Premium Service Status[/B]\n']

    if _rd_on():
        info = check_rd()
        if info:
            expiry  = info.get('expiration', '')[:10]
            premium = '✅ Premium' if info.get('type') == 'premium' else '⚠️ Free'
            lines.append('Real-Debrid: %s (expires %s)' % (premium, expiry))
        else:
            lines.append('Real-Debrid: ❌ Auth failed — check API key')
    else:
        lines.append('Real-Debrid: disabled')

    if _ad_on():
        info = check_ad()
        if info:
            expiry = info.get('premiumUntil', '')
            lines.append('AllDebrid: ✅ %s (expires %s)' % (
                info.get('username', ''), expiry))
        else:
            lines.append('AllDebrid: ❌ Auth failed — check API key')
    else:
        lines.append('AllDebrid: disabled')

    if _pm_on():
        info = check_pm()
        if info:
            used  = info.get('space_used_bytes', 0)
            total = info.get('space_limit_bytes', 1)
            pct   = int(used / total * 100) if total else 0
            lines.append('Premiumize: ✅ %s — storage %d%% used' % (
                info.get('customer_id', ''), pct))
        else:
            lines.append('Premiumize: ❌ Auth failed — check API key')
    else:
        lines.append('Premiumize: disabled')

    if _tb_on():
        info = check_tb()
        if info:
            plan = info.get('plan', 0)
            plan_label = {0: 'Free', 1: 'Essential', 2: 'Pro', 3: 'Standard'}.get(plan, 'Unknown')
            expiry = str(info.get('premium_expires_at', ''))[:10]
            lines.append('TorBox: ✅ %s — %s (expires %s)' % (
                info.get('email', ''), plan_label, expiry))
        else:
            lines.append('TorBox: ❌ Auth failed — check API key')
    else:
        lines.append('TorBox: disabled')

    if not any([_rd_on(), _ad_on(), _pm_on(), _tb_on()]):
        lines.append('\nNo premium services enabled.')
        lines.append('Configure in Settings → Premium Services.')

    xbmcgui.Dialog().textviewer('Starfleet — Premium Services', '\n'.join(lines))
