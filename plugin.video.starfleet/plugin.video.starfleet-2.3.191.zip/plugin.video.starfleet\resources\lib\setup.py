# -*- coding: utf-8 -*-
"""
resources/lib/setup.py

First-run dependency checker. Installs ResolveURL via Kodi's addon manager
(works because repository.starfleet includes Gujal00 smrzips as a source).
Runs in a background thread so it never blocks the home window from opening.
"""

import xbmc
import xbmcaddon
import xbmcgui


def _addon_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except RuntimeError:
        return False


def check_and_guide():
    """
    Check for ResolveURL in a background thread so the home window is never blocked.
    InstallAddon runs async (no wait=True) so Kodi handles the progress itself
    without freezing the UI on low-RAM devices like FireStick.
    """
    import threading

    def _check():
        xbmc.sleep(3000)  # let home window finish opening first
        if _addon_installed('script.module.resolveurl'):
            return

        xbmc.log('[Starfleet/Setup] ResolveURL not found — prompting install', xbmc.LOGINFO)

        answer = xbmcgui.Dialog().yesno(
            'Starfleet — Install ResolveURL?',
            'ResolveURL is not installed.\n\n'
            'It resolves stream links for Adult streams and other hosters '
            '(StreamTape, DoodStream, MyVidPlay, etc.).\n\n'
            'Install now?'
        )

        if not answer:
            return

        # Non-blocking — Kodi shows its own install progress dialog.
        # wait=True caused FireStick to freeze during download+extraction.
        xbmc.executebuiltin('InstallAddon(script.module.resolveurl)')
        xbmc.log('[Starfleet/Setup] InstallAddon(script.module.resolveurl) dispatched', xbmc.LOGINFO)

    threading.Thread(target=_check, daemon=True).start()
