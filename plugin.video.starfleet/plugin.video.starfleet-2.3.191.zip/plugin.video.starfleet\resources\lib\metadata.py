﻿# -*- coding: utf-8 -*-
"""
resources/lib/metadata.py

Unified metadata client for TV Shows and Movies.

Sources:
  TMDB (The Movie Database) — movies + TV shows, images, cast, ratings
  TVDB (The TV Database)    — TV show episode details, aired dates
  IMDB ID                   — cross-reference via TMDB external_ids

API Keys (from Enterprise-Toolbox/my_common.py):
  TMDB: rotated across 6 keys to stay under rate limits
  TVDB: single key, JWT auth token cached 24h

Cache TTLs:
  Search results      → 1h
  Movie detail        → 7d  (rarely changes)
  TV show detail      → 24h
  Season/episodes     → 24h
  Cast                → 7d
  Images              → 7d
  TVDB token          → 23h (token valid 24h)

Image base URL: https://image.tmdb.org/t/p/
  Poster/thumb:  w500{poster_path}
  Fanart:        original{backdrop_path}
  Cast photo:    w185{profile_path}
  Still (ep):    w300{still_path}
"""

import random
import time
from functools import lru_cache
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

# ── API Keys ──────────────────────────────────────────────────────────────────

TMDB_KEYS = [
    'df33d5fbe29640895eb99174c801dbc7',
    'a7ebe77c68d738c3dd38348ee0c8f70f',
    'fe07cdedea76c769f430982de6c14842',
    '6cb7bcda188b8c9028544da7182242fd',
    'c577de0778f2ba33846ec5003332dbb6',
    '948f72aef4062585f9075b91b9c0c226',
]
TMDB_TOKEN  = 'c46469cc91ef531c87b21d10267ca47a6r8db'
TVDB_KEY    = '33d90c77fa8907c9421895c07701b245'

TMDB_BASE   = 'https://api.themoviedb.org/3'
TMDB_IMG    = 'https://image.tmdb.org/t/p'
TVDB_BASE   = 'https://api4.thetvdb.com/v4'   # TVDB v4 API

# ── HTTP Session ──────────────────────────────────────────────────────────────

_session = None

def _sess():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update({
            'User-Agent': 'plugin.video.starfleet/1.0',
            'Accept':     'application/json',
        })
        a = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=10,
            max_retries=requests.adapters.Retry(total=3, backoff_factor=0.4)
        )
        _session.mount('https://', a)
    return _session


def _tmdb_key():
    """Rotate through TMDB keys to spread rate limit."""
    return random.choice(TMDB_KEYS)


# ── TMDB HTTP ─────────────────────────────────────────────────────────────────

def _tmdb_get(endpoint, params=None, timeout=10):
    """GET from TMDB API with API key injected."""
    p = {'api_key': _tmdb_key(), 'language': 'en-US'}
    if params:
        p.update(params)
    r = _sess().get(TMDB_BASE + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


# ── Image URL helpers ─────────────────────────────────────────────────────────

@lru_cache(maxsize=2000)
def poster(path, size='original'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''

@lru_cache(maxsize=2000)
def fanart(path, size='original'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''

@lru_cache(maxsize=2000)
def still(path, size='w300'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''

@lru_cache(maxsize=2000)
def profile(path, size='w185'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''


# ── MOVIE — Search ────────────────────────────────────────────────────────────

def search_movies(query, page=1):
    """
    Search TMDB for movies matching query.
    Returns list of slim dicts for fast list rendering.
    """
    ck = 'tmdb_movie_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        data    = _tmdb_get('/search/movie', {'query': query, 'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] search_movies error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_popular(page=1):
    ck = 'tmdb_movies_popular_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/popular', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_popular error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_top_rated(page=1):
    ck = 'tmdb_movies_top_rated_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/top_rated', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_top_rated error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_new(page=1):
    ck = 'tmdb_movies_new_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/now_playing', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_new error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_trending(page=1):
    """Weekly trending movies from TMDB."""
    ck = 'tmdb_movies_trending_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/trending/movie/week', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])
                   if m.get('vote_count', 0) >= 10]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_trending error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_upcoming(page=1):
    """Upcoming movies from TMDB."""
    ck = 'tmdb_movies_upcoming_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/upcoming', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_upcoming error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_by_date(page=1):
    """Movies sorted by release date descending — newest first."""
    import datetime as _dt
    ck = 'tmdb_movies_by_date_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        today = _dt.date.today().isoformat()
        data = _tmdb_get('/discover/movie', {
            'page': page,
            'sort_by': 'release_date.desc',
            'release_date.lte': today,
            'vote_count.gte': 10,
            'with_original_language': 'en',
        })
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_by_date error: %s' % e, xbmc.LOGERROR)
        return []


def get_movie_genres():
    ck = 'tmdb_movie_genres'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data   = _tmdb_get('/genre/movie/list')
        genres = data.get('genres', [])
        _cache.set(ck, genres, 7 * 24 * 3600)
        return genres
    except Exception as e:
        xbmc.log('[Meta] get_movie_genres error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_by_genre(genre_id, page=1):
    ck = 'tmdb_movies_genre_%s_%d' % (genre_id, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/discover/movie', {
            'with_genres': genre_id, 'page': page,
            'sort_by': 'popularity.desc'
        })
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_by_genre error: %s' % e, xbmc.LOGERROR)
        return []


# ── MOVIE — Detail ────────────────────────────────────────────────────────────

def get_movie_detail(tmdb_id):
    """
    Full movie metadata including cast, crew, videos, external IDs.
    Returns rich dict ready for Kodi ListItem.
    """
    ck = 'tmdb_movie_%s' % tmdb_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        data = _tmdb_get('/movie/%s' % tmdb_id, {
            'append_to_response': 'credits,videos,external_ids,images'
        })
        detail = _parse_movie(data)
        _cache.set(ck, detail, 7 * 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[Meta] get_movie_detail(%s) error: %s' % (tmdb_id, e), xbmc.LOGERROR)
        return {}


def _slim_movie(m):
    """Minimal movie dict for list views — fast to render."""
    return {
        'tmdb_id':      str(m.get('id', '')),
        'title':        m.get('title', m.get('original_title', '')),
        'year':         str(m.get('release_date', ''))[:4],
        'release_date': str(m.get('release_date', '')),
        'rating':       round(float(m.get('vote_average', 0)), 1),
        'thumb':        poster(m.get('poster_path', '')),
        'fanart':       fanart(m.get('backdrop_path', '')),
        'overview':     m.get('overview', ''),
        'genre_ids':    m.get('genre_ids', []),
        'media_type':   'movie',
    }


def _parse_movie(data):
    """Full movie detail dict from TMDB append_to_response response."""
    genres    = [g['name'] for g in data.get('genres', [])]
    studios   = [s['name'] for s in data.get('production_companies', [])]

    # Credits
    credits   = data.get('credits', {})
    cast      = []
    for a in credits.get('cast', [])[:20]:
        cast.append({
            'name':      a.get('name', ''),
            'character': a.get('character', ''),
            'photo':     profile(a.get('profile_path', '')),
            'order':     a.get('order', 99),
        })
    director = ''
    writers  = []
    for c in credits.get('crew', []):
        if c.get('job') == 'Director':
            director = c.get('name', '')
        elif c.get('department') == 'Writing':
            writers.append(c.get('name', ''))

    # Trailer
    trailer = ''
    for v in data.get('videos', {}).get('results', []):
        if v.get('type') == 'Trailer' and v.get('site') == 'YouTube':
            trailer = 'plugin://plugin.video.youtube/play/?video_id=%s' % v['key']
            break

    # External IDs
    ext     = data.get('external_ids', {})
    imdb_id = ext.get('imdb_id', data.get('imdb_id', ''))

    # Additional images (backdrops)
    images    = data.get('images', {})
    backdrops = [fanart(i['file_path']) for i in images.get('backdrops', [])[:5]]
    posters   = [poster(i['file_path']) for i in images.get('posters', [])[:5]]

    return {
        'tmdb_id':    str(data.get('id', '')),
        'imdb_id':    imdb_id,
        'title':      data.get('title', data.get('original_title', '')),
        'year':       str(data.get('release_date', ''))[:4],
        'rating':     round(float(data.get('vote_average', 0)), 1),
        'votes':      data.get('vote_count', 0),
        'runtime':    data.get('runtime', 0),
        'overview':   data.get('overview', ''),
        'tagline':    data.get('tagline', ''),
        'genres':     genres,
        'studios':    studios,
        'director':   director,
        'writers':    writers,
        'cast':       cast,
        'thumb':      poster(data.get('poster_path', '')),
        'fanart':     fanart(data.get('backdrop_path', '')),
        'backdrops':  backdrops,
        'posters':    posters,
        'trailer':    trailer,
        'status':       data.get('status', ''),
        'release_date': str(data.get('release_date', '')),
        'media_type':   'movie',
    }


# ── TV SHOWS — Search ─────────────────────────────────────────────────────────

def search_tv(query, page=1):
    ck = 'tmdb_tv_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/search/tv', {'query': query, 'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] search_tv error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_popular(page=1):
    ck = 'tmdb_tv_popular_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/popular', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_popular error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_top_rated(page=1):
    ck = 'tmdb_tv_top_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/top_rated', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_top_rated error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_on_the_air(page=1):
    """TV shows currently on the air from TMDB."""
    ck = 'tmdb_tv_onair_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/on_the_air', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_on_the_air error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_airing_today(page=1):
    ck = 'tmdb_tv_airing_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/airing_today', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 1800)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_airing_today error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_genres():
    ck = 'tmdb_tv_genres'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data   = _tmdb_get('/genre/tv/list')
        genres = data.get('genres', [])
        _cache.set(ck, genres, 7 * 24 * 3600)
        return genres
    except Exception as e:
        xbmc.log('[Meta] get_tv_genres error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_by_genre(genre_id, page=1):
    ck = 'tmdb_tv_genre_%s_%d' % (genre_id, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/discover/tv', {
            'with_genres': genre_id, 'page': page,
            'sort_by': 'popularity.desc'
        })
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_by_genre error: %s' % e, xbmc.LOGERROR)
        return []


# ── TV SHOWS — Detail ─────────────────────────────────────────────────────────

def get_tv_detail(tmdb_id):
    """Full TV show detail including seasons, cast, external IDs."""
    ck = 'tmdb_tv_%s' % tmdb_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data   = _tmdb_get('/tv/%s' % tmdb_id, {
            'append_to_response': 'credits,external_ids,images,videos'
        })
        detail = _parse_tv(data)
        _cache.set(ck, detail, 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[Meta] get_tv_detail(%s) error: %s' % (tmdb_id, e), xbmc.LOGERROR)
        return {}


def get_season_detail(tmdb_id, season_num):
    """Full season detail including all episodes with stills and overviews."""
    ck = 'tmdb_season_%s_%s' % (tmdb_id, season_num)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/%s/season/%s' % (tmdb_id, season_num))
        episodes = []
        for ep in data.get('episodes', []):
            episodes.append({
                'episode':   ep.get('episode_number', 0),
                'season':    ep.get('season_number', season_num),
                'title':     ep.get('name', ''),
                'overview':  ep.get('overview', ''),
                'aired':     ep.get('air_date', ''),
                'rating':    round(float(ep.get('vote_average', 0)), 1),
                'runtime':   ep.get('runtime', 0),
                'still':     still(ep.get('still_path', '')),
                'tmdb_id':   str(ep.get('id', '')),
            })
        result = {
            'season':    season_num,
            'name':      data.get('name', 'Season %s' % season_num),
            'overview':  data.get('overview', ''),
            'air_date':  data.get('air_date', ''),
            'thumb':     poster(data.get('poster_path', '')),
            'episodes':  episodes,
        }
        _cache.set(ck, result, 24 * 3600)
        return result
    except Exception as e:
        xbmc.log('[Meta] get_season_detail error: %s' % e, xbmc.LOGERROR)
        return {'episodes': []}


def _slim_tv(s):
    return {
        'tmdb_id':        str(s.get('id', '')),
        'title':          s.get('name', s.get('original_name', '')),
        'year':           str(s.get('first_air_date', ''))[:4],
        'first_air_date': str(s.get('first_air_date', '')),
        'rating':         round(float(s.get('vote_average', 0)), 1),
        'thumb':          poster(s.get('poster_path', '')),
        'fanart':         fanart(s.get('backdrop_path', '')),
        'overview':       s.get('overview', ''),
        'genre_ids':      s.get('genre_ids', []),
        'media_type':     'tv',
    }


def _parse_tv(data):
    genres   = [g['name'] for g in data.get('genres', [])]
    networks = [n['name'] for n in data.get('networks', [])]
    studios  = [s['name'] for s in data.get('production_companies', [])]

    # Seasons (skip season 0 / specials unless it has episodes)
    seasons = []
    for s in data.get('seasons', []):
        if s.get('season_number', 0) == 0 and s.get('episode_count', 0) == 0:
            continue
        seasons.append({
            'season':        s.get('season_number', 0),
            'name':          s.get('name', 'Season %s' % s.get('season_number')),
            'episode_count': s.get('episode_count', 0),
            'air_date':      s.get('air_date', ''),
            'thumb':         poster(s.get('poster_path', '')),
            'overview':      s.get('overview', ''),
        })

    # Cast
    credits = data.get('credits', {})
    cast    = []
    for a in credits.get('cast', [])[:20]:
        cast.append({
            'name':      a.get('name', ''),
            'character': a.get('character', ''),
            'photo':     profile(a.get('profile_path', '')),
        })
    creators = [c.get('name', '') for c in data.get('created_by', [])]

    # External IDs
    ext     = data.get('external_ids', {})
    imdb_id = ext.get('imdb_id', '')
    tvdb_id = str(ext.get('tvdb_id', ''))

    # Trailer
    trailer = ''
    for v in data.get('videos', {}).get('results', []):
        if v.get('type') == 'Trailer' and v.get('site') == 'YouTube':
            trailer = 'plugin://plugin.video.youtube/play/?video_id=%s' % v['key']
            break

    # Images
    images    = data.get('images', {})
    backdrops = [fanart(i['file_path']) for i in images.get('backdrops', [])[:5]]

    return {
        'tmdb_id':      str(data.get('id', '')),
        'imdb_id':      imdb_id,
        'tvdb_id':      tvdb_id,
        'title':        data.get('name', data.get('original_name', '')),
        'year':         str(data.get('first_air_date', ''))[:4],
        'rating':       round(float(data.get('vote_average', 0)), 1),
        'votes':        data.get('vote_count', 0),
        'runtime':      (data.get('episode_run_time') or [0])[0],
        'overview':     data.get('overview', ''),
        'tagline':      data.get('tagline', ''),
        'genres':       genres,
        'networks':     networks,
        'studios':      studios,
        'creators':     creators,
        'cast':         cast,
        'seasons':      seasons,
        'status':       data.get('status', ''),
        'thumb':        poster(data.get('poster_path', '')),
        'fanart':       fanart(data.get('backdrop_path', '')),
        'backdrops':    backdrops,
        'trailer':      trailer,
        'media_type':   'tv',
    }


# ── TVDB — Episode detail via TVDB v4 ─────────────────────────────────────────

def _get_tvdb_token():
    """Get/refresh TVDB JWT auth token. Cached 23h."""
    cached = _cache.get('tvdb_token')
    if cached:
        return cached

    try:
        r = _sess().post(TVDB_BASE + '/login',
                         json={'apikey': TVDB_KEY}, timeout=10)
        r.raise_for_status()
        token = r.json().get('data', {}).get('token', '')
        if token:
            _cache.set('tvdb_token', token, 23 * 3600)
            xbmc.log('[Meta] TVDB token obtained', xbmc.LOGINFO)
        return token
    except Exception as e:
        xbmc.log('[Meta] TVDB auth error: %s' % e, xbmc.LOGERROR)
        return ''


def get_tvdb_episodes(tvdb_id, season_num):
    """
    Get episode list from TVDB for a given series and season.
    Falls back gracefully to TMDB data if TVDB unavailable.
    """
    ck = 'tvdb_eps_%s_%s' % (tvdb_id, season_num)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    token = _get_tvdb_token()
    if not token:
        return []

    try:
        headers = {'Authorization': 'Bearer %s' % token}
        r = _sess().get(
            '%s/series/%s/episodes/official' % (TVDB_BASE, tvdb_id),
            headers=headers,
            params={'season': season_num, 'page': 0},
            timeout=10
        )
        r.raise_for_status()
        data     = r.json()
        episodes = []
        for ep in data.get('data', {}).get('episodes', []):
            episodes.append({
                'episode':  ep.get('number', 0),
                'season':   ep.get('seasonNumber', season_num),
                'title':    ep.get('name', ''),
                'overview': ep.get('overview', ''),
                'aired':    ep.get('aired', ''),
                'runtime':  ep.get('runtime', 0),
                'still':    ('https://artworks.thetvdb.com' + ep['image'])
                            if ep.get('image') else '',
                'tvdb_id':  str(ep.get('id', '')),
            })
        _cache.set(ck, episodes, 24 * 3600)
        return episodes
    except Exception as e:
        xbmc.log('[Meta] get_tvdb_episodes error: %s' % e, xbmc.LOGERROR)
        return []


# ── Unified episode fetcher ───────────────────────────────────────────────────

def get_episodes(tmdb_id, season_num, tvdb_id=None):
    """
    Get episodes for a season. Tries TMDB first (has stills + overview),
    enriches with TVDB data if tvdb_id available.
    """
    # TMDB is primary — richer image data
    season = get_season_detail(tmdb_id, season_num)
    episodes = season.get('episodes', [])

    # If we have a TVDB id, merge in any missing data
    if tvdb_id and episodes:
        tvdb_eps = {ep['episode']: ep for ep in get_tvdb_episodes(tvdb_id, season_num)}
        for ep in episodes:
            tvdb_ep = tvdb_eps.get(ep['episode'], {})
            # Fill in missing still from TVDB
            if not ep.get('still') and tvdb_ep.get('still'):
                ep['still'] = tvdb_ep['still']
            # Fill in missing overview from TVDB
            if not ep.get('overview') and tvdb_ep.get('overview'):
                ep['overview'] = tvdb_ep['overview']

    return episodes


# ── Cross-search: find TMDB ID from title ─────────────────────────────────────

def find_tmdb_id(title, year=None, media_type='movie'):
    """
    Search TMDB for a title and return the best matching TMDB ID.
    Used to link external content (e.g. a file on StreamTape) to metadata.
    """
    try:
        endpoint = '/search/movie' if media_type == 'movie' else '/search/tv'
        params   = {'query': title}
        if year:
            params['year' if media_type == 'movie' else 'first_air_date_year'] = year
        data    = _tmdb_get(endpoint, params)
        results = data.get('results', [])
        if results:
            return str(results[0]['id'])
    except Exception as e:
        xbmc.log('[Meta] find_tmdb_id error: %s' % e, xbmc.LOGERROR)
    return None
