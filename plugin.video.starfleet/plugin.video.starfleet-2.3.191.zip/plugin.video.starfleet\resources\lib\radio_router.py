﻿# -*- coding: utf-8 -*-
"""
resources/lib/radio_router.py — Radio section directory builder

Menu flow:
  Radio (main)
    └── 🌍 Browse by Country
          └── [Country]
                └── [State / Province / Territory]
                      └── [City] (A-Z)
                            └── [Station] → play
    └── 🔍 Search Stations
    └── 🇨🇦 Canada (shortcut)
    └── 🇺🇸 United States (shortcut)
"""

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import radio as rb
from resources.lib.radio import flag as _flag

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

# Country shortcuts shown at top of radio menu for quick access
# (iso_code, full_radio_browser_name, short_display_name)
SHORTCUTS = [
    ('CA', 'Canada',                                                   'Canada'),
    ('US', 'United States',                                            'United States'),
    ('GB', 'The United Kingdom Of Great Britain And Northern Ireland', 'United Kingdom'),
    ('FR', 'France',                                                   'France'),
    ('DE', 'Germany',                                                  'Germany'),
    ('AU', 'Australia',                                                'Australia'),
    ('IN', 'India',                                                    'India'),
    ('BR', 'Brazil',                                                   'Brazil'),
    ('JP', 'Japan',                                                    'Japan'),
    ('MX', 'Mexico',                                                   'Mexico'),
    ('IT', 'Italy',                                                    'Italy'),
    ('ES', 'Spain',                                                    'Spain'),
    ('NL', 'Netherlands',                                              'Netherlands'),
    ('PL', 'Poland',                                                   'Poland'),
    ('SE', 'Sweden',                                                   'Sweden'),
    ('NO', 'Norway',                                                   'Norway'),
    ('ZA', 'South Africa',                                             'South Africa'),
    ('NG', 'Nigeria',                                                  'Nigeria'),
    ('AR', 'Argentina',                                                'Argentina'),
    ('CO', 'Colombia',                                                 'Colombia'),
]

# Map full Radio Browser country name → ISO code for flag lookup
_COUNTRY_ISO = {full: iso for iso, full, _ in SHORTCUTS}
# Also map short names
_COUNTRY_ISO.update({short: iso for iso, _, short in SHORTCUTS})

# Label for state/province/territory by country
STATE_LABEL = {
    'Canada':         'Province / Territory',
    'United States':  'State',
    'Australia':      'State / Territory',
    'Germany':        'Bundesland',
    'France':         'Région',
    'India':          'State',
    'Brazil':         'Estado',
    'Mexico':         'Estado',
    'default':        'Region',
}


def _state_label(country):
    return STATE_LABEL.get(country, STATE_LABEL['default'])


# ── Helpers ───────────────────────────────────────────────────────────────────

def _add_dir(handle, build_url, label, params, thumb='', plot=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('music', {'title': label, 'comment': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_playable(handle, build_url, label, params, thumb='', plot=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('music', {'title': label, 'comment': plot})
    li.setProperty('IsPlayable', 'true')
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, False)


def _need_fetch(cache_key):
    """True if cache is cold (network call will be needed)."""
    return rb._cache.get(cache_key) is None


def _progress(title, msg):
    d = xbmcgui.DialogProgress()
    d.create(title, msg)
    return d


# ── Radio Main Menu ───────────────────────────────────────────────────────────

def radio_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '📻 Radio')
    xbmcplugin.setContent(handle, 'files')

    # Quick-access country shortcuts with flag emojis
    for iso, country, short in SHORTCUTS:
        f = _flag(iso)
        _add_dir(handle, build_url,
                 label='%s  %s' % (f, short),
                 params={'action': 'radio_states', 'country': country},
                 plot='Radio stations from %s' % short)

    # Divider — full country browser
    _add_dir(handle, build_url,
             label='─' * 20,
             params={'action': 'radio_menu'},
             plot='')

    _add_dir(handle, build_url,
             label='🌍  All Countries (160+)',
             params={'action': 'radio_countries'},
             plot='Browse all 160+ countries with flag icons')

    _add_dir(handle, build_url,
             label='🔍  Search Stations',
             params={'action': 'radio_search'},
             plot='Search stations by name across all countries')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── All Countries ─────────────────────────────────────────────────────────────

def radio_countries(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '📻 Radio — Pays')
    xbmcplugin.setContent(handle, 'files')

    cold = _need_fetch('rb_countries')
    dlg  = _progress('Radio', 'Chargement des pays...') if cold else None

    countries = rb.get_countries()
    if dlg:
        dlg.close()

    if not countries:
        xbmcgui.Dialog().notification('Starfleet',
                                       'Impossible de charger les pays',
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    for c in countries:
        f   = _flag(c.get('iso', ''))
        lbl = '%s  %s  (%d)' % (f, c['name'], c['count'])
        _add_dir(handle, build_url,
                 label=lbl,
                 params={'action': 'radio_states', 'country': c['name']},
                 plot='%d stations' % c['count'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── States / Provinces ────────────────────────────────────────────────────────

def radio_states(handle, build_url, country):
    xbmcplugin.setPluginCategory(handle, '📻 %s' % country)
    xbmcplugin.setContent(handle, 'files')

    ck   = 'rb_states_%s' % country.replace(' ', '_')
    cold = _need_fetch(ck)
    dlg  = _progress('Radio', 'Chargement %s...' % country) if cold else None

    states = rb.get_states(country)
    if dlg:
        dlg.close()

    if not states:
        # No state breakdown — go straight to country-level stations
        radio_stations_country(handle, build_url, country)
        return

    region_label = _state_label(country)
    xbmcplugin.setPluginCategory(handle, '📻 %s — %s' % (country, region_label))

    for s in states:
        _add_dir(handle, build_url,
                 label='%s  (%d)' % (s['name'], s['count']),
                 params={'action': 'radio_cities',
                         'country': country, 'state': s['name']},
                 plot='%d stations' % s['count'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Cities ────────────────────────────────────────────────────────────────────

def radio_cities(handle, build_url, country, state):
    xbmcplugin.setPluginCategory(handle, '📻 %s — %s' % (country, state))
    xbmcplugin.setContent(handle, 'files')

    ck   = 'rb_cities_%s_%s' % (country.replace(' ', '_'), state.replace(' ', '_'))
    cold = _need_fetch(ck)
    dlg  = _progress('Radio', 'Chargement %s...' % state) if cold else None

    cities = rb.get_cities(country, state)
    if dlg:
        dlg.close()

    if not cities:
        # No city breakdown — show all state stations directly
        radio_stations_state(handle, build_url, country, state)
        return

    if len(cities) == 1:
        # Only one city — skip city menu
        radio_stations_city(handle, build_url, country, state, cities[0]['name'])
        return

    for c in cities:
        _add_dir(handle, build_url,
                 label='%s  (%d)' % (c['name'], c['count']),
                 params={'action': 'radio_stations_city',
                         'country': country, 'state': state, 'city': c['name']},
                 plot='%d stations' % c['count'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Stations by City ──────────────────────────────────────────────────────────

def radio_stations_city(handle, build_url, country, state, city):
    xbmcplugin.setPluginCategory(handle, '📻 %s, %s' % (city, state))
    xbmcplugin.setContent(handle, 'files')

    stations = rb.get_stations_by_city(country, state, city)

    if not stations:
        xbmcgui.Dialog().notification('Starfleet',
                                       'Aucune station trouvée pour %s' % city,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    _render_stations(handle, build_url, stations)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Stations by State (fallback when no city data) ────────────────────────────

def radio_stations_state(handle, build_url, country, state):
    xbmcplugin.setPluginCategory(handle, '📻 %s — %s' % (country, state))
    xbmcplugin.setContent(handle, 'files')

    stations = rb._fetch_stations_by_state(country, state)
    stations.sort(key=lambda x: x['name'].lower())

    if not stations:
        xbmcgui.Dialog().notification('Starfleet',
                                       'Aucune station trouvée',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    _render_stations(handle, build_url, stations)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Stations by Country (fallback) ────────────────────────────────────────────

def radio_stations_country(handle, build_url, country):
    xbmcplugin.setPluginCategory(handle, '📻 %s — Stations' % country)
    xbmcplugin.setContent(handle, 'files')

    cold = _need_fetch('rb_country_top_%s' % country.replace(' ', '_'))
    dlg  = _progress('Radio', 'Chargement stations...') if cold else None

    stations = rb.get_stations_by_country(country)
    if dlg:
        dlg.close()

    if not stations:
        xbmcgui.Dialog().notification('Starfleet',
                                       'Aucune station pour %s' % country,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    _render_stations(handle, build_url, stations)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Search ────────────────────────────────────────────────────────────────────

def radio_search(handle, build_url):
    """Keyboard search dialog → results."""
    kb = xbmc.Keyboard('', 'Rechercher une station radio / Search radio station')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '📻 Recherche: %s' % query)
    xbmcplugin.setContent(handle, 'files')

    dlg = _progress('Radio', 'Recherche en cours...')
    stations = rb.search_stations(query, limit=100)
    dlg.close()

    if not stations:
        xbmcgui.Dialog().notification('Starfleet',
                                       'Aucun résultat pour: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    _render_stations(handle, build_url, stations)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Station list renderer ─────────────────────────────────────────────────────

def _render_stations(handle, build_url, stations):
    """Render a list of station items with rich metadata."""
    for s in stations:
        # Build descriptive label: Name — Codec Bitrate
        codec   = s.get('codec', '')
        bitrate = s.get('bitrate', 0)
        genre   = s.get('genre', '').replace(',', ' · ')[:40]

        suffix = ''
        if codec and bitrate:
            suffix = '  [%s %dk]' % (codec, bitrate)
        elif codec:
            suffix = '  [%s]' % codec

        label = s['name'] + suffix

        plot_parts = []
        if genre:
            plot_parts.append(genre)
        if s.get('country') and s.get('state'):
            plot_parts.append('%s, %s' % (s['state_city'] or s['state'], s['country']))
        elif s.get('country'):
            plot_parts.append(s['country'])
        if s.get('language'):
            plot_parts.append('Lang: %s' % s['language'])

        plot = ' | '.join(plot_parts)

        _add_playable(handle, build_url,
                      label=label,
                      params={
                          'action':       'radio_play',
                          'station_uuid': s['uuid'],
                          'stream_url':   s['url'],
                          'title':        s['name'],
                      },
                      thumb=s.get('thumbnail', ''),
                      plot=plot)


# ── Playback ──────────────────────────────────────────────────────────────────

def radio_play(handle, station_uuid, stream_url, title=''):
    """
    Play a radio stream.
    Try /json/url/{uuid} first (resolves redirects + counts click).
    Fall back to url_resolved from station data if API call fails.
    """
    xbmc.log('[Starfleet/Radio] play: uuid=%s url=%s' % (station_uuid, stream_url[:60]), xbmc.LOGINFO)

    # Try to get a freshly resolved URL from Radio Browser (also counts the click)
    if station_uuid:
        resolved = rb.get_stream_url(station_uuid)
        if resolved:
            stream_url = resolved

    if not stream_url:
        xbmcgui.Dialog().notification('Starfleet',
                                       'URL de flux introuvable',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=stream_url)
    li.setInfo('music', {'title': title})

    # Radio streams: MP3/AAC direct streams, some HLS
    if '.m3u8' in stream_url.lower():
        try:
            import inputstreamhelper
            h = inputstreamhelper.Helper('hls')
            if h.check_inputstream():
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        except ImportError:
            pass

    xbmcplugin.setResolvedUrl(handle, True, li)
