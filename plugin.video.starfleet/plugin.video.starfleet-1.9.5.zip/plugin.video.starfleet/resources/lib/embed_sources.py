# -*- coding: utf-8 -*-
"""
resources/lib/embed_sources.py

Embed-provider scrapers using IMDB IDs — no debrid required.
Works like The Crew's source modules: finds content on hosting sites,
returns embed or direct stream URLs for playback via ResolveURL.

Sources:
  VidSrc.to   — rcp-chain: data-hash → /rcp/{hash} → video host URL
  Autoembed   — direct API, returns embed URLs
  SuperEmbed  — multiembed wrapper, IMDB-based
"""

import re
import xbmc

try:
    import requests as _req
except ImportError:
    _req = None

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)
_HEADERS = {
    'User-Agent': _UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
}

_session = None


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=1, backoff_factor=0.3, redirect=False)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get(url, timeout=10, referer='', allow_redirects=True):
    s = _sess()
    if not s:
        return ''
    try:
        headers = {}
        if referer:
            headers['Referer'] = referer
        r = s.get(url, headers=headers, timeout=timeout, allow_redirects=allow_redirects)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Embed] GET %s: %s' % (url[:60], e), xbmc.LOGWARNING)
        return ''


def _get_final_url(url, timeout=10, referer=''):
    """Follow redirects and return the final URL."""
    s = _sess()
    if not s:
        return url
    try:
        headers = {}
        if referer:
            headers['Referer'] = referer
        r = s.get(url, headers=headers, timeout=timeout, allow_redirects=True)
        return r.url
    except Exception:
        return url


_STREAM_RE = [
    re.compile(r'''["']?file["']?\s*:\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''<source[^>]+src=["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''["'](https?://[^\s"'<>]+\.m3u8[^\s"'<>]*)["']''', re.I),
    re.compile(r'''["'](https?://[^\s"'<>]+\.mp4[^\s"'<>]*)["']''', re.I),
]

def _extract_stream(html):
    for pat in _STREAM_RE:
        m = pat.search(html)
        if m:
            url = m.group(1).replace('\\/', '/').strip()
            if url.startswith('http'):
                return url
    return ''


# ── VidSrc.to ─────────────────────────────────────────────────────────────────

_VIDSRC_BASE = 'https://vidsrc.to'

# Known video host domains — if the rcp chain leads here, try our resolvers
_KNOWN_HOSTS = [
    'streamtape.', 'mixdrop.', 'doodstream.', 'dood.watch',
    'streamvid.', 'vidhide.', 'vidmoly.', 'voe.sx',
    'upstream.to', 'vidlox.', 'highstream.',
]


def _vidsrc_rcp(rcp_hash, referer, depth=0):
    """Follow a VidSrc rcp chain to get a video host URL or direct stream."""
    if depth > 3:
        return ''
    rcp_url = '%s/rcp/%s' % (_VIDSRC_BASE, rcp_hash)
    try:
        s = _sess()
        if not s:
            return ''
        r = s.get(rcp_url, headers={'Referer': referer}, timeout=10, allow_redirects=True)
        final_url = r.url
        html = r.text

        # If redirect landed on a known video host, return it
        for host in _KNOWN_HOSTS:
            if host in final_url.lower():
                return final_url

        # Try to extract a direct stream from the page
        stream = _extract_stream(html)
        if stream:
            return stream

        # Look for nested embed iframes
        iframe_m = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
        if iframe_m:
            embed_url = iframe_m.group(1)
            if embed_url.startswith('//'):
                embed_url = 'https:' + embed_url
            for host in _KNOWN_HOSTS:
                if host in embed_url.lower():
                    return embed_url
            if embed_url.startswith('http'):
                return embed_url
    except Exception as e:
        xbmc.log('[Starfleet/Embed] VidSrc rcp error: %s' % e, xbmc.LOGWARNING)
    return ''


def search_vidsrc(imdb_id, media_type='movie', season=None, episode=None):
    """Search VidSrc.to for stream sources using IMDB ID."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/embed/tv/%s/%s/%s' % (_VIDSRC_BASE, imdb_id, season, episode)
        else:
            url = '%s/embed/movie/%s' % (_VIDSRC_BASE, imdb_id)

        html = _get(url, timeout=10)
        if not html:
            return []

        results = []

        # VidSrc uses data-hash on server <a> tags for each available server
        hashes = re.findall(r'data-hash=["\']([A-Za-z0-9]+)["\']', html, re.I)
        server_names = re.findall(r'class=["\']server-item-hl["\'][^>]*>([^<]+)<', html, re.I)

        for i, h in enumerate(hashes[:4]):
            server_label = server_names[i].strip() if i < len(server_names) else 'Server %d' % (i + 1)
            host_url = _vidsrc_rcp(h, url)
            if host_url:
                results.append({'label': 'VidSrc (%s)' % server_label, 'url': host_url})

        if not results and hashes:
            # Couldn't resolve — return embed URL for ResolveURL to try
            results.append({'label': 'VidSrc', 'url': url})

        xbmc.log('[Starfleet/Embed] VidSrc: %d results for %s' % (len(results), imdb_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] VidSrc error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Autoembed ─────────────────────────────────────────────────────────────────

_AUTOEMBED_BASE = 'https://autoembed.co'


def search_autoembed(imdb_id, media_type='movie', season=None, episode=None):
    """Search autoembed.co for stream sources using IMDB ID."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/tv/%s-%s-%s' % (_AUTOEMBED_BASE, imdb_id, season, episode)
        else:
            url = '%s/movie/%s' % (_AUTOEMBED_BASE, imdb_id)

        html = _get(url, timeout=10)
        if not html:
            return []

        # Try direct stream extraction first
        stream = _extract_stream(html)
        if stream:
            return [{'label': 'Autoembed [Direct]', 'url': stream}]

        # Look for server list
        server_urls = re.findall(r'href=["\']([^"\']+/stream/[^"\']+)["\']', html, re.I)
        if not server_urls:
            server_urls = re.findall(r'href=["\']([^"\']+/embed/[^"\']+)["\']', html, re.I)

        results = []
        for srv_url in server_urls[:3]:
            if srv_url.startswith('/'):
                srv_url = _AUTOEMBED_BASE + srv_url
            if srv_url.startswith('http'):
                srv_html = _get(srv_url, referer=url, timeout=8)
                if srv_html:
                    stream = _extract_stream(srv_html)
                    if stream:
                        results.append({'label': 'Autoembed', 'url': stream})
                        continue
                    for host in _KNOWN_HOSTS:
                        if host in srv_url.lower():
                            results.append({'label': 'Autoembed', 'url': srv_url})
                            break

        if not results:
            results.append({'label': 'Autoembed', 'url': url})

        xbmc.log('[Starfleet/Embed] Autoembed: %d results for %s' % (len(results), imdb_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] Autoembed error: %s' % e, xbmc.LOGWARNING)
        return []


# ── SuperEmbed (multiembed.mov) ───────────────────────────────────────────────

def search_superembed(imdb_id, media_type='movie', season=None, episode=None):
    """Search multiembed.mov for stream sources using IMDB ID (TMDB flag)."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = 'https://multiembed.mov/?video_id=%s&tmdb=0&s=%s&e=%s' % (imdb_id, season, episode)
        else:
            url = 'https://multiembed.mov/?video_id=%s&tmdb=0' % imdb_id

        html = _get(url, timeout=10)
        if not html:
            return []

        stream = _extract_stream(html)
        if stream:
            return [{'label': 'SuperEmbed [Direct]', 'url': stream}]

        # Look for server option links
        server_links = re.findall(r'href=["\']([^"\']+)["\'][^>]*>[^<]*(?:server|stream|play)', html, re.I)
        results = []
        for link in server_links[:2]:
            if link.startswith('//'):
                link = 'https:' + link
            if link.startswith('http'):
                for host in _KNOWN_HOSTS:
                    if host in link.lower():
                        results.append({'label': 'SuperEmbed', 'url': link})
                        break
        if not results:
            results.append({'label': 'SuperEmbed', 'url': url})
        xbmc.log('[Starfleet/Embed] SuperEmbed: %d results for %s' % (len(results), imdb_id), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] SuperEmbed error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Unified embed search ──────────────────────────────────────────────────────

def search_embed_providers(imdb_id, media_type='movie', season=None, episode=None):
    """
    Search all embed providers in parallel.
    Returns list of {'label': str, 'url': str}.
    Only runs for movie/tv — adult is handled separately.
    """
    if not imdb_id or media_type == 'adult':
        return []

    from concurrent.futures import ThreadPoolExecutor, as_completed

    tasks = {
        'VidSrc':     lambda: search_vidsrc(imdb_id, media_type, season, episode),
        'Autoembed':  lambda: search_autoembed(imdb_id, media_type, season, episode),
        'SuperEmbed': lambda: search_superembed(imdb_id, media_type, season, episode),
    }

    results = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        try:
            for future in as_completed(futures, timeout=15):
                name = futures[future]
                try:
                    r = future.result()
                    xbmc.log('[Starfleet/Embed] %s: %d results' % (name, len(r)), xbmc.LOGINFO)
                    results.extend(r)
                except Exception as e:
                    xbmc.log('[Starfleet/Embed] %s failed: %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Embed] providers timeout: %s' % e, xbmc.LOGWARNING)

    return results
