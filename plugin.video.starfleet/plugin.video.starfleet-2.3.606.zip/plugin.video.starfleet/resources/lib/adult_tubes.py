# -*- coding: utf-8 -*-
"""Generic tube-site adapter for Adult > Scenes (sites added from a tube-site list).

A site is a small config row: where its listing lives and how it pages, which URL shape is a
video page, how its categories are laid out and how its search works. Listing cards are read
from "anchor containing an image" blocks whose path matches the video shape; the video page is
read for a direct mp4/m3u8 (<source>, og:video, JSON-LD, quoted URLs, or a dataEncodings JSON).

Only sites whose pages serve a plain, full-length stream without JavaScript are listed here.
"""
import html as _html
import json
import re
from urllib.parse import urljoin, urlparse, quote_plus

import xbmc

from resources.lib import adult_streams as _as
from resources.lib import cache as _cache


def _shape(path):
    path = re.sub(r'/\d+(?=/|$)', '/#', path.split('?')[0]).rstrip('/')
    parts = path.split('/')
    return '/'.join(parts[:-1]) + '/*' if len(parts) > 2 else (path or '/')


def _fmt(f, base, u, p):
    if callable(f):
        return f(u, p)
    return f.format(b=base, u=u, us=u.rstrip('/'), p=p)


TUBES = {
    'taxi69': dict(
        label='Taxi69', base='https://taxi69.com', latest='/', page='{u}?page={p}', vshape='/video/*',
        search='/search/{q}/'),
    'perfectgirls': dict(
        label='PerfectGirls', base='https://www.perfectgirls.xxx', latest='/', page='{u}{p}/', vshape='/video/*',
        search='/search/{q}/',
        cats=dict(index='/channels/', shape='/channels/*', page='{u}{p}/')),
    'damplips': dict(
        label='DampLips', base='https://www.damplips.com', latest='/', page='{u}page/{p}/', vshape='/p/*',
        search='/search/{q}/'),
    'theclassicporn': dict(
        label='TheClassicPorn', base='https://theclassicporn.com', latest='/', page='{u}?from={p}',
        vshape='/videos/#/*', search='/search/?q={q}'),
    'youjizz': dict(
        label='YouJizz', base='https://www.youjizz.com', latest='/newest-clips/1.html',
        page='{b}/newest-clips/{p}.html', vshape='/videos/*', search='/search/{q}-1.html',
        cats=dict(index='/tags/', shape='/categories/*',
                  page=lambda u, p: re.sub(r'-\d+\.html$', '-%d.html' % p, u))),
}

_BAD = re.compile(r'categor|/cats?/|/tags?/|channel|pornstar|model|search|login|signup|/page|gay|trans|sitemap|webcam|premium|/out|/go/', re.I)


def _cards(site, html, page_url, vshape=None):
    cfg = TUBES[site]
    host = urlparse(cfg['base']).netloc.replace('www.', '')
    vs = vshape or cfg['vshape']
    films, seen = [], set()
    for m in re.finditer(r'<a\b([^>]*?)href="([^"#]+)"([^>]*)>(.{0,700}?)</a>', html, re.S):
        pre, h, post, inner = m.groups()
        if '<img' not in inner:
            continue
        u = urljoin(page_url, _html.unescape(h))
        p = urlparse(u).path
        if urlparse(u).netloc.replace('www.', '') != host or _shape(p) != vs or u in seen:
            continue
        seen.add(u)
        title = ''
        for src in (pre + post, inner):
            tm = re.search(r'title="([^"]{4,200})"', src) or re.search(r'alt="([^"]{4,200})"', src)
            if tm:
                title = _html.unescape(tm.group(1)).strip()
                break
        if not title:
            title = re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', inner))).strip()[:120]
        slug = p.strip('/').replace('/', '_')
        title = title or slug.replace('-', ' ').replace('_', ' ').title()
        th = re.search(r'(?:data-src|data-original|data-lazy-src|data-thumb|src)="((?:https?:)?//[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"', inner)
        thumb = th.group(1) if th else ''
        if thumb.startswith('//'):
            thumb = 'https:' + thumb
        films.append({'slug': slug[-90:], 'url': u, 'title': _as._clean_title(title), 'title_norm': _as._norm_title(title),
                      'thumb': thumb, 'source': site, 'streams': []})
    return films


def latest(site, page=1):
    cfg = TUBES[site]
    ck = 'tube_%s_latest_%d' % (site, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    u0 = cfg['base'] + cfg['latest']
    url = u0 if page <= 1 else _fmt(cfg['page'], cfg['base'], u0, page)
    try:
        films = _cards(site, _as._get(url), url)
        _cache.set(ck, films, 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/%s] latest error: %s' % (site, e), xbmc.LOGWARNING)
        return []


def categories(site):
    cfg = TUBES[site].get('cats')
    if not cfg:
        return []
    ck = 'tubecat_%s_v1' % site
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    base = TUBES[site]['base']
    host = urlparse(base).netloc.replace('www.', '')
    cats, seen = [], set()
    try:
        html = _as._get(base + cfg['index'])
    except Exception as e:
        xbmc.log('[Starfleet/%s] categories error: %s' % (site, e), xbmc.LOGWARNING)
        return []
    for m in re.finditer(r'<a[^>]+href="([^"#]+)"[^>]*>(.*?)</a>', html, re.S):
        u = urljoin(base + cfg['index'], _html.unescape(m.group(1)))
        if urlparse(u).netloc.replace('www.', '') != host or _shape(urlparse(u).path) != cfg['shape'] or u in seen:
            continue
        inner = m.group(2)
        tm = re.search(r'title="([^"]+)"', m.group(0)) or re.search(r'alt="([^"]+)"', inner)
        name = _html.unescape(tm.group(1)).strip() if tm else re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', ' ', inner))).strip()
        name = re.sub(r'\s*\(?\d[\d.,]*\s*(?:videos?)?\)?$', '', name).strip()
        if not name or len(name) > 40 or name.lower() == 'all' or re.search(r'/abc(/|$)', u):
            continue
        seen.add(u)
        th = re.search(r'(?:data-src|data-original|src)="((?:https?:)?//[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"', inner)
        cats.append({'name': name, 'slug': u, 'count': 0, 'thumb': ('https:' + th.group(1)) if th and th.group(1).startswith('//') else (th.group(1) if th else '')})
    if cats:
        _cache.set(ck, cats, 24 * 3600)
    return cats


def category_movies(site, slug, page=1):
    cfg = TUBES[site]['cats']
    ck = 'tubecat_%s_%s_%d' % (site, re.sub(r'\W+', '_', slug)[-60:], page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = slug if page <= 1 else _fmt(cfg['page'], TUBES[site]['base'], slug, page)
    try:
        films = _cards(site, _as._get(url), url)
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/%s] category %s p%d: %s' % (site, slug, page, e), xbmc.LOGWARNING)
        return []


def search(site, query, page=1):
    cfg = TUBES[site]
    url = cfg['base'] + cfg['search'].format(q=quote_plus(query))
    if page > 1:
        url = _fmt(cfg.get('search_page', '{u}?page={p}'), cfg['base'], url, page)
    try:
        return _cards(site, _as._get(url), url)
    except Exception as e:
        xbmc.log('[Starfleet/%s] search error: %s' % (site, e), xbmc.LOGWARNING)
        return []


# ── video page -> streams ────────────────────────────────────────────────────

_QUALITIES = {240, 360, 480, 540, 576, 720, 1080, 1440, 2160}


def _quality(u):
    """Resolution from a file name like ..._720p.mp4 / ...-1280-720-1481-h264.mp4, else 0."""
    name = re.sub(r'[?&].*$', '', u).rstrip('/').rsplit('/', 1)[-1]
    for m in re.finditer(r'(?<!\d)(\d{3,4})p(?!\w)', name):
        if int(m.group(1)) in _QUALITIES:
            return int(m.group(1))
    m = re.search(r'-\d{3,4}-(\d{3,4})-\d+-h264', name)
    if m and int(m.group(1)) in _QUALITIES:
        return int(m.group(1))
    return 0


def _media(html, base):
    out = []
    for m in re.finditer(r'<source[^>]+src=["\']([^"\']+)["\']', html):
        out.append(m.group(1))
    for m in re.finditer(r'property=["\']og:video(?::secure_url|:url)?["\'][^>]*content=["\']([^"\']+)', html):
        out.append(m.group(1))
    for m in re.finditer(r'"contentUrl"\s*:\s*"([^"]+)"', html):
        out.append(m.group(1).replace('\\/', '/'))
    m = re.search(r'dataEncodings\s*=\s*(\[.*?\]);', html, re.S)
    if m:
        try:
            enc = json.loads(m.group(1))
            for e in sorted(enc, key=lambda x: -int(x.get('quality') or 0)):
                fn = (e.get('filename') or '').replace('\\/', '/')
                if fn and '_hls' not in fn and '.mp4' in fn:
                    out.append(fn)
        except Exception:
            pass
    for m in re.finditer(r'["\'](https?:\\?/\\?/[^"\'\s<>]+?\.(?:mp4|m3u8)[^"\'\s<>]*)', html):
        out.append(m.group(1).replace('\\/', '/'))
    res, seen = [], set()
    for u in out:
        u = _html.unescape(u)
        if u.startswith('//'):
            u = 'https:' + u
        elif u.startswith('/'):
            u = urljoin(base, u)
        if u.startswith('http') and u not in seen and not re.search(r'preview|trailer|/tmb/|thumb|/ads?/', u, re.I):
            seen.add(u)
            res.append(u)
    return res


def detail(site, slug, url):
    cfg = TUBES[site]
    ck = 'tube_%s_detail_%s' % (site, slug[:70])
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _as._get(url, timeout=(5, 12))
        m = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.S | re.I)
        title = _html.unescape(re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', m.group(1)))).strip() if m else ''
        if not title:
            title = _as._og(html, 'title') or slug.replace('-', ' ').replace('_', ' ').title()
        urls = sorted(_media(html, url), key=lambda u: (-_quality(u), u))
        streams = []
        for u in urls[:4]:
            q = _quality(u)
            streams.append({'label': '[%s] %s' % (cfg['label'], ('%dp' % q) if q else ('HLS' if '.m3u8' in u else 'MP4')), 'url': u})
        film = {'id': '%s_%s' % (site, slug), 'slug': slug, 'title': _as._clean_title(title), 'title_norm': _as._norm_title(title),
                'thumb': _as._og(html, 'image'), 'description': '', 'url': url, 'source': site, 'streams': streams}
        if streams:
            _cache.set(ck, film, 20 * 60)       # these links are signed and expire
        return film
    except Exception as e:
        xbmc.log('[Starfleet/%s] detail error (%s): %s' % (site, slug, e), xbmc.LOGWARNING)
        return None
