# -*- coding: utf-8 -*-
"""
resources/lib/playback_assist.py

Helpers for "Just Play" (no source list: play the best source and, when one does not play, the next one), for getting the next
episode ready while the current one is still playing, and for sports streams that fail.

  Source memory   source_stats.json - how often each kind of source (Torrent, Debrid, Embed, a hoster's host...) actually played
                  here. The best-looking source is the one with the best record, with a sensible starting guess for kinds
                  not tried yet. The record fades as it grows so a source that was fixed (or broke) is noticed within days.
  Candidates      auto_candidates.json - the ranked source list of one title for 20 minutes, so a retry after a failure or the
                  next episode's pre-load does not search again.
  Watcher         watch_playback() - follows a stream Kodi was just told to play: never started in time, a playback error, or
                  frozen on one frame -> records the failure and hands over to a "try the next source" callback.

Nothing here touches the source search itself; metadata_router._unified_source_search calls these.
"""
import json
import os
import re
import threading
import time
from urllib.parse import urlparse

import xbmc
import xbmcgui

_LOCK = threading.Lock()
_CAND_TTL = 20 * 60
_STATS_CAP = 40.0          # successes + failures kept per source kind; older results fade
_PRIOR_WEIGHT = 4.0        # how many "virtual" results the starting guess is worth
MAX_ATTEMPTS = 5

# starting guess (0-1) for how likely a kind of source is to play, before anything has been learned
_PRIOR = {'request': 0.90, 'personal': 0.85, 'easynews': 0.80, 'debrid': 0.80, 'ddl': 0.75, 'torrent': 0.70, 'nzb': 0.65,
          'embed': 0.50}
_DEFAULT_PRIOR = 0.55


def _log(msg):
    xbmc.log('[Starfleet/PlaybackAssist] %s' % msg, xbmc.LOGINFO)


def _dir():
    import xbmcvfs
    d = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(d, exist_ok=True)
    return d


def _load(name):
    try:
        with open(os.path.join(_dir(), name), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(name, data):
    try:
        p = os.path.join(_dir(), name)
        with open(p + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(data, f)
        os.replace(p + '.tmp', p)
    except Exception as e:
        _log('could not save %s: %s' % (name, e))


# ── source memory ───────────────────────────────────────────────────────────────────────────────────────────────────

def source_key(src):
    """'torrent' / 'debrid' / 'embed' / ... from a source's [Tag] label, or a hoster's host name when it has no tag."""
    label = (src.get('label') or '') if isinstance(src, dict) else str(src)
    m = re.match(r'^\s*\[([^\]]+)\]', label)
    if m:
        return m.group(1).strip().lower()
    if ' - ' in label:                       # sports: "RockyLive - RockyLive", "Streamed - Admin"
        return label.split(' - ', 1)[0].strip().lower()
    url = (src.get('url') or '') if isinstance(src, dict) else ''
    host = urlparse(url).netloc.lower()
    return re.sub(r'^www\.', '', host) or 'unknown'


def _prior(key, debrid_on=True):
    if key == 'torrent' and not debrid_on:
        return 0.45                # without debrid a torrent goes through Elementum and needs a swarm: slower, less sure
    return _PRIOR.get(key, _DEFAULT_PRIOR)


def score(key, debrid_on=True, stats=None):
    st = (stats if stats is not None else _load('source_stats.json')).get(key) or {}
    s, f = float(st.get('s', 0)), float(st.get('f', 0))
    return (s + _prior(key, debrid_on) * _PRIOR_WEIGHT) / (s + f + _PRIOR_WEIGHT)


def record(key, ok):
    """Remember that a source of this kind did / did not play."""
    if not key:
        return
    with _LOCK:
        stats = _load('source_stats.json')
        st = stats.setdefault(key, {'s': 0.0, 'f': 0.0})
        st['s' if ok else 'f'] = float(st.get('s' if ok else 'f', 0)) + 1
        tot = st['s'] + st['f']
        if tot > _STATS_CAP:                        # fade the old results so the record follows recent behaviour
            k = _STATS_CAP / tot
            st['s'], st['f'] = round(st['s'] * k, 2), round(st['f'] * k, 2)
        st['t'] = int(time.time())
        _save('source_stats.json', stats)


def rank(sources, debrid_on=True):
    """Playable-looking sources, best first: by the source kind's record, then in the order given (which already runs from the
    highest quality down). Trailers are never auto-played."""
    stats = _load('source_stats.json')
    keep = [(i, s) for i, s in enumerate(sources) if not str(s.get('label', '')).startswith('[Trailer]')]
    keep.sort(key=lambda t: (-round(score(source_key(t[1]), debrid_on, stats), 3), t[0]))
    return [s for _, s in keep]


# ── candidate cache ─────────────────────────────────────────────────────────────────────────────────────────────────

def title_key(media_type, tmdb_id, imdb_id, season, episode, title=''):
    ident = tmdb_id or imdb_id or title
    return '%s:%s:%s:%s' % (media_type, ident, season or 0, episode or 0)


def save_candidates(key, cands, ttl=None):
    """Keep a title's ranked sources: 20 minutes, or `ttl` seconds (an episode prepared ahead of time keeps them for hours)."""
    with _LOCK:
        data = _load('auto_candidates.json')
        now = time.time()
        data = {k: v for k, v in data.items() if now - v.get('t', 0) < v.get('ttl', _CAND_TTL)}
        data[key] = {'t': now, 'c': cands}
        if ttl:
            data[key]['ttl'] = ttl
        _save('auto_candidates.json', data)


def load_candidates(key):
    v = _load('auto_candidates.json').get(key)
    if v and time.time() - v.get('t', 0) < v.get('ttl', _CAND_TTL) and v.get('c'):
        return v['c']
    return None


# ── watching a started stream ───────────────────────────────────────────────────────────────────────────────────────

_REQ_PROP = 'sf_play_request'
_BUSY_COND = ('System.HasModalDialog | Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | '
              'Window.IsActive(progressdialog)')


def new_request():
    """Call when the viewer starts something to play (not for a retry or a pre-load). A watcher that is still counting down for an
    earlier request then stands down instead of starting its next source: two plays resolving at once open two busy spinners,
    which Kodi answers with "two concurrent busydialogs" and closes."""
    try:
        xbmcgui.Window(10000).setProperty(_REQ_PROP, '%.4f' % time.time())
    except Exception:
        pass


def _request():
    try:
        return xbmcgui.Window(10000).getProperty(_REQ_PROP)
    except Exception:
        return ''


def _viewer_busy():
    try:
        return bool(xbmc.getCondVisibility(_BUSY_COND))
    except Exception:
        return False


def watch_playback(src_key, on_fail, start_timeout=35.0, ok_after=25.0, freeze_after=25.0):
    """Follow the playback Kodi was just told to start. Records the source kind as good once it has played `ok_after`
    seconds. If it never starts within `start_timeout`, raises a playback error, or sits on the same position for
    `freeze_after` seconds (not paused), records a failure and calls on_fail() once."""
    req = _request()

    def _run():
        monitor = xbmc.Monitor()
        state = {'error': False}

        class _P(xbmc.Player):
            def onPlayBackError(self):
                state['error'] = True

        player = _P()
        t0 = time.time()
        while not player.isPlaying():
            if state['error'] or time.time() - t0 > start_timeout:
                return _failed('never started' if not state['error'] else 'playback error')
            if monitor.waitForAbort(0.5):
                return
        started = last_move = time.time()
        last_pos = -1.0
        while player.isPlaying():
            if state['error']:
                return _failed('playback error')
            now = time.time()
            try:
                pos = player.getTime()
            except Exception:
                pos = last_pos
            paused = False
            try:
                paused = bool(xbmc.getCondVisibility('Player.Paused'))
            except Exception:
                pass
            if pos != last_pos or paused:
                last_pos, last_move = pos, now
            elif now - last_move > freeze_after and now - started < 120:
                return _failed('frozen')
            if now - started >= ok_after:
                record(src_key, True)
                return
            if monitor.waitForAbort(1):
                return
        # stopped before ok_after without an error callback: the viewer stopped it - not a verdict on the source

    def _failed(why):
        _log('%s did not play (%s)' % (src_key, why))
        record(src_key, False)
        # the viewer may have started something else while this was counting down: a retry now would play over it
        waited = time.time()
        while _request() == req and _viewer_busy() and time.time() - waited < 15:
            if xbmc.Monitor().waitForAbort(0.5):
                return
        if _request() != req or _viewer_busy():
            _log('%s: not trying the next source (something else was started meanwhile)' % src_key)
            return
        try:
            on_fail()
        except Exception as e:
            _log('on_fail: %s' % e)

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    return t
