# -*- coding: utf-8 -*-
"""
resources/lib/telegram_auth.py

Per-user Telegram login for the TelegramBot torrent source (see
torrent_sources.py::search_telegram_bot()) — same shared-app-identity
model as tmdb_auth.py's TMDB_V4_READ_TOKEN: API_ID/API_HASH below just
identify "this is the Starfleet app" to Telegram (registered once at
my.telegram.org), they do NOT grant access to anyone's account. Each
installer (or each family member on their own device) logs into their
OWN Telegram account here, so searches run under their own account
rather than one shared login taking everyone's search traffic.

Uses the same QR-scan approach as Telegram Desktop/Web's own "Log in by
QR Code" — no phone number or code to type at all, just scan with the
Telegram app (Settings > Devices > Link Desktop Device), then a 2FA
password prompt only if the account has one set. Reuses gui/qr_dialog.py,
the same helper TMDB/SIMKL pairing already use.

Real finding from testing this live: Telegram's QR login token expires in
well under a minute (confirmed live: a first attempt that took over 60s
end-to-end, mostly spent transferring the QR image itself to the phone
doing the scanning, failed with the token already expired) — much
shorter than TMDB v4's ~15-minute request_token window this addon's other
QR flow relies on. So this can't just show one QR and poll like
tmdb_auth.py does; it has to actively refresh the QR (a new token +
regenerated image, swapped in place via QRDialog.set_qr()) every time a
wait() call times out, for as long as the user has the dialog open.
"""
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from resources.lib.gui import qr_dialog as _qrdlg

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

# Registered once at my.telegram.org under the app name "Starfleet" —
# identifies the app, not any individual account (see this module's own
# docstring above).
API_ID = 39892797
API_HASH = '628d934e42a2663cc64025a2852a9f1d'


def _session_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'telegram')


def is_paired():
    return xbmcvfs.exists(_session_path() + '.session')


def unpair():
    p = _session_path() + '.session'
    try:
        if xbmcvfs.exists(p):
            xbmcvfs.delete(p)
    except Exception as e:
        xbmc.log('[Starfleet/Telegram] unpair delete error: %s' % e, xbmc.LOGWARNING)


_QR_WAIT_S = 25       # comfortably under the token's real expiry (see module
                      # docstring) so a refresh always lands before Telegram
                      # would have rejected the old one anyway.
_QR_MAX_TOTAL_S = 300  # 5 minutes of the user's own time, same order of
                       # magnitude as tmdb_auth.py's pairing window.


def pair_with_telegram():
    """Bound to the telegram_pair Settings action. QR scan, auto-refreshed
    for as long as the dialog stays open — see module docstring for why a
    single static QR (tmdb_auth.py's own pattern) doesn't work here."""
    dialog = xbmcgui.Dialog()
    try:
        from telethon.sync import TelegramClient
        from telethon.errors import SessionPasswordNeededError
    except Exception as e:
        xbmc.log('[Starfleet/Telegram] telethon import failed: %s' % e, xbmc.LOGERROR)
        dialog.notification('Starfleet', 'Telegram login unavailable (see kodi.log)',
                             xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    client = TelegramClient(_session_path(), API_ID, API_HASH)
    qr_dlg = None
    try:
        client.connect()
        if client.is_user_authorized():
            dialog.notification('Starfleet', 'Telegram already linked',
                                 xbmcgui.NOTIFICATION_INFO, 3000)
            return

        qr_login = client.qr_login()
        qr_path = _qrdlg.make_qr(qr_login.url, 'starfleet_telegram_qr.png')
        if not qr_path:
            dialog.notification('Starfleet', 'Could not generate QR code (see kodi.log)',
                                 xbmcgui.NOTIFICATION_ERROR, 4000)
            return
        qr_dlg = _qrdlg.QRDialog(qr_path, 'Link Telegram Account',
                                  'Telegram app > Settings > Devices > Link Desktop Device, then scan')
        qr_dlg.show()

        waited = 0
        linked = False
        while waited < _QR_MAX_TOTAL_S:
            if qr_dlg.iscanceled():
                return
            try:
                # qr_login.wait() is a real coroutine even under
                # telethon.sync (confirmed live — telethon.sync's
                # synchronous patching doesn't extend to QRLoginManager,
                # only to TelegramClient's own methods), so it needs the
                # client's own loop to actually run it.
                client.loop.run_until_complete(qr_login.wait(_QR_WAIT_S))
                linked = True
                break
            except SessionPasswordNeededError:
                qr_dlg.close()
                qr_dlg = None
                password = dialog.input('Enter your Telegram 2FA password',
                                         option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if password:
                    client.sign_in(password=password)
                    linked = True
                break
            except Exception:
                # This round's token expired before being scanned — get a
                # fresh one and swap it into the same dialog rather than
                # closing/reopening.
                waited += _QR_WAIT_S
                if waited >= _QR_MAX_TOTAL_S:
                    break
                client.loop.run_until_complete(qr_login.recreate())
                new_qr_path = _qrdlg.make_qr(qr_login.url, 'starfleet_telegram_qr.png')
                if new_qr_path:
                    qr_dlg.set_qr(new_qr_path)
                qr_dlg.update('QR refreshed — waiting… (%ds)' % waited)

        if qr_dlg:
            qr_dlg.close()
            qr_dlg = None

        if linked:
            me = client.get_me()
            name = me.username or me.first_name or 'your account'
            dialog.notification('Starfleet', 'Telegram linked as %s' % name,
                                 xbmcgui.NOTIFICATION_INFO, 4000)
        else:
            dialog.notification('Starfleet', 'Telegram linking timed out',
                                 xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception as e:
        xbmc.log('[Starfleet/Telegram] pairing error: %s' % e, xbmc.LOGERROR)
        dialog.notification('Starfleet', 'Telegram login failed: %s' % e,
                             xbmcgui.NOTIFICATION_ERROR, 5000)
    finally:
        if qr_dlg:
            qr_dlg.close()
        client.disconnect()


def show_status():
    """Bound to the telegram_status Settings action."""
    dialog = xbmcgui.Dialog()
    if is_paired():
        if dialog.yesno('Starfleet - Telegram', 'Telegram account is linked.\n\nUnlink?'):
            unpair()
            dialog.notification('Starfleet', 'Telegram unlinked',
                                 xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        dialog.ok('Starfleet - Telegram', 'Not linked yet. Use "Link Telegram Account" above.')
