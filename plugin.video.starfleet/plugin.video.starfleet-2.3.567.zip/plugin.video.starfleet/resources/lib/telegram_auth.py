# -*- coding: utf-8 -*-
"""
resources/lib/telegram_auth.py

Per-user Telegram login for the TelegramBot torrent source (see
torrent_sources.py::search_telegram_bot()) — same shared-app-identity
model as tmdb_auth.py's TMDB_V4_READ_TOKEN: API_ID/API_HASH below just
identify "this is the Starfleet app" to Telegram (registered once at
my.telegram.org), they do NOT grant access to anyone's account. Each
installer (or each family member on their own device) logs into their
OWN Telegram account here, so searches run under their own account
rather than one shared login taking everyone's search traffic.

Unlike tmdb_auth.py/simkl_auth.py's URL/QR-approve flow, Telegram's own
login is a direct phone-number + code exchange (MTProto, via the vendored
telethon/ library at this addon's root) — no browser step at all, just
three Kodi keyboard dialogs in sequence (phone, code, and a 2FA password
only if the account has one set).
"""
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

# Registered once at my.telegram.org under the app name "Starfleet" —
# identifies the app, not any individual account (see this module's own
# docstring above).
API_ID = 39892797
API_HASH = '628d934e42a2663cc64025a2852a9f1d'


def _session_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'telegram')


def is_paired():
    return xbmcvfs.exists(_session_path() + '.session')


def unpair():
    p = _session_path() + '.session'
    try:
        if xbmcvfs.exists(p):
            xbmcvfs.delete(p)
    except Exception as e:
        xbmc.log('[Starfleet/Telegram] unpair delete error: %s' % e, xbmc.LOGWARNING)


def pair_with_telegram():
    """Bound to the telegram_pair Settings action. Blocking (three Kodi
    input dialogs in a row) — fine here since, like tmdb_auth.py's
    pair_with_tmdb(), this only ever runs from a Settings button click,
    never on a GUI thread something else needs back."""
    dialog = xbmcgui.Dialog()
    phone = dialog.input('Phone number (with country code, e.g. +15551234567)')
    if not phone:
        return
    try:
        from telethon.sync import TelegramClient
        from telethon.errors import SessionPasswordNeededError
    except Exception as e:
        xbmc.log('[Starfleet/Telegram] telethon import failed: %s' % e, xbmc.LOGERROR)
        dialog.notification('Starfleet', 'Telegram login unavailable (see kodi.log)',
                             xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    client = TelegramClient(_session_path(), API_ID, API_HASH)
    try:
        client.connect()
        if not client.is_user_authorized():
            sent = client.send_code_request(phone)
            code = dialog.input('Enter the code Telegram sent you')
            if not code:
                client.disconnect()
                return
            try:
                client.sign_in(phone, code, phone_code_hash=sent.phone_code_hash)
            except SessionPasswordNeededError:
                password = dialog.input('Enter your Telegram 2FA password',
                                         option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if not password:
                    client.disconnect()
                    return
                client.sign_in(password=password)
        me = client.get_me()
        name = me.username or me.first_name or 'your account'
        dialog.notification('Starfleet', 'Telegram linked as %s' % name,
                             xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception as e:
        xbmc.log('[Starfleet/Telegram] pairing error: %s' % e, xbmc.LOGERROR)
        dialog.notification('Starfleet', 'Telegram login failed: %s' % e,
                             xbmcgui.NOTIFICATION_ERROR, 5000)
    finally:
        client.disconnect()


def show_status():
    """Bound to the telegram_status Settings action."""
    dialog = xbmcgui.Dialog()
    if is_paired():
        if dialog.yesno('Starfleet - Telegram', 'Telegram account is linked.\n\nUnlink?'):
            unpair()
            dialog.notification('Starfleet', 'Telegram unlinked',
                                 xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        dialog.ok('Starfleet - Telegram', 'Not linked yet. Use "Link Telegram Account" above.')
