# -*- coding: utf-8 -*-
"""Live TV from the public iptv-org database (https://iptv-org.github.io/), always the newest list, sorted by country.

  countries.json              -> country names, codes, flags
  iptv/index.country.m3u      -> how many channels each country has (one 3 MB file, cached 6 h)
  iptv/countries/<cc>.m3u     -> the channels of one country, fetched when the country is opened (cached 6 h), with
                                 their category, logo, tvg-id and the request headers a stream needs

Stale copies are kept and used when iptv-org cannot be reached. Guide data for these channels comes from the shared
guide matcher (epg_live.py) when the channels are exported to the TV guide.
"""
import json
import os
import re
import time

import requests
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.starfleet')
SOURCE = 'IPTV-org'
BASE = 'https://iptv-org.github.io/'
_TTL = 6 * 3600
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'

_RE_NAME = re.compile(r',(.+)$')
_RE_ATTR = lambda k: re.compile(k + r'="([^"]*)"')   # noqa: E731
_RE_ID, _RE_LOGO, _RE_GROUP = _RE_ATTR('tvg-id'), _RE_ATTR('tvg-logo'), _RE_ATTR('group-title')
_RE_QUALITY = re.compile(r'\s*\((\d{3,4})p\)')

OTA_GROUP = '📡  Broadcast networks & local stations (over-the-air)'
_OTA_ID = re.compile(r'^(ABC|NBC|CBS|FOX|PBS|CW|TheCW|MyNetworkTV|Telemundo|Univision|UniMas|ION|MeTV|AntennaTV|Estrella\w*|Cozi\w*|'
                     r'Bounce\w*|Grit|Laff|Comet\w*|CourtTV|HeroesAndIcons|Charge)\.', re.I)
_OTA_CALL = re.compile(r'\b[KW][A-Z]{2,3}(-(TV|DT|LD|CD|HD))?\b')
_OTA_CA = re.compile(r'\b(CBC|CTV|Global|Citytv|CityNews|Ici Radio-Canada|ICI RDI|Noovo|TVO|APTN|CHCH|T[ée]l[ée]-Qu[ée]bec|CPAC)\b', re.I)
# streams of services the add-on already lists on their own
_DUP_HOSTS = ('pluto.tv', 'samsung', 'plex.tv', 'jmp2.uk', 'tubi', 'roku.com')


def _dir():
    d = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/iptvorg/')
    if not xbmcvfs.exists(d):
        xbmcvfs.mkdirs(d)
    return d


def _fetch_cached(name, url, parse_json=False):
    """Text (or JSON) of `url`, cached 6 h in a file; the stale copy is used when the download fails."""
    path = os.path.join(_dir(), name)
    fresh = os.path.exists(path) and time.time() - os.path.getmtime(path) < _TTL
    if not fresh:
        try:
            r = requests.get(url, headers={'User-Agent': _UA}, timeout=(8, 40))
            if r.status_code == 200 and r.content:
                tmp = path + '.part'
                with open(tmp, 'wb') as f:
                    f.write(r.content)
                os.replace(tmp, path)
                fresh = True
        except Exception as e:
            xbmc.log('[Starfleet/IPTV-org] %s: %s' % (url, e), xbmc.LOGWARNING)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            return json.load(f) if parse_json else f.read()
    except Exception:
        return None


def _flag(code):
    try:
        return ''.join(chr(0x1F1E6 + ord(c) - 65) for c in code.upper()) if len(code) == 2 else '🌐'
    except Exception:
        return '🌐'


def get_countries():
    """[{'code', 'name', 'flag', 'count'}] for every country with channels, biggest first."""
    countries = _fetch_cached('countries.json', BASE + 'api/countries.json', parse_json=True) or []
    index = _fetch_cached('index.country.m3u', BASE + 'iptv/index.country.m3u') or ''
    counts = {}
    for g in _RE_GROUP.findall(index):
        counts[g] = counts.get(g, 0) + 1
    by_name = {c.get('name'): c for c in countries}
    out = []
    for name, n in counts.items():
        c = by_name.get(name)
        if c:
            out.append({'code': c['code'].lower(), 'name': name, 'flag': c.get('flag') or _flag(c['code']), 'count': n})
        elif name == 'International':
            out.append({'code': 'int', 'name': name, 'flag': '🌐', 'count': n})
    out.sort(key=lambda c: (-c['count'], c['name']))
    return out


def _parse(text, cc):
    channels, seen = [], {}
    lines = text.splitlines()
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        if not line.startswith('#EXTINF'):
            i += 1
            continue
        m_name, m_id, m_logo, m_grp = _RE_NAME.search(line), _RE_ID.search(line), _RE_LOGO.search(line), _RE_GROUP.search(line)
        title = m_name.group(1).strip() if m_name else ''
        referrer = ua = ''
        i += 1
        while i < n and lines[i].startswith('#'):
            if lines[i].startswith('#EXTVLCOPT:http-referrer='):
                referrer = lines[i].split('=', 1)[1].strip()
            elif lines[i].startswith('#EXTVLCOPT:http-user-agent='):
                ua = lines[i].split('=', 1)[1].strip()
            i += 1
        url = lines[i].strip() if i < n else ''
        i += 1
        if not title or not url.startswith('http'):
            continue
        q = _RE_QUALITY.search(title)
        quality = int(q.group(1)) if q else 0
        label = _RE_QUALITY.sub('', title, count=1).strip()
        hdr = []
        if referrer:
            hdr.append('Referer=' + requests.utils.quote(referrer, safe=''))
        if ua:
            hdr.append('User-Agent=' + requests.utils.quote(ua, safe=''))
        play = url + ('|' + '&'.join(hdr) if hdr else '')
        ch = {
            'id': m_id.group(1) if m_id else label,
            'title': label,
            'group': ((m_grp.group(1) if m_grp else '').split(';')[0].strip()) or 'Other',
            'source': SOURCE,
            'thumbnail': m_logo.group(1) if m_logo else '',
            'stream_url': play,
            'quality': quality,
            'country': cc.upper(),
        }
        key = (ch['id'], ch['group'])
        old = seen.get(key)
        if old is None:
            seen[key] = len(channels)
            channels.append(ch)
        elif quality > channels[old]['quality']:     # same channel listed several times: keep the best picture
            channels[old] = ch
    return channels


def get_channels(cc):
    """Channels of one country (code like 'us'), newest list, de-duplicated."""
    cc = (cc or '').lower()
    text = _fetch_cached('%s.m3u' % cc, '%siptv/countries/%s.m3u' % (BASE, cc))
    return _parse(text, cc) if text else []


def is_ota(ch):
    """Network affiliates, local stations and national broadcasters (US / Canada)."""
    cc = ch.get('country', '')
    if cc == 'US':
        return bool(_OTA_ID.match(ch.get('id', '')) or _OTA_CALL.search(ch.get('title', '')))
    if cc == 'CA':
        return bool(_OTA_CA.search(ch.get('title', '')))
    return False


def groups(cc, channels):
    """{group label: [channels]} with the over-the-air group first for the US and Canada."""
    out = {}
    if cc.lower() in ('us', 'ca'):
        ota = [c for c in channels if is_ota(c)]
        if ota:
            out[OTA_GROUP] = ota
    for c in channels:
        out.setdefault(c['group'], []).append(c)
    return out


def export_channels(codes):
    """Channels for the TV guide export: [(title, group, logo, tvg_id, play_url, country)]; streams of services the add-on
    already exports on their own are left out."""
    rows = []
    for cc in codes:
        for c in get_channels(cc):
            low = c['stream_url'].lower()
            if any(h in low for h in _DUP_HOSTS):
                continue
            rows.append((c['title'], c['stream_url'], c['thumbnail'], c['country']))
    return rows


# which countries go to the TV guide ------------------------------------------------------------------------------------

def _pvr_path():
    return os.path.join(_dir(), 'pvr_countries.json')


def pvr_countries():
    try:
        with open(_pvr_path(), 'r', encoding='utf-8') as f:
            codes = json.load(f)
        return [c for c in codes if isinstance(c, str)]
    except Exception:
        return ['us', 'ca']


def set_pvr_countries(codes):
    with open(_pvr_path(), 'w', encoding='utf-8') as f:
        json.dump([c.lower() for c in codes], f)
