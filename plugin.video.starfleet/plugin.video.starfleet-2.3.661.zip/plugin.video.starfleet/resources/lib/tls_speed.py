# -*- coding: utf-8 -*-
"""Make HTTPS requests cheaper: reuse one certificate-checking context.

requests/urllib3 build a fresh TLS context for every new connection and re-read the whole CA bundle into it
(130+ certificates: 0.3 to 1 s of CPU on a desktop, more on a Firestick). The stream search opens dozens of
connections at once, which is what slowed everything else down. install() wraps urllib3's socket-wrapping
helper so connections that would load the same CA file into an identical context share one that is loaded once.
Certificate and hostname checking stay on: only contexts that are already in CERT_REQUIRED mode are shared, and
anything unusual (client certificates, a CA directory, pinned data) goes the normal way.
Safe to call more than once; does nothing when urllib3 looks different from what is expected.
"""
import ssl
import threading

_installed = False


def install():
    global _installed
    if _installed:
        return True
    try:
        import urllib3.connection as uc
        orig = uc.ssl_wrap_socket
    except Exception:
        return False
    cache = {}
    lock = threading.Lock()

    def wrapped(*args, **kw):
        try:
            ctx = kw.get('ssl_context')
            ca = kw.get('ca_certs')
            if (ca and isinstance(ctx, ssl.SSLContext) and not args and not kw.get('ca_cert_dir')
                    and not kw.get('ca_cert_data') and not kw.get('certfile') and not kw.get('keyfile')
                    and ctx.verify_mode == ssl.CERT_REQUIRED):
                key = (ca, ctx.check_hostname, ctx.minimum_version, ctx.maximum_version)
                shared = cache.get(key)
                if shared is None:
                    with lock:
                        shared = cache.get(key)
                        if shared is None:
                            ctx.load_verify_locations(ca)
                            cache[key] = shared = ctx
                kw['ssl_context'] = shared
                kw['ca_certs'] = None
        except Exception:
            pass
        return orig(*args, **kw)

    uc.ssl_wrap_socket = wrapped
    _installed = True
    return True
