# -*- coding: utf-8 -*-
"""
resources/lib/tracker_lists.py

The user's own lists from the watch-tracking account(s) they have paired, for the TV Shows / Movies selectors: one section
per paired account, named after it ("Simkl", "Trakt", "WeTrakr"). The TV Shows selector lists only shows and the Movies
selector only movies. The list and its metadata come from the account's own service wherever that service provides them; TMDB fills in, per field,
anything the service does not supply (a missing poster / backdrop / overview, a failed call, or no metadata API at all):

  Simkl    GET /sync/all-items/{shows|movies}/  -> status, watched / total episodes, next episode, ids, poster.
           GET /{tv|movies}/{id}?extended=full  -> overview, genres, rating, runtime, network, fanart (fetched when a row is
           focused, then kept). No TMDB call is needed for the list.
  Trakt    GET /sync/watched/{shows|movies}?extended=full + /sync/watchlist/{shows|movies}?extended=full -> the titles, their
           overview, genres, rating, runtime, network and aired episode total, all in the one response. Trakt's API has no
           images, so only the posters come from TMDB.
  WeTrakr  has no read endpoint of any kind (see wetrakr_sync.py: events go in, nothing comes back), so its section is built
           from the local watch history that Starfleet itself sends to WeTrakr, and its metadata and posters come from TMDB.

Anime has its own sections in the Anime selector (get_items(..., anime=True)): Simkl keeps a separate anime list
(GET /sync/all-items/anime/, split into series and films by anime_type) and Trakt's anime are its shows / movies tagged with the
"anime" genre. WeTrakr does not record genres, so it has no anime section.

Every item is a plain dict: title, year, tmdb_id, imdb_id, thumb, fanart, overview, status ('watching' | 'plantowatch' |
'hold' | 'completed' | 'dropped'), watched_eps, total_eps, pct (0-100), next_ep / last_ep ('S02E05' or ''), ts (ISO text, sorts
as text), source ('simkl' | 'trakt' | 'tmdb') plus genres / rating / runtime / network. Results are kept for 5 minutes so
reopening a list is instant; any failure gives [] and a log line, never an exception.
"""
import re
import time

import xbmc

TRACKERS = (('simkl', 'Simkl'), ('trakt', 'Trakt'), ('wetrakr', 'WeTrakr'))
_AUTH = {'simkl': 'simkl_auth', 'trakt': 'trakt_auth', 'wetrakr': 'wetrakr_auth'}
_TTL = 300
_cache = {}
_detail_cache = {}
_IMDB = re.compile(r'^tt\d+$')
_STATUS_ORDER = {'watching': 0, 'plantowatch': 1, 'hold': 2, 'completed': 3, 'dropped': 4}
STATUS_LABEL = {'watching': 'Watching', 'plantowatch': 'Plan to Watch', 'hold': 'On Hold', 'completed': 'Completed',
                'dropped': 'Dropped'}


def _log(msg):
    xbmc.log('[Starfleet/TrackerLists] %s' % msg, xbmc.LOGINFO)


# ── which accounts are paired ────────────────────────────────────────────────────────────────────────────────────────

def _is_paired(key):
    try:
        mod = __import__('resources.lib.' + _AUTH[key], fromlist=['is_paired'])
        return bool(mod.is_paired())
    except Exception:
        return False


def paired():
    """[(key, label)] for every paired tracker, in a fixed order."""
    return [(k, label) for k, label in TRACKERS if _is_paired(k)]


# ── small helpers ────────────────────────────────────────────────────────────────────────────────────────────────────

def _int(v, default=0):
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def _item(title, year='', tmdb_id='', imdb_id='', status='watching', watched_eps=0, total_eps=0, next_ep='', ts='',
          thumb='', overview='', source='tmdb', **extra):
    it = {'title': title or '', 'year': str(year or ''), 'tmdb_id': str(tmdb_id or ''), 'imdb_id': imdb_id or '',
          'thumb': thumb, 'fanart': thumb, 'overview': overview, 'status': status, 'watched_eps': watched_eps,
          'total_eps': total_eps, 'next_ep': next_ep, 'last_ep': '', 'ts': ts or '', 'pct': 0, 'source': source,
          'genres': [], 'rating': '', 'runtime': '', 'network': '', 'simkl_id': '', 'kind': '', 'mal_id': '', 'anilist_id': ''}
    it.update(extra)
    return it


def _get_json(url, params=None, headers=None, timeout=20):
    import requests
    r = requests.get(url, params=params, headers=headers, timeout=timeout)
    r.raise_for_status()
    return r.json()


# ── Simkl ────────────────────────────────────────────────────────────────────────────────────────────────────────────

def _simkl_poster(path):
    return ('https://simkl.in/posters/%s_m.jpg' % path) if path else ''


def _simkl_fanart(path):
    return ('https://simkl.in/fanart/%s_medium.jpg' % path) if path else ''


def _simkl(media):
    from resources.lib import simkl_sync as sk
    kind = 'shows' if media == 'tv' else 'movies'
    data = _get_json(sk.SIMKL_BASE + '/sync/all-items/%s/' % kind, params=sk._params(), headers=sk._headers())
    out = []
    for it in (data.get(kind) or []):
        node = it.get('show' if media == 'tv' else 'movie') or {}
        ids = node.get('ids') or {}
        out.append(_item(
            node.get('title'), node.get('year'), ids.get('tmdb'), ids.get('imdb'), it.get('status') or 'watching',
            _int(it.get('watched_episodes_count')), _int(it.get('total_episodes_count')),
            (it.get('next_to_watch') or '') if media == 'tv' else '',
            it.get('last_watched_at') or it.get('added_to_watchlist_at') or '',
            thumb=_simkl_poster(node.get('poster')), source='simkl', simkl_id=str(ids.get('simkl') or ''),
            user_rating=it.get('user_rating')))
    return out


_ANIME_RAW = {}


def _simkl_anime(media):
    """Simkl's anime list: 'tv' = every series type (tv / ona / ova / special), 'movie' = films."""
    from resources.lib import simkl_sync as sk
    raw = _ANIME_RAW.get('simkl')
    if not raw or time.time() - raw[0] > _TTL:
        data = _get_json(sk.SIMKL_BASE + '/sync/all-items/anime/', params=sk._params(), headers=sk._headers())
        raw = _ANIME_RAW['simkl'] = (time.time(), (data or {}).get('anime') or [])
    out = []
    for it in raw[1]:
        is_movie = (it.get('anime_type') or '').lower() == 'movie'
        if is_movie != (media == 'movie'):
            continue
        node = it.get('show') or it.get('movie') or {}
        ids = node.get('ids') or {}
        out.append(_item(
            node.get('title'), node.get('year'), ids.get('tmdb'), ids.get('imdb'), it.get('status') or 'watching',
            _int(it.get('watched_episodes_count')), _int(it.get('total_episodes_count')),
            (it.get('next_to_watch') or '') if media == 'tv' else '',
            it.get('last_watched_at') or it.get('added_to_watchlist_at') or '',
            thumb=_simkl_poster(node.get('poster')), source='simkl', simkl_id=str(ids.get('simkl') or ''), kind='anime',
            mal_id=str(ids.get('mal') or ''), anilist_id=str(ids.get('anilist') or '')))
    return out


def _simkl_detail(it, media):
    """Overview, genres, rating, runtime, network and fanart for one title, from Simkl itself."""
    if not it.get('simkl_id'):
        return {}
    ck = ('simkl', media, it['simkl_id'], it.get('kind', ''))
    if ck in _detail_cache:
        return _detail_cache[ck]
    out = {}
    try:
        from resources.lib import simkl_sync as sk
        path = 'anime' if it.get('kind') == 'anime' else ('tv' if media == 'tv' else 'movies')
        d = _get_json(sk.SIMKL_BASE + '/%s/%s' % (path, it['simkl_id']),
                      params=dict(sk._params(), extended='full'), headers=sk._headers(), timeout=12)
        ratings = d.get('ratings') or {}
        rating = (ratings.get('simkl') or ratings.get('imdb') or {}).get('rating')
        out = {'overview': d.get('overview') or '', 'genres': d.get('genres') or [], 'rating': ('%.1f' % rating) if rating else '',
               'runtime': str(d.get('runtime') or ''), 'network': d.get('network') or '',
               'poster': _simkl_poster(d.get('poster')), 'backdrop': _simkl_fanart(d.get('fanart')),
               'certification': d.get('certification') or ''}
        if media == 'tv' and not it['total_eps']:
            it['total_eps'] = _int(d.get('total_episodes'))
    except Exception as e:
        _log('simkl %s detail %s: %s' % (media, it['simkl_id'], str(e)[:100]))
    _detail_cache[ck] = out
    return out


# ── Trakt ────────────────────────────────────────────────────────────────────────────────────────────────────────────

def _trakt_node(node, ids, **kw):
    return dict(overview=node.get('overview') or '', genres=[g.title() for g in (node.get('genres') or [])],
                rating=('%.1f' % node['rating']) if node.get('rating') else '', runtime=str(node.get('runtime') or ''),
                network=node.get('network') or '', source='trakt', **kw)


def _trakt(media):
    from resources.lib import trakt_sync as tk
    kind = 'shows' if media == 'tv' else 'movies'
    node_key = 'show' if media == 'tv' else 'movie'
    headers = tk._headers()
    full = {'extended': 'full'}
    watched = _get_json(tk.TRAKT_BASE + '/sync/watched/%s' % kind, params=full, headers=headers, timeout=30)
    try:
        watchlist = _get_json(tk.TRAKT_BASE + '/sync/watchlist/%s' % kind, params=full, headers=headers, timeout=30)
    except Exception as e:
        _log('trakt watchlist: %s' % e)
        watchlist = []
    out, seen = [], set()
    for w in watched or []:
        node = w.get(node_key) or {}
        ids = node.get('ids') or {}
        eps, last = 0, (0, 0)
        for s in (w.get('seasons') or []):
            if _int(s.get('number')) <= 0:
                continue
            for e in (s.get('episodes') or []):
                eps += 1
                last = max(last, (_int(s.get('number')), _int(e.get('number'))))
        it = _item(node.get('title'), node.get('year'), ids.get('tmdb'), ids.get('imdb'),
                   'watching' if media == 'tv' else 'completed', eps, _int(node.get('aired_episodes')), '',
                   w.get('last_watched_at') or '')
        it.update(_trakt_node(node, ids))
        it['last_ep'] = ('S%02dE%02d' % last) if last != (0, 0) else ''
        out.append(it)
        seen.add(str(ids.get('trakt') or ids.get('imdb') or node.get('title')))
    for w in watchlist or []:
        node = w.get(node_key) or {}
        ids = node.get('ids') or {}
        if str(ids.get('trakt') or ids.get('imdb') or node.get('title')) in seen:
            continue
        it = _item(node.get('title'), node.get('year'), ids.get('tmdb'), ids.get('imdb'), 'plantowatch', 0,
                   _int(node.get('aired_episodes')), '', w.get('listed_at') or '')
        it.update(_trakt_node(node, ids))
        out.append(it)
    return out


# ── WeTrakr (local history that Starfleet sends it) ──────────────────────────────────────────────────────────────────

def _wetrakr(media):
    from resources.lib import watch_history as wh
    db = wh._load()
    shows, movies = {}, []
    for e in db.values():
        imdb = e.get('imdb_id') or ''
        if not _IMDB.match(imdb):
            continue
        ts = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(_int(e.get('ts'))))
        if _int(e.get('season')) > 0:
            s = shows.setdefault(imdb, {'title': (e.get('title') or '').split(' - ')[0], 'tmdb': e.get('tmdb_id') or '',
                                        'eps': 0, 'ts': '', 'last': (0, 0)})
            if e.get('tmdb_id'):
                s['tmdb'] = e['tmdb_id']
            if e.get('watched'):
                s['eps'] += 1
                s['last'] = max(s['last'], (_int(e.get('season')), _int(e.get('episode'))))
            s['ts'] = max(s['ts'], ts)
        elif e.get('watched'):
            movies.append(_item(e.get('title'), '', e.get('tmdb_id'), imdb, 'completed', 1, 1, '', ts))
    if media == 'movie':
        return movies
    out = []
    for imdb, s in shows.items():
        if not s['eps']:
            continue
        it = _item(s['title'], '', s['tmdb'], imdb, 'watching', s['eps'], 0, '', s['ts'])
        it['last_ep'] = 'S%02dE%02d' % s['last']
        out.append(it)
    return out


_FETCH = {'simkl': _simkl, 'trakt': _trakt, 'wetrakr': _wetrakr}


# ── TMDB: only for what the service itself does not provide ──────────────────────────────────────────────────────────

def resolve_tmdb(it, media):
    """The TMDB id the rest of the plugin (seasons, sources, playback) works with; looked up from the IMDB id or the title
    when the service did not list one. Returns '' when there is no match."""
    if it.get('tmdb_id'):
        return it['tmdb_id']
    from resources.lib import metadata as meta
    tmdb = ''
    if it.get('kind') == 'anime':
        try:
            from resources.lib import anime_meta as am
            entry = {'id': it.get('anilist_id') or ('mal%s' % it['mal_id'] if it.get('mal_id') else 'sk%s' % it.get('simkl_id')),
                     'title': {'english': it.get('title'), 'romaji': it.get('title')},
                     'format': 'MOVIE' if media == 'movie' else 'TV', 'startDate': {'year': _int(it.get('year'))}}
            hit = am._tmdb_for(entry)
            tmdb = str((hit or {}).get('id') or '')
        except Exception as e:
            _log('anime tmdb match %s: %s' % (it.get('title'), str(e)[:80]))
        if tmdb:
            it['tmdb_id'] = tmdb
            return tmdb
    try:
        if it.get('imdb_id'):
            found = meta.find_movie_by_imdb(it['imdb_id']) if media == 'movie' else meta.find_tv_by_imdb(it['imdb_id'])
            tmdb = (found or {}).get('tmdb_id', '')
        if not tmdb and it.get('title'):
            tmdb = meta.find_tmdb_id(it['title'], it.get('year') or None, 'movie' if media == 'movie' else 'tv') or ''
    except Exception as e:
        _log('resolve_tmdb %s: %s' % (it.get('title'), str(e)[:80]))
    it['tmdb_id'] = str(tmdb or '')
    return it['tmdb_id']


def _tmdb_fill(it, media):
    """Fill from TMDB whatever the item's own service left empty (poster, backdrop, overview, rating, genres, year, episode
    total). Fields the service did supply are never replaced."""
    from resources.lib import metadata as meta
    try:
        tmdb = resolve_tmdb(it, media)
        if not tmdb:
            return
        d = meta.get_movie_detail(tmdb) if media == 'movie' else meta.get_tv_detail(tmdb)
        if not d:
            return
        if not it['thumb']:
            it['thumb'] = d.get('thumb') or ''
        if not it['fanart'] or it['fanart'] == it['thumb']:
            it['fanart'] = d.get('fanart') or it['thumb']
        if not it['overview']:
            it['overview'] = d.get('overview', '') or ''
        if not it['rating']:
            it['rating'] = str(d.get('rating', '') or '')
        if not it['genres']:
            g = d.get('genres') or []
            it['genres'] = g if isinstance(g, list) else []
        if not it['runtime'] and str(d.get('runtime', '0')) not in ('', '0'):
            it['runtime'] = str(d.get('runtime'))
        it['year'] = it['year'] or str(d.get('year', '') or '')
        if media == 'tv' and not it['total_eps']:
            it['total_eps'] = sum(_int(s.get('episode_count')) for s in (d.get('seasons') or []) if _int(s.get('season')) > 0)
    except Exception as e:
        _log('tmdb fallback %s: %s' % (it.get('title'), str(e)[:80]))


def _needs_tmdb(it):
    """True when the service gave this item no poster or no overview."""
    return not it['thumb'] or not it['overview']


def _enrich(items, media, budget=7.0):
    """TMDB fills the gaps in the list itself: every WeTrakr title (no metadata API), Trakt's posters (no images in its API), and
    any Simkl title that came without a poster. Simkl's overview arrives with the focused row's detail (see detail())."""
    from concurrent.futures import ThreadPoolExecutor, wait
    todo = [it for it in items if (not it['thumb']) or (it['source'] != 'simkl' and _needs_tmdb(it))]
    if not todo:
        return
    pool = ThreadPoolExecutor(max_workers=8)
    futs = [pool.submit(_tmdb_fill, it, media) for it in todo]
    pool.shutdown(wait=False)
    wait(futs, timeout=budget)


def _finish(it, media):
    """Progress percentage, and the final status for trackers that do not state one."""
    total, done = it['total_eps'], it['watched_eps']
    if media == 'movie':
        it['pct'] = 100 if it['status'] == 'completed' else 0
        return
    if total:
        it['pct'] = max(0, min(100, int(round(100.0 * done / total))))
        if it['status'] == 'watching' and done >= total:
            it['status'] = 'completed'
    elif it['status'] == 'completed':
        it['pct'] = 100


# ── public API ───────────────────────────────────────────────────────────────────────────────────────────────────────

def has_anime(key):
    """True for the trackers that can list anime separately (Simkl has its own anime list, Trakt tags it with a genre)."""
    return key in ('simkl', 'trakt')


def _is_anime_genre(it):
    return any(str(g).lower() == 'anime' for g in (it.get('genres') or []))


# The lists are also kept on disk (per profile) by tracker_sync.py, which refreshes them in the background whenever the account
# changed, so a section opens at once from the last copy (a Fire TV Stick needs 5-20 s to fetch and enrich a long list) and
# is as current as the last sync. A copy newer than _DISK_FRESH is used as it is; an older one (up to _DISK_STALE) is shown
# while a fresh one is fetched; anything older is fetched first.
_DISK = 'tracker_lists_cache.json'
_DISK_FRESH = 600
_DISK_STALE = 6 * 3600
_refreshing = set()


def _disk_path():
    from resources.lib import profiles as _profiles
    return _profiles.data_path(_DISK)


def _disk_load():
    import json
    try:
        with open(_disk_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _disk_store(ck, items):
    import json
    import os
    try:
        d = _disk_load()
        d['%s|%s|%s' % (ck[0], ck[1], int(bool(ck[2])))] = {'t': time.time(), 'items': items}
        p = _disk_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(d, f)
        os.replace(p + '.tmp', p)
    except Exception as e:
        _log('disk copy not written: %s' % e)


def disk_age(key, media, anime=False):
    """Seconds since the on-disk copy of one list was made, or None when there is none."""
    e = _disk_load().get('%s|%s|%s' % (key, media, int(bool(anime))))
    return (time.time() - e['t']) if e else None


def _fetch_items(key, media, anime):
    """The list from the account itself, enriched and sorted, or None when the account could not be read."""
    fetch = _simkl_anime if (anime and key == 'simkl') else _FETCH.get(key)
    if not fetch or (anime and key != 'simkl'):
        return None
    t = time.time()
    try:
        items = fetch(media)
    except Exception as e:
        _log('%s %s list failed: %s' % (key, media, str(e)[:120]))
        return None
    items = [it for it in items if it['title']]
    _enrich(items, media)
    for it in items:
        _finish(it, media)
    items.sort(key=lambda x: x['ts'], reverse=True)                       # newest first ...
    items.sort(key=lambda x: _STATUS_ORDER.get(x['status'], 9))           # ... inside each status (stable sort)
    _log('%s %s%s: %d items in %.1fs' % (key, 'anime ' if anime else '', media, len(items), time.time() - t))
    return items


def refresh(key, media, anime=False):
    """Fetch one list now and keep it (memory and disk). Returns the item count, or -1 when the account could not be read."""
    if anime and key == 'trakt':
        return refresh('trakt', media)
    items = _fetch_items(key, media, anime)
    if items is None:
        return -1
    _cache[(key, media, anime)] = (time.time(), items)
    _disk_store((key, media, anime), items)
    return len(items)


def _refresh_async(key, media, anime):
    import threading
    tag = (key, media, anime)
    if tag in _refreshing:
        return
    _refreshing.add(tag)

    def _run():
        try:
            refresh(key, media, anime)
        finally:
            _refreshing.discard(tag)
    threading.Thread(target=_run, daemon=True).start()


def get_items(key, media, anime=False):
    """Every show ('tv') or movie ('movie') on the paired account `key`, newest activity first within each status. With
    anime=True: the anime series / films only (the Anime selector's section)."""
    if anime and key == 'trakt':
        return [it for it in get_items('trakt', media) if _is_anime_genre(it)]
    ck = (key, media, anime)
    hit = _cache.get(ck)
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    e = _disk_load().get('%s|%s|%s' % (key, media, int(bool(anime))))
    if e and e.get('items'):
        age = time.time() - e['t']
        if age < _DISK_FRESH:
            _cache[ck] = (time.time(), e['items'])
            return e['items']
        if age < _DISK_STALE:                          # show the last copy now, bring it up to date behind it
            _cache[ck] = (time.time() - _TTL + 20, e['items'])
            _refresh_async(key, media, anime)
            return e['items']
    items = _fetch_items(key, media, anime)
    if items is None:
        return (e or {}).get('items') or []            # the account is unreachable: the last copy beats an empty list
    _cache[ck] = (time.time(), items)
    _disk_store(ck, items)
    return items


def detail(it, media):
    """Extra metadata for the focused row, from the item's own service (Simkl: fetched now; Trakt / WeTrakr: already on the item).
    Returns {'overview', 'poster', 'backdrop'} - any may be missing."""
    d = _simkl_detail(it, media) if it.get('source') == 'simkl' else {}
    if d:
        for k in ('genres', 'rating', 'runtime', 'network'):
            if d.get(k):
                it[k] = d[k]
        if d.get('overview'):
            it['overview'] = d['overview']
        if d.get('poster'):
            it['thumb'] = d['poster']
        if d.get('backdrop'):
            it['fanart'] = d['backdrop']
        _finish(it, media)
    if _needs_tmdb(it) or not it['fanart'] or it['fanart'] == it['thumb']:      # the service had nothing (or its call failed)
        _tmdb_fill(it, media)
        _finish(it, media)
    return {'overview': overview_text(it, media), 'poster': it.get('thumb', ''), 'backdrop': it.get('fanart', '')}


def clear_cache():
    _cache.clear()
    _detail_cache.clear()
    _ANIME_RAW.clear()


def row_label(it, media):
    """List row text: title (year), then what is next / last watched, or the status for titles not being watched."""
    label = '%s (%s)' % (it['title'], it['year']) if it['year'] else it['title']
    if media == 'tv' and it['status'] == 'watching' and it.get('next_ep'):
        return '%s  [COLOR yellow]next %s[/COLOR]' % (label, it['next_ep'])
    if media == 'tv' and it['status'] == 'watching' and it.get('last_ep'):
        return '%s  [COLOR yellow]last %s[/COLOR]' % (label, it['last_ep'])
    if it['status'] in ('plantowatch', 'hold', 'dropped'):
        return '%s  [COLOR gray]%s[/COLOR]' % (label, STATUS_LABEL[it['status']])
    return label


def overview_text(it, media):
    """Plot text: status and progress, a line of genres / rating / runtime / network, then the service's overview."""
    parts = [STATUS_LABEL.get(it['status'], it['status'].title())]
    if media == 'tv' and it['total_eps']:
        parts.append('%d of %d episodes watched (%d%%)' % (it['watched_eps'], it['total_eps'], it['pct']))
    elif media == 'tv' and it['watched_eps']:
        parts.append('%d episodes watched' % it['watched_eps'])
    if media == 'tv' and it.get('next_ep'):
        parts.append('Next up: %s' % it['next_ep'])
    elif media == 'tv' and it.get('last_ep'):
        parts.append('Last watched: %s' % it['last_ep'])
    lines = ['  •  '.join(parts)]
    facts = []
    if it.get('genres'):
        facts.append(', '.join(it['genres'][:3]))
    if it.get('rating'):
        facts.append('Rated %s' % it['rating'])
    if it.get('runtime'):
        facts.append('%s min' % it['runtime'])
    if it.get('network'):
        facts.append(it['network'])
    if facts:
        lines.append('  •  '.join(facts))
    if it.get('overview'):
        lines.append('')
        lines.append(it['overview'])
    return '\n'.join(lines)
