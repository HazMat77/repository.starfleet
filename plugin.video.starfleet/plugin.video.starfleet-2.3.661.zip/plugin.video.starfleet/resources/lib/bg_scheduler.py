# -*- coding: utf-8 -*-
"""
resources/lib/bg_scheduler.py

One place for the add-on's background work. The service used to start a thread per job (My Teams alerts, new-episode preparation,
Requests warm-up, SIMKL flush, Adult widgets, IPTV check, tracker sync, memory log, update check, connection warm-up): about ten
threads waking up on their own timers, each deciding for itself whether it was a good moment. On a Fire TV Stick (1.7 GB) that
meant work could pile up at the worst times - the end of an episode, with the next one opening - and Android once ended Kodi for it.

Now there are two threads:

  scheduler   wakes when a job is due and runs the LIGHT jobs (a few milliseconds each: flag files, timers, a log line) itself
  heavy       runs one HEAVY job at a time (network syncs, source searches) from a queue, so two heavy jobs never overlap

and one policy for all of it:  a job may say it must not run while something is playing, and no job that is not marked
essential runs while the device is short of memory (it is simply tried again a little later).

    add(name, fn, first=60, every=900, heavy=True, playing_ok=False, low_mem_ok=False)
        fn() runs the job. `every` is seconds until the next run, or a function of fn's result giving the seconds (None = never again).
    run(monitor)          the scheduler thread body
"""
import queue
import threading
import time

import xbmc

_tasks = []
_lock = threading.Lock()
_heavy_q = queue.Queue()
_RETRY_PLAYING = 60
_RETRY_LOW_MEM = 300


class _Task(object):
    def __init__(self, name, fn, first, every, heavy, playing_ok, low_mem_ok):
        self.name, self.fn, self.every = name, fn, every
        self.heavy, self.playing_ok, self.low_mem_ok = heavy, playing_ok, low_mem_ok
        self.due = time.time() + first
        self.busy = False


def _log(msg):
    xbmc.log('[Starfleet/Sched] %s' % msg, xbmc.LOGINFO)


def add(name, fn, first=60, every=900, heavy=True, playing_ok=False, low_mem_ok=False):
    with _lock:
        _tasks.append(_Task(name, fn, first, every, heavy, playing_ok, low_mem_ok))


def _playing():
    try:
        return xbmc.Player().isPlaying()
    except Exception:
        return False


def _low_memory():
    try:
        from resources.lib import memguard
        return memguard.low()
    except Exception:
        return False


def _execute(t):
    """Run one job and set when it is due next. Never raises."""
    nxt = None
    try:
        result = t.fn()
        nxt = t.every(result) if callable(t.every) else t.every
    except Exception as e:
        _log('%s failed: %s' % (t.name, str(e)[:120]))
        nxt = t.every(None) if callable(t.every) else t.every
        nxt = nxt if nxt else 900
    t.due = time.time() + nxt if nxt else float('inf')
    t.busy = False


def _heavy_worker(monitor):
    while not monitor.abortRequested():
        try:
            t = _heavy_q.get(timeout=2)
        except queue.Empty:
            continue
        _execute(t)


def run(monitor):
    """The scheduler thread (and, started from here, the one heavy worker)."""
    threading.Thread(target=_heavy_worker, args=(monitor,), daemon=True).start()
    while not monitor.abortRequested():
        now = time.time()
        wait = 5.0
        with _lock:
            tasks = list(_tasks)
        for t in tasks:
            if t.busy:
                continue
            if t.due > now:
                wait = min(wait, t.due - now)
                continue
            if not t.playing_ok and _playing():
                t.due = now + _RETRY_PLAYING
                continue
            if not t.low_mem_ok and _low_memory():
                t.due = now + _RETRY_LOW_MEM
                continue
            t.busy = True
            if t.heavy:
                _heavy_q.put(t)
            else:
                _execute(t)
        if monitor.waitForAbort(max(0.5, min(wait, 5.0))):
            break
