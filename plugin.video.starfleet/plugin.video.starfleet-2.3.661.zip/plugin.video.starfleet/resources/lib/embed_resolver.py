# -*- coding: utf-8 -*-
"""Shared helper; the one copy lives in script.module.starfleetscrapers (starfleetscrapers.core.embed_resolver)."""
import sys

from starfleetscrapers.core import embed_resolver as _impl

sys.modules[__name__] = _impl
