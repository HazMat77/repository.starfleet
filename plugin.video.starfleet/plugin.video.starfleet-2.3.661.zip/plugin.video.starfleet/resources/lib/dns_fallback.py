# -*- coding: utf-8 -*-
"""Shared helper; the one copy lives in script.module.starfleetscrapers (starfleetscrapers.core.dns_fallback)."""
import sys

from starfleetscrapers.core import dns_fallback as _impl

sys.modules[__name__] = _impl
