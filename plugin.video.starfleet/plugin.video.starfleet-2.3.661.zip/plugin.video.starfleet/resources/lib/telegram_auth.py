# -*- coding: utf-8 -*-
"""
resources/lib/telegram_auth.py

Per-user Telegram login for the TelegramBot torrent source (see
torrent_sources.py::search_telegram_bot()) — same shared-app-identity
model as tmdb_auth.py's TMDB_V4_READ_TOKEN: API_ID/API_HASH below just
identify "this is the Starfleet app" to Telegram (registered once at
my.telegram.org), they do NOT grant access to anyone's account. Each
installer (or each family member on their own device) logs into their
OWN Telegram account here, so searches run under their own account
rather than one shared login taking everyone's search traffic.

Uses the same QR-scan approach as Telegram Desktop/Web's own "Log in by
QR Code" — no phone number or code to type at all, just scan with the
Telegram app (Settings > Devices > Link Desktop Device), then a 2FA
password prompt only if the account has one set. Reuses gui/qr_dialog.py,
the same helper TMDB/SIMKL pairing already use.

Real finding from testing this live: Telegram's QR login token expires in
well under a minute (confirmed live: a first attempt that took over 60s
end-to-end, mostly spent transferring the QR image itself to the phone
doing the scanning, failed with the token already expired) — much
shorter than TMDB v4's ~15-minute request_token window this addon's other
QR flow relies on. So this can't just show one QR and poll like
tmdb_auth.py does; it has to actively refresh the QR (a new token +
regenerated image, swapped in place via QRDialog.set_qr()) every time a
wait() call times out, for as long as the user has the dialog open.

Real bug fixed 2026-09-12, found via a real kodi.log traceback: Kodi runs
plugin actions off the main thread, and constructing a bare TelegramClient
there crashed immediately with "ValueError: set_wakeup_fd only works in
main thread" — deep inside asyncio.Lock()'s implicit
asyncio.get_event_loop() call. Windows' DEFAULT asyncio event loop
(ProactorEventLoop, used automatically since Python 3.8) does its own
self-pipe/signal-handling setup that only works on the process's real
main thread; it doesn't matter that nothing here ever touches signals
directly. The standard fix is forcing the alternative SelectorEventLoop
implementation instead, which has no such setup — confirmed live on a
background thread (matching how Kodi actually calls this) that a client
built after explicitly creating and setting a SelectorEventLoop connects
and authenticates fine. SelectorEventLoop can't do asyncio subprocess
work, which is irrelevant here (Telethon only needs plain TCP). Every
entry point that constructs a TelegramClient — this module's
pair_with_telegram() and torrent_sources.py's _telegram_client() — must
call _ensure_selector_event_loop() first.
"""
import asyncio
import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from resources.lib.gui import qr_dialog as _qrdlg

ADDON = xbmcaddon.Addon('plugin.video.starfleet')


def ensure_selector_event_loop():
    """Call before constructing a TelegramClient on any thread that isn't
    guaranteed to be the process main thread (Kodi's plugin actions never
    are) — see this module's own docstring for why. Safe to call more than
    once per thread; only replaces the loop the first time.

    The probe below must catch a bare Exception, not just RuntimeError:
    if a loop was never set for this thread yet, asyncio.get_event_loop()
    itself is exactly the call that auto-creates the crashing
    ProactorEventLoop and raises the real bug's ValueError — that failure
    means "no usable loop exists yet", same as the probe simply finding
    none, so either way the fix below is to create and set our own."""
    if sys.platform != 'win32':
        return
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            loop = None
    except Exception:
        loop = None
    if not isinstance(loop, asyncio.SelectorEventLoop):
        new_loop = asyncio.SelectorEventLoop()
        asyncio.set_event_loop(new_loop)

# Registered once at my.telegram.org under the app name "Starfleet" —
# identifies the app, not any individual account (see this module's own
# docstring above).
API_ID = 39892797
API_HASH = '628d934e42a2663cc64025a2852a9f1d'


def _session_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'telegram')


def _marker_path():
    return _session_path() + '.linked'


def _mark_linked():
    try:
        with open(_marker_path(), 'w') as f:
            f.write('1')
    except Exception:
        pass


def is_paired():
    """True when a Telegram account is really linked. The session file is created the moment linking starts (before the QR code
    is scanned) and even a session Telegram never signed in holds a connection key, so neither the file nor its key proves a
    link. A completed link leaves a marker file; an account linked by an earlier version has none, so a session that has
    cached the signed-in user (its `entities` table) counts too."""
    p = _session_path() + '.session'
    if not xbmcvfs.exists(p):
        return False
    if os.path.exists(_marker_path()):
        return True
    try:
        import sqlite3
        con = sqlite3.connect(p, timeout=2)
        try:
            return (con.execute('select count(*) from entities').fetchone() or [0])[0] > 0
        finally:
            con.close()
    except Exception:
        return True                                   # cannot tell (file locked...): behave as before


def unpair():
    p = _session_path() + '.session'
    try:
        if xbmcvfs.exists(p):
            xbmcvfs.delete(p)
    except Exception as e:
        xbmc.log('[Starfleet/Telegram] unpair delete error: %s' % e, xbmc.LOGWARNING)
    try:
        if os.path.exists(_marker_path()):
            os.remove(_marker_path())
    except Exception:
        pass


_QR_WAIT_S = 25       # comfortably under the token's real expiry (see module
                      # docstring) so a refresh always lands before Telegram
                      # would have rejected the old one anyway.
_QR_MAX_TOTAL_S = 300  # 5 minutes of the user's own time, same order of
                       # magnitude as tmdb_auth.py's pairing window.
_QR_POLL_S = 3         # one slice of waiting for the scan (see pair_with_telegram)


def pair_with_telegram():
    """Bound to the telegram_pair Settings action. QR scan, auto-refreshed
    for as long as the dialog stays open — see module docstring for why a
    single static QR (tmdb_auth.py's own pattern) doesn't work here."""
    dialog = xbmcgui.Dialog()
    try:
        from telethon.sync import TelegramClient
        from telethon.errors import SessionPasswordNeededError
    except Exception as e:
        xbmc.log('[Starfleet/Telegram] telethon import failed: %s' % e, xbmc.LOGERROR)
        dialog.notification('Starfleet', 'Telegram login unavailable (see kodi.log)',
                             xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    ensure_selector_event_loop()
    client = TelegramClient(_session_path(), API_ID, API_HASH)
    qr_dlg = None
    try:
        client.connect()
        if client.is_user_authorized():
            dialog.notification('Starfleet', 'Telegram already linked',
                                 xbmcgui.NOTIFICATION_INFO, 3000)
            return

        qr_login = client.qr_login()
        qr_path = _qrdlg.make_qr(qr_login.url, 'starfleet_telegram_qr.png')
        if not qr_path:
            dialog.notification('Starfleet', 'Could not generate QR code (see kodi.log)',
                                 xbmcgui.NOTIFICATION_ERROR, 4000)
            return
        qr_dlg = _qrdlg.QRDialog(qr_path, 'Link Telegram Account',
                                  'Telegram app > Settings > Devices > Link Desktop Device, then scan')
        qr_dlg.show()

        import time as _t
        started = last_refresh = _t.time()
        linked = False

        def _finish_login():
            """True once this client is signed in; asks for the 2FA password when the account has one."""
            try:
                if client.is_user_authorized():
                    return True
            except Exception:
                pass
            return False

        qr_n = 0
        while _t.time() - started < _QR_MAX_TOTAL_S:
            if qr_dlg.iscanceled():
                return
            try:
                # qr_login.wait() is a real coroutine even under telethon.sync (confirmed live - telethon.sync's synchronous
                # patching doesn't extend to QRLoginManager, only to TelegramClient's own methods), so it needs the client's
                # own loop to run it. Short slices (a scan is noticed within a few seconds, and the loop - which is what
                # receives Telegram's "scanned" message - runs most of the time); the code itself is renewed every
                # _QR_WAIT_S seconds below.
                client.loop.run_until_complete(qr_login.wait(_QR_POLL_S))
                linked = True
                break
            except SessionPasswordNeededError:
                qr_dlg.close()
                qr_dlg = None
                password = dialog.input('Enter your Telegram 2FA password',
                                         option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if password:
                    client.sign_in(password=password)
                    linked = True
                break
            except Exception as _e:
                # Not scanned yet (the slice timed out) - or the sign-in did go through but wait() ended with an error (an
                # account on another data centre does that). Ask Telegram before going on.
                if _finish_login():
                    linked = True
                    break
                if type(_e).__name__ not in ('TimeoutError', 'CancelledError'):
                    xbmc.log('[Starfleet/Telegram] QR wait: %s: %s' % (type(_e).__name__, str(_e)[:100]), xbmc.LOGINFO)
            if _t.time() - last_refresh >= _QR_WAIT_S:
                # the code is about to expire: a fresh one, in a file of its own (Kodi keeps the picture it first showed for a
                # given file name, so re-using one name left the OLD code on screen - one the phone could no longer use)
                last_refresh = _t.time()
                try:
                    client.loop.run_until_complete(qr_login.recreate())
                except Exception as _re:
                    # recreate() refuses when the code on screen was accepted a moment ago: finish that login
                    try:
                        client.loop.run_until_complete(qr_login.wait(5))
                        linked = True
                        break
                    except SessionPasswordNeededError:
                        qr_dlg.close()
                        qr_dlg = None
                        password = dialog.input('Enter your Telegram 2FA password',
                                                 option=xbmcgui.ALPHANUM_HIDE_INPUT)
                        if password:
                            client.sign_in(password=password)
                            linked = True
                        break
                    except Exception:
                        if _finish_login():
                            linked = True
                            break
                        xbmc.log('[Starfleet/Telegram] QR renew: %s: %s' % (type(_re).__name__, str(_re)[:100]), xbmc.LOGINFO)
                        continue
                qr_n += 1
                new_qr_path = _qrdlg.make_qr(qr_login.url, 'starfleet_telegram_qr_%d_%d.png' % (int(last_refresh), qr_n))
                if new_qr_path:
                    qr_dlg.set_qr(new_qr_path)
                qr_dlg.update('QR refreshed - waiting... (%ds)' % int(_t.time() - started))

        if qr_dlg:
            qr_dlg.close()
            qr_dlg = None

        if linked:
            me = client.get_me()
            _mark_linked()
            name = me.username or me.first_name or 'your account'
            dialog.notification('Starfleet', 'Telegram linked as %s' % name,
                                 xbmcgui.NOTIFICATION_INFO, 4000)
        else:
            dialog.notification('Starfleet', 'Telegram linking timed out',
                                 xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception as e:
        xbmc.log('[Starfleet/Telegram] pairing error: %s' % e, xbmc.LOGERROR)
        dialog.notification('Starfleet', 'Telegram login failed: %s' % e,
                             xbmcgui.NOTIFICATION_ERROR, 5000)
    finally:
        if qr_dlg:
            qr_dlg.close()
        client.disconnect()


def show_status():
    """Bound to the telegram_status Settings action."""
    dialog = xbmcgui.Dialog()
    if is_paired():
        if dialog.yesno('Starfleet - Telegram', 'Telegram account is linked.\n\nUnlink?'):
            unpair()
            dialog.notification('Starfleet', 'Telegram unlinked',
                                 xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        dialog.ok('Starfleet - Telegram', 'Not linked yet. Use "Link Telegram Account" above.')
