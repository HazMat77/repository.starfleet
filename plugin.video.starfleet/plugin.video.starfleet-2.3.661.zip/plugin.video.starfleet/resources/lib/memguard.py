# -*- coding: utf-8 -*-
"""
resources/lib/memguard.py

A Fire TV Stick has about 1.7 GB of memory, of which Android itself keeps roughly 1.1 GB. Kodi playing video can use 0.5 GB, and a
second picture decoder on top (a Home trailer still running while the next episode opens) or a burst of background work at the wrong
moment is enough for Android to end Kodi ("LOW_MEMORY"). This module keeps the add-on's optional work out of those moments:

    avail_mb()            MemAvailable from /proc/meminfo (None where that is not readable)
    low(threshold_mb)     True when little memory is left
    block_trailers(secs)  Home must not start a trailer for a while (set around the end of an episode / auto-play)
    trailers_blocked()    True while that block lasts
    log_loop(monitor)     writes the memory state to kodi.log every couple of minutes ([Starfleet/Mem]) so a kill can be explained

The block is a Home-window property, so it works across the separate processes the add-on runs in.
"""
import threading
import time

import xbmc
import xbmcgui

_BLOCK_PROP = 'sf_trailer_block'
LOW_MB = 300


def _read_kb(path, key):
    try:
        with open(path, 'r') as f:
            for line in f:
                if line.startswith(key):
                    return int(line.split()[1])
    except Exception:
        pass
    return None


def avail_mb():
    kb = _read_kb('/proc/meminfo', 'MemAvailable:')
    return None if kb is None else kb // 1024


def rss_mb():
    kb = _read_kb('/proc/self/status', 'VmRSS:')
    return None if kb is None else kb // 1024


def low(threshold_mb=LOW_MB):
    a = avail_mb()
    return a is not None and a < threshold_mb


def block_trailers(secs=90):
    try:
        xbmcgui.Window(10000).setProperty(_BLOCK_PROP, '%.0f' % (time.time() + secs))
    except Exception:
        pass


def trailers_blocked():
    try:
        until = xbmcgui.Window(10000).getProperty(_BLOCK_PROP)
        return bool(until) and float(until) > time.time()
    except Exception:
        return False


def tick():
    """One log line for the scheduler. Returns seconds until the next one (30 while something plays, else 120)."""
    try:
        playing = xbmc.Player().isPlaying()
    except Exception:
        playing = False
    xbmc.log('[Starfleet/Mem] available=%s MB, Kodi resident=%s MB, threads=%d, playing=%s' % (
        avail_mb(), rss_mb(), threading.active_count(), playing), xbmc.LOGINFO)
    return 30 if playing else 120


def log_loop(monitor):
    """Service thread: one line every two minutes (every 30 s while something is playing)."""
    player = xbmc.Player()
    while not monitor.abortRequested():
        try:
            playing = player.isPlaying()
        except Exception:
            playing = False
        xbmc.log('[Starfleet/Mem] available=%s MB, Kodi resident=%s MB, threads=%d, playing=%s' % (
            avail_mb(), rss_mb(), threading.active_count(), playing), xbmc.LOGINFO)
        if monitor.waitForAbort(30 if playing else 120):
            break
