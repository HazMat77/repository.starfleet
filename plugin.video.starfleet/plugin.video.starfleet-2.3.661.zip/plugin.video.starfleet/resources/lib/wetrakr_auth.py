# -*- coding: utf-8 -*-
"""
resources/lib/wetrakr_auth.py

WeTrakr account pairing (device-code flow) for wetrakr.com, a watch-tracking service independent of Trakt/SIMKL -
nothing here touches their settings. Backs wetrakr_sync.py, which sends the playback events.

Pairing, as WeTrakr's own Kodi client does it:
  1. POST {api_url}/oauth/device/code, body {} -> {"device_code","user_code","verification_url","expires_in","interval"}
     (verification_url is currently https://wetrakr.com/activate?platform=kodi)
  2. Show user_code plus a QR code for verification_url.
  3. Poll POST {api_url}/oauth/device/token, body {"device_code": ...} every `interval` seconds:
       {"error":"authorization_pending"} keep polling | {"error":"expired_token"} stop |
       {"access_token":"...","username":"..."} done
No app identifier is needed for this flow (the separate REST API v1 needs a partner key; scrobbling does not).

Stale tokens: a saved token the server no longer knows (account re-created, token revoked) answers every event with
HTTP 401/403 while still looking paired locally. wetrakr_sync reports that here (mark_token_rejected); from then on
is_paired() is False, the settings show "needs re-pairing", and a successful pairing clears the flag.
api_url is a user-editable setting (default https://api.wetrakr.com).
"""
import time
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.gui import progress_dialog as _pdlg
from resources.lib.gui import qr_dialog as _qrdlg

ADDON = xbmcaddon.Addon('plugin.video.starfleet')


def api_url():
    return (ADDON.getSetting('wetrakr_api_url').strip() or 'https://api.wetrakr.com').rstrip('/')


def user_agent():
    version = ADDON.getAddonInfo('version') or '1.0'
    return 'plugin.video.starfleet/%s' % version


def is_paired():
    # A fresh Addon() every call, NOT the module-level ADDON above - same
    # fix simkl_auth.py's is_paired() already documents (a long-lived
    # process like the Home screen can otherwise keep reading a settings
    # snapshot frozen from before pairing completed).
    a = xbmcaddon.Addon('plugin.video.starfleet')
    return bool(a.getSetting('wetrakr_access_token').strip()) and a.getSetting('wetrakr_auth_invalid') != 'true'


def unpair():
    ADDON.setSetting('wetrakr_access_token', '')
    ADDON.setSetting('wetrakr_username', '')
    ADDON.setSetting('wetrakr_auth_invalid', 'false')


def token_rejected():
    """True when the server answered an event with 401/403 (saved token no longer valid)."""
    return xbmcaddon.Addon('plugin.video.starfleet').getSetting('wetrakr_auth_invalid') == 'true'


def mark_token_rejected():
    """Called by wetrakr_sync on HTTP 401/403: stop sending (is_paired() turns False) and tell the user once."""
    a = xbmcaddon.Addon('plugin.video.starfleet')
    if a.getSetting('wetrakr_auth_invalid') == 'true':
        return
    a.setSetting('wetrakr_auth_invalid', 'true')
    xbmcgui.Dialog().notification('Starfleet', 'WeTrakr no longer accepts this pairing - pair again in Settings',
                                  xbmcgui.NOTIFICATION_WARNING, 6000)


def pair_with_wetrakr():
    """Run the full device-code pairing flow, showing a QR code (if
    available) plus the short code in a Kodi dialog. Bound to the
    wetrakr_pair Settings action. No credentials to enter first - see this
    module's docstring for why no client id/secret is needed at all."""
    try:
        import requests
    except Exception:
        xbmcgui.Dialog().notification('Starfleet', 'requests module unavailable',
                                      xbmcgui.NOTIFICATION_ERROR)
        return

    base = api_url()
    headers = {'Content-Type': 'application/json', 'User-Agent': user_agent()}

    try:
        r = requests.post(base + '/oauth/device/code', json={}, headers=headers, timeout=10)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/WeTrakr] oauth/device/code error: %s' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Starfleet', 'WeTrakr pairing failed to start',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    device_code = data.get('device_code')
    user_code   = data.get('user_code')
    verify_url  = data.get('verification_url', 'https://wetrakr.com/activate?platform=kodi')
    expires_in  = data.get('expires_in', 900)
    interval    = data.get('interval', 5)

    if not device_code or not user_code:
        xbmcgui.Dialog().notification('Starfleet', 'WeTrakr pairing failed to start',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    msg = 'Scan, or go to %s and enter code: %s' % (verify_url, user_code)
    qr_path = _qrdlg.make_qr(verify_url, 'starfleet_wetrakr_qr.png')
    qr_dlg, txt_dlg = None, None
    if qr_path:
        qr_dlg = _qrdlg.QRDialog(qr_path, 'Pair with WeTrakr',
                                 'Scan, or go to %s' % verify_url, code=user_code)
        qr_dlg.show()
    else:
        txt_dlg = _pdlg.DialogProgress()
        txt_dlg.create('Starfleet - Pair with WeTrakr', msg)

    def _iscanceled():
        return qr_dlg.iscanceled() if qr_dlg else txt_dlg.iscanceled()

    def _update():
        if qr_dlg:
            qr_dlg.update('Waiting for you to approve… (%ds)' % waited)
        else:
            txt_dlg.update(min(99, int(100 * waited / expires_in)), msg)

    def _close():
        (qr_dlg or txt_dlg).close()

    waited = 0
    while waited < expires_in:
        if _iscanceled():
            _close()
            return
        time.sleep(interval)
        waited += interval
        _update()

        try:
            pr = requests.post(base + '/oauth/device/token', json={'device_code': device_code},
                               headers=headers, timeout=10)
            pr.raise_for_status()
            pdata = pr.json()
        except Exception as e:
            xbmc.log('[Starfleet/WeTrakr] device/token poll error: %s' % e, xbmc.LOGWARNING)
            continue

        if pdata.get('error') == 'expired_token':
            _close()
            xbmcgui.Dialog().notification('Starfleet', 'WeTrakr: code expired, try again',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            return

        if pdata.get('access_token'):
            ADDON.setSetting('wetrakr_access_token', pdata['access_token'])
            ADDON.setSetting('wetrakr_username', pdata.get('username', ''))
            ADDON.setSetting('wetrakr_auth_invalid', 'false')
            _close()
            xbmcgui.Dialog().notification('Starfleet', 'WeTrakr account paired',
                                          xbmcgui.NOTIFICATION_INFO, 3000)
            return
        # error == 'authorization_pending' (or any other unrecognized shape) - keep polling

    _close()
    xbmcgui.Dialog().notification('Starfleet', 'WeTrakr pairing timed out',
                                  xbmcgui.NOTIFICATION_INFO, 4000)


def show_status():
    """Bound to the wetrakr_status Settings action."""
    if token_rejected():
        if xbmcgui.Dialog().yesno('Starfleet - WeTrakr',
                                  'WeTrakr rejected the saved pairing (it expired or was removed).\n\nPair again now?'):
            unpair()
            pair_with_wetrakr()
        return
    if is_paired():
        username = xbmcaddon.Addon('plugin.video.starfleet').getSetting('wetrakr_username').strip()
        who = ' as %s' % username if username else ''
        xbmcgui.Dialog().ok('Starfleet - WeTrakr', 'WeTrakr is paired%s. Starfleet is sending it your playback.' % who)
    else:
        xbmcgui.Dialog().ok('Starfleet - WeTrakr', 'Not paired yet. Use "Pair with WeTrakr" above.')


def unpair_account():
    """Bound to the wetrakr_unpair Settings action: asks first, then forgets the saved pairing. Nothing changes on the
    WeTrakr account itself."""
    if not (is_paired() or token_rejected()):
        xbmcgui.Dialog().notification('Starfleet', 'WeTrakr is not paired', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    if xbmcgui.Dialog().yesno('Starfleet - WeTrakr', 'Unpair WeTrakr from Starfleet?\n\nYour WeTrakr account itself is not changed; '
                              'you can pair again at any time.'):
        unpair()
        xbmcgui.Dialog().notification('Starfleet', 'WeTrakr unpaired', xbmcgui.NOTIFICATION_INFO, 3000)

