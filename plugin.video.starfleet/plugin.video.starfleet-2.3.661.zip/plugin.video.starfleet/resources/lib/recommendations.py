# -*- coding: utf-8 -*-
"""
resources/lib/recommendations.py

The carousel behind the Profile button on Home: movies and shows picked for the viewer from what the active profile watches.

  Taste     the titles the profile has watched: its own watch history, plus the linked SIMKL / Trakt account (so a profile that
            watches elsewhere is known too). Recent and well-rated titles count more; a title rated 4 or lower counts for nothing.
  Picks     for each of those titles TMDB's own "people who liked this also watched" list; a title several of them point to
            climbs, a title already watched never appears, and unreleased, poster-less or barely-rated ones are skipped.
  Rows      Recommended Movies, Recommended Shows, then "Because you watched <title>" for the two strongest taste titles. A
            profile that has watched nothing yet gets trending / top rated rows instead, until it has.

The rows are plain Home carousel items and go through the profile's content limit like every other row (a Kids profile gets
kid-safe picks). Nothing raises: any failure gives the fallback or an empty row.
"""
import re
import time
from concurrent.futures import ThreadPoolExecutor

import xbmc

from resources.lib import cache as _cache
from resources.lib import metadata as _meta

_SEEDS_PER_KIND = 6
_ROW = 20
_REC_TTL = 6 * 3600


def _log(msg):
    xbmc.log('[Starfleet/Recommendations] %s' % msg, xbmc.LOGINFO)


def _iso_epoch(text):
    try:
        import calendar
        from starfleetscrapers.sports.timeparse import strptime
        return calendar.timegm(strptime((text or '')[:19], '%Y-%m-%dT%H:%M:%S').timetuple())
    except Exception:
        return 0


# ── taste ───────────────────────────────────────────────────────────────────────────────────────────────────────────

def _local_seeds():
    """{'movie': {tmdb_id: seed}, 'tv': {...}} from the active profile's watch history."""
    out = {'movie': {}, 'tv': {}}
    try:
        from resources.lib import watch_history as _wh
        db = _wh._load()
    except Exception:
        return out
    shows = {}
    for e in db.values():
        imdb, tmdb = e.get('imdb_id') or '', str(e.get('tmdb_id') or '')
        if not re.match(r'^tt\d+$', imdb):
            continue
        total = float(e.get('total_s') or 0)
        progress = (float(e.get('resume_s') or 0) / total) if total > 0 else 0
        if not (e.get('watched') or progress >= 0.5):
            continue
        title = re.sub(r'\s+S\d+E\d+.*$', '', e.get('title') or '')
        ts = int(e.get('ts') or 0)
        if int(e.get('season') or 0) > 0:
            s = shows.setdefault(imdb, {'tmdb': tmdb, 'title': title, 'ts': 0, 'n': 0})
            s['tmdb'] = s['tmdb'] or tmdb
            s['ts'] = max(s['ts'], ts)
            s['n'] += 1
        else:
            out['movie'][imdb] = {'tmdb': tmdb, 'imdb': imdb, 'title': title, 'ts': ts, 'w': 1.0}
    for imdb, s in shows.items():
        out['tv'][imdb] = {'tmdb': s['tmdb'], 'imdb': imdb, 'title': s['title'], 'ts': s['ts'], 'w': 1.0 + min(s['n'], 10) / 10.0}
    return out


def _tracker_seeds():
    """The same, from the linked SIMKL / Trakt accounts (titles in progress or completed, not ones rated badly)."""
    out = {'movie': {}, 'tv': {}}
    try:
        from resources.lib import tracker_lists as _tl
        linked = [k for k, _l in _tl.paired() if k in ('simkl', 'trakt')]
    except Exception:
        return out
    for key in linked:
        for media in ('movie', 'tv'):
            try:
                items = _tl.get_items(key, media)
            except Exception:
                items = []
            for it in items:
                if it['status'] not in ('watching', 'completed') or not it.get('tmdb_id'):
                    continue
                rating = it.get('user_rating')
                w = 1.0
                if rating:
                    if int(rating) <= 4:
                        continue
                    if int(rating) >= 8:
                        w = 2.0
                out[media]['t' + it['tmdb_id']] = {'tmdb': it['tmdb_id'], 'imdb': it.get('imdb_id', ''), 'title': it['title'],
                                                   'ts': _iso_epoch(it.get('ts')), 'w': w}
    return out


def seeds():
    """{'movie': [seed...], 'tv': [seed...]}: the taste titles, strongest first (newest, well rated), duplicates merged."""
    merged = {'movie': {}, 'tv': {}}
    for src in (_local_seeds(), _tracker_seeds()):
        for media in ('movie', 'tv'):
            for s in src[media].values():
                if not s['tmdb'] and s.get('imdb'):                    # a local entry without a TMDB id: look it up
                    try:
                        found = (_meta.find_movie_by_imdb(s['imdb']) if media == 'movie' else _meta.find_tv_by_imdb(s['imdb'])) or {}
                        s['tmdb'] = found.get('tmdb_id', '')
                    except Exception:
                        pass
                if not s['tmdb']:
                    continue
                cur = merged[media].get(s['tmdb'])
                if cur:
                    cur['w'] = max(cur['w'], s['w'])
                    cur['ts'] = max(cur['ts'], s['ts'])
                else:
                    merged[media][s['tmdb']] = dict(s)
    out = {}
    for media, d in merged.items():
        ranked = sorted(d.values(), key=lambda s: -s['ts'])
        for i, s in enumerate(ranked):
            s['weight'] = s['w'] / (1.0 + 0.12 * i)               # newer titles count more
        out[media] = sorted(ranked, key=lambda s: -s['weight'])[:_SEEDS_PER_KIND]
    return out, {m: set(d) for m, d in merged.items()}


# ── picks ───────────────────────────────────────────────────────────────────────────────────────────────────────────

def _recs_for(media, tmdb_id):
    """TMDB's recommendations for one title (raw results), kept for 6 hours."""
    ck = 'rec_v1_%s_%s' % (media, tmdb_id)
    hit = _cache.get(ck)
    if hit is not None:
        return hit
    try:
        data = _meta._tmdb_get('/%s/%s/recommendations' % (media, tmdb_id), {'page': 1})
        res = data.get('results') or []
        _cache.set(ck, res, _REC_TTL)
        return res
    except Exception as e:
        _log('recommendations %s %s: %s' % (media, tmdb_id, str(e)[:60]))
        return []


def _usable(r, media, today):
    date = (r.get('release_date') if media == 'movie' else r.get('first_air_date')) or ''
    return bool(r.get('poster_path')) and not r.get('adult') and int(r.get('vote_count') or 0) >= 50 and bool(date) and date <= today


def _item(r, media):
    it = _meta._slim_movie(r) if media == 'movie' else _meta._slim_tv(r)
    it.update({'id': it['tmdb_id'], 'plot': it.get('overview', ''), 'source': 'tmdb', 'media_type': media})
    return it


def _row(scores, seen, media):
    ranked = sorted(scores.values(), key=lambda x: (-x['score'], -float(x['r'].get('popularity') or 0)))
    return [_item(x['r'], media) for x in ranked if x['id'] not in seen][:_ROW]


def _fallback(row_defs):
    """Trending / top rated rows for a profile with no history yet."""
    rows = []
    for label, media, endpoint in row_defs:
        try:
            ck = 'rec_fb_v1_%s' % endpoint
            res = _cache.get(ck)
            if res is None:
                res = (_meta._tmdb_get(endpoint, {'page': 1}).get('results') or [])
                _cache.set(ck, res, 3600)
            today = time.strftime('%Y-%m-%d')
            items = [_item(r, media) for r in res if _usable(r, media, today)][:_ROW]
        except Exception as e:
            _log('fallback %s: %s' % (endpoint, str(e)[:60]))
            items = []
        if items:
            items[0]['row_label'] = label
        rows.append(items)
    return rows


def rows(per_row=_ROW):
    """The four Home rows [Recommended Movies, Recommended Shows, Because you watched A, Because you watched B]; the first item of
    each carries its heading as 'row_label'. A profile with no history gets trending / top rated rows instead."""
    try:
        taste, known = seeds()
    except Exception as e:
        _log('taste: %s' % e)
        taste, known = {'movie': [], 'tv': []}, {'movie': set(), 'tv': set()}
    if not taste['movie'] and not taste['tv']:
        return _fallback([('Trending Movies', 'movie', '/trending/movie/week'), ('Trending Shows', 'tv', '/trending/tv/week'),
                          ('Top Rated Movies', 'movie', '/movie/top_rated'), ('Top Rated Shows', 'tv', '/tv/top_rated')])
    today = time.strftime('%Y-%m-%d')
    jobs = [(m, s) for m in ('movie', 'tv') for s in taste[m]]
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(lambda j: _recs_for(j[0], j[1]['tmdb']), jobs))
    scores = {'movie': {}, 'tv': {}}
    per_seed = {}
    for (media, s), res in zip(jobs, results):
        good = [r for r in res if _usable(r, media, today)]
        per_seed[(media, s['tmdb'])] = good
        for pos, r in enumerate(good):
            e = scores[media].setdefault(str(r['id']), {'id': str(r['id']), 'r': r, 'score': 0.0})
            e['score'] += s['weight'] * (0.6 + float(r.get('vote_average') or 0) / 10.0) * (1.0 - pos * 0.01)
    seen = {m: set(known[m]) | {s['tmdb'] for s in taste[m]} for m in ('movie', 'tv')}
    movies = _row(scores['movie'], seen['movie'], 'movie')
    shows = _row(scores['tv'], seen['tv'], 'tv')
    if movies:
        movies[0]['row_label'] = 'Recommended Movies'
    if shows:
        shows[0]['row_label'] = 'Recommended Shows'
    # "Because you watched ...": the two strongest taste titles, one of each kind when there are both
    top = sorted([(m, s) for m in ('movie', 'tv') for s in taste[m]], key=lambda t: -t[1]['weight'])
    picks, kinds = [], set()
    for m, s in top:
        if m not in kinds:
            picks.append((m, s))
            kinds.add(m)
    for m, s in top:
        if len(picks) >= 2:
            break
        if (m, s) not in picks:
            picks.append((m, s))
    because = []
    for m, s in picks[:2]:
        row = [_item(r, m) for r in per_seed.get((m, s['tmdb']), []) if str(r['id']) not in seen[m]][:_ROW]
        if row:
            row[0]['row_label'] = 'Because you watched %s' % s['title']
        because.append(row)
    while len(because) < 2:
        because.append([])
    return [movies[:per_row], shows[:per_row], because[0][:per_row], because[1][:per_row]]
