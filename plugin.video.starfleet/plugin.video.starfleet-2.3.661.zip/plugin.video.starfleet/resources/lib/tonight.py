# -*- coding: utf-8 -*-
"""
resources/lib/tonight.py

"Tonight": one personal schedule built from the viewer's own accounts instead of channels, in local time. It is offered in the
TV Shows, Sports and Anime sections and each shows only its own kind of rows (build(scope=...)):

  * games      the followed teams' live games and the ones starting in the next 36 hours (my_teams.py)
  * shows      the next episode of every show being watched (continue_watching.py, which already folds in the paired SIMKL /
               MDBList accounts): ready to watch now, or its air date when it is still to come this week
  * anime      episodes airing in the next 48 hours for the anime on the paired SIMKL account, at the exact hour AniList lists

build() returns plain dicts, already in display order: LIVE now, then Tonight, Tomorrow, Ready to watch, and Later this week.
Each failure of a source only drops that source's rows. Nothing here plays anything - home.py's _open_tonight does that.
"""
import time

import xbmc

_ORDER = {'live': 0, 'today': 1, 'ready': 2, 'tomorrow': 3, 'later': 4}
_HOUR = 3600


def _log(msg):
    xbmc.log('[Starfleet/Tonight] %s' % msg, xbmc.LOGINFO)


def _day_section(ts, now):
    """'today' / 'tomorrow' / 'later' for a timestamp, by the viewer's own calendar days."""
    import datetime as _dt
    d = (_dt.date.fromtimestamp(ts) - _dt.date.fromtimestamp(now)).days
    return 'today' if d <= 0 else ('tomorrow' if d == 1 else 'later')


def _when(ts):
    from resources.lib.sports_router import _fmt_local_time
    return _fmt_local_time(ts)


def _games(now, hours=36):
    out = []
    try:
        from resources.lib import my_teams as _mt
        from resources.lib import sports_router as _sr
        for team, ev in _mt.rows():
            if not ev:
                continue
            ts = ev.get('start_ts') or 0
            live = bool(ev.get('is_live'))
            if not live and (not ts or ts > now + hours * _HOUR):
                continue
            label = _sr.event_row_label(ev)
            logo = _mt._team_logo(ev, team['name']) or team.get('logo', '')
            out.append({
                'kind': 'game', 'section': 'live' if live else _day_section(ts, now), 'sort': ts or now,
                'title': ev.get('match_title') or ev.get('title', ''), 'row_label': '[B]%s[/B]  %s' % (team['name'], label),
                'overview': '%s%s' % (_sr.event_when(ev)[0], (' • ' + ev['score_line']) if ev.get('score_line') else ''),
                'thumb': logo, 'fanart': ev.get('away_badge') or logo, 'event': ev, 'sport': team['sport'],
            })
    except Exception as e:
        _log('games: %s' % e)
    return out


def _shows(now, days=7):
    out = []
    try:
        from resources.lib import continue_watching as _cw
        today = time.strftime('%Y-%m-%d', time.localtime(now))
        week = time.strftime('%Y-%m-%d', time.localtime(now + days * 86400))
        # every show being watched, not only the 12 most recent ones the Continue Watching row shows
        for it in _cw.get_continue_watching(200, shows_limit=100):
            kind = it.get('cw_kind')
            season, episode = it.get('cw_season'), it.get('cw_episode')
            if kind not in ('tv_next', 'tv_upcoming') or not (season and episode):
                continue
            tag = 'S%02dE%02d' % (int(season), int(episode))
            base = {'title': it.get('title', ''), 'thumb': it.get('thumb', ''), 'fanart': it.get('fanart', ''),
                    'tmdb_id': it.get('tmdb_id', ''), 'season': season, 'episode': episode, 'year': it.get('year', '')}
            if kind == 'tv_next':
                out.append(dict(base, kind='episode', section='ready', sort=-(it.get('ts') or 0),
                                row_label='[COLOR FF66CC66]READY[/COLOR]  %s  %s' % (base['title'], tag),
                                overview='%s is ready to watch.\n%s' % (tag, it.get('plot', ''))))
                continue
            air = it.get('cw_air_date', '')
            if not air or air < today or air > week:
                continue
            try:
                # the day only (no time of day is known), so noon keeps it inside the right day. Plain integers, not strptime:
                # that call fails inside Kodi on Fire TV.
                y, mo, d = [int(x) for x in air[:10].split('-')]
                ts = time.mktime((y, mo, d, 12, 0, 0, 0, 0, -1))
            except (ValueError, OverflowError):
                continue
            sec = _day_section(ts, now)
            day = {'today': 'Today', 'tomorrow': 'Tomorrow'}.get(sec) or time.strftime('%a %b %d', time.localtime(ts))
            out.append(dict(base, kind='upcoming', section=sec, sort=ts,
                            row_label='[COLOR yellow]%s[/COLOR]  %s  %s airs' % (day, base['title'], tag),
                            overview='%s airs %s.' % (tag, air)))
    except Exception as e:
        _log('shows: %s' % e)
    return out


def _anime(now):
    """Episodes of the paired account's anime airing soon, at AniList's exact time."""
    out = []
    try:
        from resources.lib import tracker_lists as _tl
        if not any(k == 'simkl' for k, _l in _tl.paired()):
            return out
        watching = [it for it in _tl.get_items('simkl', 'tv', anime=True) if it['status'] == 'watching' and it.get('anilist_id')]
        if not watching:
            return out
        from resources.lib import anime_meta as _am
        ids = ','.join(it['anilist_id'] for it in watching[:50] if str(it['anilist_id']).isdigit())
        if not ids:
            return out
        by_id = {str(it['anilist_id']): it for it in watching}
        media = _am._post('query { Page(perPage: 50) { media(id_in: [%s], type: ANIME) { id title{english romaji} '
                          'coverImage{large} nextAiringEpisode{episode airingAt} } } }' % ids)
        for m in media:
            nxt = m.get('nextAiringEpisode') or {}
            ts = nxt.get('airingAt') or 0
            if not ts or ts > now + 48 * _HOUR or ts < now - 3 * _HOUR:
                continue
            it = by_id.get(str(m.get('id')), {})
            t = m.get('title') or {}
            title = t.get('english') or t.get('romaji') or it.get('title', '')
            out.append({'kind': 'anime', 'section': _day_section(ts, now), 'sort': ts, 'title': title,
                        'row_label': '[COLOR yellow]%s[/COLOR]  %s  episode %s airs' % (_when(ts), title, nxt.get('episode')),
                        'overview': 'Episode %s of %s airs %s.' % (nxt.get('episode'), title, _when(ts)),
                        'thumb': (m.get('coverImage') or {}).get('large') or it.get('thumb', ''), 'fanart': it.get('fanart', ''),
                        'tracker_item': it, 'tmdb_id': it.get('tmdb_id', ''), 'year': it.get('year', '')})
    except Exception as e:
        _log('anime: %s' % e)
    return out


def build(now=None, scope=None):
    """Every row for the page, in display order. `scope` keeps the page to the section it was opened from: 'sports' (games),
    'tv' (episodes of shows) or 'anime' (anime episodes airing); None gives all three."""
    now = now or time.time()
    parts = {'sports': (_games,), 'tv': (_shows,), 'anime': (_anime,)}.get(scope) or (_games, _shows, _anime)
    items = []
    for part in parts:
        items += part(now)
    items.sort(key=lambda x: (_ORDER.get(x['section'], 9), x['sort']))
    # a section name before its first row, so the page reads as a schedule
    titles = {'live': 'LIVE NOW', 'today': 'TONIGHT', 'ready': 'READY TO WATCH', 'tomorrow': 'TOMORROW', 'later': 'LATER THIS WEEK'}
    seen = set()
    for it in items:
        if it['section'] not in seen:
            seen.add(it['section'])
            it['section_title'] = titles.get(it['section'], '')
    return items
