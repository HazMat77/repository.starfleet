# -*- coding: utf-8 -*-
"""YouTube trailers, played through Starfleet Resolver instead of the YouTube add-on.

url_for(video_id)  -> the plugin address every trailer button / picker row / detail window plays
normalize(url)     -> turns a YouTube add-on address or a youtube.com / youtu.be link into that address (old cached values too)
play(handle, ...)  -> the 'trailer_play' action: resolve the video, play it; the YouTube add-on only when nothing resolves

The resolver hands back YouTube's own adaptive (HLS) stream when it has one, otherwise the best single file that plays from
start to finish. (YouTube's separate high-resolution video / audio files answer 403 after the first few MB without a PO
token - that is what made trailers stop and buffer - so they are not used.)"""
import re

import xbmc
import xbmcgui
import xbmcplugin

_ADDON_URL = 'plugin://plugin.video.starfleet/?action=trailer_play&video_id=%s'
_ID = re.compile(r'(?:video_id=|youtu\.be/|[?&]v=|/embed/|/shorts/|/live/|/v/)([A-Za-z0-9_-]{11})')


def url_for(video_id, title=''):
    url = _ADDON_URL % video_id
    if title:
        from urllib.parse import quote
        url += '&title=' + quote(title)
    return url


def normalize(url):
    """Any YouTube trailer address -> url_for(); anything else is returned unchanged."""
    if not url:
        return url
    if 'action=trailer_play' in url:
        return url
    if 'plugin.video.youtube' in url or re.search(r'(?:youtube\.com|youtu\.be|youtube-nocookie\.com)/', url):
        m = _ID.search(url)
        if m:
            return url_for(m.group(1))
    return url


def _resolve(video_id):
    page = 'https://www.youtube.com/watch?v=%s' % video_id
    try:
        from resources.lib import sf_resolve as _ru
        hmf = _ru.HostedMediaFile(page)
        if hmf.valid_url():
            return hmf.resolve() or None
    except Exception as e:
        xbmc.log('[Starfleet/Trailer] resolve error: %s' % e, xbmc.LOGWARNING)
    return None


def play(handle, video_id, title=''):
    if not video_id:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    resolved = _resolve(video_id)
    if resolved and resolved.startswith('plugin://'):          # the resolver itself handed it to the YouTube add-on
        xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path=resolved))
        return
    if resolved:
        try:
            from resources.lib.router import _hls_item
            li = _hls_item(resolved, title, force_hls=('.m3u8' in resolved.split('|')[0].lower() or 'hls_variant' in resolved))
        except Exception as e:
            xbmc.log('[Starfleet/Trailer] item error: %s' % e, xbmc.LOGWARNING)
            li = xbmcgui.ListItem(path=resolved)
        xbmc.log('[Starfleet/Trailer] %s via resolver: %s' % (video_id, resolved.split('|')[0][:70]), xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(handle, True, li)
        return
    # nothing resolved: the YouTube add-on, if it is installed
    try:
        if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
            xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(
                path='plugin://plugin.video.youtube/play/?video_id=%s' % video_id))
            return
    except Exception:
        pass
    xbmcgui.Dialog().notification('Starfleet', 'Trailer unavailable', xbmcgui.NOTIFICATION_WARNING, 3000)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
