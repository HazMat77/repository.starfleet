# -*- coding: utf-8 -*-
"""
resources/lib/adult_prewarm.py

Adult widgets, ready before you open them. When BOTH "Show Adult section in main menu" and "Get the Adult widgets ready in the
background" are on, the background service builds the slow part of the Adult Home rows (the New Releases / Recently Added pages and
the XXXClub check of each film) shortly after Kodi starts and again every hour, never while something is playing. Nothing happens
when either setting is off - no request at all.
"""
import xbmc
import xbmcaddon

GAP = 60 * 60


def _on():
    try:
        a = xbmcaddon.Addon('plugin.video.starfleet')
        return a.getSetting('adult_enabled') == 'true' and a.getSetting('adult_prewarm') == 'true'
    except Exception:
        return False


def tick():
    """One pass for the scheduler: build the Adult rows when both settings are on. Returns seconds until the next pass."""
    try:
        if _on():
            from resources.lib import afdb_router
            afdb_router.prewarm_adult_rows()
            return GAP
    except Exception as e:
        xbmc.log('[Starfleet/AdultPrewarm] pass failed: %s' % e, xbmc.LOGWARNING)
    return GAP if _on() else 300


def run(monitor):
    """Service thread body. Never raises."""
    if monitor.waitForAbort(90):
        return
    while not monitor.abortRequested():
        try:
            if _on() and not xbmc.Player().isPlaying():
                from resources.lib import afdb_router
                afdb_router.prewarm_adult_rows()
        except Exception as e:
            xbmc.log('[Starfleet/AdultPrewarm] pass failed: %s' % e, xbmc.LOGWARNING)
        if monitor.waitForAbort(GAP if _on() else 300):
            break
