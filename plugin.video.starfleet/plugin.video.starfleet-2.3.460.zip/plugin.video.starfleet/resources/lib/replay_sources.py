# -*- coding: utf-8 -*-
"""
resources/lib/replay_sources.py

Replay scraper — PAST events (full fight/game replays with real dates),
architecturally separate from sports_sources.py's LIVE-sports scraping.
Investigated live 2026-08-16 against 4 candidate sites; all 4 turned out to
be real/scrapable (no CF/JS-challenge dead ends this time), but they split
cleanly across the 3 target categories rather than each covering all 3:

  UFC     — watchmmafull.com  (per-INDIVIDUAL-FIGHT pages, one URL per
             matchup) + fullfightreplays.com (per-CARD-SECTION links —
             Main Card/Prelims/Early Prelims, each with 2-3 alternate
             hosts). Both merged per numbered PPV event (e.g. "UFC 330")
             so a single event offers fight-by-fight AND full-card options
             side by side, per the picker design this module is built for.
  Boxing  — fullfightreplays.com (per-fight, multiple host "servers") +
             box.live/full-fight-replays (per-fight, single official
             broadcaster YouTube embed — confirmed live via PBC's own
             channel — but only once uploaded; many recent fights show the
             site's own honest "no replay yet" state, handled as empty).
  MLB     — mlblive.net only (per-GAME, single embed host). Deep real
             archive confirmed live back through the 2025 World Series
             (Dodgers vs Blue Jays, Games 1-7) via its year-indexed pages,
             though the live listing pages themselves are NOT paginated
             (confirmed live: /page/2 on every listing 404s) so only the
             ~10-16 most recent items per page are visible at once.

Confirmed dead ends: none of the 4 — see box.live's sister-site note below
for the one thing that ISN'T covered (MMA/UFC on box.live itself).

── Site-by-site findings (all confirmed live 2026-08-16) ──────────────────

watchmmafull.com (UFC/MMA):
  - Despite "UFC MMA BOXING KICKBOXING" in its own <title> tag, /tag/boxing
    returns zero results live — this site is UFC/MMA-only in practice.
  - Only browsable catalog is the homepage's "New Video" list — /events,
    /search and /page/2 all dead-end to a generic 404 template (confirmed
    live), so this source only ever surfaces whichever ~2 most-recent
    events happen to be on the homepage at fetch time (was UFC 330 +
    UFC Vegas 120, 12 individual fight pages each, when checked).
  - Real per-fight granularity: each matchup (e.g. "Islam Makhachev vs
    Ian Machado Garry") is its own page/URL — confirmed 24 distinct fight
    pages across 2 real events on 2 real different dates. No full-card
    bundle page exists (ufc-330-full-card.html style URLs all 404).
  - Stream mechanism varies PER EVENT (not per fight): UFC 330's fights
    all embed via playmate.to, which is cleanly resolvable with plain
    requests (see _wmf_resolve_fight docstring) to a real, playable ~48-
    minute HLS stream. UFC Vegas 120's fights all embedded via
    suisports.upns.xyz instead — a bare JS-SPA shell (empty <body>,
    everything bootstrapped client-side, fight id only in a URL #hash)
    with nothing server-rendered to scrape, the same dead-end class as
    this addon's other confirmed JS-SPA embeds. Handled by resolving
    playmate.to embeds and skipping (not returning a dead link for)
    anything else, logged at LOGINFO so it's visible without being noisy.
  - No per-event thumbnail anywhere (listing <img src=""> is a lazy-load
    placeholder with no data-src fallback; individual fight pages'
    og:image is also empty) — confirmed live. TMDB is this category's
    only real art source for events from this site specifically.

fullfightreplays.com (UFC AND Boxing):
  - Real multi-org combat-sports catalog: UFC, Boxing, Bellator, ONE
    Championship, Cage Warriors, BKFC, Invicta FC, KSW, K-1. Only UFC and
    Boxing are built out below since those are the 2 of 3 target
    categories it actually covers.
  - Single-page listings per category (/ufc, /boxing) with no working
    pagination (/ufc/page/2 and /boxing/page/2 both 404, confirmed live)
    — ~10 real events per category at check time, spanning roughly one to
    two months back (e.g. boxing: Errol Spence Jr. vs. Tim Tszyu, Jul 26
    2026, through Claressa Shields vs. Kaye Scott, Aug 15 2026).
  - UFC granularity is per-CARD-SECTION, not per-fight: "Main Card" (in
    2 quality tiers x up to 3 parts via Dailymotion, plus OK.ru and
    Filemoon-mirror alternates), "Prelims", "Early Prelims" — each
    section/host pairing is its own selectable link. This is the "full
    card" counterpart to watchmmafull.com's per-fight breakdown.
  - Boxing granularity is per-fight (as expected, one bout per card),
    multiple alternate-host "servers" (OK.ru + Filemoon-mirror, confirmed
    live) per fight.
  - Real per-event thumbnail confirmed live for every listing entry
    (/_pu/<n>/<id>.png|jpg — distinct, working image per event).
  - No CAPTCHA/CF/JS wall on any page hit (listing, event, or embed pages).

box.live/full-fight-replays (Boxing ONLY):
  - Confirmed live: this is boxing-only. The fight-detail page template
    itself says "Love MMA & UFC too? Try our sister site, Cage Walks" —
    an explicit, direct confirmation it does NOT cover UFC/MMA despite
    "full fight replays" reading generically. Not used for the UFC
    category at all as a result.
  - Deep, well-organized real catalog (/fight-results/ listed 38 distinct
    real recent bouts when checked, e.g. Spence vs Tszyu Jul 26 2026,
    Fundora vs Thurman Mar 28 2026) with a real per-fight detail page for
    each (/fights/<slug>/), each carrying a real date and 2 real fighter
    photos in its hero section.
  - Replay video, when present, is a single OFFICIAL broadcaster YouTube
    embed — confirmed live: Fundora vs Thurman's embed resolves via
    YouTube's own oEmbed to "PBC FULL FIGHT: Fundora vs Thurman | March
    28, 2026" on the real Premier Boxing Champions channel. Highest-
    legitimacy source of the 4, but NOT every fight has one yet — spot-
    checking 12 real fights live found only 2 with a replay uploaded so
    far; the rest show the site's own honest "Sorry, we couldn't find any
    replay videos... yet" message (handled as an empty result here, never
    a broken/fake link).

mlblive.net (MLB ONLY):
  - NFL/NBA nav links point off-site to sister domains (nfl-video.com,
    basketball-video.com) — confirmed this specific site is MLB-only.
  - Same site engine/template as fullfightreplays.com (same "/_pu/<n>/
    <id>" thumbnail path scheme, same "Server #N" + embed-host markup) —
    _ffr_parse_sources() below is reused as-is for MLB event pages.
  - Real, deep catalog: homepage + year-indexed listing pages go back to
    2021 including the complete real 2025 World Series game-by-game
    (Los Angeles Dodgers vs Toronto Blue Jays, Games 1 through 7, real
    dates Oct 24 - Nov 1 2025) confirmed live, plus the current 2026
    regular season (multiple real games checked for Aug 15 2026: Rangers
    @ Athletics, Royals @ Angels, Brewers @ Dodgers, etc). No listing page
    is paginated though (confirmed live 404 on /page/2 for every listing
    tried) — only the most-recent ~12-16 games per page/day are visible;
    older days are reachable only via the year-index pages, which
    themselves only surface a curated/recent slice, not exhaustive daily
    coverage. One game per event (no innings-level breakdown attempted —
    not offered by the site and not asked for).
  - Real per-event thumbnail confirmed live, same /_pu/ scheme as above.

TMDB icon feasibility (checked live via /search/movie, api.themoviedb.org
using the same TMDB_KEYS this addon already uses in metadata.py):
  - UFC: excellent coverage. Every real event name pulled from the scrape
    above resolved to exactly one movie result with a real poster_path —
    "UFC 330" -> "UFC 330: Makhachev vs. Machado Garry" (2026-08-15,
    poster /dG6WMwBdPjSxlXFuBed4DKDAcdM.jpg), "UFC 329" -> "UFC 329:
    McGregor vs. Holloway 2", and even watchmmafull.com's own "UFC Vegas
    120" naming correctly fuzzy-matched to the same TMDB entry
    fullfightreplays.com calls "UFC Fight Night 284: Gamrot vs. Salkilld"
    (2026-08-08, poster /qSsDud1zHhodVHDs439xEj33OTK.jpg) — TMDB catalogs
    these as /search/movie results (PPV "event specials"), not /search/tv.
  - Boxing: also excellent. "Errol Spence Jr vs Tim Tszyu" ->
    "Errol Spence Jr. vs. Tim Tszyu" (2026-07-25, real poster), "Claressa
    Shields vs Kaye Scott" -> exact match (2026-08-15, real poster),
    "Fundora vs Thurman" -> "Sebastian Fundora vs. Keith Thurman"
    (2026-03-28, real poster) — same /search/movie pattern as UFC.
  - MLB: confirmed NOT catalogued, as expected. "Texas Rangers vs
    Athletics", "Los Angeles Dodgers vs Toronto Blue Jays World Series
    Game 7", "Milwaukee Brewers vs Los Angeles Dodgers" all returned 0
    results on both /search/movie and /search/tv — individual MLB games
    are not TMDB/IMDb entries. MLB events should fall back to a generic
    MLB/team logo (this addon already has ESPN CDN team-logo plumbing in
    sports_sources.py's _espn_logo — the mlblive.net per-event thumbnail
    below is also a real, live-confirmed fallback in the meantime).
  get_replay_poster() below wraps metadata.search_movies() for this.

Per-event site-native thumbnail (checked live per the follow-up request —
"does the source site itself expose a real per-event image, for the cases
TMDB won't have one"):
  - UFC:    watchmmafull.com has NONE (empty <img src> and empty og:image,
            confirmed live) — TMDB is the only real art source for events
            sourced from there. fullfightreplays.com DOES have one, a
            real distinct image per event (/_pu/<n>/<id>.png|jpg,
            confirmed live 200/real bytes) — carried in event['thumb']
            when an event has an ffr_url.
  - Boxing: fullfightreplays.com — same real per-event thumbnail as UFC
            above. box.live has no single fight-poster image, but DOES
            have 2 real per-fighter hero photos on every fight page
            (confirmed live, distinct real files, not the site's own
            'blank-fighter.png' placeholder for the fights checked) —
            carried as event['fighter1_photo']/['fighter2_photo'].
  - MLB:    mlblive.net has a real per-event thumbnail, same /_pu/ scheme
            as fullfightreplays.com (confirmed live) — carried in
            event['thumb'].

Return shape (per the eventual Sports > Replay > [UFC|Boxing|MLB] >
[dates] > [events] > [fight/source picker] menu this is built for):
  get_replay_dates(sport)          -> [{'date_key': 'YYYY-MM-DD',
                                         'label': 'Month D, YYYY'}, ...]
                                       most recent first.
  get_replay_events(sport, date_key) -> [event dict, ...] — each carries
                                       at least 'title', 'date_key',
                                       'date_label', 'id', 'thumb', plus
                                       internal fields (e.g. 'wmf_fights',
                                       'ffr_url', 'boxlive_url') that
                                       get_replay_sources() reads back.
                                       Pass one of these dicts straight
                                       into get_replay_sources() — no
                                       separate lookup needed.
  get_replay_sources(sport, event) -> [{'label': str, 'url': str}, ...] —
                                       individual fight/matchup entries
                                       AND full-card/section entries are
                                       both included as separate options
                                       whenever the source site offers
                                       both, never one-or-the-other.

Cache: event catalogs 20 min, individual source-page resolutions 15 min,
TMDB poster lookups 24h (via metadata.py's own cache calls).
"""

import re
import html as _html
import datetime
import xbmc
import xbmcaddon
import xbmcvfs
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests as _req
from resources.lib import cache as _cache

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_cache.init(_PROFILE + '/cache.db')

# Same browser-header convention as sports_sources.py/torrent_sources.py —
# no 'br' (Brotli) since decoding it needs an optional dependency this
# environment doesn't have; gzip/deflate are handled natively.
_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
}

_WMF_BASE     = 'https://watchmmafull.com'
_FFR_BASE     = 'https://fullfightreplays.com'
_BOXLIVE_BASE = 'https://box.live'
_MLBLIVE_BASE = 'https://mlblive.net'


def _get(url, timeout=12, referer=''):
    try:
        headers = dict(_HEADERS)
        if referer:
            headers['Referer'] = referer
        r = _req.get(url, headers=headers, timeout=timeout)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Replay] GET %s: %s' % (url[:90], e), xbmc.LOGWARNING)
        return ''


_RE_WS = re.compile(r'\s+')


def _clean(t):
    return _RE_WS.sub(' ', _html.unescape(t or '')).strip(' - ')


def _parse_date(s):
    """Parse the various date-string formats used across the 4 sites
    ('August 15, 2026' / 'Aug 09, 2026' / 'Saturday, Aug 08 2026') into
    (date_key 'YYYY-MM-DD', label 'Month D, YYYY'). Returns (None, s) on
    failure so one malformed date can never crash a whole catalog fetch —
    the caller just drops that entry."""
    if not s:
        return None, ''
    s2 = re.sub(r'^[A-Za-z]+,\s*', '', s.strip())  # strip leading weekday, e.g. "Saturday, "
    s2 = s2.replace(',', '')
    for fmt in ('%B %d %Y', '%b %d %Y'):
        try:
            d = datetime.datetime.strptime(s2, fmt).date()
            return d.isoformat(), d.strftime('%B %d, %Y')
        except Exception:
            continue
    return None, s.strip()


# ── watchmmafull.com (UFC/MMA — per-fight) ──────────────────────────────────

_RE_WMF_ITEM = re.compile(
    r'<li class="video-item-compact">(.*?)</li>\s*(?=<li class="video-item-compact">|</ul>)',
    re.S)
_RE_WMF_TITLE     = re.compile(r'title="([^"]+)"', re.I)
_RE_WMF_HREF      = re.compile(r'href="(/[a-z0-9\-]+\.html)"\s+class="video-thumb-small"', re.I)
_RE_WMF_WATCH_BTN = re.compile(r'<a href="([^"]+)"\s+class="watch-link-btn', re.I)
_RE_WMF_FILECODE  = re.compile(r'/embed/([A-Za-z0-9]+)')


def _wmf_scrape_ufc():
    """See module docstring's watchmmafull.com section for what's confirmed
    live about this site's real catalog depth/shape. Groups the individual
    fight-card entries (title format always "EVENT - FIGHTER A vs.
    FIGHTER B - DATE", confirmed stable live) by event into one dict per
    real event, each carrying its list of per-fight page URLs."""
    html = _get(_WMF_BASE + '/')
    if not html:
        return []

    events = {}  # (event_name, date_key) -> event dict
    for block in _RE_WMF_ITEM.findall(html):
        href_m  = _RE_WMF_HREF.search(block)
        title_m = _RE_WMF_TITLE.search(block)
        if not href_m or not title_m:
            continue
        title = _clean(title_m.group(1))
        parts = [p.strip() for p in title.split(' - ')]
        if len(parts) < 3:
            continue
        event_name, fighters, date_str = parts[0], parts[1], parts[-1]
        date_key, date_label = _parse_date(date_str)
        if not date_key:
            continue
        key = (event_name, date_key)
        ev = events.setdefault(key, {
            'sport': 'ufc', 'source': 'watchmmafull',
            'title': event_name, 'date_key': date_key, 'date_label': date_label,
            'id': 'wmf_%s_%s' % (re.sub(r'\W+', '_', event_name.lower()).strip('_'), date_key),
            'thumb': '', 'fanart': '',
            'wmf_fights': [],
        })
        ev['wmf_fights'].append({
            'label': fighters.replace(' vs.', ' vs'),
            'url':   _WMF_BASE + href_m.group(1),
        })

    return list(events.values())


def _wmf_resolve_fight(fight_url):
    """Resolve one watchmmafull.com fight page to a real playable URL, or
    None if the event's embed host is an unresolvable JS-SPA (see module
    docstring — this varies per EVENT, not per fight). playmate.to embeds
    resolve via a plain POST to its own /api/s endpoint with the filecode
    parsed out of the embed URL, returning {'sx': '<master m3u8 URL>'} —
    confirmed live real HLS (#EXTM3U) whose segments carry deliberately
    fake .css/.js/.woff extensions (real MPEG-TS bytes underneath, 0x47
    sync byte confirmed) as a crude scraper-deterrent; Kodi's own HLS
    demuxer reads the playlist by its declared content, not the URL
    suffix, so this plays fine as a direct stream URL."""
    ck = 'replay_wmf_fight_%s' % re.sub(r'\W+', '_', fight_url)[-80:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None

    html = _get(fight_url)
    m = _RE_WMF_WATCH_BTN.search(html) if html else None
    if not m:
        _cache.set(ck, False, 15 * 60)
        return None
    embed_url = m.group(1)

    if 'playmate.to' in embed_url:
        fc_m = _RE_WMF_FILECODE.search(embed_url)
        if fc_m:
            try:
                r = _req.post(
                    'https://playmate.to/api/s',
                    json={'filecode': fc_m.group(1)},
                    headers=dict(_HEADERS, Referer=embed_url, Origin='https://playmate.to',
                                 **{'Content-Type': 'application/json'}),
                    timeout=10)
                r.raise_for_status()
                sx = r.json().get('sx', '') or None
                _cache.set(ck, sx or False, 15 * 60)
                return sx
            except Exception as e:
                xbmc.log('[Starfleet/Replay] watchmmafull playmate.to resolve failed (%s): %s'
                         % (fight_url[:60], e), xbmc.LOGWARNING)

    # Unknown/JS-SPA embed host (e.g. suisports.upns.xyz — bare JS bootstrap
    # shell, nothing server-rendered) — no real link to scrape, skip rather
    # than hand back a dead one.
    xbmc.log('[Starfleet/Replay] watchmmafull unresolved embed host for %s: %s'
             % (fight_url[:60], embed_url), xbmc.LOGINFO)
    _cache.set(ck, False, 15 * 60)
    return None


# ── fullfightreplays.com (UFC + Boxing) / mlblive.net (MLB) shared template ──
# Confirmed live: both sites are built on the same site engine — same
# "/_pu/<n>/<id>" thumbnail scheme, same event-listing markup, same
# "<strong>/<b>Section header</strong>" + su-button-link-or-iframe watch
# section on event pages — so one pair of parsers covers all 3 of this
# module's 3 target categories for these 2 sites.

_RE_FFR_LIST_ITEM = re.compile(
    r'<a href="(/[a-z0-9\-]+)"><img src="(/_pu/[^"]+)" alt="[^"]*"></a>.*?'
    r'<h3><a href="\1">([^<]+)</a></h3>.*?'
    r'<p>([A-Za-z]+ \d{1,2}, \d{4})[^<]*</p>',
    re.S)


def _ffr_scrape_listing(base, path):
    """Scrape a fullfightreplays.com/mlblive.net category or homepage
    listing page. Confirmed live: single page, no working pagination
    (every /page/2 tried 404s) — returns whatever's on that one page."""
    html = _get(base + path)
    events = []
    if not html:
        return events
    for href, thumb, title, date_str in _RE_FFR_LIST_ITEM.findall(html):
        date_key, date_label = _parse_date(date_str)
        if not date_key:
            continue
        events.append({
            'title': _clean(title), 'url': base + href, 'thumb': base + thumb,
            'date_key': date_key, 'date_label': date_label,
        })
    return events


_RE_FFR_HEADER = re.compile(
    # Section headings appear both as <strong><span>Text</span></strong>
    # (mlblive.net's "Server #N") and plain <strong>Text</strong> /
    # <b>Text</b> (fullfightreplays.com's "Main Card...", "OK", "Fiilemoon"
    # [sic]) — confirmed live both nestings occur, so the inner <span> is
    # optional here rather than assumed either way.
    r'<(?:strong|b)>\s*(?:<span[^>]*>)?\s*([^<]{1,60}?)\s*(?:</span>)?\s*</(?:strong|b)>', re.I)
_RE_FFR_BUTTON = re.compile(
    r'class="su-button[^"]*"[^>]*href="([^"]+)"[^>]*>.*?<span[^>]*>([^<]{1,20})</span>',
    re.I | re.S)
_RE_FFR_IFRAME = re.compile(r'<iframe[^>]+src="((?:https?:)?//[^"]+)"', re.I)

# Short/typo'd site labels normalized to a clearer host name for the picker
# (confirmed live "OK" and "Fiilemoon" [sic] are exactly what the site's
# own HTML uses for these 2 headers).
_FFR_HOST_SYNONYMS = {'ok': 'OK.ru', 'fiilemoon': 'Filemoon', 'filemoon': 'Filemoon'}


def _ffr_parse_sources(html):
    """Generic 'section heading (<strong>/<b>) applies to every su-button
    link or raw <iframe> that follows it, until the next heading' parser —
    confirmed live against both fullfightreplays.com's UFC (Main Card in
    2 quality tiers x parts, Prelims, Early Prelims x multiple hosts) and
    Boxing (Server #1/#2 x host) event pages, and mlblive.net's game pages
    (single "Server #N" x host)."""
    if not html:
        return []
    tokens = []
    for m in _RE_FFR_HEADER.finditer(html):
        tokens.append((m.start(), 'header', _clean(m.group(1))))
    for m in _RE_FFR_BUTTON.finditer(html):
        tokens.append((m.start(), 'button', (m.group(1), _clean(m.group(2)))))
    for m in _RE_FFR_IFRAME.finditer(html):
        tokens.append((m.start(), 'iframe', m.group(1)))
    tokens.sort(key=lambda t: t[0])

    results = []
    seen    = set()
    cur_header = ''
    for _, kind, val in tokens:
        if kind == 'header':
            cur_header = _FFR_HOST_SYNONYMS.get(val.lower(), val)
            continue
        url, label = val if kind == 'button' else (val, '')
        url = _html.unescape(url)
        url = url if url.startswith('http') else 'https:' + url
        if url in seen:
            continue
        seen.add(url)
        if label and label.lower() != 'watch' and cur_header:
            full_label = '%s - %s' % (cur_header, label)
        else:
            full_label = cur_header or label or 'Watch'
        results.append({'label': full_label, 'url': url})
    return results


def _ffr_event_sources(url):
    ck = 'replay_ffr_src_%s' % re.sub(r'\W+', '_', url)[-80:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    result = _ffr_parse_sources(_get(url))
    _cache.set(ck, result, 15 * 60)
    return result


# ── box.live (Boxing only) ───────────────────────────────────────────────────

_RE_BOXLIVE_VS_LINK = re.compile(r'href="(https://box\.live/fights/[a-z0-9\-]+-vs-[a-z0-9\-]+/)"')
_RE_BOXLIVE_H1       = re.compile(r'<h1[^>]*>\s*([^<]+?)\s*</h1>', re.I)
_RE_BOXLIVE_DATE     = re.compile(r'fight-date__str1[^>]*>\s*([^<]+?)\s*<', re.I)
_RE_BOXLIVE_VIDEO    = re.compile(r'replay-iframe[^>]*src="([^"]+)"', re.I)
_RE_BOXLIVE_PHOTO    = re.compile(
    r'data-src="(https://box\.live/wp-content/uploads/[^"]+\.(?:png|jpg))"', re.I)
_BOXLIVE_PHOTO_SKIP = ('ppv', 'amazon', 'banner', 'sponsor', 'blank-fighter', 'logo')


def _boxlive_fight_detail(url):
    """Fetch one box.live /fights/<slug>/ page. Returns None on fetch
    failure; otherwise a dict — 'video_url' is '' (not missing) when the
    site's own honest 'no replay yet' state applies, which is common for
    fights within the last couple of weeks (confirmed live: not every
    fight gets an official replay upload, and it can take weeks when it
    does)."""
    html = _get(url)
    if not html:
        return None
    h1_m   = _RE_BOXLIVE_H1.search(html)
    date_m = _RE_BOXLIVE_DATE.search(html)
    if not h1_m or not date_m:
        return None
    date_key, date_label = _parse_date(date_m.group(1))
    if not date_key:
        return None

    video_m = _RE_BOXLIVE_VIDEO.search(html)

    # Hero fighter photos: scoped to the region between the fight-card
    # header and the replays section so an ad banner or undercard-fighter
    # thumbnail elsewhere on the page can't get picked up instead.
    i0 = html.find('single-fight')
    i1 = html.find('id="replays"')
    region = html[i0:i1] if 0 <= i0 < i1 else html[:20000]
    photos = []
    for p in _RE_BOXLIVE_PHOTO.finditer(region):
        u = p.group(1)
        if any(skip in u.lower() for skip in _BOXLIVE_PHOTO_SKIP):
            continue
        if u not in photos:
            photos.append(u)
        if len(photos) >= 2:
            break

    return {
        'title':      _clean(h1_m.group(1)),
        'url':        url,
        'date_key':   date_key,
        'date_label': date_label,
        'video_url':  video_m.group(1) if video_m else '',
        'fighter1_photo': photos[0] if len(photos) > 0 else '',
        'fighter2_photo': photos[1] if len(photos) > 1 else '',
    }


def _boxlive_scrape_boxing():
    """box.live's /fight-results/ listing gives slugs + records but not a
    clean per-card date/title in one pass (that page is a stats/results
    table, not a blog-style listing like fullfightreplays.com's), so each
    real fight found there is fetched individually for its date, video
    (if any) and fighter photos — bounded (~38 real fights at check time)
    and threaded, same pattern sports_sources.py already uses for
    concurrent per-item fetches."""
    html = _get(_BOXLIVE_BASE + '/fight-results/')
    if not html:
        return []
    slugs = list(dict.fromkeys(_RE_BOXLIVE_VS_LINK.findall(html)))  # de-dup, preserve order

    events = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        futures = {ex.submit(_boxlive_fight_detail, u): u for u in slugs}
        for fut in as_completed(futures):
            try:
                d = fut.result()
            except Exception as e:
                xbmc.log('[Starfleet/Replay] box.live fight detail: %s' % e, xbmc.LOGWARNING)
                continue
            if d:
                events.append(d)
    return events


# ── UFC catalog (merge watchmmafull.com per-fight + fullfightreplays.com
#    per-card-section, matched by numbered PPV, e.g. "UFC 330") ────────────

_UFC_NUM_RE = re.compile(r'\bUFC\s+(\d{3,4})\b', re.I)


def _get_ufc_catalog():
    ck = 'replay_catalog_ufc_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        wmf_events = _wmf_scrape_ufc()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] wmf ufc scrape: %s' % e, xbmc.LOGWARNING)
        wmf_events = []
    try:
        ffr_events = _ffr_scrape_listing(_FFR_BASE, '/ufc')
    except Exception as e:
        xbmc.log('[Starfleet/Replay] ffr ufc scrape: %s' % e, xbmc.LOGWARNING)
        ffr_events = []

    ffr_by_num = {}
    ffr_unmatched = []
    for ev in ffr_events:
        m = _UFC_NUM_RE.search(ev['title'])
        (ffr_by_num.__setitem__(m.group(1), ev) if m else ffr_unmatched.append(ev))

    catalog = []
    matched_nums = set()
    for ev in wmf_events:
        m = _UFC_NUM_RE.search(ev['title'])
        num = m.group(1) if m else None
        merged = dict(ev)
        if num and num in ffr_by_num:
            ffr_ev = ffr_by_num[num]
            merged['title'] = ffr_ev['title']       # fuller name, e.g. includes headliners
            merged['ffr_url'] = ffr_ev['url']
            merged['thumb'] = ffr_ev.get('thumb', '')
            matched_nums.add(num)
        catalog.append(merged)

    for num, ev in ffr_by_num.items():
        if num in matched_nums:
            continue
        catalog.append({
            'sport': 'ufc', 'source': 'fullfightreplays', 'title': ev['title'],
            'date_key': ev['date_key'], 'date_label': ev['date_label'],
            'id': 'ffr_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
            'thumb': ev.get('thumb', ''), 'fanart': '',
            'ffr_url': ev['url'], 'wmf_fights': [],
        })
    for ev in ffr_unmatched:
        catalog.append({
            'sport': 'ufc', 'source': 'fullfightreplays', 'title': ev['title'],
            'date_key': ev['date_key'], 'date_label': ev['date_label'],
            'id': 'ffr_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
            'thumb': ev.get('thumb', ''), 'fanart': '',
            'ffr_url': ev['url'], 'wmf_fights': [],
        })

    catalog.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, catalog, 20 * 60)
    return catalog


# ── Boxing catalog (fullfightreplays.com + box.live, kept as separate
#    entries per source rather than merged — the 2 sites' naming
#    conventions differ too much to match reliably: "Claressa Shields vs.
#    Kaye Scott" vs box.live's surname-only "Shields vs Scott" h1 — safer
#    to list both plainly labeled by source than risk a wrong merge) ───────

def _get_boxing_catalog():
    ck = 'replay_catalog_boxing_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    catalog = []
    try:
        for ev in _ffr_scrape_listing(_FFR_BASE, '/boxing'):
            catalog.append({
                'sport': 'boxing', 'source': 'fullfightreplays', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'ffr_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'ffr_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] ffr boxing scrape: %s' % e, xbmc.LOGWARNING)

    try:
        for ev in _boxlive_scrape_boxing():
            catalog.append({
                'sport': 'boxing', 'source': 'boxlive', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'bl_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('fighter1_photo', ''), 'fanart': ev.get('fighter2_photo', ''),
                'fighter1_photo': ev.get('fighter1_photo', ''),
                'fighter2_photo': ev.get('fighter2_photo', ''),
                'boxlive_url': ev['url'], 'boxlive_video': ev.get('video_url', ''),
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] boxlive boxing scrape: %s' % e, xbmc.LOGWARNING)

    catalog.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, catalog, 20 * 60)
    return catalog


# ── MLB catalog (mlblive.net only — homepage + current-year index merged
#    and de-duplicated by URL, since neither page alone is exhaustive and
#    both are un-paginated, confirmed live) ─────────────────────────────────

def _get_mlb_catalog():
    ck = 'replay_catalog_mlb_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    catalog = {}
    year = datetime.date.today().year
    for path in ('/', '/%d-mlb-full-game-replays' % year):
        try:
            for ev in _ffr_scrape_listing(_MLBLIVE_BASE, path):
                catalog[ev['url']] = ev
        except Exception as e:
            xbmc.log('[Starfleet/Replay] mlblive scrape (%s): %s' % (path, e), xbmc.LOGWARNING)

    result = []
    for ev in catalog.values():
        result.append({
            'sport': 'mlb', 'source': 'mlblive', 'title': ev['title'],
            'date_key': ev['date_key'], 'date_label': ev['date_label'],
            'id': 'mlb_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
            'thumb': ev.get('thumb', ''), 'fanart': '',
            'mlblive_url': ev['url'],
        })
    result.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, result, 20 * 60)
    return result


_CATALOG_FUNCS = {
    'ufc':    _get_ufc_catalog,
    'boxing': _get_boxing_catalog,
    'mlb':    _get_mlb_catalog,
}


# ── Public API ────────────────────────────────────────────────────────────

def get_replay_dates(sport):
    """Real dates (most recent first) that have at least one replay event
    for `sport` ('ufc' / 'boxing' / 'mlb'), across every source confirmed
    live for that sport (see module docstring)."""
    fn = _CATALOG_FUNCS.get(sport)
    if not fn:
        return []
    try:
        catalog = fn()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_dates(%s): %s' % (sport, e), xbmc.LOGWARNING)
        return []

    seen = {}
    for ev in catalog:
        dk = ev.get('date_key')
        if dk and dk not in seen:
            seen[dk] = ev.get('date_label', dk)
    return [{'date_key': dk, 'label': seen[dk]} for dk in sorted(seen, reverse=True)]


def get_replay_events(sport, date_key):
    """Events for `sport` on `date_key` ('YYYY-MM-DD'), most-recently-added
    source first. Each dict carries everything get_replay_sources() needs
    — pass it straight through, no separate lookup required."""
    fn = _CATALOG_FUNCS.get(sport)
    if not fn:
        return []
    try:
        catalog = fn()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_events(%s, %s): %s' % (sport, date_key, e), xbmc.LOGWARNING)
        return []
    return [ev for ev in catalog if ev.get('date_key') == date_key]


def get_replay_sources(sport, event):
    """Every real playable option for `event` (as returned by
    get_replay_events), individual-fight AND full-card/section entries
    both included whenever the underlying site(s) offer both — never
    picking just one. Entries with a broken/unresolvable underlying embed
    are silently skipped rather than returned as a dead link."""
    sources = []
    try:
        if sport == 'ufc':
            for fight in event.get('wmf_fights') or []:
                url = _wmf_resolve_fight(fight['url'])
                if url:
                    sources.append({'label': fight['label'], 'url': url})
            ffr_url = event.get('ffr_url')
            if ffr_url:
                sources.extend(_ffr_event_sources(ffr_url))

        elif sport == 'boxing':
            ffr_url = event.get('ffr_url')
            if ffr_url:
                sources.extend(_ffr_event_sources(ffr_url))
            bl_url = event.get('boxlive_url')
            if bl_url:
                video = event.get('boxlive_video', '')
                if not video:
                    # Event dict may predate a video being uploaded, or came
                    # from a cached catalog — re-check live rather than
                    # trusting a stale 'no replay yet' from catalog-build time.
                    detail = _boxlive_fight_detail(bl_url)
                    video = detail.get('video_url', '') if detail else ''
                if video:
                    sources.append({'label': 'Full Fight (Official YouTube)', 'url': video})

        elif sport == 'mlb':
            mlb_url = event.get('mlblive_url')
            if mlb_url:
                sources.extend(_ffr_event_sources(mlb_url))

    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_sources(%s, %r): %s'
                 % (sport, event.get('title', ''), e), xbmc.LOGWARNING)

    return sources


# ── TMDB poster lookup (icon feasibility — see module docstring) ──────────

def get_replay_poster(title):
    """UFC/Boxing event poster via TMDB, wrapping metadata.py's own
    search_movies() (same TMDB_KEYS, same 24h cache) rather than
    duplicating key rotation here — confirmed live this reliably finds
    both UFC PPVs/Fight Nights and named boxing matchups (see module
    docstring for real examples). Returns {} for MLB games (confirmed
    live these are never on TMDB) or on any lookup failure — callers
    should fall back to the site-native thumbnail/fanart already present
    on the event dict, or a generic sport logo, when this is empty."""
    if not title:
        return {}
    try:
        from resources.lib import metadata as _meta
        results = _meta.search_movies(title)
        if results:
            m = results[0]
            return {'thumb': m.get('thumb', ''), 'fanart': m.get('fanart', '')}
    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_poster(%r): %s' % (title, e), xbmc.LOGWARNING)
    return {}
