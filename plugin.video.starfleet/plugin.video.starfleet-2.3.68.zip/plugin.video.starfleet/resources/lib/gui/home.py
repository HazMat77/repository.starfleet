"""
Starfleet Home Window — Amazon Prime Video-style GUI
xbmcgui.WindowXML subclass that shows a hero + carousel layout.
"""
import threading
import xbmc
import xbmcgui
import xbmcaddon

_ADDON = xbmcaddon.Addon('plugin.video.starfleet')

# Control IDs (match Starfleet-Home.xml)
_ID_HERO_PLAY   = 20
_ID_HERO_INFO   = 21
_ID_HERO_ADD    = 22
_ID_NAV_HOME    = 40
_ID_NAV_MOVIES  = 41
_ID_NAV_TV      = 42
_ID_NAV_SPORTS  = 43
_ID_NAV_LIVE    = 44
_ID_NAV_ADULT   = 45
_ID_NAV_SEARCH  = 46
_ID_ROW0        = 100
_ID_ROW1        = 200
_ID_ROW2        = 300

_ROW_LABELS = ['New Releases', 'Popular', 'Trending']
_ROW_ACTIONS = ['afdb_new', 'afdb_popular', 'afdb_trending']

_TRAILER_DELAY = 4  # seconds before trailer auto-plays


class HomeWindow(xbmcgui.WindowXML):
    """Amazon Prime Video-inspired home screen."""

    def __init__(self, *args, **kwargs):
        self._film_rows = [[], [], []]
        self._hero_index = 0
        self._hero_films = []
        self._trailer_timer = None
        self._trailer_playing = False
        self._plugin_url = kwargs.pop('plugin_url', '')
        super(HomeWindow, self).__init__(*args, **kwargs)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def onInit(self):
        self._set_row_labels()
        self._load_data_async()

    def onAction(self, action):
        action_id = action.getId()
        # Back / Escape → close
        if action_id in (xbmcgui.ACTION_PREVIOUS_MENU,
                          xbmcgui.ACTION_NAV_BACK,
                          xbmcgui.ACTION_STOP):
            self._stop_trailer()
            self.close()

    def onClick(self, control_id):
        if control_id == _ID_HERO_PLAY:
            self._play_hero()
        elif control_id == _ID_HERO_INFO:
            self._open_info()
        elif control_id == _ID_HERO_ADD:
            xbmc.executebuiltin('Notification(Starfleet,Added to watchlist,3000)')
        elif control_id in (_ID_NAV_MOVIES, _ID_NAV_ADULT):
            self._stop_trailer()
            self.close()
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=adult_movies_library)')
        elif control_id == _ID_NAV_TV:
            self._stop_trailer()
            self.close()
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=main_menu_tv)')
        elif control_id == _ID_NAV_SPORTS:
            self._stop_trailer()
            self.close()
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=main_menu_sports)')
        elif control_id == _ID_NAV_LIVE:
            self._stop_trailer()
            self.close()
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=main_menu_live)')
        elif control_id == _ID_NAV_SEARCH:
            self._stop_trailer()
            self.close()
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=search)')
        elif control_id in (_ID_ROW0, _ID_ROW1, _ID_ROW2):
            row_idx = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2}[control_id]
            self._play_from_row(row_idx)

    def onFocus(self, control_id):
        if control_id in (_ID_ROW0, _ID_ROW1, _ID_ROW2):
            row_idx = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2}[control_id]
            self._update_hero_from_row(row_idx)

    # ------------------------------------------------------------------
    # Data loading
    # ------------------------------------------------------------------
    def _set_row_labels(self):
        for i, label in enumerate(_ROW_LABELS):
            self.setProperty('sf_row%d_label' % i, label)

    def _load_data_async(self):
        threading.Thread(target=self._load_data, daemon=True).start()

    def _load_data(self):
        try:
            from resources.lib import afdb_router as _ar
            rows = _ar.get_home_carousel_data()
        except Exception:
            rows = [[], [], []]

        self._film_rows = rows
        # Small delay to let the window finish initialising before populating
        xbmc.sleep(300)
        self._populate_carousels()

    def _populate_carousels(self):
        list_ids = [_ID_ROW0, _ID_ROW1, _ID_ROW2]
        for row_idx, list_id in enumerate(list_ids):
            try:
                ctrl = self.getControl(list_id)
                ctrl.reset()
                films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
                for film in films:
                    li = xbmcgui.ListItem(label=film.get('title', ''))
                    li.setArt({'thumb': film.get('thumb', ''), 'fanart': film.get('fanart', '')})
                    li.setProperty('film_id', str(film.get('id', '')))
                    li.setProperty('film_url', film.get('url', ''))
                    li.setProperty('film_source', film.get('source', ''))
                    li.setProperty('film_slug', film.get('slug', ''))
                    ctrl.addItem(li)
            except Exception:
                pass

        # Set hero from first row
        if self._film_rows and self._film_rows[0]:
            self._set_hero(self._film_rows[0][0], 0)
            self._schedule_trailer()

    def _set_hero(self, film, row_idx):
        self._hero_films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
        self._hero_index = 0
        title = film.get('title', '')
        year = film.get('year', '')
        rating = film.get('rating', '')
        runtime = film.get('runtime', '')
        meta_parts = [p for p in [year, rating, runtime] if p]
        self.setProperty('sf_hero_title', title)
        self.setProperty('sf_hero_meta', '  ·  '.join(meta_parts))
        self.setProperty('sf_hero_plot', film.get('plot', film.get('description', '')))
        self.setProperty('sf_hero_fanart', film.get('fanart', film.get('thumb', '')))
        self.setProperty('sf_hero_badge', film.get('source', '').upper() or 'STARFLEET')

    def _update_hero_from_row(self, row_idx):
        try:
            ctrl = self.getControl({0: _ID_ROW0, 1: _ID_ROW1, 2: _ID_ROW2}[row_idx])
            pos = ctrl.getSelectedPosition()
            films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
            if films and 0 <= pos < len(films):
                self._stop_trailer()
                self._set_hero(films[pos], row_idx)
                self._schedule_trailer()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Trailer
    # ------------------------------------------------------------------
    def _schedule_trailer(self):
        self._stop_trailer()
        self._trailer_timer = threading.Timer(_TRAILER_DELAY, self._start_trailer)
        self._trailer_timer.daemon = True
        self._trailer_timer.start()

    def _start_trailer(self):
        try:
            films = self._hero_films
            if not films:
                return
            film = films[self._hero_index]
            trailer = film.get('trailer', '')
            if trailer:
                self._trailer_playing = True
                self.setProperty('sf_trailer_playing', 'true')
                xbmc.Player().play(trailer, windowed=True)
        except Exception:
            pass

    def _stop_trailer(self):
        if self._trailer_timer:
            self._trailer_timer.cancel()
            self._trailer_timer = None
        if self._trailer_playing:
            try:
                xbmc.Player().stop()
            except Exception:
                pass
            self._trailer_playing = False
            self.setProperty('sf_trailer_playing', '')

    # ------------------------------------------------------------------
    # Playback / navigation
    # ------------------------------------------------------------------
    def _play_hero(self):
        films = self._hero_films
        if not films:
            return
        film = films[self._hero_index]
        self._stop_trailer()
        self.close()
        self._play_film(film)

    def _play_from_row(self, row_idx):
        try:
            ctrl = self.getControl({0: _ID_ROW0, 1: _ID_ROW1, 2: _ID_ROW2}[row_idx])
            pos = ctrl.getSelectedPosition()
            films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
            if films and 0 <= pos < len(films):
                self._stop_trailer()
                self.close()
                self._play_film(films[pos])
        except Exception:
            pass

    def _play_film(self, film):
        source = film.get('source', 'afdb')
        slug = film.get('slug', '')
        film_id = str(film.get('id', ''))
        url = film.get('url', '')
        title = film.get('title', '')
        if source == 'pandamovies':
            cmd = 'RunPlugin(plugin://plugin.video.starfleet/?action=adult_panda_play&slug=%s&film_url=%s&title=%s)' % (slug, url, title)
        elif source == 'hqporner':
            cmd = 'RunPlugin(plugin://plugin.video.starfleet/?action=adult_hqp_play&slug=%s&film_url=%s&title=%s)' % (slug, url, title)
        elif source in ('freeomovie', 'xxxmoviestream', 'pornwatch', 'watchpornfree', 'speedporn', 'xxxscenes', 'xmovix'):
            cmd = 'RunPlugin(plugin://plugin.video.starfleet/?action=adult_stream_sources&film_id=%s&film_url=%s&title=%s)' % (film_id, url, title)
        else:
            cmd = 'RunPlugin(plugin://plugin.video.starfleet/?action=afdb_play_search&film_id=%s&film_slug=%s&film_title=%s)' % (film_id, slug, title)
        xbmc.executebuiltin(cmd)

    def _open_info(self):
        films = self._hero_films
        if not films:
            return
        film = films[self._hero_index]
        xbmcgui.Dialog().textviewer(film.get('title', ''), film.get('plot', film.get('description', 'No information available.')))
