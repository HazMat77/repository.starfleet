# -*- coding: utf-8 -*-
"""
resources/lib/setup.py

First-run dependency checker. Installs ResolveURL via Kodi's addon manager
(works because repository.starfleet includes Gujal00 smrzips as a source).
"""

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon('plugin.video.starfleet')


def _addon_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except RuntimeError:
        return False


def check_and_guide():
    """
    Check for ResolveURL on every startup.
    If missing, offer to install it — repository.starfleet includes the
    Gujal00 smrzips source so Kodi can find it without any extra repo.
    """
    if _addon_installed('script.module.resolveurl'):
        return

    xbmc.log('[Starfleet/Setup] ResolveURL not found — prompting install', xbmc.LOGINFO)

    answer = xbmcgui.Dialog().yesno(
        'Starfleet — Install ResolveURL?',
        'ResolveURL is not installed.\n\n'
        'It resolves stream links for Adult streams and other hosters '
        '(StreamTape, DoodStream, MyVidPlay, etc.).\n\n'
        'Install now?'
    )

    if not answer:
        return

    xbmc.executebuiltin('InstallAddon(script.module.resolveurl)', True)
    xbmc.sleep(1000)

    if _addon_installed('script.module.resolveurl'):
        xbmcgui.Dialog().notification(
            'Starfleet Setup',
            'ResolveURL installed successfully!',
            xbmcgui.NOTIFICATION_INFO, 4000
        )
        xbmc.log('[Starfleet/Setup] ResolveURL installed OK', xbmc.LOGINFO)
    else:
        xbmcgui.Dialog().ok(
            'Starfleet Setup',
            'ResolveURL could not be installed automatically.\n\n'
            'Install manually:\n'
            '1. Go to github.com/Gujal00/ResolveURL\n'
            '2. Download the latest script.module.resolveurl zip\n'
            '3. Add-ons → Install from zip'
        )
