"""
Starfleet Home GUI launcher.
Opens the home window immediately with cached data, then refreshes in the background.
"""
import sys
import os
import json
import threading
import xbmc
import xbmcvfs
import xbmcaddon


def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)

    data_dir  = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(data_dir, exist_ok=True)
    data_file = os.path.join(data_dir, 'home_data.json')

    empty    = [[], [], []]
    contexts = {'default': empty, 'movies': empty, 'tv': empty,
                'sports': empty, 'live': empty, 'adult': empty}

    # Load whatever is cached — instant, never blocks
    try:
        with open(data_file, 'r', encoding='utf-8') as f:
            raw = json.load(f)
        if isinstance(raw, list):
            contexts['default'] = raw
            contexts['movies']  = raw
            contexts['tv']      = raw
        else:
            contexts = raw
        d = contexts.get('default', empty)
        xbmc.log('[Starfleet/Home] loaded %d/%d/%d films from cache' % (
            len(d[0]), len(d[1]), len(d[2])), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/Home] no cache yet (%s), showing empty home' % e, xbmc.LOGINFO)

    # Open the window immediately — user sees it under a second
    try:
        from resources.lib.gui.home import HomeWindow
        win = HomeWindow('Starfleet-Home.xml', addon_path, 'Default', '1080i',
                         contexts=contexts)

        # Background refresh — writes new data for next launch; hides spinner when done
        def _refresh():
            try:
                from resources.lib import afdb_router as _ar
                _ctx = _ar.get_home_carousel_data()
                _tmp = data_file + '.tmp'
                with open(_tmp, 'w', encoding='utf-8') as _f:
                    json.dump(_ctx, _f)
                os.replace(_tmp, data_file)
                _d = _ctx.get('default', empty)
                xbmc.log('[Starfleet/Home] background refresh done: %d/%d/%d' % (
                    len(_d[0]), len(_d[1]), len(_d[2])), xbmc.LOGINFO)
            except Exception as _e:
                xbmc.log('[Starfleet/Home] background refresh error: %s' % _e, xbmc.LOGWARNING)
            finally:
                # Hide the plugin spinner regardless of success/failure
                try:
                    win.setProperty('sf_loaded', '1')
                except Exception:
                    pass

        t = threading.Thread(target=_refresh, daemon=True)
        t.start()

        win.doModal()
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        del win
    except Exception as e:
        xbmc.log('[Starfleet/Home] window error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
