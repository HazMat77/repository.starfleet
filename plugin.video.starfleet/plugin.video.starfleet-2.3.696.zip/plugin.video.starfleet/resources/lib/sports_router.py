﻿# -*- coding: utf-8 -*-
"""
resources/lib/sports_router.py

Kodi UI for the Sports section.

Menu:
  Sports → [NFL, NBA, MLB, NHL, UFC, Boxing, Soccer, F1, CFB, NCAAB, CFL, WWE]
         → Today's Games  (event list for the selected sport)
         → click game → dialog: Link 1, Link 2, ... → play
"""

import re
import time as _time
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmcplugin
_XP = xbmcplugin          # the real module; _play_stream may be handed a stand-in for one Just Play attempt
from resources.lib.gui import progress_dialog as _pdlg
from resources.lib.gui.select_dialog import select as _select_dialog

_NFL_NETWORK_ICON = 'https://thumb.wikimedia.org/wikipedia/en/thumb/8/8f/NFL_Network_logo.svg/250px-NFL_Network_logo.svg.png'
# Name-based lookup (same as NHL Network's own _NHL_NETWORK_PATH below) —
# not in daddylive.li's OWN daily event schedule as a persistent listing
# (confirmed live 2026-09-13: it only shows up there as a one-off timed
# program, "NFL Network" at 17:30, not a standing 24/7 entry), but the
# dlstreams.st/dlive.sx channel DIRECTORY (a separate, persistent catalog
# from the daily schedule) is where NHL/MLB Network's own entries actually
# live, so this follows that exact same, already-working pattern.
_NFL_NETWORK_PATH = 'dlchan:NFL-Network'

_NFL_REDZONE_ICON = 'https://thumb.wikimedia.org/wikipedia/en/thumb/7/7b/NFL_Network_Redzone.png/250px-NFL_Network_Redzone.png'
# Two known-good dlive.sx channel ids, confirmed live 2026-09-13 straight
# from daddylive.li's own current schedule ("NFL : Redzone" event's own
# Link-1/Link-2 channels) and confirmed resolving end-to-end through this
# same dlchan_multi: -> resolve_dlstreams_channel() -> live_sources.py's
# resolve_dlstreams_channel -> sports_sources._livetv902_resolve_dlstreams
# chain already used for MLB/NHL Network above — a real signed .m3u8 came
# back for both ids. A third candidate id (3007, from tvnow247.top's own
# schedule) was tried too but its own deep-link chain uses a different,
# non-atob mirror tier this addon doesn't decode yet, so it's left out
# rather than shipped unverified.
_NFL_REDZONE_PATH = 'dlchan_multi:667|449'


def _fmt_local_time(start_ts):
    """UTC unix timestamp -> 'Today 8:00 PM' in the device's own time zone (Kodi runs Python in the OS zone)."""
    if not start_ts:
        return ''
    try:
        import datetime as _dt
        local = _time.localtime(int(start_ts))
        t_str = _time.strftime('%I:%M %p', local).lstrip('0') or _time.strftime('%I:%M %p', local)
        days = (_dt.date.fromtimestamp(int(start_ts)) - _dt.date.today()).days
        if days == 0:
            day = 'Today'
        elif days == 1:
            day = 'Tomorrow'
        elif days == -1:
            day = 'Yesterday'
        else:
            # Cross-platform: avoid %-d (Linux) / %#d (Windows) - just use tm_mday
            day = '%s %s %d' % (_time.strftime('%a', local), _time.strftime('%b', local), local.tm_mday)
        return '%s %s' % (day, t_str)
    except Exception:
        return ''


_CHANNEL_WORDS = re.compile(r'network|channel|24/7|redzone', re.I)
_VS = re.compile(r'\s(?:vs\.?|v|@|at)\s|\s-\s', re.I)


def _is_247(ev):
    """A standing TV channel (NHL Network, Tennis Channel...) rather than a timed game."""
    title = ev.get('title') or ''
    if _VS.search(title):
        return False
    path = ev.get('path') or ''
    return path.startswith(('dlchan:', 'livesite:')) and (not ev.get('start_ts') or bool(_CHANNEL_WORDS.search(title)))


def event_when(ev):
    """(text, colour) for an event: the live clock, FINAL, the local start time, LIVE 24/7 or TBD."""
    if ev.get('game_state') == 'post':
        return 'FINAL', 'gray'
    if ev.get('is_live'):
        d = ev.get('score_detail') or ''
        return ('LIVE  %s' % d if d else 'LIVE'), 'red'
    if _is_247(ev):
        return 'LIVE 24/7', 'red'
    t = _fmt_local_time(ev.get('start_ts', 0))
    return (t, 'yellow') if t else ('TBD', 'gray')


def event_row_label(ev):
    """One list row: the local time (or live clock) in front of the teams, or of the live score when there is one."""
    when, colour = event_when(ev)
    return '[COLOR %s]%s[/COLOR]  %s' % (colour, when, ev.get('score_line') or ev.get('title', ''))


def prepare_events(sport_slug, events):
    """Attach live scores, then drop games that are over (or started more than 12 hours ago and are not on any more)."""
    try:
        from resources.lib import sports_sources as _ss
        events = getattr(_ss, 'with_live_scores', lambda s, e: e)(sport_slug, events)
    except Exception:
        pass
    now = _time.time()
    # one-match sports are over a few hours after the start; tournaments, Tests and golf rounds run longer
    window = (5 if sport_slug in ('soccer', 'nba', 'nhl', 'mlb', 'nfl', 'cfb', 'ncaab', 'cfl') else 12) * 3600
    keep = []
    for ev in events:
        if ev.get('game_state') == 'post':
            continue
        ts = ev.get('start_ts') or 0
        if ts and ts < now - window and not ev.get('is_live') and not _is_247(ev):
            continue
        keep.append(ev)
    return keep


ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')


def _progress(msg):
    d = _pdlg.DialogProgress()
    d.create('Starfleet Sports', msg)
    d.update(5)
    return d


# Same quality-tier ranking metadata_router._sort_by_quality()/afdb_router.
# _sort_by_quality() already use for Movies/TV and Adult — kept as its own
# local copy here too (small, self-contained). Per direct request
# 2026-09-07. Sports streams usually carry their quality (when known) in a
# separate `quality` dict field rather than baked into the label text the
# way a torrent release name is, so this checks both — unlike the other
# two copies, most sports sources never populate either, so this quietly
# no-ops (stable sort, original relative order kept) for those, only
# actually reordering when at least one candidate's quality is known.
_QUALITY_RE = re.compile(
    r'\b(2160p|4k|1080p|720p|480p|360p|blu-ray|bluray|web-dl|webdl|webrip|hdtv|3d|hdcam|hdts|dvdscr|cam)\b',
    re.IGNORECASE
)
_QUALITY_RANK = {
    '2160p': 7, '4k': 7,
    '1080p': 6,
    '720p':  5,
    'blu-ray': 4, 'bluray': 4, 'web-dl': 4, 'webdl': 4, 'webrip': 4, 'hdtv': 4, '3d': 4,
    '480p': 3,
    '360p': 2,
    'hdcam': 1, 'hdts': 1, 'dvdscr': 1, 'cam': 1,
}


# Added 2026-09-13, per an extended real debugging session where the same
# genuinely-working source (nfl24all.ir, labeled "NFL24ALL") kept getting
# passed over in favor of whatever the picker happened to default-highlight
# — repeatedly confirmed via real kodi.log traces that users picking the
# first/highlighted option (a natural thing to do) kept landing on a
# source that reliably 403s/404s (mut.st, labeled "mut"), never the one
# that actually had a real stream. _sort_by_quality already reorders by
# quality tier when known; this adds a small secondary tiebreak so ties
# (the overwhelming common case for live sports — most sources here never
# populate a quality field at all) don't just fall back to arbitrary
# source-merge-order, which is what was burying the reliable option.
# Deliberately narrow and evidence-based rather than a blanket
# "prefer official-sounding sources" heuristic: NFL24ALL's own boost
# reflects it succeeding at the discovery step every single time it had
# data available across this whole session; mut's own penalty reflects
# 100% observed playback failure (403) across every real attempt traced,
# not a guess about the site's general reputation.
_SOURCE_PRIORITY = {
    # falconresolved ranks above the live-resolved sources deliberately —
    # it's pre-verified by an actual real headless browser on the scraper
    # PC (scraper_falconstreams_nfl.py), not just "found a URL that looked
    # right" the way every live in-addon resolver here can only ever do.
    'falconresolved': 3,
    'nfl24all': 2, 'nhl24all': 2, 'mlb24all': 2, 'nba24all': 2,
    # LiveSites links are only returned after their playlist answered 200
    # (dead/geo-blocked channels are dropped in sports_starfleet_live.resolve_link).
    'livesites-sportzone': 2, 'livesites-topsurge': 2,
    'livesites-flyembed': 2, 'livesites-sportsonline': 2,
    'mut': -2,
}


def _sort_by_quality(sources):
    def _rank(s):
        text = '%s %s' % (s.get('quality', ''), s.get('label', ''))
        m = _QUALITY_RE.search(text)
        quality_rank = _QUALITY_RANK.get(m.group(1).lower(), 0) if m else 0
        src_key = (s.get('source', '') or '').lower()
        priority = _SOURCE_PRIORITY.get(src_key, 0)
        return (quality_rank, priority)
    return sorted(sources, key=_rank, reverse=True)


# ── Sport categories ──────────────────────────────────────────────────────────

def sports_menu(handle, build_url):
    """Top-level sports menu: show each sport category as a folder."""
    from resources.lib import json_data as _jd

    xbmcplugin.setPluginCategory(handle, 'Sports')
    xbmcplugin.setContent(handle, 'files')

    # Hockey hub — all leagues from onhockey.tv
    hockey_li = xbmcgui.ListItem(label='🏒  Hockey')
    hockey_li.setArt({'thumb': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png',
                      'icon':  'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'})
    hockey_li.setInfo('video', {'title': '🏒  Hockey'})
    xbmcplugin.addDirectoryItem(handle, build_url({'action': 'hockey_menu'}), hockey_li, True)

    cats = _jd.get_all_categories()

    for cat in cats:
        li = xbmcgui.ListItem(label=cat['label'])
        li.setArt({'thumb': cat['icon'], 'icon': cat['icon']})
        li.setInfo('video', {'title': cat['label']})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':      'sports_events',
                       'sport_slug':  cat['slug'],
                       'sport_label': cat['label'],
                       'sport_icon':  cat['icon'],
                       'tsdb_sport':  cat.get('tsdb_sport', '')}),
            li, True
        )

    # Replay (past games / fights) lives under Sports, not in the top bar
    replay_li = xbmcgui.ListItem(label='🔁  Replay (Past Events)')
    replay_li.setInfo('video', {'title': '🔁  Replay (Past Events)'})
    xbmcplugin.addDirectoryItem(handle, build_url({'action': 'replay_menu'}), replay_li, True)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Events list for a sport ───────────────────────────────────────────────────

def sports_events(handle, build_url, sport_slug, sport_label='', sport_icon='', tsdb_sport=''):
    """List today's and upcoming events for a sport category."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '%s' % (sport_label or sport_slug.upper()))
    xbmcplugin.setContent(handle, 'files')

    if sport_slug == 'nfl':
        nfl_net_li = xbmcgui.ListItem(label='📺  NFL Network  [COLOR red]LIVE 24/7[/COLOR]')
        nfl_net_li.setArt({'thumb': _NFL_NETWORK_ICON, 'icon': _NFL_NETWORK_ICON})
        nfl_net_li.setInfo('video', {'title': 'NFL Network', 'plot': '24/7 NFL Network live TV channel.'})
        nfl_net_li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'sports_event_play',
                       'event_id':   'nfl_network_live',
                       'event_path': _NFL_NETWORK_PATH,
                       'sport_slug': 'nfl',
                       'title':      'NFL Network'}),
            nfl_net_li, False
        )

        nfl_rz_li = xbmcgui.ListItem(label='📺  NFL RedZone  [COLOR red]LIVE 24/7[/COLOR]')
        nfl_rz_li.setArt({'thumb': _NFL_REDZONE_ICON, 'icon': _NFL_REDZONE_ICON})
        nfl_rz_li.setInfo('video', {'title': 'NFL RedZone', 'plot': 'Live look-ins on every game, every Sunday afternoon during the NFL season.'})
        nfl_rz_li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'sports_event_play',
                       'event_id':   'nfl_redzone_live',
                       'event_path': _NFL_REDZONE_PATH,
                       'sport_slug': 'nfl',
                       'title':      'NFL RedZone'}),
            nfl_rz_li, False
        )

    if sport_slug == 'mlb':
        mlb_net_li = xbmcgui.ListItem(label='📺  MLB Network  [COLOR red]LIVE 24/7[/COLOR]')
        mlb_net_li.setArt({'thumb': _MLB_NETWORK_ICON, 'icon': _MLB_NETWORK_ICON})
        mlb_net_li.setInfo('video', {'title': 'MLB Network', 'plot': '24/7 MLB Network live TV channel.'})
        mlb_net_li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'sports_event_play',
                       'event_id':   'mlb_network_live',
                       'event_path': _MLB_NETWORK_PATH,
                       'sport_slug': 'mlb',
                       'title':      'MLB Network'}),
            mlb_net_li, False
        )

    cold = _cache.get('sport_ev4_%s' % sport_slug) is None
    dlg  = _progress('Loading %s events...' % (sport_label or sport_slug.upper())) if cold else None
    events = _ss.get_sport_events(sport_slug, tsdb_sport=tsdb_sport)
    if dlg:
        dlg.close()

    if not events:
        xbmcgui.Dialog().notification(
            'Starfleet Sports',
            'No events found for %s' % sport_slug.upper(),
            xbmcgui.NOTIFICATION_INFO
        )
        return

    events = prepare_events(sport_slug, events)
    xbmc.log('[Starfleet/Sports] rendering %d %s events, first start_ts=%s' % (
        len(events), sport_slug, events[0].get('start_ts', 'MISSING') if events else 'N/A'), xbmc.LOGINFO)
    for ev in events:
        local_time = _fmt_local_time(ev.get('start_ts', 0))
        label = event_row_label(ev)

        league = ev.get('league', '')
        plot_parts = []
        if league and league.upper() != sport_slug.upper():
            plot_parts.append(league)
        if local_time and not ev.get('is_live'):
            plot_parts.append(local_time)
        if ev.get('is_live'):
            score_str = ev.get('score_line') or ev.get('plot', '')
            if ev.get('score_detail'):
                plot_parts.append('🔴 %s' % ev['score_detail'])
            if score_str:
                plot_parts.append('🔴 ' + score_str)
            elif not ev.get('score_detail'):
                plot_parts.append('🔴 LIVE NOW')
        if ev.get('venue'):
            plot_parts.append('📍 ' + ev['venue'])
        plot = ' • '.join(plot_parts)

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': ev['title'],
            'plot':  plot,
        })

        # Home team badge → thumb/icon; away badge → fanart (shown as background)
        home_badge = ev.get('home_badge', '') or ev.get('logo', '') or sport_icon
        away_badge = ev.get('away_badge', '') or home_badge
        li.setArt({'thumb': home_badge, 'icon': home_badge, 'fanart': away_badge})

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':      'sports_event_play',
                       'event_id':    ev['id'],
                       'event_path':  ev['path'],
                       'sport_slug':  sport_slug,
                       'title':       ev['title'],
                       'start':       str(int(ev.get('start_ts') or 0))}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Play an event — show stream picker dialog ─────────────────────────────────

def sports_event_play(handle, event_id='', event_path='', sport_slug='', title='', start='', auto=None, skip=0):
    """
    Fetch available stream links for the event and show a dialog picker.
    Merges ISE streams (event_path) + Roxiestreams (sport_slug).
    Just Play (Settings, or auto=True): no picker - the stream sources are ranked by how well each has played here, the best one
    plays, and when it does not play the next one is started (skip = how many already failed; the ranked list is cached for
    20 minutes so a retry does not search again).
    """
    from resources.lib import sports_sources as _ss
    from resources.lib import playback_assist as _assist
    if auto is None:
        try:
            auto = xbmcaddon.Addon('plugin.video.starfleet').getSetting('just_play') == 'true'
        except Exception:
            auto = False
    try:
        skip = int(skip or 0)
    except (TypeError, ValueError):
        skip = 0
    _key = _assist.title_key('sport', event_id, '', 0, 0, '%s:%s' % (sport_slug, title))
    if not skip:
        _assist.new_request()          # the viewer's own play: a stale "try the next stream" of an earlier one stands down

    try:
        start_ts = int(start or 0)
    except ValueError:
        start_ts = 0
    streams = _assist.load_candidates(_key) if (auto and skip) else None
    if streams is None:
        dlg = _progress('Fetching stream links...')
        streams = _ss.get_event_streams(event_path, event_id, sport_slug, title, start_ts)
        dlg.close()
        if auto and streams:
            streams = _assist.rank(_sort_by_quality(streams))
            _assist.save_candidates(_key, streams)

    if not streams:
        xbmcgui.Dialog().ok(
            'Starfleet Sports — %s' % title,
            'No stream links available yet.\n\n'
            'This event may not have started, or stream links will appear '
            'a few minutes before/after kick-off.\n\n'
            'Try again when the event is live.'
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if auto:
        from urllib.parse import quote

        class _Shim(object):
            def __init__(self):
                self.ok = None

            def setResolvedUrl(self, h, ok, item):
                self.ok = bool(ok)
                if ok:
                    xbmcplugin.setResolvedUrl(h, ok, item)

            def __getattr__(self, name):
                return getattr(xbmcplugin, name)

        def _retry(n):
            try:
                xbmcgui.Dialog().notification('Starfleet Sports', 'That stream did not play - trying the next one',
                                              xbmcgui.NOTIFICATION_INFO, 3000)
            except Exception:
                pass
            url = ('plugin://plugin.video.starfleet/?action=sports_event_play&event_id=%s&event_path=%s&sport_slug=%s&title=%s'
                   '&start=%s&auto=1&skip=%d' % (quote(str(event_id)), quote(str(event_path)), sport_slug, quote(title),
                                                  start_ts, n))
            li = xbmcgui.ListItem(title)
            li.setProperty('IsPlayable', 'true')
            xbmc.Player().play(url, li)

        tried = 0
        idx = skip
        while idx < len(streams) and tried < _assist.MAX_ATTEMPTS:
            s = streams[idx]
            key = _assist.source_key(s)
            xbmc.log('[Starfleet/JustPlay] sports stream %d of %d (%s)' % (idx + 1, len(streams), key), xbmc.LOGINFO)
            shim = _Shim()
            try:
                _play_stream(handle, s['url'], title, shim=shim)
            except Exception as e:
                xbmc.log('[Starfleet/JustPlay] stream raised: %s' % e, xbmc.LOGWARNING)
                shim.ok = False
            if shim.ok:
                nxt = idx + 1
                _assist.watch_playback(key, (lambda n=nxt: _retry(n)) if nxt < len(streams) else (lambda: None))
                return
            idx += 1
            tried += 1
        xbmcgui.Dialog().notification('Starfleet Sports', 'None of the streams would play', xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    streams = _sort_by_quality(streams)

    # Build dialog options — show source + quality
    def _fmt_option(i, s):
        src  = s.get('source', '')
        lbl  = s.get('label', 'Stream')
        qual = s.get('quality', '')
        parts = ['[%s]' % src] if src else []
        parts.append(lbl)
        if qual and qual not in lbl:
            parts.append('(%s)' % qual)
        return '%d. %s' % (i + 1, ' '.join(parts))

    options = [_fmt_option(i, s) for i, s in enumerate(streams)]

    if len(streams) == 1:
        chosen_url = streams[0]['url']
    else:
        idx = _select_dialog(
            '%s — Choose stream' % title, options
        )
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen_url = streams[idx]['url']

    _play_stream(handle, chosen_url, title)


# ── Replay (past games and fights) as plain folders: sport -> date -> event -> pick a source ─────────────────────────────

_REPLAY_SPORT_ORDER = (('ufc', 'UFC'), ('boxing', 'Boxing'), ('wwe', 'Wrestling'), ('motorsport', 'Motorsport'), ('soccer', 'Soccer'), ('nfl', 'NFL'), ('nba', 'NBA'), ('nhl', 'NHL'), ('mlb', 'MLB'))


def replay_menu(handle, build_url):
    """Replay's first level: one folder per sport that has full-game / full-fight replays."""
    from resources.lib import json_data as _jd
    xbmcplugin.setPluginCategory(handle, 'Replay')
    xbmcplugin.setContent(handle, 'files')
    icons = {}
    try:
        icons = {c.get('slug'): c.get('icon', '') for c in _jd.get_all_categories()}
    except Exception:
        pass
    for slug, label in _REPLAY_SPORT_ORDER:
        li = xbmcgui.ListItem(label=label)
        icon = icons.get(slug, '')
        if icon:
            li.setArt({'thumb': icon, 'icon': icon})
        li.setInfo('video', {'title': label})
        xbmcplugin.addDirectoryItem(handle, build_url({'action': 'replay_dates', 'sport': slug, 'label': label, 'icon': icon}), li, True)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def replay_dates(handle, build_url, sport='', label='', icon=''):
    """Replay's second level: the days that have at least one replay, newest first."""
    from resources.lib import replay_sources as _rs
    xbmcplugin.setPluginCategory(handle, '%s replays' % (label or sport.upper()))
    xbmcplugin.setContent(handle, 'files')
    for d in _rs.get_replay_dates(sport)[:90]:
        li = xbmcgui.ListItem(label=d['label'])
        if icon:
            li.setArt({'thumb': icon, 'icon': icon})
        li.setInfo('video', {'title': d['label']})
        xbmcplugin.addDirectoryItem(handle, build_url({'action': 'replay_events', 'sport': sport, 'label': label, 'icon': icon,
                                                       'date': d['date_key']}), li, True)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def replay_events(handle, build_url, sport='', date='', label='', icon=''):
    """Replay's third level: the games / fight cards of one day. Picking one asks for a source and plays it."""
    from resources.lib import replay_sources as _rs
    xbmcplugin.setPluginCategory(handle, date)
    xbmcplugin.setContent(handle, 'files')
    for ev in _rs.get_replay_events(sport, date):
        title = ev.get('title', '')
        thumb = ev.get('thumb') or ev.get('fighter1_photo') or icon
        li = xbmcgui.ListItem(label=title)
        art = {'thumb': thumb, 'icon': thumb}
        if ev.get('fanart'):
            art['fanart'] = ev['fanart']
        li.setArt(art)
        li.setInfo('video', {'title': title, 'plot': ev.get('date_label', '')})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle, build_url({'action': 'replay_event_play', 'sport': sport, 'date': date,
                                                       'event_id': ev.get('id', ''), 'title': title}), li, False)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def replay_event_play(handle, sport='', date='', event_id='', title=''):
    """Finds every source of one replay event, lets the viewer pick one when there are several, and plays it."""
    from resources.lib import replay_sources as _rs
    ev = next((e for e in _rs.get_replay_events(sport, date) if e.get('id') == event_id), None)
    if not ev:
        xbmcgui.Dialog().notification('Starfleet', 'That replay is not listed any more', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    dlg = _progress('Finding sources for %s...' % (title or ev.get('title', '')))
    try:
        sources = _rs.get_replay_sources(sport, ev)
    finally:
        dlg.close()
    if not sources:
        xbmcgui.Dialog().notification('Starfleet', 'No playable sources found for %s' % (title or ev.get('title', '')),
                                      xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    if len(sources) == 1:
        chosen = sources[0]
    else:
        idx = _select_dialog('%s - Choose source' % (title or ev.get('title', '')), [x['label'] for x in sources])
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = sources[idx]
    _play_stream(handle, chosen['url'], title or ev.get('title', ''))


def replay_play(handle, url='', title=''):
    """Play a single already-resolved Replay source (resources/lib/
    replay_sources.py's get_replay_sources() already did the picking —
    home.py's custom-skin flow calls this with one chosen url/title,
    same as sports_event_play calls _play_stream after its own picker).
    Reuses _play_stream as-is: Replay's URLs are the same mix (bare .m3u8,
    ok.ru/Dailymotion/Filemoon/YouTube embed pages) this function already
    resolves via ResolveURL -> generic iframe-chain fallback for live
    sports, PLUS magnet: URIs (sport-video.org.ua's torrent-derived
    sources and the generic torrent_sources.search_all() results) which
    _play_stream now resolves via the addon's own debrid resolver instead
    — see that function's own docstring."""
    if not url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    _play_stream(handle, url, title)


_OKRU_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
_RE_OKRU_ID = re.compile(r'(?:videoembed|video|live)/(\d+)')
# Same relative quality ranking ResolveURL's own OKRu plugin uses internally,
# reused here so this picks the same "best available" tier.
_OKRU_QUALITY_ORDER = ('full', 'hd', 'sd', 'low', 'lowest', 'mobile')


def _resolve_okru(url):
    """Own OK.ru resolver, bypassing ResolveURL's OKRu plugin entirely for
    this one host. Confirmed live 2026-08-16 this codebase's own metadata
    POST + direct CDN GET works cleanly end-to-end with a single fixed
    User-Agent — the actual bug wasn't ok.ru's CDN at all (a plain
    requests.get() of the resolved URL returned a real 200/video/mp4
    immediately), it's that ResolveURL's OKRu plugin signs the CDN URL
    against its own internally-generated common.RAND_UA, then hands the
    URL back to be pipe-tagged for playback — if Kodi's own player engine
    doesn't send that EXACT UA string back out again (the same
    pipe-tagged-header reliability gap this file's own _play_stream
    comment already documents for .m3u8/Referer on Firestick), okcdn.ru's
    signature check on the mismatched UA causes CDVDDemuxFFmpeg to hang
    for ~30s and then fail with 'could not open file' — confirmed live
    from a real kodi.log, not guessed. Using ONE fixed UA for both the
    metadata fetch AND the pipe-tagged playback header removes that gap
    entirely instead of trusting ResolveURL's own UA rotation to survive
    Kodi's playback pipeline intact.

    UPDATE 2026-08-16 — still confirmed broken on the user's real Kodi
    21.1 device even with the inputstream.ffmpegdirect curl-mode fix
    active (see _play_stream's own comment). Root-caused one level deeper
    via a live tamper test rather than guessing a 3rd fix: the CDN URL
    this function returns embeds a `srcIp=<ip>` query parameter that
    okcdn.ru ACTIVELY VALIDATES server-side — taking a real, freshly
    resolved, correctly-signed URL and editing ONLY that one param (sig
    untouched) flipped a working 200/video/mp4 response into a 400,
    confirmed live. Everything else about this resolver checks out fine
    in isolation (verified live: correct UA -> 200 real video bytes;
    wrong/missing UA -> 400, exactly as this function's own header-
    matching logic above assumes) — both www.ok.ru and the returned
    vd<N>.okcdn.ru CDN host are IPv4-only (confirmed via DNS lookup, ruling
    out an IPv4/IPv6 dual-stack address-family mismatch specifically), and
    the metadata POST + CDN GET both happen back-to-back inside this same
    function call, same process, same egress path — so this is NOT a
    caching/staleness bug on this addon's own side. The remaining
    explanation is network-level and outside this code's control: if the
    user's device/ISP/VPN assigns a different apparent public IP between
    this function's own Python metadata POST and Kodi's separate
    ffmpegdirect/curl fetch a moment later (common with some VPNs, CGNAT
    pools, or per-connection IP rotation), okcdn.ru will reject the second
    request even though the first one succeeded. Not a 3rd guess-and-fix
    — see replay_sources.py's own "2026-08-16 reliability audit" docstring
    section for how the picker now degrades around this (OK.ru kept, just
    no longer the default-looking first option when a more reliable
    alternate exists for that event).
    Returns the direct CDN URL (already pipe-tagged with the matching
    User-Agent) or None."""
    m = _RE_OKRU_ID.search(url)
    if not m:
        return None
    media_id = m.group(1)
    embed_url = 'https://ok.ru/videoembed/%s' % media_id
    try:
        import requests as _req
        r = _req.post('https://ok.ru/dk?cmd=videoPlayerMetadata',
                      data={'mid': media_id},
                      headers={'User-Agent': _OKRU_UA, 'Referer': embed_url, 'Origin': 'https://ok.ru'},
                      timeout=12)
        r.raise_for_status()
        data = r.json()
        if 'error' in data:
            return None
        vids = data.get('videos') or []
        if not vids:
            return None
        by_quality = {v.get('name'): v.get('url') for v in vids if v.get('url')}
        chosen = None
        try:
            from resources.lib import replay_abr
            _name = replay_abr.okru_progressive_choice(vids, int((data.get('movie') or {}).get('duration') or 0))
            chosen = by_quality.get(_name) if _name else None
        except Exception as _e:
            xbmc.log('[Starfleet/Sports] ok.ru quality pick skipped: %s' % _e, xbmc.LOGINFO)
        if not chosen:
            for q in _OKRU_QUALITY_ORDER:
                if q in by_quality:
                    chosen = by_quality[q]
                    break
        if not chosen:
            chosen = vids[0].get('url')
        if not chosen:
            return None

        # UPDATE 2026-08-18 — real fix found via a direct browser DevTools
        # capture of a genuinely working request to this same CDN: the
        # response carries access-control-allow-origin: https://ok.ru,
        # which only appears when the server is actively validating the
        # Origin header via CORS (this is a cross-origin fetch()/XHR call
        # from the ok.ru embed page's own JS, confirmed by
        # sec-fetch-mode: cors in the real request). Neither this
        # resolver nor ResolveURL's own OKRu plugin has ever sent Referer
        # OR Origin - only User-Agent - which is a real, concrete gap this
        # whole investigation missed until seeing an actual successful
        # request side by side. The response's own Set-Cookie is issued
        # BY this request, not required beforehand, so no cookie/session
        # step is needed first.

        # UPDATE 2026-08-19 — adding Referer/Origin made no difference
        # (confirmed live: identical ~30s hang-then-fail on a real
        # device). A self-test fetch of the exact same URL, from this same
        # device/network, using this addon's own Python requests session,
        # was added here to prove where the gap actually was — and it did:
        # the self-test always succeeded while Kodi's own player kept
        # failing on the identical URL moments later, confirming the gap
        # was specifically in Kodi's playback engine/network stack, not
        # this device's network or IP. That diagnosis is what led straight
        # to the local-relay fix below (route Kodi's player at this same
        # working Python session instead of letting it talk to the CDN
        # directly).
        #
        # UPDATE 2026-09-05 — the self-test outlived its purpose and turned
        # into a real bug of its own: confirmed live (same-session
        # kodi.log) that even with the relay now actually wired in and
        # running, playback still failed — this time hanging ~32s inside
        # CDVDDemuxFFmpeg::Open on the RELAY url itself, right after the
        # self-test had just reported a clean 200/video/mp4 on the direct
        # CDN URL moments earlier. That pattern — one real, successful
        # fetch, then every subsequent fetch of the identical signed URL
        # failing/hanging — is the signature of a single-use signed URL,
        # not a network/IP mismatch: the self-test itself was quietly
        # burning the one real connection this CDN URL is good for, before
        # the relay (or, previously, Kodi's own player) ever got a chance
        # to use it. Removed entirely — it already did its job proving the
        # relay was the right fix; keeping it running afterward only
        # sabotaged the exact thing it helped design.
        from urllib.parse import quote as _uq
        try:
            from resources.lib import local_proxy
            return local_proxy.build_relay_url(chosen, _OKRU_UA)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] local proxy unavailable, falling back to direct CDN URL: %s' % e,
                      xbmc.LOGWARNING)
            return '%s|User-Agent=%s&Referer=%s&Origin=%s' % (
                chosen, _uq(_OKRU_UA, safe=''), _uq(embed_url, safe=''), _uq('https://ok.ru', safe=''))
    except Exception as e:
        xbmc.log('[Starfleet/Sports] _resolve_okru error: %s' % e, xbmc.LOGWARNING)
        return None


_FFMPEGDIRECT_ID = 'inputstream.ffmpegdirect'


def _has_ffmpegdirect():
    """inputstream.ffmpegdirect (unlike inputstream.adaptive) isn't
    provisioned through inputstreamhelper — that module only handles
    inputstream.adaptive's Widevine/DRM setup. ffmpegdirect is a plain
    Kodi addon the user installs/enables like any other, so the correct
    check is simply "is it installed", via xbmcaddon.Addon() raising
    RuntimeError if it's absent — not h.check_inputstream()."""
    try:
        xbmcaddon.Addon(_FFMPEGDIRECT_ID)
        return True
    except Exception:
        return False


def _play_stream(handle, url, title='', shim=None):
    """Resolve the URL via resolveurl/resolvers then set as resolved URL. `shim` (Just Play) stands in for xbmcplugin so the
    result can be read and a failure held back; failures then show a short notice instead of a dialog that waits for OK."""
    quiet = shim is not None
    xbmcplugin = shim if quiet else _XP

    def _problem(heading, msg):
        if quiet:
            xbmcgui.Dialog().notification('Starfleet Sports', msg.split('\n')[0], xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().ok(heading, msg)
    if url.startswith('slap:'):
        from resources.lib import sports_sources as _ss_slap
        fresh = _ss_slap._slap_refresh(url)
        if not fresh:
            xbmcgui.Dialog().notification('Starfleet Sports', 'SlapStreams feed is not on air any more', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        url = fresh
    resolved = url
    referer = ''
    abr_note = ''
    if not url.startswith('magnet:'):
        try:
            from resources.lib import replay_abr
            _abr_url, abr_note = replay_abr.resolve(url)
            if _abr_url:
                resolved = _abr_url
        except Exception as _e:
            xbmc.log('[Starfleet/Sports] adaptive resolve skipped: %s' % _e, xbmc.LOGINFO)

    # magnet: URIs (sport-video.org.ua's torrent-derived sources and the
    # generic torrent_sources.search_all() results, both wired into
    # replay_sources.get_replay_sources() — see that module's docstring)
    # need the addon's own debrid resolver, not ResolveURL — ResolveURL has
    # no concept of a magnet: URI at all and would just hand it straight
    # back unresolved rather than actually play it. Reuses
    # resolvers.resolve_magnet(), the exact same debrid entry point
    # afdb_router.py's adult_stream_play() already uses for XXXClub's own
    # torrent-play path, instead of a second one-off implementation here.
    # Once resolved, `resolved` no longer equals `url`, so every
    # OK.ru/ResolveURL/iframe-chain step below is automatically skipped by
    # its own pre-existing `if resolved == url:` guard — no separate
    # branching needed for the rest of this function, and the same final
    # .m3u8-vs-plain ListItem + setResolvedUrl block at the bottom handles
    # a debrid-resolved URL exactly like every other resolved URL already.
    if url.startswith('magnet:'):
        from resources.lib import resolvers as _resolvers
        try:
            debrid_resolved = _resolvers.resolve_magnet(url)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] resolve_magnet error: %s' % e, xbmc.LOGWARNING)
            debrid_resolved = None
        if debrid_resolved:
            resolved = debrid_resolved
        else:
            xbmc.log('[Starfleet/Sports] magnet could not be resolved via debrid (no debrid '
                     'service configured, or this torrent is not instantly cached): %s'
                     % url[:90], xbmc.LOGWARNING)
            _problem(
                'Starfleet Sports — %s' % title,
                'No playable source found for this torrent.\n\n'
                'This usually means no debrid service (Real-Debrid, AllDebrid, '
                'Premiumize, TorBox) is configured in Settings, or this '
                'particular torrent isn\'t instantly cached there yet.'
            )
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return

    elif '1fichier.com' in url or 'gofile.io' in url:
        # File-locker links (wrestling replays) — ResolveURL can't play these
        # on its own, they need a debrid service (AllDebrid/Premiumize both
        # unlock 1fichier; Premiumize handles gofile). resolvers.resolve()
        # tries the enabled debrid services first and hands back the input
        # URL unchanged when nothing could unlock it.
        from resources.lib import resolvers as _resolvers
        try:
            unlocked = _resolvers.resolve(url)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] debrid resolve error: %s' % e, xbmc.LOGWARNING)
            unlocked = None
        if unlocked and unlocked != url:
            resolved = unlocked
        else:
            msg = ('This link needs a debrid service (AllDebrid / Premiumize) that can '
                        'unlock it, and none returned a playable link.')
            _problem('Starfleet Sports — %s' % title, msg)
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return

    elif ('ok.ru' in url or 'odnoklassniki.ru' in url) and resolved == url:
        # UPDATE 2026-08-18 - back to trying this addon's own resolver
        # FIRST: a real browser DevTools capture of a genuinely working
        # request to this same CDN showed the response carrying
        # access-control-allow-origin: https://ok.ru, meaning the server
        # actively validates the Origin header via CORS - and neither
        # this resolver nor ResolveURL's own OKRu plugin has ever sent
        # Referer or Origin, only User-Agent. _resolve_okru() below now
        # sends both (see its own docstring), which ResolveURL's
        # third-party plugin has no way to do - so this addon's own
        # resolver is now the more complete one and should go first
        # again, with ResolveURL kept only as a fallback if this one
        # can't even get a URL at all.
        okru = _resolve_okru(url)
        if okru:
            resolved = okru
        if resolved == url:
            try:
                from resources.lib import sf_resolve as resolveurl
                hmf = resolveurl.HostedMediaFile(url)
                if hmf.valid_url():
                    r = hmf.resolve()
                    if r:
                        resolved = r
            except ImportError:
                pass
            except Exception as e:
                xbmc.log('[Starfleet/Sports] ResolveURL okru fallback error: %s' % e, xbmc.LOGWARNING)

    _direct_media = bool(re.search(r'\.(?:mp4|mkv|webm)(?:\?|$)', url.split('|', 1)[0], re.I)) \
        or 'brightcovecdn.com/media/' in url

    # Try ResolveURL if available (skipped for ok.ru/magnet — both handled
    # above already — and for direct media files)
    if resolved == url and not _direct_media:
        try:
            from resources.lib import sf_resolve as resolveurl
            hmf = resolveurl.HostedMediaFile(url)
            if hmf.valid_url():
                r = hmf.resolve()
                if r:
                    resolved = r
        except ImportError:
            pass
        except Exception as e:
            xbmc.log('[Starfleet/Sports] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    # Neither ResolveURL nor any host-specific case recognized this URL —
    # several aggregators (confirmed for SportSurge) hand back a plain
    # wrapper page, not a direct stream: e.g. resports.cfd is pure ad
    # markup around a single <iframe>, which itself embeds ANOTHER wrapper
    # page, which finally has the real signed .m3u8 URL inline in its own
    # JS (3 hops, confirmed live). Kodi's demuxer just fails silently
    # trying to probe the wrapper HTML as video ("error probing input
    # format") — this generic iframe-chain follower fixes that instead of
    # only working for the specific embed domains ResolveURL/embed_resolver
    # already recognize by name.
    if resolved == url and not _direct_media:
        try:
            from resources.lib import embed_resolver
            stream, stream_referer = embed_resolver.resolve_generic_iframe_chain(url)
            if stream:
                resolved = stream
                referer = stream_referer or ''
        except Exception as e:
            xbmc.log('[Starfleet/Sports] embed_resolver iframe-chain error: %s' % e, xbmc.LOGWARNING)

    # Provider pages the generic chain cannot open (_econfig players such as wikisport's /court/ links,
    # kora.st, xyzstreams, nexa) - the same decoders the live-site sources use.
    if resolved == url and url.startswith('http') and '.m3u8' not in url.lower() and not _direct_media:
        try:
            from resources.lib import sports_starfleet_live as _sl
            alt = _sl.resolve_link(url)
            if alt:
                resolved = alt
        except Exception as e:
            xbmc.log('[Starfleet/Sports] live-site resolver error: %s' % e, xbmc.LOGWARNING)

    # These signed CDN links 403 with no Referer at all (confirmed live for
    # the SportSurge chain above) — Kodi's player doesn't send one unless
    # it's encoded into the URL, so it's appended here using this
    # codebase's existing url|Referer=... pipe syntax (same convention as
    # the DaddyLive/FalconStreams/Scenes resolvers).
    if referer and resolved.startswith('http'):
        from urllib.parse import quote as _uq
        resolved = '%s|Referer=%s' % (resolved, _uq(referer, safe=''))

    # .m3u8 links need inputstream.adaptive with explicit header properties —
    # the plain pipe-tagged path|Referer=...&User-Agent=... string alone isn't
    # reliably honored on every platform (confirmed live on Firestick: the
    # custom Referer/User-Agent were silently dropped and replaced with the
    # device's own default browser UA, causing the CDN to 403 valid, freshly
    # resolved links). router.py's _hls_item() already does this correctly
    # for Live TV — reuse it here instead of the old raw-path approach.
    #
    # Brightcove's own HLS packaging (NHL.com's condensed games —
    # replay_sources._nhl_resolve_video) reported live 2026-08-16 as "plays
    # audio only, no video". A 2026-08-21 attempt to fix this by routing
    # Brightcove URLs to Kodi's NATIVE player instead of inputstream.
    # adaptive was wrong-direction — confirmed live via kodi.log this made
    # it WORSE, not better: "Opening stream: 0 source: 256" (a single
    # stream) followed immediately by "CDVDMessageQueue(video)::Put
    # MSGQ_NOT_INITIALIZED" — Kodi's bare ffmpeg HLS demuxer, with no
    # adaptive-streaming-aware layer in front of it, latched onto this
    # manifest's very FIRST #EXT-X-MEDIA entry (which happens to be the
    # AUDIO group — it's listed before any #EXT-X-STREAM-INF video variant
    # in Brightcove's own manifest ordering) and never opened a video
    # stream at all. inputstream.adaptive exists specifically to parse and
    # join demuxed audio/video HLS groups correctly instead of naively
    # taking the first entry — reverted back to always going through it
    # for every .m3u8 URL including this one, which is what should have
    # been tried and properly confirmed FIRST rather than assumed already
    # broken from the 2026-08-16 report alone.
    if '.m3u8' in resolved.lower():
        from resources.lib.router import _hls_item
        # Some sports CDNs disguise every .ts segment as a picture (RIFF/WEBP header
        # in front of the real transport stream), which inputstream.adaptive cannot
        # demux (kodi.log: "Cannot get the stream sample reader" -> "Codec id 27
        # require extradata" -> audio only). When the first segment is wrapped the
        # stream is played through the local relay that strips the wrapper; clean
        # streams are left alone. See local_proxy.maybe_wrap_hls.
        try:
            from resources.lib import local_proxy as _lp
            resolved = _lp.maybe_wrap_hls(resolved)
        except Exception as _e:
            xbmc.log('[Starfleet/Sports] segment-unwrap check skipped: %s' % _e, xbmc.LOGINFO)
        li = _hls_item(resolved, title, force_hls=True)
        li.setProperty('IsPlayable', 'true')
        if abr_note:
            try:
                from resources.lib import replay_abr
                replay_abr.chooser_properties(li)
                xbmcgui.Dialog().notification('Starfleet', abr_note, xbmcgui.NOTIFICATION_INFO, 2500, False)
            except Exception:
                pass
        xbmc.log('[Starfleet/Sports] .m3u8 stream, inputstream property: %s'
                 % li.getProperty('inputstream'), xbmc.LOGINFO)
    else:
        li = xbmcgui.ListItem(label=title, path=resolved)
        li.setInfo('video', {'title': title})
        # Plain (non-.m3u8) resolved URLs carrying a pipe-tagged
        # |User-Agent=...|Referer=... header — OK.ru's resolved CDN MP4s
        # via _resolve_okru() above, and the SportSurge iframe-chain's
        # Referer-tagged links a few lines up — hit this branch. A bare
        # xbmcgui.ListItem(path='url|Header=value') is NOT reliably
        # honored here the way the equivalent pipe-tag is for the .m3u8
        # branch above (which routes through router.py's _hls_item() and
        # inputstream.adaptive instead of trusting the raw path string).
        # Confirmed live via a real kodi.log on Windows Kodi 21.1:
        # _resolve_okru() produces a genuinely fetchable, correctly signed
        # CDN URL — independently verified with a plain requests.get()
        # using the identical User-Agent, real 200/video/mp4 — yet
        # CDVDDemuxFFmpeg still failed with "could not open file" after a
        # ~30s hang. Root cause per Kodi's own inputstream.ffmpegdirect
        # issue tracker (github.com/xbmc/inputstream.ffmpegdirect issue
        # #12, "Stream url is not stripped of piped http headers") and the
        # Kodi forum ("User agent not being passed to ffmpeg",
        # forum.kodi.tv/showthread.php?tid=345263): when VideoPlayer opens
        # a plain progressive URL with NO inputstream addon set, it hands
        # the URL straight to ffmpeg's own libavformat/http protocol
        # handler, which doesn't reliably parse Kodi's url|Header=value
        # pipe-tag syntax. Kodi's OWN cURL file layer (CCurlFile) DOES
        # parse that syntax correctly and reliably — that's the same
        # mechanism this addon's other pipe-tagged Referer/User-Agent
        # links (mythav_sources.py, vidhide_bypass.py, afdb_router.py,
        # etc.) rely on successfully, because those are all .m3u8 and go
        # through _hls_item()/inputstream.adaptive, which likewise forces
        # a component other than ffmpeg's raw http handler to do the
        # fetching. inputstream.ffmpegdirect's documented
        # `open_mode=curl` property (github.com/xbmc/inputstream.
        # ffmpegdirect README) exists specifically to force that same
        # reliable cURL path for non-adaptive (progressive/TS) streams,
        # while ffmpeg still does the demuxing once bytes are flowing —
        # this is the standard fix IPTV/catch-up-TV Kodi addons use for
        # "custom header on a plain HTTP video". Note ffmpegdirect has NO
        # stream_headers/manifest_headers property (unlike
        # inputstream.adaptive) — the header is still carried on the same
        # pipe-tagged path string, just handed to a component that
        # actually honors it. Falls back to the pre-existing bare-path
        # behavior (no worse than before) when the addon isn't installed,
        # or when there's no pipe-tag at all (nothing for this to fix).
        #
        # Scoping double-checked 2026-08-16 against a real concern: does
        # this fire on a resolveurl-resolved YouTube URL (Replay's box.live
        # Boxing source) and interfere with playback that worked before
        # this branch existed? Confirmed NO via ResolveURL 5.1.206's own
        # published youtube.py source — its get_media_url() never appends
        # Kodi's pipe-delimited header syntax to a resolved googlevideo.com
        # URL (that's a bespoke YouTube-cipher extraction path, not the
        # generic get_media_url()/append_headers() helper most other
        # plugins share), so `resolved` for a successful YouTube resolve
        # never contains '|' and this branch structurally can't fire for
        # it. Only OK.ru (_resolve_okru above, which explicitly builds a
        # pipe-tagged string) and the SportSurge iframe-chain's own
        # Referer-append a few lines up ever produce a pipe here — already
        # correctly scoped, no narrowing needed.
        if '|' in resolved and _has_ffmpegdirect():
            mime = 'video/mp2t' if '.ts' in resolved.split('|', 1)[0].lower() else 'video/mp4'
            li.setProperty('inputstream', _FFMPEGDIRECT_ID)
            li.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
            li.setMimeType(mime)
            li.setContentLookup(False)
        li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle, True, li)


# ── Hockey hub (onhockey.tv — all leagues) ────────────────────────────────────

_HOCKEY_ICON = 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'

# All leagues onhockey.tv covers — always shown even with 0 current games
_HOCKEY_ALL_LEAGUES = [
    'NHL', 'AHL', 'KHL', 'OHL', 'WHL', 'QMJHL', 'ECHL',
    'SHL', 'DEL', 'Liiga', 'Czech', 'Slovak', 'EIHL',
    'NCAA', 'IIHF', 'PWHL', 'NWHL', 'PHF',
    'AIHL', 'NZIHL',
]


_NHL_NETWORK_ICON = 'https://upload.wikimedia.org/wikipedia/en/thumb/1/1f/NHL_Network_logo.svg/200px-NHL_Network_logo.svg.png'
# Resolved directly via daddylive.mov (onhockey.tv's own DaddyLive proxy/channel=663
# path stopped working — the site now redirects through daddylive.mov's channel
# pages instead). See sports_sources._dlchan_streams / _dlchan_stream_url.
# 'dlchan:' (not 'daddylive:') — that prefix is already used by the separate,
# pre-existing daddylive.eu multi-sport event scraper in sports_sources.py.
_NHL_NETWORK_PATH = 'dlchan:NHL-Network'

_MLB_NETWORK_ICON = 'https://upload.wikimedia.org/wikipedia/en/thumb/a/a6/MLB_Network_logo.svg/200px-MLB_Network_logo.svg.png'
# MLB Network has three known-good daddylive.mov channel-id variants
# (captured directly from the site — each is a distinct mirror, not a
# fallback chain). Resolved in parallel and offered as Link 1/2/3 in the
# stream picker rather than picking one silently, since any one mirror
# can go down independently of the others.
_MLB_NETWORK_PATH = 'dlchan_multi:MLB-Network|MLB-Network-US|399'


def hockey_menu(handle, build_url):
    """List all leagues from onhockey.tv as browsable folders."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, 'Hockey')
    xbmcplugin.setContent(handle, 'files')

    # NHL Network — 24/7 live TV channel (DaddyLive stream 663 via onhockey.tv)
    nhl_net_li = xbmcgui.ListItem(label='📺  NHL Network  [COLOR red]LIVE 24/7[/COLOR]')
    nhl_net_li.setArt({'thumb': _NHL_NETWORK_ICON, 'icon': _NHL_NETWORK_ICON})
    nhl_net_li.setInfo('video', {'title': 'NHL Network', 'plot': '24/7 NHL Network live TV channel.'})
    nhl_net_li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({'action':     'sports_event_play',
                   'event_id':   'nhl_network_live',
                   'event_path': _NHL_NETWORK_PATH,
                   'sport_slug': 'nhl',
                   'title':      'NHL Network'}),
        nhl_net_li, False
    )

    dlg    = _progress('Loading hockey schedule...')
    events = _ss.get_onhockey_events()
    dlg.close()

    # Count games per league from schedule
    league_counts = {}
    for ev in events:
        lg = ev.get('league', 'NHL')
        league_counts[lg] = league_counts.get(lg, 0) + 1

    # Build final league list: known ones first (in order), then any from schedule not in list
    shown = set()
    leagues = []
    for lg in _HOCKEY_ALL_LEAGUES:
        leagues.append((lg, league_counts.get(lg, 0)))
        shown.add(lg)
    for lg in sorted(league_counts):
        if lg not in shown:
            leagues.append((lg, league_counts[lg]))

    for lg, count in leagues:
        if count > 0:
            label = '%s  (%d upcoming)' % (lg, count)
        else:
            label = '%s  — off season' % lg
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': _HOCKEY_ICON, 'icon': _HOCKEY_ICON})
        li.setInfo('video', {'title': lg, 'plot': '%d games in current schedule' % count})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'hockey_league_events', 'league': lg}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def hockey_league_events(handle, build_url, league='NHL'):
    """List upcoming games for a specific hockey league from onhockey.tv."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '%s' % league)
    xbmcplugin.setContent(handle, 'files')

    dlg    = _progress('Loading %s schedule...' % league)
    events = _ss.get_onhockey_events()
    dlg.close()

    league_events = [e for e in events if e.get('league', 'NHL') == league]

    if not league_events:
        xbmcgui.Dialog().notification(
            'Starfleet', 'No %s games scheduled right now' % league, xbmcgui.NOTIFICATION_INFO
        )
        return

    for ev in league_events:
        start_ts   = ev.get('start_ts', 0)
        date_label = ev.get('date_label', '')
        local_time = _fmt_local_time(start_ts) if start_ts else ''

        if ev.get('is_live'):
            time_tag = '[COLOR red]🔴 LIVE[/COLOR]'
        elif local_time:
            time_tag = '[COLOR yellow]%s[/COLOR]' % local_time
        elif date_label:
            time_tag = '[COLOR grey]%s[/COLOR]' % date_label
        else:
            time_tag = ''

        label = '%s  %s' % (time_tag, ev['title']) if time_tag else ev['title']
        plot  = local_time or date_label or ('🔴 LIVE NOW' if ev.get('is_live') else '')

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': ev['title'], 'plot': plot})
        li.setArt({'thumb': _HOCKEY_ICON, 'icon': _HOCKEY_ICON})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'sports_event_play',
                       'event_id':   ev['id'],
                       'event_path': ev['path'],
                       'sport_slug': 'hockey',
                       'title':      ev['title']}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
