# -*- coding: utf-8 -*-
"""
resources/lib/phone_remote.py

Phone as remote: while it is on (Settings > Phone Remote), the service answers on the home network with a small page. A phone that opens
the address (or scans its QR code) gets a search box, the trending titles and the episodes of a show; choosing something sends it to Kodi,
which opens it and plays it. Every request carries a 4-digit pairing code (shown in Settings), nothing leaves the home network, and it is
off until switched on. Same page and rules as the HazMat TV app's phone remote. Voice search: the phone keyboard's own microphone key
dictates into the search box.
"""
import json
import os
import random
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse

import xbmc
import xbmcaddon
import xbmcgui

BASE_PORT = 8765
_server = None
_port = 0
_fail = 0
_locked_until = 0.0


def _log(msg):
    xbmc.log('[Starfleet/PhoneRemote] %s' % msg, xbmc.LOGINFO)


def _addon():
    return xbmcaddon.Addon('plugin.video.starfleet')


def enabled():
    try:
        return _addon().getSetting('phone_remote') == 'true'
    except Exception:
        return False


def code():
    """The 4-digit pairing code (made the first time it is asked for)."""
    a = _addon()
    c = a.getSetting('phone_remote_code')
    if not (c and c.isdigit() and len(c) == 4):
        c = '%04d' % random.SystemRandom().randrange(10000)
        a.setSetting('phone_remote_code', c)
    return c


def new_code():
    _addon().setSetting('phone_remote_code', '')
    return code()


def _private_rank(ip):
    """Lower is better: a home router hands out 192.168.x.x; 172.16-31 and 10.x are also used by VPN tunnels, Docker and virtual machines."""
    try:
        a, b = [int(x) for x in ip.split('.')[:2]]
    except ValueError:
        return 9
    if a == 192 and b == 168:
        return 0
    if a == 172 and 16 <= b <= 31:
        return 2 if b == 17 else 1
    if a == 10:
        return 3
    return 9


def addresses():
    """Every IPv4 address of this device that a phone on the same Wi-Fi could use, the likeliest home-network one first. A VPN
    (the default route goes into the tunnel) must not be the one given out, so the address is not taken from the route alone."""
    found = []
    for target in ('192.168.1.1', '192.168.0.1', '10.0.0.1', '10.255.255.255', '8.8.8.8'):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect((target, 1))
            found.append(s.getsockname()[0])
        except Exception:
            pass
        finally:
            s.close()
    try:
        found += socket.gethostbyname_ex(socket.gethostname())[2]
    except Exception:
        pass
    out = []
    for ip in found:
        if ip and not ip.startswith(('127.', '169.254.', '0.')) and ip not in out:
            out.append(ip)
    return sorted(out, key=_private_rank)


def address():
    """This device's address on the home network (None without one)."""
    ips = addresses()
    return ips[0] if ips else None


def url():
    ip = address()
    if not ip or not _port:
        return None
    return 'http://%s:%d/?k=%s' % (ip, _port, code())


# ── data (TMDB through the add-on's own metadata module) ───────────────────────────────────────────────────────────

def _items(movies, shows):
    out, seen = [], set()
    for tv, lst in ((False, movies), (True, shows)):
        for m in (lst or [])[:14]:
            tid = str(m.get('tmdb_id') or '')
            if not tid or (tid, tv) in seen or m.get('media_type') == 'person':
                continue
            seen.add((tid, tv))
            out.append({'id': tid, 'tv': tv, 'title': m.get('title') or m.get('name') or '', 'year': m.get('year') or '', 'poster': m.get('thumb') or ''})
    return out


_PAD = {'up': 'Input.Up', 'down': 'Input.Down', 'left': 'Input.Left', 'right': 'Input.Right', 'ok': 'Input.Select', 'back': 'Input.Back'}
_PAD_ACTIONS = {'okhold': 'contextmenu', 'enter': 'enter', 'playpause': 'playpause', 'ff': 'fastforward', 'rew': 'rewind'}


def _rpc(method, params=None):
    msg = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        msg['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(msg)))
    except Exception:
        return {'error': {'message': 'no answer'}}


def _keys(q):
    """The phone as a keyboard and arrow pad: text goes into the keyboard window that is open on the screen (the whole text of the box,
    as typed on the phone), code presses one key (up, down, left, right, ok, back, enter, playpause, ff, rew)."""
    code = q.get('code')
    if code in _PAD:
        r = _rpc(_PAD[code])
    elif code in _PAD_ACTIONS:
        r = _rpc('Input.ExecuteAction', {'action': _PAD_ACTIONS[code]})
    elif 'text' in q:
        r = _rpc('Input.SendText', {'text': q.get('text', '')[:2000], 'done': q.get('done') == '1'})
        if r.get('error'):
            return {'error': 'Open a text box on the TV first (Search...), then type here'}
    else:
        return {'error': 'Unknown'}
    return {'error': 'The TV did not take that key'} if r.get('error') else {'ok': True}


def _state():
    """Kodi cannot be mirrored or touched; the phone only needs to know whether a keyboard is open on the TV."""
    kb = xbmc.getCondVisibility('Window.IsActive(virtualkeyboard) | Window.IsActive(numericinput)')
    return {'mirror': False, 'kodi': True, 'field': bool(kb), 'text': ''}


def _api(path, q):
    if path == '/api/state':
        return _state()
    if path == '/api/key':
        return _keys(q)
    if path != '/api/play':
        from resources.lib import metadata as md
    if path == '/api/search':
        text = (q.get('q') or '').strip()
        if len(text) < 2:
            return []
        return _items(md.search_movies(text), md.search_tv(text))
    if path == '/api/trending':
        return _items(md.get_movies_trending(), md.get_tv_popular())
    if path == '/api/seasons':
        show = md.get_tv_detail(q.get('id', '')) or {}
        return [s.get('season') for s in show.get('seasons', []) if s.get('season') not in (None, 0, '0')]
    if path == '/api/episodes':
        eps = md.get_episodes(q.get('id', ''), int(q.get('s') or 1)) or []
        return [{'n': e.get('episode'), 'name': e.get('title') or ''} for e in eps]
    if path == '/api/play':
        tid = q.get('id', '')
        if not tid:
            return {'error': 'No title'}
        tv = q.get('tv') == '1'
        s, e = int(q.get('s') or 0), int(q.get('e') or 0)
        if tv and not (s and e):
            return {'error': 'Pick an episode'}
        title = q.get('title', '')
        if tv:
            query = 'action=meta_ep_play&tmdb_id=%s&season_num=%d&episode_num=%d&title=%s&year=%s' % (
                tid, s, e, quote('%s S%02dE%02d' % (title, s, e)), q.get('year', ''))
        else:
            query = 'action=meta_movie_play&tmdb_id=%s&title=%s&year=%s' % (tid, quote(title), q.get('year', ''))
        xbmc.executebuiltin('PlayMedia(plugin://plugin.video.starfleet/?%s)' % query)
        return {'ok': True}
    return {'error': 'Unknown'}


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, status, ctype, body):
        data = body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global _fail, _locked_until
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path in ('/', '/index.html'):
            return self._send(200, 'text/html; charset=utf-8', PAGE)
        if not u.path.startswith('/api/'):
            return self._send(404, 'text/plain', 'Not found')
        now = time.time()
        if now < _locked_until:
            return self._send(429, 'application/json', '{"error":"Too many wrong codes - wait a minute"}')
        if q.get('k') != code():
            _fail += 1
            if _fail >= 10:
                _fail, _locked_until = 0, now + 60
            return self._send(403, 'application/json', '{"error":"Wrong code"}')
        _fail = 0
        try:
            body = _api(u.path, q)
        except Exception as e:
            _log('%s: %s' % (u.path, e))
            body = {'error': 'Failed'}
        self._send(200, 'application/json', json.dumps(body))


def start():
    global _server, _port
    if _server or not enabled():
        return
    for p in range(BASE_PORT, BASE_PORT + 10):
        try:
            _server = ThreadingHTTPServer(('0.0.0.0', p), _Handler)
            _port = p
            break
        except OSError:
            continue
    if not _server:
        _log('no free port')
        return
    _server.daemon_threads = True
    threading.Thread(target=_server.serve_forever, daemon=True, name='starfleet-phone-remote').start()
    _log('listening on %d' % _port)


def stop():
    global _server, _port
    if _server:
        try:
            _server.shutdown()
            _server.server_close()
        except Exception:
            pass
    _server, _port = None, 0


def sync():
    """Start or stop the server to match the setting (called at start-up and when settings change)."""
    if enabled():
        start()
    else:
        stop()


def show_link():
    """Settings > Phone Remote > Show the address: the QR code and the code to type."""
    if not enabled():
        xbmcgui.Dialog().ok('Phone remote', 'Switch "Phone as remote" on first.')
        return
    sync()
    link = url()
    if not link:
        xbmcgui.Dialog().ok('Phone remote', 'No home network found (is this device on Wi-Fi or Ethernet?).')
        return
    from resources.lib.gui import qr_dialog as _q
    path = _q.make_qr(link, 'starfleet_phone_remote_qr.png')
    if not path:
        xbmcgui.Dialog().textviewer('Phone remote', 'Open this on your phone (same Wi-Fi):\n\n%s\n\nCode: %s' % (link.split('?')[0], code()))
        return
    others = [i for i in addresses() if i != address()]
    note = '' if not others else '  (if it does not open, try %s)' % ', '.join('http://%s:%d' % (i, _port) for i in others[:2])
    dlg = _q.QRDialog(path, 'Phone remote', 'Scan with the phone camera, or open %s%s' % (link.split('?')[0], note), code=code())
    dlg.update('Search on the phone, choose a title: it plays here.')
    dlg.doModal()


PAGE = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Starfleet remote</title><style>
html,body{margin:0;height:100%;background:#000;color:#e6edf3;font-family:system-ui,sans-serif;overscroll-behavior:none}
#top{position:fixed;top:0;left:0;right:0;z-index:5;display:flex;gap:6px;padding:8px;background:#161b22;border-bottom:1px solid #30363d}
#top button{flex:1}
#scr{position:fixed;top:56px;left:0;right:0;bottom:0;display:flex;align-items:center;justify-content:center;touch-action:none;user-select:none;-webkit-user-select:none}
#img{max-width:100%;max-height:100%;-webkit-user-drag:none;pointer-events:none}
#msg{position:fixed;left:0;right:0;top:56px;z-index:6;padding:6px 12px;color:#ff8c00;font-size:14px;background:rgba(0,0,0,.6);text-align:center}
#msg:empty{display:none}
.sheet{position:fixed;left:0;right:0;bottom:0;z-index:9;background:#161b22;border-top:1px solid #30363d;padding:12px;display:none;max-height:78%;overflow:auto;box-sizing:border-box}
textarea,input{width:100%;box-sizing:border-box;padding:12px;border-radius:8px;border:1px solid #30363d;background:#0f171e;color:#e6edf3;font-size:17px}
button{background:#ff8c00;border:0;color:#0f171e;font-weight:700;padding:11px 12px;border-radius:8px;font-size:15px}
button.s{background:#21262d;color:#e6edf3;font-weight:500}
.r{display:flex;gap:8px;margin-top:8px}.r button{flex:1;margin:0}
.g{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:280px;margin:10px auto}.g button{padding:16px 4px}
.card{display:flex;gap:12px;padding:8px 0;border-bottom:1px solid #21262d;align-items:center}
.card img{width:48px;height:72px;object-fit:cover;border-radius:6px;background:#21262d}
.card .t{flex:1}.card .t b{display:block;font-size:15px}.card .t span{color:#8b949e;font-size:12px}
.eps{padding:4px 0 10px}.eps button{margin:3px 4px 0 0}
</style></head><body>
<div id="top"><button class="s" id="bsearch">Search</button><button class="s" id="bkeys">Arrows</button><button class="s" id="btype">Type</button><button class="s" id="bback">Back</button></div>
<div id="msg"></div>
<div id="scr"></div>
<div class="sheet" id="ssearch"><input id="q" placeholder="Search a movie or show..." autocomplete="off"><div id="list"></div><div class="r"><button class="s" data-close="ssearch">Close</button></div></div>
<div class="sheet" id="skeys"><div class="g"><span></span><button class="s" data-c="up">Up</button><span></span><button class="s" data-c="left">Left</button><button data-c="ok">OK</button><button class="s" data-c="right">Right</button><span></span><button class="s" data-c="down">Down</button><button class="s" data-c="back">Back</button></div>
<div class="r"><button class="s" data-c="okhold">Hold OK</button><button class="s" data-c="enter">Enter</button></div>
<div class="r"><button class="s" data-c="rew">Rewind</button><button class="s" data-c="playpause">Play/Pause</button><button class="s" data-c="ff">Forward</button></div>
<div class="r"><button class="s" data-close="skeys">Close</button></div></div>
<div class="sheet" id="stype"><textarea id="tx" rows="3" placeholder="Type or paste here: it goes into the box on the TV" autocapitalize="off" autocorrect="off" spellcheck="false"></textarea>
<div class="r"><button class="s" id="tclr">Clear</button><button class="s" data-c="enter">Enter</button><button data-close="stype">Done</button></div></div>
<script>
var K=new URLSearchParams(location.search).get('k')||sessionStorage.getItem('k')||'';
if(!K){K=prompt('Code shown on the TV (Settings > Phone Remote)')||''}
sessionStorage.setItem('k',K);
function g(id){return document.getElementById(id)}
var img=g('img'),msg=g('msg'),tx=g('tx'),list=g('list'),mirrorOn=false,lastUrl=null,fieldOpen=false,manual=false,timer=null,shown=false;
function api(p,a){var u='/api/'+p+'?k='+encodeURIComponent(K);for(var x in a||{})u+='&'+x+'='+encodeURIComponent(a[x]);return fetch(u).then(function(r){return r.json()})}
function say(t){msg.textContent=t||''}
function el(tag,txt,cls){var e=document.createElement(tag);if(txt!=null)e.textContent=txt;if(cls)e.className=cls;return e}
var tq=Promise.resolve();
var NOBOX='Open a text box on the TV first, then type here';
function touch(a){tq=tq.then(function(){return api('touch',a)}).then(function(r){say(r&&r.error?r.error:'')},function(){say('The TV did not answer')})}
function key(a,cb){tq=tq.then(function(){return api('key',a)}).then(function(r){if(r&&r.error)say(r.error);else if(cb)cb(r);else if(r&&r.field===false)say(NOBOX)},function(){say('The TV did not answer')})}
function sheet(id,on){g(id).style.display=on?'block':'none'}
function frame(){
  if(!mirrorOn)return;
  var t0=Date.now();
  fetch('api/shot?k='+encodeURIComponent(K)+'&w='+(screen.width>700?1280:960)+'&t='+t0).then(function(r){
    var ct=r.headers.get('content-type')||'';
    if(ct.indexOf('image')<0)return r.json().then(function(j){say(j.error||'No picture');throw 0});
    return r.blob()
  }).then(function(b){
    var u=URL.createObjectURL(b),old=lastUrl;lastUrl=u;
    img.onload=function(){if(old)URL.revokeObjectURL(old)};img.src=u;shown=true;
    setTimeout(frame,Math.max(90,Math.min(600,(Date.now()-t0)*0.6)))
  },function(e){setTimeout(frame,e===0?3000:1500)})
}
function openType(text){tx.value=text||'';sheet('stype',true);fieldOpen=true;try{tx.focus()}catch(e){}}
function closeType(){sheet('stype',false);fieldOpen=false;manual=false;tx.blur()}
function poll(){
  api('state').then(function(s){
    if(s.mirror===false){
      if(mirrorOn){mirrorOn=false}
      if(!shown){shown=true;if(!s.kodi)say(s.error||'Screen sharing is off on the TV');sheet('skeys',true)}
      if(s.kodi){if(s.field&&!fieldOpen){manual=false;openType('')}else if(!s.field&&fieldOpen&&!manual){closeType()}}
    }else if(!s.error){
      if(!mirrorOn){mirrorOn=true;say('');frame()}
      if(s.field&&!fieldOpen){manual=false;openType(s.text)}
      else if(!s.field&&fieldOpen&&!manual){closeType()}
    }
  },function(){}).then(function(){setTimeout(poll,900)})
}
// taps, long presses and swipes on the picture
var gs=null;
var scr=g('scr');
scr.addEventListener('pointerdown',function(e){gs={x:e.clientX,y:e.clientY,t:Date.now()};try{scr.setPointerCapture(e.pointerId)}catch(x){}});
scr.addEventListener('pointerup',function(e){
  if(!gs||!shown)return;var r=img.getBoundingClientRect(),s=gs;gs=null;
  function nx(v){return Math.max(0,Math.min(1,(v-r.left)/r.width)).toFixed(4)}
  function ny(v){return Math.max(0,Math.min(1,(v-r.top)/r.height)).toFixed(4)}
  var dt=Date.now()-s.t,dist=Math.sqrt(Math.pow(e.clientX-s.x,2)+Math.pow(e.clientY-s.y,2));
  if(dist>14)touch({a:'swipe',x:nx(s.x),y:ny(s.y),x2:nx(e.clientX),y2:ny(e.clientY),ms:Math.max(120,Math.min(700,dt))});
  else if(dt>550)touch({a:'hold',x:nx(s.x),y:ny(s.y)});
  else touch({a:'tap',x:nx(s.x),y:ny(s.y)});
});
scr.addEventListener('pointercancel',function(){gs=null});
// buttons
g('bsearch').onclick=function(){sheet('ssearch',true);sheet('skeys',false);if(!list.childNodes.length)trending();g('q').focus()};
g('bkeys').onclick=function(){sheet('skeys',g('skeys').style.display!=='block')};
g('btype').onclick=function(){manual=true;openType(tx.value)};
g('bback').onclick=function(){key({code:'back'})};
document.querySelectorAll('[data-close]').forEach(function(b){b.onclick=function(){var id=b.getAttribute('data-close');if(id==='stype')closeType();else sheet(id,false)}});
document.querySelectorAll('[data-c]').forEach(function(b){b.onclick=function(){key({code:b.getAttribute('data-c')})}});
// typing on the phone goes into the box on the TV, the whole text each time
function sendFull(t){key({text:t.slice(0,2000)})}
var ttimer=null;
tx.addEventListener('input',function(){clearTimeout(ttimer);var v=tx.value;ttimer=setTimeout(function(){sendFull(v)},140)});
g('tclr').onclick=function(){tx.value='';sendFull('')};
// search
function show(items){list.innerHTML='';if(items.error){say(items.error);return}
  items.forEach(function(h){var c=el('div',null,'card'),i=el('img');if(h.poster)i.src=h.poster;c.appendChild(i);
    var t=el('div',null,'t');t.appendChild(el('b',h.title));t.appendChild(el('span',(h.tv?'Show':'Movie')+(h.year?' - '+h.year:'')));c.appendChild(t);
    var b=el('button',h.tv?'Episodes':'Play on TV');b.onclick=function(){h.tv?episodes(h,c):play(h,0,0)};c.appendChild(b);list.appendChild(c)})}
function play(h,s,e){api('play',{id:h.id,tv:h.tv?1:0,s:s,e:e,title:h.title,year:h.year}).then(function(r){say(r.ok?'Sent to Kodi: '+h.title+(s?' S'+s+'E'+e:''):(r.error||'Failed'));if(r.ok)sheet('ssearch',false)})}
function episodes(h,card){var old=card.nextSibling;if(old&&old.className==='eps'){old.remove();return}
  var box=el('div',null,'eps');card.after(box);api('seasons',{id:h.id}).then(function(ss){if(!ss.length){box.appendChild(el('span','No seasons listed'));return}
    ss.forEach(function(n){var b=el('button','Season '+n,'s');b.onclick=function(){box.querySelectorAll('.ep').forEach(function(x){x.remove()});
      api('episodes',{id:h.id,s:n}).then(function(es){es.forEach(function(x){var e=el('button',x.n+'. '+x.name,'s ep');e.style.display='block';e.style.width='100%';e.style.textAlign='left';e.onclick=function(){play(h,n,x.n)};box.appendChild(e)})})};box.appendChild(b)})})}
g('q').addEventListener('input',function(e){clearTimeout(timer);var v=e.target.value;timer=setTimeout(function(){v.length<2?trending():api('search',{q:v}).then(show)},350)});
function trending(){api('trending').then(function(r){show(r)})}
poll();
</script></body></html>"""
