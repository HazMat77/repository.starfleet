﻿# -*- coding: utf-8 -*-
"""
resources/lib/free_sources.py

Free streaming scrapers: Popcornflix, Tubi, Fawesome, Plex.

Popcornflix — rapi.ifood.tv backend; direct HLS URLs.
Tubi        — tubitv.com search + VOD resolve; direct HLS URLs.
Fawesome    — JS-rendered; listing entry only (no working stream scraper).
Plex        — Plex free AVOD; requires auth for stream URLs (listing entry only).
"""

import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
}

_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5, redirect=False)
        )
        _session.mount('https://', a)
    return _session


# ── Free service registry ─────────────────────────────────────────────────────

FREE_SERVICES = [
    {
        'id':          'popcornflix',
        'label':       'Popcornflix',
        'icon':        'https://www.popcornflix.com/favicon.ico',
        'media_type':  'both',
        'scrapable':   True,
        'url':         'https://www.popcornflix.com',
        'provider_id': 300,
    },
    {
        'id':          'tubi',
        'label':       'Tubi',
        'icon':        'https://tubitv.com/favicon.ico',
        'media_type':  'both',
        'scrapable':   True,
        'url':         'https://tubitv.com',
        'provider_id': 73,
    },
    {
        'id':          'fawesome',
        'label':       'Fawesome',
        'icon':        'https://fawesome.tv/favicon.ico',
        'media_type':  'both',
        'scrapable':   False,
        'url':         'https://fawesome.tv',
        'provider_id': 473,
    },
    {
        'id':          'plex',
        'label':       'Plex (Free)',
        'icon':        'https://www.plex.tv/wp-content/themes/plex/assets/img/favicon.ico',
        'media_type':  'both',
        'scrapable':   False,
        'url':         'https://watch.plex.tv',
        'provider_id': 538,
    },
]


def get_free_services(media_type=None):
    if media_type is None:
        return FREE_SERVICES
    return [s for s in FREE_SERVICES if s['media_type'] in (media_type, 'both')]


# ── TMDB discover by watch provider ──────────────────────────────────────────

_TMDB_KEYS = [
    'df33d5fbe29640895eb99174c801dbc7',
    'a7ebe77c68d738c3dd38348ee0c8f70f',
    'fe07cdedea76c769f430982de6c14842',
    '6cb7bcda188b8c9028544da7182242fd',
]
_TMDB_BASE = 'https://api.themoviedb.org/3'
_TMDB_IMG  = 'https://image.tmdb.org/t/p/w500'


def _tmdb_discover(endpoint, provider_id, page=1):
    import random
    key = random.choice(_TMDB_KEYS)
    params = {
        'api_key': key,
        'language': 'en-US',
        'watch_region': 'US',
        'with_watch_providers': str(provider_id),
        'watch_monetization_types': 'free',
        'sort_by': 'popularity.desc',
        'page': page,
    }
    try:
        r = _sess().get(_TMDB_BASE + endpoint, params=params, timeout=10)
        r.raise_for_status()
        return r.json().get('results', [])
    except Exception as e:
        xbmc.log('[Starfleet/FreeSrc] TMDB discover error: %s' % e, xbmc.LOGWARNING)
        return []


def get_free_movies_tmdb(service_id=None, page=1):
    """Return TMDB discover movies available free on the given service."""
    provider_id = 73  # default Tubi
    if service_id:
        svc_map = {s['id']: s.get('provider_id', 73) for s in FREE_SERVICES}
        provider_id = svc_map.get(service_id, 73)

    ck = 'free_movies_tmdb_%s_%d' % (service_id or 'default', page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    raw = _tmdb_discover('/discover/movie', provider_id, page)
    results = []
    for m in raw:
        results.append({
            'tmdb_id': m.get('id', ''),
            'title':   m.get('title', ''),
            'plot':    m.get('overview', ''),
            'year':    (m.get('release_date', '') or '')[:4],
            'rating':  str(m.get('vote_average', '')),
            'mpaa':    '',
            'thumb':   (_TMDB_IMG + m['poster_path']) if m.get('poster_path') else '',
            'fanart':  ('https://image.tmdb.org/t/p/w1280' + m['backdrop_path']) if m.get('backdrop_path') else '',
        })
    _cache.set(ck, results, 3600)
    return results


def get_free_tv_tmdb(service_id=None, page=1):
    """Return TMDB discover TV shows available free on the given service."""
    provider_id = 73
    if service_id:
        svc_map = {s['id']: s.get('provider_id', 73) for s in FREE_SERVICES}
        provider_id = svc_map.get(service_id, 73)

    ck = 'free_tv_tmdb_%s_%d' % (service_id or 'default', page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    raw = _tmdb_discover('/discover/tv', provider_id, page)
    results = []
    for m in raw:
        results.append({
            'tmdb_id': m.get('id', ''),
            'title':   m.get('name', '') or m.get('original_name', ''),
            'plot':    m.get('overview', ''),
            'year':    (m.get('first_air_date', '') or '')[:4],
            'rating':  str(m.get('vote_average', '')),
            'mpaa':    '',
            'thumb':   (_TMDB_IMG + m['poster_path']) if m.get('poster_path') else '',
            'fanart':  ('https://image.tmdb.org/t/p/w1280' + m['backdrop_path']) if m.get('backdrop_path') else '',
        })
    _cache.set(ck, results, 3600)
    return results


# ── Title normalisation ───────────────────────────────────────────────────────

import unicodedata

def _norm_title(t):
    t = t.lower()
    t = ''.join(c for c in unicodedata.normalize('NFD', t)
                if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9 ]', '', t).strip()


def _title_score(query_norm, candidate_norm):
    q = set(query_norm.split())
    c = set(candidate_norm.split())
    if not q:
        return 0.0
    return len(q & c) / max(len(q), len(c))


# ── Popcornflix ───────────────────────────────────────────────────────────────

_PCF_RAPI   = 'http://rapi.ifood.tv'
_PCF_PARAMS = (
    'appId=9&siteId=1518&platform_id=1217575&deviceId=starfleet'
    '&apiEnv=production&session-id=0&auth-token=1217575'
    '&gridstyle=flat-movie&keys='
)

_PCF_SEARCH_URLS = [
    lambda title: (
        'https://www.popcornflix.com/api/popcornflix/v4/search?searchString=%s&platform=web'
        % _req.utils.quote(title)
    ),
    lambda title: (
        'https://popcornflix.com/api/search?q=%s'
        % _req.utils.quote(title)
    ),
]


def get_popcornflix_movies(page=1):
    ck = 'free_pcf_movies_p%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    per_page = 20
    start    = (page - 1) * per_page
    url = (
        '%s/recipes.php?searchType=popular&%s'
        '&max-results=%d&start-index=%d&country=CA'
        % (_PCF_RAPI, _PCF_PARAMS, per_page, start)
    )

    try:
        r = _sess().get(url, timeout=12)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Free] Popcornflix list error: %s' % e, xbmc.LOGERROR)
        return []

    if data.get('status') != 'ok':
        return []

    items = []
    for m in (data.get('results') or []):
        title = m.get('title') or ''
        if not title:
            continue
        hls = m.get('video_hls_url') or m.get('video_url') or ''
        items.append({
            'title':      title,
            'year':       str(m.get('year') or ''),
            'plot':       (m.get('description') or '')[:300],
            'thumb':      m.get('main_picture') or m.get('picture') or '',
            'stream_url': hls,
            'pcf_id':     str(m.get('node_id') or ''),
        })

    _cache.set(ck, items, 1800)
    xbmc.log('[Starfleet/Free] Popcornflix: %d movies (page %d)' % (len(items), page), xbmc.LOGINFO)
    return items


def search_popcornflix(title, media_type='movie'):
    norm_q = _norm_title(title)
    data = None

    for url_fn in _PCF_SEARCH_URLS:
        try:
            r = _sess().get(url_fn(title), timeout=10)
            r.raise_for_status()
            data = r.json()
            if data and (data.get('results') or data.get('items') or data.get('data')):
                break
        except Exception as e:
            xbmc.log('[Starfleet/Free] Popcornflix endpoint failed: %s' % e, xbmc.LOGWARNING)
            data = None
            continue

    if not data:
        return []

    entries = data.get('results') or data.get('items') or data.get('data') or []
    results = []
    for m in entries:
        t = m.get('title', '') or m.get('name', '')
        if not t or _title_score(norm_q, _norm_title(t)) < 0.5:
            continue
        stream = m.get('video_hls_url') or m.get('video_url') or m.get('streamUrl', '')
        if not stream:
            continue
        year = str(m.get('year', '') or m.get('releaseYear', '') or '')
        label = '[FREE] Popcornflix — %s%s' % (t, ' (%s)' % year if year else '')
        results.append({'label': label, 'url': stream, 'source': 'popcornflix'})

    xbmc.log('[Starfleet/Free] Popcornflix search "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── Tubi ──────────────────────────────────────────────────────────────────────

_TUBI_SEARCH_URLS = [
    'https://tubitv.com/oz/row/search/result?q=%s&type=%s&platform=web&deviceType=androidphone',
    'https://tubitv.com/oz/row/search?q=%s&type=%s&platform=web',
    'https://tubitv.com/oz/movies/search?q=%s&type=%s',
]
_TUBI_VOD     = 'https://tubitv.com/api/usercontents/retrieve_vod/%s?devicetype=web'
_TUBI_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json',
    'Referer': 'https://tubitv.com/',
}


def _tubi_stream_url(content_id):
    try:
        r = _sess().get(_TUBI_VOD % content_id, headers=_TUBI_HEADERS, timeout=10)
        if r.status_code != 200:
            return ''
        data = r.json()
        for res in (data.get('video_resources') or []):
            url = res.get('manifest', {}).get('url', '') or res.get('url', '')
            if url and ('.m3u8' in url or '.mp4' in url):
                return url
    except Exception:
        pass
    return ''


def search_tubi(title, media_type='movie'):
    norm_q    = _norm_title(title)
    tubi_type = 'movie' if media_type != 'tv' else 'tv_movie'
    from urllib.parse import quote as _q
    data = None
    for url_tpl in _TUBI_SEARCH_URLS:
        try:
            url = url_tpl % (_q(title), tubi_type)
            r = _sess().get(url, headers=_TUBI_HEADERS, timeout=12)
            r.raise_for_status()
            data = r.json()
            if data and (data.get('results') or data.get('data')):
                break
        except Exception as e:
            xbmc.log('[Starfleet/Free] Tubi endpoint failed: %s' % e, xbmc.LOGWARNING)
            data = None
            continue

    if not data:
        return []

    results_raw = data.get('results') or data.get('data') or []
    if isinstance(results_raw, dict):
        results_raw = results_raw.get('movies') or results_raw.get('series') or []

    results = []
    for item in results_raw[:10]:
        t = item.get('title', '') or item.get('name', '')
        if not t or _title_score(norm_q, _norm_title(t)) < 0.5:
            continue
        content_id = str(item.get('id', '') or item.get('content_id', ''))
        if not content_id:
            continue
        stream_url = _tubi_stream_url(content_id)
        if not stream_url:
            continue
        year = str(item.get('year', '') or item.get('release_year', '') or '')
        label = '[FREE] Tubi — %s%s' % (t, ' (%s)' % year if year else '')
        results.append({'label': label, 'url': stream_url, 'source': 'tubi'})

    xbmc.log('[Starfleet/Free] Tubi search "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── Plex Free ─────────────────────────────────────────────────────────────────
# Plex AVOD stream URLs require a Plex auth token — search returns metadata only.

def search_plex(title, media_type='movie'):
    xbmc.log('[Starfleet/Free] Plex search skipped (auth required for stream URLs)', xbmc.LOGINFO)
    return []


# ── Fawesome ──────────────────────────────────────────────────────────────────
# JS-rendered — no scrapable stream URLs.

def search_fawesome(title, media_type='movie'):
    xbmc.log('[Starfleet/Free] Fawesome search skipped (JS-rendered, no API)', xbmc.LOGINFO)
    return []


# ── Combined search ───────────────────────────────────────────────────────────

def search_free_streams(title, year=None, media_type='movie', imdb_id=None,
                        season=None, episode=None):
    """
    Search all active free sources for a given title.
    Returns list of {'label', 'url', 'source'}.
    When imdb_id is provided, also queries Nuvio and WebStreamer direct stream APIs.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    tasks = {
        'scrapers': lambda: _search_scraper_sources(title, media_type,
                                                    imdb_id=imdb_id,
                                                    season=season,
                                                    episode=episode),
    }

    results = []
    with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        for future in as_completed(futures, timeout=40):
            try:
                results.extend(future.result())
            except Exception as e:
                xbmc.log('[Starfleet/Free] %s search failed: %s' % (futures[future], e),
                         xbmc.LOGWARNING)

    return results


def _search_scraper_sources(title, media_type='movie', imdb_id=None,
                            season=None, episode=None):
    """Delegate to scraper_sources.search_all_scrapers() — isolated import."""
    try:
        from resources.lib.scraper_sources import search_all_scrapers
        return search_all_scrapers(title, media_type, season=season,
                                   episode=episode, imdb_id=imdb_id)
    except Exception as e:
        xbmc.log('[Starfleet/Free] scraper_sources import error: %s' % e, xbmc.LOGWARNING)
        return []
