# -*- coding: utf-8 -*-
"""
resources/lib/request_sources.py

"Requests" — manually curated movie/TV/adult stream links, produced by an
external orchestrator (run on a separate always-on PC, same setup as the
sports/channel scraper JSON already hosted this way) and published as JSON
to this repo's own data/ folder. Not a scraped source — real, hand-picked
links, matched precisely instead of by fuzzy title search:
  - Movies: matched by imdb_id (e.g. "tt20912374")
  - TV:     matched by show title (normalised) + season + episode
  - Adult:  matched by AdultDVDEmpire's own numeric film id (the same
            "ade_id"/"film_id" this addon's own ade.py already uses)

Every entry's own 'url' is handed to ResolveURL exactly like every other embed
source in this addon — streamtape.com (the host every current example
uses) is a standard ResolveURL-supported host, no custom per-host logic
needed here.

JSON shape (one array per file):
  requests_movies.json:
    [{"imdb_id": "tt20912374", "title": "Pins and Needles",
      "url": "https://streamtape.com/v/.../tt20912374_Pins_and_Needles.mp4"}]
  requests_tv.json:
    [{"title": "Furious", "season": 1, "episode": 6,
      "url": "https://streamtape.com/v/.../furious.s01e06...mp4"}]
  requests_adult.json:
    [{"adc_id": "1896334", "title": "Cara & Lucy Escorts Deluxe",
      "url": "https://streamtape.com/v/.../1896334_Cara_%26_Lucy..."}]
"""
import re
import unicodedata
import xbmc
import xbmcaddon
import xbmcvfs
import requests

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_BASE = 'https://hazmat77.github.io/repository.starfleet/data'
_REQUESTS_MOVIES_URL = _BASE + '/requests_movies.json'
_REQUESTS_TV_URL     = _BASE + '/requests_tv.json'
_REQUESTS_ADULT_URL  = _BASE + '/requests_adult.json'

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                    '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
}

# Short TTL — this is meant to reflect "the orchestrator just ran" quickly,
# not a slow-changing scraper catalogue like everything else in json_data.py.
_TTL = 5 * 60


def _fetch_json(url, cache_key):
    cached = _cache.get(cache_key)
    if cached is not None:
        return cached
    try:
        r = requests.get(url, headers=_HEADERS, timeout=12)
        r.raise_for_status()
        data = r.json()
        if not isinstance(data, list):
            data = []
    except Exception as e:
        xbmc.log('[Starfleet/Requests] fetch error (%s): %s' % (url, e), xbmc.LOGWARNING)
        return []
    _cache.set(cache_key, data, _TTL if data else 60)
    return data


def _norm_title(t):
    t = (t or '').lower()
    t = ''.join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9 ]', '', t).strip()


def get_requested_movies():
    return _fetch_json(_REQUESTS_MOVIES_URL, 'requests_movies_v1')


def get_requested_tv():
    return _fetch_json(_REQUESTS_TV_URL, 'requests_tv_v1')


def get_requested_adult():
    return _fetch_json(_REQUESTS_ADULT_URL, 'requests_adult_v1')


def find_movie_request(imdb_id):
    if not imdb_id:
        return None
    for r in get_requested_movies():
        if r.get('imdb_id') == imdb_id:
            return r
    return None


def find_tv_request(title, season, episode):
    if not title or not season or not episode:
        return None
    norm_q = _norm_title(title)
    for r in get_requested_tv():
        if (_norm_title(r.get('title', '')) == norm_q
                and str(r.get('season', '')) == str(season)
                and str(r.get('episode', '')) == str(episode)):
            return r
    return None


def find_adult_request(ade_id):
    if not ade_id:
        return None
    ade_id = str(ade_id)
    for r in get_requested_adult():
        if str(r.get('adc_id', r.get('ade_id', ''))) == ade_id:
            return r
    return None


def resolve_request_stream(url):
    """Hand a Request entry's own url to ResolveURL — every current entry
    is a streamtape.com link, a standard ResolveURL-supported host, same
    as every other embed source in this addon. Falls back to the raw url
    untouched if ResolveURL can't resolve it (or isn't installed), same
    fallback behaviour every other resolver call in this codebase uses."""
    if not url:
        return None
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                return r
    except ImportError:
        pass
    except Exception as e:
        xbmc.log('[Starfleet/Requests] resolveurl error: %s' % e, xbmc.LOGWARNING)
    return url
