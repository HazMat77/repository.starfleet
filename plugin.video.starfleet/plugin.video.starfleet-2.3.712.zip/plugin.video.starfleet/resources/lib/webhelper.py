# -*- coding: utf-8 -*-
"""
Starfleet Helper (Android only): the little companion app that does two jobs Kodi cannot do by itself.

  1. It opens a player page in a hidden web view, the way the HazMat TV app does, and gives back the stream the page plays. Sources whose player
     is built by obfuscated JavaScript (marked 'sfweb:<page>' by the scrapers) need it.
  2. It shows a site's "are you human?" check (an "I am not a robot" box) as a real page the person moves a pointer over with the arrow keys and
     clicks with OK. The cookie that earns stays on this device and the sources of that site use it (see the Verify list in Settings).

It is NOT a dependency: everything else works without it, and when a source that needs it is chosen, a pop-up offers to install it.

    enable_env()            set HAZMAT_WEBVIEW so the scrapers list the sources that need the helper (Android only, and only when the setting is on)
    available()             True when the helper answers (it is started when it is installed but not running)
    sniff(page, referer)    -> 'stream|Header=value&..' or ''
    resolve_page(page, ...) -> the stream for a page, with the install pop-up, a progress notice and error messages; '' when there is none
    verify_menu()           the Settings list of sites that ask to be verified: verify, switch the sources on or off, forget
    verify_site(key)        opens the verify screen for one site and keeps what it earns
"""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui

PORT = 18765
_BASE = 'http://127.0.0.1:%d' % PORT
PACKAGE = 'com.starfleet.helper'
HELPER_APK = 'StarfleetHelper-1.1.0.apk'
HELPER_VERSION = '1.1.0'            # the verify screen needs this one; page sniffing works with 1.0.0
HELPER_URL = 'https://hazmat77.github.io/repository.starfleet/' + HELPER_APK

ENABLED = True              # the web-view sources are listed on Android (the setting "Use the Starfleet Helper" can switch them off)

_declined_at = 0.0          # the pop-up is not shown again for 10 minutes after "Cancel" (a list of streams can hold several of these sources)


def _setting(key, default=''):
    try:
        v = xbmcaddon.Addon().getSetting(key)
        return v if v != '' else default
    except Exception:
        return default


def is_android():
    try:
        return bool(xbmc.getCondVisibility('System.Platform.Android'))
    except Exception:
        return False


def enabled():
    """The helper's features are on: the code switch, and the viewer's own setting (on unless they turned it off)."""
    return ENABLED and _setting('use_helper', 'true') != 'false'


def enable_env():
    """Tell the scrapers that web-view sources can be offered (they are listed whether or not the helper is installed yet)."""
    if enabled() and is_android():
        os.environ.setdefault('HAZMAT_WEBVIEW', '1')


def _get(path, timeout):
    import urllib.request
    with urllib.request.urlopen(_BASE + path, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8', 'replace'))


def ping(timeout=1.5):
    try:
        d = _get('/ping', timeout)
        return d if d.get('ok') else None
    except Exception:
        return None


def _vkey(v):
    out = []
    for p in str(v or '0').split('.'):
        try:
            out.append(int(p))
        except ValueError:
            out.append(0)
    return tuple(out)


def _start(wait=6.0):
    """Opens the helper's invisible start screen (it starts the service and closes at once) and waits for it to answer."""
    xbmc.executebuiltin('StartAndroidActivity("%s","com.starfleet.helper.START")' % PACKAGE)
    end = time.time() + wait
    while time.time() < end:
        if ping(1.0):
            return True
        xbmc.sleep(400)
    return False


def available(start=True):
    """True when the helper answers; with `start`, an installed helper that is not running is started first."""
    if not is_android():
        return False
    if ping():
        return True
    return _start() if start else False


def sniff(page, referer='', timeout=25):
    """Asks the helper for the stream a player page plays. '' when the page gave none in time."""
    from urllib.parse import quote
    try:
        d = _get('/sniff?url=%s&referer=%s&timeout=%d' % (quote(page, safe=''), quote(referer or '', safe=''), int(timeout)), timeout + 8)
        return d.get('url') or ''
    except Exception as e:
        xbmc.log('[Starfleet/Helper] sniff failed: %s' % e, xbmc.LOGWARNING)
        return ''


# ---- the install offer -----------------------------------------------------------------------------------------------------------------

DOWNLOADER = 'com.esaba.downloader'      # the Downloader app: it has Android's "install unknown apps" permission, which Kodi does not have


def _install():
    """Kodi cannot install an app itself (Android lets only an app with the "install unknown apps" permission do that, and Kodi has none), so
    the helper's address goes to the Downloader app, which fetches it and opens Android's installer. The person presses Install there."""
    shown = HELPER_URL.split('://', 1)[-1]
    xbmcgui.Dialog().ok('Starfleet Helper',
                        'The Downloader app opens next and gets the helper. Press [B]Install[/B] when it asks, then choose the source again.[CR]'
                        'No Downloader app yet? Install the free Downloader app, open it and type:[CR][B]%s[/B]' % shown)
    xbmc.log('[Starfleet/Helper] handing %s to the Downloader app' % HELPER_URL, xbmc.LOGINFO)
    xbmc.executebuiltin('StartAndroidActivity("%s","android.intent.action.VIEW","","%s")' % (DOWNLOADER, HELPER_URL))
    return True


def offer_install(update=False, reason='', force=False):
    """The pop-up: this needs the helper; OK downloads and installs it."""
    global _declined_at
    if not force and time.time() - _declined_at < 600:
        return False
    if update:
        msg = 'The Starfleet Helper needs an update%s.[CR]Would you like to update it?' % (reason or '')
    else:
        msg = 'This source needs the Starfleet Helper add-on.[CR]Would you like to install it?' if not reason else \
            '%s[CR]needs the Starfleet Helper add-on. Would you like to install it?' % reason
    if xbmcgui.Dialog().yesno('Starfleet Helper', msg, nolabel='Cancel', yeslabel='OK'):
        return _install()
    _declined_at = time.time()
    return False


# ---- what the routers call -------------------------------------------------------------------------------------------------------------

def resolve_page(page, referer='', title='', timeout=25):
    """The stream of a web player page ('url|headers'), or '' when there is none (the user has been told why)."""
    page = (page or '')
    if page.startswith('sfweb:'):
        page = page[len('sfweb:'):]
    if not is_android():
        xbmcgui.Dialog().notification('Starfleet', 'This source needs an Android device', xbmcgui.NOTIFICATION_INFO, 4000)
        return ''
    if not available():
        offer_install()
        return ''
    xbmcgui.Dialog().notification('Starfleet', 'Opening the web player...', xbmcgui.NOTIFICATION_INFO, 3000)
    got = sniff(page, referer, timeout)
    if not got:
        xbmcgui.Dialog().notification('Starfleet', 'The web player did not give a stream', xbmcgui.NOTIFICATION_INFO, 4000)
    return got


# ---- the verify screen ------------------------------------------------------------------------------------------------------------------

def _sites():
    from starfleetscrapers.core import http as sfhttp
    return sfhttp, sfhttp.SITES


def _ready_for_verify():
    """The helper (version 1.1.0 or later) answers; installs or updates it first when it has to."""
    if not is_android():
        xbmcgui.Dialog().ok('Starfleet Helper', 'The site checks need an Android device.')
        return False
    d = ping() or (_start() and ping())
    if not d:
        offer_install(reason='Verifying a site', force=True)
        return False
    if _vkey(d.get('version')) < _vkey(HELPER_VERSION):
        offer_install(update=True, reason=' for the site checks', force=True)
        return False
    return True


def verify_site(key):
    """Opens the verify screen for a site and waits for the person to pass its check. True when the site now has a cookie from this device."""
    from urllib.parse import quote
    sfhttp, sites = _sites()
    site = sites.get(key)
    if not site or not _ready_for_verify():
        return False
    try:
        before = int((_get('/clearance?site=%s' % key, 3) or {}).get('ts') or 0)
    except Exception:
        before = 0
    fresh = '&fresh=1'          # always starts without an old cookie, so the one kept is the one this check earned
    uri = 'starfleethelper://verify?site=%s&url=%s&cookie=cf_clearance&title=%s%s' % (key, quote(site['url'], safe=''), quote(site['name'], safe=''), fresh)
    xbmc.executebuiltin('StartAndroidActivity("%s","android.intent.action.VIEW","","%s")' % (PACKAGE, uri))
    xbmc.log('[Starfleet/Helper] verify screen opened for %s' % key, xbmc.LOGINFO)
    seen_running = False
    end = time.time() + 600
    monitor = xbmc.Monitor()
    xbmc.sleep(1500)
    while time.time() < end and not monitor.abortRequested():
        try:
            st = _get('/verify-state', 3)
        except Exception:
            st = {}
        if st.get('running'):
            seen_running = True
        elif seen_running or time.time() > end - 570:     # closed, or never opened within 30 s
            break
        xbmc.sleep(1000)
    got = {}
    try:
        got = _get('/clearance?site=%s' % key, 3) or {}
    except Exception:
        pass
    if got.get('ok') and int(got.get('ts') or 0) > before and got.get('cf'):
        sfhttp.set_clearance(key, got.get('cf', ''), got.get('ua', ''), got.get('cookie', ''))
        xbmcgui.Dialog().notification('Starfleet', '%s is verified - its sources are on' % site['name'], xbmcgui.NOTIFICATION_INFO, 5000)
        return True
    xbmcgui.Dialog().notification('Starfleet', '%s was not verified' % site['name'], xbmcgui.NOTIFICATION_INFO, 4000)
    return False


def _ago(ts):
    s = max(0, int(time.time()) - int(ts or 0))
    if s < 3600:
        return 'a few minutes ago'
    if s < 86400:
        return '%d hours ago' % (s // 3600)
    return '%d days ago' % (s // 86400)


def verify_menu():
    """Settings > Verify sites: the sites that ask 'are you human?', with what each needs."""
    if not is_android():
        xbmcgui.Dialog().ok('Verify sites', 'These checks are shown by the Starfleet Helper, which needs an Android device.')
        return
    try:
        sfhttp, sites = _sites()
        from starfleetscrapers.core import source_toggles as st
    except Exception:
        xbmcgui.Dialog().notification('Starfleet', 'Update the Starfleet Scrapers add-on first', xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    sel = 0
    while True:
        keys = list(sites.keys())
        rows = []
        for k in keys:
            s = sites[k]
            state, ts = sfhttp.status(k)
            cat, sk = s['toggle']
            on = st.on(cat, sk)
            if state == 'verified':
                how = 'verified %s' % _ago(ts)
            elif state == 'expired':
                how = 'needs another check'
            else:
                how = 'not verified'
            rows.append('%s  [%s]   %s   -   sources %s' % (s['name'], s['kind'], how, 'ON' if on else 'OFF'))
        rows.append('Install or update the Starfleet Helper')
        i = xbmcgui.Dialog().select('Verify sites (arrows + OK on the page, Back when done)', rows, preselect=sel)
        if i < 0:
            return
        sel = i
        if i == len(keys):
            if ping() and _vkey((ping() or {}).get('version')) >= _vkey(HELPER_VERSION):
                xbmcgui.Dialog().ok('Starfleet Helper', 'The Starfleet Helper %s is installed and up to date.' % (ping() or {}).get('version', ''))
            else:
                _install()
            continue
        k = keys[i]
        s = sites[k]
        cat, sk = s['toggle']
        state, _ts = sfhttp.status(k)
        opts = ['Verify now' if state == 'none' else 'Verify again',
                'Turn its sources %s' % ('OFF' if st.on(cat, sk) else 'ON')]
        if state != 'none':
            opts.append('Forget this verification')
        j = xbmcgui.Dialog().select(s['name'], opts)
        if j == 0:
            verify_site(k)
        elif j == 1:
            st.set_on(cat, sk, not st.on(cat, sk))
        elif j == 2:
            sfhttp.forget(k)
            try:
                _get('/forget?site=%s' % k, 3)
            except Exception:
                pass
