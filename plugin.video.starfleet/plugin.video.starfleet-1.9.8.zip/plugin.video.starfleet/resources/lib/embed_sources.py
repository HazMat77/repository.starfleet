# -*- coding: utf-8 -*-
"""
resources/lib/embed_sources.py

Embed-provider scrapers using IMDB IDs — no debrid required.
Works like The Crew's source modules: finds content on hosting sites,
returns embed or direct stream URLs for playback via ResolveURL.

Sources:
  VidSrc.to   — rcp-chain: data-hash → /rcp/{hash} → video host URL
  VidSrc.me   — alternative VidSrc mirror
  Autoembed   — direct IMDB-ID URL, returns direct streams or host URLs
  SuperEmbed  — multiembed.mov, IMDB-based

IMPORTANT: every provider must only return results with PLAYABLE URLs.
Never return an embed page URL (multiembed.mov, autoembed.co, vidsrc.to)
as a result — Kodi cannot play a webpage.
"""

import re
import xbmc

try:
    import requests as _req
except ImportError:
    _req = None

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)
_HEADERS = {
    'User-Agent': _UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
}

_session = None


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=0, redirect=False)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get(url, timeout=10, referer='', allow_redirects=True):
    s = _sess()
    if not s:
        return ''
    try:
        headers = {}
        if referer:
            headers['Referer'] = referer
        r = s.get(url, headers=headers, timeout=timeout, allow_redirects=allow_redirects)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Embed] GET %s: %s' % (url[:60], e), xbmc.LOGWARNING)
        return ''


def _get_with_final_url(url, timeout=10, referer=''):
    """Fetch URL and return (text, final_url_after_redirects)."""
    s = _sess()
    if not s:
        return '', url
    try:
        headers = {}
        if referer:
            headers['Referer'] = referer
        r = s.get(url, headers=headers, timeout=timeout, allow_redirects=True)
        return r.text, r.url
    except Exception as e:
        xbmc.log('[Starfleet/Embed] GET+final %s: %s' % (url[:60], e), xbmc.LOGWARNING)
        return '', url


_STREAM_RE = [
    re.compile(r'''["']?file["']?\s*:\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''<source[^>]+src=["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    re.compile(r'''loadSource\s*\(\s*["'](https?://[^"']+\.m3u8[^"']*)["']''', re.I),
    re.compile(r'''["'](https?://[^\s"'<>]+\.m3u8[^\s"'<>]*)["']''', re.I),
    re.compile(r'''["'](https?://[^\s"'<>]+\.mp4[^\s"'<>]*)["']''', re.I),
]


def _extract_stream(html):
    for pat in _STREAM_RE:
        m = pat.search(html)
        if m:
            url = m.group(1).replace('\\/', '/').strip()
            if url.startswith('http'):
                return url
    return ''


# Known video host domains — these are playable via our resolvers or ResolveURL
_KNOWN_HOSTS = [
    'streamtape.', 'mixdrop.', 'doodstream.', 'dood.watch',
    'streamvid.', 'vidhide.', 'vidmoly.', 'voe.sx',
    'upstream.to', 'vidlox.', 'highstream.', 'filemoon.',
]


def _is_known_host(url):
    url_lower = url.lower()
    return any(h in url_lower for h in _KNOWN_HOSTS)


def _is_direct_stream(url):
    """True if the URL is a direct playable stream or a known resolvable host."""
    url_lower = url.lower()
    if any(ext in url_lower for ext in ('.m3u8', '.mp4', '.mkv')):
        return True
    return _is_known_host(url)


# ── VidSrc.to ─────────────────────────────────────────────────────────────────

_VIDSRC_BASE = 'https://vidsrc.to'


def _vidsrc_rcp(rcp_hash, referer, depth=0):
    """Follow a VidSrc rcp chain to get a video host URL or direct stream."""
    if depth > 3:
        return ''
    rcp_url = '%s/rcp/%s' % (_VIDSRC_BASE, rcp_hash)
    try:
        html, final_url = _get_with_final_url(rcp_url, timeout=10, referer=referer)
        # If redirect landed on a known video host, return it
        if _is_known_host(final_url):
            return final_url
        # Try direct stream extraction
        stream = _extract_stream(html)
        if stream:
            return stream
        # Look for nested embed iframes
        iframe_m = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
        if iframe_m:
            embed_url = iframe_m.group(1)
            if embed_url.startswith('//'):
                embed_url = 'https:' + embed_url
            if _is_known_host(embed_url):
                return embed_url
            if embed_url.startswith('http') and _is_direct_stream(embed_url):
                return embed_url
    except Exception as e:
        xbmc.log('[Starfleet/Embed] VidSrc rcp error: %s' % e, xbmc.LOGWARNING)
    return ''


def search_vidsrc(imdb_id, media_type='movie', season=None, episode=None):
    """Search VidSrc.to for stream sources using IMDB ID."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/embed/tv/%s/%s/%s' % (_VIDSRC_BASE, imdb_id, season, episode)
        else:
            url = '%s/embed/movie/%s' % (_VIDSRC_BASE, imdb_id)

        html = _get(url, timeout=12)
        if not html:
            return []

        # Try multiple patterns for VidSrc server hashes
        hashes = (
            re.findall(r'data-hash=["\']([A-Za-z0-9]+)["\']', html, re.I) or
            re.findall(r'/rcp/([A-Za-z0-9]{6,})', html) or
            re.findall(r'data-id=["\']([A-Za-z0-9]+)["\'][^>]*class=["\'][^"\']*server', html, re.I) or
            re.findall(r'class=["\'][^"\']*server[^"\']*["\'][^>]*data-[a-z]+=\s*["\']([A-Za-z0-9]+)["\']', html, re.I)
        )
        server_names = re.findall(r'class=["\']server-item-hl["\'][^>]*>([^<]+)<', html, re.I)

        results = []
        for i, h in enumerate(hashes[:4]):
            server_label = server_names[i].strip() if i < len(server_names) else 'S%d' % (i + 1)
            host_url = _vidsrc_rcp(h, url)
            if host_url and _is_direct_stream(host_url):
                results.append({'label': 'VidSrc (%s)' % server_label, 'url': host_url})

        # Don't return embed page URL as fallback — Kodi can't play it
        xbmc.log('[Starfleet/Embed] VidSrc: %d results for %s (found %d hashes)' % (
            len(results), imdb_id, len(hashes)), xbmc.LOGWARNING)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] VidSrc error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Autoembed ─────────────────────────────────────────────────────────────────

_AUTOEMBED_BASE = 'https://autoembed.co'


def search_autoembed(imdb_id, media_type='movie', season=None, episode=None):
    """Search autoembed.co for stream sources using IMDB ID."""
    if not imdb_id:
        return []
    try:
        # Correct autoembed.co URL format
        if media_type == 'tv' and season and episode:
            url = '%s/tv/imdb_id/%s/%s/%s' % (_AUTOEMBED_BASE, imdb_id, season, episode)
        else:
            url = '%s/movie/imdb_id/%s' % (_AUTOEMBED_BASE, imdb_id)

        html, final_url = _get_with_final_url(url, timeout=12)
        if not html:
            return []

        # If the redirect landed on a direct stream, return it
        if _is_direct_stream(final_url) and final_url != url:
            return [{'label': 'Autoembed', 'url': final_url}]

        # Try direct stream extraction
        stream = _extract_stream(html)
        if stream:
            return [{'label': 'Autoembed [Direct]', 'url': stream}]

        # Look for server list with embed/stream links
        results = []
        server_links = re.findall(
            r'href=["\']([^"\']+(?:/stream/|/embed/|/e/)[^"\']+)["\']', html, re.I
        )
        for srv_url in server_links[:3]:
            if srv_url.startswith('/'):
                srv_url = _AUTOEMBED_BASE + srv_url
            if not srv_url.startswith('http'):
                continue
            # Only follow if it's a known host (immediately playable)
            if _is_known_host(srv_url):
                results.append({'label': 'Autoembed', 'url': srv_url})
                continue
            # Otherwise fetch and try to extract a stream
            srv_html, srv_final = _get_with_final_url(srv_url, referer=url, timeout=8)
            if _is_direct_stream(srv_final) and srv_final != srv_url:
                results.append({'label': 'Autoembed', 'url': srv_final})
            elif srv_html:
                s = _extract_stream(srv_html)
                if s:
                    results.append({'label': 'Autoembed', 'url': s})

        # Don't add raw autoembed page URL as fallback — Kodi can't play it
        xbmc.log('[Starfleet/Embed] Autoembed: %d results for %s' % (len(results), imdb_id), xbmc.LOGWARNING)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] Autoembed error: %s' % e, xbmc.LOGWARNING)
        return []


# ── SuperEmbed (multiembed.mov) ───────────────────────────────────────────────

def search_superembed(imdb_id, media_type='movie', season=None, episode=None):
    """Search multiembed.mov for stream sources using IMDB ID."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = 'https://multiembed.mov/?video_id=%s&tmdb=0&s=%s&e=%s' % (imdb_id, season, episode)
        else:
            url = 'https://multiembed.mov/?video_id=%s&tmdb=0' % imdb_id

        html, final_url = _get_with_final_url(url, timeout=12)
        if not html:
            return []

        # If redirected to a direct stream, return it
        if _is_direct_stream(final_url) and final_url != url:
            return [{'label': 'SuperEmbed', 'url': final_url}]

        # Try direct stream extraction
        stream = _extract_stream(html)
        if stream:
            return [{'label': 'SuperEmbed [Direct]', 'url': stream}]

        # Look for server links (known video hosts only)
        results = []
        # Pattern: server buttons with href/data-href pointing to known hosts
        all_links = re.findall(r'href=["\']([^"\']{8,})["\']', html, re.I)
        all_links += re.findall(r'data-href=["\']([^"\']{8,})["\']', html, re.I)
        all_links += re.findall(r'data-src=["\']([^"\']{8,})["\']', html, re.I)

        for link in all_links:
            if link.startswith('//'):
                link = 'https:' + link
            if not link.startswith('http'):
                continue
            if _is_known_host(link):
                results.append({'label': 'SuperEmbed', 'url': link})
            elif _is_direct_stream(link) and 'multiembed' not in link.lower():
                results.append({'label': 'SuperEmbed [Direct]', 'url': link})
            if len(results) >= 2:
                break

        # IMPORTANT: DO NOT add multiembed.mov URL as fallback — it's a webpage, not a stream
        xbmc.log('[Starfleet/Embed] SuperEmbed: %d results for %s' % (len(results), imdb_id), xbmc.LOGWARNING)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Embed] SuperEmbed error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Unified embed search ──────────────────────────────────────────────────────

def search_embed_providers(imdb_id, media_type='movie', season=None, episode=None):
    """
    Search all embed providers in parallel.
    Returns list of {'label': str, 'url': str}.
    Only runs for movie/tv — adult is handled separately.
    All returned URLs are either direct streams (.m3u8/.mp4) or known
    video host URLs (streamtape, mixdrop, etc.) — never bare embed page URLs.
    """
    if not imdb_id or media_type == 'adult':
        return []

    from concurrent.futures import ThreadPoolExecutor, as_completed

    tasks = {
        'VidSrc':     lambda: search_vidsrc(imdb_id, media_type, season, episode),
        'Autoembed':  lambda: search_autoembed(imdb_id, media_type, season, episode),
        'SuperEmbed': lambda: search_superembed(imdb_id, media_type, season, episode),
    }

    results = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        try:
            for future in as_completed(futures, timeout=18):
                name = futures[future]
                try:
                    r = future.result()
                    results.extend(r)
                except Exception as e:
                    xbmc.log('[Starfleet/Embed] %s failed: %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Embed] providers timeout: %s' % e, xbmc.LOGWARNING)

    xbmc.log('[Starfleet/Embed] Total embed results: %d for %s' % (len(results), imdb_id), xbmc.LOGWARNING)
    return results
