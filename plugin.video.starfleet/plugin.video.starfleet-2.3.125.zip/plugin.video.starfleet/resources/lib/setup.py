# -*- coding: utf-8 -*-
"""
resources/lib/setup.py

First-run dependency checker. Auto-installs Gujal00 repo + ResolveURL
if they are missing, so stream resolution works out of the box.
"""

import os
import zipfile
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

# Gujal00 ResolveURL repo — https://github.com/Gujal00/ResolveURL
_GUJAL_REPO_URL    = 'https://github.com/Gujal00/ResolveURL/releases/latest/download/repository.gujal00.zip'
_GUJAL_REPO_TMP    = 'special://temp/repository.gujal00.zip'
_GUJAL_REPO_ID     = 'repository.gujal00'
_ADDONS_DIR        = 'special://home/addons/'

_RESOLVEURL_ZIP_URL = 'https://github.com/Gujal00/ResolveURL/releases/latest/download/script.module.resolveurl.zip'
_RESOLVEURL_ZIP_TMP = 'special://temp/script.module.resolveurl.zip'


def _addon_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except RuntimeError:
        return False


def _download_file(url, dest_special):
    """Download url to a special:// path. Returns True on success."""
    import requests
    dest = xbmcvfs.translatePath(dest_special)
    try:
        r = requests.get(url, timeout=30, stream=True)
        r.raise_for_status()
        with open(dest, 'wb') as f:
            for chunk in r.iter_content(65536):
                f.write(chunk)
        return os.path.exists(dest) and os.path.getsize(dest) > 1000
    except Exception as e:
        xbmc.log('[Starfleet/Setup] download error: %s' % e, xbmc.LOGERROR)
        return False


def _extract_zip_to_addons(zip_special):
    """Extract a Kodi addon zip into the addons folder."""
    zip_path    = xbmcvfs.translatePath(zip_special)
    addons_path = xbmcvfs.translatePath(_ADDONS_DIR)
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(addons_path)
        xbmc.log('[Starfleet/Setup] Extracted %s to %s' % (zip_path, addons_path), xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log('[Starfleet/Setup] extract error: %s' % e, xbmc.LOGERROR)
        return False


def _install_gujal_repo():
    """Download and extract the Gujal00 repository zip."""
    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet Setup', 'Downloading ResolveURL repository...')
    dlg.update(10)

    ok = _download_file(_GUJAL_REPO_URL, _GUJAL_REPO_TMP)
    dlg.update(50)

    if not ok:
        dlg.close()
        xbmcgui.Dialog().ok(
            'Starfleet Setup',
            'Could not download ResolveURL repository.\n'
            'Check your internet connection and try again.\n\n'
            'Install manually from: github.com/Gujal00/ResolveURL'
        )
        return False

    dlg.update(70, 'Installing ResolveURL repository...')
    ok = _extract_zip_to_addons(_GUJAL_REPO_TMP)
    dlg.update(100)
    dlg.close()

    if not ok:
        xbmcgui.Dialog().ok('Starfleet Setup', 'Failed to extract repository zip.')
        return False

    xbmc.executebuiltin('UpdateLocalAddons', True)
    xbmc.sleep(1500)
    return True


def _install_resolveurl():
    """Download and extract ResolveURL from Gujal00 GitHub releases."""
    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet Setup', 'Downloading ResolveURL...')
    dlg.update(10)
    ok = _download_file(_RESOLVEURL_ZIP_URL, _RESOLVEURL_ZIP_TMP)
    dlg.update(60)
    if not ok:
        dlg.close()
        return False
    dlg.update(80, 'Installing ResolveURL...')
    ok = _extract_zip_to_addons(_RESOLVEURL_ZIP_TMP)
    dlg.update(100)
    dlg.close()
    if ok:
        xbmc.executebuiltin('UpdateLocalAddons', True)
        xbmc.sleep(1000)
    return ok


def check_and_guide():
    """
    Check for ResolveURL on every startup.
    If missing, offer to auto-install via Gujal00 repo.
    """
    if _addon_installed('script.module.resolveurl'):
        return

    xbmc.log('[Starfleet/Setup] ResolveURL not found — prompting install', xbmc.LOGINFO)

    answer = xbmcgui.Dialog().yesno(
        'Starfleet — Install ResolveURL?',
        'ResolveURL is not installed.\n\n'
        'It resolves stream links for Adult streams and other hosters '
        '(StreamTape, DoodStream, MyVidPlay, etc.).\n\n'
        'Install now? (downloads from github.com/Gujal00/ResolveURL)'
    )

    if not answer:
        return

    # Step 1 — install Gujal00 repo (if not already)
    if not _addon_installed(_GUJAL_REPO_ID):
        ok = _install_gujal_repo()
        if not ok:
            return
        xbmc.sleep(1000)

    # Step 2 — install ResolveURL
    _install_resolveurl()

    if _addon_installed('script.module.resolveurl'):
        xbmcgui.Dialog().notification(
            'Starfleet Setup',
            'ResolveURL installed successfully!',
            xbmcgui.NOTIFICATION_INFO, 4000
        )
        xbmc.log('[Starfleet/Setup] ResolveURL installed OK', xbmc.LOGINFO)
    else:
        xbmcgui.Dialog().ok(
            'Starfleet Setup',
            'ResolveURL could not be installed automatically.\n\n'
            'Install manually:\n'
            '1. Go to github.com/Gujal00/ResolveURL\n'
            '2. Download the repository zip\n'
            '3. Add-ons → Install from zip'
        )
