# -*- coding: utf-8 -*-
"""
service.py — Kodi background service entry point (xbmc.python.service,
start="startup" in addon.xml). Runs for the whole Kodi session, unlike
default.py's plugin:// invocations which are fresh, short-lived processes
(this addon explicitly sets reuselanguageinvoker=false) — see
resources/lib/local_proxy.py's own docstring for why that distinction is
exactly what OK.ru playback needed.
"""
import xbmc

try:
    from resources.lib import tls_speed
    tls_speed.install()
except Exception:
    pass

try:                                          # keep Starfleet Scrapers / Starfleet Resolver in step with this version
    from resources.lib import dep_check
    dep_check.run_in_background()
except Exception:
    pass

try:                                          # open the connections to the fast sources before the first search
    from resources.lib import torrent_sources as _ts
    _ts.prewarm()
except Exception:
    pass

try:                                          # the memory state in kodi.log, so a "low memory" kill of Kodi can be explained afterwards
    import threading
    from resources.lib import memguard
    threading.Thread(target=memguard.log_loop, args=(xbmc.Monitor(),), daemon=True).start()
except Exception:
    pass

try:                                          # My Teams alerts (a thread that sleeps until a team is followed)
    import threading
    from resources.lib import myteams_alerts
    threading.Thread(target=myteams_alerts.run, args=(xbmc.Monitor(),), daemon=True).start()
except Exception:
    pass

try:                                          # today's new episodes of the shows being watched, ready when their links appear
    import threading
    from resources.lib import airing_prep
    threading.Thread(target=airing_prep.run, args=(xbmc.Monitor(),), daemon=True).start()
except Exception:
    pass

try:                                          # build the Requests lists once, in the background, so the first source list is quick
    import threading
    def _warm_requests():
        if xbmc.Monitor().waitForAbort(60):
            return
        from resources.lib import request_sources as _rq
        _rq.warm()
    threading.Thread(target=_warm_requests, daemon=True).start()
except Exception:
    pass

try:                                          # watched marks that could not be sent to SIMKL earlier are sent when it is reachable
    import threading
    def _simkl_flush():
        mon = xbmc.Monitor()
        if mon.waitForAbort(120):
            return
        while not mon.abortRequested():
            try:
                from resources.lib import simkl_sync
                simkl_sync.flush_pending()
            except Exception:
                pass
            if mon.waitForAbort(20 * 60):
                break
    threading.Thread(target=_simkl_flush, daemon=True).start()
except Exception:
    pass

try:                                          # the Adult widgets, only when the Adult section and this option are both on
    import threading
    from resources.lib import adult_prewarm
    threading.Thread(target=adult_prewarm.run, args=(xbmc.Monitor(),), daemon=True).start()
except Exception:
    pass

try:                                          # the public IPTV playlists: a quiet check in the background (Live TV speeds it up)
    import threading
    import xbmcaddon
    if xbmcaddon.Addon('plugin.video.starfleet').getSetting('live_m3u_quiet') != 'false':
        from starfleetscrapers.live import m3u_lists
        threading.Thread(target=m3u_lists.service, args=(xbmc.Monitor(),), daemon=True).start()
except Exception:
    pass

try:                                          # keep the plugin level with the paired tracking accounts (SIMKL / Trakt My List)
    import threading
    from resources.lib import tracker_sync
    threading.Thread(target=tracker_sync.run, args=(xbmc.Monitor(),), daemon=True).start()
except Exception:
    pass

from resources.lib import local_proxy

local_proxy.run_service(xbmc.Monitor())
