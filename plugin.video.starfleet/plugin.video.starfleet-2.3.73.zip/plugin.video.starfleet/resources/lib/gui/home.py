"""
Starfleet Home Window — Amazon Prime Video-style GUI
"""
import threading
import xbmc
import xbmcgui
import xbmcaddon

try:
    _ADDON = xbmcaddon.Addon('plugin.video.starfleet')
except Exception:
    _ADDON = None

# Control IDs
_ID_PLAY    = 20
_ID_INFO    = 21
_ID_NAV_MOV = 41
_ID_NAV_TV  = 42
_ID_NAV_SPT = 43
_ID_NAV_LIV = 44
_ID_NAV_ADU = 45
_ID_ROW0    = 100
_ID_ROW1    = 200
_ID_ROW2    = 300

_ROW_LABELS   = ['New Releases', 'Popular', 'Trending']
_TRAILER_DELAY = 5


class HomeWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        self._film_rows      = [[], [], []]
        self._hero_films     = []
        self._hero_row       = 0
        self._trailer_timer  = None
        self._trailer_active = False
        self._data_ready     = False
        super(HomeWindow, self).__init__(*args, **kwargs)

    # ------------------------------------------------------------------ lifecycle

    def onInit(self):
        try:
            for i, lbl in enumerate(_ROW_LABELS):
                self.setProperty('sf_row%d_label' % i, lbl)
            self.setProperty('sf_hero_title', 'Loading...')
            # Load data in background — populate via repeated timer check
            threading.Thread(target=self._fetch_data, daemon=True).start()
        except Exception as e:
            xbmc.log('[Starfleet/Home] onInit: %s' % e, xbmc.LOGERROR)

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                   xbmcgui.ACTION_STOP, xbmcgui.ACTION_PARENT_DIR):
            self._stop_trailer()
            self.close()

    def onClick(self, cid):
        try:
            if cid == _ID_PLAY:
                self._play_hero()
            elif cid == _ID_INFO:
                self._show_info()
            elif cid == _ID_NAV_MOV:
                self._open_section('adult_movies_library')
            elif cid == _ID_NAV_TV:
                self._open_section('main_menu_tv')
            elif cid == _ID_NAV_SPT:
                self._open_section('main_menu_sports')
            elif cid == _ID_NAV_LIV:
                self._open_section('live_menu')
            elif cid == _ID_NAV_ADU:
                self._open_section('adult_movies_library')
            elif cid in (_ID_ROW0, _ID_ROW1, _ID_ROW2):
                self._play_selected(cid)
        except Exception as e:
            xbmc.log('[Starfleet/Home] onClick: %s' % e, xbmc.LOGERROR)

    def onFocus(self, cid):
        try:
            if not self._data_ready:
                return
            row_map = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2}
            if cid in row_map:
                self._update_hero_from_row(row_map[cid])
        except Exception:
            pass

    # ------------------------------------------------------------------ data

    def _fetch_data(self):
        try:
            from resources.lib import afdb_router as _ar
            rows = _ar.get_home_carousel_data()
        except Exception as e:
            xbmc.log('[Starfleet/Home] _fetch_data: %s' % e, xbmc.LOGERROR)
            rows = [[], [], []]

        self._film_rows = rows
        self._data_ready = True

        # Give window time to finish drawing, then populate on a loop
        # Kodi doesn't let background threads call getControl safely,
        # so we use a timer that keeps retrying until it works.
        xbmc.sleep(800)
        for attempt in range(10):
            try:
                self._populate_all()
                break
            except Exception as e:
                xbmc.log('[Starfleet/Home] populate attempt %d: %s' % (attempt, e), xbmc.LOGWARNING)
                xbmc.sleep(300)

    def _populate_all(self):
        for row_idx, list_id in enumerate([_ID_ROW0, _ID_ROW1, _ID_ROW2]):
            films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
            ctrl = self.getControl(list_id)
            ctrl.reset()
            for film in films:
                li = xbmcgui.ListItem(label=film.get('title', ''))
                li.setArt({
                    'thumb':  film.get('thumb', ''),
                    'fanart': film.get('fanart', film.get('thumb', '')),
                })
                li.setProperty('film_id',     str(film.get('id', '')))
                li.setProperty('film_url',    film.get('url', ''))
                li.setProperty('film_source', film.get('source', 'afdb'))
                li.setProperty('film_slug',   film.get('slug', ''))
                ctrl.addItem(li)

        # Set hero from first film in row 0
        if self._film_rows and self._film_rows[0]:
            self._set_hero(self._film_rows[0][0])
            self._schedule_trailer()

    def _set_hero(self, film):
        title   = film.get('title', '')
        year    = film.get('year', '')
        rating  = film.get('rating', '')
        runtime = film.get('runtime', '')
        meta    = '  |  '.join(p for p in [year, rating, runtime] if p)
        self.setProperty('sf_hero_title',  title)
        self.setProperty('sf_hero_meta',   meta)
        self.setProperty('sf_hero_plot',   film.get('plot', film.get('description', '')))
        self.setProperty('sf_hero_fanart', film.get('fanart', film.get('thumb', '')))
        self.setProperty('sf_hero_badge',  film.get('source', 'AFDB').upper())

    def _update_hero_from_row(self, row_idx):
        try:
            lids = [_ID_ROW0, _ID_ROW1, _ID_ROW2]
            ctrl = self.getControl(lids[row_idx])
            pos  = ctrl.getSelectedPosition()
            films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
            if films and 0 <= pos < len(films):
                self._stop_trailer()
                self._hero_row = row_idx
                self._set_hero(films[pos])
                self._schedule_trailer()
        except Exception:
            pass

    # ------------------------------------------------------------------ trailer

    def _schedule_trailer(self):
        self._stop_trailer()
        t = threading.Timer(_TRAILER_DELAY, self._start_trailer)
        t.daemon = True
        t.start()
        self._trailer_timer = t

    def _start_trailer(self):
        try:
            films = self._film_rows[self._hero_row] if self._film_rows else []
            if not films:
                return
            film = films[0]
            trailer = film.get('trailer', '')
            if trailer:
                self._trailer_active = True
                self.setProperty('sf_trailer_playing', 'true')
                xbmc.Player().play(trailer, windowed=True)
        except Exception:
            pass

    def _stop_trailer(self):
        if self._trailer_timer:
            self._trailer_timer.cancel()
            self._trailer_timer = None
        if self._trailer_active:
            try:
                xbmc.Player().stop()
            except Exception:
                pass
            self._trailer_active = False
            self.setProperty('sf_trailer_playing', '')

    # ------------------------------------------------------------------ play / nav

    def _play_hero(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        self._stop_trailer()
        self.close()
        self._play_film(films[0])

    def _play_selected(self, cid):
        row_map = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2}
        row_idx = row_map[cid]
        try:
            ctrl  = self.getControl(cid)
            pos   = ctrl.getSelectedPosition()
            films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
            if films and 0 <= pos < len(films):
                self._stop_trailer()
                self.close()
                self._play_film(films[pos])
        except Exception as e:
            xbmc.log('[Starfleet/Home] _play_selected: %s' % e, xbmc.LOGERROR)

    def _play_film(self, film):
        source  = film.get('source', 'afdb')
        slug    = film.get('slug', '')
        film_id = str(film.get('id', ''))
        url     = film.get('url', '')
        title   = film.get('title', '').replace("'", '')
        if source == 'pandamovies':
            cmd = "RunPlugin(plugin://plugin.video.starfleet/?action=adult_panda_play&slug=%s&film_url=%s&title=%s)" % (slug, url, title)
        elif source == 'hqporner':
            cmd = "RunPlugin(plugin://plugin.video.starfleet/?action=adult_hqp_play&slug=%s&film_url=%s&title=%s)" % (slug, url, title)
        elif source in ('freeomovie','xxxmoviestream','pornwatch','watchpornfree','speedporn','xxxscenes','xmovix'):
            cmd = "RunPlugin(plugin://plugin.video.starfleet/?action=adult_stream_sources&film_id=%s&film_url=%s&title=%s)" % (film_id, url, title)
        else:
            cmd = "RunPlugin(plugin://plugin.video.starfleet/?action=afdb_play_search&film_id=%s&film_slug=%s&film_title=%s)" % (film_id, slug, title)
        xbmc.executebuiltin(cmd)

    def _show_info(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        film = films[0]
        xbmcgui.Dialog().textviewer(
            film.get('title', 'Info'),
            film.get('plot', film.get('description', 'No information available.'))
        )

    def _open_section(self, action):
        self._stop_trailer()
        self.close()
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=%s)' % action)
