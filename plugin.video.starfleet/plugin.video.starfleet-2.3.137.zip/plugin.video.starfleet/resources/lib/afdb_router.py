﻿# -*- coding: utf-8 -*-
"""
resources/lib/afdb_router.py — Adult Film Database section

Menu structure:
  🔞 Adult
    ├── 🆕 New Releases
    ├── 🏆 Most Popular
    ├── 🎭 Browse by Category
    ├── 🎬 Browse by Studio  (A-Z)
    ├── 👤 Browse by Actor   (A-Z)
    └── 🔍 Search

Each film item opens a detail page with:
  - Full description / synopsis
  - Cast list (each actor is browsable)
  - Studio, Director, Year, Runtime, Rating
  - Front cover as thumbnail
  - Large front cover as fanart
  - Back cover as additional art
  - Categories as genre tags

Playback:
  - No stream URL yet → shows "Add stream source" dialog
  - When a stream URL is supplied (StreamTape, DoodStream, etc.)
    it is passed to ResolveURL/URLResolver for resolution
  - Falls back to direct play if ResolveURL not installed
"""

import re as _re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon


def _extract_year(title):
    """Pull the most recent 4-digit year from a title string (1980–2099)."""
    years = _re.findall(r'\b(19[89]\d|20[0-9]\d)\b', title or '')
    return max(int(y) for y in years) if years else 0

from resources.lib import afdb
from resources.lib import cache as _cache
from concurrent.futures import ThreadPoolExecutor

ADDON     = xbmcaddon.Addon('plugin.video.starfleet')
PAGE_SIZE = 30


# ── Helpers ───────────────────────────────────────────────────────────────────

def _add_dir(handle, build_url, label, params, thumb='', plot=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_film(handle, build_url, film):
    """Add a film as a directly-playable item with the richest available metadata.

    Priority chain:
      thumb  : ADE CDN (highest quality) → AFDB 400 px front → AFDB 200 px front
      fanart : AFDB 400 px front cover (always available by URL pattern)
      banner : AFDB back cover
      landscape / extra fanarts : AFDB scene screenshots
      metadata : AFDB detail (year/studio/director/cast/categories/synopsis)
                 ADE detail (fills any gaps + adds runtime/rating)
    """
    import re as _re

    # 1. Seed from the slim card dict (id, slug, title, thumb from list page)
    d = dict(film)

    # 2. Merge AFDB full detail (prewarm cache)
    full_afdb = _cache.get('afdb_film_%s' % film.get('id', ''))
    if full_afdb:
        for k, v in full_afdb.items():
            if v and not d.get(k):
                d[k] = v
        # Screenshots live only in full detail — always take them
        if full_afdb.get('screenshots'):
            d['screenshots'] = full_afdb['screenshots']

    # 3. Merge ADE search result → higher-quality CDN thumb + description gap-fill
    _ade_ck = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', d.get('title', '').lower())[:80]
    ade_search = _cache.get(_ade_ck)
    ade_film_id = ''
    if ade_search and isinstance(ade_search, dict):
        ade_film_id = ade_search.get('id', '')
        # ADE CDN thumb is typically 600-1200 px — prefer over AFDB 200 px
        if ade_search.get('thumb') and ade_search.get('fanart'):
            d.setdefault('ade_thumb',  ade_search['thumb'])
            d.setdefault('ade_fanart', ade_search['fanart'])
        for k in ('description', 'year', 'studio', 'director'):
            if not d.get(k) and ade_search.get(k):
                d[k] = ade_search[k]
        if not d.get('cast') and ade_search.get('cast'):
            d['cast'] = ade_search['cast']

    # 4. Merge ADE full detail → runtime, rating, genres, cast, synopsis
    if ade_film_id:
        ade_detail = _cache.get('ade_detail_%s' % ade_film_id)
        if ade_detail and isinstance(ade_detail, dict):
            for k in ('description', 'year', 'studio', 'director', 'runtime', 'rating'):
                if not d.get(k) and ade_detail.get(k):
                    d[k] = ade_detail[k]
            if not d.get('categories') and ade_detail.get('categories'):
                d['categories'] = ade_detail['categories']
            if not d.get('cast') and ade_detail.get('cast'):
                d['cast'] = ade_detail['cast']
            # ADE CDN thumb from detail (wider search in full page)
            if ade_detail.get('thumb') and not d.get('ade_thumb'):
                d['ade_thumb']  = ade_detail['thumb']
                d['ade_fanart'] = ade_detail.get('fanart', ade_detail['thumb'])

    # 5. Build best-available artwork URLs
    film_id   = film.get('id', '')
    # Thumb: ADE CDN (highest quality) → AFDB 200px front → whatever card supplied
    best_thumb = (
        d.get('ade_thumb')
        or (afdb.thumb_url(film_id) if film_id else '')
        or d.get('thumb', '')
    )
    fanart = (
        d.get('ade_fanart')
        or (afdb.thumb_url(film_id) if film_id else '')
        or d.get('fanart', best_thumb)
    )
    backcover    = d.get('backcover', '')
    screenshots  = d.get('screenshots', [])

    li = xbmcgui.ListItem(label=d['title'])

    # 6. Set Kodi metadata
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(d['title'])
        tag.setPlot(d.get('description', ''))
        if str(d.get('year', '')).isdigit():
            tag.setYear(int(d['year']))
        if d.get('studio'):
            tag.setStudios([d['studio']])
        if d.get('categories'):
            tag.setGenres(d['categories'])
        if d.get('director'):
            tag.setDirectors([d['director']])
        if d.get('rating'):
            try:
                tag.setRating(float(d['rating']))
            except (ValueError, TypeError):
                pass
        if d.get('runtime'):
            try:
                tag.setDuration(int(d['runtime']) * 60)
            except (ValueError, TypeError):
                pass
        tag.setMpaa('Adults Only')
        # Cast — merge AFDB actor IDs with ADE names, attach cached photos
        cast_list = []
        seen_names = set()
        for c in (d.get('cast') or []):
            name = c.get('name', '')
            if not name or name in seen_names:
                continue
            seen_names.add(name)
            photo = ''
            actor_id = c.get('id', '')
            if actor_id:
                actor_detail = _cache.get('afdb_actor_detail_%s' % actor_id)
                photo = (actor_detail or {}).get('photo', '')
            cast_list.append(xbmcgui.Actor(name, '', 0, photo))
        if cast_list:
            tag.setCast(cast_list)
    except Exception:
        info = {
            'title':    d['title'],
            'plot':     d.get('description', ''),
            'year':     int(d['year']) if str(d.get('year', '')).isdigit() else 0,
            'studio':   d.get('studio', ''),
            'genre':    ', '.join(d.get('categories', [])),
            'director': d.get('director', ''),
            'rating':   float(d.get('rating', 0) or 0),
            'duration': int(d.get('runtime', 0) or 0) * 60,
            'mpaa':     'Adults Only',
        }
        li.setInfo('video', info)

    # 7. Artwork — richest possible set
    art = {
        'thumb':   best_thumb,
        'poster':  best_thumb,
        'fanart':  fanart,
    }
    if backcover:
        art['banner'] = backcover
    if screenshots:
        art['landscape'] = screenshots[0]
    # Additional fanart slots (Kodi 18+) — scene shots after the front-cover fanart
    for i, shot in enumerate(screenshots[:4], 2):
        art['fanart%d' % i] = shot

    li.setArt(art)

    li.setProperty('IsPlayable', 'true')

    source = film.get('source', 'afdb')
    if source == 'pandamovies':
        play_params = {
            'action':   'adult_panda_play',
            'slug':     film.get('slug', ''),
            'film_url': film.get('url', ''),
            'title':    film['title'],
        }
    elif source == 'hqporner':
        play_params = {
            'action':   'adult_hqp_play',
            'slug':     film.get('slug', ''),
            'film_url': film.get('url', ''),
            'title':    film['title'],
        }
    elif source in ('freeomovie', 'xxxmoviestream', 'pornwatch',
                    'watchpornfree', 'speedporn', 'xxxscenes', 'xmovix'):
        play_params = {
            'action':   'adult_stream_sources',
            'film_id':  film.get('id', ''),
            'film_url': film.get('url', ''),
            'title':    film['title'],
        }
    else:
        play_params = {
            'action':     'afdb_play_search',
            'film_id':    film.get('id', ''),
            'film_slug':  film.get('slug', ''),
            'film_title': film['title'],
        }

    xbmcplugin.addDirectoryItem(handle, build_url(play_params), li, False)


def _need_fetch(key):
    return _cache.get(key) is None


def _progress(msg):
    d = xbmcgui.DialogProgress()
    d.create('Starfleet', msg)
    return d


def _next_page(handle, build_url, action, page, extra=None):
    params = {'action': action, 'page': page + 1}
    if extra:
        params.update(extra)
    _add_dir(handle, build_url,
             label='~~ Next Page (%d) ~~' % (page + 1),
             params=params)


# ── Adult Main Menu ───────────────────────────────────────────────────────────

def _prewarm_film_details(films):
    """
    Fire-and-forget background pre-fetch of full AFDB film detail
    (description, cast, studio, director, rating, photos) for each
    slim result in a list view. User sees instant detail loads with
    no loading dialog on subsequent clicks.
    Only fetches films whose detail cache is cold.
    Max 5 concurrent requests to avoid hammering AFDB.
    """
    cold = [
        (f['id'], f['slug']) for f in films
        if f.get('id') and _need_fetch('afdb_film_%s' % f['id'])
    ]
    if not cold:
        return

    def _fetch(film_id, film_slug):
        try:
            afdb.get_film_detail(film_id, film_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for film_id, film_slug in cold:
        pool.submit(_fetch, film_id, film_slug)
    pool.shutdown(wait=False)   # never blocks the UI


def _prewarm_actor_details(films):
    """
    Pre-fetch actor photos and profiles for cast members found in
    a list of film results. Pulls actor detail for any actor whose
    photo cache is cold so browsing cast is instant.
    Capped at 10 actors to avoid excessive requests.
    """
    seen     = set()
    to_fetch = []

    for film in films:
        for actor in film.get('cast', [])[:5]:  # top 5 cast per film
            aid = actor.get('id', '')
            if aid and aid not in seen:
                seen.add(aid)
                if _need_fetch('afdb_actor_detail_%s' % aid):
                    to_fetch.append((aid, actor.get('slug', '')))
            if len(to_fetch) >= 10:
                break
        if len(to_fetch) >= 10:
            break

    if not to_fetch:
        return

    def _fetch(actor_id, actor_slug):
        try:
            afdb.get_actor_detail(actor_id, actor_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for actor_id, actor_slug in to_fetch:
        pool.submit(_fetch, actor_id, actor_slug)
    pool.shutdown(wait=False)


def _filter_films_with_sources(films):
    """
    Filter a film list to only those that have at least one cached stream source.
    Films from stream sources (panda, hqporner, freeomovie, etc.) always pass —
    they ARE the source. ADE/AFDB films are checked against the title cache.
    Films not yet in any cache pass through (graceful degradation on first load).
    Background prewarm is launched for unchecked films so next load is filtered.
    """
    try:
        from resources.lib import adult_streams as _as
        _as.prewarm_title_index()   # ensure index is built from cached data

        checked = []
        unchecked = []
        for film in films:
            # Stream-source films always kept — they carry their own playback
            if film.get('source') in _as.STREAM_SOURCE_NAMES:
                checked.append(film)
                continue
            result = _as.has_cached_source(film.get('title', ''))
            if result is None:
                unchecked.append(film)   # not yet in any cache — show it this time
            elif result:
                checked.append(film)     # confirmed has a source
            # else: confirmed has NO source — drop it

        # Background: pre-check unchecked films so next load can filter them
        if unchecked:
            def _prewarm_check():
                for f in unchecked:
                    try:
                        _as.search_by_title(f['title'])
                    except Exception:
                        pass
            import threading
            threading.Thread(target=_prewarm_check, daemon=True).start()

        return checked + unchecked
    except Exception as e:
        xbmc.log('[AFDB] source filter error: %s' % e, xbmc.LOGWARNING)
        return films   # fail open


def adult_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Adult')
    xbmcplugin.setContent(handle, 'movies')

    _add_dir(handle, build_url, '🎬  Movies',
             {'action': 'adult_movies_menu'},
             plot='Browse Adult DVD Empire — New Releases, Recently Added, Best Sellers')

    _add_dir(handle, build_url, '🎞️  Scenes',
             {'action': 'adult_hqp_categories'},
             plot='Browse HD scenes by category on HQ Porner')

    _add_dir(handle, build_url, '🔍  Search',
             {'action': 'adult_search_unified'},
             plot='Search by movie title, performer name, or scene type (e.g. anal)')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_movies_menu(handle, build_url):
    """Movies submenu: ADE browse sections + library + favorites."""
    xbmcplugin.setPluginCategory(handle, 'Adult — Movies')
    xbmcplugin.setContent(handle, 'movies')

    _add_dir(handle, build_url, '🆕  New Releases',
             {'action': 'adult_browse_new_releases', 'page': 1},
             plot='New release movies from Adult DVD Empire (/new-release-porn-movies.html)')
    _add_dir(handle, build_url, '🕐  Recently Added',
             {'action': 'adult_browse_recently_added', 'page': 1},
             plot='Recently added videos from Adult DVD Empire (/new-addition-porn-videos.html)')
    _add_dir(handle, build_url, '🏆  Best Sellers',
             {'action': 'adult_browse_bestsellers', 'page': 1},
             plot='Best selling videos from Adult DVD Empire (/best-selling-porn-videos.html)')
    _add_dir(handle, build_url, '❤️  Adult Favorites',
             {'action': 'adult_favorites_list'},
             plot='Your saved adult movies')
    _add_dir(handle, build_url, '🗄️  Full Library',
             {'action': 'adult_movies_library', 'page': 1},
             plot='All movies — sources checked, sorted by most recent year')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def _ade_browse_page(handle, build_url, films, section_label, page, next_action):
    """Render an ADE listing page with parallel detail prewarming and context menus."""
    import urllib.parse as _up
    import html as _html_lib
    from resources.lib import ade as _ade, adult_favorites as _afav

    xbmcplugin.setPluginCategory(handle, section_label)
    xbmcplugin.setContent(handle, 'movies')

    if not films:
        xbmcgui.Dialog().notification('ADE', 'No films found — try a different page', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        return

    # Parallel detail prewarming for uncached films (fire-and-forget)
    def _prewarm(film):
        try:
            if not _cache.get('ade_detail_%s' % film.get('id', '')):
                _ade.get_film_detail(film['id'], film['slug'])
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=10)
    for film in films:
        pool.submit(_prewarm, film)
    pool.shutdown(wait=False)

    for film in films:
        ade_id = str(film.get('id', ''))
        # Merge cached detail into the stub — include artwork so og:image / scraped covers apply
        ade_detail = _cache.get('ade_detail_%s' % ade_id)
        d = dict(film)
        d['title'] = _html_lib.unescape(d.get('title', ''))
        if isinstance(ade_detail, dict):
            for k in ('description', 'year', 'studio', 'director', 'runtime', 'rating',
                      'categories', 'cast', 'trailer', 'thumb', 'fanart', 'backcover'):
                if ade_detail.get(k) and (not d.get(k) or k in ('thumb', 'fanart', 'backcover', 'trailer')):
                    d[k] = ade_detail[k]

        li = xbmcgui.ListItem(label=d['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(d['title'])
            tag.setPlot(d.get('description', ''))
            if str(d.get('year', '')).isdigit():
                tag.setYear(int(d['year']))
            if d.get('studio'):
                tag.setStudios([d['studio']])
            if d.get('categories'):
                tag.setGenres(d['categories'])
            if d.get('rating'):
                try:
                    tag.setRating(float(d['rating']))
                except Exception:
                    pass
            if d.get('runtime'):
                try:
                    tag.setDuration(int(d['runtime']) * 60)
                except Exception:
                    pass
            if d.get('trailer'):
                try:
                    tag.setTrailer(d['trailer'])
                except Exception:
                    pass
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': d['title'], 'plot': d.get('description', ''),
                                  'year': int(d['year']) if str(d.get('year','')).isdigit() else 0,
                                  'mpaa': 'Adults Only'})

        thumb    = d.get('thumb', '')
        # Use back cover as fanart/background when available; it's a different composition
        # that works better as a wide background than the front cover repeated
        backcover = d.get('backcover', '')
        fanart    = backcover if backcover else d.get('fanart', thumb)
        li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': fanart, 'banner': thumb})
        li.setProperty('IsPlayable', 'true')

        # Context menu: add or remove from adult favorites
        title_enc  = _up.quote(d['title'])
        thumb_enc  = _up.quote(thumb)
        fanart_enc = _up.quote(fanart)
        if _afav.is_favorite(ade_id):
            ctx_label  = 'Remove from Adult Favorites'
            ctx_action = ('RunPlugin(plugin://plugin.video.starfleet/'
                          '?action=adult_favorites_remove&ade_id=%s&title=%s)' % (ade_id, title_enc))
        else:
            ctx_label  = 'Add to Adult Favorites'
            ctx_action = ('RunPlugin(plugin://plugin.video.starfleet/'
                          '?action=adult_favorites_add&ade_id=%s&title=%s&thumb=%s&fanart=%s)'
                          % (ade_id, title_enc, thumb_enc, fanart_enc))
        li.addContextMenuItems([(ctx_label, ctx_action)])

        slug = d.get('slug', '')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_ade_play', 'ade_id': ade_id,
                       'ade_slug': slug, 'title': d['title']}),
            li, False
        )

    # Next page
    _next_page(handle, build_url, next_action, page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle, succeeded=True)


def adult_browse_new_releases(handle, build_url, page=1):
    """ADE new release movies — /new-release-porn-movies.html (16 pages)."""
    from resources.lib import ade as _ade
    dlg = _progress('Loading New Releases — page %d…' % page)
    films = _ade.browse_new_release_movies(page)
    dlg.close()
    _ade_browse_page(handle, build_url, films, '🆕 New Releases', page, 'adult_browse_new_releases')


def adult_browse_recently_added(handle, build_url, page=1):
    """ADE recently added videos — /new-addition-porn-videos.html (5000+ pages)."""
    from resources.lib import ade as _ade
    dlg = _progress('Loading Recently Added — page %d…' % page)
    films = _ade.browse_recently_added_videos(page)
    dlg.close()
    _ade_browse_page(handle, build_url, films, '🕐 Recently Added', page, 'adult_browse_recently_added')


def adult_browse_bestsellers(handle, build_url, page=1):
    """ADE best selling videos — /best-selling-porn-videos.html."""
    from resources.lib import ade as _ade
    dlg = _progress('Loading Best Sellers — page %d…' % page)
    films = _ade.browse_bestseller_videos(page)
    dlg.close()
    _ade_browse_page(handle, build_url, films, '🏆 Best Sellers', page, 'adult_browse_bestsellers')


def _no_source_path():
    import os, xbmcvfs
    d = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'no_source_ids.json')


def _load_no_source_ids():
    try:
        import json
        with open(_no_source_path(), 'r', encoding='utf-8') as f:
            return set(json.load(f))
    except Exception:
        return set()


def _mark_no_source(ade_id):
    xbmc.log('[Starfleet/NoSource] marking ade_id=%r' % ade_id, xbmc.LOGINFO)
    try:
        import json
        ids = _load_no_source_ids()
        ids.add(str(ade_id))
        p = _no_source_path()
        with open(p + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(list(ids), f)
        import os
        os.replace(p + '.tmp', p)
        xbmc.log('[Starfleet/NoSource] saved %d ids' % len(ids), xbmc.LOGINFO)
    except Exception:
        pass


def adult_ade_play_direct(ade_id, ade_slug='', title=''):
    """
    Play an ADE film from the home screen carousel without going through the plugin URL
    resolver.  Called directly (no handle) in a background thread so the home window
    keeps its doModal() alive and no Videos window is opened.
    """
    from resources.lib import ade as _ade, adult_streams as _as, torrent_sources as _ts
    import html as _html_lib
    title = _html_lib.unescape(title)
    xbmc.log('[Starfleet/ADE] play_direct ade_id=%r title=%r' % (ade_id, title), xbmc.LOGINFO)

    dlg = _progress('Grab a tissue… getting your load ready')

    trailer_url = _ade.trailer_url(ade_id)
    streams = []

    def _search_xxxclub():
        try:
            results = _ts.search_xxxclub(title, limit=8, media_type='adult')
            out = []
            for t in (results or []):
                qual = ''
                t_title = t.get('title', '')
                for kw in ('2160p', '4K', '1080p', '720p'):
                    if kw.lower() in t_title.lower():
                        qual = ' [%s]' % kw
                        break
                out.append({'label': '[XXXClub]%s %s [%s]' % (qual, t_title, t.get('size', '')),
                            'url': t.get('magnet', '')})
            return out
        except Exception:
            return []

    def _search_free():
        try:
            return _as.search_by_title(title) or []
        except Exception:
            return []

    pool = ThreadPoolExecutor(max_workers=3)
    f_xxxclub = pool.submit(_search_xxxclub)
    f_free    = pool.submit(_search_free)

    try:
        for item in (f_xxxclub.result(timeout=25) or []):
            if item.get('url'):
                streams.append(item)
    except Exception:
        pass

    try:
        for r in (f_free.result(timeout=30) or []):
            if r.get('url'):
                streams.append({'label': '[FREE] %s' % r.get('label', 'Stream'), 'url': r['url']})
    except Exception:
        pass

    pool.shutdown(wait=False)
    dlg.close()

    if not streams:
        _mark_no_source(ade_id)
        xbmcgui.Dialog().notification('Starfleet', 'No sources found for "%s"' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    if trailer_url:
        streams.insert(0, {'label': '[TRAILER] HD', 'url': trailer_url})

    if len(streams) == 1 and streams[0]['label'].startswith('[TRAILER]'):
        _mark_no_source(ade_id)
        xbmcgui.Dialog().notification('Starfleet', 'No adult sources for "%s" — skipping' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    if len(streams) == 1:
        chosen_url = streams[0]['url']
    else:
        idx = xbmcgui.Dialog().select('Source — %s' % title, [s['label'] for s in streams])
        if idx < 0:
            return
        chosen_url = streams[idx]['url']

    resolved = adult_stream_play(chosen_url, title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream',
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    xbmc.Player().play(resolved, li)


def adult_ade_play(handle, ade_id, ade_slug='', title=''):
    """Play an ADE film: trailer + XXXClub (debrid) + free streams in parallel."""
    from resources.lib import ade as _ade, adult_streams as _as, torrent_sources as _ts
    import html as _html_lib
    title = _html_lib.unescape(title)

    dlg = _progress('Grab a tissue… getting your load ready')

    trailer_url = _ade.trailer_url(ade_id)
    streams = []

    def _search_xxxclub():
        try:
            results = _ts.search_xxxclub(title, limit=8, media_type='adult')
            out = []
            for t in (results or []):
                qual = ''
                t_title = t.get('title', '')
                for kw in ('2160p', '4K', '1080p', '720p'):
                    if kw.lower() in t_title.lower():
                        qual = ' [%s]' % kw
                        break
                out.append({'label': '[XXXClub]%s %s [%s]' % (qual, t_title, t.get('size', '')),
                            'url': t.get('magnet', '')})
            return out
        except Exception:
            return []

    def _search_free():
        try:
            return _as.search_by_title(title) or []
        except Exception:
            return []

    pool = ThreadPoolExecutor(max_workers=3)
    f_xxxclub = pool.submit(_search_xxxclub)
    f_free    = pool.submit(_search_free)

    try:
        for item in (f_xxxclub.result(timeout=25) or []):
            if item.get('url'):
                streams.append(item)
    except Exception:
        pass

    try:
        for r in (f_free.result(timeout=30) or []):
            if r.get('url'):
                streams.append({'label': '[FREE] %s' % r.get('label', 'Stream'), 'url': r['url']})
    except Exception:
        pass

    pool.shutdown(wait=False)
    dlg.close()

    if not streams:
        # No sources and no trailer — nothing to play
        _mark_no_source(ade_id)
        xbmcgui.Dialog().notification('Starfleet', 'No sources found for "%s"' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if trailer_url:
        streams.insert(0, {'label': '[TRAILER] HD', 'url': trailer_url})

    if len(streams) == 1 and streams[0]['label'].startswith('[TRAILER]'):
        # Only trailer available — mark and skip
        _mark_no_source(ade_id)
        xbmcgui.Dialog().notification('Starfleet', 'No adult sources for "%s" — skipping' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen_url = streams[0]['url']
    else:
        idx = xbmcgui.Dialog().select('Source — %s' % title, [s['label'] for s in streams])
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen_url = streams[idx]['url']

    resolved = adult_stream_play(chosen_url, title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    xbmcplugin.setResolvedUrl(handle, True, li)


def adult_free_sites(handle, build_url):
    """Top-level menu listing all browsable free adult sites."""
    xbmcplugin.setPluginCategory(handle, 'Free Adult Sites')
    xbmcplugin.setContent(handle, 'files')

    _add_dir(handle, build_url, 'PandaMovies — Browse by Genre',
             {'action': 'adult_panda_genres'},
             plot='Browse adult movies on PandaMovies by genre category')

    _add_dir(handle, build_url, 'HQ Porner — Browse by Category',
             {'action': 'adult_hqp_categories'},
             plot='Browse HD adult movies on HQ Porner by category')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_panda_genres(handle, build_url):
    """List all genre categories from PandaMovies."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'PandaMovies — Genres')
    xbmcplugin.setContent(handle, 'files')

    dlg = _progress('Loading PandaMovies genres...')
    genres = _as.get_panda_genres()
    dlg.close()

    if not genres:
        xbmcgui.Dialog().notification('PandaMovies', 'No genres found', xbmcgui.NOTIFICATION_INFO)
        return

    for g in genres:
        _add_dir(handle, build_url, g['name'],
                 {'action': 'adult_panda_movies', 'genre_url': g['url'], 'page': 1,
                  'genre_name': g['name']},
                 plot='Browse %s movies on PandaMovies' % g['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def adult_panda_movies(handle, build_url, genre_url, genre_name='', page=1):
    """List movies from a PandaMovies genre page."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'PandaMovies — %s' % (genre_name or 'Movies'))
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading movies...')
    films = _as.get_panda_movies(genre_url, page=page)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('PandaMovies', 'No movies found', xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'mpaa': 'Adults Only'})
        if film.get('thumb'):
            li.setArt({'thumb': film['thumb'], 'poster': film['thumb'], 'fanart': film['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_panda_play', 'slug': film['slug'],
                       'film_url': film['url'], 'title': film['title']}),
            li, False
        )

    _next_page(handle, build_url, 'adult_panda_movies', page,
               extra={'genre_url': genre_url, 'genre_name': genre_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_panda_play(handle, slug, film_url, title=''):
    """Fetch PandaMovies detail, show stream picker, play via ResolveURL."""
    from resources.lib import adult_streams as _as

    dlg = _progress('Finding streams...')
    film = _as.get_panda_movie_detail(slug, film_url)
    dlg.close()

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification('PandaMovies', 'No streams found for: %s' % title,
                                       xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    film_title = title or film.get('title', '')
    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('PandaMovies', 'Could not resolve stream',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved, label=film_title)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie', 'mpaa': 'Adults Only'})
    if '.m3u8' in resolved.lower():
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in resolved.lower():
        li.setMimeType('video/mp4')
    xbmcplugin.setResolvedUrl(handle, True, li)


def adult_hqp_categories(handle, build_url):
    """List all categories from HQ Porner."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'HQ Porner — Categories')
    xbmcplugin.setContent(handle, 'files')

    dlg = _progress('Loading HQ Porner categories...')
    cats = _as.get_hqporner_categories()
    dlg.close()

    if not cats:
        xbmcgui.Dialog().notification('HQ Porner', 'No categories found', xbmcgui.NOTIFICATION_INFO)
        return

    for c in cats:
        _add_dir(handle, build_url, c['name'],
                 {'action': 'adult_hqp_movies', 'cat_url': c['url'], 'page': 1,
                  'cat_name': c['name']},
                 plot='Browse %s movies on HQ Porner' % c['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def adult_hqp_movies(handle, build_url, cat_url, cat_name='', page=1):
    """List movies from an HQ Porner category page."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'HQ Porner — %s' % (cat_name or 'Movies'))
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading movies...')
    films = _as.get_hqporner_movies(cat_url, page=page)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('HQ Porner', 'No movies found', xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'mpaa': 'Adults Only'})
        if film.get('thumb'):
            li.setArt({'thumb': film['thumb'], 'poster': film['thumb'], 'fanart': film['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_hqp_play', 'slug': film['slug'],
                       'film_url': film['url'], 'title': film['title']}),
            li, False
        )

    _next_page(handle, build_url, 'adult_hqp_movies', page,
               extra={'cat_url': cat_url, 'cat_name': cat_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_hqp_play(handle, slug, film_url, title=''):
    """Fetch HQ Porner detail, show stream picker, play."""
    from resources.lib import adult_streams as _as

    dlg = _progress('Finding streams...')
    film = _as.get_hqporner_movie_detail(slug, film_url)
    dlg.close()

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification('HQ Porner', 'No streams found for: %s' % title,
                                       xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    film_title = title or film.get('title', '')
    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('HQ Porner', 'Could not resolve stream',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved, label=film_title)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie', 'mpaa': 'Adults Only'})
    if '.m3u8' in resolved.lower():
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in resolved.lower():
        li.setMimeType('video/mp4')
    xbmcplugin.setResolvedUrl(handle, True, li)


# ── Adult Trailers ────────────────────────────────────────────────────────────

def adult_trailers(handle, build_url, page=1):
    """
    Show ADE new-release trailers as directly-playable items.
    Fetches up to 24 new releases, resolves trailer URLs in parallel,
    and shows only entries that have a playable trailer (YouTube/Vimeo/mp4).
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from resources.lib import ade as _ade

    xbmcplugin.setPluginCategory(handle, '🎬 Trailers')
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading trailers...')
    films = _ade.browse_new_releases(page=page)
    if dlg:
        dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No trailers found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    # Resolve trailer URLs in parallel — each film needs a detail fetch
    def _get_trailer(film):
        try:
            detail = _ade.get_film_detail(film['id'], film.get('slug', ''))
            trailer = detail.get('trailer', '') if detail else ''
            return film, trailer
        except Exception:
            return film, ''

    trailer_items = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(_get_trailer, f): f for f in films[:24]}
        for fut in as_completed(futures, timeout=20):
            try:
                film, trailer_url = fut.result()
                if trailer_url:
                    trailer_items.append((film, trailer_url))
            except Exception:
                pass

    if not trailer_items:
        xbmcgui.Dialog().notification('Adult', 'No trailers available right now',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    # Sort by film title
    trailer_items.sort(key=lambda x: x[0].get('title', '').lower())

    for film, trailer_url in trailer_items:
        title = film.get('title', 'Unknown')
        thumb = film.get('thumb', '') or film.get('fanart', '')
        year  = film.get('year', '')
        studio = film.get('studio', '')

        label = '[Trailer] %s' % title
        if year:
            label += ' (%s)' % year

        li = xbmcgui.ListItem(label=label)
        info = {'title': title, 'mediatype': 'movie'}
        if year:
            try:
                info['year'] = int(year)
            except (ValueError, TypeError):
                pass
        if studio:
            info['studio'] = studio
        li.setInfo('video', info)
        if thumb:
            li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_direct', 'stream_url': trailer_url, 'title': title}),
            li, False
        )

    if len(films) >= 24:
        _next_page(handle, build_url, 'adult_trailers', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Adult Movies Library ──────────────────────────────────────────────────────

_LIBRARY_CACHE_KEY = 'adult_library_full_v5'
_LIBRARY_CACHE_TTL = 2 * 3600  # 2 hours
_LIBRARY_PAGE_SIZE = 20


_ADE_DVD_CATS = [
    'milf', 'anal', 'lesbian', 'big-tits', 'teen', 'blonde',
    'brunette', 'hardcore', 'interracial', 'latina',
    'gangbang', 'creampie', 'squirting', 'threesome', 'orgy',
]
_OD_STUDIO_LIMIT  = 30   # max on-demand studios to fetch
_OD_CAT_LIMIT     = 20   # max on-demand categories to fetch


def _build_full_library():
    """
    Fetch films from all ADE sections (DVD: new, bestsellers, on-sale, blu-ray,
    used; DVD categories; On Demand: new, recently-added, bestsellers, top studios,
    top categories) plus AFDB new/popular.  Deduplicates, filters to known sources,
    sorts by year desc.  Cached 2 h.
    """
    from resources.lib import adult_streams as _as
    from resources.lib import ade as _ade

    def _safe(fn, *args):
        try:
            return fn(*args) or []
        except Exception:
            return []

    all_films_map  = {}
    seen_titles    = set()

    def _norm_title(t):
        import re as _re
        return _re.sub(r'[^a-z0-9]', '', (t or '').lower())

    def _add_films(films):
        for film in (films or []):
            fid = film.get('id', '')
            if not fid:
                fid = '%s_%s' % (film.get('source', 'ade'), film.get('slug', ''))
            if not fid or fid in all_films_map:
                continue
            nt = _norm_title(film.get('title', ''))
            if nt and nt in seen_titles:
                continue
            all_films_map[fid] = film
            if nt:
                seen_titles.add(nt)

    # ── Phase A: static section fetches (all in parallel) ────────────────────
    static_jobs = []

    # AFDB
    for pg in range(1, 4):
        static_jobs += [(afdb.get_new_releases, pg), (afdb.get_popular, pg)]

    # ADE DVD sections — pages 1-3 each
    dvd_fns = [
        _ade.browse_new_releases, _ade.browse_bestsellers,
        _ade.browse_on_sale,      _ade.browse_bluray,
        _ade.browse_used_dvd,
    ]
    for fn in dvd_fns:
        for pg in range(1, 4):
            static_jobs.append((fn, pg))

    # ADE DVD genre categories — page 1 only
    for cat in _ADE_DVD_CATS:
        static_jobs.append((_ade.browse_category, cat))

    # ADE On Demand — pages 1-3 each
    od_fns = [
        _ade.browse_od_new_releases,
        _ade.browse_od_recently_added,
        _ade.browse_od_bestsellers,
    ]
    for fn in od_fns:
        for pg in range(1, 4):
            static_jobs.append((fn, pg))

    with ThreadPoolExecutor(max_workers=20) as pool:
        futs = [pool.submit(_safe, fn, arg) for fn, arg in static_jobs]
        for fut in futs:
            try:
                _add_films(fut.result(timeout=25))
            except Exception:
                pass

    # ── Phase B: on-demand studios + categories (enumerate then fetch) ────────
    try:
        studios = _safe(_ade.get_od_studios)[:_OD_STUDIO_LIMIT]
        cats    = _safe(_ade.get_od_categories)[:_OD_CAT_LIMIT]
        sub_jobs = (
            [(_ade.browse_od_studio,   path) for _, path in studios] +
            [(_ade.browse_od_category, path) for _, path in cats]
        )
        with ThreadPoolExecutor(max_workers=16) as pool:
            futs2 = [pool.submit(_safe, fn, arg) for fn, arg in sub_jobs]
            for fut in futs2:
                try:
                    _add_films(fut.result(timeout=20))
                except Exception:
                    pass
    except Exception:
        pass

    # ── Phase C: free stream sites + panda + hqporner (bulk list-page stubs) ─
    try:
        from resources.lib import adult_streams as _as_bulk
        _add_films(_as_bulk.get_library_stubs_bulk(max_pages=15))
    except Exception as _e:
        xbmc.log('[Starfleet/Library] bulk stubs error: %s' % _e, xbmc.LOGWARNING)

    films = list(all_films_map.values())
    xbmc.log('[Starfleet/Library] _build_full_library: %d unique films before filter' % len(films), xbmc.LOGWARNING)

    _as.prewarm_title_index()
    films = _filter_films_with_sources(films)

    def _year_key(f):
        y = f.get('year', '') or ''
        try:
            return int(str(y)[:4]) if str(y).isdigit() else 0
        except Exception:
            return 0

    films.sort(key=_year_key, reverse=True)
    xbmc.log('[Starfleet/Library] _build_full_library: %d films after filter/sort' % len(films), xbmc.LOGWARNING)
    return films


def get_home_carousel_data(rows=3, per_row=20):
    """
    Return a dict of context row-sets for HomeWindow.
    Keys: 'default', 'movies', 'tv'
    Each value is a list of 3 row-lists (each list = up to per_row film dicts).
    """
    try:
        from resources.lib import metadata as _meta
        from concurrent.futures import ThreadPoolExecutor

        def _movie(m):
            return {
                'id': str(m.get('tmdb_id', '')), 'tmdb_id': str(m.get('tmdb_id', '')),
                'title': m.get('title', ''), 'thumb': m.get('thumb', ''),
                'fanart': m.get('fanart', m.get('thumb', '')),
                'plot': m.get('overview', ''), 'year': str(m.get('year', '')),
                'rating': str(m.get('rating', '')), 'source': 'tmdb', 'media_type': 'movie',
            }
        def _tv(m):
            return {
                'id': str(m.get('tmdb_id', '')), 'tmdb_id': str(m.get('tmdb_id', '')),
                'title': m.get('title', ''), 'thumb': m.get('thumb', ''),
                'fanart': m.get('fanart', m.get('thumb', '')),
                'plot': m.get('overview', ''), 'year': str(m.get('year', '')),
                'rating': str(m.get('rating', '')), 'source': 'tmdb', 'media_type': 'tv',
            }

        from resources.lib import sports_sources as _ss

        # Cap at 6 workers — 12 simultaneous threads OOM-crashes low-RAM devices (FireStick)
        ex = ThreadPoolExecutor(max_workers=6)
        f_new      = ex.submit(_meta.get_movies_new,        page=1)
        f_popular  = ex.submit(_meta.get_movies_popular,    page=1)
        f_top      = ex.submit(_meta.get_movies_top_rated,  page=1)
        f_upcoming = ex.submit(_meta.get_movies_upcoming,   page=1)
        f_trend    = ex.submit(_meta.get_movies_trending,   page=1)
        f_tv_pop   = ex.submit(_meta.get_tv_popular,        page=1)
        f_tv_top   = ex.submit(_meta.get_tv_top_rated,      page=1)
        f_tv_air   = ex.submit(_meta.get_tv_airing_today,   page=1)
        f_tv_onair = ex.submit(_meta.get_tv_on_the_air,     page=1)
        f_sp_soc   = ex.submit(_ss.get_todays_sport_events, 'soccer', 'Soccer',            per_row)
        f_sp_nba   = ex.submit(_ss.get_todays_sport_events, 'nba',    'Basketball',        per_row)
        f_sp_nhl   = ex.submit(_ss.get_todays_sport_events, 'nhl',    'Ice Hockey',        per_row)
        f_sp_mlb   = ex.submit(_ss.get_todays_sport_events, 'mlb',    'Baseball',          per_row)
        f_sp_nfl   = ex.submit(_ss.get_todays_sport_events, 'nfl',    'American Football', per_row)
        ex.shutdown(wait=False)

        try: new_films      = [_movie(m) for m in (f_new.result(timeout=12)      or [])][:per_row]
        except Exception: new_films = []
        try: pop_films      = [_movie(m) for m in (f_popular.result(timeout=12)  or [])][:per_row]
        except Exception: pop_films = []
        try: top_films      = [_movie(m) for m in (f_top.result(timeout=12)      or [])][:per_row]
        except Exception: top_films = []
        try: upcoming_films = [_movie(m) for m in (f_upcoming.result(timeout=12) or [])][:per_row]
        except Exception: upcoming_films = []
        try: trend_films    = [_movie(m) for m in (f_trend.result(timeout=12)    or [])][:per_row]
        except Exception: trend_films = []
        try: tv_pop         = [_tv(m)   for m in (f_tv_pop.result(timeout=12)    or [])][:per_row]
        except Exception: tv_pop = []
        try: tv_top         = [_tv(m)   for m in (f_tv_top.result(timeout=12)    or [])][:per_row]
        except Exception: tv_top = []
        try: tv_air         = [_tv(m)   for m in (f_tv_air.result(timeout=12)    or [])][:per_row]
        except Exception: tv_air = []
        try: tv_onair       = [_tv(m)   for m in (f_tv_onair.result(timeout=12)  or [])][:per_row]
        except Exception: tv_onair = []

        try: sp_soc  = f_sp_soc.result(timeout=20) or []
        except Exception: sp_soc = []
        try: sp_nba  = f_sp_nba.result(timeout=20) or []
        except Exception: sp_nba = []
        try: sp_nhl  = f_sp_nhl.result(timeout=20) or []
        except Exception: sp_nhl = []
        try: sp_mlb  = f_sp_mlb.result(timeout=20) or []
        except Exception: sp_mlb = []
        try: sp_nfl  = f_sp_nfl.result(timeout=20) or []
        except Exception: sp_nfl = []
        sp_row2 = (sp_nba + sp_nhl)[:per_row]
        sp_row3 = (sp_mlb + sp_nfl)[:per_row]

        def _fav_carousel(media_type):
            try:
                from resources.lib import favorites as _fav
                items = _fav.get_movies() if media_type == 'movie' else _fav.get_tv()
                return [{'id': str(f.get('tmdb_id', '')), 'tmdb_id': str(f.get('tmdb_id', '')),
                         'title': f.get('title', ''), 'thumb': f.get('thumb', ''),
                         'fanart': f.get('fanart', ''), 'source': 'tmdb',
                         'media_type': media_type} for f in (items or [])][:per_row]
            except Exception:
                return []

        xbmc.log('[Starfleet/Home] TMDB rows: %d new / %d popular / %d top / %d tv_pop / %d tv_top / %d airing' % (
            len(new_films), len(pop_films), len(top_films), len(tv_pop), len(tv_top), len(tv_air)), xbmc.LOGINFO)
        xbmc.log('[Starfleet/Home] Sports rows: soc=%d nba=%d nhl=%d mlb=%d nfl=%d' % (
            len(sp_soc), len(sp_nba), len(sp_nhl), len(sp_mlb), len(sp_nfl)), xbmc.LOGINFO)

        # Adult rows — only fetch if adult section is enabled (saves RAM + network on FireStick)
        ade_new_films = ade_recent_films = ade_fav_films = []
        _adult_on = False
        try:
            _adult_on = xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
        except Exception:
            pass
        try:
            if not _adult_on:
                raise Exception('adult disabled')
            from resources.lib import ade as _ade, adult_favorites as _af

            def _ade_item(film):
                return {
                    'id': str(film.get('id', '')), 'ade_id': str(film.get('id', '')),
                    'ade_slug': film.get('slug', ''),
                    'title': film.get('title', ''), 'thumb': film.get('thumb', ''),
                    'fanart': film.get('fanart', film.get('thumb', '')),
                    'source': 'ade', 'media_type': 'movie',
                }

            _ade_pool = ThreadPoolExecutor(max_workers=2)
            f_ade_new    = _ade_pool.submit(_ade.browse_new_release_movies,    1)
            f_ade_recent = _ade_pool.submit(_ade.browse_recently_added_videos, 1)
            _ade_pool.shutdown(wait=False)

            try: ade_new_films    = [_ade_item(m) for m in (f_ade_new.result(timeout=8)    or [])][:per_row]
            except Exception: ade_new_films = []
            try: ade_recent_films = [_ade_item(m) for m in (f_ade_recent.result(timeout=8) or [])][:per_row]
            except Exception: ade_recent_films = []

            # Filter out ADE items previously found to have no adult sources
            _no_src = _load_no_source_ids()
            if _no_src:
                ade_new_films    = [m for m in ade_new_films    if str(m.get('ade_id', '')) not in _no_src]
                ade_recent_films = [m for m in ade_recent_films if str(m.get('ade_id', '')) not in _no_src]

            ade_fav_films = [{'id': f['ade_id'], 'ade_id': f['ade_id'], 'ade_slug': '',
                              'title': f.get('title', ''), 'thumb': f.get('thumb', ''),
                              'fanart': f.get('fanart', f.get('thumb', '')),
                              'source': 'ade', 'media_type': 'movie'}
                             for f in _af.get_all()][:per_row]
        except Exception as _ae:
            xbmc.log('[Starfleet/Home] adult rows error (non-fatal): %s' % _ae, xbmc.LOGWARNING)

        return {
            'default': [new_films,  tv_pop,    trend_films,    pop_films],
            'movies':  [new_films,  pop_films,  top_films,     upcoming_films],
            'tv':      [tv_pop,     tv_top,     tv_air,        tv_onair],
            'sports':  [sp_soc,     sp_row2,    sp_row3,       []],
            'live':    [_fav_carousel('movie'), _fav_carousel('tv'), [], []],
            'adult':   [ade_new_films, ade_recent_films, ade_fav_films, []],
        }
    except Exception as _e:
        xbmc.log('[Starfleet/Home] get_home_carousel_data error: %s' % _e, xbmc.LOGWARNING)
        empty = [[], [], [], []]
        return {'default': empty, 'movies': empty, 'tv': empty, 'sports': empty, 'live': empty, 'adult': empty}


def adult_movies_library(handle, build_url, page=1):
    """
    Browse adult movies with local pagination.
    All films are fetched once and cached; each page call slices the cached list.
    """
    import re as _re
    from resources.lib import adult_streams as _as

    xbmcplugin.setPluginCategory(handle, 'Adult Movies — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    # ── Load full library (from cache on warm visits) ─────────────────────────
    all_films = _cache.get(_LIBRARY_CACHE_KEY) if _LIBRARY_CACHE_KEY else None
    if all_films is None:
        dlg = xbmcgui.DialogProgress()
        dlg.create('Starfleet', 'Populating list....grab a tissue')
        dlg.update(10, 'Fetching movie catalogue...')
        all_films = _build_full_library()
        dlg.update(80, 'Prewarming metadata...')
        # Prewarm detail for first 36 films in background
        CHUNK_SIZE = 12
        cold_films = all_films[:36]

        def _prewarm_film(film):
            fid   = film.get('id', '')
            fslug = film.get('slug', '')
            title = film.get('title', '')
            if fid and _need_fetch('afdb_film_%s' % fid):
                try:
                    afdb.get_film_detail(fid, fslug)
                except Exception:
                    pass
            if title:
                _ade_ck = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', title.lower())[:80]
                ade_cached = _cache.get(_ade_ck)
                if ade_cached is None:
                    try:
                        from resources.lib import ade as _ade
                        ade_meta = _ade.search_by_title(title)
                        if ade_meta and ade_meta.get('id'):
                            _ade.get_film_detail(ade_meta['id'], ade_meta.get('slug', ''))
                    except Exception:
                        pass

        for chunk_start in range(0, len(cold_films), CHUNK_SIZE):
            if dlg.iscanceled():
                break
            chunk = cold_films[chunk_start: chunk_start + CHUNK_SIZE]
            with ThreadPoolExecutor(max_workers=len(chunk)) as pool:
                futs_chunk = [pool.submit(_prewarm_film, f) for f in chunk]
                for fut in futs_chunk:
                    try:
                        fut.result(timeout=30)
                    except Exception:
                        pass
            pct = 80 + int(18 * (chunk_start + CHUNK_SIZE) / max(len(cold_films), 1))
            dlg.update(min(pct, 98), 'Metadata prewarmed: %d / %d' % (
                min(chunk_start + CHUNK_SIZE, len(cold_films)), len(cold_films)))

        try:
            _cache.set(_LIBRARY_CACHE_KEY, all_films, _LIBRARY_CACHE_TTL)
        except Exception:
            pass
        dlg.close()

        # Background: ADE DVD-cover enrichment for all films beyond the first 36.
        # Runs silently so the UI is responsive; results land in ade_search_* cache.
        _bg_enrich_films = all_films[36:]
        if _bg_enrich_films:
            import threading as _thr
            def _bg_ade_enrich(films):
                import re as _re2
                try:
                    from resources.lib import ade as _ade2
                except Exception:
                    return
                for f in films:
                    title = f.get('title', '')
                    if not title:
                        continue
                    ck = 'ade_search_%s' % _re2.sub(r'[^a-z0-9]', '_', title.lower())[:80]
                    if _cache.get(ck) is not None:
                        continue
                    try:
                        meta = _ade2.search_by_title(title)
                        if meta and meta.get('id'):
                            _ade2.get_film_detail(meta['id'], meta.get('slug', ''))
                    except Exception:
                        pass
            _thr.Thread(target=_bg_ade_enrich, args=(_bg_enrich_films,), daemon=True).start()

    # ── Slice for the requested page ──────────────────────────────────────────
    start = (page - 1) * _LIBRARY_PAGE_SIZE
    end   = start + _LIBRARY_PAGE_SIZE
    page_films = all_films[start:end]

    xbmc.log('[Starfleet/Library] PAGE=%d showing films[%d:%d] of %d total. First 3: %s' % (
        page, start, end, len(all_films), [f.get('title','?') for f in page_films[:3]]), xbmc.LOGWARNING)

    if not page_films and page == 1:
        xbmcgui.Dialog().notification(
            'Adult', 'Sources still loading — check back in a moment',
            xbmcgui.NOTIFICATION_INFO, 4000)

    for film in page_films:
        _add_film(handle, build_url, film)

    if end < len(all_films):
        _next_page(handle, build_url, 'adult_movies_library', page)

    # Background: ADE cover enrichment for current page + stream source search
    import threading
    def _bg_page_enrich():
        import re as _re2
        try:
            from resources.lib import ade as _ade2
        except Exception:
            return
        for f in page_films:
            title = f.get('title', '')
            if not title:
                continue
            ck = 'ade_search_%s' % _re2.sub(r'[^a-z0-9]', '_', title.lower())[:80]
            if _cache.get(ck) is not None:
                continue
            try:
                meta = _ade2.search_by_title(title)
                if meta and meta.get('id'):
                    _ade2.get_film_detail(meta['id'], meta.get('slug', ''))
            except Exception:
                pass

    threading.Thread(target=_bg_page_enrich, daemon=True).start()
    _prewarm_actor_details(page_films)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── New Releases ──────────────────────────────────────────────────────────────

def afdb_new(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🆕 New Releases')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_new_%d' % page)
    dlg  = _progress('Loading new releases...') if cold else None
    films = afdb.get_new_releases(page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    _prewarm_film_details(films)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_new', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Most Popular ──────────────────────────────────────────────────────────────

def afdb_popular(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🏆 Most Popular')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_popular_%d' % page)
    dlg  = _progress('Loading popular films...') if cold else None
    films = afdb.get_popular(page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_popular', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Categories ────────────────────────────────────────────────────────────────

def afdb_categories(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎭 Categories')
    xbmcplugin.setContent(handle, 'files')

    for cat in sorted(afdb.CATEGORIES):
        _add_dir(handle, build_url, cat,
                 {'action': 'afdb_by_category', 'category': cat, 'page': 1},
                 plot='Browse %s films' % cat)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def afdb_by_category(handle, build_url, category, page=1):
    xbmcplugin.setPluginCategory(handle, '🎭 %s' % category)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_cat_%s_%d' % (category.replace(' ', '_'), page))
    dlg  = _progress('Loading %s...' % category) if cold else None
    films = afdb.get_by_category(category, page=page)
    if dlg: dlg.close()

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_category', page,
                   extra={'category': category})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Studios ───────────────────────────────────────────────────────────────────

def afdb_studios(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '🎬 Studios — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_studios', 'letter': l})

    cold = _need_fetch('afdb_studios_%s' % letter)
    dlg  = _progress('Loading studios...') if cold else None
    studios = afdb.get_studios(letter)
    if dlg: dlg.close()

    for s in studios:
        _add_dir(handle, build_url, s['name'],
                 {'action': 'afdb_by_studio', 'studio': s['slug'],
                  'studio_name': s['name'], 'page': 1},
                 plot='Films from %s' % s['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_by_studio(handle, build_url, studio, studio_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '🎬 %s' % (studio_name or studio))
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_studio_%s_%d' % (studio.replace(' ', '_'), page))
    dlg  = _progress('Loading studio films...') if cold else None
    films = afdb.get_by_studio(studio, page=page)
    if dlg: dlg.close()

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_studio', page,
                   extra={'studio': studio, 'studio_name': studio_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Actors ────────────────────────────────────────────────────────────────────

def afdb_actors(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '👤 Actors — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_actors', 'letter': l})

    cold = _need_fetch('afdb_actors_%s' % letter)
    dlg  = _progress('Loading actors...') if cold else None
    actors = afdb.get_actors(letter)
    if dlg: dlg.close()

    for actor in actors:
        li = xbmcgui.ListItem(label=actor['name'])
        li.setInfo('video', {'title': actor['name']})
        li.setArt({
            'thumb':  actor.get('photo', ''),
            'icon':   actor.get('photo', ''),
            'poster': actor.get('photo', ''),
            'fanart': actor.get('photo_large', actor.get('photo', '')),
        })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'afdb_actor_detail',
                       'actor_id': actor['id'],
                       'actor_slug': actor['slug'],
                       'actor_name': actor['name']}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_detail(handle, build_url, actor_id, actor_slug, actor_name=''):
    """
    Show actor profile page:
    - Photo as full-screen poster/fanart
    - Bio, measurements, nationality, hair, eyes, ethnicity
    - Filmography link
    """
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'files')

    cold = afdb._cache.get('afdb_actor_detail_%s' % actor_id) is None
    dlg  = _progress('Loading %s...' % actor_name) if cold else None
    actor = afdb.get_actor_detail(actor_id, actor_slug)
    if dlg: dlg.close()

    # Build rich plot string from all available fields
    plot_parts = []
    if actor.get('birthday'):
        plot_parts.append('Born: %s' % actor['birthday'])
    if actor.get('nationality'):
        plot_parts.append('Nationality: %s' % actor['nationality'])
    if actor.get('ethnicity'):
        plot_parts.append('Ethnicity: %s' % actor['ethnicity'])
    if actor.get('measurements'):
        plot_parts.append('Measurements: %s' % actor['measurements'])
    if actor.get('height'):
        plot_parts.append('Height: %s' % actor['height'])
    if actor.get('weight'):
        plot_parts.append('Weight: %s' % actor['weight'])
    if actor.get('hair'):
        plot_parts.append('Hair: %s' % actor['hair'])
    if actor.get('eyes'):
        plot_parts.append('Eyes: %s' % actor['eyes'])
    if actor.get('bio'):
        plot_parts.append('\n%s' % actor['bio'])
    plot = '\n'.join(plot_parts)

    # Profile card item
    li = xbmcgui.ListItem(label='ℹ️  %s — Profile' % actor['name'])
    li.setInfo('video', {
        'title': actor['name'],
        'plot':  plot,
    })
    li.setArt({
        'thumb':   actor.get('photo', ''),
        'poster':  actor.get('photo', ''),
        'fanart':  actor.get('photo_large', actor.get('photo', '')),
        'banner':  actor.get('photo_large', actor.get('photo', '')),
    })
    xbmcplugin.addDirectoryItem(handle, build_url({'action': 'afdb_actor_detail',
                                                    'actor_id': actor_id,
                                                    'actor_slug': actor_slug,
                                                    'actor_name': actor['name']}),
                                li, False)

    # Filmography link
    _add_dir(handle, build_url,
             label='🎬  Filmography (%s films)' % (actor.get('filmcount') or ''),
             params={'action': 'afdb_actor_films',
                     'actor_id': actor_id,
                     'actor_slug': actor_slug,
                     'actor_name': actor['name'],
                     'page': 1},
             thumb=actor.get('photo', ''),
             plot='Browse all films featuring %s' % actor['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_films(handle, build_url, actor_id, actor_slug,
                     actor_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_actor_films_%s_%d' % (actor_id, page))
    dlg  = _progress('Loading films...') if cold else None
    films = afdb.get_by_actor(actor_id, actor_slug, page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No films found for %s' % actor_name,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_actor_films', page,
                   extra={'actor_id': actor_id, 'actor_slug': actor_slug,
                          'actor_name': actor_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Search ────────────────────────────────────────────────────────────────────

def afdb_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search Adult Film Database')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '🔍 Search: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    dlg   = _progress('Searching...')
    films = afdb.search_films(query)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        _add_film(handle, build_url, film)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Unified Search ────────────────────────────────────────────────────────────

def adult_search_unified(handle, build_url):
    """
    Single search box for: movie title, performer name, or scene type/tag.
    - If query matches an AFDB category → show films for that category
    - If query matches performer names → show matching actor filmographies
    - Otherwise → search AFDB titles + free stream sites by title
    """
    kb = xbmc.Keyboard('', 'Search movies, performers, scenes...')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, 'Search: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    query_lower = query.lower()

    # Check if query matches an AFDB category (scene type / tag search)
    category_match = None
    try:
        for cat in afdb.CATEGORIES:
            if query_lower in cat.lower() or cat.lower() in query_lower:
                category_match = cat
                break
    except Exception:
        pass

    if category_match:
        dlg = _progress('Searching "%s"...' % category_match)
        films = afdb.get_by_category(category_match, page=1)
        dlg.close()
        films = _filter_films_with_sources(films)
        for film in films:
            _add_film(handle, build_url, film)
        if films:
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
            return

    # Performer / actor search — search AFDB actor pages by walking A-Z
    # (AFDB has no actor search API; we skip this for now and rely on title search)
    actor_films = []

    # Title search across AFDB + free stream sites
    dlg = _progress('Searching "%s"...' % query)
    afdb_films = []
    try:
        afdb_films = afdb.search_films(query)
    except Exception:
        pass

    # Merge: actor films + AFDB title results (deduplicated by id)
    seen_ids = set()
    all_films = []
    for film in (actor_films + afdb_films):
        fid = film.get('id', '')
        if fid and fid not in seen_ids:
            seen_ids.add(fid)
            all_films.append(film)
    dlg.close()

    # If no AFDB results, search XXXClub torrents + free stream sites directly
    if not all_films:
        from resources.lib import adult_streams as _as
        from resources.lib import torrent_sources as _ts
        dlg = _progress('Searching "%s"...' % query)
        torrent_results = _ts.search_xxxclub(query, limit=20, media_type='adult')
        stream_results = _as.search_by_title(query)
        dlg.close()

        # Show XXXClub torrent results as individual playable items
        for t in torrent_results:
            label = '[COLOR cyan][XC][/COLOR] %s  [COLOR grey][%s][/COLOR]' % (
                t['title'], t.get('size', ''))
            li = xbmcgui.ListItem(label=label)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(t['title'])
                tag.setPlot('[XXXClub] Seeds: %d' % t.get('seeds', 0))
                tag.setMpaa('Adults Only')
            except Exception:
                li.setInfo('video', {'title': t['title'], 'mpaa': 'Adults Only'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(
                handle,
                build_url({'action': 'play_xxxclub_magnet',
                           'magnet': t['magnet'],
                           'title': t['title']}),
                li, False
            )

        # Show free stream results as individual playable items
        for s in stream_results:
            lbl = s.get('label') or query
            li = xbmcgui.ListItem(label='[COLOR yellow][Stream][/COLOR] %s' % lbl)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(lbl)
                tag.setMpaa('Adults Only')
            except Exception:
                li.setInfo('video', {'title': lbl, 'mpaa': 'Adults Only'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, s['url'], li, False)

        if torrent_results or stream_results:
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
            return

        xbmcgui.Dialog().notification('Adult', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
        return

    all_films = _filter_films_with_sources(all_films)
    for film in all_films:
        _add_film(handle, build_url, film)

    _prewarm_film_details(all_films)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Film Detail / Play ────────────────────────────────────────────────────────

def afdb_detail(handle, build_url, film_id, film_slug, film_title=''):
    """Legacy detail view — redirects to afdb_play_search."""
    afdb_play_search(handle, film_id, film_slug, film_title)


def afdb_play_search(handle, film_id, film_slug, film_title=''):
    """
    Browse AFDB for metadata → search ALL scrapers in parallel
    (trailer, personal, debrid, free streams, XXXClub, all torrent sources)
    → source picker dialog → play via ResolveURL.

    Source order: Trailer, personal, debrid [yellow], free streams,
    XXXClub [cyan], general torrents [orange].
    """
    from resources.lib import adult_streams as _as
    from resources.lib import ade as _ade
    from resources.lib import torrent_sources as _ts

    # Resolve title
    title = film_title
    year  = None
    if not title:
        cold = _need_fetch('afdb_film_%s' % film_id)
        dlg  = _progress('Loading...') if cold else None
        film_detail = afdb.get_film_detail(film_id, film_slug)
        if dlg: dlg.close()
        title = film_detail.get('title', '')
        year  = film_detail.get('year') or None
        if not film_detail.get('description') and title:
            try:
                _ade.search_by_title(title)
            except Exception:
                pass

    if not title:
        xbmcgui.Dialog().notification('Starfleet', 'Film title not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet', 'Grab a tissue, sources loading...')

    from concurrent.futures import ThreadPoolExecutor as _TPE

    def _free():
        return _as.search_by_title(title)

    def _personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(title, year=year, media_type='adult')
        except Exception:
            return []

    def _debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            raw = _dt.get_debrid_streams(title, year=year, media_type='adult')
            for s in raw:
                s['label'] = '[COLOR yellow]%s[/COLOR]' % s['label']
                s['is_debrid'] = True
            return raw
        except Exception:
            return []

    def _trailer():
        try:
            url = _ade.get_trailer_url(title)
            if url:
                return [{'label': '[Trailer]', 'url': url, 'is_trailer': True}]
        except Exception:
            pass
        return []

    def _xxxclub():
        try:
            results = _ts.search_xxxclub(title, limit=5, media_type='adult')
            out = []
            for t in results:
                qual = ''
                for tag in ('2160p', '4K', '1080p', '720p', '480p'):
                    if tag.lower() in t.get('title', '').lower():
                        qual = '  [COLOR lime][%s][/COLOR]' % tag
                        break
                seeds = ('  [COLOR grey]↑%d[/COLOR]' % t['seeds']) if t.get('seeds') else ''
                size  = ('  [COLOR grey][%s][/COLOR]' % t['size']) if t.get('size') else ''
                lbl = '[COLOR cyan][XXXClub][/COLOR] %s%s%s%s' % (
                    t.get('title', title), qual, size, seeds)
                out.append({'label': lbl, 'url': t['magnet']})
            return out
        except Exception:
            return []

    def _torrents():
        try:
            results = _ts.search_all(title, year=year, media_type='adult')
            out = []
            for t in results:
                qual = ''
                for tag in ('2160p', '4K', '1080p', '720p', '480p'):
                    if tag.lower() in t.get('title', '').lower():
                        qual = '  [COLOR lime][%s][/COLOR]' % tag
                        break
                seeds = ('  [COLOR grey]↑%d[/COLOR]' % t['seeds']) if t.get('seeds') else ''
                size  = ('  [COLOR grey][%s][/COLOR]' % t['size']) if t.get('size') else ''
                src   = t.get('source', '')
                src_tag = ('  [COLOR darkgrey]%s[/COLOR]' % src) if src else ''
                url   = t.get('magnet', '')
                if url:
                    lbl = '[COLOR orange][Torrent][/COLOR] %s%s%s%s%s' % (
                        t.get('title', title), qual, size, seeds, src_tag)
                    out.append({'label': lbl, 'url': url})
            return out
        except Exception:
            return []

    trailers = personals = debrids = frees = xxxclub = torrents = []
    try:
        with _TPE(max_workers=6) as _pool:
            _f_trailer  = _pool.submit(_trailer)
            _f_personal = _pool.submit(_personal)
            _f_debrid   = _pool.submit(_debrid)
            _f_free     = _pool.submit(_free)
            _f_xxxclub  = _pool.submit(_xxxclub)
            _f_torrents = _pool.submit(_torrents)
            try: trailers  = _f_trailer.result(timeout=15)
            except Exception: pass
            try: personals = _f_personal.result(timeout=15)
            except Exception: pass
            try: debrids   = _f_debrid.result(timeout=25)
            except Exception: pass
            try: frees     = _f_free.result(timeout=30)
            except Exception: pass
            try: xxxclub   = _f_xxxclub.result(timeout=25)
            except Exception: pass
            try: torrents  = _f_torrents.result(timeout=35)
            except Exception: pass
    finally:
        dlg.close()

    # Order: trailer, personal, debrid, free, XXXClub, torrents
    streams = trailers + personals + debrids + frees + xxxclub + torrents

    if not streams:
        xbmcgui.Dialog().notification(
            'Starfleet', 'No streams found for: %s' % title,
            xbmcgui.NOTIFICATION_WARNING, 5000
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = ['%s — %s' % (s['label'], s.get('url', '')[:40]) if s.get('is_trailer')
                   else s['label']
                   for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    elif '.mkv' in _url_lc:
        li.setMimeType('video/x-matroska')
    xbmcplugin.setResolvedUrl(handle, True, li)


_THUMB_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
)

def _thumb_ref(thumb, film_url=''):
    """Append Referer + User-Agent headers so Kodi can fetch images from protected CDNs."""
    if not thumb or '|' in thumb:
        return thumb
    import re as _re
    m = _re.match(r'(https?://[^/]+)', film_url or thumb)
    ref = (m.group(1) + '/') if m else ''
    if ref:
        return '%s|Referer=%s&User-Agent=%s' % (thumb, ref, _THUMB_UA)
    return '%s|User-Agent=%s' % (thumb, _THUMB_UA)


def _ade_enrich_background(films):
    """
    Fire-and-forget: fetch ADE metadata for free-stream films that have
    no thumbnail or description, so the next page load shows enriched data.
    Capped at 10 films per call to avoid hammering ADE.
    """
    from resources.lib import ade as _ade
    from concurrent.futures import ThreadPoolExecutor

    cold = [f for f in films
            if not f.get('thumb') or not f.get('description')][:10]
    if not cold:
        return

    def _fetch(film):
        try:
            _ade.search_by_title(film['title'])
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=4)
    for f in cold:
        pool.submit(_fetch, f)
    pool.shutdown(wait=False)


def adult_streams(handle, build_url, page=1, xclub_cursor=''):
    """
    Browse adult movies. Shows XXXClub torrents (fast) plus a Free Streams folder.
    xclub_cursor: raw xxxclub.to pagination cursor (empty = first page).
    """
    xbmcplugin.setPluginCategory(handle, 'Adult Movies — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    from resources.lib import torrent_sources as _ts
    xxxclub_torrents = []
    next_site_cursor = ''
    try:
        xxxclub_torrents, next_site_cursor = _ts.browse_xxxclub(cursor=xclub_cursor or '1')
        xbmc.log('[Starfleet] XXXClub page=%d cursor=%s returned %d items' % (page, xclub_cursor or '1', len(xxxclub_torrents)), xbmc.LOGWARNING)
        xxxclub_torrents.sort(key=lambda t: _extract_year(t.get('title', '')), reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet] XXXClub failed: %s' % e, xbmc.LOGWARNING)
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    # ── XXXClub torrents ──────────────────────────────────────────────────────
    for t in xxxclub_torrents:
        yr = _extract_year(t.get('title', ''))
        yr_tag = '  [COLOR grey](%d)[/COLOR]' % yr if yr else ''
        label = '[COLOR cyan][XC][/COLOR] %s%s  [COLOR grey][%s][/COLOR]' % (t['title'], yr_tag, t['size'])
        li = xbmcgui.ListItem(label=label)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(t['title'])
            tag.setPlot('[XXXClub] %s' % t['size'])
            tag.setMpaa('Adults Only')
            if yr:
                tag.setYear(yr)
        except Exception:
            info = {'title': t['title'], 'plot': '[XXXClub] %s' % t['size'], 'mpaa': 'Adults Only'}
            if yr:
                info['year'] = yr
            li.setInfo('video', info)
        if t.get('thumb'):
            li.setArt({'thumb': t['thumb'], 'poster': t['thumb'], 'icon': t['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_xxxclub_magnet',
                       'magnet': t['magnet'],
                       'title':  t['title']}),
            li, False
        )

    # Next page: pass the real xxxclub cursor so page 2 needs only one HTTP request
    if next_site_cursor:
        _next_page(handle, build_url, 'adult_streams', page,
                   extra={'xclub_cursor': next_site_cursor})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_free_streams(handle, build_url, page=1):
    """
    Browse free adult stream sources (loaded on-demand to avoid UI freeze).
    """
    from resources.lib import adult_streams as _as
    import re as _re

    xbmcplugin.setPluginCategory(handle, 'Free Streams — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading free streams...')
    films = _as.get_all_stream_stubs(page=page)
    dlg.close()

    for film in (films or []):
        ade_key = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', film['title'].lower())[:80]
        ade_meta = _cache.get(ade_key)
        if ade_meta and isinstance(ade_meta, dict):
            if not film.get('thumb') and ade_meta.get('thumb'):
                film['thumb'] = ade_meta['thumb']
            if not film.get('description') and ade_meta.get('description'):
                film['description'] = ade_meta['description']

        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setPlot(film.get('description', ''))
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'plot': film.get('description', ''), 'mpaa': 'Adults Only'})

        if film.get('thumb'):
            thumb = _thumb_ref(film['thumb'], film.get('url', ''))
            li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb, 'icon': thumb})

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_stream_sources',
                       'film_id': film['id'],
                       'film_url': film.get('url', ''),
                       'title': film['title']}),
            li, False
        )

    if films:
        _ade_enrich_background(films)

    _next_page(handle, build_url, 'adult_free_streams', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_stream_sources(handle, build_url, film_id, title='', film_url=''):
    """
    Show a dialog listing all stream sources for a film, then play the chosen one.
    Always searches debrid/torrents regardless of whether free streams are cached.
    Fetches the detail page on demand if not cached (stub-based listing).
    """
    from resources.lib import adult_streams as _as
    from concurrent.futures import ThreadPoolExecutor

    # 1. Try merged cache (set by get_all_streams legacy path)
    film = _cache.get('fstreams_merged_%s' % film_id)

    # 2. Try per-source detail cache
    if not film:
        _PREFIX_CACHE = {
            'freeo_':   'fstreams_freeo_detail_%s',
            'xxxms_':   'fstreams_xxxms_detail_%s',
            'wpw_':     'fstreams_wpw_detail_%s',
            'wpf_':     'fstreams_wpf_detail_%s',
            'spn_':     'fstreams_spn_detail_%s',
            'xmovix_':  'fstreams_xmovix_detail_%s',
        }
        for prefix, ck_tpl in _PREFIX_CACHE.items():
            if film_id.startswith(prefix):
                slug = film_id[len(prefix):]
                film = _cache.get(ck_tpl % slug)
                break

    # 3. Fetch detail page on demand (stub listing path — no detail cached yet)
    if not film or not film.get('streams'):
        try:
            fetched = _as.fetch_film_detail_on_demand(film_id, film_url)
            if fetched and fetched.get('streams'):
                film = fetched
        except Exception as e:
            xbmc.log('[Starfleet/Streams] on-demand detail fetch error: %s' % e, xbmc.LOGWARNING)

    film_title  = title or (film.get('title', '') if film else '')
    cached_streams = (film.get('streams') or []) if film else []

    if not film_title:
        xbmcgui.Dialog().notification('Starfleet', 'Film title not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    def _personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(film_title, media_type='adult')
        except Exception:
            return []

    def _debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            raw = _dt.get_debrid_streams(film_title, media_type='adult')
            for s in raw:
                s['label'] = '[COLOR yellow]%s[/COLOR]' % s['label']
            return raw
        except Exception as e:
            xbmc.log('[Starfleet/Streams] debrid error: %s' % e, xbmc.LOGWARNING)
            return []

    def _site_search():
        # Always search the free streaming sites by title so AFDB browse/search
        # results also get free scraper streams, not just debrid results.
        if cached_streams:
            return cached_streams  # already have them from scraper cache
        try:
            return _as.search_by_title(film_title)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] site search error: %s' % e, xbmc.LOGWARNING)
            return []

    with ThreadPoolExecutor(max_workers=3) as pool:
        f_personal = pool.submit(_personal)
        f_debrid   = pool.submit(_debrid)
        f_sites    = pool.submit(_site_search)
        try:
            personals = f_personal.result(timeout=15)
        except Exception:
            personals = []
        try:
            debrids = f_debrid.result(timeout=40)
        except Exception:
            debrids = []
        try:
            site_free = f_sites.result(timeout=40)
        except Exception:
            site_free = []

    streams = personals + debrids + site_free

    if not streams:
        xbmcgui.Dialog().notification('Starfleet', 'No streams found for: %s' % film_title,
                                       xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    elif '.mkv' in _url_lc:
        li.setMimeType('video/x-matroska')
    xbmcplugin.setResolvedUrl(handle, True, li)


def adult_stream_play(stream_url, title=''):
    """Resolve a stream URL and return the playable URL, or '' on failure.
    Callers pass the returned URL to setResolvedUrl(handle, True, ListItem(path=url))."""
    if not stream_url:
        return ''

    # Route magnet URIs through Elementum
    if stream_url.startswith('magnet:'):
        from urllib.parse import quote as _uq
        elementum_url = 'plugin://plugin.video.elementum/play?uri=%s' % _uq(stream_url)
        xbmc.log('[Starfleet/Streams] Routing magnet via Elementum: ' + elementum_url[:80], xbmc.LOGINFO)
        return elementum_url

    resolved_url = stream_url

    # Step 1: internal resolver for embed domains ResolveURL doesn't cover
    try:
        from resources.lib import embed_resolver as _er
        internal = _er.resolve(stream_url)
        if internal:
            xbmc.log('[Starfleet/Streams] InternalResolver: %s' % internal[:80], xbmc.LOGINFO)
            resolved_url = internal
    except Exception as e:
        xbmc.log('[Starfleet/Streams] InternalResolver error: %s' % e, xbmc.LOGWARNING)

    # Step 2: ResolveURL for hosters it supports (DoodStream, MixDrop, etc.)
    if resolved_url == stream_url:
        try:
            import resolveurl
            if resolveurl.HostedMediaFile(stream_url).valid_url():
                hmf = resolveurl.HostedMediaFile(stream_url)
                resolved_url = hmf.resolve()
                xbmc.log('[Starfleet/Streams] ResolveURL: %s' % (resolved_url or 'failed')[:80], xbmc.LOGINFO)
        except ImportError:
            xbmc.log('[Starfleet/Streams] ResolveURL not installed', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        return ''

    # JS embed with unresolved # fragment — Kodi can't play it
    if resolved_url == stream_url and '#' in resolved_url:
        return ''

    return resolved_url


def afdb_play(handle, stream_url, film_id=''):
    """
    Resolve and play a stream URL via ResolveURL if available,
    otherwise direct play.
    """
    if not stream_url:
        xbmcgui.Dialog().ok(
            'Starfleet — No Stream Source',
            'No stream URL has been assigned to this film yet.\n\n'
            'To add playback support:\n'
            '1. Find the film on a hoster (StreamTape, DoodStream, etc.)\n'
            '2. The stream URL will be passed here automatically\n'
            '   once a source plugin or scraper provides it.\n\n'
            'Metadata from Adult Film Database is ready and waiting.'
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    resolved_url = stream_url

    # Try ResolveURL addon first (supports 50+ hosters)
    try:
        import resolveurl
        if resolveurl.HostedMediaFile(stream_url).valid_url():
            hmf = resolveurl.HostedMediaFile(stream_url)
            resolved_url = hmf.resolve()
            xbmc.log('[AFDB] ResolveURL resolved: %s' % resolved_url[:80],
                     xbmc.LOGINFO)
    except ImportError:
        xbmc.log('[AFDB] ResolveURL not installed — playing directly',
                 xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[AFDB] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        xbmcgui.Dialog().notification('Adult', 'Could not resolve stream URL',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved_url)
    xbmcplugin.setResolvedUrl(handle, True, li)


# ── XXXClub Browse ────────────────────────────────────────────────────────────

def xxxclub_browse(handle, build_url, cursor=''):
    """
    Browse latest torrents from XXXClub.to.
    Each item is directly playable via debrid (magnet → debrid → stream).
    """
    from resources.lib import torrent_sources as _ts

    xbmcplugin.setPluginCategory(handle, '🔞 XXXClub — Latest')
    xbmcplugin.setContent(handle, 'movies')

    dlg = xbmcgui.DialogProgress()
    dlg.create('XXXClub', 'Fetching latest torrents...')

    torrents, next_cursor = _ts.browse_xxxclub(cursor=cursor)
    dlg.close()

    if not torrents:
        xbmcgui.Dialog().notification('XXXClub', 'No results found', xbmcgui.NOTIFICATION_INFO)
        return

    for t in torrents:
        li = xbmcgui.ListItem(label='%s  [COLOR grey][%s][/COLOR]' % (t['title'], t['size']))
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(t['title'])
            tag.setPlot('[COLOR grey]%s[/COLOR]' % t['size'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': t['title'], 'plot': t['size'], 'mpaa': 'Adults Only'})
        if t.get('thumb'):
            li.setArt({'thumb': t['thumb'], 'poster': t['thumb'], 'icon': t['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_xxxclub_magnet',
                       'magnet': t['magnet'],
                       'title':  t['title']}),
            li, False
        )

    if next_cursor:
        _add_dir(handle, build_url, '» Next Page',
                 {'action': 'xxxclub_browse', 'cursor': next_cursor},
                 plot='Load next page')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def play_xxxclub_magnet(handle, magnet, title=''):
    """Resolve a XXXClub magnet via debrid and play it."""
    from resources.lib import debrid_torrent as _dt

    dlg = xbmcgui.DialogProgress()
    dlg.create('XXXClub', 'Resolving via debrid...')

    try:
        import urllib.parse as _ul, re as _re
        qs = _ul.parse_qs(_ul.urlparse(magnet).query)
        info_hash = _re.search(r'btih:([a-fA-F0-9]{40})', magnet)
        info_hash = info_hash.group(1).lower() if info_hash else ''

        stream_url = None
        for fn in (_dt.rd_magnet_to_stream, _dt.ad_magnet_to_stream,
                   _dt.pm_magnet_to_stream, _dt.tb_magnet_to_stream):
            try:
                result = fn(magnet, info_hash)
                if result:
                    stream_url = result
                    break
            except Exception:
                continue
    finally:
        dlg.close()

    if not stream_url:
        # No debrid — route via Elementum by resolving directly to the plugin URL
        import urllib.parse as _ul2
        elem_url = 'plugin://plugin.video.elementum/play?uri=' + _ul2.quote(magnet, safe='')
        xbmc.log('[Starfleet] XXXClub no debrid, routing via Elementum: %s' % elem_url[:80], xbmc.LOGINFO)
        li = xbmcgui.ListItem(path=elem_url, label=title or 'XXXClub')
        xbmcplugin.setResolvedUrl(handle, True, li)
        return

    li = xbmcgui.ListItem(path=stream_url, label=title)
    xbmcplugin.setResolvedUrl(handle, True, li)
