# plugin.video.tvaplus — TVA+ Kodi Plugin

Free Quebec TV for Kodi 19+ (Matrix and later). Streams content from
[tvaplus.ca](https://www.tvaplus.ca) — the official free platform of Groupe TVA / Québecor.

---

## Status

| Category | Status | Notes |
|----------|--------|-------|
| 📡 **Live TV — TVA** | ✅ Working | asset_key confirmed from browser |
| 📡 **Live TV — LCN, Addik, etc.** | ⏳ Needs asset_keys | See setup below |
| 📺 **TV Shows (VOD)** | ⏳ Needs API URL | See setup below |
| 🎬 **Movies (VOD)** | ⏳ Needs API URL | See setup below |

---

## Installation

1. Zip the `plugin.video.tvaplus` folder
2. Kodi → **Add-ons → Install from zip file** → select the zip
3. Find **TVA+** under **Video Add-ons**

### Dependencies

- Kodi 19+ (Matrix) — Python 3
- `script.module.requests` (usually pre-installed)
- *(Optional)* `inputstream.adaptive` — better HLS quality

---

## How Live TV Works — Google DAI

TVA+ uses **Google DAI (Dynamic Ad Insertion)** for all live channels.

Each channel has a **static `asset_key`** that never changes. To get a
playable stream, the plugin POSTs to Google DAI's registration endpoint
using that key, and gets back a fresh time-limited HLS URL.

**TVA's asset_key is already set:** `5DUWih-wSeOUg9zszuE-Jw`

### Adding More Live Channels

To get the asset_key for LCN, Addik, Casa, Moi & Cie, and Prise 2:

1. Open **Chrome** and go to `https://www.tvaplus.ca`
2. Press **F12** → click the **Network** tab → click **Fetch/XHR**
3. Click a live channel (e.g. LCN) and press play
4. Watch the requests — look for one to `dai.google.com`
5. The URL will look like:
   ```
   https://dai.google.com/linear/hls/pa/event/XXXXXXXXXXXXXXXXXX/stream/...
   ```
6. Copy the value between `/event/` and `/stream/` — that's the asset_key
7. Open `resources/lib/api.py` and paste it into `DAI_LIVE_CHANNELS`

### Capturing VOD API Endpoints

For Shows and Movies, do the same thing but look for **JSON requests**
(not dai.google.com) that return lists of shows/movies with titles and IDs.
Copy those URLs into `VOD_SHOWS_URL`, `VOD_MOVIES_URL`, and `VOD_STREAM_URL`
at the top of `resources/lib/api.py`.

---

## Architecture

```
default.py          ← Kodi entry point, URL router
resources/lib/
  api.py            ← All network calls, Google DAI, SQLite cache
  router.py         ← Kodi ListItem builders, playback handler
resources/
  settings.xml      ← Addon settings
```

### Performance
- **SQLite cache** — show/movie lists cached 6h, live channel list 5min
- **Stream URLs never cached** — Google DAI tokens are short-lived
- **Connection pooling** — single requests.Session reused across calls
- **Smart season skip** — single-season shows go straight to episodes
- **Progress dialog** — shown while registering DAI session

---

## Disclaimer

Community plugin, not affiliated with Groupe TVA or Québecor.
Only accesses freely and publicly available Canadian content.
TVA Sports Direct (paid) is intentionally excluded.
