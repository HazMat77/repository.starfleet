# -*- coding: utf-8 -*-
"""
resources/lib/personal_sources.py

Search the user's personal cloud storage libraries for a matching title.
Credentials are hardcoded below — update if they change.

Both MixDrop and Streamtape use the same folder layout:
  Home/Movies/       — files named "tt1234567 Title (Year) Quality.mp4"
  Home/TV Shows/     — subfolders "tt1234567 Show Name"
                         → subfolders "tt1234567 Season N"  (or "Season N")
                           → episode files named with S01E01
  Home/Porn/         — adult files, matched by title or tt-prefix
"""

import re
import xbmc
from resources.lib import cache as _cache

try:
    import requests as _req
except ImportError:
    _req = None

# ── shared helpers ─────────────────────────────────────────────────────────────

_RE_IMDB = re.compile(r'\btt(\d{7,8})\b', re.IGNORECASE)
_RE_SxEx = re.compile(r'\bS(\d{1,2})E(\d{1,2})\b', re.IGNORECASE)
_RE_ADE  = re.compile(r'^(\d{4,8})\s+(.+)$')

# Streamtape Porn folder has subfolders — search all of these for adult content
_ST_PORN_SUBFOLDERS = ['movies', 'scenes', '3d porn']
_MD_PORN_SUBFOLDERS = ['movies', 'scenes', '3d porn']

_session = None


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _imdb_from_name(name):
    """Extract numeric IMDB ID from 'tt1234567 Title ...' → '1234567'."""
    m = _RE_IMDB.search(name)
    return m.group(1) if m else ''


def _ade_from_name(name):
    """Extract ADE product ID from '4796444 THR3E #4.mp4' → '4796444'."""
    clean = re.sub(r'\.[a-z0-9]{2,5}$', '', name, flags=re.IGNORECASE).strip()
    m = _RE_ADE.match(clean)
    return m.group(1) if m else ''


def _title_matches(filename, title, year=None):
    """Fuzzy match title against a filename, stripping tt/ADE prefix and quality tags."""
    fname = re.sub(r'\.[a-z0-9]{2,5}$', '', filename, flags=re.IGNORECASE)
    fname = re.sub(r'^tt\d{7,8}\s+', '', fname).strip()    # strip tt-prefix
    fname = re.sub(r'^\d{4,8}\s+', '', fname).strip()      # strip ADE prefix
    fname = re.sub(r'\(\d{4}\).*$', '', fname).strip()     # strip (Year) onwards
    fname = re.sub(r'[._\-]', ' ', fname).lower().strip()
    title_clean = title.lower().strip()
    if title_clean in fname:
        return True
    words = [w for w in title_clean.split() if len(w) > 2]
    return bool(words and all(w in fname for w in words))


# ── MixDrop ───────────────────────────────────────────────────────────────────

_MD_EMAIL = 'hazmatrevelation@gmail.com'
_MD_KEY   = 'KqVDq4GQ363ju4gCV'
_MD_API   = 'https://api.mixdrop.ag'


def _md_get(endpoint, params=None, timeout=10):
    s = _sess()
    if not s:
        return {}
    p = {'email': _MD_EMAIL, 'key': _MD_KEY}
    if params:
        p.update(params)
    r = s.get(_MD_API + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _md_list_folder(ref=''):
    """List a MixDrop folder → (subfolders, files). Cached 1h."""
    ck = 'md_folder_%s' % (ref or 'root')
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        params = {'ref': ref} if ref else {}
        data   = _md_get('/folderlist', params)
        result = data.get('result', {})
        if isinstance(result, dict):
            subfolders = result.get('folders', []) or []
            files      = result.get('files',   []) or []
        elif isinstance(result, list):
            subfolders, files = [], result
        else:
            subfolders, files = [], []
        out = (subfolders, files)
        _cache.set(ck, out, 3600)
        return out
    except Exception as e:
        xbmc.log('[Personal/MixDrop] listfolder %r error: %s' % (ref, e), xbmc.LOGWARNING)
        _cache.set(ck, ([], []), 3600)
        return [], []


def _md_root_folders():
    """Return {name_lower: ref} for root-level folders. Cached 7 days."""
    ck = 'md_root_folders'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    subfolders, _ = _md_list_folder('')
    mapping = {}
    for f in subfolders:
        name = (f.get('title') or f.get('name') or '').strip()
        ref  = f.get('ref') or f.get('id') or ''
        if name and ref:
            mapping[name.lower()] = ref
    _cache.set(ck, mapping, 7 * 24 * 3600)
    return mapping


def _md_stream_url(file_ref):
    """Resolve a MixDrop file ref to a direct stream URL."""
    try:
        data   = _md_get('/fileref2', {'ref': file_ref})
        result = data.get('result', {})
        if isinstance(result, dict):
            return result.get('url', '') or result.get('stream', '')
    except Exception as e:
        xbmc.log('[Personal/MixDrop] stream URL error for %s: %s' % (file_ref, e), xbmc.LOGWARNING)
    return ''


def _md_find_episode(season_ref, season_num, episode_num):
    """Return file ref of the episode file matching S{season}E{episode}."""
    _, files = _md_list_folder(season_ref)
    ts, te = int(season_num), int(episode_num)
    for f in files:
        fname = f.get('title') or f.get('name') or ''
        m = _RE_SxEx.search(fname)
        if m and int(m.group(1)) == ts and int(m.group(2)) == te:
            return f.get('ref') or f.get('fileref') or ''
    return ''


def search_mixdrop(title, year=None, media_type='movie', imdb_id=None,
                   season=None, episode=None):
    """
    Search the user's MixDrop personal library.
    - Movies  → Home/Movies/   matched by IMDB ID or title
    - TV      → Home/TV Shows/ → show subfolder → season subfolder → episode file
    - Adult   → Home/Porn/     matched by IMDB ID or title
    """
    if not _req:
        return []

    roots = _md_root_folders()

    if media_type == 'tv':
        target_roots = ['tv shows']
    elif media_type == 'adult':
        target_roots = ['porn']
    else:
        target_roots = ['movies']

    clean_imdb = ''
    if imdb_id:
        m = _RE_IMDB.search(str(imdb_id))
        clean_imdb = m.group(1) if m else str(imdb_id).lstrip('t')

    sources = []

    for root_name in target_roots:
        root_ref = roots.get(root_name)
        if not root_ref:
            xbmc.log('[Personal/MixDrop] root folder "%s" not found' % root_name, xbmc.LOGWARNING)
            continue

        if media_type == 'tv':
            # navigate: TV Shows → show folder → season folder → episode file
            show_folders, _ = _md_list_folder(root_ref)
            show_ref = ''
            for sf in show_folders:
                sf_name = sf.get('title') or sf.get('name') or ''
                if clean_imdb and _imdb_from_name(sf_name) == clean_imdb:
                    show_ref = sf.get('ref') or sf.get('id') or ''
                    break
                if not clean_imdb and _title_matches(sf_name, title):
                    show_ref = sf.get('ref') or sf.get('id') or ''
                    break
            if not show_ref:
                continue

            season_folders, _ = _md_list_folder(show_ref)
            target_s = int(season) if season else 1
            season_ref = ''
            for sf in season_folders:
                sf_name = sf.get('title') or sf.get('name') or ''
                if re.search(r'\bSeason\s+%d\b' % target_s, sf_name, re.IGNORECASE):
                    season_ref = sf.get('ref') or sf.get('id') or ''
                    break
            if not season_ref:
                continue

            ep_ref = _md_find_episode(season_ref, target_s, episode or 1)
            if not ep_ref:
                continue
            url = _md_stream_url(ep_ref)
            if url:
                sources.append({
                    'label': '[MixDrop] %s S%02dE%02d' % (title, target_s, episode or 1),
                    'url':   url,
                })

        elif media_type == 'adult':
            # Porn/ has subfolders (Movies, Scenes, 3D porn) — search each
            porn_subfolders, porn_files = _md_list_folder(root_ref)
            # collect files both directly in Porn/ and in its subfolders
            file_candidates = list(porn_files)
            for psf in porn_subfolders:
                psf_name = (psf.get('title') or psf.get('name') or '').lower()
                if any(psf_name == s for s in _MD_PORN_SUBFOLDERS):
                    psf_ref = psf.get('ref') or psf.get('id') or ''
                    if psf_ref:
                        _, sub_files = _md_list_folder(psf_ref)
                        file_candidates.extend(sub_files)
            for f in file_candidates:
                fname = f.get('title') or f.get('name') or ''
                if not fname or not _title_matches(fname, title):
                    continue
                fref = f.get('ref') or f.get('fileref') or ''
                if not fref:
                    continue
                url = _md_stream_url(fref)
                if not url:
                    continue
                sources.append({'label': '[MixDrop] %s' % fname, 'url': url})

        else:
            # movies: match by IMDB ID or title
            _, files = _md_list_folder(root_ref)
            for f in files:
                fname = f.get('title') or f.get('name') or ''
                if not fname:
                    continue
                f_imdb = _imdb_from_name(fname)
                matched = (clean_imdb and f_imdb and f_imdb == clean_imdb) or \
                          _title_matches(fname, title, year)
                if not matched:
                    continue
                fref = f.get('ref') or f.get('fileref') or ''
                if not fref:
                    continue
                url = _md_stream_url(fref)
                if not url:
                    continue
                sources.append({'label': '[MixDrop] %s' % fname, 'url': url})

    if sources:
        xbmc.log('[Personal/MixDrop] Found %d match(es) for "%s"' % (len(sources), title),
                 xbmc.LOGINFO)
    return sources


# ── Streamtape ────────────────────────────────────────────────────────────────

_ST_USER = '3002fb47d0df5c2b160d'
_ST_PASS = 'Zaden2010!'
_ST_API  = 'https://api.streamtape.com'


def _st_get(endpoint, params=None, timeout=10):
    s = _sess()
    if not s or not _ST_PASS:
        return {}
    p = {'login': _ST_USER, 'key': _ST_PASS}
    if params:
        p.update(params)
    r = s.get(_ST_API + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _st_list_folder(folder_id=''):
    """List a Streamtape folder → (subfolders, files). Cached 1h."""
    ck = 'st_folder_%s' % (folder_id or 'root')
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        params = {'folder': folder_id} if folder_id else {}
        data   = _st_get('/file/listfolder', params)
        result = data.get('result', {})
        if not isinstance(result, dict):
            raise ValueError('unexpected result: %r' % result)
        folders = result.get('folders', []) or []
        files   = result.get('files',   []) or []
        out = (folders, files)
        _cache.set(ck, out, 3600)
        return out
    except Exception as e:
        xbmc.log('[Personal/Streamtape] listfolder %r error: %s' % (folder_id, e), xbmc.LOGWARNING)
        _cache.set(ck, ([], []), 3600)
        return [], []


def _st_root_folders():
    """Return {name_lower: folder_id} for root-level folders. Cached 7 days."""
    ck = 'st_root_folders'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    folders, _ = _st_list_folder('')
    mapping = {(f.get('name') or '').strip().lower(): f.get('id') or ''
               for f in folders if f.get('name') and f.get('id')}
    _cache.set(ck, mapping, 7 * 24 * 3600)
    return mapping


def _st_stream_url(file_id):
    """Get a playable URL for a Streamtape file ID via ticket flow."""
    try:
        data   = _st_get('/file/dlticket', {'file': file_id})
        ticket = data.get('result', {}).get('ticket', '')
        if not ticket:
            return ''
        data2 = _st_get('/file/dl', {'file': file_id, 'ticket': ticket})
        return data2.get('result', {}).get('url', '')
    except Exception as e:
        xbmc.log('[Personal/Streamtape] stream URL error for %s: %s' % (file_id, e), xbmc.LOGWARNING)
        return ''


def _st_find_episode(season_folder_id, season_num, episode_num):
    """Return linkid of the episode file matching S{season}E{episode}."""
    _, files = _st_list_folder(season_folder_id)
    ts, te = int(season_num), int(episode_num)
    for f in files:
        fname = f.get('name') or ''
        m = _RE_SxEx.search(fname)
        if m and int(m.group(1)) == ts and int(m.group(2)) == te:
            return f.get('linkid') or f.get('id') or ''
    return ''


def search_streamtape(title, year=None, media_type='movie', imdb_id=None,
                      season=None, episode=None):
    """
    Search the user's Streamtape personal library.
    - Movies  → Home/Movies/   matched by IMDB ID or title
    - TV      → Home/TV Shows/ → show subfolder → season subfolder → episode file
    - Adult   → Home/Porn/     matched by IMDB ID or title
    """
    if not _req or not _ST_PASS:
        return []

    roots = _st_root_folders()

    if media_type == 'tv':
        target_roots = ['tv shows']
    elif media_type == 'adult':
        target_roots = ['porn']
    else:
        target_roots = ['movies']

    clean_imdb = ''
    if imdb_id:
        m = _RE_IMDB.search(str(imdb_id))
        clean_imdb = m.group(1) if m else str(imdb_id).lstrip('t')

    sources = []

    for root_name in target_roots:
        root_id = roots.get(root_name)
        if not root_id:
            xbmc.log('[Personal/Streamtape] root folder "%s" not found' % root_name, xbmc.LOGWARNING)
            continue

        if media_type == 'tv':
            show_folders, _ = _st_list_folder(root_id)
            show_id = ''
            for sf in show_folders:
                sf_name = sf.get('name') or ''
                if clean_imdb and _imdb_from_name(sf_name) == clean_imdb:
                    show_id = sf.get('id') or ''
                    break
                if not clean_imdb and _title_matches(sf_name, title):
                    show_id = sf.get('id') or ''
                    break
            if not show_id:
                continue

            season_folders, _ = _st_list_folder(show_id)
            target_s = int(season) if season else 1
            season_id = ''
            for sf in season_folders:
                sf_name = sf.get('name') or ''
                if re.search(r'\bSeason\s+%d\b' % target_s, sf_name, re.IGNORECASE):
                    season_id = sf.get('id') or ''
                    break
            if not season_id:
                continue

            ep_id = _st_find_episode(season_id, target_s, episode or 1)
            if not ep_id:
                continue
            url = _st_stream_url(ep_id)
            if url:
                sources.append({
                    'label': '[Streamtape] %s S%02dE%02d' % (title, target_s, episode or 1),
                    'url':   url,
                })

        elif media_type == 'adult':
            # Porn/ has subfolders (Movies, Scenes, 3D porn) — search each
            porn_subfolders, porn_files = _st_list_folder(root_id)
            file_candidates = list(porn_files)
            for psf in porn_subfolders:
                psf_name = (psf.get('name') or '').lower()
                if any(psf_name == s for s in _ST_PORN_SUBFOLDERS):
                    psf_id = psf.get('id') or ''
                    if psf_id:
                        _, sub_files = _st_list_folder(psf_id)
                        file_candidates.extend(sub_files)
            for f in file_candidates:
                fname = f.get('name') or ''
                if not fname or not _title_matches(fname, title):
                    continue
                fid = f.get('linkid') or f.get('id') or ''
                if not fid:
                    continue
                url = _st_stream_url(fid)
                if not url:
                    continue
                sources.append({'label': '[Streamtape] %s' % fname, 'url': url})

        else:
            # movies: match by IMDB ID or title
            _, files = _st_list_folder(root_id)
            for f in files:
                fname = f.get('name') or ''
                if not fname:
                    continue
                f_imdb = _imdb_from_name(fname)
                matched = (clean_imdb and f_imdb and f_imdb == clean_imdb) or \
                          _title_matches(fname, title, year)
                if not matched:
                    continue
                fid = f.get('linkid') or f.get('id') or ''
                if not fid:
                    continue
                url = _st_stream_url(fid)
                if not url:
                    continue
                sources.append({'label': '[Streamtape] %s' % fname, 'url': url})

    if sources:
        xbmc.log('[Personal/Streamtape] Found %d match(es) for "%s"' % (len(sources), title),
                 xbmc.LOGINFO)
    return sources


# ── Unified personal library search ──────────────────────────────────────────

def search_personal(title, year=None, media_type='movie', imdb_id=None,
                    season=None, episode=None):
    """Search all personal library services and return combined source list."""
    sources = []
    try:
        sources += search_mixdrop(title, year=year, media_type=media_type,
                                  imdb_id=imdb_id, season=season, episode=episode)
    except Exception as e:
        xbmc.log('[Personal] MixDrop error: %s' % e, xbmc.LOGWARNING)
    try:
        sources += search_streamtape(title, year=year, media_type=media_type,
                                     imdb_id=imdb_id, season=season, episode=episode)
    except Exception as e:
        xbmc.log('[Personal] Streamtape error: %s' % e, xbmc.LOGWARNING)
    return sources
