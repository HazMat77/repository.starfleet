﻿# -*- coding: utf-8 -*-
"""
resources/lib/unified_live.py

Unified Live TV channel list — all sources, deduplicated, source-picker on conflicts.

Performance:
  - All source fetches run in PARALLEL via ThreadPoolExecutor
  - Cold load: wait = slowest single source (~3-5s) not sum of all (~12s)
  - Warm load: pure cache hit, <5ms
  - Dedup and merge runs on cached data — no re-fetch on repeat opens
  - Unified list itself cached 10 min
"""

import re
import threading
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError

import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

SOURCE_LABELS = {
    'Samsung TV+': '📺  Samsung TV+',
    'Plex':        '🟠  Plex',
    'Pluto TV':    '🪐  Pluto TV',
    'TVA+':        '📡  Québecor/Global News',
}

# Per-source fetch timeout — each source gets this long independently
FETCH_TIMEOUT = 15

# ── Name normalisation ────────────────────────────────────────────────────────

_RE_QUALITY  = re.compile(r'\b(HD|SD|FHD|UHD|4K|720p|1080p|480p)\b', re.IGNORECASE)
_RE_BRACKETS = re.compile(r'\[.*?\]')
_RE_PARENS   = re.compile(r'\(.*?\)')
_RE_NONALNUM = re.compile(r'[^a-z0-9 ]')
_RE_MULTI_SP = re.compile(r' {2,}')
_STRIP_TAIL  = {'television', 'channel', 'network', 'tv', 'plus', 'ca', 'us', 'hd'}

@lru_cache(maxsize=5000)
def _normalize(name):
    n = name.lower()
    n = _RE_BRACKETS.sub(' ', n)
    n = _RE_PARENS.sub(' ', n)
    n = _RE_QUALITY.sub(' ', n)
    n = _RE_NONALNUM.sub(' ', n)
    n = _RE_MULTI_SP.sub(' ', n).strip()
    parts = n.split()
    while parts and parts[-1] in _STRIP_TAIL:
        parts.pop()
    return ' '.join(parts)


# ── Parallel source fetcher ───────────────────────────────────────────────────

def _fetch_samsung():
    from resources.lib import live_sources
    chs = live_sources.get_samsung_channels()
    return [dict(ch, source='Samsung TV+') for ch in chs]

def _fetch_plex():
    from resources.lib import live_sources
    chs = live_sources.get_plex_channels()
    return [dict(ch, source='Plex') for ch in chs]

def _fetch_pluto():
    from resources.lib import live_sources
    chs = live_sources.get_pluto_channels()
    return [dict(ch, source='Pluto TV') for ch in chs]

_FETCHERS = {
    'Samsung TV+': _fetch_samsung,
    'Plex':        _fetch_plex,
    'Pluto TV':    _fetch_pluto,
}


def _fetch_all_parallel():
    """
    Fetch all sources simultaneously using a thread pool.
    Returns flat list of raw channel dicts with 'source' key set.
    Failed/timed-out sources are skipped with a warning logged.
    """
    raw     = []
    lock    = threading.Lock()

    with ThreadPoolExecutor(max_workers=len(_FETCHERS)) as pool:
        futures = {
            pool.submit(fn): source
            for source, fn in _FETCHERS.items()
        }
        for future in as_completed(futures, timeout=FETCH_TIMEOUT + 2):
            source = futures[future]
            try:
                channels = future.result(timeout=FETCH_TIMEOUT)
                with lock:
                    raw.extend(channels)
                xbmc.log('[Starfleet] %s: %d channels fetched' % (
                    source, len(channels)), xbmc.LOGINFO)
            except TimeoutError:
                xbmc.log('[Starfleet] %s: fetch timed out' % source, xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log('[Starfleet] %s: fetch error: %s' % (source, e), xbmc.LOGWARNING)

    return raw


# ── Merge & dedup ─────────────────────────────────────────────────────────────

def _merge(raw, tva_channels=None):
    """
    Merge raw channel list into deduplicated groups.
    Returns sorted list of group dicts.
    """
    if tva_channels:
        for ch in tva_channels:
            raw.append({
                'id':         ch.get('id', ''),
                'title':      ch['title'],
                'group':      'TVA+',
                'source':     'TVA+',
                'thumbnail':  ch.get('thumbnail', ''),
                'stream_url': '',
                'asset_key':  ch.get('asset_key', ''),
                'channel_id': ch.get('id', ''),
            })

    groups = {}

    for ch in raw:
        title = (ch.get('title') or '').strip()
        if not title:
            continue
        key = _normalize(title)
        if not key:
            continue

        entry = {
            'source':     ch['source'],
            'label':      SOURCE_LABELS.get(ch['source'], ch['source']),
            'stream_url': ch.get('stream_url', ''),
            'thumbnail':  ch.get('thumbnail', ''),
            'ch_id':      ch.get('id', ''),
            'asset_key':  ch.get('asset_key', ''),
            'channel_id': ch.get('channel_id', ch.get('id', '')),
        }

        if key not in groups:
            groups[key] = {
                'key':       key,
                'title':     title,
                'thumbnail': ch.get('thumbnail', ''),
                'group':     ch.get('group', ''),
                'sources':   [],
            }
        else:
            # Prefer longer title, prefer non-empty thumbnail
            if len(title) > len(groups[key]['title']):
                groups[key]['title'] = title
            if not groups[key]['thumbnail'] and ch.get('thumbnail'):
                groups[key]['thumbnail'] = ch['thumbnail']

        # One entry per source per channel
        if ch['source'] not in [s['source'] for s in groups[key]['sources']]:
            groups[key]['sources'].append(entry)

    return sorted(groups.values(), key=lambda x: x['title'].lower())


# ── Public API ────────────────────────────────────────────────────────────────

def get_all_channels(tva_channels=None):
    """
    Return merged, deduplicated channel list from all sources.
    All network fetches run in parallel — cold load waits only for
    the slowest single source, not the sum of all sources.
    """
    ck     = 'unified_live_all'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    raw    = _fetch_all_parallel()
    result = _merge(raw, tva_channels)

    _cache.set(ck, result, 10 * 60)
    xbmc.log('[Starfleet] Unified live: %d channels merged from %d raw' % (
        len(result), len(raw)), xbmc.LOGINFO)
    return result


def invalidate():
    _cache.delete('unified_live_all')


# ── Source picker ─────────────────────────────────────────────────────────────

def pick_source_and_play(handle, channel):
    """
    Single source  → return immediately, no dialog.
    Multi source   → show select dialog → return chosen.
    Returns (source_entry, action) or (None, None) on cancel.
    """
    sources = channel['sources']

    if len(sources) == 1:
        return sources[0], _action_for(sources[0])

    options = [s['label'] for s in sources]
    idx = xbmcgui.Dialog().select(
        'Stream "%s" from:' % channel['title'], options
    )
    if idx < 0:
        return None, None

    return sources[idx], _action_for(sources[idx])


def _action_for(source_entry):
    return 'play_live_dai' if source_entry['source'] == 'TVA+' else 'play_direct'
