﻿# -*- coding: utf-8 -*-
"""
resources/lib/sports_router.py

Kodi UI for the Sports section.

Menu:
  Sports → [NFL, NBA, MLB, NHL, UFC, Boxing, Soccer, F1, CFB, NCAAB, CFL, WWE]
         → Today's Games  (event list for the selected sport)
         → click game → dialog: Link 1, Link 2, ... → play
"""

import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmcplugin

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')


def _progress(msg):
    d = xbmcgui.DialogProgress()
    d.create('Starfleet Sports', msg)
    d.update(5)
    return d


# ── Sport categories ──────────────────────────────────────────────────────────

def sports_menu(handle, build_url):
    """Top-level sports menu: show each sport category as a folder."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '🏟️  Sports')
    xbmcplugin.setContent(handle, 'files')

    cats = _ss.get_sport_categories()

    for cat in cats:
        li = xbmcgui.ListItem(label=cat['label'])
        li.setArt({'thumb': cat['icon'], 'icon': cat['icon']})
        li.setInfo('video', {'title': cat['label']})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'sports_events', 'sport_slug': cat['slug'],
                       'sport_label': cat['label'], 'sport_icon': cat['icon']}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Events list for a sport ───────────────────────────────────────────────────

def sports_events(handle, build_url, sport_slug, sport_label='', sport_icon=''):
    """List today's and upcoming events for a sport category."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '🏟️  %s' % (sport_label or sport_slug.upper()))
    xbmcplugin.setContent(handle, 'files')

    cold = _cache.get('sports_events_%s' % sport_slug) is None
    dlg  = _progress('Loading %s events...' % sport_slug.upper()) if cold else None
    events = _ss.get_sport_events(sport_slug)
    if dlg:
        dlg.close()

    if not events:
        xbmcgui.Dialog().notification(
            'Starfleet Sports',
            'No events found for %s' % sport_slug.upper(),
            xbmcgui.NOTIFICATION_INFO
        )
        return

    for ev in events:
        # Build display label with live indicator and time
        status = '[COLOR red]🔴 LIVE[/COLOR] — ' if ev.get('is_live') else ''
        label  = '%s%s' % (status, ev['title'])
        sublabel = ev.get('datetime', '')
        if ev.get('league') and ev['league'].upper() != sport_slug.upper():
            sublabel = '%s • %s' % (ev['league'], sublabel) if sublabel else ev['league']

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': ev['title'],
            'plot':  '%s\n%s' % (sublabel, '🔴 LIVE NOW' if ev.get('is_live') else ''),
        })

        # Use league logo if available, otherwise sport category icon
        logo = ev.get('logo') or sport_icon
        if logo:
            li.setArt({'thumb': logo, 'icon': logo, 'fanart': logo})

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'sports_event_play',
                       'event_id':   ev['id'],
                       'event_path': ev['path'],
                       'title':      ev['title']}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Play an event — show stream picker dialog ─────────────────────────────────

def sports_event_play(handle, event_id='', event_path='', title=''):
    """
    Fetch available stream links for the event and show a dialog picker.
    If not live yet, show a notification. If live, show Link 1 / Link 2 / ...
    """
    from resources.lib import sports_sources as _ss

    if not event_path:
        xbmcgui.Dialog().notification('Starfleet Sports', 'Event path missing',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    dlg = _progress('Fetching stream links...')
    streams = _ss.get_event_streams(event_path, event_id)
    dlg.close()

    if not streams:
        xbmcgui.Dialog().ok(
            'Starfleet Sports — %s' % title,
            'No stream links available yet.\n\n'
            'This event may not have started, or stream links will appear '
            'a few minutes before/after kick-off.\n\n'
            'Try again when the event is live.'
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # Build dialog options
    options = ['Link %d — %s' % (i + 1, s['label']) for i, s in enumerate(streams)]

    if len(streams) == 1:
        chosen_url = streams[0]['url']
    else:
        idx = xbmcgui.Dialog().select(
            '%s — Choose stream' % title, options
        )
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen_url = streams[idx]['url']

    _play_stream(handle, chosen_url, title)


def _play_stream(handle, url, title=''):
    """Resolve the URL via resolveurl/resolvers then set as resolved URL."""
    resolved = url

    # Try ResolveURL if available
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                resolved = r
    except ImportError:
        pass
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    li = xbmcgui.ListItem(label=title, path=resolved)
    li.setInfo('video', {'title': title})
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle, True, li)
