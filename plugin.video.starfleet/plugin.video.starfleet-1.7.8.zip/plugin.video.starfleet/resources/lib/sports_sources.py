﻿# -*- coding: utf-8 -*-
"""
resources/lib/sports_sources.py

Sports live-stream scraper.

Primary source: istreameast.cx
  - Individual game/event cards with TheSportsDB league logos
  - Game title (teams), datetime, league name
  - /links/{slug-id} pages show stream table when event is live

Secondary source: crackstreams.mx
  - Sport category list with ESPN CDN league logos
  - Homepage game listings for cross-referencing stream links

Cache: category list 1h, game list 10min (live data), stream list 5min
"""

import re
import time
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

ISE_BASE   = 'https://istreameast.cx'
CRACK_BASE = 'https://crackstreams.mx'

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
    return _session


def _get(url, timeout=12):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()


# ── Sport categories ──────────────────────────────────────────────────────────

# Curated category list — istreameast schedule slugs + metadata
_CATEGORIES = [
    {'slug': 'nfl',    'label': 'NFL',          'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nfl.png'},
    {'slug': 'nba',    'label': 'NBA',          'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nba.png'},
    {'slug': 'mlb',    'label': 'MLB',          'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/mlb.png'},
    {'slug': 'nhl',    'label': 'NHL',          'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'},
    {'slug': 'ufc',    'label': 'UFC / MMA',    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ufc.png'},
    {'slug': 'boxing', 'label': 'Boxing',       'icon': 'https://iili.io/3aqk6js.webp'},
    {'slug': 'soccer', 'label': 'Soccer',       'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/fifa.png'},
    {'slug': 'f1',     'label': 'Formula 1',    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/f1.png'},
    {'slug': 'cfb',    'label': 'College Football (CFB)', 'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaaf.png'},
    {'slug': 'ncaab',  'label': 'College Basketball (NCAAB)', 'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaab.png'},
    {'slug': 'cfl',    'label': 'CFL',          'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/cfl.png'},
    {'slug': 'wwe',    'label': 'WWE / Wrestling', 'icon': 'https://r2.thesportsdb.com/images/media/league/badge/r43xns1461424282.png/tiny'},
]

def get_sport_categories():
    """Return list of sport category dicts with slug, label, icon."""
    return _CATEGORIES


# ── Game/event listing from istreameast.cx ────────────────────────────────────

_RE_ISE_CARD = re.compile(
    r'class="event-card"\s+onclick="window\.location\.href=\'(/links/([^\']+))\'"\s+'
    r'data-event-id="(\d+)"\s+data-start-ts="(\d+)"[^>]*>',
    re.IGNORECASE
)
_RE_ISE_LOGO = re.compile(
    r'<img[^>]+src="(https://[^"]+thesportsdb[^"]+|https://[^"]+espncdn[^"]+)"[^>]*alt="([^"]*)"',
    re.IGNORECASE
)
_RE_ISE_TITLE    = re.compile(r'class="event-title"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_DATETIME = re.compile(r'class="event-datetime"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_LEAGUE   = re.compile(r'class="event-league"\s*>(.*?)</div>', re.IGNORECASE | re.DOTALL)
_RE_ISE_STATUS   = re.compile(r'class="event-status\s+([^"]+)"\s*>(.*?)</span>', re.IGNORECASE)

# Stream table row on detail page
_RE_ISE_STREAM_ROW = re.compile(
    r'<tr[^>]*>\s*<td[^>]*>([^<]*)</td>\s*'   # streamer
    r'<td[^>]*>([^<]*)</td>\s*'                 # channel
    r'<td[^>]*>([^<]*)</td>\s*'                 # language
    r'<td[^>]*>([^<]*)</td>\s*'                 # quality
    r'<td[^>]*>[^<]*</td>\s*'                   # ads
    r'<td[^>]*>[^<]*</td>\s*'                   # adblock
    r'<td[^>]*>[^<]*</td>\s*'                   # bitrate
    r'<td[^>]*>[^<]*</td>\s*'                   # misr
    r'<td[^>]*><a[^>]+href="([^"]+)"[^>]*>',    # watch link
    re.IGNORECASE | re.DOTALL
)

# Also check for crackstreams game links on their homepage
_RE_CRACK_CARD = re.compile(
    r'<a[^>]+href="(/watch-live/([^/\"]+)/([^/\"]+)/([^/\"]+)/(\d+))"[^>]*>'
    r'(?:(?!</a>).)*?'
    r'<div[^>]*class="[^"]*event-title[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE | re.DOTALL
)
_RE_CRACK_IMG = re.compile(
    r'<img[^>]+src="(https://[^"]+espncdn[^"]+)"[^>]+alt="([^"]+)"',
    re.IGNORECASE
)


def _parse_ise_block(card_html, block):
    """Extract event details from the HTML block following an event-card div."""
    m_title = _RE_ISE_TITLE.search(block)
    m_dt    = _RE_ISE_DATETIME.search(block)
    m_lg    = _RE_ISE_LEAGUE.search(block)
    m_st    = _RE_ISE_STATUS.search(block)
    m_logo  = _RE_ISE_LOGO.search(block)

    title    = _clean(m_title.group(1)) if m_title else ''
    datetime_str = _clean(m_dt.group(1))  if m_dt    else ''
    league   = _clean(_RE_STRIP.sub(' ', m_lg.group(1))) if m_lg else ''
    # strip status span text from league
    league   = re.sub(r'\s+\d+\s+(?:hours?|minutes?)\s+from\s+now.*', '', league, flags=re.IGNORECASE).strip()

    status_class = m_st.group(1).strip() if m_st else 'upcoming'
    is_live = 'live' in status_class.lower()

    logo_url = m_logo.group(1) if m_logo else ''

    return title, datetime_str, league, logo_url, is_live


def get_sport_events(sport_slug='nfl'):
    """
    Return list of event dicts for a sport from istreameast.cx.
    Each dict: {id, slug, path, title, datetime, league, logo, is_live, start_ts}
    """
    ck = 'sports_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = ISE_BASE + '/schedule/%s' % sport_slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] istreameast fetch error (%s): %s' % (sport_slug, e), xbmc.LOGERROR)
        # Fall back to homepage
        try:
            html = _get(ISE_BASE + '/')
        except Exception:
            return []

    events = []
    seen   = set()

    # Find all event-card divs and extract data from following block
    for m in _RE_ISE_CARD.finditer(html):
        path, slug, event_id, start_ts = m.group(1), m.group(2), m.group(3), m.group(4)
        if event_id in seen:
            continue
        seen.add(event_id)

        # Extract the ~800 chars of HTML after this card div open for detail fields
        block_start = m.end()
        block = html[block_start:block_start + 900]

        title, datetime_str, league, logo_url, is_live = _parse_ise_block(None, block)

        # Only include events matching the requested sport (or all if homepage fallback)
        if sport_slug != 'nfl' and league and league.upper() != sport_slug.upper():
            # For sports like 'ufc' the league might say 'UFC' - check case-insensitive
            if sport_slug.lower() not in league.lower():
                continue

        events.append({
            'id':       event_id,
            'slug':     slug,
            'path':     path,
            'title':    title or slug.replace('-', ' ').title(),
            'datetime': datetime_str,
            'league':   league,
            'logo':     logo_url,
            'is_live':  is_live,
            'start_ts': int(start_ts),
        })

    # Sort: live first, then by start time ascending
    events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))

    _cache.set(ck, events, 10 * 60)  # 10 min cache for live data
    xbmc.log('[Starfleet/Sports] %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def get_all_events():
    """Return all events from istreameast.cx homepage (all sports mixed)."""
    ck = 'sports_events_all'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(ISE_BASE + '/')
        events = []
        seen   = set()

        for m in _RE_ISE_CARD.finditer(html):
            path, slug, event_id, start_ts = m.group(1), m.group(2), m.group(3), m.group(4)
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[m.end():m.end() + 900]
            title, datetime_str, league, logo_url, is_live = _parse_ise_block(None, block)
            events.append({
                'id':       event_id,
                'slug':     slug,
                'path':     path,
                'title':    title or slug.replace('-', ' ').title(),
                'datetime': datetime_str,
                'league':   league,
                'logo':     logo_url,
                'is_live':  is_live,
                'start_ts': int(start_ts),
            })

        events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
        _cache.set(ck, events, 10 * 60)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] all events error: %s' % e, xbmc.LOGERROR)
        return []


# ── Event stream links ────────────────────────────────────────────────────────

def get_event_streams(event_path, event_id=''):
    """
    Fetch stream links for a specific event.
    Returns list of: {'label', 'url', 'quality', 'language'}
    Empty list if event not live yet.
    """
    ck = 'sports_streams_%s' % event_id if event_id else None
    if ck:
        cached = _cache.get(ck)
        if cached is not None:
            return cached

    url = ISE_BASE + event_path
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] stream page error (%s): %s' % (event_path, e), xbmc.LOGERROR)
        return []

    streams = []
    for m in _RE_ISE_STREAM_ROW.finditer(html):
        streamer, channel, language, quality, watch_url = (
            m.group(1).strip(), m.group(2).strip(),
            m.group(3).strip(), m.group(4).strip(),
            m.group(5).strip()
        )
        if not watch_url or watch_url == '#':
            continue
        label = '%s %s %s' % (streamer or channel, quality, language)
        label = label.strip()
        streams.append({
            'label':    label or 'Stream',
            'url':      watch_url,
            'quality':  quality,
            'language': language,
        })

    if streams and ck:
        _cache.set(ck, streams, 5 * 60)  # 5 min — live links change
    elif ck:
        _cache.set(ck, [], 2 * 60)  # 2 min — retry soon for upcoming

    xbmc.log('[Starfleet/Sports] event %s: %d streams' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# ── Crackstreams homepage game listings (for additional source links) ─────────

def get_crack_events():
    """
    Fetch game listings from crackstreams.mx homepage.
    Returns list of: {'title', 'sport', 'path', 'logo'}
    """
    ck = 'sports_crack_events'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(CRACK_BASE + '/')
        events = []
        seen   = set()

        # Extract game cards: path, sport, league, teams slug, id, title
        for m in _RE_CRACK_CARD.finditer(html):
            path, sport = m.group(1), m.group(2)
            teams_slug  = m.group(4)
            event_id    = m.group(5)
            title       = _clean(m.group(6))
            if event_id in seen:
                continue
            seen.add(event_id)

            # Find league logo in preceding context
            block = html[max(0, m.start() - 400):m.start()]
            im    = _RE_CRACK_IMG.search(block)
            logo  = im.group(1) if im else ''

            events.append({
                'id':    event_id,
                'title': title,
                'sport': sport,
                'path':  path,
                'logo':  logo,
            })

        _cache.set(ck, events, 10 * 60)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] crackstreams events error: %s' % e, xbmc.LOGWARNING)
        return []
