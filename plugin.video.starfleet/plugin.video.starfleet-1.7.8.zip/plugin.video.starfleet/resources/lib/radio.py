﻿# -*- coding: utf-8 -*-
"""
resources/lib/radio.py — Radio Browser API client

Source: radio-browser.info — Free, open, public API. 90,000+ stations.
Organized by country → state/province/territory → city → stations.

Same dataset as Streema (and 20,000+ more stations on top).
No scraping, no ToS issues, no fragile HTML parsing.

API docs: https://api.radio-browser.info/
Servers:  de1, de2, nl1, fi1 — all identical, we DNS-round-robin for resilience.

Cache strategy:
  Countries list   → 7 days  (almost never changes)
  States per country → 7 days
  Cities per state   → 24h
  Stations per city  → 6h    (stream URLs occasionally change)
  Station stream     → never cached (follow redirects at play time)
"""

import socket
import random
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

import requests
from resources.lib import cache as _cache
_cache.init(_CACHE_DB)

UA = 'plugin.video.starfleet/1.0.0 Kodi Radio Browser Client'


def flag(iso):
    """Convert ISO 3166-1 alpha-2 country code to flag emoji."""
    if not iso or len(iso) != 2:
        return '🌐'
    return ''.join(chr(0x1F1E0 + ord(c.upper()) - ord('A')) for c in iso.upper())

# ── Server resolution (Radio Browser recommends DNS-based balancing) ───────────

_API_BASE = None

def _get_base():
    global _API_BASE
    if _API_BASE:
        return _API_BASE
    # Radio Browser's recommended approach: resolve all.api.radio-browser.info
    # and pick one IP at random for this session
    try:
        ips = list({r[4][0] for r in socket.getaddrinfo('all.api.radio-browser.info', 443)})
        if ips:
            ip = random.choice(ips)
            # Reverse-resolve to get hostname (needed for SNI/TLS)
            host = socket.gethostbyaddr(ip)[0]
            _API_BASE = 'https://%s' % host
            xbmc.log('[Starfleet/Radio] Using server: %s' % _API_BASE, xbmc.LOGINFO)
            return _API_BASE
    except Exception as e:
        xbmc.log('[Starfleet/Radio] DNS resolution failed: %s' % e, xbmc.LOGWARNING)
    # Fallback to a known-good server
    _API_BASE = 'https://de1.api.radio-browser.info'
    return _API_BASE


# ── HTTP session ──────────────────────────────────────────────────────────────

_session = None

def _sess():
    global _session
    if _session is None:
        import threading
        _session = requests.Session()
        _session.headers.update({
            'User-Agent': UA,
            'Accept': 'application/json',
        })
        a = requests.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=requests.adapters.Retry(total=2, backoff_factor=0.4)
        )
        _session.mount('https://', a)
    return _session


def _get(path, params=None, timeout=10):
    base = _get_base()
    url  = base + path
    r = _sess().get(url, params=params, timeout=timeout)
    r.raise_for_status()
    return r.json()


# ── Countries ─────────────────────────────────────────────────────────────────

def get_countries():
    """
    Returns list of {'name': str, 'iso': str, 'count': int}
    sorted alphabetically, only countries with stations.
    """
    cached = _cache.get('rb_countries')
    if cached is not None:
        return cached

    try:
        data = _get('/json/countries', params={'order': 'name', 'hidebroken': 'true'})
        countries = [
            {'name': c['name'], 'iso': c.get('iso_3166_1', ''), 'count': int(c.get('stationcount', 0))}
            for c in data if c.get('name') and int(c.get('stationcount', 0)) > 0
        ]
        countries.sort(key=lambda x: x['name'].lower())
        _cache.set('rb_countries', countries, 7 * 24 * 3600)
        xbmc.log('[Starfleet/Radio] Countries loaded: %d' % len(countries), xbmc.LOGINFO)
        return countries
    except Exception as e:
        xbmc.log('[Starfleet/Radio] get_countries error: %s' % e, xbmc.LOGERROR)
        return []


# ── States / Provinces / Territories ─────────────────────────────────────────

def get_states(country_name):
    """
    Returns list of {'name': str, 'count': int} for a country.
    Sorted alphabetically. Filters out empty-name states.
    """
    ck = 'rb_states_%s' % country_name.replace(' ', '_')
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        data = _get('/json/states/%s/' % requests.utils.quote(country_name),
                    params={'order': 'name', 'hidebroken': 'true'})
        states = [
            {'name': s['name'], 'count': int(s.get('stationcount', 0))}
            for s in data if s.get('name') and int(s.get('stationcount', 0)) > 0
        ]
        states.sort(key=lambda x: x['name'].lower())
        _cache.set(ck, states, 7 * 24 * 3600)
        return states
    except Exception as e:
        xbmc.log('[Starfleet/Radio] get_states(%s) error: %s' % (country_name, e), xbmc.LOGERROR)
        return []


# ── Cities ────────────────────────────────────────────────────────────────────

def get_cities(country_name, state_name):
    """
    Radio Browser doesn't have a direct city-list endpoint,
    so we fetch all stations for the state and extract unique cities.
    Returns list of {'name': str, 'count': int} sorted A-Z.
    Cached separately from station data.
    """
    ck = 'rb_cities_%s_%s' % (
        country_name.replace(' ', '_'), state_name.replace(' ', '_'))
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        stations = _fetch_stations_by_state(country_name, state_name)
        city_counts = {}
        for s in stations:
            city = (s.get('state_city') or '').strip()
            if city:
                city_counts[city] = city_counts.get(city, 0) + 1

        cities = [{'name': c, 'count': n} for c, n in city_counts.items()]
        cities.sort(key=lambda x: x['name'].lower())

        # Cache cities list for 24h
        _cache.set(ck, cities, 24 * 3600)
        return cities
    except Exception as e:
        xbmc.log('[Starfleet/Radio] get_cities(%s,%s) error: %s' % (country_name, state_name, e), xbmc.LOGERROR)
        return []


# ── Stations ──────────────────────────────────────────────────────────────────

def _fetch_stations_by_state(country_name, state_name):
    """
    Internal: fetch all stations for a state from API.
    Returns raw list with city field mapped to 'state_city'.
    """
    ck = 'rb_state_stations_%s_%s' % (
        country_name.replace(' ', '_'), state_name.replace(' ', '_'))
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        data = _get('/json/stations/search', params={
            'country':    country_name,
            'state':      state_name,
            'hidebroken': 'true',
            'order':      'name',
            'limit':      '2000',
        })
        stations = [_parse_station_with_city(s) for s in data]
        _cache.set(ck, stations, 6 * 3600)
        return stations
    except Exception as e:
        xbmc.log('[Starfleet/Radio] _fetch_stations_by_state error: %s' % e, xbmc.LOGERROR)
        return []


def get_stations_by_city(country_name, state_name, city_name):
    """
    Returns stations filtered to a specific city, sorted alphabetically.
    Uses cached state-level fetch — no extra API call.
    """
    all_stations = _fetch_stations_by_state(country_name, state_name)
    city_lower   = city_name.lower()
    filtered = [s for s in all_stations
                if (s.get('state_city') or '').lower() == city_lower]
    filtered.sort(key=lambda x: x['name'].lower())
    return filtered


def get_stations_by_country(country_name, limit=200):
    """
    Fallback: get top stations for a country when no state data exists.
    Used for countries with no state breakdown.
    """
    ck = 'rb_country_top_%s' % country_name.replace(' ', '_')
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        data = _get('/json/stations/search', params={
            'country':    country_name,
            'hidebroken': 'true',
            'order':      'clickcount',
            'reverse':    'true',
            'limit':      str(limit),
        })
        stations = [_parse_station(s) for s in data]
        stations.sort(key=lambda x: x['name'].lower())
        _cache.set(ck, stations, 6 * 3600)
        return stations
    except Exception as e:
        xbmc.log('[Starfleet/Radio] get_stations_by_country error: %s' % e, xbmc.LOGERROR)
        return []


def get_stream_url(station_uuid):
    """
    Get a playable stream URL for a station.
    Calls the /json/url/{uuid} endpoint which:
      1. Returns the resolved/de-redirected stream URL
      2. Increments the click counter (good for the community DB)
    Never cached — always fresh.
    """
    try:
        data = _get('/json/url/%s' % station_uuid, timeout=6)
        url = data.get('url', '')
        xbmc.log('[Starfleet/Radio] Stream URL for %s: %s' % (station_uuid, url[:80]), xbmc.LOGINFO)
        return url
    except Exception as e:
        xbmc.log('[Starfleet/Radio] get_stream_url(%s) error: %s' % (station_uuid, e), xbmc.LOGERROR)
        return None


def search_stations(query, country=None, limit=50):
    """Search stations by name — used for a search feature."""
    try:
        params = {
            'name':       query,
            'hidebroken': 'true',
            'order':      'clickcount',
            'reverse':    'true',
            'limit':      str(limit),
        }
        if country:
            params['country'] = country
        data = _get('/json/stations/search', params=params)
        return [_parse_station(s) for s in data]
    except Exception as e:
        xbmc.log('[Starfleet/Radio] search error: %s' % e, xbmc.LOGERROR)
        return []


# ── Parser ────────────────────────────────────────────────────────────────────

def _parse_station(s):
    """Normalize a Radio Browser station dict."""
    return {
        'uuid':       s.get('stationuuid', ''),
        'name':       s.get('name', '').strip(),
        'url':        s.get('url_resolved') or s.get('url', ''),
        'thumbnail':  s.get('favicon', ''),
        'genre':      s.get('tags', ''),
        'bitrate':    s.get('bitrate', 0),
        'codec':      s.get('codec', ''),
        'country':    s.get('country', ''),
        'state':      s.get('state', ''),
        'state_city': s.get('state', ''),   # city comes from 'state' field in per-state queries
                                             # but from individual station 'city' if present
        'language':   s.get('language', ''),
        'votes':      s.get('votes', 0),
        'clicks':     s.get('clickcount', 0),
    }

# Patch: Radio Browser returns city in a 'state' field only when
# filtering by state — the actual city is in the station's own record
def _parse_station_with_city(s):
    parsed = _parse_station(s)
    city = s.get('city') or s.get('state', '')
    parsed['state_city'] = city.strip()
    return parsed
