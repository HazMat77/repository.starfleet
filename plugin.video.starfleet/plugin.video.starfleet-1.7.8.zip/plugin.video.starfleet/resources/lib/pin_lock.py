# -*- coding: utf-8 -*-
"""
resources/lib/pin_lock.py

PIN protection and visibility control for the Adult section.

Settings used:
  adult_enabled    — bool  — show/hide Adult in main menu
  adult_pin_enabled — bool — require PIN before entering
  adult_pin        — str   — the 4-digit PIN (stored hidden)

Session state:
  PIN is only asked ONCE per Kodi session (stored in memory).
  Restarting Kodi resets the session lock.
  Navigating away and back does NOT re-ask for PIN.
"""

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()

# In-memory session unlock flag — resets when Kodi restarts
_session_unlocked = False


def adult_visible():
    """Return True if the Adult section should appear in the main menu."""
    return ADDON.getSetting('adult_enabled') == 'true'


def pin_required():
    """Return True if PIN protection is enabled and a PIN has been set."""
    return (ADDON.getSetting('adult_pin_enabled') == 'true' and
            bool(ADDON.getSetting('adult_pin').strip()))


def is_unlocked():
    """Return True if already unlocked this session."""
    return _session_unlocked


def prompt_pin():
    """
    Show a numeric PIN entry dialog.
    Returns True if PIN correct, False if wrong or cancelled.
    Stores unlock state in memory for the rest of the session.
    """
    global _session_unlocked

    # Already unlocked this session
    if _session_unlocked:
        return True

    stored_pin = ADDON.getSetting('adult_pin').strip()
    if not stored_pin:
        # No PIN set — allow access
        _session_unlocked = True
        return True

    # Show keyboard for PIN entry
    kb = xbmc.Keyboard('', 'Enter Adult Section PIN', True)  # True = hidden input
    kb.doModal()

    if not kb.isConfirmed():
        return False   # user cancelled

    entered = kb.getText().strip()

    if entered == stored_pin:
        _session_unlocked = True
        xbmc.log('[Starfleet] Adult section unlocked for this session', xbmc.LOGINFO)
        return True
    else:
        xbmcgui.Dialog().notification(
            'Starfleet',
            'Incorrect PIN',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        xbmc.log('[Starfleet] Adult section PIN incorrect', xbmc.LOGWARNING)
        return False


def set_pin():
    """
    Interactive PIN setup wizard.
    Asks for new PIN twice to confirm, then saves to settings.
    Called from Settings → Adult Section → Set / Change PIN.
    """
    # Step 1: Enter new PIN
    kb1 = xbmc.Keyboard('', 'Enter new PIN (4 digits)', True)
    kb1.doModal()
    if not kb1.isConfirmed():
        return

    pin1 = kb1.getText().strip()

    if not pin1:
        xbmcgui.Dialog().ok('Starfleet', 'PIN cannot be empty.')
        return

    if not pin1.isdigit():
        xbmcgui.Dialog().ok('Starfleet', 'PIN must contain digits only.')
        return

    if len(pin1) < 4:
        xbmcgui.Dialog().ok('Starfleet', 'PIN must be at least 4 digits.')
        return

    # Step 2: Confirm PIN
    kb2 = xbmc.Keyboard('', 'Confirm new PIN', True)
    kb2.doModal()
    if not kb2.isConfirmed():
        return

    pin2 = kb2.getText().strip()

    if pin1 != pin2:
        xbmcgui.Dialog().ok('Starfleet', 'PINs do not match. Please try again.')
        return

    # Save
    ADDON.setSetting('adult_pin', pin1)
    ADDON.setSetting('adult_pin_enabled', 'true')
    xbmcgui.Dialog().notification(
        'Starfleet', 'PIN set successfully', xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.log('[Starfleet] Adult PIN updated', xbmc.LOGINFO)


def clear_pin():
    """Remove PIN and disable PIN protection."""
    global _session_unlocked
    ADDON.setSetting('adult_pin', '')
    ADDON.setSetting('adult_pin_enabled', 'false')
    _session_unlocked = False
    xbmcgui.Dialog().notification(
        'Starfleet', 'PIN removed', xbmcgui.NOTIFICATION_INFO, 2000)


def lock_session():
    """
    Manually re-lock the adult section for this session.
    Useful if you want to lock again without restarting Kodi.
    """
    global _session_unlocked
    _session_unlocked = False
    xbmcgui.Dialog().notification(
        'Starfleet', 'Adult section locked', xbmcgui.NOTIFICATION_INFO, 2000)
