# -*- coding: utf-8 -*-
"""
resources/lib/setup.py

First-run dependency checker and setup guide.
Called once on first launch to verify all deps are present
and guide the user through installing missing optional ones.
"""

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()


def _addon_installed(addon_id):
    """Return True if an addon is installed and enabled."""
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except RuntimeError:
        return False


def check_and_guide():
    """
    Check optional dependencies on first run.
    Shows a single concise dialog if anything is missing.
    Only runs once — sets a flag in settings afterward.
    """
    if ADDON.getSetting('setup_done') == 'true':
        return

    missing   = []
    installed = []

    checks = [
        ('inputstream.adaptive',          'InputStream Adaptive',  'Official Kodi repo'),
        ('script.module.inputstreamhelper','InputStreamHelper',     'Official Kodi repo'),
        ('script.module.resolveurl',       'ResolveURL',            'jsergio123 repo (bundled in zip)'),
    ]

    for addon_id, name, source in checks:
        if _addon_installed(addon_id):
            installed.append(name)
        else:
            missing.append((name, source))

    if missing:
        lines = ['Starfleet is installed. Optional dependencies missing:\n']
        for name, source in missing:
            lines.append('  %s\n  Source: %s\n' % (name, source))
        lines.append(
            '\nTo install:\n'
            '1. For Official Kodi repo items: Add-ons → Install from repo\n'
            '   → Kodi Add-on Repository → find and install each one.\n\n'
            '2. For ResolveURL: First install repository.jsergio123\n'
            '   (included in the Starfleet zip alongside this plugin),\n'
            '   then install ResolveURL from that repo.\n\n'
            'Starfleet works without these — streams degrade gracefully.'
        )
        xbmcgui.Dialog().textviewer('Starfleet — Setup', ''.join(lines))

    ADDON.setSetting('setup_done', 'true')
    xbmc.log('[Starfleet] Setup check complete. Missing: %d, Installed: %d'
             % (len(missing), len(installed)), xbmc.LOGINFO)
