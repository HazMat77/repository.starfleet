# -*- coding: utf-8 -*-
"""
resources/lib/setup.py

First-run dependency checker. Auto-installs jsergio123 repo + ResolveURL
if they are missing, so stream resolution works out of the box.
"""

import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()

# jsergio repo zip — moved to github.com/jsergio123/zips
_JSERGIO_ZIP_URL = 'https://raw.githubusercontent.com/jsergio123/zips/master/repository.jsergio/repository.jsergio-1.0.7.zip'
_JSERGIO_ZIP_TMP = 'special://temp/repository.jsergio.zip'
_JSERGIO_ADDON_ID = 'repository.jsergio'


def _addon_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except RuntimeError:
        return False


def _download_file(url, dest_special):
    """Download url to a special:// path. Returns True on success."""
    import requests
    dest = xbmcvfs.translatePath(dest_special)
    try:
        r = requests.get(url, timeout=20, stream=True)
        r.raise_for_status()
        with open(dest, 'wb') as f:
            for chunk in r.iter_content(65536):
                f.write(chunk)
        return os.path.exists(dest) and os.path.getsize(dest) > 1000
    except Exception as e:
        xbmc.log('[Starfleet/Setup] download error: %s' % e, xbmc.LOGERROR)
        return False


def _install_jsergio_repo():
    """Download and install the jsergio123 repository zip."""
    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet Setup', 'Downloading jsergio123 repository...')
    dlg.update(10)

    ok = _download_file(_JSERGIO_ZIP_URL, _JSERGIO_ZIP_TMP)
    dlg.update(60)
    dlg.close()

    if not ok:
        xbmcgui.Dialog().ok(
            'Starfleet Setup',
            'Could not download jsergio123 repository.\n'
            'Check your internet connection and try again.\n\n'
            'You can install it manually:\n'
            'Add-ons → Install from zip → browse to repository.jsergio123.zip'
        )
        return False

    local_path = xbmcvfs.translatePath(_JSERGIO_ZIP_TMP)
    xbmc.executebuiltin('InstallFromZip(%s)' % local_path, True)
    xbmc.sleep(2000)

    if not _addon_installed(_JSERGIO_ADDON_ID):
        xbmcgui.Dialog().notification(
            'Starfleet Setup',
            'jsergio repo installed — Kodi may prompt to enable it',
            xbmcgui.NOTIFICATION_INFO, 5000
        )
    return True


def _install_resolveurl():
    """Install ResolveURL from the jsergio123 repository."""
    xbmc.executebuiltin('InstallAddon(script.module.resolveurl)', True)
    xbmc.sleep(3000)
    return _addon_installed('script.module.resolveurl')


def check_and_guide():
    """
    Check for ResolveURL on every startup (not just first run).
    If missing, offer to auto-install via jsergio123 repo.
    """
    if _addon_installed('script.module.resolveurl'):
        return

    xbmc.log('[Starfleet/Setup] ResolveURL not found — prompting install', xbmc.LOGINFO)

    answer = xbmcgui.Dialog().yesno(
        'Starfleet — Install ResolveURL?',
        'ResolveURL is not installed.\n\n'
        'It resolves stream links for Adult streams and other hosters '
        '(StreamTape, DoodStream, MyVidPlay, etc.).\n\n'
        'Install now? (downloads jsergio123 repo then ResolveURL)'
    )

    if not answer:
        return

    # Step 1 — install jsergio123 repo (if not already)
    if not _addon_installed(_JSERGIO_ADDON_ID):
        ok = _install_jsergio_repo()
        if not ok:
            return
        xbmc.sleep(1000)

    # Step 2 — install ResolveURL from the repo
    _install_resolveurl()

    if _addon_installed('script.module.resolveurl'):
        xbmcgui.Dialog().notification(
            'Starfleet Setup',
            'ResolveURL installed successfully!',
            xbmcgui.NOTIFICATION_INFO, 4000
        )
        xbmc.log('[Starfleet/Setup] ResolveURL installed OK', xbmc.LOGINFO)
    else:
        xbmcgui.Dialog().ok(
            'Starfleet Setup',
            'ResolveURL could not be installed automatically.\n\n'
            'Install manually:\n'
            '1. Add-ons → Install from repo\n'
            '2. Choose "jsergio123 Repository"\n'
            '3. Find and install "ResolveURL"'
        )
