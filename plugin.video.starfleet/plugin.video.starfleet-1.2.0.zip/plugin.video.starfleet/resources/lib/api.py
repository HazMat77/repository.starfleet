﻿# -*- coding: utf-8 -*-
"""
resources/lib/api.py — Starfleet Kodi Plugin

LIVE TV — Google DAI (Dynamic Ad Insertion)
============================================
Starfleet uses Google DAI for all live channels. The architecture:

  1. Each channel has a STATIC asset_key (event ID) — permanent, never changes
  2. To get a playable stream, POST to:
       https://dai.google.com/linear/hls/pa/event/{asset_key}/stream
     Returns JSON with stream_manifest URL containing a fresh session token
  3. Pass stream_manifest to Kodi — it's a standard HLS m3u8

Asset keys confirmed from browser capture:
  TVA         = 5DUWih-wSeOUg9zszuE-Jw
  TVA Sports  = _dmjyteCQl2eKXIanHXztQ
  TVA Sports 2 — subscription-only (permission: TVASD), no DAI key exposed
  LCN / Addik / Casa / Moi & Cie / Prise 2 — no live streams on tvaplus.ca
"""

import json
import sqlite3
import time
import os

import xbmc
import xbmcaddon`nimport xbmcvfs
import requests

ADDON    = xbmcaddon.Addon()
PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_DB = os.path.join(PROFILE, 'cache.db')

# ---------------------------------------------------------------------------
# Google DAI — Live channel asset keys
# These are STATIC per channel. Captured via browser DevTools Network tab.
# To find more: open starfleet.ca, play a live channel, look for
# dai.google.com/linear/hls/.../event/{THIS_VALUE}/stream in XHR requests
# ---------------------------------------------------------------------------
DAI_LIVE_CHANNELS = [
    # ── TVA / Québecor ────────────────────────────────────────────────────────
    {
        'id':        'tva',
        'title':     'TVA',
        'asset_key': '5DUWih-wSeOUg9zszuE-Jw',
        'thumbnail': 'https://logo.clearbit.com/tva.ca',
        'group':     'Québecor',
        'description': 'La chaîne principale de TVA — en direct',
    },
    {
        'id':        'tva-sports',
        'title':     'TVA Sports',
        'asset_key': '_dmjyteCQl2eKXIanHXztQ',
        'thumbnail': 'https://logo.clearbit.com/tvasports.ca',
        'group':     'Québecor',
        'description': 'Chaîne sportive de TVA — en direct',
    },
    # ── Global News (Corus) — DAI asset keys from JW Player feed ─────────────
    {
        'id':        'global-national',
        'title':     'Global News National',
        'asset_key': 'cQOVg6jKSvusQAfYpTrUoQ',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News National 24/7 live stream',
    },
    {
        'id':        'global-bc',
        'title':     'Global News BC',
        'asset_key': 'eIIBH8jkR-SWGaD5E4MesA',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News BC live stream',
    },
    {
        'id':        'global-toronto',
        'title':     'Global News Toronto',
        'asset_key': 'BblZeSsBRSSCtvkKRZ8XJQ',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Toronto live stream',
    },
    {
        'id':        'global-edmonton',
        'title':     'Global News Edmonton',
        'asset_key': 'K8ZZN35nQA2N_hskrUB2oQ',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Edmonton live stream',
    },
    {
        'id':        'global-calgary',
        'title':     'Global News Calgary',
        'asset_key': 'AYQ1ssB7RcOX9D78FtdoQQ',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Calgary live stream',
    },
    {
        'id':        'global-halifax',
        'title':     'Global News Halifax',
        'asset_key': 'ljv6O6ZiSiKudWk7qwWbEw',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Halifax live stream',
    },
    {
        'id':        'global-winnipeg',
        'title':     'Global News Winnipeg',
        'asset_key': 'R5XZJcTAQPuyvhsVWIKRhw',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Winnipeg live stream',
    },
    {
        'id':        'global-montreal',
        'title':     'Global News Montreal',
        'asset_key': 'wI13hMWhRSKbyZ8Q1DQR3Q',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Montreal live stream',
    },
    {
        'id':        'global-okanagan',
        'title':     'Global News Okanagan',
        'asset_key': 'PLPlPfeDQCCe4GaxAWpi4g',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Okanagan live stream',
    },
    {
        'id':        'global-saskatoon',
        'title':     'Global News Saskatoon',
        'asset_key': 'cAeO9FUXSRatnrvaksoJ9A',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Saskatoon live stream',
    },
    {
        'id':        'global-regina',
        'title':     'Global News Regina',
        'asset_key': 'A69Xh6OaTfOrRf2oHVLaPQ',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Regina live stream',
    },
    {
        'id':        'global-lethbridge',
        'title':     'Global News Lethbridge',
        'asset_key': 'hYQh95EXRwaF0IOhUrJoEQ',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Lethbridge live stream',
    },
    {
        'id':        'global-kingston',
        'title':     'Global News Kingston',
        'asset_key': 'poxVVQNQSMqFBnT6qR-Lwg',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Kingston live stream',
    },
    {
        'id':        'global-peterborough',
        'title':     'Global News Peterborough',
        'asset_key': 'CQ82MHxxS7qwe7Zvs4_sUA',
        'thumbnail': 'https://logo.clearbit.com/globalnews.ca',
        'group':     'Global News',
        'description': 'Global News Peterborough live stream',
    },
]

# DAI stream registration endpoint — /pa/ (publisher authenticated) confirmed working from browser
DAI_STREAM_URL_PA = 'https://dai.google.com/linear/hls/pa/event/{asset_key}/stream'
DAI_STREAM_URL    = 'https://dai.google.com/linear/hls/event/{asset_key}/stream'

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/124.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json',
    'Accept-Language': 'fr-CA,fr;q=0.9',
    'Origin': 'https://www.starfleet.ca',
    'Referer': 'https://www.starfleet.ca/',
}

TTL_LIVE = 5 * 60   # live channel list cache: 5 minutes

# ---------------------------------------------------------------------------
# HTTP session
# ---------------------------------------------------------------------------
_session = None

def _get_session():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=10, max_retries=2)
        _session.mount('https://', adapter)
    return _session

# ---------------------------------------------------------------------------
# SQLite cache
# ---------------------------------------------------------------------------
def _db():
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE)
    conn = sqlite3.connect(CACHE_DB, timeout=5)
    conn.execute('CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT, expires REAL)')
    conn.commit()
    return conn

def _cache_get(key):
    try:
        conn = _db()
        row = conn.execute('SELECT value, expires FROM cache WHERE key=?', (key,)).fetchone()
        conn.close()
        if row and row[1] > time.time():
            return json.loads(row[0])
    except Exception as e:
        xbmc.log('[Starfleet] cache_get error: %s' % e, xbmc.LOGWARNING)
    return None

def _cache_set(key, data, ttl):
    try:
        conn = _db()
        conn.execute('INSERT OR REPLACE INTO cache (key, value, expires) VALUES (?,?,?)',
                     (key, json.dumps(data), time.time() + ttl))
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log('[Starfleet] cache_set error: %s' % e, xbmc.LOGWARNING)

# ---------------------------------------------------------------------------
# Public: Live TV
# ---------------------------------------------------------------------------

def get_live_channels():
    """Return list of live channel dicts. Only includes channels with known asset_keys."""
    return [ch for ch in DAI_LIVE_CHANNELS if ch['asset_key']]


def get_live_stream_url(asset_key):
    """
    Register a new Google DAI session and return the HLS stream URL.
    The session token is short-lived so we never cache this.

    Google DAI docs: POST to stream endpoint, get back JSON with stream_manifest.
    """
    # /pa/ (publisher authenticated) confirmed working from browser; try it first
    for url_template in [DAI_STREAM_URL_PA, DAI_STREAM_URL]:
        url = url_template.format(asset_key=asset_key)
        xbmc.log('[Starfleet] DAI stream registration: POST %s' % url, xbmc.LOGINFO)
        try:
            r = _get_session().post(url, timeout=10, data={})
            xbmc.log('[Starfleet] DAI response: %d' % r.status_code, xbmc.LOGINFO)
            if r.status_code == 200:
                data = r.json()
                xbmc.log('[Starfleet] DAI JSON keys: %s' % list(data.keys()), xbmc.LOGINFO)
                # Google DAI returns stream_manifest as the playable URL
                stream = data.get('stream_manifest') or data.get('stream_manifest_url')
                if stream:
                    xbmc.log('[Starfleet] DAI stream URL obtained successfully', xbmc.LOGINFO)
                    return stream
        except Exception as e:
            xbmc.log('[Starfleet] DAI error on %s: %s' % (url, e), xbmc.LOGERROR)

    xbmc.log('[Starfleet] DAI: all registration attempts failed', xbmc.LOGERROR)
    return None


# ---------------------------------------------------------------------------
# Re-export live source helpers so router only imports from api
# ---------------------------------------------------------------------------
from resources.lib.live_sources import (
    get_samsung_channels,
    get_plex_channels,
    get_pluto_channels,
    refresh_pluto,
)
