# -*- coding: utf-8 -*-
"""
resources/lib/api.py — Starfleet Kodi Plugin

LIVE TV — Two stream backends
==============================
TVA / Québecor  → Google DAI (publisher-authenticated /pa/ endpoint).
                  Asset key + API key are scraped fresh from tvaplus.ca each call.
Global News     → Direct HLS from corusappservices.com.
                  Media ID is scraped from globalnews.ca, then Corus API returns HLS URL.
"""

import json
import re
import sqlite3
import time
import os

import xbmc
import xbmcaddon
import xbmcvfs
import requests

ADDON    = xbmcaddon.Addon()
PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_DB = os.path.join(PROFILE, 'cache.db')

# ---------------------------------------------------------------------------
# TVA — channel definitions (asset keys scraped dynamically at play time)
# ---------------------------------------------------------------------------
TVA_CHANNELS = [
    {
        'id':        'tva',
        'title':     'TVA',
        'live_url':  'https://www.tvaplus.ca/tva/en-direct',
        'thumbnail': 'https://logo.clearbit.com/tva.ca',
        'group':     'Québecor',
        'description': 'La chaîne principale de TVA — en direct',
    },
    {
        'id':        'tva-sports',
        'title':     'TVA Sports',
        'live_url':  'https://www.tvaplus.ca/tva-sports/en-direct',
        'thumbnail': 'https://logo.clearbit.com/tvasports.ca',
        'group':     'Québecor',
        'description': 'Chaîne sportive de TVA — en direct',
    },
]

# ---------------------------------------------------------------------------
# Global News — channel definitions (HLS via Corus API)
# ---------------------------------------------------------------------------
GLOBAL_NEWS_CHANNELS = [
    {'id': 'global-national',    'title': 'Global News National',    'region': 'national',    'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-bc',          'title': 'Global News BC',          'region': 'bc',          'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-toronto',     'title': 'Global News Toronto',     'region': 'toronto',     'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-edmonton',    'title': 'Global News Edmonton',    'region': 'edmonton',    'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-calgary',     'title': 'Global News Calgary',     'region': 'calgary',     'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-halifax',     'title': 'Global News Halifax',     'region': 'halifax',     'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-winnipeg',    'title': 'Global News Winnipeg',    'region': 'winnipeg',    'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-montreal',    'title': 'Global News Montreal',    'region': 'montreal',    'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-okanagan',    'title': 'Global News Okanagan',    'region': 'okanagan',    'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-saskatoon',   'title': 'Global News Saskatoon',   'region': 'saskatoon',   'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-regina',      'title': 'Global News Regina',      'region': 'regina',      'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-lethbridge',  'title': 'Global News Lethbridge',  'region': 'lethbridge',  'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-kingston',    'title': 'Global News Kingston',    'region': 'kingston',    'thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
    {'id': 'global-peterborough','title': 'Global News Peterborough','region': 'peterborough','thumbnail': 'https://logo.clearbit.com/globalnews.ca', 'group': 'Global News'},
]

# For backwards compat with router — combined list exposed as DAI_LIVE_CHANNELS
DAI_LIVE_CHANNELS = TVA_CHANNELS + GLOBAL_NEWS_CHANNELS

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json',
    'Accept-Language': 'en-CA,en;q=0.9,fr-CA;q=0.8',
}

TTL_LIVE = 5 * 60

# ---------------------------------------------------------------------------
# HTTP session
# ---------------------------------------------------------------------------
_session = None

def _get_session():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=10, max_retries=2)
        _session.mount('https://', adapter)
    return _session

# ---------------------------------------------------------------------------
# SQLite cache
# ---------------------------------------------------------------------------
def _db():
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE)
    conn = sqlite3.connect(CACHE_DB, timeout=5)
    conn.execute('CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT, expires REAL)')
    conn.commit()
    return conn

def _cache_get(key):
    try:
        conn = _db()
        row = conn.execute('SELECT value, expires FROM cache WHERE key=?', (key,)).fetchone()
        conn.close()
        if row and row[1] > time.time():
            return json.loads(row[0])
    except Exception as e:
        xbmc.log('[Starfleet] cache_get error: %s' % e, xbmc.LOGWARNING)
    return None

def _cache_set(key, data, ttl):
    try:
        conn = _db()
        conn.execute('INSERT OR REPLACE INTO cache (key, value, expires) VALUES (?,?,?)',
                     (key, json.dumps(data), time.time() + ttl))
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log('[Starfleet] cache_set error: %s' % e, xbmc.LOGWARNING)

# ---------------------------------------------------------------------------
# Public: channel list
# ---------------------------------------------------------------------------

def get_live_channels():
    """Return list of live channel dicts."""
    return DAI_LIVE_CHANNELS


# ---------------------------------------------------------------------------
# TVA — scrape asset_key + api_key from tvaplus.ca, then POST to DAI /pa/
# ---------------------------------------------------------------------------

def _scrape_tva_keys(live_url):
    """
    Fetch a tvaplus.ca live page and extract the DAI asset_key and api_key
    from the inline JavaScript.  Returns (asset_key, api_key) or (None, None).
    """
    ck = 'tva_dai_keys_' + live_url.split('/')[-2]
    cached = _cache_get(ck)
    if cached:
        return cached['asset_key'], cached['api_key']

    try:
        r = _get_session().get(live_url, timeout=12)
        r.raise_for_status()
        html = r.text

        asset_m = re.search(r'[Aa]sset[Kk]ey["\': ]+([A-Za-z0-9_\-]{10,30})', html)
        api_m   = re.search(r'api[Kk]ey["\': ]+([A-Za-z0-9_\-./]{10,80})',    html)

        asset_key = asset_m.group(1) if asset_m else None
        api_key   = api_m.group(1)   if api_m   else None

        if asset_key and api_key:
            _cache_set(ck, {'asset_key': asset_key, 'api_key': api_key}, 3600)
            xbmc.log('[Starfleet] TVA scraped asset_key=%s api_key=%s' % (asset_key, api_key[:20]), xbmc.LOGINFO)
        else:
            xbmc.log('[Starfleet] TVA key scrape failed from %s' % live_url, xbmc.LOGWARNING)

        return asset_key, api_key
    except Exception as e:
        xbmc.log('[Starfleet] TVA key scrape error: %s' % e, xbmc.LOGERROR)
        return None, None


def _get_tva_stream(channel):
    """POST to Google DAI /pa/ endpoint with publisher api-key. Returns HLS URL."""
    live_url  = channel.get('live_url', '')
    asset_key, api_key = _scrape_tva_keys(live_url)

    if not asset_key:
        xbmc.log('[Starfleet] TVA: no asset_key scraped', xbmc.LOGERROR)
        return None

    dai_url = 'https://dai.google.com/linear/hls/pa/event/%s/stream' % asset_key
    xbmc.log('[Starfleet] DAI POST %s' % dai_url, xbmc.LOGINFO)

    try:
        # Publisher-authenticated DAI requires api-key in POST body
        r = _get_session().post(
            dai_url,
            data={'api-key': api_key} if api_key else {},
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            timeout=12
        )
        xbmc.log('[Starfleet] DAI response: %d' % r.status_code, xbmc.LOGINFO)
        if r.status_code == 200:
            data = r.json()
            stream = data.get('stream_manifest') or data.get('stream_manifest_url') or data.get('url')
            if stream:
                xbmc.log('[Starfleet] DAI stream OK: %s' % stream[:80], xbmc.LOGINFO)
                return stream
            xbmc.log('[Starfleet] DAI JSON keys: %s' % list(data.keys()), xbmc.LOGWARNING)
        else:
            xbmc.log('[Starfleet] DAI %d body: %s' % (r.status_code, r.text[:200]), xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] DAI error: %s' % e, xbmc.LOGERROR)

    return None


# ---------------------------------------------------------------------------
# Global News — scrape media ID from globalnews.ca, fetch HLS from Corus API
# ---------------------------------------------------------------------------

_GNCA_FEED = 'https://globalnews.ca/gnca-ajax-redesign/video-entry/%s/'
import urllib.parse as _urlparse

def _get_global_news_stream(channel):
    """
    1. Fetch globalnews.ca/live/{region}/ to get JW Player media ID
    2. Hit Corus GNCA API to get direct HLS URL
    """
    region = channel.get('region', '')
    ck = 'global_news_hls_%s' % region
    cached = _cache_get(ck)
    if cached:
        return cached

    live_url = 'https://globalnews.ca/live/%s/' % region
    try:
        r = _get_session().get(live_url, timeout=12)
        r.raise_for_status()
        m = re.search(r'"mediaId"\s*:\s*"([a-f0-9\-]{36})"', r.text)
        if not m:
            xbmc.log('[Starfleet] GlobalNews: no mediaId on %s' % live_url, xbmc.LOGWARNING)
            return None
        media_id = m.group(1)
        xbmc.log('[Starfleet] GlobalNews %s mediaId=%s' % (region, media_id), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet] GlobalNews page error: %s' % e, xbmc.LOGERROR)
        return None

    feed_url = _GNCA_FEED % _urlparse.quote('{"id":"%s"}' % media_id)
    try:
        r2 = _get_session().get(feed_url, timeout=12)
        r2.raise_for_status()
        items = r2.json()
        if not items:
            return None
        sources = items[0].get('sources', [])
        hls = next((s['file'] for s in sources if s.get('type') == 'hls'), None)
        if hls:
            xbmc.log('[Starfleet] GlobalNews HLS: %s' % hls[:80], xbmc.LOGINFO)
            _cache_set(ck, hls, 300)   # cache 5 min — live streams rotate tokens
            return hls
    except Exception as e:
        xbmc.log('[Starfleet] GlobalNews feed error: %s' % e, xbmc.LOGERROR)

    return None


# ---------------------------------------------------------------------------
# Public: get stream URL for any live channel
# ---------------------------------------------------------------------------

def get_live_stream_url(channel_or_asset_key):
    """
    Accepts either a full channel dict or a bare asset_key string (legacy).
    Returns a playable HLS URL or None.
    """
    # Legacy: bare asset_key string passed from old router code
    if isinstance(channel_or_asset_key, str):
        asset_key = channel_or_asset_key
        # Find channel in list
        ch = next((c for c in DAI_LIVE_CHANNELS if c.get('asset_key') == asset_key), None)
        if ch is None:
            # Might be a TVA channel — construct minimal dict
            ch = {'asset_key': asset_key, 'live_url': '', 'region': ''}
        channel_or_asset_key = ch

    channel = channel_or_asset_key

    # Route by channel type
    if 'region' in channel and channel['region']:
        return _get_global_news_stream(channel)
    elif 'live_url' in channel and channel['live_url']:
        return _get_tva_stream(channel)
    else:
        xbmc.log('[Starfleet] Unknown channel type: %s' % channel, xbmc.LOGWARNING)
        return None


# ---------------------------------------------------------------------------
# Re-export live source helpers so router only imports from api
# ---------------------------------------------------------------------------
from resources.lib.live_sources import (
    get_samsung_channels,
    get_plex_channels,
    get_pluto_channels,
    refresh_pluto,
)
