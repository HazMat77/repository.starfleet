﻿# -*- coding: utf-8 -*-
"""
resources/lib/free_sources.py

Free streaming site catalog scrapers.

Sites:
  BounceTV      — bouncetv.com  — HTML scrapable. TV shows only.
  Popcornflix   — popcornflix.com — JS-rendered, use TMDB browse with site reference
  Fawesome       — fawesome.tv   — JS-rendered, use TMDB browse with site reference
  Filmzie        — filmzie.com   — JS-rendered, use TMDB browse with site reference
  Midnight Pulp  — midnightpulp.com — JS-rendered
  DistroTV       — distro.tv     — FAST channels, JS-rendered
  Radial Ent.    — radialentertainment.com — JS-rendered

For JS-rendered sites, we provide a catalogue of their known content categories
(comedy, horror, etc.) backed by TMDB discovery, with the site listed as a
free streaming reference source in the play dialog.

BounceTV returns actual show listings for TMDB lookup.
"""

import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
}

_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
    return _session

def _get(url, timeout=10):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


# ── Free streaming service registry ──────────────────────────────────────────

# Each entry: id, label, icon_url, media_type ('movies'|'tv'|'both'), scrapable
FREE_SERVICES = [
    {
        'id':         'popcornflix',
        'label':      'Popcornflix',
        'icon':       'https://logo.clearbit.com/popcornflix.com',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://www.popcornflix.com',
    },
    {
        'id':         'fawesome',
        'label':      'Fawesome',
        'icon':       'https://logo.clearbit.com/fawesome.tv',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://fawesome.tv',
    },
    {
        'id':         'filmzie',
        'label':      'Filmzie',
        'icon':       'https://logo.clearbit.com/filmzie.com',
        'media_type': 'movies',
        'scrapable':  False,
        'url':        'https://filmzie.com',
    },
    {
        'id':         'midnightpulp',
        'label':      'Midnight Pulp',
        'icon':       'https://logo.clearbit.com/midnightpulp.com',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://www.midnightpulp.com',
    },
    {
        'id':         'distrotv',
        'label':      'DistroTV',
        'icon':       'https://logo.clearbit.com/distro.tv',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://www.distro.tv',
    },
    {
        'id':         'bouncetv',
        'label':      'BounceTV',
        'icon':       'https://logo.clearbit.com/bouncetv.com',
        'media_type': 'tv',
        'scrapable':  True,
        'url':        'https://www.bouncetv.com',
    },
    {
        'id':         'radial',
        'label':      'Radial Entertainment',
        'icon':       'https://logo.clearbit.com/radialentertainment.com',
        'media_type': 'movies',
        'scrapable':  False,
        'url':        'https://www.radialentertainment.com',
    },
]


def get_free_services(media_type=None):
    """Return list of free service dicts, optionally filtered by media_type."""
    if media_type is None:
        return FREE_SERVICES
    return [s for s in FREE_SERVICES if s['media_type'] in (media_type, 'both')]


# ── BounceTV scraper ──────────────────────────────────────────────────────────

BOUNCE_BASE = 'https://www.bouncetv.com'

_RE_BOUNCE_SHOW = re.compile(
    r'href="(/show/([a-z0-9][a-z0-9-]+)/(\d+))"',
    re.IGNORECASE
)
_RE_BOUNCE_THUMB = re.compile(
    r'<img[^>]+(?:data-src|src)="(https://storage\.googleapis\.com/[^"]+)"[^>]+alt="([^"]+)"',
    re.IGNORECASE
)


def get_bouncetv_shows():
    """
    Scrape BounceTV show listings.
    Returns list of: {'id', 'slug', 'title', 'thumb', 'url'}
    """
    ck = 'free_bouncetv_shows'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html  = _get(BOUNCE_BASE + '/shows')
        shows = []
        seen  = set()

        # Match show links
        for m in _RE_BOUNCE_SHOW.finditer(html):
            path, slug, show_id = m.group(1), m.group(2), m.group(3)
            if show_id in seen:
                continue
            seen.add(show_id)

            # Find thumbnail near this link
            block = html[m.start():m.start() + 400]
            im    = _RE_BOUNCE_THUMB.search(block)
            thumb = im.group(1) if im else ''
            title = slug.replace('-', ' ').title()

            shows.append({
                'id':    show_id,
                'slug':  slug,
                'title': title,
                'thumb': thumb,
                'url':   BOUNCE_BASE + path,
            })

        _cache.set(ck, shows, 6 * 3600)
        xbmc.log('[Starfleet/Free] BounceTV: %d shows' % len(shows), xbmc.LOGINFO)
        return shows
    except Exception as e:
        xbmc.log('[Starfleet/Free] BounceTV error: %s' % e, xbmc.LOGERROR)
        return []


# ── TMDB-backed show/movie list for non-scrapable sites ──────────────────────

def get_free_movies_tmdb(genre_id=None, page=1):
    """
    Return popular free-tier friendly movies from TMDB.
    Used to populate Popcornflix, Fawesome, Filmzie etc.
    """
    from resources.lib import metadata as meta
    try:
        if genre_id:
            return meta.get_movies_by_genre(genre_id, page=page)
        return meta.get_movies_popular(page=page)
    except Exception as e:
        xbmc.log('[Starfleet/Free] TMDB movies error: %s' % e, xbmc.LOGWARNING)
        return []


def get_free_tv_tmdb(genre_id=None, page=1):
    """Return popular free-tier friendly TV shows from TMDB."""
    from resources.lib import metadata as meta
    try:
        if genre_id:
            return meta.get_tv_by_genre(genre_id, page=page)
        return meta.get_tv_popular(page=page)
    except Exception as e:
        xbmc.log('[Starfleet/Free] TMDB tv error: %s' % e, xbmc.LOGWARNING)
        return []
