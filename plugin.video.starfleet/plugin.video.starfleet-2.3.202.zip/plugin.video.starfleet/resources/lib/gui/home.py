"""
Starfleet Home Window.
Data is pre-loaded before doModal() so onInit populates on the GUI thread safely.
Rows swap based on which nav button is focused: Movies → New/Popular/Top Rated,
TV Shows → Popular TV Shows (3 rows), default → New Releases/TV Shows/Trending.
"""
import xbmc
import xbmcgui
import xbmcaddon

try:
    _ADDON = xbmcaddon.Addon('plugin.video.starfleet')
except Exception:
    _ADDON = None

_ID_PLAY    = 20
_ID_INFO    = 21
_ID_NAV_MOV = 41
_ID_NAV_TV  = 42
_ID_NAV_SPT = 43
_ID_NAV_LIV = 44
_ID_NAV_ADU = 45
_ID_ROW0    = 100
_ID_ROW1    = 200
_ID_ROW2    = 300
_ID_ROW3    = 400
_ID_CURSOR  = 90

_NAV_IDS = (_ID_NAV_MOV, _ID_NAV_TV, _ID_NAV_SPT, _ID_NAV_LIV, _ID_NAV_ADU)

# Row list geometry (must match Starfleet-Home.xml) — used to hand-position
# the id=90 focus cursor, since the lists' own <focusedlayout> border does
# not render on some Kodi builds/devices (confirmed on Fire TV / Kodi 21.2).
_ROW_TOP     = {_ID_ROW0: 408, _ID_ROW1: 646, _ID_ROW2: 884}
_ROW_LEFT    = 48
_ITEM_WIDTH  = 120
_CURSOR_MAX_POS = 14  # only the first ~15 unscrolled items have a known pixel position

# Row labels per context (4 rows)
_CONTEXT_LABELS = {
    'default': ['New Releases', 'TV Shows',           'Trending',     'Popular Movies'],
    'movies':  ['New Releases', 'Popular Movies',     'Top Rated',    'Upcoming'],
    'tv':      ['Popular TV',   'Top Rated TV',       'Airing Today', 'On The Air'],
    'sports':  ['Soccer Today', 'NBA & NHL Today',    'MLB & NFL Today', ''],
    'live':    ['Favorite Movies', 'Favorite TV Shows', '', ''],
    'adult':   ['New Releases', 'Recently Added',     'Adult Favorites', ''],
}


class HomeWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        # Accept either old film_rows= or new contexts=
        self._contexts   = kwargs.pop('contexts', None)
        self._close_event = kwargs.pop('close_event', None)
        film_rows        = kwargs.pop('film_rows', None)
        if self._contexts is None:
            rows = film_rows or [[], [], [], []]
            self._contexts = {'default': rows, 'movies': rows, 'tv': rows}
        self._current_ctx = 'default'
        self._film_rows   = self._contexts.get('default', [[], [], [], []])
        self._hero_row    = 0
        self._hero_pos    = 0
        self.pending_nav  = None
        self._navigating  = False
        self._playing     = False
        super(HomeWindow, self).__init__(*args, **kwargs)

    # ---------------------------------------------------------------- lifecycle

    def onInit(self):
        try:
            try:
                _adult_on = xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
            except Exception:
                _adult_on = False
            self.setProperty('sf_adult_enabled', 'true' if _adult_on else 'false')
            self._apply_context('default')
            if self._film_rows and self._film_rows[0]:
                self._set_hero(self._film_rows[0][0])
            else:
                self.setProperty('sf_hero_title', 'Welcome to Starfleet')
        except Exception as e:
            xbmc.log('[Starfleet/Home] onInit: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                   xbmcgui.ACTION_STOP, xbmcgui.ACTION_PARENT_DIR):
            if self._close_event:
                self._close_event.set()
            self.close()
        elif aid in (xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT,
                     xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN):
            self._update_hero_from_focus()

    def onFocus(self, cid):
        try:
            if cid == _ID_NAV_MOV:
                self._switch_context('movies')
            elif cid == _ID_NAV_TV:
                self._switch_context('tv')
            elif cid == _ID_NAV_SPT:
                self._switch_context('sports')
            elif cid == _ID_NAV_LIV:
                self._switch_context('live')
            elif cid == _ID_NAV_ADU:
                self._switch_context('adult')
            self._update_hero_from_focus()
        except Exception as e:
            xbmc.log('[Starfleet/Home] onFocus %d: %s' % (cid, e), xbmc.LOGERROR)

    def onClick(self, cid):
        xbmc.log('[Starfleet/Home] onClick cid=%d' % cid, xbmc.LOGINFO)
        try:
            if cid == _ID_PLAY:
                self._play_hero()
            elif cid == _ID_INFO:
                self._show_info()
            elif cid == _ID_NAV_MOV:
                self._nav('meta_movies_menu')
            elif cid == _ID_NAV_TV:
                self._nav('meta_tv_menu')
            elif cid == _ID_NAV_SPT:
                self._nav('sports_menu')
            elif cid == _ID_NAV_LIV:
                self._nav('live_menu')
            elif cid == _ID_NAV_ADU:
                self._nav('adult_menu')
            elif cid == 46:
                try:
                    xbmcaddon.Addon('plugin.video.starfleet').openSettings()
                except Exception:
                    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=open_settings)')
                try:
                    _adult_on = xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
                    self.setProperty('sf_adult_enabled', 'true' if _adult_on else 'false')
                except Exception:
                    pass
            elif cid in (_ID_ROW0, _ID_ROW1, _ID_ROW2, _ID_ROW3):
                self._play_row_item(cid)
        except Exception as e:
            xbmc.log('[Starfleet/Home] onClick %d: %s' % (cid, e), xbmc.LOGERROR)

    # ---------------------------------------------------------------- context

    def _switch_context(self, ctx):
        if ctx == self._current_ctx:
            return
        self._current_ctx = ctx
        self._film_rows   = self._contexts.get(ctx, self._contexts.get('default', [[], [], [], []]))
        self._hero_row    = 0
        self._hero_pos    = 0
        self._apply_context(ctx)

    def _apply_context(self, ctx):
        labels = _CONTEXT_LABELS.get(ctx, _CONTEXT_LABELS['default'])
        for i, lbl in enumerate(labels):
            self.setProperty('sf_row%d_label' % i, lbl)
        self._film_rows = self._contexts.get(ctx, self._contexts.get('default', [[], [], [], []]))
        self._populate_carousels()
        if self._film_rows and self._film_rows[0]:
            self._set_hero(self._film_rows[0][0])

    # ---------------------------------------------------------------- populate

    def _populate_carousels(self):
        for row_idx, list_id in enumerate([_ID_ROW0, _ID_ROW1, _ID_ROW2, _ID_ROW3]):
            films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
            ctrl  = self.getControl(list_id)
            ctrl.reset()
            for film in films:
                li = xbmcgui.ListItem(label=film.get('title', ''))
                li.setArt({
                    'thumb':  film.get('thumb', ''),
                    'fanart': film.get('fanart', film.get('thumb', '')),
                })
                li.setProperty('film_id',    str(film.get('id', film.get('tmdb_id', ''))))
                li.setProperty('film_source', film.get('source', 'tmdb'))
                li.setProperty('film_media',  film.get('media_type', 'movie'))
                ctrl.addItem(li)

    def _set_hero(self, film):
        title  = film.get('title', '')
        year   = str(film.get('year', ''))
        rating = str(film.get('rating', ''))
        meta   = '  |  '.join(p for p in [year, '★ ' + rating if rating else ''] if p)
        media  = film.get('media_type', 'movie')
        badge  = 'TV SHOW' if media == 'tv' else 'MOVIE'
        self.setProperty('sf_hero_title',  title)
        self.setProperty('sf_hero_meta',   meta)
        self.setProperty('sf_hero_plot',   film.get('plot', film.get('overview', '')))
        self.setProperty('sf_hero_fanart', film.get('fanart', film.get('thumb', '')))
        self.setProperty('sf_hero_badge',  badge)

    def _update_hero_from_focus(self):
        try:
            rmap = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2, _ID_ROW3: 3}
            cid  = self.getFocusId()
            if cid in rmap:
                row   = rmap[cid]
                ctrl  = self.getControl(cid)
                pos   = ctrl.getSelectedPosition()
                films = self._film_rows[row] if row < len(self._film_rows) else []
                if films and 0 <= pos < len(films):
                    if row != self._hero_row or pos != self._hero_pos:
                        self._hero_row = row
                        self._hero_pos = pos
                        self._set_hero(films[pos])
                self._update_cursor(cid, pos)
            else:
                self._update_cursor(None, None)
        except Exception:
            pass

    def _update_cursor(self, cid, pos):
        """Position/show the id=90 focus-highlight overlay over the currently
        selected carousel item. Falls back to hiding it once the row has
        scrolled past the first screen of items, since pixel position for
        scrolled-past items isn't available from the container API."""
        try:
            cursor = self.getControl(_ID_CURSOR)
            if cid not in _ROW_TOP or pos is None or pos > _CURSOR_MAX_POS:
                cursor.setVisible(False)
                return
            x = _ROW_LEFT + pos * _ITEM_WIDTH - 3
            y = _ROW_TOP[cid] - 3
            cursor.setPosition(x, y)
            cursor.setVisible(True)
        except Exception:
            pass

    # ---------------------------------------------------------------- actions

    def _play_hero(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        pos = self._hero_pos if self._hero_pos < len(films) else 0
        self._play_film(films[pos])

    def _play_row_item(self, cid):
        rmap = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2, _ID_ROW3: 3}
        row  = rmap[cid]
        try:
            ctrl  = self.getControl(cid)
            pos   = ctrl.getSelectedPosition()
            films = self._film_rows[row] if row < len(self._film_rows) else []
            if films and 0 <= pos < len(films):
                self._play_film(films[pos])
        except Exception as e:
            xbmc.log('[Starfleet/Home] _play_row_item: %s' % e, xbmc.LOGERROR)

    def _play_film(self, film):
        if self._playing:
            return
        self._playing = True
        import threading as _t
        def _reset_playing():
            import time; time.sleep(4)
            self._playing = False
        _t.Thread(target=_reset_playing, daemon=True).start()

        import urllib.parse as _up
        source  = film.get('source', 'tmdb')
        media   = film.get('media_type', 'movie')
        tmdb_id = str(film.get('tmdb_id', film.get('id', '')))
        title   = _up.quote(film.get('title', ''))
        year    = _up.quote(str(film.get('year', '')))

        # For TV shows: close the home window and navigate into the show page
        if source == 'tmdb' and media == 'tv':
            self._nav('meta_tv_show&tmdb_id=%s' % tmdb_id)
            return

        # All playback actions: use xbmc.Player().play() so the home window stays in doModal().
        # ActivateWindow(Videos,...) must NOT be used from within doModal — when setResolvedUrl(False)
        # is returned, Kodi navigates to the parent plugin URL which re-opens the home window.
        li = xbmcgui.ListItem(film.get('title', ''))
        li.setProperty('IsPlayable', 'true')

        if source == 'ade':
            # Call directly in a thread — never go through the plugin URL resolver
            # because setResolvedUrl(False) causes Kodi to navigate to plugin:// root
            # which re-opens the home window in a cascade.
            ade_id_raw   = str(film.get('ade_id', film.get('id', '')))
            ade_slug_raw = str(film.get('ade_slug', ''))
            film_title   = film.get('title', '')
            import threading
            def _ade_thread(aid=ade_id_raw, aslug=ade_slug_raw, t=film_title):
                try:
                    from resources.lib.afdb_router import adult_ade_play_direct
                    adult_ade_play_direct(aid, aslug, t)
                except Exception as exc:
                    xbmc.log('[Starfleet/Home] ade direct play error: %s' % exc, xbmc.LOGERROR)
            threading.Thread(target=_ade_thread, daemon=True).start()
            return

        if source == 'tmdb':
            url = 'plugin://plugin.video.starfleet/?action=meta_movie_play&tmdb_id=%s&title=%s&year=%s' % (tmdb_id, title, year)
        elif source == 'sports':
            event_id   = _up.quote(str(film.get('event_id', '')))
            event_path = _up.quote(str(film.get('event_path', '')))
            sport_slug = film.get('sport_slug', '')
            url = 'plugin://plugin.video.starfleet/?action=sports_event_play&event_id=%s&event_path=%s&sport_slug=%s&title=%s' % (event_id, event_path, sport_slug, title)
        elif source == 'pandamovies':
            slug = film.get('slug', '')
            film_url = _up.quote(film.get('url', ''))
            url = 'plugin://plugin.video.starfleet/?action=adult_panda_play&slug=%s&film_url=%s&title=%s' % (slug, film_url, title)
        elif source == 'hqporner':
            slug = film.get('slug', '')
            film_url = _up.quote(film.get('url', ''))
            url = 'plugin://plugin.video.starfleet/?action=adult_hqp_play&slug=%s&film_url=%s&title=%s' % (slug, film_url, title)
        else:
            film_id = str(film.get('id', ''))
            slug    = film.get('slug', '')
            url = 'plugin://plugin.video.starfleet/?action=afdb_play_search&film_id=%s&film_slug=%s&film_title=%s' % (film_id, slug, title)

        xbmc.Player().play(url, li)

    def _show_info(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        film = films[self._hero_pos] if self._hero_pos < len(films) else films[0]
        xbmcgui.Dialog().textviewer(
            film.get('title', 'Info'),
            film.get('plot', film.get('overview', 'No description available.'))
        )

    def _nav(self, action):
        # Guard: ignore rapid repeated clicks while a nav is in progress.
        if self._navigating:
            return
        self._navigating = True
        xbmc.log('[Starfleet/Home] nav → %s' % action, xbmc.LOGINFO)
        self.pending_nav = action
        # Write the target action to nav.lock BEFORE closing.  The dispatcher
        # reads this file, returns a dummy item so the Videos container has
        # focus, then fires Container.Update itself from CPythonInvoker(5)
        # (a fresh invoker, so sleep() is reliable and no shutdown race).
        try:
            import xbmcvfs as _xbmcvfs, os as _os
            _dd = _xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
            open(_os.path.join(_dd, 'nav.lock'), 'w').write(action)
        except Exception:
            pass
        # Signal background threads to stop (prevents GUI crash from
        # _push_when_ready calling set_context on a closed window).
        if self._close_event:
            self._close_event.set()
        self.close()
        # Fire ActivateWindow from a background thread ~600 ms after home closes.
        # The delay lets the Videos root-URL plugin call (CPythonInvoker N+1)
        # complete and dismiss its DialogBusy before ActivateWindow fires —
        # ActivateWindow is silently refused while any modal dialog is active.
        #
        # Two-step navigation (not a single ActivateWindow straight to the
        # category): ActivateWindow always makes its target URL the base of
        # that window's own back-history, discarding whatever came before.
        # Jumping straight to ?action=X therefore means Back from X exits
        # Kodi's addon context entirely — the addon's own root is never
        # pushed onto history, so dispatcher's "reopen Home" check on root
        # visits never gets a chance to run.
        #
        # Instead: ActivateWindow to the bare root FIRST (while nav.lock is
        # still fresh, so dispatcher's main_menu sees the transition-in-
        # progress branch and returns quietly instead of relaunching Home),
        # THEN remove nav.lock, THEN Container.Update into the target
        # category — a normal in-window navigation that pushes properly.
        # Back from the category now correctly pops to the bare root, which
        # (with nav.lock gone) really is dispatcher's "user came back" case
        # and reopens Home for real.
        import threading as _threading
        def _fire_nav(a=action):
            xbmc.sleep(600)
            xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.starfleet/)')
            xbmc.sleep(400)
            # Remove nav.lock now so the NEXT time root is visited (i.e. when
            # the user later presses Back out of this category) dispatcher
            # treats it as a genuine "return to Home" request.
            try:
                import xbmcvfs as _xv, os as _o
                _dd = _xv.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
                _o.remove(_o.join(_dd, 'nav.lock'))
            except Exception:
                pass
            xbmc.executebuiltin(
                'Container.Update(plugin://plugin.video.starfleet/?action=%s)' % a
            )
        # Non-daemon so run_home.py's main() waits for this thread before exiting —
        # daemon threads are killed when the main thread returns, which would prevent
        # ActivateWindow from ever firing.
        _threading.Thread(target=_fire_nav, daemon=False).start()
