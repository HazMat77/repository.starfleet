import requests as _req
from bs4 import BeautifulSoup
import datetime
import re

_RE_TSTEK_GAME_CARD = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/game/[^"#\s]{4,120})"[^>]*>'
    r'.*?<span>\s*(\d+:\d+\s*(?:am|pm)[^<]*?)\s*</span>'
    r'.*?<div[^>]+class="row[^"]*my-auto[^"]*"[^>]*>\s*([^<]{3,120}?)\s*</div>',
    re.IGNORECASE | re.DOTALL
)
TSTEK_BASE      = 'https://totalsportek24.is'
_TSTEK_SLUGS = {
    'soccer':  'soccer-streams',
    'nfl':     'nfl-streams',
    'nba':     'nba-streams',
    'nhl':     'nhl-streams',
    'mlb':     'mlb-stream',
    'ufc':     'ufc-streams',
    'boxing':  'boxing-streams',
    'f1':      'f1-streams',
    'cfb':     'college-football-streams',
    'ncaab':   'college-basketball-streams',
    'wwe':     'wwe-streams',
    'tennis':  'tennis-streams',
    'rugby':   'rugby-streams',
    'cricket': 'cricket-streams',
    'motogp':  'motogp-streams',
}
_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5, redirect=False)
        )
        _session.mount('https://', a)
    return _session
    
def _get(url, timeout=12):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text
    
if __name__ == '__main__':
    sport_slug = 'soccer'
    sport_url = '%s/%s' % (TSTEK_BASE, _TSTEK_SLUGS.get(sport_slug, sport_slug + '-streams'))
    print(f'{datetime.datetime.utcnow()} VGU _tstek_events {sport_slug} before get url {sport_url}')
    try:
        html = _sess().get(sport_url, timeout=5,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
                           
        print(f'{datetime.datetime.utcnow()} html len {len(html)}')
        soup = BeautifulSoup(html, 'html.parser')
        print(f'{datetime.datetime.utcnow()} parsed')
        all_as = soup.find_all('a')
        print(f'{datetime.datetime.utcnow()} find_all a')
        for a in all_as:
            if a.has_attr('href') and a['href'].find('totalsportek24.is/game/') != -1:
                href = a['href']
                span = a.find('span')
                if span is not None:
                    raw_time = span.text.strip()
                    rows = a.find_all('div', class_='row')
                    if len(rows) == 0:
                        continue
                    title = ''
                    for row in rows:
                        if len(title) == 0:
                            title = row.text.strip()
                        else:
                            title = title + ' - ' + row.text.strip()
                    print(f'Found {href} {raw_time} {title}')
        print(f'{datetime.datetime.utcnow()} soup done')
        
        searched = _RE_TSTEK_GAME_CARD.search(html)
        print(f'{datetime.datetime.utcnow()} searched {searched}')
        _iter_cards = _RE_TSTEK_GAME_CARD.finditer(html)
        print(f'{datetime.datetime.utcnow()} iter {_iter_cards}')
        for m in _iter_cards:
            print(f'{datetime.datetime.utcnow()} m {m}')
    except Exception as e:
        print(f'Got exception {e} during get')
    print(f'{datetime.datetime.utcnow()} done')
