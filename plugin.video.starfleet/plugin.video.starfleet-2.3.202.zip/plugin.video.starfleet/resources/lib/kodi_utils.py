# -*- coding: utf-8 -*-
"""
resources/lib/kodi_utils.py — Kodi version-aware helpers.
"""
import xbmc

try:
    _KODI_VER = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
except Exception:
    _KODI_VER = 19


def set_video_info(li, info):
    """Set video metadata on a ListItem.

    Uses InfoTagVideo setters (Kodi 20+) to avoid the setInfo() deprecation
    warning. Falls back to li.setInfo('video', info) on Kodi 19 and below.
    Unknown keys are silently ignored — callers can pass the full info dict
    without filtering.
    """
    if not info:
        return
    if _KODI_VER < 20:
        li.setInfo('video', info)
        return
    tag = li.getVideoInfoTag()
    for k, v in info.items():
        if v is None:
            continue
        try:
            if   k == 'title':         tag.setTitle(str(v))
            elif k == 'plot':          tag.setPlot(str(v))
            elif k == 'mpaa':          tag.setMpaa(str(v))
            elif k == 'mediatype':     tag.setMediaType(str(v))
            elif k == 'year':          tag.setYear(int(v) if v else 0)
            elif k == 'season':        tag.setSeason(int(v) if v else -1)
            elif k == 'episode':       tag.setEpisode(int(v) if v else -1)
            elif k == 'rating':        tag.setRating(float(v) if v else 0.0)
            elif k == 'duration':      tag.setDuration(int(v) if v else 0)
            elif k == 'imdbnumber':    tag.setIMDbNumber(str(v))
            elif k == 'tvshowtitle':   tag.setTvShowTitle(str(v))
            elif k == 'aired':         tag.setFirstAired(str(v))
            elif k == 'premiered':     tag.setPremiered(str(v))
            elif k == 'playcount':     tag.setPlaycount(int(v) if v else 0)
            elif k == 'tagline':       tag.setTagLine(str(v))
            elif k == 'originaltitle': tag.setOriginalTitle(str(v))
            elif k == 'trailer':       tag.setTrailer(str(v))
            elif k == 'genre':
                genres = [v] if isinstance(v, str) else list(v)
                if len(genres) == 1 and ',' in genres[0]:
                    genres = [g.strip() for g in genres[0].split(',') if g.strip()]
                tag.setGenres(genres)
            elif k == 'studio':
                studios = [v] if isinstance(v, str) else list(v)
                if len(studios) == 1 and ',' in studios[0]:
                    studios = [s.strip() for s in studios[0].split(',') if s.strip()]
                tag.setStudios(studios)
            elif k == 'director':
                dirs = [v] if isinstance(v, str) else list(v)
                if len(dirs) == 1 and ',' in dirs[0]:
                    dirs = [d.strip() for d in dirs[0].split(',') if d.strip()]
                tag.setDirectors(dirs)
            elif k == 'cast':
                cast_list = list(v) if v else []
                actors = []
                for item in cast_list:
                    if isinstance(item, str):
                        actors.append(xbmc.Actor(item))
                    elif isinstance(item, dict):
                        actors.append(xbmc.Actor(
                            item.get('name', ''),
                            item.get('role', ''),
                            item.get('order', 0),
                            item.get('thumbnail', ''),
                        ))
                if actors:
                    tag.setCast(actors)
        except Exception:
            pass
