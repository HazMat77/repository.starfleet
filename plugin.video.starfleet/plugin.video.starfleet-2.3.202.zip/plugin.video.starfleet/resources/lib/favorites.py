# -*- coding: utf-8 -*-
"""
resources/lib/favorites.py

Favorites — save movies and TV shows for quick access.

Schema per entry:
  {
    "media_type": "movie" | "tv",
    "tmdb_id":    "12345",
    "imdb_id":    "tt1234567",
    "title":      "Breaking Bad",
    "year":       "2008",
    "thumb":      "https://...",
    "fanart":     "https://...",
    "ts":         1719600000       # unix timestamp added
  }

Key = "movie:tmdb_12345" or "tv:tmdb_67890"
"""

import json
import os
import time
import threading
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.kodi_utils import set_video_info as _svi

_LOCK = threading.Lock()
_DB   = None


def _db_path():
    profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/')
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'favorites.json')


def _load():
    global _DB
    if _DB is not None:
        return _DB
    try:
        p = _db_path()
        if xbmcvfs.exists(p):
            with open(p, 'r', encoding='utf-8') as f:
                _DB = json.load(f)
        else:
            _DB = {}
    except Exception as e:
        xbmc.log('[Starfleet/Favorites] load error: %s' % e, xbmc.LOGWARNING)
        _DB = {}
    return _DB


def _save():
    try:
        with open(_db_path(), 'w', encoding='utf-8') as f:
            json.dump(_DB, f, indent=2)
    except Exception as e:
        xbmc.log('[Starfleet/Favorites] save error: %s' % e, xbmc.LOGWARNING)


def _key(media_type, tmdb_id):
    return '%s:tmdb_%s' % (media_type, tmdb_id)


# ── Public API ────────────────────────────────────────────────────────────────

def add(media_type, tmdb_id, title, year='', imdb_id='', thumb='', fanart=''):
    if not tmdb_id:
        return
    k = _key(media_type, tmdb_id)
    with _LOCK:
        db = _load()
        db[k] = {
            'media_type': media_type,
            'tmdb_id':    str(tmdb_id),
            'imdb_id':    imdb_id or '',
            'title':      title or '',
            'year':       str(year or ''),
            'thumb':      thumb or '',
            'fanart':     fanart or '',
            'ts':         int(time.time()),
        }
        _save()
    xbmc.log('[Starfleet/Favorites] Added: %s (%s)' % (title, media_type), xbmc.LOGINFO)


def remove(media_type, tmdb_id):
    k = _key(media_type, tmdb_id)
    with _LOCK:
        db = _load()
        if k in db:
            title = db[k].get('title', '')
            del db[k]
            _save()
            xbmc.log('[Starfleet/Favorites] Removed: %s' % title, xbmc.LOGINFO)


def is_favorite(media_type, tmdb_id):
    k = _key(media_type, tmdb_id)
    return k in _load()


def get_all():
    db = _load()
    items = list(db.values())
    items.sort(key=lambda x: x.get('ts', 0), reverse=True)
    return items


def get_movies():
    return [i for i in get_all() if i.get('media_type') == 'movie']


def get_tv():
    return [i for i in get_all() if i.get('media_type') == 'tv']


# ── Kodi UI ───────────────────────────────────────────────────────────────────

def favorites_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '⭐ Favorites')
    xbmcplugin.setContent(handle, 'files')

    movies = get_movies()
    tv     = get_tv()

    xbmcgui.ListItem  # just import check
    from xbmcgui import ListItem as _LI

    def _add_dir(label, params, plot=''):
        li = _LI(label=label)
        _svi(li, {'title': label, 'plot': plot})
        xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)

    _add_dir('🎬  Favourite Movies  (%d)' % len(movies),
             {'action': 'favorites_movies'},
             plot='Your saved movies')
    _add_dir('📺  Favourite TV Shows  (%d)' % len(tv),
             {'action': 'favorites_tv'},
             plot='Your saved TV shows')
    _add_dir('🗑️  Clear All Favorites',
             {'action': 'favorites_clear_confirm'},
             plot='Remove everything from your favorites list')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def favorites_movies(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎬 Favourite Movies')
    xbmcplugin.setContent(handle, 'movies')

    movies = get_movies()
    if not movies:
        xbmcgui.Dialog().notification('Favorites', 'No favourite movies yet',
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        return

    for m in movies:
        label = m['title']
        if m.get('year'):
            label += '  (%s)' % m['year']
        li = xbmcgui.ListItem(label=label)
        _svi(li, {
            'title':     m['title'],
            'year':      int(m['year']) if str(m.get('year', '')).isdigit() else 0,
            'mediatype': 'movie',
        })
        li.setArt({
            'thumb':  m.get('thumb', ''),
            'poster': m.get('thumb', ''),
            'fanart': m.get('fanart', ''),
        })
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([
            ('Remove from Favorites',
             'RunPlugin(%s)' % build_url({'action': 'favorites_remove',
                                          'media_type': 'movie',
                                          'tmdb_id': m['tmdb_id'],
                                          'refresh': '1'}))
        ])
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':  'meta_movie_play',
                       'tmdb_id': m['tmdb_id'],
                       'title':   m['title'],
                       'imdb_id': m.get('imdb_id', ''),
                       'year':    m.get('year', '')}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def favorites_tv(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '📺 Favourite TV Shows')
    xbmcplugin.setContent(handle, 'tvshows')

    shows = get_tv()
    if not shows:
        xbmcgui.Dialog().notification('Favorites', 'No favourite TV shows yet',
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        return

    for s in shows:
        label = s['title']
        if s.get('year'):
            label += '  (%s)' % s['year']
        li = xbmcgui.ListItem(label=label)
        _svi(li, {
            'title':     s['title'],
            'year':      int(s['year']) if str(s.get('year', '')).isdigit() else 0,
            'mediatype': 'tvshow',
        })
        li.setArt({
            'thumb':  s.get('thumb', ''),
            'poster': s.get('thumb', ''),
            'fanart': s.get('fanart', ''),
        })
        li.addContextMenuItems([
            ('Remove from Favorites',
             'RunPlugin(%s)' % build_url({'action': 'favorites_remove',
                                          'media_type': 'tv',
                                          'tmdb_id': s['tmdb_id'],
                                          'refresh': '1'}))
        ])
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':  'meta_tv_show',
                       'tmdb_id': s['tmdb_id']}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def favorites_add_action(media_type, tmdb_id, title, year='', imdb_id='',
                          thumb='', fanart=''):
    """Called via RunPlugin context menu — adds item and shows toast."""
    add(media_type, tmdb_id, title, year=year, imdb_id=imdb_id,
        thumb=thumb, fanart=fanart)
    xbmcgui.Dialog().notification(
        'Starfleet',
        'Added to Favorites: %s' % title,
        xbmcgui.NOTIFICATION_INFO, 3000
    )


def favorites_remove_action(media_type, tmdb_id, refresh=False):
    """Called via RunPlugin context menu — removes item and optionally refreshes."""
    with _LOCK:
        db = _load()
        k  = _key(media_type, tmdb_id)
        title = db.get(k, {}).get('title', '')
        if k in db:
            del db[k]
            _save()
    xbmcgui.Dialog().notification(
        'Starfleet',
        'Removed from Favorites: %s' % title,
        xbmcgui.NOTIFICATION_INFO, 3000
    )
    if refresh:
        xbmc.executebuiltin('Container.Refresh')


def favorites_clear_confirm():
    """Ask for confirmation then wipe everything."""
    if xbmcgui.Dialog().yesno('Clear Favorites',
                               'Remove ALL favorites? This cannot be undone.'):
        global _DB
        with _LOCK:
            _DB = {}
            _save()
        xbmcgui.Dialog().notification('Starfleet', 'Favorites cleared',
                                       xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')
