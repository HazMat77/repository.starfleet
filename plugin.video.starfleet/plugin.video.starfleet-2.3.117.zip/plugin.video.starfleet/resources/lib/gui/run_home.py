"""
Starfleet Home GUI launcher.
Opens the home window immediately with cached data, then refreshes in the background.
"""
import sys
import os
import json
import threading
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon


def _show_loading_splash(addon, data_dir):
    """Show a 45-second flashing 'Loading' dialog on first run or after an update."""
    version_file = os.path.join(data_dir, 'last_version.txt')
    current_ver  = addon.getAddonInfo('version')
    try:
        with open(version_file, 'r') as _f:
            saved_ver = _f.read().strip()
    except Exception:
        saved_ver = ''
    if saved_ver == current_ver:
        return
    # New install or update — show splash
    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet', 'Loading… please wait')
    messages = [
        'Initialising Starfleet…',
        'Calibrating warp drive…',
        'Engaging deflector array…',
        'Syncing star charts…',
        'Almost ready…',
    ]
    total_ms  = 45000
    step_ms   = 500
    steps     = total_ms // step_ms
    msg_cycle = len(messages)
    for i in range(steps):
        if dlg.iscanceled():
            break
        pct = int((i / steps) * 100)
        dlg.update(pct, messages[(i // 4) % msg_cycle])
        xbmc.sleep(step_ms)
    dlg.close()
    try:
        with open(version_file, 'w') as _f:
            _f.write(current_ver)
    except Exception:
        pass


def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)

    data_dir  = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(data_dir, exist_ok=True)
    data_file = os.path.join(data_dir, 'home_data.json')

    _show_loading_splash(addon, data_dir)

    empty    = [[], [], []]
    contexts = {'default': empty, 'movies': empty, 'tv': empty,
                'sports': empty, 'live': empty, 'adult': empty}

    # Load whatever is cached — instant, never blocks
    try:
        with open(data_file, 'r', encoding='utf-8') as f:
            raw = json.load(f)
        if isinstance(raw, list):
            contexts['default'] = raw
            contexts['movies']  = raw
            contexts['tv']      = raw
        else:
            # Merge loaded keys over the empty skeleton so all contexts always exist
            for k, v in raw.items():
                contexts[k] = v
        d = contexts.get('default', empty)
        xbmc.log('[Starfleet/Home] loaded %d/%d/%d films from cache' % (
            len(d[0]), len(d[1]), len(d[2])), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/Home] no cache yet (%s), showing empty home' % e, xbmc.LOGINFO)

    # Open the window immediately — user sees it under a second
    try:
        from resources.lib.gui.home import HomeWindow
        win = HomeWindow('Starfleet-Home.xml', addon_path, 'Default', '1080i',
                         contexts=contexts)

        # Background refresh — updates in-memory contexts AND saves to disk for next launch
        def _refresh():
            try:
                from resources.lib import afdb_router as _ar
                _ctx = _ar.get_home_carousel_data()
                _tmp = data_file + '.tmp'
                with open(_tmp, 'w', encoding='utf-8') as _f:
                    json.dump(_ctx, _f)
                os.replace(_tmp, data_file)
                _d = _ctx.get('default', empty)
                xbmc.log('[Starfleet/Home] background refresh done: %d/%d/%d' % (
                    len(_d[0]), len(_d[1]), len(_d[2])), xbmc.LOGINFO)
                # Push fresh contexts into the live window so all nav tabs show correct carousels
                try:
                    win._contexts = _ctx
                except Exception:
                    pass
            except Exception as _e:
                xbmc.log('[Starfleet/Home] background refresh error: %s' % _e, xbmc.LOGWARNING)
            finally:
                try:
                    win.setProperty('sf_loaded', '1')
                except Exception:
                    pass

        t = threading.Thread(target=_refresh, daemon=True)
        t.start()

        win.doModal()
        nav_action = win.pending_nav
        del win
        if nav_action:
            # Wait for the WindowXML modal to fully de-register from Kodi's window stack.
            # doModal() returns as soon as close() is called, but Kodi keeps the window
            # registered as an active modal for a short period after. ActivateWindow is
            # refused while any modal is active.
            # getCurrentWindowDialogId() only tracks type="dialog" windows; our home is
            # type="window" opened with doModal(), so we use System.HasModalDialog instead.
            for _ in range(40):
                xbmc.sleep(50)
                if not xbmc.getCondVisibility('System.HasModalDialog'):
                    break
            xbmc.sleep(200)
            xbmc.executebuiltin('ActivateWindow(Home)')
            xbmc.sleep(250)
            xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.starfleet/?action=%s)' % nav_action)
    except Exception as e:
        xbmc.log('[Starfleet/Home] window error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
