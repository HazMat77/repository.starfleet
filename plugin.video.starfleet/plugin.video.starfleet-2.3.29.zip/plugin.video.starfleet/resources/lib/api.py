# -*- coding: utf-8 -*-
"""
resources/lib/api.py �?? Starfleet Kodi Plugin

LIVE TV �?? Two stream backends
==============================
TVA / Québecor  �?? Brightcove Playback API (account 5813221784001).
                  referenceId per channel; returns Akamai-tokened HLS URL.
Global News     �?? Direct HLS from corusappservices.com.
                  Media ID is scraped from globalnews.ca, then Corus API returns HLS URL.
"""

import json
import re
import sqlite3
import time
import os

import xbmc
import xbmcaddon
import xbmcvfs
import requests

ADDON    = xbmcaddon.Addon()
PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_DB = os.path.join(PROFILE, 'cache.db')

# Lazy geo_spoof import — only imported at call time so settings.xml is read fresh
def _geo():
    from resources.lib import geo_spoof
    return geo_spoof

# ---------------------------------------------------------------------------
# TVA �?? Brightcove Playback API config (stable credentials from tvaplus.ca)
# ---------------------------------------------------------------------------
_BC_ACCOUNT    = '5813221784001'
_BC_POLICY_KEY = (
    'BCpkADawqM2hsFvZUZm6C4LPMbysl5Q-rMeLlFTZPj5BBvQRNHYYYXYB9zGUnCYXUeLn'
    'FjFa9Z4uUpBoie-uaIsInp1oa88qYdIy3vmsrTxuANN2hqo4XsvX3YW1OfPocwoHZ6fZQ'
    '4m4ZttzlW_yhkrBbkXXlg3T4Sa2FA'
)
_BC_PLAYBACK   = 'https://edge.api.brightcove.com/playback/v1/accounts/%s/videos/ref:%s'

TVA_CHANNELS = [
    {
        'id':           'tva',
        'title':        'TVA',
        'reference_id': 'tva_6341846685112',
        'thumbnail':    'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/TVA_%28TV_network%29_logo.svg/200px-TVA_%28TV_network%29_logo.svg.png',
        'group':        'Québecor',
        'description':  'La chaîne principale de TVA �?? en direct',
    },
    {
        'id':           'tva-sports',
        'title':        'TVA Sports',
        'reference_id': 'TVASports_1_BO_VMedia',
        'thumbnail':    'https://upload.wikimedia.org/wikipedia/en/thumb/5/5a/TVA_Sports_logo.svg/200px-TVA_Sports_logo.svg.png',
        'group':        'Québecor',
        'description':  'Chaîne sportive de TVA �?? en direct',
    },
    {
        'id':           'tva-sports-2',
        'title':        'TVA Sports 2',
        'reference_id': 'TVASports_2_BO_VMedia',
        'thumbnail':    'https://upload.wikimedia.org/wikipedia/en/thumb/5/5a/TVA_Sports_logo.svg/200px-TVA_Sports_logo.svg.png',
        'group':        'Québecor',
        'description':  'TVA Sports 2 — en direct',
    },
]

# ---------------------------------------------------------------------------
# Global News �?? channel definitions (HLS via Corus API)
# ---------------------------------------------------------------------------
GLOBAL_NEWS_CHANNELS = [
    {'id': 'global-national',    'title': 'Global News National',    'region': 'national',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-bc',          'title': 'Global News BC',          'region': 'bc',          'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-toronto',     'title': 'Global News Toronto',     'region': 'toronto',     'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-edmonton',    'title': 'Global News Edmonton',    'region': 'edmonton',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-calgary',     'title': 'Global News Calgary',     'region': 'calgary',     'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-halifax',     'title': 'Global News Halifax',     'region': 'halifax',     'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-winnipeg',    'title': 'Global News Winnipeg',    'region': 'winnipeg',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-montreal',    'title': 'Global News Montreal',    'region': 'montreal',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-okanagan',    'title': 'Global News Okanagan',    'region': 'okanagan',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-saskatoon',   'title': 'Global News Saskatoon',   'region': 'saskatoon',   'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-regina',      'title': 'Global News Regina',      'region': 'regina',      'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-lethbridge',  'title': 'Global News Lethbridge',  'region': 'lethbridge',  'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-kingston',    'title': 'Global News Kingston',    'region': 'kingston',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-peterborough','title': 'Global News Peterborough','region': 'peterborough','thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
]

# For backwards compat with router �?? combined list exposed as DAI_LIVE_CHANNELS

# ---------------------------------------------------------------------------
# CBC / Radio-Canada — live channels
# ---------------------------------------------------------------------------
# CBC uses Brightcove account 1632977552001.
# Policy key can be extracted from https://www.cbc.ca/player/ DevTools
# (search for BCpkAD... in script responses) and updated via addon settings.
_CBC_ACCOUNT              = '1632977552001'
_CBC_POLICY_KEY_DEFAULT   = (
    'BCpkADawqM3nOfHhTNd2EkOLmLsO0pXimCkHJVsG4aQ5tIQh9E58Xsh4bFGQ'
    'QBf_y5dBFhMGxcYbQciFefN9WR0T0WFLRFk4HHwFLdGx9GJcqC8bROTtjhYR'
    'kp3WFBQ'
)

CBC_CHANNELS = [
    {
        'id':           'cbc-news-network',
        'title':        'CBC News Network',
        'cbc_type':     'gem_scrape',
        'gem_slug':     'cbcnn',
        'hls_fallback': 'https://cbcnewslive.akamaized.net/hls/live/2028077/cbcnewslive/master.m3u8',
        'thumbnail':    'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/CBC_News_Network.svg/200px-CBC_News_Network.svg.png',
        'group':        'CBC',
        'description':  'CBC News Network — 24/7 Canadian news (geo-locked)',
    },
    {
        'id':           'cbc-tv-english',
        'title':        'CBC Television',
        'cbc_type':     'gem_scrape',
        'gem_slug':     'cbcprimary',
        'hls_fallback': '',
        'thumbnail':    'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/CBC_television_logo.svg/200px-CBC_television_logo.svg.png',
        'group':        'CBC',
        'description':  'CBC (English) — live (geo-locked)',
    },
    {
        'id':           'ici-radio-canada',
        'title':        'ICI Radio-Canada Tele',
        'cbc_type':     'gem_scrape',
        'gem_slug':     'icirc',
        'hls_fallback': '',
        'thumbnail':    'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/ICI_Radio-Canada_Tel%C3%A9_logo.svg/200px-ICI_Radio-Canada_Tel%C3%A9_logo.svg.png',
        'group':        'Radio-Canada',
        'description':  'ICI Radio-Canada Tele — en direct (geo-bloque)',
    },
]
# ---------------------------------------------------------------------------
# Noovo (Bell Media / Québecor) — live channels
# ---------------------------------------------------------------------------
# Noovo main: dynamic Brightcove scraping from noovo.ca/en-direct
# Noovo sub-channels: FAST CloudFront streams (free, no auth)
NOOVO_CHANNELS = [
    {
        'id':         'noovo',
        'title':      'Noovo',
        'noovo_type': 'live',
        'thumbnail':  'https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Noovo_logo.svg/200px-Noovo_logo.svg.png',
        'group':      'Noovo',
        'description': 'Noovo — chaîne généraliste québécoise en direct',
    },
    {
        'id':      'noovo-cinema',
        'title':   'Noovo Cinéma',
        'hls_url': 'https://dk4ogs46bjxcw.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-xr1ct045l70mz/Noovo_Cinema.m3u8',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Noovo_logo.svg/200px-Noovo_logo.svg.png',
        'group':   'Noovo',
        'description': 'Noovo Cinéma — films en continu (FAST)',
    },
    {
        'id':      'noovo-comedies',
        'title':   'Noovo Comédies',
        'hls_url': 'https://d2s8iafdyzconc.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-6x2p3ho0vw00a/Noovo_Comedies_Home.m3u8',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Noovo_logo.svg/200px-Noovo_logo.svg.png',
        'group':   'Noovo',
        'description': 'Noovo Comédies — comédies en continu (FAST)',
    },
    {
        'id':      'noovo-telerealites',
        'title':   'Noovo Téléréalités',
        'hls_url': 'https://d29qczaufx5vc3.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-dxg2k6h0o2l6i/Noovo_Telerealites.m3u8',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Noovo_logo.svg/200px-Noovo_logo.svg.png',
        'group':   'Noovo',
        'description': 'Noovo Téléréalités — téléréalités en continu (FAST)',
    },
]

DAI_LIVE_CHANNELS = TVA_CHANNELS + GLOBAL_NEWS_CHANNELS + CBC_CHANNELS + NOOVO_CHANNELS

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json',
    'Accept-Language': 'en-CA,en;q=0.9,fr-CA;q=0.8',
}

TTL_LIVE = 5 * 60

# ---------------------------------------------------------------------------
# HTTP session
# ---------------------------------------------------------------------------
_session = None

def _get_session():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=10, max_retries=2)
        _session.mount('https://', adapter)
    return _session

# ---------------------------------------------------------------------------
# SQLite cache
# ---------------------------------------------------------------------------
def _db():
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE)
    conn = sqlite3.connect(CACHE_DB, timeout=5)
    conn.execute('CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT, expires REAL)')
    conn.commit()
    return conn

def _cache_get(key):
    try:
        conn = _db()
        row = conn.execute('SELECT value, expires FROM cache WHERE key=?', (key,)).fetchone()
        conn.close()
        if row and row[1] > time.time():
            return json.loads(row[0])
    except Exception as e:
        xbmc.log('[Starfleet] cache_get error: %s' % e, xbmc.LOGWARNING)
    return None

def _cache_set(key, data, ttl):
    try:
        conn = _db()
        conn.execute('INSERT OR REPLACE INTO cache (key, value, expires) VALUES (?,?,?)',
                     (key, json.dumps(data), time.time() + ttl))
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log('[Starfleet] cache_set error: %s' % e, xbmc.LOGWARNING)

# ---------------------------------------------------------------------------
# Public: channel list
# ---------------------------------------------------------------------------

def get_live_channels():
    """Return list of live channel dicts."""
    return DAI_LIVE_CHANNELS


# ---------------------------------------------------------------------------
# TVA �?? Brightcove Playback API (Akamai-tokened HLS, valid ~1 hour per fetch)
# ---------------------------------------------------------------------------

def _get_tva_stream(channel):
    """Fetch a time-limited HLS URL from Brightcove Playback API. Returns HLS URL or None."""
    ref_id = channel.get('reference_id', '')
    if not ref_id:
        xbmc.log('[Starfleet] TVA: no reference_id for channel %s' % channel.get('id'), xbmc.LOGERROR)
        return None

    ck = 'tva_bc_stream_' + ref_id
    cached = _cache_get(ck)
    if cached:
        return cached

    url = _BC_PLAYBACK % (_BC_ACCOUNT, ref_id)
    xbmc.log('[Starfleet] TVA Brightcove GET %s' % url, xbmc.LOGINFO)

    geo = _geo()
    sess = geo.session() if geo.is_enabled() else _get_session()
    try:
        r = sess.get(
            url,
            headers={'Accept': 'application/json;pk=' + _BC_POLICY_KEY,
                     'Origin': 'https://www.tvaplus.ca'},
            timeout=12
        )
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet] TVA Brightcove error: %s' % e, xbmc.LOGERROR)
        return None

    sources = data.get('sources') or []
    hls = next((s['src'] for s in sources if s.get('src', '').endswith('.m3u8')
                or 'hls' in s.get('type', '')), None)
    if not hls:
        hls = next((s['src'] for s in sources if s.get('src')), None)

    if hls:
        xbmc.log('[Starfleet] TVA stream OK: %s' % hls[:80], xbmc.LOGINFO)
        _cache_set(ck, hls, 3000)   # Akamai token valid ~1 h; cache 50 min
        return geo.decorate_url(hls) if geo.is_enabled() else hls

    xbmc.log('[Starfleet] TVA: no src in Brightcove sources %s' % sources, xbmc.LOGWARNING)
    return None


# ---------------------------------------------------------------------------
# Global News �?? scrape media ID from globalnews.ca, fetch HLS from Corus API
# ---------------------------------------------------------------------------

_GNCA_FEED = 'https://globalnews.ca/gnca-ajax-redesign/video-entry/%s/'
import urllib.parse as _urlparse

def _get_global_news_stream(channel):
    """
    1. Fetch globalnews.ca/live/{region}/ to get JW Player media ID
    2. Hit Corus GNCA API to get direct HLS URL
    """
    region = channel.get('region', '')
    ck = 'global_news_hls_%s' % region
    cached = _cache_get(ck)
    if cached:
        return cached

    live_url = 'https://globalnews.ca/live/%s/' % region
    try:
        r = _get_session().get(live_url, timeout=12)
        r.raise_for_status()
        m = re.search(r'"mediaId"\s*:\s*"([a-f0-9\-]{36})"', r.text)
        if not m:
            xbmc.log('[Starfleet] GlobalNews: no mediaId on %s' % live_url, xbmc.LOGWARNING)
            return None
        media_id = m.group(1)
        xbmc.log('[Starfleet] GlobalNews %s mediaId=%s' % (region, media_id), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet] GlobalNews page error: %s' % e, xbmc.LOGERROR)
        return None

    feed_url = _GNCA_FEED % _urlparse.quote('{"id":"%s"}' % media_id)
    try:
        r2 = _get_session().get(feed_url, timeout=12)
        r2.raise_for_status()
        items = r2.json()
        if not items:
            return None
        sources = items[0].get('sources', [])
        hls = next((s['file'] for s in sources if s.get('type') == 'hls'), None)
        if hls:
            xbmc.log('[Starfleet] GlobalNews HLS: %s' % hls[:80], xbmc.LOGINFO)
            _cache_set(ck, hls, 300)   # cache 5 min �?? live streams rotate tokens
            return hls
    except Exception as e:
        xbmc.log('[Starfleet] GlobalNews feed error: %s' % e, xbmc.LOGERROR)

    return None



# ---------------------------------------------------------------------------
# Noovo — dynamic Brightcove scraping from noovo.ca/en-direct
# ---------------------------------------------------------------------------

def _get_noovo_stream(channel):
    """
    Fetch the live HLS stream for Noovo.

    Strategy:
      1. Fetch noovo.ca/en-direct, extract the JS bundle ID.
      2. Fetch the JS bundle, extract Brightcove data-account + data-video-id.
      3. Call the Brightcove Playback API (no policy key — Noovo account is public).
      4. Return decorated URL with geo_spoof headers if enabled.
    """
    ck = 'noovo_stream_live'
    geo = _geo()
    sess = geo.session() if geo.is_enabled() else _get_session()

    cached = _cache_get(ck)
    if cached:
        return geo.decorate_url(cached) if geo.is_enabled() else cached

    # Step 1 — live page → JS bundle ID
    try:
        r = sess.get('https://noovo.ca/en-direct', timeout=12,
                     headers={'Accept': 'text/html', 'Referer': 'https://noovo.ca/'})
        r.raise_for_status()
        m = re.search(r'dist/js/noovo\.([a-z0-9]+)\.', r.text)
        if not m:
            xbmc.log('[Starfleet] Noovo: no JS bundle ID in en-direct', xbmc.LOGWARNING)
            return None
        bundle_id = m.group(1)
    except Exception as e:
        xbmc.log('[Starfleet] Noovo page error: %s' % e, xbmc.LOGERROR)
        return None

    # Step 2 — JS bundle → Brightcove account + video ID
    try:
        js_url = 'https://noovo.ca/dist/js/noovo.%s.js' % bundle_id
        r2 = sess.get(js_url, timeout=15)
        r2.raise_for_status()
        js = r2.text
        m_acct = re.search(r'data-account[=\s"\']+([0-9]{8,})', js)
        m_vid  = re.search(r'data-video-id[=\s"\']+([0-9]{8,})', js)
        if not (m_acct and m_vid):
            xbmc.log('[Starfleet] Noovo JS: Brightcove IDs not found in bundle', xbmc.LOGWARNING)
            return None
        bc_account  = m_acct.group(1)
        bc_video_id = m_vid.group(1)
        xbmc.log('[Starfleet] Noovo BC account=%s vid=%s' % (bc_account, bc_video_id), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet] Noovo JS error: %s' % e, xbmc.LOGERROR)
        return None

    # Step 3 — Brightcove Playback API (public account, no policy key required)
    bc_url = ('https://edge.api.brightcove.com/playback/v1/accounts/%s/videos/%s'
               % (bc_account, bc_video_id))
    try:
        r3 = sess.get(bc_url, timeout=12,
                      headers={'Accept': 'application/json',
                               'Origin': 'https://noovo.ca'})
        r3.raise_for_status()
        sources = r3.json().get('sources', [])
        hls = next((s['src'] for s in sources
                    if s.get('src', '').endswith('.m3u8')
                    or 'hls' in s.get('type', '')), None)
        if hls:
            xbmc.log('[Starfleet] Noovo HLS OK: %s' % hls[:80], xbmc.LOGINFO)
            _cache_set(ck, hls, 300)
            return geo.decorate_url(hls) if geo.is_enabled() else hls
    except Exception as e:
        xbmc.log('[Starfleet] Noovo Brightcove error: %s' % e, xbmc.LOGERROR)

    return None


def _get_direct_hls(channel):
    """Return a direct HLS URL (FAST channels, no scraping needed)."""
    url = channel.get('hls_url', '')
    if not url:
        return None
    geo = _geo()
    return geo.decorate_url(url) if geo.is_enabled() else url




# ---------------------------------------------------------------------------
# CBC — Gem live page scrape + Brightcove fallback
# ---------------------------------------------------------------------------

def _get_cbc_stream(channel):
    """
    Fetch a live HLS stream URL for a CBC / Radio-Canada channel.

    Strategy:
      1. Scrape the CBC Gem live-TV page (e.g. /player/play/live-tv/cbcnn)
         to extract the Brightcove video ID embedded in page JSON.
      2. Hit the CBC Brightcove Playback API with that ID.
      3. Fall back to channel['hls_fallback'] (known Akamai URL) on error.
      4. Decorate the final URL with Canadian IP headers via geo_spoof.
    """
    ch_id = channel['id']
    ck    = 'cbc_stream_%s' % ch_id

    geo   = _geo()
    sess  = geo.session() if geo.is_enabled() else _get_session()

    cached = _cache_get(ck)
    if cached:
        return geo.decorate_url(cached) if geo.is_enabled() else cached

    gem_slug = channel.get('gem_slug', '')
    video_id = ''

    # Step 1 — Scrape Gem page for Brightcove video ID
    if gem_slug:
        page_url = 'https://www.cbc.ca/player/play/live-tv/%s' % gem_slug
        try:
            r = sess.get(page_url, timeout=12,
                         headers={'Referer': 'https://www.cbc.ca/',
                                  'Accept': 'text/html'})
            r.raise_for_status()
            html = r.text
            # Try various patterns CBC has used over time
            for pat in (
                r'"contentId"\s*:\s*"(\d+)"',
                r'data-clip-id="(\d+)"',
                r'"videoId"\s*:\s*"(\d+)"',
                r'brightcove[^}]*["\']id["\']\s*:\s*["\'](\d{10,})',
            ):
                m = re.search(pat, html)
                if m:
                    video_id = m.group(1)
                    break
            if not video_id:
                xbmc.log('[Starfleet] CBC: no videoId on %s' % page_url, xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet] CBC page error (%s): %s' % (gem_slug, e), xbmc.LOGERROR)

    # Step 2 — Brightcove Playback API
    hls = ''
    if video_id:
        policy_key = ADDON.getSetting('cbc_policy_key') or _CBC_POLICY_KEY_DEFAULT
        bc_url = ('https://edge.api.brightcove.com/playback/v1/accounts/%s/videos/%s'
                  % (_CBC_ACCOUNT, video_id))
        try:
            r2 = sess.get(bc_url, timeout=12,
                          headers={'Accept': 'application/json;pk=' + policy_key,
                                   'Origin': 'https://www.cbc.ca'})
            r2.raise_for_status()
            data    = r2.json()
            sources = data.get('sources', [])
            hls = next((s['src'] for s in sources
                        if s.get('src', '').endswith('.m3u8')
                        or 'hls' in s.get('type', '')), '')
            if hls:
                xbmc.log('[Starfleet] CBC stream OK: %s' % hls[:80], xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet] CBC Brightcove error: %s' % e, xbmc.LOGERROR)

    # Step 3 — Fallback to known direct HLS
    if not hls:
        hls = channel.get('hls_fallback', '')
        if hls:
            xbmc.log('[Starfleet] CBC using HLS fallback for %s' % ch_id, xbmc.LOGWARNING)

    if hls:
        _cache_set(ck, hls, 300)    # 5 min — live stream tokens rotate
        return geo.decorate_url(hls) if geo.is_enabled() else hls

    xbmc.log('[Starfleet] CBC: no stream found for %s' % ch_id, xbmc.LOGERROR)
    return None


# ---------------------------------------------------------------------------
# Public: get stream URL for any live channel
# ---------------------------------------------------------------------------

def get_live_stream_url(channel_or_asset_key):
    """
    Accepts either a full channel dict or a bare asset_key string (legacy).
    Returns a playable HLS URL or None.
    """
    # Legacy: bare asset_key string passed from old router code
    if isinstance(channel_or_asset_key, str):
        asset_key = channel_or_asset_key
        # Find channel in list
        ch = next((c for c in DAI_LIVE_CHANNELS if c.get('asset_key') == asset_key), None)
        if ch is None:
            # Might be a TVA channel �?? construct minimal dict
            ch = {'asset_key': asset_key, 'live_url': '', 'region': ''}
        channel_or_asset_key = ch

    channel = channel_or_asset_key

    # Route by channel type
    if channel.get('cbc_type'):
        return _get_cbc_stream(channel)
    elif channel.get('noovo_type'):
        return _get_noovo_stream(channel)
    elif channel.get('hls_url'):
        return _get_direct_hls(channel)
    elif 'region' in channel and channel['region']:
        return _get_global_news_stream(channel)
    elif 'reference_id' in channel and channel['reference_id']:
        return _get_tva_stream(channel)
    else:
        xbmc.log('[Starfleet] Unknown channel type: %s' % channel, xbmc.LOGWARNING)
        return None


# ---------------------------------------------------------------------------
# Re-export live source helpers so router only imports from api
# ---------------------------------------------------------------------------
from resources.lib.live_sources import (
    get_samsung_channels,
    get_plex_channels,
    get_pluto_channels,
    refresh_pluto,
)
