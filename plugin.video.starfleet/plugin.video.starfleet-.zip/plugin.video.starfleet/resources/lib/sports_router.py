﻿# -*- coding: utf-8 -*-
"""
resources/lib/sports_router.py

Kodi UI for the Sports section.

Menu:
  Sports → [NFL, NBA, MLB, NHL, UFC, Boxing, Soccer, F1, CFB, NCAAB, CFL, WWE]
         → Today's Games  (event list for the selected sport)
         → click game → dialog: Link 1, Link 2, ... → play
"""

import re
import time as _time
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmcplugin
from resources.lib.gui import progress_dialog as _pdlg
from resources.lib.gui.select_dialog import select as _select_dialog


def _fmt_local_time(start_ts):
    """Convert UTC unix timestamp → human-readable local device time string."""
    if not start_ts:
        return ''
    try:
        local = _time.localtime(int(start_ts))
        now   = _time.localtime()
        # 12-hour clock, no leading zero
        t_str = _time.strftime('%I:%M %p', local).lstrip('0') or _time.strftime('%I:%M %p', local)
        # Day label
        if local.tm_year == now.tm_year and local.tm_yday == now.tm_yday:
            day = 'Today'
        elif local.tm_year == now.tm_year and local.tm_yday == now.tm_yday + 1:
            day = 'Tomorrow'
        else:
            # Cross-platform: avoid %-d (Linux) / %#d (Windows) — just use tm_mday
            day = '%s %s %d' % (_time.strftime('%a', local), _time.strftime('%b', local), local.tm_mday)
        return '%s %s' % (day, t_str)
    except Exception:
        return ''

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')


def _progress(msg):
    d = _pdlg.DialogProgress()
    d.create('Starfleet Sports', msg)
    d.update(5)
    return d


# ── Sport categories ──────────────────────────────────────────────────────────

def sports_menu(handle, build_url):
    """Top-level sports menu: show each sport category as a folder."""
    from resources.lib import json_data as _jd

    xbmcplugin.setPluginCategory(handle, 'Sports')
    xbmcplugin.setContent(handle, 'files')

    # Hockey hub — all leagues from onhockey.tv
    hockey_li = xbmcgui.ListItem(label='🏒  Hockey')
    hockey_li.setArt({'thumb': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png',
                      'icon':  'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'})
    hockey_li.setInfo('video', {'title': '🏒  Hockey'})
    xbmcplugin.addDirectoryItem(handle, build_url({'action': 'hockey_menu'}), hockey_li, True)

    cats = _jd.get_all_categories()

    for cat in cats:
        li = xbmcgui.ListItem(label=cat['label'])
        li.setArt({'thumb': cat['icon'], 'icon': cat['icon']})
        li.setInfo('video', {'title': cat['label']})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':      'sports_events',
                       'sport_slug':  cat['slug'],
                       'sport_label': cat['label'],
                       'sport_icon':  cat['icon'],
                       'tsdb_sport':  cat.get('tsdb_sport', '')}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Events list for a sport ───────────────────────────────────────────────────

def sports_events(handle, build_url, sport_slug, sport_label='', sport_icon='', tsdb_sport=''):
    """List today's and upcoming events for a sport category."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '%s' % (sport_label or sport_slug.upper()))
    xbmcplugin.setContent(handle, 'files')

    if sport_slug == 'mlb':
        mlb_net_li = xbmcgui.ListItem(label='📺  MLB Network  [COLOR red]LIVE 24/7[/COLOR]')
        mlb_net_li.setArt({'thumb': _MLB_NETWORK_ICON, 'icon': _MLB_NETWORK_ICON})
        mlb_net_li.setInfo('video', {'title': 'MLB Network', 'plot': '24/7 MLB Network live TV channel.'})
        mlb_net_li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'sports_event_play',
                       'event_id':   'mlb_network_live',
                       'event_path': _MLB_NETWORK_PATH,
                       'sport_slug': 'mlb',
                       'title':      'MLB Network'}),
            mlb_net_li, False
        )

    cold = _cache.get('sport_ev4_%s' % sport_slug) is None
    dlg  = _progress('Loading %s events...' % (sport_label or sport_slug.upper())) if cold else None
    events = _ss.get_sport_events(sport_slug, tsdb_sport=tsdb_sport)
    if dlg:
        dlg.close()

    if not events:
        xbmcgui.Dialog().notification(
            'Starfleet Sports',
            'No events found for %s' % sport_slug.upper(),
            xbmcgui.NOTIFICATION_INFO
        )
        return

    xbmc.log('[Starfleet/Sports] rendering %d %s events, first start_ts=%s' % (
        len(events), sport_slug, events[0].get('start_ts', 'MISSING') if events else 'N/A'), xbmc.LOGINFO)
    for ev in events:
        local_time = _fmt_local_time(ev.get('start_ts', 0))
        if ev.get('is_live'):
            time_tag = '[COLOR red]🔴 LIVE[/COLOR]'
        elif local_time:
            time_tag = '[COLOR yellow]%s[/COLOR]' % local_time
        else:
            # start_ts was 0 — the source (usually TheSportsDB for niche/combat
            # sports) had no parseable date/time for this event. Show TBD rather
            # than nothing, so it doesn't look like a display bug.
            time_tag = '[COLOR gray]TBD[/COLOR]'

        label = '%s  %s' % (time_tag, ev['title']) if time_tag else ev['title']

        league = ev.get('league', '')
        plot_parts = []
        if league and league.upper() != sport_slug.upper():
            plot_parts.append(league)
        if local_time and not ev.get('is_live'):
            plot_parts.append(local_time)
        if ev.get('is_live'):
            score_str = ev.get('plot', '')
            if score_str:
                plot_parts.append('🔴 ' + score_str)
            else:
                plot_parts.append('🔴 LIVE NOW')
        if ev.get('venue'):
            plot_parts.append('📍 ' + ev['venue'])
        plot = ' • '.join(plot_parts)

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': ev['title'],
            'plot':  plot,
        })

        # Home team badge → thumb/icon; away badge → fanart (shown as background)
        home_badge = ev.get('home_badge', '') or ev.get('logo', '') or sport_icon
        away_badge = ev.get('away_badge', '') or home_badge
        li.setArt({'thumb': home_badge, 'icon': home_badge, 'fanart': away_badge})

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':      'sports_event_play',
                       'event_id':    ev['id'],
                       'event_path':  ev['path'],
                       'sport_slug':  sport_slug,
                       'title':       ev['title']}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Play an event — show stream picker dialog ─────────────────────────────────

def sports_event_play(handle, event_id='', event_path='', sport_slug='', title=''):
    """
    Fetch available stream links for the event and show a dialog picker.
    Merges ISE streams (event_path) + Roxiestreams (sport_slug).
    """
    from resources.lib import sports_sources as _ss

    dlg = _progress('Fetching stream links...')
    streams = _ss.get_event_streams(event_path, event_id, sport_slug, title)
    dlg.close()

    if not streams:
        xbmcgui.Dialog().ok(
            'Starfleet Sports — %s' % title,
            'No stream links available yet.\n\n'
            'This event may not have started, or stream links will appear '
            'a few minutes before/after kick-off.\n\n'
            'Try again when the event is live.'
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # Build dialog options — show source + quality
    def _fmt_option(i, s):
        src  = s.get('source', '')
        lbl  = s.get('label', 'Stream')
        qual = s.get('quality', '')
        parts = ['[%s]' % src] if src else []
        parts.append(lbl)
        if qual and qual not in lbl:
            parts.append('(%s)' % qual)
        return '%d. %s' % (i + 1, ' '.join(parts))

    options = [_fmt_option(i, s) for i, s in enumerate(streams)]

    if len(streams) == 1:
        chosen_url = streams[0]['url']
    else:
        idx = _select_dialog(
            '%s — Choose stream' % title, options
        )
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen_url = streams[idx]['url']

    _play_stream(handle, chosen_url, title)


def replay_play(handle, url='', title=''):
    """Play a single already-resolved Replay source (resources/lib/
    replay_sources.py's get_replay_sources() already did the picking —
    home.py's custom-skin flow calls this with one chosen url/title,
    same as sports_event_play calls _play_stream after its own picker).
    Reuses _play_stream as-is: Replay's URLs are the same mix (bare .m3u8,
    ok.ru/Dailymotion/Filemoon/YouTube embed pages) this function already
    resolves via ResolveURL -> generic iframe-chain fallback for live
    sports, PLUS magnet: URIs (sport-video.org.ua's torrent-derived
    sources and the generic torrent_sources.search_all() results) which
    _play_stream now resolves via the addon's own debrid resolver instead
    — see that function's own docstring."""
    if not url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    _play_stream(handle, url, title)


_OKRU_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
_RE_OKRU_ID = re.compile(r'(?:videoembed|video|live)/(\d+)')
# Same relative quality ranking ResolveURL's own OKRu plugin uses internally,
# reused here so this picks the same "best available" tier.
_OKRU_QUALITY_ORDER = ('full', 'hd', 'sd', 'low', 'lowest', 'mobile')


def _resolve_okru(url):
    """Own OK.ru resolver, bypassing ResolveURL's OKRu plugin entirely for
    this one host. Confirmed live 2026-08-16 this codebase's own metadata
    POST + direct CDN GET works cleanly end-to-end with a single fixed
    User-Agent — the actual bug wasn't ok.ru's CDN at all (a plain
    requests.get() of the resolved URL returned a real 200/video/mp4
    immediately), it's that ResolveURL's OKRu plugin signs the CDN URL
    against its own internally-generated common.RAND_UA, then hands the
    URL back to be pipe-tagged for playback — if Kodi's own player engine
    doesn't send that EXACT UA string back out again (the same
    pipe-tagged-header reliability gap this file's own _play_stream
    comment already documents for .m3u8/Referer on Firestick), okcdn.ru's
    signature check on the mismatched UA causes CDVDDemuxFFmpeg to hang
    for ~30s and then fail with 'could not open file' — confirmed live
    from a real kodi.log, not guessed. Using ONE fixed UA for both the
    metadata fetch AND the pipe-tagged playback header removes that gap
    entirely instead of trusting ResolveURL's own UA rotation to survive
    Kodi's playback pipeline intact.
    Returns the direct CDN URL (already pipe-tagged with the matching
    User-Agent) or None."""
    m = _RE_OKRU_ID.search(url)
    if not m:
        return None
    media_id = m.group(1)
    try:
        import requests as _req
        r = _req.post('http://www.ok.ru/dk?cmd=videoPlayerMetadata',
                      data={'mid': media_id}, headers={'User-Agent': _OKRU_UA}, timeout=12)
        r.raise_for_status()
        data = r.json()
        if 'error' in data:
            return None
        vids = data.get('videos') or []
        if not vids:
            return None
        by_quality = {v.get('name'): v.get('url') for v in vids if v.get('url')}
        chosen = None
        for q in _OKRU_QUALITY_ORDER:
            if q in by_quality:
                chosen = by_quality[q]
                break
        if not chosen:
            chosen = vids[0].get('url')
        if not chosen:
            return None
        from urllib.parse import quote as _uq
        return '%s|User-Agent=%s' % (chosen, _uq(_OKRU_UA, safe=''))
    except Exception as e:
        xbmc.log('[Starfleet/Sports] _resolve_okru error: %s' % e, xbmc.LOGWARNING)
        return None


def _play_stream(handle, url, title=''):
    """Resolve the URL via resolveurl/resolvers then set as resolved URL."""
    resolved = url
    referer = ''

    # magnet: URIs (sport-video.org.ua's torrent-derived sources and the
    # generic torrent_sources.search_all() results, both wired into
    # replay_sources.get_replay_sources() — see that module's docstring)
    # need the addon's own debrid resolver, not ResolveURL — ResolveURL has
    # no concept of a magnet: URI at all and would just hand it straight
    # back unresolved rather than actually play it. Reuses
    # resolvers.resolve_magnet(), the exact same debrid entry point
    # afdb_router.py's adult_stream_play() already uses for XXXClub's own
    # torrent-play path, instead of a second one-off implementation here.
    # Once resolved, `resolved` no longer equals `url`, so every
    # OK.ru/ResolveURL/iframe-chain step below is automatically skipped by
    # its own pre-existing `if resolved == url:` guard — no separate
    # branching needed for the rest of this function, and the same final
    # .m3u8-vs-plain ListItem + setResolvedUrl block at the bottom handles
    # a debrid-resolved URL exactly like every other resolved URL already.
    if url.startswith('magnet:'):
        from resources.lib import resolvers as _resolvers
        try:
            debrid_resolved = _resolvers.resolve_magnet(url)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] resolve_magnet error: %s' % e, xbmc.LOGWARNING)
            debrid_resolved = None
        if debrid_resolved:
            resolved = debrid_resolved
        else:
            xbmc.log('[Starfleet/Sports] magnet could not be resolved via debrid (no debrid '
                     'service configured, or this torrent is not instantly cached): %s'
                     % url[:90], xbmc.LOGWARNING)
            xbmcgui.Dialog().ok(
                'Starfleet Sports — %s' % title,
                'No playable source found for this torrent.\n\n'
                'This usually means no debrid service (Real-Debrid, AllDebrid, '
                'Premiumize, TorBox) is configured in Settings, or this '
                'particular torrent isn\'t instantly cached there yet.'
            )
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return

    elif 'ok.ru' in url or 'odnoklassniki.ru' in url:
        okru = _resolve_okru(url)
        if okru:
            resolved = okru

    # Try ResolveURL if available (skipped for ok.ru/magnet — both handled
    # above already; ResolveURL's own OKRu plugin is the thing that was
    # actually failing, see _resolve_okru's own docstring)
    if resolved == url:
        try:
            import resolveurl
            hmf = resolveurl.HostedMediaFile(url)
            if hmf.valid_url():
                r = hmf.resolve()
                if r:
                    resolved = r
        except ImportError:
            pass
        except Exception as e:
            xbmc.log('[Starfleet/Sports] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    # Neither ResolveURL nor any host-specific case recognized this URL —
    # several aggregators (confirmed for SportSurge) hand back a plain
    # wrapper page, not a direct stream: e.g. resports.cfd is pure ad
    # markup around a single <iframe>, which itself embeds ANOTHER wrapper
    # page, which finally has the real signed .m3u8 URL inline in its own
    # JS (3 hops, confirmed live). Kodi's demuxer just fails silently
    # trying to probe the wrapper HTML as video ("error probing input
    # format") — this generic iframe-chain follower fixes that instead of
    # only working for the specific embed domains ResolveURL/embed_resolver
    # already recognize by name.
    if resolved == url:
        try:
            from resources.lib import embed_resolver
            stream, stream_referer = embed_resolver.resolve_generic_iframe_chain(url)
            if stream:
                resolved = stream
                referer = stream_referer or ''
        except Exception as e:
            xbmc.log('[Starfleet/Sports] embed_resolver iframe-chain error: %s' % e, xbmc.LOGWARNING)

    # These signed CDN links 403 with no Referer at all (confirmed live for
    # the SportSurge chain above) — Kodi's player doesn't send one unless
    # it's encoded into the URL, so it's appended here using this
    # codebase's existing url|Referer=... pipe syntax (same convention as
    # the DaddyLive/FalconStreams/Scenes resolvers).
    if referer and resolved.startswith('http'):
        from urllib.parse import quote as _uq
        resolved = '%s|Referer=%s' % (resolved, _uq(referer, safe=''))

    # .m3u8 links need inputstream.adaptive with explicit header properties —
    # the plain pipe-tagged path|Referer=...&User-Agent=... string alone isn't
    # reliably honored on every platform (confirmed live on Firestick: the
    # custom Referer/User-Agent were silently dropped and replaced with the
    # device's own default browser UA, causing the CDN to 403 valid, freshly
    # resolved links). router.py's _hls_item() already does this correctly
    # for Live TV — reuse it here instead of the old raw-path approach.
    if '.m3u8' in resolved.lower():
        from resources.lib.router import _hls_item
        li = _hls_item(resolved, title)
        li.setProperty('IsPlayable', 'true')
    else:
        li = xbmcgui.ListItem(label=title, path=resolved)
        li.setInfo('video', {'title': title})
        li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle, True, li)


# ── Hockey hub (onhockey.tv — all leagues) ────────────────────────────────────

_HOCKEY_ICON = 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'

# All leagues onhockey.tv covers — always shown even with 0 current games
_HOCKEY_ALL_LEAGUES = [
    'NHL', 'AHL', 'KHL', 'OHL', 'WHL', 'QMJHL', 'ECHL',
    'SHL', 'DEL', 'Liiga', 'Czech', 'Slovak', 'EIHL',
    'NCAA', 'IIHF', 'PWHL', 'NWHL', 'PHF',
    'AIHL', 'NZIHL',
]


_NHL_NETWORK_ICON = 'https://upload.wikimedia.org/wikipedia/en/thumb/1/1f/NHL_Network_logo.svg/200px-NHL_Network_logo.svg.png'
# Resolved directly via daddylive.mov (onhockey.tv's own DaddyLive proxy/channel=663
# path stopped working — the site now redirects through daddylive.mov's channel
# pages instead). See sports_sources._dlchan_streams / _dlchan_stream_url.
# 'dlchan:' (not 'daddylive:') — that prefix is already used by the separate,
# pre-existing daddylive.eu multi-sport event scraper in sports_sources.py.
_NHL_NETWORK_PATH = 'dlchan:NHL-Network'

_MLB_NETWORK_ICON = 'https://upload.wikimedia.org/wikipedia/en/thumb/a/a6/MLB_Network_logo.svg/200px-MLB_Network_logo.svg.png'
# MLB Network has three known-good daddylive.mov channel-id variants
# (captured directly from the site — each is a distinct mirror, not a
# fallback chain). Resolved in parallel and offered as Link 1/2/3 in the
# stream picker rather than picking one silently, since any one mirror
# can go down independently of the others.
_MLB_NETWORK_PATH = 'dlchan_multi:MLB-Network|MLB-Network-US|399'


def hockey_menu(handle, build_url):
    """List all leagues from onhockey.tv as browsable folders."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, 'Hockey')
    xbmcplugin.setContent(handle, 'files')

    # NHL Network — 24/7 live TV channel (DaddyLive stream 663 via onhockey.tv)
    nhl_net_li = xbmcgui.ListItem(label='📺  NHL Network  [COLOR red]LIVE 24/7[/COLOR]')
    nhl_net_li.setArt({'thumb': _NHL_NETWORK_ICON, 'icon': _NHL_NETWORK_ICON})
    nhl_net_li.setInfo('video', {'title': 'NHL Network', 'plot': '24/7 NHL Network live TV channel.'})
    nhl_net_li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({'action':     'sports_event_play',
                   'event_id':   'nhl_network_live',
                   'event_path': _NHL_NETWORK_PATH,
                   'sport_slug': 'nhl',
                   'title':      'NHL Network'}),
        nhl_net_li, False
    )

    dlg    = _progress('Loading hockey schedule...')
    events = _ss.get_onhockey_events()
    dlg.close()

    # Count games per league from schedule
    league_counts = {}
    for ev in events:
        lg = ev.get('league', 'NHL')
        league_counts[lg] = league_counts.get(lg, 0) + 1

    # Build final league list: known ones first (in order), then any from schedule not in list
    shown = set()
    leagues = []
    for lg in _HOCKEY_ALL_LEAGUES:
        leagues.append((lg, league_counts.get(lg, 0)))
        shown.add(lg)
    for lg in sorted(league_counts):
        if lg not in shown:
            leagues.append((lg, league_counts[lg]))

    for lg, count in leagues:
        if count > 0:
            label = '%s  (%d upcoming)' % (lg, count)
        else:
            label = '%s  — off season' % lg
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': _HOCKEY_ICON, 'icon': _HOCKEY_ICON})
        li.setInfo('video', {'title': lg, 'plot': '%d games in current schedule' % count})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'hockey_league_events', 'league': lg}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def hockey_league_events(handle, build_url, league='NHL'):
    """List upcoming games for a specific hockey league from onhockey.tv."""
    from resources.lib import sports_sources as _ss

    xbmcplugin.setPluginCategory(handle, '%s' % league)
    xbmcplugin.setContent(handle, 'files')

    dlg    = _progress('Loading %s schedule...' % league)
    events = _ss.get_onhockey_events()
    dlg.close()

    league_events = [e for e in events if e.get('league', 'NHL') == league]

    if not league_events:
        xbmcgui.Dialog().notification(
            'Starfleet', 'No %s games scheduled right now' % league, xbmcgui.NOTIFICATION_INFO
        )
        return

    for ev in league_events:
        start_ts   = ev.get('start_ts', 0)
        date_label = ev.get('date_label', '')
        local_time = _fmt_local_time(start_ts) if start_ts else ''

        if ev.get('is_live'):
            time_tag = '[COLOR red]🔴 LIVE[/COLOR]'
        elif local_time:
            time_tag = '[COLOR yellow]%s[/COLOR]' % local_time
        elif date_label:
            time_tag = '[COLOR grey]%s[/COLOR]' % date_label
        else:
            time_tag = ''

        label = '%s  %s' % (time_tag, ev['title']) if time_tag else ev['title']
        plot  = local_time or date_label or ('🔴 LIVE NOW' if ev.get('is_live') else '')

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': ev['title'], 'plot': plot})
        li.setArt({'thumb': _HOCKEY_ICON, 'icon': _HOCKEY_ICON})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'sports_event_play',
                       'event_id':   ev['id'],
                       'event_path': ev['path'],
                       'sport_slug': 'hockey',
                       'title':      ev['title']}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
