# -*- coding: utf-8 -*-
"""
resources/lib/replay_sources.py

Replay scraper — PAST events (full fight/game replays with real dates),
architecturally separate from sports_sources.py's LIVE-sports scraping.
Investigated live 2026-08-16 against 4 candidate sites; all 4 turned out to
be real/scrapable (no CF/JS-challenge dead ends this time), but they split
cleanly across the 3 target categories rather than each covering all 3:

  UFC     — watchmmafull.com  (per-INDIVIDUAL-FIGHT pages, one URL per
             matchup) + fullfightreplays.com (per-CARD-SECTION links —
             Main Card/Prelims/Early Prelims, each with 2-3 alternate
             hosts). Both merged per numbered PPV event (e.g. "UFC 330")
             so a single event offers fight-by-fight AND full-card options
             side by side, per the picker design this module is built for.
  Boxing  — fullfightreplays.com (per-fight, multiple host "servers") +
             box.live/full-fight-replays (per-fight, single official
             broadcaster YouTube embed — confirmed live via PBC's own
             channel — but only once uploaded; many recent fights show the
             site's own honest "no replay yet" state, handled as empty).
  MLB     — mlblive.net only (per-GAME, single embed host). Deep real
             archive confirmed live back through the 2025 World Series
             (Dodgers vs Blue Jays, Games 1-7) via its year-indexed pages,
             though the live listing pages themselves are NOT paginated
             (confirmed live: /page/2 on every listing 404s) so only the
             ~10-16 most recent items per page are visible at once.

Confirmed dead ends: none of the 4 — see box.live's sister-site note below
for the one thing that ISN'T covered (MMA/UFC on box.live itself).

── Site-by-site findings (all confirmed live 2026-08-16) ──────────────────

watchmmafull.com (UFC/MMA):
  - Despite "UFC MMA BOXING KICKBOXING" in its own <title> tag, /tag/boxing
    returns zero results live — this site is UFC/MMA-only in practice.
  - Only browsable catalog is the homepage's "New Video" list — /events,
    /search and /page/2 all dead-end to a generic 404 template (confirmed
    live), so this source only ever surfaces whichever ~2 most-recent
    events happen to be on the homepage at fetch time (was UFC 330 +
    UFC Vegas 120, 12 individual fight pages each, when checked).
  - Real per-fight granularity: each matchup (e.g. "Islam Makhachev vs
    Ian Machado Garry") is its own page/URL — confirmed 24 distinct fight
    pages across 2 real events on 2 real different dates. No full-card
    bundle page exists (ufc-330-full-card.html style URLs all 404).
  - Stream mechanism varies PER EVENT (not per fight): UFC 330's fights
    all embed via playmate.to, which is cleanly resolvable with plain
    requests (see _wmf_resolve_fight docstring) to a real, playable ~48-
    minute HLS stream. UFC Vegas 120's fights all embedded via
    suisports.upns.xyz instead — a bare JS-SPA shell (empty <body>,
    everything bootstrapped client-side, fight id only in a URL #hash)
    with nothing server-rendered to scrape, the same dead-end class as
    this addon's other confirmed JS-SPA embeds. Handled by resolving
    playmate.to embeds and skipping (not returning a dead link for)
    anything else, logged at LOGINFO so it's visible without being noisy.
  - No per-event thumbnail anywhere (listing <img src=""> is a lazy-load
    placeholder with no data-src fallback; individual fight pages'
    og:image is also empty) — confirmed live. TMDB is this category's
    only real art source for events from this site specifically.

fullfightreplays.com (UFC AND Boxing):
  - Real multi-org combat-sports catalog: UFC, Boxing, Bellator, ONE
    Championship, Cage Warriors, BKFC, Invicta FC, KSW, K-1. Only UFC and
    Boxing are built out below since those are the 2 of 3 target
    categories it actually covers.
  - Single-page listings per category (/ufc, /boxing) with no working
    pagination (/ufc/page/2 and /boxing/page/2 both 404, confirmed live)
    — ~10 real events per category at check time, spanning roughly one to
    two months back (e.g. boxing: Errol Spence Jr. vs. Tim Tszyu, Jul 26
    2026, through Claressa Shields vs. Kaye Scott, Aug 15 2026).
  - UFC granularity is per-CARD-SECTION, not per-fight: "Main Card" (in
    2 quality tiers x up to 3 parts via Dailymotion, plus OK.ru and
    Filemoon-mirror alternates), "Prelims", "Early Prelims" — each
    section/host pairing is its own selectable link. This is the "full
    card" counterpart to watchmmafull.com's per-fight breakdown.
  - Boxing granularity is per-fight (as expected, one bout per card),
    multiple alternate-host "servers" (OK.ru + Filemoon-mirror, confirmed
    live) per fight.
  - Real per-event thumbnail confirmed live for every listing entry
    (/_pu/<n>/<id>.png|jpg — distinct, working image per event).
  - No CAPTCHA/CF/JS wall on any page hit (listing, event, or embed pages).

box.live/full-fight-replays (Boxing ONLY):
  - Confirmed live: this is boxing-only. The fight-detail page template
    itself says "Love MMA & UFC too? Try our sister site, Cage Walks" —
    an explicit, direct confirmation it does NOT cover UFC/MMA despite
    "full fight replays" reading generically. Not used for the UFC
    category at all as a result.
  - Deep, well-organized real catalog (/fight-results/ listed 38 distinct
    real recent bouts when checked, e.g. Spence vs Tszyu Jul 26 2026,
    Fundora vs Thurman Mar 28 2026) with a real per-fight detail page for
    each (/fights/<slug>/), each carrying a real date and 2 real fighter
    photos in its hero section.
  - Replay video, when present, is a single OFFICIAL broadcaster YouTube
    embed — confirmed live: Fundora vs Thurman's embed resolves via
    YouTube's own oEmbed to "PBC FULL FIGHT: Fundora vs Thurman | March
    28, 2026" on the real Premier Boxing Champions channel. Highest-
    legitimacy source of the 4, but NOT every fight has one yet — spot-
    checking 12 real fights live found only 2 with a replay uploaded so
    far; the rest show the site's own honest "Sorry, we couldn't find any
    replay videos... yet" message (handled as an empty result here, never
    a broken/fake link).

mlblive.net (MLB ONLY):
  - NFL/NBA nav links point off-site to sister domains (nfl-video.com,
    basketball-video.com) — confirmed this specific site is MLB-only.
  - Same site engine/template as fullfightreplays.com (same "/_pu/<n>/
    <id>" thumbnail path scheme, same "Server #N" + embed-host markup) —
    _ffr_parse_sources() below is reused as-is for MLB event pages.
  - Real, deep catalog: homepage + year-indexed listing pages go back to
    2021 including the complete real 2025 World Series game-by-game
    (Los Angeles Dodgers vs Toronto Blue Jays, Games 1 through 7, real
    dates Oct 24 - Nov 1 2025) confirmed live, plus the current 2026
    regular season (multiple real games checked for Aug 15 2026: Rangers
    @ Athletics, Royals @ Angels, Brewers @ Dodgers, etc). No listing page
    is paginated though (confirmed live 404 on /page/2 for every listing
    tried) — only the most-recent ~12-16 games per page/day are visible;
    older days are reachable only via the year-index pages, which
    themselves only surface a curated/recent slice, not exhaustive daily
    coverage. One game per event (no innings-level breakdown attempted —
    not offered by the site and not asked for).
  - Real per-event thumbnail confirmed live, same /_pu/ scheme as above.

sport-video.org.ua (UFC + Boxing + MLB, TORRENT-based — added 2026-08-16):
  - Multi-sport torrent index, real and live, no CF/JS wall anywhere in the
    chain (listing pages, detail pages, or the .torrent downloads
    themselves) — confirmed live end-to-end.
  - /baseball.html (+ numbered /baseball1.html..baseball6.html) is MLB —
    real per-game detail pages (e.g. /BRSPP150826.html = "Boston Red Sox at
    Pittsburgh Pirates 15.08.2026"). Real pagination confirmed live to run
    ONE page deeper than that: /baseball7.html and /baseball8.html are both
    real 200s with real distinct older games (back to 12.06.2024 on
    baseball8.html); /baseball9.html 404s, confirmed the true end.
  - /other.html (+ /other1.html..other25.html, confirmed live 200 through
    other25.html, other26.html 404s — a real 26-page-deep archive going
    back to April/May 2024) is a mixed bag: Formula 1, NASCAR, IndyCar,
    MotoGP, WRC, tennis, golf, cricket, athletics — AND, confirmed live,
    real UFC (title always starts "UFC ...", e.g. "UFC Fight Night Gamrot
    vs Salkilld", "UFC 329 McGregor vs Holloway 2") and Boxing (title
    starts "Boxing ..." for standalone cards, e.g. "Boxing Anthony Joshua
    vs Kristian Prenga", or "Zuffa Boxing N ..." for Dana White's Zuffa
    Boxing series) entries mixed in among the rest — roughly 3-5 real
    UFC/Boxing events per page. No separate combat-sports category page
    exists on this site; /other.html is genuinely where they live.
  - Each detail page has a real `<a href="./<Title> <DD.MM.YYYY>.mkv.torrent">`
    download link — never a magnet: URI directly. Two HTML template
    generations coexist across the archive (newer: onclick=window.open(...)
    thumbnails; older, pre-~mid-2026: plain rel="prettyPhoto" thumbnail
    links) — the listing parser below anchors only on the <strong>TITLE
    DATE</strong> heading and the following ./<slug>.html detail link, so
    it parses both generations the same way without caring which one a
    given page uses.
  - Downloading that .torrent file and deriving its info_hash from the raw
    bencoded 'info' dict (same technique torrent_sources.py's own
    _torrent_info_hash/_make_magnet already use for FreeJAVTorrent's
    identically torrent-file-only detail pages — reused here rather than a
    second bencode parser) produces a real, valid magnet: URI — confirmed
    live against 3 real detail pages spanning both template generations:
      "Boston Red Sox at Pittsburgh Pirates 15.08.2026" (MLB, new template)
        -> info_hash 6de0636d09f82b1991185997cf63d5934c760e99
      "UFC Fight Night Song vs Figueiredo 30.05.2026" (UFC, OLD template)
        -> info_hash a33ad29bdbc10880c79c67eb7a427e483190566a
      "UFC Fight Night Medic vs Rodriguez 01.08.2026" (UFC, new template)
        -> info_hash 684619ef06c9a2bd663579b2e6cbfcaac52b5764
  - Kept as its own separate 'sportvideo' source entry per event (not
    merged into the wmf/ffr/mlblive catalogs) — this site's own titles
    ("UFC Fight Night Song vs Figueiredo") don't reliably line up with the
    other sites' naming (fullfightreplays.com's "UFC Fight Night 284:
    Gamrot vs. Salkilld"), same "list separately rather than risk a wrong
    merge" call already made for Boxing's ffr-vs-box.live split above.
    get_replay_sources() resolves the magnet lazily (network + bencode
    parse only happen when a user actually opens the source picker for
    that event), cached 15 min same as every other per-event resolution
    in this module.

Generic multi-site torrent search (torrent_sources.search_all — the same
44-source engine Movies/TV/Adult already use, wired in for every Replay
event across all 3 sports, added 2026-08-16):
  - Called with just the event's own title text (no imdb_id/year — these
    are event names, not movie titles), same plain title-search mode
    search_knaben/search_1337x already support on their own.
  - UFC: real, correctly-matched results confirmed live for "UFC 330" — 10
    results, including actual real full main-card/prelims rips (e.g.
    "UFC.330.Makhachev.vs.Machado.Garry.Main.Card.And.Prelims.1080p.IPTV.
    MKV/H.265") alongside some legitimately-titled-but-not-the-full-event
    noise (PPV Countdown specials, Embedded vlog episodes — these carry
    "UFC 330" in their real title too, so they pass the title-word filter
    honestly; they're just not what most users mean by "the replay").
  - Boxing: real match confirmed live for "Errol Spence Jr. vs. Tim Tszyu"
    — 1 result, a real, well-seeded (94 seeds) Russian-broadcast IPTV rip
    with the fighters' names and date in its own title.
  - MLB: confirmed NOT a good match — 0 real results across several real
    title attempts tried live ("Boston Red Sox at Pittsburgh Pirates",
    "Los Angeles Dodgers vs Toronto Blue Jays World Series Game 7", "MLB
    World Series 2025 Game 7"). Individual regular-season (and even
    marquee playoff) games essentially don't get uploaded/named this way
    on general torrent sites the way PPV/fight-card events do. Still wired
    in unconditionally for MLB too (a big enough game could hit some day)
    rather than special-cased off — it's a harmless no-op exactly like
    every other empty-results case already handled throughout this module.
  - Each matched result is appended with 'magnet' (and 'url' set to the
    same magnet: URI) and a label like 'Knaben [1080p, 11 seeds]' so it's
    clearly distinguishable in the picker from the embed-page sources
    above it — see sports_router.py's _play_stream for the magnet: branch
    that routes these through the addon's existing debrid resolver instead
    of ResolveURL.

TMDB icon feasibility (checked live via /search/movie, api.themoviedb.org
using the same TMDB_KEYS this addon already uses in metadata.py):
  - UFC: excellent coverage. Every real event name pulled from the scrape
    above resolved to exactly one movie result with a real poster_path —
    "UFC 330" -> "UFC 330: Makhachev vs. Machado Garry" (2026-08-15,
    poster /dG6WMwBdPjSxlXFuBed4DKDAcdM.jpg), "UFC 329" -> "UFC 329:
    McGregor vs. Holloway 2", and even watchmmafull.com's own "UFC Vegas
    120" naming correctly fuzzy-matched to the same TMDB entry
    fullfightreplays.com calls "UFC Fight Night 284: Gamrot vs. Salkilld"
    (2026-08-08, poster /qSsDud1zHhodVHDs439xEj33OTK.jpg) — TMDB catalogs
    these as /search/movie results (PPV "event specials"), not /search/tv.
  - Boxing: also excellent. "Errol Spence Jr vs Tim Tszyu" ->
    "Errol Spence Jr. vs. Tim Tszyu" (2026-07-25, real poster), "Claressa
    Shields vs Kaye Scott" -> exact match (2026-08-15, real poster),
    "Fundora vs Thurman" -> "Sebastian Fundora vs. Keith Thurman"
    (2026-03-28, real poster) — same /search/movie pattern as UFC.
  - MLB: confirmed NOT catalogued, as expected. "Texas Rangers vs
    Athletics", "Los Angeles Dodgers vs Toronto Blue Jays World Series
    Game 7", "Milwaukee Brewers vs Los Angeles Dodgers" all returned 0
    results on both /search/movie and /search/tv — individual MLB games
    are not TMDB/IMDb entries. MLB events should fall back to a generic
    MLB/team logo (this addon already has ESPN CDN team-logo plumbing in
    sports_sources.py's _espn_logo — the mlblive.net per-event thumbnail
    below is also a real, live-confirmed fallback in the meantime).
  get_replay_poster() below wraps metadata.search_movies() for this.

Per-event site-native thumbnail (checked live per the follow-up request —
"does the source site itself expose a real per-event image, for the cases
TMDB won't have one"):
  - UFC:    watchmmafull.com has NONE (empty <img src> and empty og:image,
            confirmed live) — TMDB is the only real art source for events
            sourced from there. fullfightreplays.com DOES have one, a
            real distinct image per event (/_pu/<n>/<id>.png|jpg,
            confirmed live 200/real bytes) — carried in event['thumb']
            when an event has an ffr_url.
  - Boxing: fullfightreplays.com — same real per-event thumbnail as UFC
            above. box.live has no single fight-poster image, but DOES
            have 2 real per-fighter hero photos on every fight page
            (confirmed live, distinct real files, not the site's own
            'blank-fighter.png' placeholder for the fights checked) —
            carried as event['fighter1_photo']/['fighter2_photo'].
  - MLB:    mlblive.net has a real per-event thumbnail, same /_pu/ scheme
            as fullfightreplays.com (confirmed live) — carried in
            event['thumb'].

Return shape (per the eventual Sports > Replay > [UFC|Boxing|MLB] >
[dates] > [events] > [fight/source picker] menu this is built for):
  get_replay_dates(sport)          -> [{'date_key': 'YYYY-MM-DD',
                                         'label': 'Month D, YYYY'}, ...]
                                       most recent first.
  get_replay_events(sport, date_key) -> [event dict, ...] — each carries
                                       at least 'title', 'date_key',
                                       'date_label', 'id', 'thumb', plus
                                       internal fields (e.g. 'wmf_fights',
                                       'ffr_url', 'boxlive_url') that
                                       get_replay_sources() reads back.
                                       Pass one of these dicts straight
                                       into get_replay_sources() — no
                                       separate lookup needed.
  get_replay_sources(sport, event) -> [{'label': str, 'url': str}, ...] —
                                       individual fight/matchup entries
                                       AND full-card/section entries are
                                       both included as separate options
                                       whenever the source site offers
                                       both, never one-or-the-other. Magnet
                                       (torrent) entries — sport-video.org.ua
                                       and the generic torrent_sources.
                                       search_all() results, both added
                                       2026-08-16 — also carry a 'magnet'
                                       key equal to 'url' so the caller
                                       (sports_router.py's _play_stream)
                                       knows to route them through the
                                       addon's debrid resolver instead of
                                       ResolveURL.

Cache: event catalogs 20 min, individual source-page resolutions 15 min
(sport-video.org.ua's per-event magnet resolution included), TMDB poster
lookups 24h (via metadata.py's own cache calls). torrent_sources.search_all()
has its own separate 15 min cache, unaffected by this module's own TTLs.
"""

import re
import html as _html
import datetime
import xbmc
import xbmcaddon
import xbmcvfs
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests as _req
from resources.lib import cache as _cache

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_cache.init(_PROFILE + '/cache.db')

# Same browser-header convention as sports_sources.py/torrent_sources.py —
# no 'br' (Brotli) since decoding it needs an optional dependency this
# environment doesn't have; gzip/deflate are handled natively.
_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
}

_WMF_BASE     = 'https://watchmmafull.com'
_FFR_BASE     = 'https://fullfightreplays.com'
_BOXLIVE_BASE = 'https://box.live'
_MLBLIVE_BASE = 'https://mlblive.net'
_SVO_BASE     = 'https://sport-video.org.ua'


def _get(url, timeout=12, referer=''):
    try:
        headers = dict(_HEADERS)
        if referer:
            headers['Referer'] = referer
        r = _req.get(url, headers=headers, timeout=timeout)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Replay] GET %s: %s' % (url[:90], e), xbmc.LOGWARNING)
        return ''


_RE_WS = re.compile(r'\s+')


def _clean(t):
    return _RE_WS.sub(' ', _html.unescape(t or '')).strip(' - ')


def _parse_date(s):
    """Parse the various date-string formats used across the 4 sites
    ('August 15, 2026' / 'Aug 09, 2026' / 'Saturday, Aug 08 2026') into
    (date_key 'YYYY-MM-DD', label 'Month D, YYYY'). Returns (None, s) on
    failure so one malformed date can never crash a whole catalog fetch —
    the caller just drops that entry."""
    if not s:
        return None, ''
    s2 = re.sub(r'^[A-Za-z]+,\s*', '', s.strip())  # strip leading weekday, e.g. "Saturday, "
    s2 = s2.replace(',', '')
    for fmt in ('%B %d %Y', '%b %d %Y'):
        try:
            d = datetime.datetime.strptime(s2, fmt).date()
            return d.isoformat(), d.strftime('%B %d, %Y')
        except Exception:
            continue
    return None, s.strip()


# ── watchmmafull.com (UFC/MMA — per-fight) ──────────────────────────────────

_RE_WMF_ITEM = re.compile(
    r'<li class="video-item-compact">(.*?)</li>\s*(?=<li class="video-item-compact">|</ul>)',
    re.S)
_RE_WMF_TITLE     = re.compile(r'title="([^"]+)"', re.I)
_RE_WMF_HREF      = re.compile(r'href="(/[a-z0-9\-]+\.html)"\s+class="video-thumb-small"', re.I)
_RE_WMF_WATCH_BTN = re.compile(r'<a href="([^"]+)"\s+class="watch-link-btn', re.I)
_RE_WMF_FILECODE  = re.compile(r'/embed/([A-Za-z0-9]+)')


def _wmf_scrape_ufc():
    """See module docstring's watchmmafull.com section for what's confirmed
    live about this site's real catalog depth/shape. Groups the individual
    fight-card entries (title format always "EVENT - FIGHTER A vs.
    FIGHTER B - DATE", confirmed stable live) by event into one dict per
    real event, each carrying its list of per-fight page URLs."""
    html = _get(_WMF_BASE + '/')
    if not html:
        return []

    events = {}  # (event_name, date_key) -> event dict
    for block in _RE_WMF_ITEM.findall(html):
        href_m  = _RE_WMF_HREF.search(block)
        title_m = _RE_WMF_TITLE.search(block)
        if not href_m or not title_m:
            continue
        title = _clean(title_m.group(1))
        parts = [p.strip() for p in title.split(' - ')]
        if len(parts) < 3:
            continue
        event_name, fighters, date_str = parts[0], parts[1], parts[-1]
        date_key, date_label = _parse_date(date_str)
        if not date_key:
            continue
        key = (event_name, date_key)
        ev = events.setdefault(key, {
            'sport': 'ufc', 'source': 'watchmmafull',
            'title': event_name, 'date_key': date_key, 'date_label': date_label,
            'id': 'wmf_%s_%s' % (re.sub(r'\W+', '_', event_name.lower()).strip('_'), date_key),
            'thumb': '', 'fanart': '',
            'wmf_fights': [],
        })
        ev['wmf_fights'].append({
            'label': fighters.replace(' vs.', ' vs'),
            'url':   _WMF_BASE + href_m.group(1),
        })

    return list(events.values())


def _wmf_resolve_fight(fight_url):
    """Resolve one watchmmafull.com fight page to a real playable URL, or
    None if the event's embed host is an unresolvable JS-SPA (see module
    docstring — this varies per EVENT, not per fight). playmate.to embeds
    resolve via a plain POST to its own /api/s endpoint with the filecode
    parsed out of the embed URL, returning {'sx': '<master m3u8 URL>'} —
    confirmed live real HLS (#EXTM3U) whose segments carry deliberately
    fake .css/.js/.woff extensions (real MPEG-TS bytes underneath, 0x47
    sync byte confirmed) as a crude scraper-deterrent; Kodi's own HLS
    demuxer reads the playlist by its declared content, not the URL
    suffix, so this plays fine as a direct stream URL."""
    ck = 'replay_wmf_fight_%s' % re.sub(r'\W+', '_', fight_url)[-80:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None

    html = _get(fight_url)
    m = _RE_WMF_WATCH_BTN.search(html) if html else None
    if not m:
        _cache.set(ck, False, 15 * 60)
        return None
    embed_url = m.group(1)

    if 'playmate.to' in embed_url:
        fc_m = _RE_WMF_FILECODE.search(embed_url)
        if fc_m:
            try:
                r = _req.post(
                    'https://playmate.to/api/s',
                    json={'filecode': fc_m.group(1)},
                    headers=dict(_HEADERS, Referer=embed_url, Origin='https://playmate.to',
                                 **{'Content-Type': 'application/json'}),
                    timeout=10)
                r.raise_for_status()
                sx = r.json().get('sx', '') or None
                _cache.set(ck, sx or False, 15 * 60)
                return sx
            except Exception as e:
                xbmc.log('[Starfleet/Replay] watchmmafull playmate.to resolve failed (%s): %s'
                         % (fight_url[:60], e), xbmc.LOGWARNING)

    # Unknown/JS-SPA embed host (e.g. suisports.upns.xyz — bare JS bootstrap
    # shell, nothing server-rendered) — no real link to scrape, skip rather
    # than hand back a dead one.
    xbmc.log('[Starfleet/Replay] watchmmafull unresolved embed host for %s: %s'
             % (fight_url[:60], embed_url), xbmc.LOGINFO)
    _cache.set(ck, False, 15 * 60)
    return None


# ── fullfightreplays.com (UFC + Boxing) / mlblive.net (MLB) shared template ──
# Confirmed live: both sites are built on the same site engine — same
# "/_pu/<n>/<id>" thumbnail scheme, same event-listing markup, same
# "<strong>/<b>Section header</strong>" + su-button-link-or-iframe watch
# section on event pages — so one pair of parsers covers all 3 of this
# module's 3 target categories for these 2 sites.

_RE_FFR_LIST_ITEM = re.compile(
    r'<a href="(/[a-z0-9\-]+)"><img src="(/_pu/[^"]+)" alt="[^"]*"></a>.*?'
    r'<h3><a href="\1">([^<]+)</a></h3>.*?'
    r'<p>([A-Za-z]+ \d{1,2}, \d{4})[^<]*</p>',
    re.S)


def _ffr_scrape_listing(base, path, pages=1):
    """Scrape a fullfightreplays.com/mlblive.net category or homepage
    listing page, optionally following its real pagination for `pages`
    total pages. CORRECTION from an earlier pass of this module: this
    site's pagination is NOT the `/path/page/2` scheme that was tried and
    404'd — confirmed live 2026-08-16 the real working scheme is a bare
    `?page<N>` query suffix on the SAME path (`/ufc?page2`, `/?page3`,
    etc — no `=` sign, no leading `/page/`), which returns genuinely
    different, older events on each page (confirmed live: fullfightreplays
    goes back to January 2026 for UFC over 3 pages, and mid-June 2026 for
    Boxing; mlblive.net's `?pageN` on the homepage moves one real day
    back roughly every page). Stops early if a page returns zero events
    (reached the end of the real archive) rather than always fetching the
    full `pages` count."""
    events = []
    for page in range(1, pages + 1):
        url = base + path + ('?page%d' % page if page > 1 else '')
        html = _get(url)
        if not html:
            break
        page_events = []
        for href, thumb, title, date_str in _RE_FFR_LIST_ITEM.findall(html):
            date_key, date_label = _parse_date(date_str)
            if not date_key:
                continue
            page_events.append({
                'title': _clean(title), 'url': base + href, 'thumb': base + thumb,
                'date_key': date_key, 'date_label': date_label,
            })
        if not page_events:
            break
        events.extend(page_events)
    return events


_RE_FFR_HEADER = re.compile(
    # Section headings appear both as <strong><span>Text</span></strong>
    # (mlblive.net's "Server #N") and plain <strong>Text</strong> /
    # <b>Text</b> (fullfightreplays.com's "Main Card...", "OK", "Fiilemoon"
    # [sic]) — confirmed live both nestings occur, so the inner <span> is
    # optional here rather than assumed either way.
    r'<(?:strong|b)>\s*(?:<span[^>]*>)?\s*([^<]{1,60}?)\s*(?:</span>)?\s*</(?:strong|b)>', re.I)
_RE_FFR_BUTTON = re.compile(
    r'class="su-button[^"]*"[^>]*href="([^"]+)"[^>]*>.*?<span[^>]*>([^<]{1,20})</span>',
    re.I | re.S)
_RE_FFR_IFRAME = re.compile(r'<iframe[^>]+src="((?:https?:)?//[^"]+)"', re.I)

# Short/typo'd site labels normalized to a clearer host name for the picker
# (confirmed live "OK" and "Fiilemoon" [sic] are exactly what the site's
# own HTML uses for these 2 headers).
_FFR_HOST_SYNONYMS = {'ok': 'OK.ru', 'fiilemoon': 'Filemoon', 'filemoon': 'Filemoon'}


def _ffr_parse_sources(html):
    """Generic 'section heading (<strong>/<b>) applies to every su-button
    link or raw <iframe> that follows it, until the next heading' parser —
    confirmed live against both fullfightreplays.com's UFC (Main Card in
    2 quality tiers x parts, Prelims, Early Prelims x multiple hosts) and
    Boxing (Server #1/#2 x host) event pages, and mlblive.net's game pages
    (single "Server #N" x host)."""
    if not html:
        return []
    tokens = []
    for m in _RE_FFR_HEADER.finditer(html):
        tokens.append((m.start(), 'header', _clean(m.group(1))))
    for m in _RE_FFR_BUTTON.finditer(html):
        tokens.append((m.start(), 'button', (m.group(1), _clean(m.group(2)))))
    for m in _RE_FFR_IFRAME.finditer(html):
        tokens.append((m.start(), 'iframe', m.group(1)))
    tokens.sort(key=lambda t: t[0])

    results = []
    seen    = set()
    cur_header = ''
    for _, kind, val in tokens:
        if kind == 'header':
            cur_header = _FFR_HOST_SYNONYMS.get(val.lower(), val)
            continue
        url, label = val if kind == 'button' else (val, '')
        url = _html.unescape(url)
        url = url if url.startswith('http') else 'https:' + url
        if url in seen:
            continue
        seen.add(url)
        if label and label.lower() != 'watch' and cur_header:
            full_label = '%s - %s' % (cur_header, label)
        else:
            full_label = cur_header or label or 'Watch'
        results.append({'label': full_label, 'url': url})
    return results


def _ffr_event_sources(url):
    ck = 'replay_ffr_src_%s' % re.sub(r'\W+', '_', url)[-80:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    result = _ffr_parse_sources(_get(url))
    _cache.set(ck, result, 15 * 60)
    return result


# ── box.live (Boxing only) ───────────────────────────────────────────────────

_RE_BOXLIVE_VS_LINK = re.compile(r'href="(https://box\.live/fights/[a-z0-9\-]+-vs-[a-z0-9\-]+/)"')
_RE_BOXLIVE_H1       = re.compile(r'<h1[^>]*>\s*([^<]+?)\s*</h1>', re.I)
_RE_BOXLIVE_DATE     = re.compile(r'fight-date__str1[^>]*>\s*([^<]+?)\s*<', re.I)
_RE_BOXLIVE_VIDEO    = re.compile(r'replay-iframe[^>]*src="([^"]+)"', re.I)
_RE_BOXLIVE_PHOTO    = re.compile(
    r'data-src="(https://box\.live/wp-content/uploads/[^"]+\.(?:png|jpg))"', re.I)
_BOXLIVE_PHOTO_SKIP = ('ppv', 'amazon', 'banner', 'sponsor', 'blank-fighter', 'logo')


def _boxlive_fight_detail(url):
    """Fetch one box.live /fights/<slug>/ page. Returns None on fetch
    failure; otherwise a dict — 'video_url' is '' (not missing) when the
    site's own honest 'no replay yet' state applies, which is common for
    fights within the last couple of weeks (confirmed live: not every
    fight gets an official replay upload, and it can take weeks when it
    does)."""
    html = _get(url)
    if not html:
        return None
    h1_m   = _RE_BOXLIVE_H1.search(html)
    date_m = _RE_BOXLIVE_DATE.search(html)
    if not h1_m or not date_m:
        return None
    date_key, date_label = _parse_date(date_m.group(1))
    if not date_key:
        return None

    video_m = _RE_BOXLIVE_VIDEO.search(html)

    # Hero fighter photos: scoped to the region between the fight-card
    # header and the replays section so an ad banner or undercard-fighter
    # thumbnail elsewhere on the page can't get picked up instead.
    i0 = html.find('single-fight')
    i1 = html.find('id="replays"')
    region = html[i0:i1] if 0 <= i0 < i1 else html[:20000]
    photos = []
    for p in _RE_BOXLIVE_PHOTO.finditer(region):
        u = p.group(1)
        if any(skip in u.lower() for skip in _BOXLIVE_PHOTO_SKIP):
            continue
        if u not in photos:
            photos.append(u)
        if len(photos) >= 2:
            break

    return {
        'title':      _clean(h1_m.group(1)),
        'url':        url,
        'date_key':   date_key,
        'date_label': date_label,
        'video_url':  video_m.group(1) if video_m else '',
        'fighter1_photo': photos[0] if len(photos) > 0 else '',
        'fighter2_photo': photos[1] if len(photos) > 1 else '',
    }


def _boxlive_scrape_boxing():
    """box.live's /fight-results/ listing gives slugs + records but not a
    clean per-card date/title in one pass (that page is a stats/results
    table, not a blog-style listing like fullfightreplays.com's), so each
    real fight found there is fetched individually for its date, video
    (if any) and fighter photos — bounded (~38 real fights at check time)
    and threaded, same pattern sports_sources.py already uses for
    concurrent per-item fetches."""
    html = _get(_BOXLIVE_BASE + '/fight-results/')
    if not html:
        return []
    slugs = list(dict.fromkeys(_RE_BOXLIVE_VS_LINK.findall(html)))  # de-dup, preserve order

    events = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        futures = {ex.submit(_boxlive_fight_detail, u): u for u in slugs}
        for fut in as_completed(futures):
            try:
                d = fut.result()
            except Exception as e:
                xbmc.log('[Starfleet/Replay] box.live fight detail: %s' % e, xbmc.LOGWARNING)
                continue
            if d:
                events.append(d)
    return events


# ── sport-video.org.ua (UFC + Boxing via /other.html, MLB via /baseball.html
#    — TORRENT-based, .torrent-file-to-magnet, see module docstring) ────────

_RE_SVO_ITEM = re.compile(
    r"<strong>([^<]+?)\s+(\d{2}\.\d{2}\.\d{4})</strong></span>(.*?)"
    r'<a href="\./([^"]+\.html)">', re.S)
_RE_SVO_THUMB = re.compile(r"images/([^'\"]+\.(?:jpg|png))", re.I)
_RE_SVO_TORRENT_LINK = re.compile(r'<a href="(\./[^"]+\.torrent)">')
_SVO_UFC_RE    = re.compile(r'\bUFC\b', re.I)
_SVO_BOXING_RE = re.compile(r'\bBoxing\b', re.I)


def _svo_parse_date(s):
    """sport-video.org.ua's own date format is always numeric DD.MM.YYYY
    (e.g. '15.08.2026') — confirmed live, distinct from every other source
    in this module (all of which use textual month names) — so this gets
    its own tiny parser rather than overloading _parse_date's format list
    with a 5th guess."""
    try:
        d = datetime.datetime.strptime(s.strip(), '%d.%m.%Y').date()
        return d.isoformat(), d.strftime('%B %d, %Y')
    except Exception:
        return None, s.strip()


def _svo_scrape_listing(path_base, max_pages):
    """Fetch sport-video.org.ua's numbered pagination for one category
    (path_base='baseball' or 'other') — confirmed live real, distinct
    pages/dates all the way from path_base+'.html' (page 1) through
    path_base+'<max_pages-1>.html', 404ing cleanly past the real archive
    end (confirmed live: baseball9.html and other26.html both 404 —
    max_pages is passed one past the last confirmed-real page so a 404 on
    the extra page is expected/harmless, not a sign something broke).

    Two HTML template generations coexist across the real archive (newer:
    thumbnail via onclick="window.open('images/...')"; older, pre-mid-2026:
    thumbnail via a plain <a href="images/...jpg" rel="prettyPhoto...">
    link) — _RE_SVO_ITEM only anchors on the <strong>TITLE DATE</strong>
    heading and the following ./<slug>.html detail-page link, capturing
    whatever thumbnail markup sits between them as an opaque middle group
    parsed separately by _RE_SVO_THUMB — confirmed live this parses both
    template generations identically without needing to detect which one
    a given page uses.

    Fetched concurrently since every page URL is independently addressable
    (a numbered filename, not a real 'next page' link that has to be
    followed one at a time) — same threaded-fetch pattern
    _boxlive_scrape_boxing already uses for its own bounded per-item
    fetches."""
    urls = [_SVO_BASE + '/' + path_base + '.html']
    urls += [_SVO_BASE + '/%s%d.html' % (path_base, n) for n in range(1, max_pages)]

    pages = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        futures = {ex.submit(_get, u): u for u in urls}
        for fut in as_completed(futures):
            u = futures[fut]
            try:
                html = fut.result()
            except Exception as e:
                xbmc.log('[Starfleet/Replay] sport-video.org.ua page fetch (%s): %s'
                         % (u[:60], e), xbmc.LOGWARNING)
                continue
            if html:
                pages[u] = html

    events = []
    seen = set()
    for u in urls:  # preserve page order (most recent first)
        html = pages.get(u)
        if not html:
            continue
        for title, date_str, mid, href in _RE_SVO_ITEM.findall(html):
            date_key, date_label = _svo_parse_date(date_str)
            if not date_key:
                continue
            detail_url = _SVO_BASE + '/' + href
            if detail_url in seen:
                continue
            seen.add(detail_url)
            thumb_m = _RE_SVO_THUMB.search(mid)
            events.append({
                'title': _clean(title), 'url': detail_url,
                'thumb': (_SVO_BASE + '/images/' + thumb_m.group(1)) if thumb_m else '',
                'date_key': date_key, 'date_label': date_label,
            })
    return events


def _svo_get_listing(path_base, max_pages):
    """Cached wrapper around _svo_scrape_listing — both the UFC and Boxing
    catalogs below filter the SAME /other.html archive for their own
    sport, so without this they'd each independently re-fetch all ~26
    pages on a cold cache. 20 min TTL, same as every other catalog-level
    cache in this module."""
    ck = 'replay_svo_listing_%s_v1' % path_base
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    events = _svo_scrape_listing(path_base, max_pages)
    _cache.set(ck, events, 20 * 60)
    return events


def _svo_resolve_magnet(detail_url, title=''):
    """Resolve one sport-video.org.ua event page to a magnet: URI.
    Confirmed live this site only ever offers a real `.torrent` FILE
    download link on its detail pages (never a magnet: URI directly — see
    module docstring), so this downloads that file and derives the
    info_hash from its own bencoded 'info' dict — reusing
    torrent_sources.py's own _torrent_info_hash/_make_magnet helpers (the
    exact same technique already used there for FreeJAVTorrent's own
    torrent-file-only detail pages) instead of a second bencode parser
    living in this file too."""
    ck = 'replay_svo_magnet_%s' % re.sub(r'\W+', '_', detail_url)[-80:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None

    html = _get(detail_url)
    m = _RE_SVO_TORRENT_LINK.search(html) if html else None
    if not m:
        _cache.set(ck, False, 15 * 60)
        return None

    from urllib.parse import quote as _uq, urljoin as _urljoin
    # The .torrent filename is the real event title + date with spaces —
    # confirmed live (e.g. "./UFC Fight Night Gamrot vs Salkilld
    # 08.08.2026.mkv.torrent") — quoted here rather than reconstructed from
    # the listing's own title/date fields so a mismatch in either can never
    # produce a broken download URL.
    torrent_url = _uq(_urljoin(detail_url, m.group(1)), safe=':/')
    try:
        r = _req.get(torrent_url, headers=_HEADERS, timeout=20)
        r.raise_for_status()
        torrent_bytes = r.content
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua torrent fetch failed (%s): %s'
                 % (detail_url[:60], e), xbmc.LOGWARNING)
        _cache.set(ck, False, 15 * 60)
        return None

    from resources.lib import torrent_sources as _ts
    info_hash = _ts._torrent_info_hash(torrent_bytes)
    if not info_hash:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua: no info_hash parsed from torrent (%s)'
                 % detail_url[:60], xbmc.LOGWARNING)
        _cache.set(ck, False, 15 * 60)
        return None
    magnet = _ts._make_magnet(info_hash, title)
    _cache.set(ck, magnet, 15 * 60)
    return magnet


# ── UFC catalog (merge watchmmafull.com per-fight + fullfightreplays.com
#    per-card-section, matched by numbered PPV, e.g. "UFC 330") ────────────

_UFC_NUM_RE = re.compile(r'\bUFC\s+(\d{3,4})\b', re.I)


def _get_ufc_catalog():
    ck = 'replay_catalog_ufc_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        wmf_events = _wmf_scrape_ufc()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] wmf ufc scrape: %s' % e, xbmc.LOGWARNING)
        wmf_events = []
    try:
        ffr_events = _ffr_scrape_listing(_FFR_BASE, '/ufc', pages=4)
    except Exception as e:
        xbmc.log('[Starfleet/Replay] ffr ufc scrape: %s' % e, xbmc.LOGWARNING)
        ffr_events = []

    ffr_by_num = {}
    ffr_unmatched = []
    for ev in ffr_events:
        m = _UFC_NUM_RE.search(ev['title'])
        (ffr_by_num.__setitem__(m.group(1), ev) if m else ffr_unmatched.append(ev))

    catalog = []
    matched_nums = set()
    for ev in wmf_events:
        m = _UFC_NUM_RE.search(ev['title'])
        num = m.group(1) if m else None
        merged = dict(ev)
        if num and num in ffr_by_num:
            ffr_ev = ffr_by_num[num]
            merged['title'] = ffr_ev['title']       # fuller name, e.g. includes headliners
            merged['ffr_url'] = ffr_ev['url']
            merged['thumb'] = ffr_ev.get('thumb', '')
            matched_nums.add(num)
        catalog.append(merged)

    for num, ev in ffr_by_num.items():
        if num in matched_nums:
            continue
        catalog.append({
            'sport': 'ufc', 'source': 'fullfightreplays', 'title': ev['title'],
            'date_key': ev['date_key'], 'date_label': ev['date_label'],
            'id': 'ffr_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
            'thumb': ev.get('thumb', ''), 'fanart': '',
            'ffr_url': ev['url'], 'wmf_fights': [],
        })
    for ev in ffr_unmatched:
        catalog.append({
            'sport': 'ufc', 'source': 'fullfightreplays', 'title': ev['title'],
            'date_key': ev['date_key'], 'date_label': ev['date_label'],
            'id': 'ffr_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
            'thumb': ev.get('thumb', ''), 'fanart': '',
            'ffr_url': ev['url'], 'wmf_fights': [],
        })

    # sport-video.org.ua (torrent-based) — kept as its own separate entries
    # rather than merged into the wmf/ffr matching above; see module
    # docstring for why (naming doesn't line up reliably with the other 2
    # sites).
    try:
        for ev in _svo_get_listing('other', 26):
            if not _SVO_UFC_RE.search(ev['title']):
                continue
            catalog.append({
                'sport': 'ufc', 'source': 'sportvideo', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'svo_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'wmf_fights': [], 'svo_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua ufc scrape: %s' % e, xbmc.LOGWARNING)

    catalog.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, catalog, 20 * 60)
    return catalog


# ── Boxing catalog (fullfightreplays.com + box.live, kept as separate
#    entries per source rather than merged — the 2 sites' naming
#    conventions differ too much to match reliably: "Claressa Shields vs.
#    Kaye Scott" vs box.live's surname-only "Shields vs Scott" h1 — safer
#    to list both plainly labeled by source than risk a wrong merge) ───────

def _get_boxing_catalog():
    ck = 'replay_catalog_boxing_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    catalog = []
    try:
        for ev in _ffr_scrape_listing(_FFR_BASE, '/boxing', pages=4):
            catalog.append({
                'sport': 'boxing', 'source': 'fullfightreplays', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'ffr_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'ffr_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] ffr boxing scrape: %s' % e, xbmc.LOGWARNING)

    try:
        for ev in _boxlive_scrape_boxing():
            catalog.append({
                'sport': 'boxing', 'source': 'boxlive', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'bl_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('fighter1_photo', ''), 'fanart': ev.get('fighter2_photo', ''),
                'fighter1_photo': ev.get('fighter1_photo', ''),
                'fighter2_photo': ev.get('fighter2_photo', ''),
                'boxlive_url': ev['url'], 'boxlive_video': ev.get('video_url', ''),
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] boxlive boxing scrape: %s' % e, xbmc.LOGWARNING)

    # sport-video.org.ua (torrent-based) — same /other.html archive the UFC
    # catalog above filters, re-used here via the cached wrapper so this
    # doesn't re-fetch all ~26 pages a second time within the same 20 min
    # window.
    try:
        for ev in _svo_get_listing('other', 26):
            if not _SVO_BOXING_RE.search(ev['title']):
                continue
            catalog.append({
                'sport': 'boxing', 'source': 'sportvideo', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'svo_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'svo_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua boxing scrape: %s' % e, xbmc.LOGWARNING)

    catalog.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, catalog, 20 * 60)
    return catalog


# ── MLB catalog (mlblive.net only — homepage + current-year index merged
#    and de-duplicated by URL, since neither page alone is exhaustive and
#    homepage paginates via the real ?pageN scheme documented on
#    _ffr_scrape_listing now — the year-index page is fetched too since
#    it's not guaranteed to be a strict subset of the homepage's recent
#    slice, de-duplicated by URL either way) ──────────────────────────────

def _get_mlb_catalog():
    ck = 'replay_catalog_mlb_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    catalog = {}
    year = datetime.date.today().year
    for path, pages in (('/', 6), ('/%d-mlb-full-game-replays' % year, 2)):
        try:
            for ev in _ffr_scrape_listing(_MLBLIVE_BASE, path, pages=pages):
                catalog[ev['url']] = ev
        except Exception as e:
            xbmc.log('[Starfleet/Replay] mlblive scrape (%s): %s' % (path, e), xbmc.LOGWARNING)

    result = []
    for ev in catalog.values():
        result.append({
            'sport': 'mlb', 'source': 'mlblive', 'title': ev['title'],
            'date_key': ev['date_key'], 'date_label': ev['date_label'],
            'id': 'mlb_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
            'thumb': ev.get('thumb', ''), 'fanart': '',
            'mlblive_url': ev['url'],
        })

    # sport-video.org.ua (torrent-based) — /baseball.html + its own numbered
    # pagination, kept as separate entries (distinct domain/URL scheme from
    # mlblive.net above, same "list separately" call as everywhere else in
    # this module rather than attempt a cross-site title merge).
    try:
        for ev in _svo_get_listing('baseball', 9):
            result.append({
                'sport': 'mlb', 'source': 'sportvideo', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'svo_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'svo_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua mlb scrape: %s' % e, xbmc.LOGWARNING)

    result.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, result, 20 * 60)
    return result


_CATALOG_FUNCS = {
    'ufc':    _get_ufc_catalog,
    'boxing': _get_boxing_catalog,
    'mlb':    _get_mlb_catalog,
}


# ── Public API ────────────────────────────────────────────────────────────

def get_replay_dates(sport):
    """Real dates (most recent first) that have at least one replay event
    for `sport` ('ufc' / 'boxing' / 'mlb'), across every source confirmed
    live for that sport (see module docstring)."""
    fn = _CATALOG_FUNCS.get(sport)
    if not fn:
        return []
    try:
        catalog = fn()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_dates(%s): %s' % (sport, e), xbmc.LOGWARNING)
        return []

    seen = {}
    for ev in catalog:
        dk = ev.get('date_key')
        if dk and dk not in seen:
            seen[dk] = ev.get('date_label', dk)
    return [{'date_key': dk, 'label': seen[dk]} for dk in sorted(seen, reverse=True)]


def get_replay_events(sport, date_key):
    """Events for `sport` on `date_key` ('YYYY-MM-DD'), most-recently-added
    source first. Each dict carries everything get_replay_sources() needs
    — pass it straight through, no separate lookup required."""
    fn = _CATALOG_FUNCS.get(sport)
    if not fn:
        return []
    try:
        catalog = fn()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_events(%s, %s): %s' % (sport, date_key, e), xbmc.LOGWARNING)
        return []
    return [ev for ev in catalog if ev.get('date_key') == date_key]


_RE_TORRENT_QUERY_STRIP = re.compile(
    r'\s*-\s*Full Fight Replays?\s*-\s*[A-Za-z]+\.?\s*\d{1,2},?\s*\d{4}(?:\s+\w+)?\s*$', re.I)


def _torrent_search_title(title):
    """Clean an event['title'] down to a real search query for
    torrent_sources.search_all(). fullfightreplays.com's own titles
    (which flow straight into event['title'] for merged/unmatched UFC and
    Boxing catalog entries — see _get_ufc_catalog/_get_boxing_catalog)
    carry a real trailing "- Full Fight Replay(s) - <Month D, YYYY>
    [Boxing]" suffix that's literally that SITE's own page-title text, not
    anything added by this module. Confirmed live this measurably breaks
    the generic search: the raw stored title for UFC 330 returns 0 results
    from search_all(), while the same query stripped down to "UFC 330:
    Makhachev vs. Machado Garry" returns 10 real ones — most of the 44
    wired-in sources do a fairly literal site-search, not a fuzzy one, so
    a `date`/`Full Fight Replay(s)` tail poisons the query for all of
    them at once. No-op (returns the title unchanged) for every other
    source in this module (watchmmafull.com, box.live, mlblive.net,
    sport-video.org.ua) since none of them carry this suffix."""
    cleaned = _RE_TORRENT_QUERY_STRIP.sub('', title or '').strip()
    return cleaned or title


def get_replay_sources(sport, event):
    """Every real playable option for `event` (as returned by
    get_replay_events), individual-fight AND full-card/section entries
    both included whenever the underlying site(s) offer both — never
    picking just one. Entries with a broken/unresolvable underlying embed
    are silently skipped rather than returned as a dead link."""
    sources = []
    try:
        if sport == 'ufc':
            for fight in event.get('wmf_fights') or []:
                url = _wmf_resolve_fight(fight['url'])
                if url:
                    sources.append({'label': fight['label'], 'url': url})
            ffr_url = event.get('ffr_url')
            if ffr_url:
                sources.extend(_ffr_event_sources(ffr_url))
            svo_url = event.get('svo_url')
            if svo_url:
                magnet = _svo_resolve_magnet(svo_url, event.get('title', ''))
                if magnet:
                    sources.append({'label': 'sport-video.org.ua (Torrent)',
                                     'url': magnet, 'magnet': magnet})

        elif sport == 'boxing':
            ffr_url = event.get('ffr_url')
            if ffr_url:
                sources.extend(_ffr_event_sources(ffr_url))
            bl_url = event.get('boxlive_url')
            if bl_url:
                video = event.get('boxlive_video', '')
                if not video:
                    # Event dict may predate a video being uploaded, or came
                    # from a cached catalog — re-check live rather than
                    # trusting a stale 'no replay yet' from catalog-build time.
                    detail = _boxlive_fight_detail(bl_url)
                    video = detail.get('video_url', '') if detail else ''
                if video:
                    sources.append({'label': 'Full Fight (Official YouTube)', 'url': video})
            svo_url = event.get('svo_url')
            if svo_url:
                magnet = _svo_resolve_magnet(svo_url, event.get('title', ''))
                if magnet:
                    sources.append({'label': 'sport-video.org.ua (Torrent)',
                                     'url': magnet, 'magnet': magnet})

        elif sport == 'mlb':
            mlb_url = event.get('mlblive_url')
            if mlb_url:
                sources.extend(_ffr_event_sources(mlb_url))
            svo_url = event.get('svo_url')
            if svo_url:
                magnet = _svo_resolve_magnet(svo_url, event.get('title', ''))
                if magnet:
                    sources.append({'label': 'sport-video.org.ua (Torrent)',
                                     'url': magnet, 'magnet': magnet})

        # Generic multi-site torrent search (torrent_sources.search_all —
        # the same 44-source engine Movies/TV/Adult already use) matched
        # purely on the event's own title text: no imdb_id/year is passed
        # since replay event titles ("UFC 330", "Errol Spence Jr. vs. Tim
        # Tszyu") aren't conventional movie titles, just a plain
        # title-text search the same way search_knaben/search_1337x
        # already support when only given a title. Wired in unconditionally
        # for all 3 sports (see module docstring for the live-verified,
        # per-sport results) — MLB team-vs-team titles are confirmed a
        # poor match (0 real results across several real titles tried
        # live), but this is left wired in rather than special-cased off
        # since it's a harmless no-op exactly like every other empty-result
        # case in this module, and a big enough MLB game could still hit.
        # Each match is labeled distinctly ('<source> [quality, N seeds]')
        # and carries a 'magnet' key (== 'url') so it's obvious in the
        # picker and to the caller that this routes through the addon's
        # debrid resolver — see sports_router.py's _play_stream magnet:
        # branch — instead of ResolveURL/embed resolution like every
        # source above.
        title = event.get('title', '')
        if title:
            try:
                from resources.lib import torrent_sources as _ts
                query = _torrent_search_title(title)
                for t in _ts.search_all(query, media_type='movie', max_per_source=5):
                    magnet = t.get('magnet', '')
                    if not magnet:
                        continue
                    label = '%s [%s, %s seeds]' % (
                        t.get('source', 'Torrent'), t.get('quality') or '?', t.get('seeds', 0))
                    sources.append({'label': label, 'url': magnet, 'magnet': magnet})
            except Exception as e:
                xbmc.log('[Starfleet/Replay] torrent_sources search_all(%r): %s'
                         % (title, e), xbmc.LOGWARNING)

    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_sources(%s, %r): %s'
                 % (sport, event.get('title', ''), e), xbmc.LOGWARNING)

    return sources


# ── TMDB poster lookup (icon feasibility — see module docstring) ──────────

def get_replay_poster(title):
    """UFC/Boxing event poster via TMDB, wrapping metadata.py's own
    search_movies() (same TMDB_KEYS, same 24h cache) rather than
    duplicating key rotation here — confirmed live this reliably finds
    both UFC PPVs/Fight Nights and named boxing matchups (see module
    docstring for real examples). Returns {} for MLB games (confirmed
    live these are never on TMDB) or on any lookup failure — callers
    should fall back to the site-native thumbnail/fanart already present
    on the event dict, or a generic sport logo, when this is empty."""
    if not title:
        return {}
    try:
        from resources.lib import metadata as _meta
        results = _meta.search_movies(title)
        if results:
            m = results[0]
            return {'thumb': m.get('thumb', ''), 'fanart': m.get('fanart', '')}
    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_poster(%r): %s' % (title, e), xbmc.LOGWARNING)
    return {}
