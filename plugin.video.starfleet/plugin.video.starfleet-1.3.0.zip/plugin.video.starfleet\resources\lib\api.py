?# -*- coding: utf-8 -*-
"""
resources/lib/api.py �?? Starfleet Kodi Plugin

LIVE TV �?? Two stream backends
==============================
TVA / Québecor  �?? Brightcove Playback API (account 5813221784001).
                  referenceId per channel; returns Akamai-tokened HLS URL.
Global News     �?? Direct HLS from corusappservices.com.
                  Media ID is scraped from globalnews.ca, then Corus API returns HLS URL.
"""

import json
import re
import sqlite3
import time
import os

import xbmc
import xbmcaddon
import xbmcvfs
import requests

ADDON    = xbmcaddon.Addon()
PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_DB = os.path.join(PROFILE, 'cache.db')

# ---------------------------------------------------------------------------
# TVA �?? Brightcove Playback API config (stable credentials from tvaplus.ca)
# ---------------------------------------------------------------------------
_BC_ACCOUNT    = '5813221784001'
_BC_POLICY_KEY = (
    'BCpkADawqM2hsFvZUZm6C4LPMbysl5Q-rMeLlFTZPj5BBvQRNHYYYXYB9zGUnCYXUeLn'
    'FjFa9Z4uUpBoie-uaIsInp1oa88qYdIy3vmsrTxuANN2hqo4XsvX3YW1OfPocwoHZ6fZQ'
    '4m4ZttzlW_yhkrBbkXXlg3T4Sa2FA'
)
_BC_PLAYBACK   = 'https://edge.api.brightcove.com/playback/v1/accounts/%s/videos/ref:%s'

TVA_CHANNELS = [
    {
        'id':           'tva',
        'title':        'TVA',
        'reference_id': 'tva_6341846685112',
        'thumbnail':    'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/TVA_%28TV_network%29_logo.svg/200px-TVA_%28TV_network%29_logo.svg.png',
        'group':        'Québecor',
        'description':  'La chaîne principale de TVA �?? en direct',
    },
    {
        'id':           'tva-sports',
        'title':        'TVA Sports',
        'reference_id': 'TVASports_1_BO_VMedia',
        'thumbnail':    'https://upload.wikimedia.org/wikipedia/en/thumb/5/5a/TVA_Sports_logo.svg/200px-TVA_Sports_logo.svg.png',
        'group':        'Québecor',
        'description':  'Chaîne sportive de TVA �?? en direct',
    },
]

# ---------------------------------------------------------------------------
# Global News �?? channel definitions (HLS via Corus API)
# ---------------------------------------------------------------------------
GLOBAL_NEWS_CHANNELS = [
    {'id': 'global-national',    'title': 'Global News National',    'region': 'national',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-bc',          'title': 'Global News BC',          'region': 'bc',          'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-toronto',     'title': 'Global News Toronto',     'region': 'toronto',     'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-edmonton',    'title': 'Global News Edmonton',    'region': 'edmonton',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-calgary',     'title': 'Global News Calgary',     'region': 'calgary',     'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-halifax',     'title': 'Global News Halifax',     'region': 'halifax',     'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-winnipeg',    'title': 'Global News Winnipeg',    'region': 'winnipeg',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-montreal',    'title': 'Global News Montreal',    'region': 'montreal',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-okanagan',    'title': 'Global News Okanagan',    'region': 'okanagan',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-saskatoon',   'title': 'Global News Saskatoon',   'region': 'saskatoon',   'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-regina',      'title': 'Global News Regina',      'region': 'regina',      'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-lethbridge',  'title': 'Global News Lethbridge',  'region': 'lethbridge',  'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-kingston',    'title': 'Global News Kingston',    'region': 'kingston',    'thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
    {'id': 'global-peterborough','title': 'Global News Peterborough','region': 'peterborough','thumbnail': 'https://globalnews.ca/wp-content/themes/global-news-theme/images/icons/favicon-32x32.png', 'group': 'Global News'},
]

# For backwards compat with router �?? combined list exposed as DAI_LIVE_CHANNELS
DAI_LIVE_CHANNELS = TVA_CHANNELS + GLOBAL_NEWS_CHANNELS

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json',
    'Accept-Language': 'en-CA,en;q=0.9,fr-CA;q=0.8',
}

TTL_LIVE = 5 * 60

# ---------------------------------------------------------------------------
# HTTP session
# ---------------------------------------------------------------------------
_session = None

def _get_session():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=10, max_retries=2)
        _session.mount('https://', adapter)
    return _session

# ---------------------------------------------------------------------------
# SQLite cache
# ---------------------------------------------------------------------------
def _db():
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE)
    conn = sqlite3.connect(CACHE_DB, timeout=5)
    conn.execute('CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT, expires REAL)')
    conn.commit()
    return conn

def _cache_get(key):
    try:
        conn = _db()
        row = conn.execute('SELECT value, expires FROM cache WHERE key=?', (key,)).fetchone()
        conn.close()
        if row and row[1] > time.time():
            return json.loads(row[0])
    except Exception as e:
        xbmc.log('[Starfleet] cache_get error: %s' % e, xbmc.LOGWARNING)
    return None

def _cache_set(key, data, ttl):
    try:
        conn = _db()
        conn.execute('INSERT OR REPLACE INTO cache (key, value, expires) VALUES (?,?,?)',
                     (key, json.dumps(data), time.time() + ttl))
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log('[Starfleet] cache_set error: %s' % e, xbmc.LOGWARNING)

# ---------------------------------------------------------------------------
# Public: channel list
# ---------------------------------------------------------------------------

def get_live_channels():
    """Return list of live channel dicts."""
    return DAI_LIVE_CHANNELS


# ---------------------------------------------------------------------------
# TVA �?? Brightcove Playback API (Akamai-tokened HLS, valid ~1 hour per fetch)
# ---------------------------------------------------------------------------

def _get_tva_stream(channel):
    """Fetch a time-limited HLS URL from Brightcove Playback API. Returns HLS URL or None."""
    ref_id = channel.get('reference_id', '')
    if not ref_id:
        xbmc.log('[Starfleet] TVA: no reference_id for channel %s' % channel.get('id'), xbmc.LOGERROR)
        return None

    ck = 'tva_bc_stream_' + ref_id
    cached = _cache_get(ck)
    if cached:
        return cached

    url = _BC_PLAYBACK % (_BC_ACCOUNT, ref_id)
    xbmc.log('[Starfleet] TVA Brightcove GET %s' % url, xbmc.LOGINFO)

    try:
        r = _get_session().get(
            url,
            headers={'Accept': 'application/json;pk=' + _BC_POLICY_KEY,
                     'Origin': 'https://www.tvaplus.ca'},
            timeout=12
        )
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet] TVA Brightcove error: %s' % e, xbmc.LOGERROR)
        return None

    sources = data.get('sources') or []
    hls = next((s['src'] for s in sources if s.get('src', '').endswith('.m3u8')
                or 'hls' in s.get('type', '')), None)
    if not hls:
        hls = next((s['src'] for s in sources if s.get('src')), None)

    if hls:
        xbmc.log('[Starfleet] TVA stream OK: %s' % hls[:80], xbmc.LOGINFO)
        _cache_set(ck, hls, 3000)   # Akamai token valid ~1 h; cache 50 min
        return hls

    xbmc.log('[Starfleet] TVA: no src in Brightcove sources %s' % sources, xbmc.LOGWARNING)
    return None


# ---------------------------------------------------------------------------
# Global News �?? scrape media ID from globalnews.ca, fetch HLS from Corus API
# ---------------------------------------------------------------------------

_GNCA_FEED = 'https://globalnews.ca/gnca-ajax-redesign/video-entry/%s/'
import urllib.parse as _urlparse

def _get_global_news_stream(channel):
    """
    1. Fetch globalnews.ca/live/{region}/ to get JW Player media ID
    2. Hit Corus GNCA API to get direct HLS URL
    """
    region = channel.get('region', '')
    ck = 'global_news_hls_%s' % region
    cached = _cache_get(ck)
    if cached:
        return cached

    live_url = 'https://globalnews.ca/live/%s/' % region
    try:
        r = _get_session().get(live_url, timeout=12)
        r.raise_for_status()
        m = re.search(r'"mediaId"\s*:\s*"([a-f0-9\-]{36})"', r.text)
        if not m:
            xbmc.log('[Starfleet] GlobalNews: no mediaId on %s' % live_url, xbmc.LOGWARNING)
            return None
        media_id = m.group(1)
        xbmc.log('[Starfleet] GlobalNews %s mediaId=%s' % (region, media_id), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet] GlobalNews page error: %s' % e, xbmc.LOGERROR)
        return None

    feed_url = _GNCA_FEED % _urlparse.quote('{"id":"%s"}' % media_id)
    try:
        r2 = _get_session().get(feed_url, timeout=12)
        r2.raise_for_status()
        items = r2.json()
        if not items:
            return None
        sources = items[0].get('sources', [])
        hls = next((s['file'] for s in sources if s.get('type') == 'hls'), None)
        if hls:
            xbmc.log('[Starfleet] GlobalNews HLS: %s' % hls[:80], xbmc.LOGINFO)
            _cache_set(ck, hls, 300)   # cache 5 min �?? live streams rotate tokens
            return hls
    except Exception as e:
        xbmc.log('[Starfleet] GlobalNews feed error: %s' % e, xbmc.LOGERROR)

    return None


# ---------------------------------------------------------------------------
# Public: get stream URL for any live channel
# ---------------------------------------------------------------------------

def get_live_stream_url(channel_or_asset_key):
    """
    Accepts either a full channel dict or a bare asset_key string (legacy).
    Returns a playable HLS URL or None.
    """
    # Legacy: bare asset_key string passed from old router code
    if isinstance(channel_or_asset_key, str):
        asset_key = channel_or_asset_key
        # Find channel in list
        ch = next((c for c in DAI_LIVE_CHANNELS if c.get('asset_key') == asset_key), None)
        if ch is None:
            # Might be a TVA channel �?? construct minimal dict
            ch = {'asset_key': asset_key, 'live_url': '', 'region': ''}
        channel_or_asset_key = ch

    channel = channel_or_asset_key

    # Route by channel type
    if 'region' in channel and channel['region']:
        return _get_global_news_stream(channel)
    elif 'reference_id' in channel and channel['reference_id']:
        return _get_tva_stream(channel)
    else:
        xbmc.log('[Starfleet] Unknown channel type: %s' % channel, xbmc.LOGWARNING)
        return None


# ---------------------------------------------------------------------------
# Re-export live source helpers so router only imports from api
# ---------------------------------------------------------------------------
from resources.lib.live_sources import (
    get_samsung_channels,
    get_plex_channels,
    get_pluto_channels,
    refresh_pluto,
)
