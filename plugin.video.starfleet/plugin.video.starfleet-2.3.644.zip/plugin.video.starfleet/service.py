# -*- coding: utf-8 -*-
"""
service.py — Kodi background service entry point (xbmc.python.service,
start="startup" in addon.xml). Runs for the whole Kodi session, unlike
default.py's plugin:// invocations which are fresh, short-lived processes
(this addon explicitly sets reuselanguageinvoker=false) — see
resources/lib/local_proxy.py's own docstring for why that distinction is
exactly what OK.ru playback needed.
"""
import xbmc

try:
    from resources.lib import tls_speed
    tls_speed.install()
except Exception:
    pass

try:                                          # keep Starfleet Scrapers / Starfleet Resolver in step with this version
    from resources.lib import dep_check
    dep_check.run_in_background()
except Exception:
    pass

try:                                          # open the connections to the fast sources before the first search
    from resources.lib import torrent_sources as _ts
    _ts.prewarm()
except Exception:
    pass

from resources.lib import local_proxy

local_proxy.run_service(xbmc.Monitor())
