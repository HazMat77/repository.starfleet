# -*- coding: utf-8 -*-
"""
resources/lib/myteams_alerts.py

My Teams alerts, run from the background service (service.py): when a followed team's game goes live, goes to overtime, gets
close late, or ends, Kodi shows a notice - and when nothing is playing, asks "Watch now?" and starts the game on Just Play.

It does nothing (no network at all) until a team is followed and alerts are on. Only the sports that have a followed team are
read, from the same 20-second scoreboard cache the sports lists use, every minute while a followed team's game is on or about
to start, every 8 minutes otherwise (soccer's all-leagues scoreboard is large, so it is read every 2 minutes at most). Each
kind of alert fires once per game; what has been sent is kept in my_alert_state.json for two days.
"""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui

STATE = 'my_alert_state.json'
POLL_ACTIVE = 60
POLL_SOCCER_ACTIVE = 120
POLL_IDLE = 480
POLL_OFF = 120


def _log(msg):
    xbmc.log('[Starfleet/MyTeamsAlerts] %s' % msg, xbmc.LOGINFO)


def _setting(key, default='true'):
    try:
        v = xbmcaddon.Addon('plugin.video.starfleet').getSetting(key)
        return v if v != '' else default
    except Exception:
        return default


def _state_path():
    import xbmcvfs
    d = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, STATE)


def _load_state():
    try:
        with open(_state_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        now = time.time()
        return {k: v for k, v in d.items() if now - v.get('t', 0) < 2 * 86400}
    except Exception:
        return {}


def _save_state(st):
    try:
        p = _state_path()
        with open(p + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(st, f)
        os.replace(p + '.tmp', p)
    except Exception as e:
        _log('state not saved: %s' % e)


def _game_key(sport, g):
    return '%s|%s|%s|%s' % (sport, g['home'], g['away'], time.strftime('%Y%m%d', time.gmtime(g.get('start') or 0)))


def _score(g):
    return '%s %s - %s %s' % (g['away'], g['as'], g['hs'], g['home'])


def _message(kind, team, g):
    """(heading, text) for one alert."""
    if kind == 'live':
        return 'Starfleet - %s' % team, '%s vs %s is LIVE now.' % (g['away'], g['home'])
    if kind == 'ot':
        return 'Starfleet - %s' % team, 'OVERTIME! %s' % _score(g)
    if kind == 'close':
        return 'Starfleet - %s' % team, 'Close game: %s (%s)' % (_score(g), g.get('detail') or 'late')
    return 'Starfleet - %s' % team, 'Final: %s' % _score(g)


def _find_event(sport, g):
    """The event-list entry for a scoreboard game (both teams must match), or None."""
    try:
        from resources.lib import sports_sources as _ss
        from resources.lib import my_teams as _mt
        for ev in _ss.get_sport_events(sport):
            if _mt.event_has_team(ev, g['home']) and _mt.event_has_team(ev, g['away']):
                return ev
    except Exception as e:
        _log('event lookup: %s' % e)
    return None


def _watch(sport, g, team):
    ev = _find_event(sport, g)
    if not ev:
        xbmcgui.Dialog().notification('Starfleet', 'No stream listing for %s yet' % team, xbmcgui.NOTIFICATION_INFO, 4000)
        return
    from urllib.parse import quote
    url = ('plugin://plugin.video.starfleet/?action=sports_event_play&event_id=%s&event_path=%s&sport_slug=%s&title=%s'
           '&start=%s&auto=1' % (quote(str(ev.get('id', ''))), quote(str(ev.get('path', ''))), sport,
                                 quote(ev.get('match_title') or ev.get('title', '')), int(ev.get('start_ts') or 0)))
    li = xbmcgui.ListItem(ev.get('match_title') or ev.get('title', ''))
    li.setProperty('IsPlayable', 'true')
    xbmc.Player().play(url, li)


def _alert(kind, sport, team, g):
    heading, text = _message(kind, team, g)
    _log('%s: %s' % (kind, text))
    try:
        playing = xbmc.Player().isPlaying()
    except Exception:
        playing = False
    if kind != 'final' and not playing and _setting('myteams_alert_prompt') != 'false':
        try:
            if xbmcgui.Dialog().yesno(heading, text + '\n\nWatch now?', nolabel='Not now', yeslabel='Watch', autoclose=25000):
                _watch(sport, g, team)
            return
        except Exception as e:
            _log('prompt failed: %s' % e)
    xbmcgui.Dialog().notification(heading, text, xbmcgui.NOTIFICATION_INFO, 7000)


def tick(now=None):
    """One pass over the followed teams; returns the seconds to wait before the next one."""
    if _setting('myteams_alerts') == 'false':
        return POLL_OFF
    from resources.lib import my_teams as _mt
    followed = _mt.teams()
    if not followed:
        return POLL_OFF
    from starfleetscrapers.sports import live_scores as _ls
    now = now or time.time()
    state = _load_state()
    active, soccer_only = False, True
    by_sport = {}
    for t in followed:
        by_sport.setdefault(t['sport'], []).append(t['name'])
    alerted = set()
    for sport, names in by_sport.items():
        try:
            pairs = _ls.team_games(sport, names)
        except Exception as e:
            _log('%s scoreboard: %s' % (sport, e))
            continue
        for team, g in pairs:
            key = _game_key(sport, g)
            st = state.setdefault(key, {'t': now})
            st['t'] = now
            soon = g['state'] == 'pre' and 0 <= (g.get('start') or 0) - now <= 40 * 60
            if g['state'] == 'in' or soon:
                active = True
                if sport != 'soccer':
                    soccer_only = False
            kinds = []
            if g['state'] == 'in' and not st.get('live'):
                st['live'] = True
                kinds.append('live')
            if _ls.is_overtime(g) and not st.get('ot'):
                st['ot'] = True
                kinds.append('ot')
            elif (_setting('myteams_alert_close') != 'false' and _ls.is_close_late(sport, g)
                  and not st.get('close') and not st.get('ot')):
                st['close'] = True
                kinds.append('close')
            if g['state'] == 'post' and st.get('live') and not st.get('final') and _setting('myteams_alert_final', 'false') == 'true':
                st['final'] = True
                kinds.append('final')
            for kind in kinds[:1]:                       # one alert per game per pass (the most important comes first)
                if (key, kind) in alerted:
                    continue
                alerted.add((key, kind))
                _alert(kind, sport, team, g)
    _save_state(state)
    if not active:
        return POLL_IDLE
    return POLL_SOCCER_ACTIVE if soccer_only else POLL_ACTIVE


def run(monitor):
    """Service thread body: a pass every `tick()` seconds until Kodi shuts down. Never raises."""
    if monitor.waitForAbort(45):                         # let Kodi finish starting before the first look
        return
    while not monitor.abortRequested():
        try:
            delay = tick()
        except Exception as e:
            _log('pass failed: %s' % e)
            delay = POLL_IDLE
        if monitor.waitForAbort(delay):
            break
