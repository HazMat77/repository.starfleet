# -*- coding: utf-8 -*-
"""
resources/lib/simkl_auth.py

SIMKL account pairing (PIN device-code flow) — same idea as trakt_auth.py's
Trakt pairing, mirrored for SIMKL (simkl.com), a competing watch-tracking
service for movies/TV/anime. Independent of Trakt — nothing here touches
trakt_auth.py or its settings. Backs watch_history.py's SIMKL scrobble/
resume sync (see simkl_sync.py) the same way trakt_auth.py was meant to.

Uses a bundled SIMKL_CLIENT_ID — same shared-app model as metadata.py's
TMDB_KEYS/TMDB_V4_READ_TOKEN: a client_id only identifies "this is the
Starfleet app" to SIMKL, it does not grant access to any account's data.
Every user still personally enters the PIN code at simkl.com/pin (or scans
the QR code below) and logs into their own SIMKL account to approve, which
is what actually grants THEIR access_token. No registration/setup needed
on any device — "Pair with SIMKL" is a single click.

SIMKL's PIN flow (verified against api.simkl.org, 2026):
  1. GET https://api.simkl.com/oauth/pin
       ?client_id=...&app-name=...&app-version=...
     -> {"result":"OK","user_code":"5G6JAH",
         "verification_uri":"https://simkl.com/pin",
         "expires_in":900,"interval":5}
  2. Show user_code (+ a QR code for verification_uri, if pyqrcode is
     available — script.module.pyqrcode ships as a transitive dependency
     of script.module.resolveurl, which this addon already requires, same
     library ResolveURL's own debrid-pairing QR codes use).
  3. Poll GET https://api.simkl.com/oauth/pin/{user_code}
       ?client_id=...&app-name=...&app-version=... every `interval` seconds:
       - {"result":"KO","message":"Authorization pending"} -> keep polling
       - {"result":"OK","access_token":"..."} -> done
     A response containing a 'device_code' field means the original code
     was garbage-collected (expired/already used) — stop and restart.

Unlike Trakt's device flow, SIMKL's PIN flow needs no client_secret at all —
just client_id, plus an app-name/app-version pair SIMKL asks every client to
send for their own debugging, and a descriptive User-Agent header.
"""
import time
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.gui import progress_dialog as _pdlg
from resources.lib.gui import qr_dialog as _qrdlg

ADDON      = xbmcaddon.Addon('plugin.video.starfleet')
SIMKL_BASE = 'https://api.simkl.com'
APP_NAME   = 'starfleet-kodi'
APP_VERSION = ADDON.getAddonInfo('version') or '1.0'
USER_AGENT  = 'plugin.video.starfleet/%s' % APP_VERSION

# Confirmed live against /oauth/pin before bundling (same shared-app model
# as TMDB_V4_READ_TOKEN in metadata.py — see this module's docstring).
SIMKL_CLIENT_ID = 'd5b1d975cd0ebcaff604b3142d049ff1ffdedb7f781f9cfc8b43f6f50af1df87'


def is_paired():
    # A fresh Addon() every call, NOT the module-level ADDON above -
    # confirmed live as a real bug for the identical TMDB-pairing case (see
    # favorites.py's _addon() docstring for the full story): a long-lived
    # process (this addon's Home screen runs as one for the whole session)
    # that imported this module before pairing completed would otherwise
    # keep reading a settings snapshot frozen from before the pairing
    # write, no matter how long it's been since.
    return bool(xbmcaddon.Addon('plugin.video.starfleet').getSetting('simkl_access_token').strip())


def unpair():
    ADDON.setSetting('simkl_access_token', '')


def pair_with_simkl():
    """Run the full PIN pairing flow, showing a QR code (if available) plus
    the short code in a Kodi dialog. Bound to the simkl_pair Settings
    action. No credentials to enter first — see this module's docstring
    for why the bundled client_id covers that step."""
    try:
        import requests
    except Exception:
        xbmcgui.Dialog().notification('Starfleet', 'requests module unavailable',
                                      xbmcgui.NOTIFICATION_ERROR)
        return

    headers = {'User-Agent': USER_AGENT}
    params  = {'client_id': SIMKL_CLIENT_ID, 'app-name': APP_NAME, 'app-version': APP_VERSION}

    try:
        r = requests.get(SIMKL_BASE + '/oauth/pin', params=params,
                         headers=headers, timeout=10)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/SIMKL] oauth/pin error: %s' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Starfleet', 'SIMKL pairing failed to start',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    user_code  = data.get('user_code')
    verify_url = data.get('verification_uri', data.get('verification_url', 'simkl.com/pin'))
    expires_in = data.get('expires_in', 900)
    interval   = data.get('interval', 5)

    if not user_code:
        xbmcgui.Dialog().notification('Starfleet', 'SIMKL pairing failed to start',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    msg = 'Scan, or go to %s and enter code: %s' % (verify_url, user_code)
    qr_path = _qrdlg.make_qr(verify_url, 'starfleet_simkl_qr.png')
    qr_dlg, txt_dlg = None, None
    if qr_path:
        qr_dlg = _qrdlg.QRDialog(qr_path, 'Pair with SIMKL',
                                 'Scan, or go to %s' % verify_url, code=user_code)
        qr_dlg.show()
    else:
        txt_dlg = _pdlg.DialogProgress()
        txt_dlg.create('Starfleet - Pair with SIMKL', msg)

    def _iscanceled():
        return qr_dlg.iscanceled() if qr_dlg else txt_dlg.iscanceled()

    def _update():
        # qr_dlg has its own separate, always-visible instruction line (the
        # URL/code itself never changes) - its update() call only ever
        # needs a short, genuinely different status string here, never
        # `msg` again (confirmed live: passing the same text back in made
        # the URL/code line visually repeat itself under the QR every few
        # seconds). The plain-text fallback dialog has no separate
        # instruction line at all, so it still needs the full `msg`.
        if qr_dlg:
            qr_dlg.update('Waiting for you to approve… (%ds)' % waited)
        else:
            txt_dlg.update(min(99, int(100 * waited / expires_in)), msg)

    def _close():
        (qr_dlg or txt_dlg).close()

    waited = 0
    while waited < expires_in:
        if _iscanceled():
            _close()
            return
        time.sleep(interval)
        waited += interval
        _update()

        try:
            pr = requests.get(SIMKL_BASE + '/oauth/pin/%s' % user_code,
                              params=params, headers=headers, timeout=10)
            pr.raise_for_status()
            pdata = pr.json()
        except Exception as e:
            xbmc.log('[Starfleet/SIMKL] pin poll error: %s' % e, xbmc.LOGWARNING)
            continue

        if 'device_code' in pdata:
            # Original code was garbage-collected (expired/used elsewhere) —
            # this response shape is a fresh init response, not a poll result.
            _close()
            xbmcgui.Dialog().notification('Starfleet', 'SIMKL: code expired, try again',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            return

        if pdata.get('result') == 'OK' and pdata.get('access_token'):
            ADDON.setSetting('simkl_access_token', pdata['access_token'])
            _close()
            xbmcgui.Dialog().notification('Starfleet', 'SIMKL account paired',
                                          xbmcgui.NOTIFICATION_INFO, 3000)
            # Per direct request: offer a clean break from this device's own
            # local movie/TV progress right at the moment SIMKL becomes the
            # cross-device source of truth, rather than leaving old local-only
            # entries sitting in Continue Watching indefinitely alongside it.
            # Adult content is untouched either way — SIMKL never tracks it
            # (see simkl_sync.py's _real_imdb() filter) and it has its own
            # separate Settings toggle, unrelated to this prompt.
            try:
                if xbmcgui.Dialog().yesno(
                        'Starfleet - SIMKL',
                        'SIMKL is now paired.\n\nDelete this device\'s local movie/TV '
                        'watch progress and use only SIMKL going forward?\n\n'
                        '(Adult content progress is not affected either way.)'):
                    from resources.lib import watch_history as _wh
                    removed = _wh.clear_non_adult()
                    xbmcgui.Dialog().notification(
                        'Starfleet', 'Cleared %d local entr%s' % (removed, 'y' if removed == 1 else 'ies'),
                        xbmcgui.NOTIFICATION_INFO, 3000)
            except Exception as e:
                xbmc.log('[Starfleet/SIMKL] post-pair local-clear prompt error: %s' % e, xbmc.LOGWARNING)
            return
        # result == 'KO' / "Authorization pending" — keep polling

    _close()
    xbmcgui.Dialog().notification('Starfleet', 'SIMKL pairing timed out',
                                  xbmcgui.NOTIFICATION_INFO, 4000)


def show_status():
    """Bound to the simkl_status Settings action."""
    if is_paired():
        if xbmcgui.Dialog().yesno('Starfleet - SIMKL', 'SIMKL account is paired.\n\nUnpair?'):
            unpair()
            xbmcgui.Dialog().notification('Starfleet', 'SIMKL unpaired',
                                          xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok('Starfleet - SIMKL', 'Not paired yet. Use "Pair with SIMKL" above.')
