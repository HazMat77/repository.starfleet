﻿# -*- coding: utf-8 -*-
"""
resources/lib/ade.py — Adult DVD Empire metadata scraper

URL patterns (as of 2024):
  Search:  GET https://www.adultdvdempire.com/allsearch/search?q=TITLE&type=product
  Detail:  https://www.adultdvdempire.com/{id}/{slug}.html
  Covers:  https://imgs1cdn.adultempire.com/products/{id[-2:]}/{id}h.jpg  (front cover)
           https://imgs1cdn.adultempire.com/products/{id[-2:]}/{id}bh.jpg (back cover)

Age confirmation: site requires a POST to /Account/AgeConfirmation before any content.
Cache TTLs:
  Search results  → 6 h
  Film detail     → 24 h
"""

import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

import requests
from resources.lib import cache as _cache
from resources.lib.title_utils import clean_adult_title as _clean_title
_cache.init(_CACHE_DB)

BASE = 'https://www.adultdvdempire.com'

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': BASE + '/',
}

# ── Pre-compiled patterns ──────────────────────────────────────────────────────

_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE  = re.compile(r'\s+')

# Search result card: <a href="/ID/slug.html" ... title="Movie Title"
_RE_SEARCH_CARD = re.compile(
    r'href="/([\d]+)/([a-z0-9][a-z0-9-]*porn-movies\.html)"[^>]*title="([^"]+)"',
    re.IGNORECASE
)
# Also match cards where title attr is before href
_RE_SEARCH_CARD2 = re.compile(
    r'title="([^"]+)"[^>]*href="/([\d]+)/([a-z0-9][a-z0-9-]*porn-movies\.html)"',
    re.IGNORECASE
)
# product-details__item-title anchor: class="product-details__item-title" title="..."
_RE_SEARCH_TITLE_ANCHOR = re.compile(
    r'class="product-details__item-title"[^>]*href="/([\d]+)/([a-z0-9][a-z0-9-]*\.html)"[^>]*title="([^"]+)"',
    re.IGNORECASE
)
_RE_SEARCH_TITLE_ANCHOR2 = re.compile(
    r'href="/([\d]+)/([a-z0-9][a-z0-9-]*\.html)"[^>]*class="product-details__item-title"[^>]*title="([^"]+)"',
    re.IGNORECASE
)

# Detail page: title
_RE_TITLE = re.compile(
    r'class="movie-page__heading__title"[^>]*>\s*([^<]+)\s*<',
    re.IGNORECASE
)
_RE_TITLE_H1 = re.compile(r'<h1[^>]*>([^<]+)<', re.IGNORECASE)

# Synopsis
_RE_SYNOPSIS = re.compile(
    r'class="synopsis-content"[^>]*>\s*<p[^>]*>(.*?)</p>',
    re.IGNORECASE | re.DOTALL
)
_RE_SYNOPSIS2 = re.compile(
    r'class="synopsis-content"[^>]*>(.*?)</div>',
    re.IGNORECASE | re.DOTALL
)

# Studio: <a href="/studio-id/studio/name-porn-movies.html">Studio Name</a> near heading
_RE_STUDIO = re.compile(
    r'href="/\d+/[^"]+porn-movies\.html"[^>]*class="[^"]*studio[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_STUDIO2 = re.compile(
    r'<a[^>]+href="/\d+/[^"]*studios?-porn-movies\.html"[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_STUDIO3 = re.compile(
    r'(?:Studio|Label)[:\s]*(?:<[^>]+>)+([^<]{2,60})',
    re.IGNORECASE
)

# Year: <small>(YYYY)</small>
_RE_YEAR_SMALL = re.compile(r'<small>\s*\((\d{4})\)\s*</small>', re.IGNORECASE)
_RE_YEAR = re.compile(r'(?:Release\s*Date|Production\s*Year|Year)[^<]*(\d{4})', re.IGNORECASE)

# Cast: <a href="/ID/slug-pornstars.html" ... class="PerformerName">Name</a>
# Captures id+slug too (not just the name) so a cast entry can be traced back
# to that performer's own profile page — needed to fetch their headshot,
# since the photo CDN path isn't derivable from the id/slug alone (confirmed
# live: different performers use different numeric shard prefixes).
_RE_CAST_FULL = re.compile(
    r'href="/(\d+)/([a-z0-9][a-z0-9-]*pornstars?\.html)"[^>]*class="PerformerName"[^>]*>([^<]+)<',
    re.IGNORECASE
)
# Name-only fallbacks, kept in case a page's markup order differs from the above.
_RE_CAST = re.compile(
    r'class="PerformerName"[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_CAST2 = re.compile(
    r'href="/\d+/[^"]*pornstars?\.html"[^>]*>([^<]+)<',
    re.IGNORECASE
)

# Performer profile page headshot: <img ... src="...N_bust/slug.jpg" ...>
_RE_PERFORMER_PHOTO = re.compile(r'<img[^>]+src="([^"]+_bust/[^"]+)"', re.IGNORECASE)

# Director — confirmed live the real markup is
# '<div class="...directors..."><strong>Director:</strong>&nbsp;<a href="/ID/NAME-directors.html" ...>Name</a>...',
# i.e. one or more director links, not plain text right after the label —
# match the links directly instead of "whatever text follows some tags"
# (which used to grab the literal "&nbsp;" entity between the label and
# the first link, since that entity isn't itself inside a tag).
_RE_DIRECTOR_LINK = re.compile(
    r'href="/\d+/[^"]*-directors\.html"[^>]*>\s*([^<]{2,60}?)\s*</a>',
    re.IGNORECASE
)

# Runtime — confirmed live the real markup is
# '<li><small>Length: </small> 2 hrs. 22 mins.</li>', never a bare minute
# count directly after the label as this used to assume.
_RE_RUNTIME = re.compile(
    r'Length:\s*</small>\s*(?:(\d+)\s*hrs?\.?)?\s*(?:(\d+)\s*mins?\.?)?',
    re.IGNORECASE
)

# Rating
_RE_RATING = re.compile(
    r'(?:rating|score)[^>]*>\s*([0-9.]+)\s*(?:out\s*of|/)?',
    re.IGNORECASE
)

# Genres/categories — confirmed live the real href is "/ID/category/SLUG.html"
# directly, with no extra path segment between the numeric id and "category"
# the way the old pattern assumed (that version never matched anything on a
# real page, silently leaving every film's categories empty).
_RE_GENRES2 = re.compile(
    r'href="/\d+/category/[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE
)

# Browse listing cards — DVD and on-demand (streaming/download/video slugs)
_RE_BROWSE_CARD = re.compile(
    r'href="/([\d]+)/([a-z0-9][a-z0-9-]*(?:porn-movies|porn-videos|streaming|download)\.html)"[^>]*title="([^"]+)"',
    re.IGNORECASE
)
_RE_BROWSE_CARD2 = re.compile(
    r'title="([^"]+)"[^>]*href="/([\d]+)/([a-z0-9][a-z0-9-]*(?:porn-movies|porn-videos|streaming|download)\.html)"',
    re.IGNORECASE
)
# CDN images (caps1cdn or imgs1cdn)
_RE_CDN_IMG = re.compile(
    r'src="(https?://[a-z0-9.-]*(?:caps1cdn|imgs1cdn)[^"]+(?:\.jpg|\.jpeg|\.png|\.webp))"',
    re.IGNORECASE
)
# Nearest CDN thumbnail within a card chunk (both img1cdn and caps1cdn)
_RE_NEAR_IMG = re.compile(
    r'src="(https?://(?:imgs\d+cdn|caps\d+cdn|img\d+\.adultempire)[^"]+\.(?:jpg|jpeg|png|webp))"',
    re.IGNORECASE
)
# og:image meta tag — canonical cover for DVDs and streaming videos alike
_RE_OG_IMAGE  = re.compile(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', re.IGNORECASE)
_RE_OG_IMAGE2 = re.compile(r'<meta[^>]+content="([^"]+)"[^>]+property="og:image"', re.IGNORECASE)


# ── HTTP session ───────────────────────────────────────────────────────────────

_session = None
_age_confirmed = False


def _sess():
    global _session, _age_confirmed
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        a = requests.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=requests.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)

    if not _age_confirmed:
        try:
            _session.get(BASE + '/', timeout=10)
            _session.post(
                BASE + '/Account/AgeConfirmation',
                data={'ageConfirmationClicked': 'true'},
                headers={**HEADERS, 'X-Requested-With': 'XMLHttpRequest'},
                timeout=10
            )
            _age_confirmed = True
        except Exception as e:
            xbmc.log('[ADE] age confirm error: %s' % e, xbmc.LOGWARNING)

    return _session


def _get(url, params=None, timeout=12):
    r = _sess().get(url, params=params, timeout=timeout)
    r.raise_for_status()
    return r.text


def _clean(text):
    text = _RE_STRIP_TAGS.sub(' ', text)
    return _RE_WHITESPACE.sub(' ', text).strip()


def _cover_url(film_id, variant='h'):
    """Build CDN cover URL from film ID. variant: 'h'=front high, 'bh'=back high."""
    sid = str(film_id)
    return 'https://imgs1cdn.adultempire.com/products/%s/%s%s.jpg' % (sid[-2:], sid, variant)


def trailer_url(film_id):
    """Return the HLS trailer stream URL for a film. No account required."""
    return 'https://trailer.adultempire.com/hls/trailer/%s/master.m3u8' % film_id


# ── Public API ─────────────────────────────────────────────────────────────────

def search_by_title(title):
    """
    Search ADE for `title`. Returns a metadata dict or None.
    Cached 6 hours.
    """
    ck = 'ade_search_%s' % re.sub(r'[^a-z0-9]', '_', title.lower())[:80]
    cached = _cache.get(ck)
    if cached is not None:
        return cached if cached else None

    try:
        html = _get(BASE + '/allsearch/search', params={'q': title, 'type': 'product'})
    except Exception as e:
        xbmc.log('[ADE] search error for "%s": %s' % (title, e), xbmc.LOGWARNING)
        return None

    film = _parse_search_result(html, title)
    _cache.set(ck, film if film else False, 6 * 3600)

    if film:
        xbmc.log('[ADE] search "%s" → "%s"' % (title, film.get('title', '')), xbmc.LOGINFO)
    else:
        xbmc.log('[ADE] search "%s" → no match' % title, xbmc.LOGINFO)

    return film


def search_films(query, search_type='product', limit=30):
    """
    Search ADE for `query`, returning ALL matching films as a list (unlike
    search_by_title, which returns only the single best match — built for
    "find the exact movie behind this exact title" enrichment, not "show me
    everything matching this"). Reuses the same card markup every browse
    listing page already uses, since ADE's search results page turns out to
    be built from identical cards — confirmed live.

    search_type: 'product' (default, matches titles AND genre/category tags
    — confirmed live that a genre keyword like "MILF" returns the correct
    genre-tagged films even on the default type) or 'talent' (performer
    name — confirmed live this filters to a specific performer's actual
    filmography, not just a title-text coincidence).
    """
    ck = 'ade_searchlist_%s_%s' % (search_type, re.sub(r'[^a-z0-9]', '_', query.lower())[:60])
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []

    try:
        html = _get(BASE + '/allsearch/search', params={'q': query, 'type': search_type})
    except Exception as e:
        xbmc.log('[ADE] search_films(%s, %s) error: %s' % (query, search_type, e), xbmc.LOGWARNING)
        return []

    films = _parse_browse_page(html)[:limit]
    _cache.set(ck, films or False, 6 * 3600)
    xbmc.log('[ADE] search_films(%s, %s) → %d films' % (query, search_type, len(films)), xbmc.LOGINFO)
    return films


def search_by_talent(name, limit=30):
    """Films featuring a specific performer, by ADE's own performer-filtered
    search (type=talent) — not a title-text search."""
    return search_films(name, search_type='talent', limit=limit)


def get_film_detail(film_id, film_slug):
    """
    Fetch full ADE detail page for a known film.
    Returns metadata dict. Cached 24 h.
    """
    ck = 'ade_detail_%s' % film_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    # New URL format uses .html extension
    slug = film_slug if film_slug.endswith('.html') else film_slug
    url = '%s/%s/%s' % (BASE, film_id, slug)
    if not url.endswith('.html'):
        url = url.rstrip('/') + '.html'

    try:
        html = _get(url)
        detail = _parse_detail(film_id, film_slug, html)
        _cache.set(ck, detail, 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[ADE] detail(%s) error: %s' % (film_id, e), xbmc.LOGWARNING)
        return _minimal(film_id, film_slug)


def get_trailer_url(title):
    """
    Search ADE for title and return its HLS trailer URL.
    Trailer CDN: trailer.adultempire.com/hls/trailer/{id}/master.m3u8 — no auth.
    """
    film = search_by_title(title)
    if film:
        return trailer_url(film['id'])
    return ''


def get_performer_photo(performer_id, performer_slug):
    """
    Fetch a performer's headshot photo URL from their ADE profile page
    (e.g. /497013/alexis-may-pornstars.html). Requires an actual page fetch
    — the CDN path (imgs1cdn.adultempire.com/actor/{shard}/{id}_bust/{slug}.jpg)
    uses a per-performer shard prefix that isn't derivable from the id/slug
    alone (confirmed live: different performers use different prefixes, not
    a simple id-based formula like film covers use). Cached 30 days since a
    performer's profile photo essentially never changes.
    """
    if not performer_id or not performer_slug:
        return ''
    ck = 'ade_performer_photo_%s' % performer_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached or ''
    try:
        url = '%s/%s/%s' % (BASE, performer_id, performer_slug)
        html = _get(url)
        m = _RE_PERFORMER_PHOTO.search(html)
        photo = m.group(1) if m else ''
        _cache.set(ck, photo or False, 30 * 24 * 3600)
        return photo
    except Exception as e:
        xbmc.log('[ADE] get_performer_photo(%s) error: %s' % (performer_id, e), xbmc.LOGWARNING)
        return ''


def get_cast_with_photos(cast, limit=4):
    """
    Given a film's cast list (from get_film_detail — each entry has
    id/slug/name when the detail page's markup matched _RE_CAST_FULL),
    fetch headshot photos for up to `limit` of them in parallel. One HTTP
    request per performer is unavoidable (see get_performer_photo); running
    them concurrently keeps total latency close to a single request instead
    of stacking N of them sequentially for every focus change.
    """
    subset = [c for c in cast if c.get('id') and c.get('slug')][:limit]
    if not subset:
        return [{'name': c.get('name', ''), 'photo': ''} for c in cast[:limit]]
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=len(subset)) as pool:
        photos = list(pool.map(lambda c: get_performer_photo(c['id'], c['slug']), subset))
    return [{'name': c['name'], 'photo': photo} for c, photo in zip(subset, photos)]


def _browse(cache_key, url_page1, url_pageN_tpl, page=1, label='section'):
    """
    Generic paginated browse helper.  url_pageN_tpl uses %d for the page number.
    Returns list of film stub dicts.  Caches 6 h (empty pages cached 1 h).
    """
    ck = '%s_%d' % (cache_key, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = url_page1 if page <= 1 else (url_pageN_tpl % page)
    try:
        html  = _get(url)
        films = _parse_browse_page(html)
        _cache.set(ck, films or False, 6 * 3600)
        xbmc.log('[ADE] %s page=%d → %d films' % (label, page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[ADE] %s page=%d error: %s' % (label, page, e), xbmc.LOGWARNING)
        _cache.set(ck, False, 3600)
        return []


# ── DVD/Video sections ──────────────────────────────────────────────────────────
#
# ADE restructured its site (2026): the old "-porn-movies.html" / path-based
# "/name/2.html" pagination scheme is dead (silently 302s to the homepage via
# ?aspxerrorpath=, HTTP 200 masking the failure). Confirmed live via direct
# testing: content now lives under "-porn-videos.html" URLs (plus two
# still-alive "-porn-movies.html" survivors), and ALL pagination site-wide is
# now a "?page=N" query string, not a path segment. DVD genre categories
# (milf/anal/etc, both -movies and -videos naming) and the entire
# /on-demand/... namespace are confirmed fully dead with no live replacement
# found on ADE's own current navigation — dropped rather than left broken.

def browse_new_releases(page=1):
    """New release videos: /new-release-porn-videos.html."""
    return _browse('ade_new_v2', BASE + '/new-release-porn-videos.html',
                   BASE + '/new-release-porn-videos.html?page=%d', page, 'new release videos')


def browse_bestsellers(page=1):
    """Bestselling movies: /best-selling-porn-movies.html (still alive)."""
    return _browse('ade_dvd_best', BASE + '/best-selling-porn-movies.html',
                   BASE + '/best-selling-porn-movies.html?page=%d', page, 'DVD bestsellers')


def browse_new_release_movies(page=1):
    """New release movies: /new-release-porn-movies.html (still alive)."""
    return _browse('ade_new_rel2', BASE + '/new-release-porn-movies.html',
                   BASE + '/new-release-porn-movies.html?page=%d', page, 'new release movies')


def browse_recently_added_videos(page=1):
    """Recently added videos: /new-addition-porn-videos.html."""
    return _browse('ade_recent_add2', BASE + '/new-addition-porn-videos.html',
                   BASE + '/new-addition-porn-videos.html?page=%d', page, 'recently added videos')


def browse_bestseller_videos(page=1):
    """Best selling videos: /best-selling-porn-videos.html."""
    return _browse('ade_bestsell_v', BASE + '/best-selling-porn-videos.html',
                   BASE + '/best-selling-porn-videos.html?page=%d', page, 'bestseller videos')


# ── Parsers ────────────────────────────────────────────────────────────────────

def _minimal(film_id, slug):
    return {
        'id':          film_id,
        'slug':        slug,
        'title':       _clean_title(re.sub(r'-porn-movies.*', '', slug).replace('-', ' ').title()),
        'description': '',
        'year':        '',
        'runtime':     0,
        'studio':      '',
        'director':    '',
        'rating':      0.0,
        'cast':        [],
        'categories':  [],
        'thumb':       _cover_url(film_id, 'h'),
        'fanart':      _cover_url(film_id, 'bh'),
        'backcover':   _cover_url(film_id, 'bh'),
        'trailer':     trailer_url(film_id),
        'source':      'ade',
    }


def _parse_search_result(html, query):
    """
    Parse the first relevant movie from an ADE search results page.
    Returns a metadata dict or None.
    """
    import unicodedata

    def _norm(t):
        t = t.lower()
        t = ''.join(c for c in unicodedata.normalize('NFD', t)
                    if unicodedata.category(c) != 'Mn')
        t = re.sub(r'[^a-z0-9 ]', '', t)
        return re.sub(r'\s+', ' ', t).strip()

    norm_q = _norm(query)
    candidates = []  # (film_id, slug, title)

    def _add_candidate(fid, fslug, ftitle):
        fid = fid.strip()
        fslug = fslug.strip()
        ftitle = _clean_title(_clean(ftitle))
        if fid and fslug and ftitle and not any(c[0] == fid for c in candidates):
            candidates.append((fid, fslug, ftitle))

    # Pattern: class="product-details__item-title" with title attr
    for m in _RE_SEARCH_TITLE_ANCHOR.finditer(html):
        _add_candidate(m.group(1), m.group(2), m.group(3))
    for m in _RE_SEARCH_TITLE_ANCHOR2.finditer(html):
        _add_candidate(m.group(1), m.group(2), m.group(3))

    # Pattern: href="/ID/slug.html" title="Title"
    for m in _RE_SEARCH_CARD.finditer(html):
        _add_candidate(m.group(1), m.group(2), m.group(3))
    for m in _RE_SEARCH_CARD2.finditer(html):
        _add_candidate(m.group(2), m.group(3), m.group(1))

    # Broad fallback: any /ID/slug-porn-movies.html with a title attr
    if not candidates:
        for m in re.finditer(
            r'href="/([\d]+)/([a-z0-9][a-z0-9-]*porn-movies\.html)"',
            html, re.IGNORECASE
        ):
            fid, fslug = m.group(1), m.group(2)
            # Look for a nearby title attribute or text
            region = html[max(0, m.start() - 50): m.end() + 200]
            tm = re.search(r'title="([^"]+)"', region)
            if tm:
                _add_candidate(fid, fslug, tm.group(1))

    if not candidates:
        return None

    # Score candidates
    best = None
    best_score = -1
    for fid, fslug, ftitle in candidates:
        norm_t = _norm(ftitle)
        if norm_t == norm_q:
            best = (fid, fslug, ftitle)
            break
        q_words = set(norm_q.split())
        t_words = set(norm_t.split())
        score   = len(q_words & t_words) / max(len(q_words), 1)
        if score > best_score:
            best_score = score
            best = (fid, fslug, ftitle)

    if not best or best_score < 0.4:
        # If we have candidates but no good match, return first one anyway
        if candidates:
            best = candidates[0]
        else:
            return None

    film_id, film_slug, film_title = best

    detail = _minimal(film_id, film_slug)
    detail['title'] = film_title
    # Thumb already set by _minimal via _cover_url
    return detail


def _parse_browse_page(html):
    """Parse a browse/listing page, returning list of film stub dicts."""
    films = []
    seen  = set()

    def _add(fid, fslug, ftitle, pos):
        if fid in seen or not fid or not fslug or not ftitle:
            return
        seen.add(fid)
        d = _minimal(fid, fslug)
        d['title'] = _clean_title(_clean(ftitle))
        # Pull the nearest CDN thumbnail from the card HTML (±700 chars around the link).
        # This correctly handles video items whose covers live on caps1cdn, not imgs1cdn.
        # Must pick the match CLOSEST to `pos`, not the first one in the window —
        # a plain .search() returns the leftmost match, which in a dense grid is
        # often a neighboring card's cover, mismatching that film's poster/title.
        window_start = max(0, pos - 700)
        chunk = html[window_start:min(len(html), pos + 700)]
        anchor_offset = pos - window_start
        best_url, best_dist = None, None
        for img_m in _RE_NEAR_IMG.finditer(chunk):
            dist = abs(img_m.start() - anchor_offset)
            if best_dist is None or dist < best_dist:
                best_dist = dist
                best_url = img_m.group(1)
        if best_url:
            d['thumb']  = best_url
            d['fanart'] = best_url
        films.append(d)

    for m in _RE_BROWSE_CARD.finditer(html):
        _add(m.group(1), m.group(2), m.group(3), m.start())
    for m in _RE_BROWSE_CARD2.finditer(html):
        _add(m.group(2), m.group(3), m.group(1), m.start())

    return films


def _parse_detail(film_id, film_slug, html):
    detail = _minimal(film_id, film_slug)

    # Title
    m = _RE_TITLE.search(html)
    if not m:
        m = _RE_TITLE_H1.search(html)
    if m:
        detail['title'] = _clean_title(_clean(m.group(1)))

    # Cover — og:image is canonical and works for both DVDs and streaming video clips.
    # _minimal() pre-fills the DVD CDN formula as a fallback; override with og:image here.
    # Keep backcover from _minimal (DVD CDN `bh` variant) as a separate fanart source.
    for _pat in (_RE_OG_IMAGE, _RE_OG_IMAGE2):
        _im = _pat.search(html)
        if _im and _im.group(1).startswith('http'):
            detail['thumb'] = _im.group(1)
            # Only override fanart if we don't already have a separate back cover
            if not detail.get('backcover'):
                detail['fanart'] = _im.group(1)
            break
    # Also look for any high-res CDN still/screenshot to use as fanart background
    _cdn_imgs = _RE_CDN_IMG.findall(html)
    if _cdn_imgs:
        # Prefer the largest/last CDN image that isn't the same as thumb
        for _ci in reversed(_cdn_imgs):
            if _ci != detail.get('thumb') and 'caps1cdn' in _ci:
                detail['fanart'] = _ci
                break

    # Synopsis
    m = _RE_SYNOPSIS.search(html)
    if not m:
        m = _RE_SYNOPSIS2.search(html)
    if m:
        detail['description'] = _clean(m.group(1))[:800]

    # Studio
    m = _RE_STUDIO.search(html) or _RE_STUDIO2.search(html) or _RE_STUDIO3.search(html)
    if m:
        detail['studio'] = _clean(m.group(1))

    # Director — a film can have more than one (e.g. co-directors), joined
    # for display; dedup preserves first-seen order.
    directors = []
    seen_dir = set()
    for m in _RE_DIRECTOR_LINK.finditer(html):
        name = _clean(m.group(1))
        if name and name not in seen_dir:
            seen_dir.add(name)
            directors.append(name)
    if directors:
        detail['director'] = ', '.join(directors)

    # Year — try <small>(YYYY)</small> first
    m = _RE_YEAR_SMALL.search(html)
    if not m:
        m = _RE_YEAR.search(html)
    if m:
        detail['year'] = m.group(1)

    # Runtime — "X hrs. Y mins." → total minutes (either group can be absent,
    # e.g. a sub-hour title with just "45 mins.").
    m = _RE_RUNTIME.search(html)
    if m:
        hrs  = int(m.group(1)) if m.group(1) else 0
        mins = int(m.group(2)) if m.group(2) else 0
        if hrs or mins:
            detail['runtime'] = hrs * 60 + mins

    # Rating
    m = _RE_RATING.search(html)
    if m:
        try:
            detail['rating'] = float(m.group(1))
        except ValueError:
            pass

    # Cast — id+slug+name together when the markup order matches (lets a
    # cast entry be traced to its performer page for a headshot photo);
    # falls back to name-only patterns if that order doesn't match.
    cast = []
    seen_cast = set()
    for m in _RE_CAST_FULL.finditer(html):
        pid, pslug, name = m.group(1), m.group(2), _clean(m.group(3))
        if name and name not in seen_cast and len(name) > 2:
            seen_cast.add(name)
            cast.append({'id': pid, 'slug': pslug, 'name': name})
    if not cast:
        for pat in (_RE_CAST, _RE_CAST2):
            for m in pat.finditer(html):
                name = _clean(m.group(1))
                if name and name not in seen_cast and len(name) > 2:
                    seen_cast.add(name)
                    cast.append({'id': '', 'slug': '', 'name': name})
    detail['cast'] = cast

    # Genres/categories
    cats = []
    seen_c = set()
    for m in _RE_GENRES2.finditer(html):
        cat = _clean(m.group(1))
        if cat and cat not in seen_c and len(cat) > 1:
            seen_c.add(cat)
            cats.append(cat)
    detail['categories'] = cats

    # Trailer: HLS stream at trailer.adultempire.com, no account required
    detail['trailer'] = trailer_url(film_id)

    return detail
