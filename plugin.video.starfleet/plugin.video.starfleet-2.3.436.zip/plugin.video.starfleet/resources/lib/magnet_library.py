# -*- coding: utf-8 -*-
"""
resources/lib/magnet_library.py

Reads the cumulative, merge-not-overwrite magnet-library JSON files
produced by the standalone scraper suite's weekly/daily jobs
(scraper_knaben_movies.py/_tv.py/_adult.py, scraper_eztv_magnets.py,
scraper_eztv_airing_today.py — see that suite's magnet_library.py for the
merge logic). Movie/TV entries are keyed by exact tmdb_id — a hit there is
more reliable than any live scraper's title guess, no title matching
needed at all, the id lookup IS the match. Adult is different: it's
matched by clean title only, never an id — the addon's own Adult section
mixes multiple incompatible id namespaces (ADE/adultdvdempire.com vs AFDB/
adultfilmdatabase.com vs free-stream stubs, per this addon's own history),
so trusting whichever id happens to be on hand at a given adult call site
risks silently showing a completely different title's magnets. A fuzzy
title match (same _titles_match() word-overlap logic already used for
matching JSON-sourced sports events) can only ever under-match (find
nothing), never mismatch a title to the wrong content.

A magnet is an infohash, not an IP-bound stream URL, so last week's finds
stay valid indefinitely (until peers/debrid cache actually dies) — that's
why these files are worth reading at all instead of just relying on the
live search that already runs every time.
"""

import re
import xbmc

try:
    import requests as _req
except ImportError:
    _req = None

from resources.lib import cache as _cache

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
}

_DATA_BASE = 'https://hazmat77.github.io/repository.starfleet/data/'

# name -> hosted filename. All 4 are produced by run_magnets.py (weekly) /
# run_magnets_daily.py (eztv only, daily) in the standalone scraper suite.
_SOURCES = {
    'movie_magnets': _DATA_BASE + 'movie_magnets.json',
    'tv_magnets':    _DATA_BASE + 'tv_magnets.json',
    'adult_magnets': _DATA_BASE + 'adult_magnets.json',
    'eztv_magnets':  _DATA_BASE + 'eztv_magnets.json',
}


def _fetch(name):
    """Fetch+cache one library file. None on failure/missing. 30 min cache
    — these files only get refreshed weekly (or daily for eztv_magnets),
    so there's no benefit to re-fetching more often than that within a
    single Kodi session, but this still picks up a fresh run same-day."""
    ck = 'magnetlib_raw_%s' % name
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None
    url = _SOURCES.get(name)
    if not url or _req is None:
        return None
    try:
        r = _req.get(url, timeout=10, headers=_HEADERS)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/MagnetLib] fetch %s failed: %s' % (name, e), xbmc.LOGWARNING)
        _cache.set(ck, {}, 60)
        return None
    _cache.set(ck, data, 1800)
    return data


def _entry_to_results(entry, source_label):
    if not entry:
        return []
    out = []
    for m in (entry.get('magnets') or []):
        if not m.get('magnet') or not m.get('info_hash'):
            continue
        out.append({
            'title':     m.get('name') or entry.get('title', ''),
            'quality':   m.get('quality', ''),
            'info_hash': m.get('info_hash', ''),
            'magnet':    m.get('magnet', ''),
            'seeds':     0,   # not tracked by the cumulative library
            'size':      '',
            'source':    source_label,
        })
    return out


_RE_EP_MARKER = re.compile(r's0*(\d{1,2})[\s._-]*e0*(\d{1,3})(?!\d)', re.IGNORECASE)
_RE_SEASON_RANGE = re.compile(r's0*(\d{1,2})[\s._-]*(?:-|to)[\s._-]*s?0*(\d{1,2})\b', re.IGNORECASE)
_RE_SEASON_ONLY = re.compile(r'\bs(?:eason)?\.?\s*0*(\d{1,2})\b', re.IGNORECASE)


def _episode_ok(name, season, episode):
    """Same semantics as torrent_sources.search_all()'s own episode filter:
    a release with NO single-episode marker (season pack, 'S01-S05',
    'COMPLETE', etc.) is assumed to legitimately contain the target episode
    and kept; one WITH a marker must match it exactly. Confirmed live this
    was missing entirely from the cumulative-library path: a show's entry
    in eztv_magnets.json accumulates EVERY episode ever found for it (S02
    season packs, S02E03/E04/E06/E07/E08, even a later season's S03E01, all
    in the same flat list) — get_cached_magnets() returned the whole pile
    for every request regardless of which episode was actually asked for,
    so a "wrong episode" magnet could easily outrank the real one in the
    picker (e.g. by quality or just position). torrent_sources.py's own
    filter never saw these entries at all, since library results are
    appended in debrid_torrent.py AFTER that filter already ran.

    Confirmed live a second, related bug in this same function: a release
    with NO SxxExx marker isn't necessarily season-agnostic — a name like
    'Lioness 2023 S02 1080p x265-ELiTE EZTV' is a SEASON 2 pack (the '02'
    right there in the name), but with no 'E' part at all it never matched
    _RE_EP_MARKER, so it fell into the "no marker = assume it matches"
    branch and got treated as valid for a Season 3 Episode 1 request too —
    a real Season 2 pack outranking (or just sitting alongside) the actual
    S03E01 file in the picker, and playing the wrong season if picked. Now
    a bare season number/range in the name (no episode part) is treated as
    identifying its own season(s) explicitly, and rejected unless the
    target season is among them — only a release with no season indication
    of ANY kind (e.g. a plain 'COMPLETE' bundle) still falls through to the
    "assume it matches" default."""
    markers = _RE_EP_MARKER.findall(name or '')
    if markers:
        return any(int(s) == int(season) and int(e) == int(episode) for s, e in markers)

    rng = _RE_SEASON_RANGE.search(name or '')
    if rng:
        lo, hi = int(rng.group(1)), int(rng.group(2))
        if lo > hi:
            lo, hi = hi, lo
        return lo <= int(season) <= hi

    season_only = _RE_SEASON_ONLY.findall(name or '')
    if season_only:
        return any(int(s) == int(season) for s in season_only)

    return True


def _find_by_title(library, title):
    """Fuzzy title lookup for adult — deliberately never an id (see this
    module's own docstring for why). Lazy-imports sports_sources the same
    way json_data.py already does, to reuse the exact same word-overlap
    matcher rather than a second, slightly-different one."""
    if not library or not title:
        return None
    from resources.lib.sports_sources import _titles_match
    from resources.lib.title_utils import clean_adult_title
    clean_query = clean_adult_title(title)
    for entry in library.values():
        if _titles_match(clean_query, clean_adult_title(entry.get('title', '')), threshold=2):
            return entry
    return None


def get_cached_magnets(media_type, tmdb_id=None, title=None, season=None, episode=None):
    """Returns torrent_sources.py-shaped magnet dicts (same keys as every
    live scraper's own results, so these merge into search_all()'s output
    with no special-casing downstream) from whichever cumulative library
    applies to this media_type. Movie/TV: exact tmdb_id lookup. Adult:
    fuzzy clean-title match only — see this module's own docstring.

    For TV, season/episode (when given) filter out every entry that names a
    DIFFERENT episode (see _episode_ok's own docstring) — every show's
    library entry accumulates every episode ever found for it in one flat
    list, so without this a request for one specific episode got back
    every episode/season pack the library has ever seen for that show.
    """
    results = []
    if media_type == 'movie' and tmdb_id:
        entry = (_fetch('movie_magnets') or {}).get('tmdb:%s' % tmdb_id)
        results += _entry_to_results(entry, 'Knaben (library)')
    elif media_type == 'tv' and tmdb_id:
        # Two separate cumulative files can both have this show: Knaben's
        # weekly TV pass and EZTV's own 720p+ library/daily airing-today
        # feed — both keyed the same way (tmdb show id, under a "tvdb:"
        # prefix chosen for both when they were built, not an actual
        # TheTVDB id).
        tv_entry = (_fetch('tv_magnets') or {}).get('tvdb:%s' % tmdb_id)
        results += _entry_to_results(tv_entry, 'Knaben (library)')
        eztv_entry = (_fetch('eztv_magnets') or {}).get('tvdb:%s' % tmdb_id)
        results += _entry_to_results(eztv_entry, 'EZTV (library)')
        if season is not None and episode is not None:
            results = [r for r in results if _episode_ok(r.get('title', ''), season, episode)]
    elif media_type == 'adult' and title:
        entry = _find_by_title(_fetch('adult_magnets'), title)
        results += _entry_to_results(entry, 'Knaben (library)')
    return results
