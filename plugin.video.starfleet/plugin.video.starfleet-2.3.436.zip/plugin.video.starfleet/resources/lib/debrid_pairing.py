# -*- coding: utf-8 -*-
"""
resources/lib/debrid_pairing.py — device-code pairing for Real-Debrid,
AllDebrid, Premiumize, and TorBox: click one button, see a 4-6 digit code
AND a QR code, enter/scan it on any device, and the API key/token gets
saved automatically — no copy-pasting a raw API key at all.

Confirmed live 2026-08-06 via a real reported bug: an earlier version of
this module reimplemented each service's device-code HTTP flow from
scratch with a plain xbmcgui.DialogProgress, which crashed outright
(DialogProgress.update() takes only (percent, message) on this Kodi
version, not the old 4-arg (percent, line1, line2, line3) signature this
first draft assumed) — and even fixed, that path would only ever show
plain text, never a QR code.

Rewritten to delegate entirely to script.module.resolveurl's own bundled
resolver classes instead of re-implementing any of this — Starfleet
already REQUIRES that addon (see addon.xml's <import>), and gears itself
has zero debrid-pairing code of its own at all (confirmed by reading its
entire installed source): "pairing with gears" *is* ResolveURL's own
Settings > Authorize My Account flow, which already renders a real QR
code (via ResolveURL's bundled pyqrcode) alongside the short code inside
its own CustomProgressDialog.QRCodeProgressDialog, and is the actual,
tested, production code every other Kodi debrid client already relies on
for this. Calling resolver.authorize_resolver() here shows that exact
same dialog; the only thing this module adds is copying the resulting
token into Starfleet's OWN rd_api_key/ad_api_key/pm_api_key/tb_api_key
settings afterward, so Starfleet's own Settings screen reflects it and
debrid_torrent.py's _rd_key()/etc. (which already falls back to reading
ResolveURL's own stored token if Starfleet's own field is empty) has it
in both places.
"""
import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

_RESOLVEURL_INSTALLED_CHECK = "System.HasAddon(script.module.resolveurl)"


def _resolveurl_missing():
    if not xbmc.getCondVisibility(_RESOLVEURL_INSTALLED_CHECK):
        xbmcgui.Dialog().notification(
            'Starfleet', 'ResolveURL addon is required for pairing',
            xbmcgui.NOTIFICATION_ERROR, 5000)
        return True
    return False


def _run_resolveurl_auth(import_path, class_name, starfleet_setting, token_setting_name='token'):
    """Shared driver for all four services: import the named ResolveURL
    resolver class, run its own authorize_resolver() (real QR + code
    dialog, real HTTP polling, all inside ResolveURL's own tested code),
    then copy whatever it stored into Starfleet's own setting."""
    if _resolveurl_missing():
        return False
    try:
        module = __import__(import_path, fromlist=[class_name])
        resolver_cls = getattr(module, class_name)
        resolver = resolver_cls()
        resolver.authorize_resolver()
        token = (resolver.get_setting(token_setting_name) or '').strip()
    except Exception as e:
        xbmc.log('[Starfleet/Pairing] %s error: %s' % (class_name, e), xbmc.LOGWARNING)
        token = ''

    if not token:
        xbmcgui.Dialog().notification('Starfleet', 'Pairing was not completed',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        return False

    ADDON.setSetting(starfleet_setting, token)
    xbmcgui.Dialog().notification('Starfleet', 'Paired successfully',
                                  xbmcgui.NOTIFICATION_INFO, 4000)
    return True


def pair_realdebrid():
    return _run_resolveurl_auth('resolveurl.plugins.realdebrid', 'RealDebridResolver', 'rd_api_key')


def pair_alldebrid():
    return _run_resolveurl_auth('resolveurl.plugins.alldebrid', 'AllDebridResolver', 'ad_api_key')


def pair_premiumize():
    return _run_resolveurl_auth('resolveurl.plugins.premiumize_me', 'PremiumizeMeResolver', 'pm_api_key')


def pair_torbox():
    # TorBox's own resolver stores its token under 'apikey', not 'token'.
    return _run_resolveurl_auth('resolveurl.plugins.torbox', 'TorBoxResolver', 'tb_api_key',
                                 token_setting_name='apikey')


_PAIRERS = {
    'realdebrid': pair_realdebrid,
    'alldebrid':  pair_alldebrid,
    'premiumize': pair_premiumize,
    'torbox':     pair_torbox,
}


def pair(service):
    fn = _PAIRERS.get(service)
    if not fn:
        return False
    return fn()
