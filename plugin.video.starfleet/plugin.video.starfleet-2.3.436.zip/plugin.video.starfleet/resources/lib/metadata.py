﻿# -*- coding: utf-8 -*-
"""
resources/lib/metadata.py

Unified metadata client for TV Shows and Movies.

Sources:
  TMDB (The Movie Database) — movies + TV shows, images, cast, ratings
  TVDB (The TV Database)    — TV show episode details, aired dates
  IMDB ID                   — cross-reference via TMDB external_ids

API Keys (from Enterprise-Toolbox/my_common.py):
  TMDB: rotated across 6 keys to stay under rate limits
  TVDB: single key, JWT auth token cached 24h

Cache TTLs:
  Search results      → 1h
  Movie detail        → 7d  (rarely changes)
  TV show detail      → 24h
  Season/episodes     → 24h
  Cast                → 7d
  Images              → 7d
  TVDB token          → 23h (token valid 24h)

Image base URL: https://image.tmdb.org/t/p/
  Poster/thumb:  w500{poster_path}
  Fanart:        original{backdrop_path}
  Cast photo:    w185{profile_path}
  Still (ep):    w300{still_path}
"""

import random
import time
from functools import lru_cache
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

# ── API Keys ──────────────────────────────────────────────────────────────────

TMDB_KEYS = [
    'df33d5fbe29640895eb99174c801dbc7',
    'a7ebe77c68d738c3dd38348ee0c8f70f',
    'fe07cdedea76c769f430982de6c14842',
    '6cb7bcda188b8c9028544da7182242fd',
    'c577de0778f2ba33846ec5003332dbb6',
    '948f72aef4062585f9075b91b9c0c226',
]
TMDB_TOKEN  = 'c46469cc91ef531c87b21d10267ca47a6r8db'
TVDB_KEY    = '32b17143-9e3d-4b91-813f-c36bf66185a7'  # old key confirmed dead (401 InvalidAPIKey) — replaced with a fresh one, verified live

# v4 "API Read Access Token" — bootstraps the tmdb_auth.py pairing handshake
# (see the v4 auth section below). Same shared-app model as TMDB_KEYS above:
# this identifies the Starfleet app to TMDB, it does NOT grant access to any
# particular account's data — every installer still personally logs into
# their own TMDB account and approves during pairing, getting their own
# separate access_token, exactly like every other Starfleet user sharing
# TMDB_KEYS above for search/metadata never exposes anyone's own account.
# Confirmed live against /4/auth/request_token before bundling.
TMDB_V4_READ_TOKEN = ('eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4MmM0NTQyNjc2OGM5MTAzN2Iw'
                      'NzBhZGEwMmZlZTg4OCIsIm5iZiI6MTY5NDU1OTI0NS4wNzIsInN1YiI6'
                      'IjY1MDBlYzBkZjI5ZDY2MDExZDVjOWEwNCIsInNjb3BlcyI6WyJhcGlf'
                      'cmVhZCJdLCJ2ZXJzaW9uIjoxfQ.rYzJrWFbkRliHhfsI--NhNgx40qZ'
                      'Fo3jsU_FyKU1xMc')

TMDB_BASE    = 'https://api.themoviedb.org/3'
TMDB_BASE_V4 = 'https://api.themoviedb.org/4'
TMDB_IMG    = 'https://image.tmdb.org/t/p'
TVDB_BASE   = 'https://api4.thetvdb.com/v4'   # TVDB v4 API

# ── HTTP Session ──────────────────────────────────────────────────────────────

_session = None

def _sess():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update({
            'User-Agent': 'plugin.video.starfleet/1.0',
            'Accept':     'application/json',
        })
        a = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=10,
            max_retries=requests.adapters.Retry(total=3, backoff_factor=0.4)
        )
        _session.mount('https://', a)
    return _session


def _tmdb_key():
    """Rotate through TMDB keys to spread rate limit."""
    return random.choice(TMDB_KEYS)


# ── TMDB HTTP ─────────────────────────────────────────────────────────────────

def _tmdb_get(endpoint, params=None, timeout=10):
    """GET from TMDB API with API key injected."""
    p = {'api_key': _tmdb_key(), 'language': 'en-US'}
    if params:
        p.update(params)
    r = _sess().get(TMDB_BASE + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def get_tmdb_list(list_id):
    """Fetch a public TMDB v3 List (the same list at themoviedb.org/list/
    <id>) by ID — backs favorites.py's optional 'sync Favorites from a
    TMDB List' setting. Confirmed live: TMDB's own /list/{id} endpoint
    already tags every item with 'media_type' ('movie' or 'tv'), so one
    list can freely mix both and this just passes items through as-is for
    the caller to split. Also confirmed live: the endpoint paginates at
    ~20 items/page (a 68-item list returned total_pages=4) even though it
    takes no explicit per_page/limit param — fetches every page instead
    of silently truncating to the first 20. Returns [] on any error
    (bad/private list ID, network failure) rather than raising, since
    this is read on every Favorites-widget render."""
    try:
        items = []
        page, total_pages = 1, 1
        while page <= total_pages:
            data = _tmdb_get('/list/%s' % list_id, params={'page': page})
            items.extend(data.get('items') or [])
            total_pages = min(int(data.get('total_pages') or 1), 20)  # sanity cap
            page += 1
        return items
    except Exception as e:
        xbmc.log('[Starfleet/Metadata] get_tmdb_list(%s) error: %s' % (list_id, e), xbmc.LOGWARNING)
        return []


# ── TMDB v4 account auth + list write ──────────────────────────────────────────
# Separate, unrelated auth system from the v3 api_key above. TMDB's v3 list
# write endpoints (list/{id}/add_item) only ever accept a bare movie
# media_id — confirmed live they're literally titled "Add Movie"/"Remove
# Movie" in TMDB's own API reference, no media_type field exists to pass a
# TV id through. Since this addon's Favorites already mix movies and TV in
# one list (see get_tmdb_list() above), only v4's list-write endpoint
# (which does take a media_type per item) can push both kinds back. v4 has
# its own, unrelated OAuth-ish handshake: the caller needs a personal "API
# Read Access Token (v4 auth)" (from the account's own themoviedb.org
# Settings > API page — there's no bundle-wide token like TMDB_KEYS above,
# each user registers/owns their own) as the Bearer for the 2 handshake
# calls below; the resulting access_token from step 2 (not the read
# token) is what actually authorizes list writes afterward.

def tmdb_v4_request_token(read_token):
    """Step 1 of v4 pairing. Returns (request_token, error_message) — one
    is always '' on success/failure respectively."""
    try:
        r = _sess().post(TMDB_BASE_V4 + '/auth/request_token', json={},
                          headers={'Authorization': 'Bearer %s' % read_token,
                                   'Content-Type': 'application/json'},
                          timeout=10)
        data = r.json()
        if data.get('success') and data.get('request_token'):
            return data['request_token'], ''
        return '', data.get('status_message', 'Unknown error')
    except Exception as e:
        xbmc.log('[Starfleet/Metadata] tmdb_v4_request_token error: %s' % e, xbmc.LOGWARNING)
        return '', str(e)


def tmdb_v4_create_access_token(read_token, request_token):
    """Step 2 of v4 pairing — call only after the user has approved
    request_token at themoviedb.org/auth/access. Returns a dict with
    'success' (bool) plus 'access_token'/'account_id' on success —
    'success': False with no exception is the normal "not approved yet"
    response, since TMDB has no separate pending-status check to poll."""
    try:
        r = _sess().post(TMDB_BASE_V4 + '/auth/access_token',
                          json={'request_token': request_token},
                          headers={'Authorization': 'Bearer %s' % read_token,
                                   'Content-Type': 'application/json'},
                          timeout=10)
        return r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Metadata] tmdb_v4_create_access_token error: %s' % e, xbmc.LOGWARNING)
        return {'success': False}


def _tmdb_v4_list_write(method, list_id, access_token, media_type, media_id):
    try:
        r = _sess().request(
            method, TMDB_BASE_V4 + '/list/%s/items' % list_id,
            json={'items': [{'media_type': media_type, 'media_id': int(media_id)}]},
            headers={'Authorization': 'Bearer %s' % access_token,
                     'Content-Type': 'application/json'},
            timeout=10)
        data = r.json()
        results = data.get('results') or []
        ok = bool(results and results[0].get('success'))
        # Always log the raw response, not just on exception - a clean HTTP
        # 200 with results[0].success=False (wrong list owner, bad/expired
        # access_token, media_id not actually in the list on remove, etc.)
        # previously vanished with zero trace in kodi.log, making a report
        # like "it silently didn't work" undiagnosable after the fact.
        xbmc.log('[Starfleet/Metadata] tmdb_v4_list_write(%s, list=%s, %s/%s) -> '
                 'HTTP %s ok=%s body=%s' % (method, list_id, media_type, media_id,
                                            r.status_code, ok, data), xbmc.LOGINFO)
        return ok
    except Exception as e:
        xbmc.log('[Starfleet/Metadata] tmdb_v4_list_write(%s, list=%s, %s/%s) error: %s' %
                 (method, list_id, media_type, media_id, e), xbmc.LOGWARNING)
        return False


def tmdb_v4_list_add_item(list_id, access_token, media_type, media_id):
    return _tmdb_v4_list_write('POST', list_id, access_token, media_type, media_id)


def tmdb_v4_list_remove_item(list_id, access_token, media_type, media_id):
    return _tmdb_v4_list_write('DELETE', list_id, access_token, media_type, media_id)


# ── Image URL helpers ─────────────────────────────────────────────────────────

@lru_cache(maxsize=2000)
def poster(path, size='original'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''

@lru_cache(maxsize=2000)
def fanart(path, size='original'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''

@lru_cache(maxsize=2000)
def still(path, size='w300'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''

@lru_cache(maxsize=2000)
def profile(path, size='w185'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''


# ── MOVIE — Search ────────────────────────────────────────────────────────────

def search_movies(query, page=1):
    """
    Search TMDB for movies matching query.
    Returns list of slim dicts for fast list rendering.
    """
    ck = 'tmdb_movie_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        data    = _tmdb_get('/search/movie', {'query': query, 'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] search_movies error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_popular(page=1):
    ck = 'tmdb_movies_popular_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/popular', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_popular error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_top_rated(page=1):
    ck = 'tmdb_movies_top_rated_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/top_rated', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_top_rated error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_new(page=1):
    ck = 'tmdb_movies_new_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/now_playing', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_new error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_trending(page=1):
    """Weekly trending movies from TMDB."""
    ck = 'tmdb_movies_trending_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/trending/movie/week', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])
                   if m.get('vote_count', 0) >= 10]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_trending error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_upcoming(page=1):
    """Upcoming movies from TMDB."""
    ck = 'tmdb_movies_upcoming_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/upcoming', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_upcoming error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_anticipated(page=1):
    """'Most anticipated' upcoming movies, approximated from TMDB alone (no
    Trakt dependency): unreleased titles sorted by TMDB's own popularity
    score, rather than /movie/upcoming's plain nearest-release-date order
    (which surfaces obscure titles releasing next week over a genuinely
    hyped one releasing in 3 months)."""
    import datetime as _dt
    ck = 'tmdb_movies_anticipated_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        today = _dt.date.today().isoformat()
        data = _tmdb_get('/discover/movie', {
            'sort_by': 'popularity.desc',
            'primary_release_date.gte': today,
            'page': page,
        })
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3 * 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_anticipated error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_anticipated(page=1):
    """'Most anticipated' upcoming TV shows — same approach as
    get_movies_anticipated but for /discover/tv."""
    import datetime as _dt
    ck = 'tmdb_tv_anticipated_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        today = _dt.date.today().isoformat()
        data = _tmdb_get('/discover/tv', {
            'sort_by': 'popularity.desc',
            'first_air_date.gte': today,
            'page': page,
        })
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3 * 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_anticipated error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_by_date(page=1):
    """Movies sorted by release date descending — newest first."""
    import datetime as _dt
    ck = 'tmdb_movies_by_date_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        today = _dt.date.today().isoformat()
        data = _tmdb_get('/discover/movie', {
            'page': page,
            'sort_by': 'release_date.desc',
            'release_date.lte': today,
            'vote_count.gte': 10,
            'with_original_language': 'en',
        })
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_by_date error: %s' % e, xbmc.LOGERROR)
        return []


def get_movie_genres():
    ck = 'tmdb_movie_genres'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data   = _tmdb_get('/genre/movie/list')
        genres = data.get('genres', [])
        _cache.set(ck, genres, 7 * 24 * 3600)
        return genres
    except Exception as e:
        xbmc.log('[Meta] get_movie_genres error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_by_genre(genre_id, page=1):
    ck = 'tmdb_movies_genre_%s_%d' % (genre_id, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/discover/movie', {
            'with_genres': genre_id, 'page': page,
            'sort_by': 'popularity.desc'
        })
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_by_genre error: %s' % e, xbmc.LOGERROR)
        return []


# ── MOVIE — Detail ────────────────────────────────────────────────────────────

def _fill_mpaa_from_simkl(detail, media_type):
    """TMDB's own certification (release_dates for movies, content_ratings
    for TV) sometimes comes back empty — non-US titles, newer releases,
    or ones TMDB just hasn't backfilled. SIMKL's public /movies|tv/{imdb}
    endpoint (no pairing needed) often has it when TMDB doesn't, confirmed
    live (R for Oppenheimer, TV-MA for Special Ops: Lioness), so it's used
    as a same-cache-window fallback only — never overwrites a TMDB value
    that's already there, and costs nothing when TMDB already had one."""
    if detail.get('mpaa') or not detail.get('imdb_id'):
        return
    try:
        from resources.lib import simkl_sync as _simkl_sync
        cert = _simkl_sync.get_certification(detail['imdb_id'], media_type)
        if cert:
            detail['mpaa'] = cert
    except Exception as e:
        xbmc.log('[Meta] SIMKL certification fallback error: %s' % e, xbmc.LOGWARNING)


def get_movie_detail(tmdb_id):
    """
    Full movie metadata including cast, crew, videos, external IDs.
    Returns rich dict ready for Kodi ListItem.
    """
    ck = 'tmdb_movie_%s' % tmdb_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        data = _tmdb_get('/movie/%s' % tmdb_id, {
            'append_to_response': 'credits,videos,external_ids,images,release_dates'
        })
        detail = _parse_movie(data)
        _fill_mpaa_from_simkl(detail, 'movie')
        _cache.set(ck, detail, 7 * 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[Meta] get_movie_detail(%s) error: %s' % (tmdb_id, e), xbmc.LOGERROR)
        return {}


def _slim_movie(m):
    """Minimal movie dict for list views — fast to render."""
    return {
        'tmdb_id':      str(m.get('id', '')),
        'title':        m.get('title', m.get('original_title', '')),
        'year':         str(m.get('release_date', ''))[:4],
        'release_date': str(m.get('release_date', '')),
        'rating':       round(float(m.get('vote_average', 0)), 1),
        'thumb':        poster(m.get('poster_path', '')),
        'fanart':       fanart(m.get('backdrop_path', '')),
        'overview':     m.get('overview', ''),
        'genre_ids':    m.get('genre_ids', []),
        'media_type':   'movie',
    }


def _movie_certification(data):
    """US MPAA-style certification (G/PG/PG-13/R/NC-17) from TMDB's own
    release_dates append_to_response block — no IMDb scraping involved
    (IMDb's own Parents Guide page is bot-walled now, confirmed live: a
    plain fetch gets an HTTP 202 with an empty body, not real content).
    Falls back to GB's own board rating if the US entry has none, so a
    non-US-released title still shows something rather than blank."""
    for preferred in ('US', 'GB'):
        for entry in data.get('release_dates', {}).get('results', []):
            if entry.get('iso_3166_1') != preferred:
                continue
            for rd in entry.get('release_dates', []):
                cert = (rd.get('certification') or '').strip()
                if cert:
                    return cert
    return ''


def _parse_movie(data):
    """Full movie detail dict from TMDB append_to_response response."""
    genres    = [g['name'] for g in data.get('genres', [])]
    studios   = [s['name'] for s in data.get('production_companies', [])]

    # Credits
    credits   = data.get('credits', {})
    cast      = []
    for a in credits.get('cast', [])[:20]:
        cast.append({
            'name':      a.get('name', ''),
            'character': a.get('character', ''),
            'photo':     profile(a.get('profile_path', '')),
            'order':     a.get('order', 99),
        })
    director = ''
    writers  = []
    for c in credits.get('crew', []):
        if c.get('job') == 'Director':
            director = c.get('name', '')
        elif c.get('department') == 'Writing':
            writers.append(c.get('name', ''))

    # Trailer
    trailer = ''
    for v in data.get('videos', {}).get('results', []):
        if v.get('type') == 'Trailer' and v.get('site') == 'YouTube':
            trailer = 'plugin://plugin.video.youtube/play/?video_id=%s' % v['key']
            break

    # External IDs
    ext     = data.get('external_ids', {})
    imdb_id = ext.get('imdb_id', data.get('imdb_id', ''))

    # Additional images (backdrops)
    images    = data.get('images', {})
    backdrops = [fanart(i['file_path']) for i in images.get('backdrops', [])[:5]]
    posters   = [poster(i['file_path']) for i in images.get('posters', [])[:5]]

    return {
        'tmdb_id':    str(data.get('id', '')),
        'imdb_id':    imdb_id,
        'title':      data.get('title', data.get('original_title', '')),
        'year':       str(data.get('release_date', ''))[:4],
        'rating':     round(float(data.get('vote_average', 0)), 1),
        'votes':      data.get('vote_count', 0),
        'runtime':    data.get('runtime', 0),
        'overview':   data.get('overview', ''),
        'tagline':    data.get('tagline', ''),
        'genres':     genres,
        'studios':    studios,
        'director':   director,
        'writers':    writers,
        'cast':       cast,
        'thumb':      poster(data.get('poster_path', '')),
        'fanart':     fanart(data.get('backdrop_path', '')),
        'backdrops':  backdrops,
        'posters':    posters,
        'trailer':    trailer,
        'status':       data.get('status', ''),
        'release_date': str(data.get('release_date', '')),
        'mpaa':         _movie_certification(data),
        'media_type':   'movie',
    }


# ── TV SHOWS — Search ─────────────────────────────────────────────────────────

def search_tv(query, page=1):
    ck = 'tmdb_tv_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/search/tv', {'query': query, 'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] search_tv error: %s' % e, xbmc.LOGERROR)
        return []


# ── PERSON — Search + credits ─────────────────────────────────────────────────
# TMDB's /search/movie and /search/tv only match against titles — a query
# like "Tom Cruise" typed into Movies/TV Search returns nothing at all, even
# though TMDB has every actor's full filmography available. search_person()
# + get_person_*_credits() close that gap; search_movies_and_people()/
# search_tv_and_people() below are the actual drop-in replacements for the
# search entry points, since title search still needs to run too (a query
# could be a real title AND a person's name, e.g. "Elvis").

def search_person(query, page=1):
    """Search TMDB for a person (actor/actress/director/etc) by name."""
    ck = 'tmdb_person_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/search/person', {'query': query, 'page': page})
        results = [{
            'person_id':  str(p.get('id', '')),
            'name':       p.get('name', ''),
            'photo':      profile(p.get('profile_path', '')),
            'popularity': p.get('popularity', 0),
        } for p in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] search_person error: %s' % e, xbmc.LOGERROR)
        return []


def get_person_movie_credits(person_id):
    """Movies a person appears in as cast, newest first. TMDB's own
    /person/{id}/movie_credits cast entries carry the same fields
    _slim_movie() already expects from a /search/movie result, so no
    separate parsing is needed."""
    ck = 'tmdb_person_movie_credits_%s' % person_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/person/%s/movie_credits' % person_id)
        results = [_slim_movie(m) for m in data.get('cast', [])]
        results.sort(key=lambda m: m.get('release_date', ''), reverse=True)
        _cache.set(ck, results, 3600 * 24)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_person_movie_credits error: %s' % e, xbmc.LOGERROR)
        return []


def get_person_tv_credits(person_id):
    """TV shows a person appears in as cast, newest first — same reuse of
    _slim_tv() as get_person_movie_credits does for _slim_movie()."""
    ck = 'tmdb_person_tv_credits_%s' % person_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/person/%s/tv_credits' % person_id)
        results = [_slim_tv(s) for s in data.get('cast', [])]
        results.sort(key=lambda s: s.get('first_air_date', ''), reverse=True)
        _cache.set(ck, results, 3600 * 24)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_person_tv_credits error: %s' % e, xbmc.LOGERROR)
        return []


def search_movies_and_people(query, page=1):
    """Title search merged with a person-name match. Title results come
    first; if the query also matches a real person (best/most popular
    match), that person's own filmography is appended, deduped by
    tmdb_id — so "Tom Cruise" surfaces his movies instead of nothing, while
    "Top Gun" still works exactly as before."""
    results = search_movies(query, page=page)
    seen = {m['tmdb_id'] for m in results}
    try:
        people = search_person(query)
        if people:
            for m in get_person_movie_credits(people[0]['person_id']):
                if m['tmdb_id'] not in seen:
                    results.append(m)
                    seen.add(m['tmdb_id'])
    except Exception as e:
        xbmc.log('[Meta] search_movies_and_people person merge error: %s' % e, xbmc.LOGWARNING)
    return results


def search_tv_and_people(query, page=1):
    """Same as search_movies_and_people, for TV shows."""
    results = search_tv(query, page=page)
    seen = {s['tmdb_id'] for s in results}
    try:
        people = search_person(query)
        if people:
            for s in get_person_tv_credits(people[0]['person_id']):
                if s['tmdb_id'] not in seen:
                    results.append(s)
                    seen.add(s['tmdb_id'])
    except Exception as e:
        xbmc.log('[Meta] search_tv_and_people person merge error: %s' % e, xbmc.LOGWARNING)
    return results


def get_tv_popular(page=1):
    ck = 'tmdb_tv_popular_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/popular', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_popular error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_top_rated(page=1):
    ck = 'tmdb_tv_top_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/top_rated', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_top_rated error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_on_the_air(page=1):
    """TV shows currently on the air from TMDB."""
    ck = 'tmdb_tv_onair_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/on_the_air', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_on_the_air error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_airing_today(page=1):
    ck = 'tmdb_tv_airing_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/airing_today', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 1800)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_airing_today error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_genres():
    ck = 'tmdb_tv_genres'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data   = _tmdb_get('/genre/tv/list')
        genres = data.get('genres', [])
        _cache.set(ck, genres, 7 * 24 * 3600)
        return genres
    except Exception as e:
        xbmc.log('[Meta] get_tv_genres error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_by_genre(genre_id, page=1):
    ck = 'tmdb_tv_genre_%s_%d' % (genre_id, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/discover/tv', {
            'with_genres': genre_id, 'page': page,
            'sort_by': 'popularity.desc'
        })
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_by_genre error: %s' % e, xbmc.LOGERROR)
        return []


# ── TV SHOWS — Detail ─────────────────────────────────────────────────────────

def get_tv_detail(tmdb_id):
    """Full TV show detail including seasons, cast, external IDs."""
    ck = 'tmdb_tv_%s' % tmdb_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data   = _tmdb_get('/tv/%s' % tmdb_id, {
            'append_to_response': 'credits,external_ids,images,videos,content_ratings'
        })
        detail = _parse_tv(data)
        _fill_mpaa_from_simkl(detail, 'tv')
        _cache.set(ck, detail, 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[Meta] get_tv_detail(%s) error: %s' % (tmdb_id, e), xbmc.LOGERROR)
        return {}


def _episodate_episodes(show_title, season_num):
    """Cross-check episodate.com — a free service needing no API key,
    built on TheTVDB's own dataset — for episodes TMDB simply doesn't
    have listed yet at all. TMDB is community-edited and can genuinely
    lag real air dates by days or weeks for smaller/reality shows;
    confirmed live (via the real TMDB API, not guesswork) that a real
    show's TMDB season page still showed only episode 1 after episode 2
    had already aired and was watchable elsewhere, while episodate.com
    already had it. This never overrides a TMDB episode that already
    exists — see get_season_detail below, which only adds an entry from
    here for an episode number TMDB is missing entirely — it exists
    purely to catch that gap, not to replace TMDB as the primary source."""
    if not show_title:
        return []
    import re as _re
    ck = 'episodate_%s_s%s' % (_re.sub(r'[^a-z0-9]', '', show_title.lower())[:60], season_num)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        # Deliberately NOT using _sess() here — that shared session's
        # HTTPAdapter has 3 retries with backoff mounted on it (fine for
        # the primary TMDB/TVDB calls elsewhere in this file), but
        # episodate.com is a best-effort backstop only (see this
        # function's own docstring) — confirmed live it can go fully
        # unreachable for a stretch, and 2 calls x 3 retries x an 8s read
        # timeout stacked up to a ~36 second freeze on the episode list
        # for something that's explicitly optional. A single quick
        # attempt with no retries is the right cost for a nice-to-have.
        r = requests.get('https://www.episodate.com/api/search',
                         params={'q': show_title}, timeout=4)
        results = (r.json() or {}).get('tv_shows') or []
        if not results:
            _cache.set(ck, [], 3600)
            return []
        permalink = results[0].get('permalink', '')
        if not permalink:
            return []
        r2 = requests.get('https://www.episodate.com/api/show-details',
                          params={'q': permalink}, timeout=4)
        eps = (r2.json() or {}).get('tvShow', {}).get('episodes') or []
        out = []
        for e in eps:
            if e.get('season') != season_num:
                continue
            out.append({
                'episode':  e.get('episode', 0),
                'season':   season_num,
                'title':    e.get('name', ''),
                'overview': '',
                'aired':    (e.get('air_date') or '')[:10],
                'rating':   0,
                'runtime':  0,
                'still':    '',
                'tmdb_id':  '',
            })
        _cache.set(ck, out, 6 * 3600)
        return out
    except Exception as e:
        xbmc.log('[Meta] _episodate_episodes error: %s' % e, xbmc.LOGWARNING)
        return []


def get_season_detail(tmdb_id, season_num):
    """Full season detail including all episodes with stills and overviews.
    Cross-checks two other sources for any episode TMDB doesn't have
    listed at all yet — TMDB is community-edited and can genuinely lag
    real air dates by days or weeks for smaller/reality shows. TVDB tried
    first (needs the show's tvdb_id, which TMDB's own detail response
    already carries): confirmed live it's the richer of the two, with
    real per-episode overviews and even future episode titles/dates
    already listed for shows well ahead of their air date, not just the
    next one. episodate.com (free, no API key) is a second, cheaper
    backstop for whatever TVDB doesn't have (no tvdb_id resolved, or TVDB
    itself doesn't carry the show) — its own episodes have no
    overview/still at all, so it only ever fills a genuine gap, never
    displaces a TVDB or TMDB entry for the same episode."""
    ck = 'tmdb_season_%s_%s' % (tmdb_id, season_num)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/%s/season/%s' % (tmdb_id, season_num))
        episodes = []
        seen_nums = set()
        for ep in data.get('episodes', []):
            enum = ep.get('episode_number', 0)
            seen_nums.add(enum)
            episodes.append({
                'episode':   enum,
                'season':    ep.get('season_number', season_num),
                'title':     ep.get('name', ''),
                'overview':  ep.get('overview', ''),
                'aired':     ep.get('air_date', ''),
                'rating':    round(float(ep.get('vote_average', 0)), 1),
                'runtime':   ep.get('runtime', 0),
                'still':     still(ep.get('still_path', '')),
                'tmdb_id':   str(ep.get('id', '')),
            })
        try:
            show_detail = get_tv_detail(tmdb_id) or {}
            tvdb_id = show_detail.get('tvdb_id', '')
            if tvdb_id:
                for extra in get_tvdb_episodes(tvdb_id, season_num):
                    if extra['episode'] and extra['episode'] not in seen_nums:
                        episodes.append(extra)
                        seen_nums.add(extra['episode'])
            show_title = show_detail.get('title', '')
            for extra in _episodate_episodes(show_title, season_num):
                if extra['episode'] and extra['episode'] not in seen_nums:
                    episodes.append(extra)
                    seen_nums.add(extra['episode'])
            episodes.sort(key=lambda e: e['episode'])
        except Exception as e:
            xbmc.log('[Meta] TVDB/episodate cross-check error: %s' % e, xbmc.LOGWARNING)
        result = {
            'season':    season_num,
            'name':      data.get('name', 'Season %s' % season_num),
            'overview':  data.get('overview', ''),
            'air_date':  data.get('air_date', ''),
            'thumb':     poster(data.get('poster_path', '')),
            'episodes':  episodes,
        }
        _cache.set(ck, result, 24 * 3600)
        return result
    except Exception as e:
        xbmc.log('[Meta] get_season_detail error: %s' % e, xbmc.LOGERROR)
        return {'episodes': []}


def _slim_tv(s):
    return {
        'tmdb_id':        str(s.get('id', '')),
        'title':          s.get('name', s.get('original_name', '')),
        'year':           str(s.get('first_air_date', ''))[:4],
        'first_air_date': str(s.get('first_air_date', '')),
        'rating':         round(float(s.get('vote_average', 0)), 1),
        'thumb':          poster(s.get('poster_path', '')),
        'fanart':         fanart(s.get('backdrop_path', '')),
        'overview':       s.get('overview', ''),
        'genre_ids':      s.get('genre_ids', []),
        'media_type':     'tv',
    }


def _tv_certification(data):
    """US TV content rating (TV-Y/TV-PG/TV-14/TV-MA/etc) from TMDB's own
    content_ratings append_to_response block — same reasoning as
    _movie_certification above (no IMDb scraping — that page is bot-walled
    now). Falls back to GB if no US rating is listed."""
    for preferred in ('US', 'GB'):
        for entry in data.get('content_ratings', {}).get('results', []):
            if entry.get('iso_3166_1') != preferred:
                continue
            rating = (entry.get('rating') or '').strip()
            if rating:
                return rating
    return ''


def _parse_tv(data):
    genres   = [g['name'] for g in data.get('genres', [])]
    networks = [n['name'] for n in data.get('networks', [])]
    studios  = [s['name'] for s in data.get('production_companies', [])]

    # Seasons (skip season 0 / specials unless it has episodes)
    seasons = []
    for s in data.get('seasons', []):
        if s.get('season_number', 0) == 0 and s.get('episode_count', 0) == 0:
            continue
        seasons.append({
            'season':        s.get('season_number', 0),
            'name':          s.get('name', 'Season %s' % s.get('season_number')),
            'episode_count': s.get('episode_count', 0),
            'air_date':      s.get('air_date', ''),
            'thumb':         poster(s.get('poster_path', '')),
            'overview':      s.get('overview', ''),
        })

    # Cast
    credits = data.get('credits', {})
    cast    = []
    for a in credits.get('cast', [])[:20]:
        cast.append({
            'name':      a.get('name', ''),
            'character': a.get('character', ''),
            'photo':     profile(a.get('profile_path', '')),
        })
    creators = [c.get('name', '') for c in data.get('created_by', [])]

    # External IDs
    ext     = data.get('external_ids', {})
    imdb_id = ext.get('imdb_id', '')
    tvdb_id = str(ext.get('tvdb_id', ''))

    # Trailer
    trailer = ''
    for v in data.get('videos', {}).get('results', []):
        if v.get('type') == 'Trailer' and v.get('site') == 'YouTube':
            trailer = 'plugin://plugin.video.youtube/play/?video_id=%s' % v['key']
            break

    # Images
    images    = data.get('images', {})
    backdrops = [fanart(i['file_path']) for i in images.get('backdrops', [])[:5]]

    return {
        'tmdb_id':      str(data.get('id', '')),
        'imdb_id':      imdb_id,
        'tvdb_id':      tvdb_id,
        'title':        data.get('name', data.get('original_name', '')),
        'year':         str(data.get('first_air_date', ''))[:4],
        'first_air_date': data.get('first_air_date', ''),
        'rating':       round(float(data.get('vote_average', 0)), 1),
        'votes':        data.get('vote_count', 0),
        'runtime':      (data.get('episode_run_time') or [0])[0],
        'overview':     data.get('overview', ''),
        'tagline':      data.get('tagline', ''),
        'genres':       genres,
        'networks':     networks,
        'studios':      studios,
        'creators':     creators,
        'cast':         cast,
        'seasons':      seasons,
        'status':       data.get('status', ''),
        'thumb':        poster(data.get('poster_path', '')),
        'fanart':       fanart(data.get('backdrop_path', '')),
        'backdrops':    backdrops,
        'trailer':      trailer,
        'mpaa':         _tv_certification(data),
        'media_type':   'tv',
    }


# ── TVDB — Episode detail via TVDB v4 ─────────────────────────────────────────

def _get_tvdb_token():
    """Get/refresh TVDB JWT auth token. Cached 23h."""
    cached = _cache.get('tvdb_token')
    if cached:
        return cached

    if _cache.get('tvdb_token_failed'):
        return ''

    try:
        r = _sess().post(TVDB_BASE + '/login',
                         json={'apikey': TVDB_KEY}, timeout=10)
        r.raise_for_status()
        token = r.json().get('data', {}).get('token', '')
        if token:
            _cache.set('tvdb_token', token, 23 * 3600)
            xbmc.log('[Meta] TVDB token obtained', xbmc.LOGINFO)
        return token
    except Exception as e:
        xbmc.log('[Meta] TVDB auth error (TV episode metadata unavailable): %s' % e, xbmc.LOGWARNING)
        _cache.set('tvdb_token_failed', True, 2 * 3600)
        return ''


def get_tvdb_episodes(tvdb_id, season_num):
    """
    Get episode list from TVDB for a given series and season.
    Falls back gracefully to TMDB data if TVDB unavailable.
    """
    ck = 'tvdb_eps_%s_%s' % (tvdb_id, season_num)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    token = _get_tvdb_token()
    if not token:
        return []

    try:
        headers = {'Authorization': 'Bearer %s' % token}
        r = _sess().get(
            '%s/series/%s/episodes/official' % (TVDB_BASE, tvdb_id),
            headers=headers,
            params={'season': season_num, 'page': 0},
            timeout=10
        )
        r.raise_for_status()
        data     = r.json()
        episodes = []
        for ep in data.get('data', {}).get('episodes', []):
            episodes.append({
                'episode':  ep.get('number', 0),
                'season':   ep.get('seasonNumber', season_num),
                'title':    ep.get('name', ''),
                'overview': ep.get('overview', ''),
                'aired':    ep.get('aired', ''),
                'runtime':  ep.get('runtime', 0),
                # TVDB v4's own 'image' field is already a full URL
                # (confirmed live: "https://artworks.thetvdb.com/banners/
                # ..."), not a relative path — prepending the base URL
                # again produced a broken doubled-domain link that could
                # never load. This never surfaced before now because the
                # dead API key meant this code path never actually ran.
                'still':    ep.get('image', '') or '',
                'tvdb_id':  str(ep.get('id', '')),
            })
        _cache.set(ck, episodes, 24 * 3600)
        return episodes
    except Exception as e:
        xbmc.log('[Meta] get_tvdb_episodes error: %s' % e, xbmc.LOGERROR)
        return []


# ── Unified episode fetcher ───────────────────────────────────────────────────

def get_episodes(tmdb_id, season_num, tvdb_id=None):
    """
    Get episodes for a season. Tries TMDB first (has stills + overview),
    enriches with TVDB data if tvdb_id available.
    """
    # TMDB is primary — richer image data
    season = get_season_detail(tmdb_id, season_num)
    episodes = season.get('episodes', [])

    # If we have a TVDB id, merge in any missing data
    if tvdb_id and episodes:
        tvdb_eps = {ep['episode']: ep for ep in get_tvdb_episodes(tvdb_id, season_num)}
        for ep in episodes:
            tvdb_ep = tvdb_eps.get(ep['episode'], {})
            # Fill in missing still from TVDB
            if not ep.get('still') and tvdb_ep.get('still'):
                ep['still'] = tvdb_ep['still']
            # Fill in missing overview from TVDB
            if not ep.get('overview') and tvdb_ep.get('overview'):
                ep['overview'] = tvdb_ep['overview']

    return episodes


# ── Cross-search: find TMDB ID from title ─────────────────────────────────────

def find_tmdb_id(title, year=None, media_type='movie'):
    """
    Search TMDB for a title and return the best matching TMDB ID.
    Used to link external content (e.g. a file on StreamTape) to metadata.
    """
    try:
        endpoint = '/search/movie' if media_type == 'movie' else '/search/tv'
        params   = {'query': title}
        if year:
            params['year' if media_type == 'movie' else 'first_air_date_year'] = year
        data    = _tmdb_get(endpoint, params)
        results = data.get('results', [])
        if results:
            return str(results[0]['id'])
    except Exception as e:
        xbmc.log('[Meta] find_tmdb_id error: %s' % e, xbmc.LOGERROR)
    return None
