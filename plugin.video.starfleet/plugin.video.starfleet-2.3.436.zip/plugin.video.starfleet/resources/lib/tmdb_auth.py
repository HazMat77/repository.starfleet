# -*- coding: utf-8 -*-
"""
resources/lib/tmdb_auth.py

TMDB v4 account pairing — lets a user link their own TMDB account so
Favorites (see favorites.py) can WRITE movies and TV shows into their TMDB
List, not just read one. Uses metadata.py's bundled TMDB_V4_READ_TOKEN to
bootstrap the handshake — same shared-app model as that module's TMDB_KEYS,
which every Starfleet install already shares for search/metadata without
exposing anyone's own account. The read token only identifies "this is the
Starfleet app" to TMDB; each user still personally logs into their own TMDB
account and approves during pairing below, getting their own separate
access_token that's what actually authorizes writes to whatever list they
configured in Settings.

Shows a QR code for the approve URL (via resources/lib/gui/qr_dialog.py,
the same helper SIMKL pairing uses) rather than just printing the raw URL as
text — confirmed live via a real screenshot that TMDB's v4 approve URL
(themoviedb.org/auth/access?request_token=<a 100+ character JWT>) is far
too long to type out on a remote. Unlike SIMKL's PIN flow, there's no
separate short code to type here at all: scanning the QR takes you straight
to the pre-filled approval page, so the QR alone is the whole action.
"""
import time
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.gui import progress_dialog as _pdlg
from resources.lib.gui import qr_dialog as _qrdlg
from resources.lib import metadata as _meta

ADDON = xbmcaddon.Addon('plugin.video.starfleet')


def is_paired():
    # Fresh Addon() every call — see favorites.py's _addon() docstring for
    # why reusing the module-level ADDON here is the exact bug that made
    # "paired but favorites still didn't write" happen in the first place.
    return bool(xbmcaddon.Addon('plugin.video.starfleet').getSetting('tmdb_v4_access_token').strip())


def unpair():
    ADDON.setSetting('tmdb_v4_access_token', '')
    ADDON.setSetting('tmdb_v4_account_id', '')


def pair_with_tmdb():
    """Run the v4 request_token -> approve-in-browser -> access_token
    handshake, showing a QR code (if available) in a Kodi dialog. Bound to
    the tmdb_pair Settings action. No credentials to enter first — see this
    module's docstring for why the bundled read token covers that step."""
    read_token = _meta.TMDB_V4_READ_TOKEN
    request_token, err = _meta.tmdb_v4_request_token(read_token)
    if not request_token:
        xbmc.log('[Starfleet/TMDB] request_token error: %s' % err, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Starfleet', 'TMDB pairing failed to start: %s' % err,
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    approve_url = 'https://www.themoviedb.org/auth/access?request_token=%s' % request_token
    msg = 'Scan, or go to %s' % approve_url
    qr_path = _qrdlg.make_qr(approve_url, 'starfleet_tmdb_qr.png')
    qr_dlg, txt_dlg = None, None
    if qr_path:
        qr_dlg = _qrdlg.QRDialog(qr_path, 'Pair with TMDB', msg)
        qr_dlg.show()
    else:
        txt_dlg = _pdlg.DialogProgress()
        txt_dlg.create('Starfleet - Pair with TMDB', 'Go to %s and click Approve.' % approve_url)

    def _iscanceled():
        return qr_dlg.iscanceled() if qr_dlg else txt_dlg.iscanceled()

    def _update():
        # qr_dlg has its own separate, always-visible instruction line (the
        # URL/QR itself never changes) - its update() call only ever needs
        # a short, genuinely different status string here, never `msg`
        # again (confirmed live: passing the same text back in made the URL
        # line visually repeat itself under the QR every few seconds). The
        # plain-text fallback dialog has no separate instruction line at
        # all, so it still needs the full `msg` on every update.
        if qr_dlg:
            qr_dlg.update('Waiting for you to approve… (%ds)' % waited)
        else:
            txt_dlg.update(min(99, int(100 * waited / expires_in)), msg)

    def _close():
        (qr_dlg or txt_dlg).close()

    interval, expires_in = 5, 900  # v4 request_tokens aren't documented with
    # an explicit lifetime the way v3's 60-minute one is - 15 minutes covers
    # a real "open on my phone, log in, approve" pace with room to spare,
    # matching this addon's own Trakt pairing default order of magnitude.
    waited = 0
    while waited < expires_in:
        if _iscanceled():
            _close()
            return
        time.sleep(interval)
        waited += interval
        _update()

        data = _meta.tmdb_v4_create_access_token(read_token, request_token)
        if data.get('success') and data.get('access_token'):
            ADDON.setSetting('tmdb_v4_access_token', data['access_token'])
            ADDON.setSetting('tmdb_v4_account_id', str(data.get('account_id', '')))
            _close()
            xbmcgui.Dialog().notification('Starfleet', 'TMDB account paired',
                                          xbmcgui.NOTIFICATION_INFO, 3000)
            return
        # success:false with no exception just means "not approved yet" -
        # TMDB has no distinct pending-vs-denied status to tell those apart,
        # so keep polling until the user approves or the window times out.

    _close()
    xbmcgui.Dialog().notification('Starfleet', 'TMDB pairing timed out',
                                  xbmcgui.NOTIFICATION_INFO, 4000)


def show_status():
    """Bound to the tmdb_status Settings action."""
    if is_paired():
        if xbmcgui.Dialog().yesno('Starfleet - TMDB', 'TMDB account is paired.\n\nUnpair?'):
            unpair()
            xbmcgui.Dialog().notification('Starfleet', 'TMDB unpaired',
                                          xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok('Starfleet - TMDB', 'Not paired yet. Use "Pair with TMDB" above.')
