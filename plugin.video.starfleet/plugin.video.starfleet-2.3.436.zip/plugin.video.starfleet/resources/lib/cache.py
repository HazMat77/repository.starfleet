# -*- coding: utf-8 -*-
"""
resources/lib/cache.py

High-performance binary cache — SQLite + Pickle.

Why Pickle over JSON:
  - Serialisation:   ~3-10x faster than json.dumps
  - Deserialisation: ~3-10x faster than json.loads
  - Storage:         ~30-50% smaller (no quotes, no key repetition)
  - Native Python:   no conversion needed — list/dict/int/float preserved exactly
  - Protocol 4:      optimal for Python 3.4+ (Kodi 19+ uses Python 3.8)

Architecture:
  L1 — in-memory hot dict   : <1ms,  capped at HOT_MAX entries
  L2 — SQLite BLOB row      : ~1ms,  single persistent WAL connection
  L3 — miss → network fetch : varies

Thread safety:
  Single threading.Lock guards all SQLite writes.
  Reads are lock-free (SQLite WAL allows concurrent readers).
  Hot cache uses a separate RLock for thread-safe eviction.
"""

import pickle
import sqlite3
import time
import os
import threading

# ── Tunables ──────────────────────────────────────────────────────────────────
HOT_MAX      = 50        # max L1 entries (increase if RAM permits)
PICKLE_PROTO = 4         # protocol 4 = Python 3.4+ optimal
PRAGMA_CACHE = 4000      # SQLite page cache size (pages × 4KB = 16MB)

# ── Module-level state ────────────────────────────────────────────────────────
_conn      = None
_db_lock   = threading.Lock()
_hot       = {}           # key → (value, expires_float)
_hot_lock  = threading.RLock()


def init(db_path):
    """
    Initialise the SQLite connection. Safe to call multiple times —
    only opens the connection once per process (reuselanguageinvoker keeps
    the module alive between Kodi navigation calls).

    Many independent modules each call this at import time with the same
    db_path (torrent_sources, metadata, sports_sources, etc). Kodi's first
    navigation often imports several of these concurrently on different
    background threads, and the plain `if _conn is not None: return` check
    below has a check-then-act race: two threads can both see None, both
    open their own sqlite3.connect() to the same file, and both start
    issuing startup PRAGMAs at once — this is exactly what produced a live
    "Safety level may not be changed inside a transaction" crash out of
    _open_movies_menu. Guard the whole init with _db_lock so only the first
    caller actually connects; everyone else just returns.
    """
    global _conn
    if _conn is not None:
        return
    with _db_lock:
        if _conn is not None:
            return
        _init_locked(db_path)


def _init_locked(db_path):
    global _conn
    try:
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
    except OSError:
        pass

    _conn = sqlite3.connect(db_path, check_same_thread=False, timeout=5)

    # Performance PRAGMAs
    _conn.execute('PRAGMA journal_mode=WAL')       # concurrent reads + writes
    _conn.execute('PRAGMA synchronous=NORMAL')     # safe but not paranoid
    _conn.execute('PRAGMA cache_size=%d' % PRAGMA_CACHE)
    _conn.execute('PRAGMA temp_store=MEMORY')      # temp tables in RAM
    _conn.execute('PRAGMA mmap_size=67108864')     # 64MB memory-mapped I/O

    # Schema — BLOB column stores raw pickle bytes
    _conn.execute(
        'CREATE TABLE IF NOT EXISTS cache '
        '(key TEXT PRIMARY KEY, value BLOB, expires REAL)'
    )
    _conn.execute(
        'CREATE INDEX IF NOT EXISTS idx_expires ON cache(expires)'
    )
    _conn.commit()

    # Purge expired rows at startup (fast — uses the index)
    try:
        _conn.execute('DELETE FROM cache WHERE expires < ?', (time.time(),))
        _conn.commit()
    except Exception:
        pass


def get(key):
    """
    Retrieve a cached value.
    Returns the original Python object or None on miss/expiry.
    """
    now = time.time()

    # ── L1: hot cache ─────────────────────────────────────────────────────────
    with _hot_lock:
        entry = _hot.get(key)
        if entry is not None:
            val, exp = entry
            if exp > now:
                return val
            del _hot[key]

    # ── L2: SQLite ────────────────────────────────────────────────────────────
    if _conn is None:
        return None

    try:
        row = _conn.execute(
            'SELECT value, expires FROM cache WHERE key=?', (key,)
        ).fetchone()
    except Exception:
        return None

    if not row or row[1] <= now:
        return None

    # Deserialise pickle blob
    try:
        val = pickle.loads(row[0])
    except Exception:
        return None

    # Promote to L1
    with _hot_lock:
        if len(_hot) < HOT_MAX:
            _hot[key] = (val, row[1])

    return val


def set(key, data, ttl):
    """
    Store a value with a TTL in seconds.
    Serialises to pickle bytes before writing to SQLite.
    """
    if _conn is None:
        return

    expires = time.time() + ttl

    # Serialise to binary
    try:
        blob = pickle.dumps(data, protocol=PICKLE_PROTO)
    except Exception:
        return

    with _db_lock:
        try:
            _conn.execute(
                'INSERT OR REPLACE INTO cache (key, value, expires) '
                'VALUES (?, ?, ?)',
                (key, sqlite3.Binary(blob), expires)
            )
            _conn.commit()
        except Exception:
            pass

    # Write to L1
    with _hot_lock:
        if len(_hot) < HOT_MAX:
            _hot[key] = (data, expires)
        elif key in _hot:
            _hot[key] = (data, expires)


def delete(keys):
    """Delete one or more keys from both L1 and L2."""
    if _conn is None:
        return
    if isinstance(keys, str):
        keys = [keys]

    with _db_lock:
        try:
            _conn.executemany(
                'DELETE FROM cache WHERE key=?', [(k,) for k in keys]
            )
            _conn.commit()
        except Exception:
            pass

    with _hot_lock:
        for k in keys:
            _hot.pop(k, None)


def flush_hot():
    """Clear the L1 memory cache — useful after bulk operations."""
    with _hot_lock:
        _hot.clear()


def clear_all():
    """
    Wipe every cached entry (L1 + L2) — e.g. the Sports category list
    (tsdb_sport_cats_v2, 24h TTL) or any other stale entry cached before an
    addon update changed what it should contain. Addon-code updates don't
    invalidate already-cached results on their own since caching is purely
    time-based, not version-aware — confirmed live: a device that had
    already browsed Sports before a menu fix shipped kept serving the old
    cached list for the rest of that 24h window even after updating.
    Exposed as a Settings button so this doesn't need ADB/file access to
    the addon's private data dir, which Android blocks anyway.
    """
    if _conn is not None:
        with _db_lock:
            try:
                _conn.execute('DELETE FROM cache')
                _conn.commit()
            except Exception:
                pass
    flush_hot()


def clear_if_updated():
    """Wipe the entire cache the first time this addon runs after a version
    change, so a stale cached result built under old code can never survive
    a version bump the way clear_all()'s own docstring describes (caching
    here is purely time-based — a version change on its own never
    invalidates anything). Confirmed live more than once this session: the
    Sports category list (24h TTL) kept serving icons built under the old
    code for the rest of that window even after the fix shipped and the
    addon updated, because nothing about updating touches an already-cached
    blob.

    Called once at the very top of dispatcher.run(), before any
    action-specific module gets a chance to populate the cache with data
    built under whatever version just started running. A plain marker file
    in the profile dir (not an addon setting) tracks the last-seen version
    — cheap to check on every call (one small file read) and only actually
    wipes + rewrites when the running version differs from it."""
    try:
        import xbmcaddon
        import xbmcvfs
        import xbmc as _xbmc

        # Explicit addon id, not the no-arg xbmcaddon.Addon() — confirmed
        # live this call was silently failing every single time from
        # run_home.py (the RunScript-launched entry point that actually
        # opens first on every normal launch, the whole reason this call
        # was added there in the first place): "No valid addon id could be
        # obtained. None was passed and the script wasn't executed in a
        # normal Kodi manner." Kodi can only infer the calling addon's id
        # for the no-arg form inside a real plugin:// invocation context;
        # RunScript never provides that, so the version-bump cache clear
        # never actually ran from Home, and the "not yet released" bug (and
        # any other stale-cache symptom) kept surviving updates despite
        # this safeguard supposedly covering it. The explicit id works
        # identically in both contexts, so this is a strict improvement,
        # not just a RunScript-specific special case.
        addon = xbmcaddon.Addon('plugin.video.starfleet')
        current = addon.getAddonInfo('version')
        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        marker = os.path.join(profile, '.cache_version')

        last = ''
        if os.path.exists(marker):
            with open(marker, 'r', encoding='utf-8') as f:
                last = f.read().strip()

        if last == current:
            return

        init(os.path.join(profile, 'cache.db'))
        clear_all()

        os.makedirs(profile, exist_ok=True)
        with open(marker, 'w', encoding='utf-8') as f:
            f.write(current)

        _xbmc.log('[Starfleet/Cache] version changed (%s -> %s) - cache cleared'
                  % (last or '(none)', current), _xbmc.LOGINFO)
    except Exception as e:
        try:
            import xbmc as _xbmc
            _xbmc.log('[Starfleet/Cache] clear_if_updated error: %s' % e, _xbmc.LOGWARNING)
        except Exception:
            pass


def stats():
    """Return cache statistics dict — useful for debug logging."""
    row_count = 0
    db_size   = 0
    if _conn:
        try:
            row_count = _conn.execute(
                'SELECT COUNT(*) FROM cache WHERE expires > ?', (time.time(),)
            ).fetchone()[0]
            db_size = _conn.execute(
                "SELECT page_count * page_size FROM pragma_page_count(), "
                "pragma_page_size()"
            ).fetchone()[0]
        except Exception:
            pass
    with _hot_lock:
        hot_count = len(_hot)
    return {
        'l1_entries': hot_count,
        'l2_entries': row_count,
        'db_bytes':   db_size,
    }
