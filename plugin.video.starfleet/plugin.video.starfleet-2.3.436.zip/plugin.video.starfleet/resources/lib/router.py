﻿# -*- coding: utf-8 -*-
"""
resources/lib/router.py — Starfleet Kodi Plugin
Main menu + Live TV section directory builder.
Radio section is handled by radio_router.py.
"""

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from resources.lib.gui import progress_dialog as _pdlg

from resources.lib import api

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')

def _icon(name):
    """Return absolute path to a media icon PNG."""
    import xbmcvfs
    return xbmcvfs.translatePath(_PROFILE + '/resources/media/' + name + '.png')

LIVE_SOURCES_MENU = [
    ('live_tva',    '📡  GEOlocked — Canada (TVA / CBC / Global News)',
     'TVA, CBC News Network, ICI Radio-Canada, Global News — geo-locked Canadian channels. Enable geo-bypass in Settings > Canadian Channels to watch from outside Canada.'),
    ('live_samsung','📺  Samsung TV+',
     'Free Samsung TV Plus channels — Canada'),
    ('live_plex',   '🟠  Plex FAST Channels',
     'Free Plex channels — news, movies, entertainment'),
    ('live_pluto',  '🪐  Pluto TV Canada',
     '110+ Pluto TV channels — free and legal'),
    ('live_toutv',  '🍁  ICI / Noovo (Radio-Canada)',
     'ICI Radio-Canada Télé, ICI RDI, ICI Artv, ICI Explora, Noovo — free French-Canadian channels'),
    ('live_news',   '🌍  Free Worldwide News & Channels',
     'Al Jazeera, France 24, DW, Euronews, NASA TV, CGTN, ABC Australia and more — free worldwide streams'),
    ('live_tvnow',  '📡  Live Channels — 500+ Channels by Country',
     'Full live TV catalogue, pre-resolved and grouped by country — sports, news, entertainment (adult channels excluded, see Adult section)'),
]


def _add_dir(handle, build_url, label, params, thumb='', plot=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_play(handle, build_url, label, params, thumb='', plot='', info=None):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', dict({'title': label, 'plot': plot}, **(info or {})))
    li.setProperty('IsPlayable', 'true')
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, False)


def _hls_item(url, title='', force_hls=False):
    # Extract |header=value&... portion appended by geo_spoof.decorate_url()
    extra_headers = ''
    if '|' in url:
        _, extra_headers = url.split('|', 1)

    li = xbmcgui.ListItem(path=url)
    li.setInfo('video', {'title': title})
    # Community-M3U aggregators (Plex, Samsung TV+) hand out extensionless
    # proxy/shortlink URLs (e.g. epg.provider.plex.tv/library/parts/<id>/,
    # jmp2.uk/stvp-<id>) that only resolve to a real .m3u8 after a redirect
    # we never see here — the '.m3u8' sniff below misses them, leaving
    # inputstream.adaptive unconfigured by us and at the mercy of Kodi's own
    # (unreliable, for these) content-type auto-detection. force_hls lets
    # callers that know the source is always HLS bypass the sniff.
    if force_hls or '.m3u8' in url.lower():
        try:
            import inputstreamhelper
            h = inputstreamhelper.Helper('hls')
            if h.check_inputstream():
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                # Propagate geo-spoof headers to manifest AND every segment request
                if extra_headers:
                    li.setProperty('inputstream.adaptive.stream_headers',   extra_headers)
                    li.setProperty('inputstream.adaptive.manifest_headers', extra_headers)
        except ImportError:
            pass
    return li


def _loading(msg):
    d = _pdlg.DialogProgress()
    d.create('Starfleet', msg)
    return d


def _list_channels(handle, build_url, channels, source=''):
    for ch in channels:
        logo  = ch.get('thumbnail', '')
        label = ch['title']
        li    = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': label,
            'plot':  '%s — %s' % (ch.get('source', source), ch.get('group', '')),
        })
        li.setProperty('IsPlayable', 'true')
        if logo:
            li.setArt({
                'thumb':  logo,
                'icon':   logo,
                'poster': logo,
                # Use logo as fanart too — better than blank background
                'fanart': logo,
            })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'play_direct',
                       'stream_url': ch.get('stream_url', ''),
                       'ch_id':      ch.get('id', ''),
                       'source':     ch.get('source', source),
                       'title':      ch['title']}),
            li, False
        )
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def _group_menu(handle, build_url, channels, group_action, source_label):
    groups = {}
    for ch in channels:
        groups.setdefault(ch.get('group', 'Autres'), []).append(ch)
    for g in sorted(groups):
        _add_dir(handle, build_url,
                 label='%s  (%d)' % (g, len(groups[g])),
                 params={'action': group_action, 'group': g},
                 plot='%d chaînes' % len(groups[g]))
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Main Menu ─────────────────────────────────────────────────────────────────

def main_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Starfleet')
    xbmcplugin.setContent(handle, 'files')

    _add_dir(handle, build_url, '⭐  Favorites',
             {'action': 'favorites_menu'},
             thumb=_icon('icon_favorites'),
             plot='Your saved movies and TV shows')

    _add_dir(handle, build_url, '📺  TV Shows',
             {'action': 'meta_tv_menu'},
             thumb=_icon('icon_tvshows'),
             plot='Browse TV shows — Popular, Top Rated, by Genre, Search (TMDB + TVDB)')

    _add_dir(handle, build_url, '🎬  Movies',
             {'action': 'meta_movies_menu'},
             thumb=_icon('icon_movies'),
             plot='Browse movies — Popular, Top Rated, Now Playing, by Genre, Search (TMDB)')

    _add_dir(handle, build_url, '🏟️  Sports',
             {'action': 'sports_menu'},
             thumb=_icon('icon_livetv'),
             plot='Live sports — NFL, NBA, MLB, NHL, UFC, Soccer, F1 and more. Stream links from istreameast.cx and crackstreams.mx')

    _add_dir(handle, build_url, '📡  Live TV — Toutes les sources',
             {'action': 'live_menu'},
             thumb=_icon('icon_livetv'),
             plot='Starfleet, Samsung TV+, Plex, Pluto TV — toutes gratuites')

    _add_dir(handle, build_url, '📻  Radio',
             {'action': 'radio_menu'},
             thumb=_icon('icon_radio'),
             plot='90 000+ stations radio — Monde entier par pays, région, ville')

    # Adult section — only shown if enabled in settings
    from resources.lib import pin_lock
    if pin_lock.adult_visible():
        _add_dir(handle, build_url, '🔞  Adult',
                 {'action': 'adult_menu'},
                 thumb=_icon('icon_adult'),
                 plot='Adult Film Database — Metadata, cast, studios, categories')

    _add_dir(handle, build_url, '⚙️  Settings',
             {'action': 'open_settings'},
             thumb=_icon('icon_settings'),
             plot='Configure premium services, PIN, metadata language')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Live Menu ─────────────────────────────────────────────────────────────────

def live_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Live TV')
    xbmcplugin.setContent(handle, 'files')

    # Pre-warm all live sources in background threads while menu renders
    try:
        from resources.lib.live_sources import prewarm_all
        prewarm_all()
    except Exception:
        pass

    # ── Unified list first ────────────────────────────────────────────────
    _add_dir(handle, build_url,
             label='📺  All Channels (Unified)',
             params={'action': 'live_all'},
             plot='All channels from all sources in one list — duplicates show a source picker')

    _add_dir(handle, build_url,
             label='─' * 30,
             params={'action': 'live_menu'},
             plot='')

    # ── Individual sources ────────────────────────────────────────────────
    for action, label, plot in LIVE_SOURCES_MENU:
        _add_dir(handle, build_url, label, {'action': action}, plot=plot)

    _add_dir(handle, build_url, '⚙️  Exporter M3U + EPG pour pvr.iptvsimple',
             {'action': 'export_iptv'},
             plot='Génère URLs M3U + XMLTV pour la grille EPG Kodi')
    _add_dir(handle, build_url, '🔄  Rafraîchir tout / Refresh All',
             {'action': 'live_refresh_all'},
             plot='Force refresh all channel lists and unified cache')
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def settings_menu(handle, build_url):
    """Quick-access settings and account status."""
    xbmcplugin.setPluginCategory(handle, '⚙️ Settings')
    xbmcplugin.setContent(handle, 'files')

    _add_dir(handle, build_url, '⚙️  Open Settings',
             {'action': 'open_settings'},
             plot='Configure premium services, PIN, TVA+ keys, metadata options')

    _add_dir(handle, build_url, '🔑  Premium Service Status',
             {'action': 'premium_status'},
             plot='Check Real-Debrid, AllDebrid, Premiumize account status')

    _add_dir(handle, build_url, '🔒  Lock Adult Section Now',
             {'action': 'adult_lock'},
             plot='Re-lock the adult section for this session')

    _add_dir(handle, build_url, '🔓  Set / Change Adult PIN',
             {'action': 'set_adult_pin'},
             plot='Set or change the 4-digit adult section PIN')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Unified Channel List ─────────────────────────────────────────────────────

def list_live_all(handle, build_url):
    """
    All channels from all sources in one alphabetical list.
    Channels available from multiple sources show a source-picker dialog on play.
    """
    from resources.lib import unified_live
    from resources.lib import api as _api

    xbmcplugin.setContent(handle, 'files')

    # Show progress only on cold cache
    from resources.lib import cache as _c
    cold = _c.get('unified_live_all') is None
    dlg  = None
    if cold:
        dlg = _pdlg.DialogProgress()
        dlg.create('Starfleet', 'Loading all channels...')
        dlg.update(10, 'Fetching Samsung TV+...')

    tva_channels = _api.get_live_channels()  # TVA DAI channels

    if dlg:
        dlg.update(50, 'Fetching Plex & Pluto TV...')

    channels = unified_live.get_all_channels(tva_channels=tva_channels)

    if dlg:
        dlg.update(100)
        dlg.close()

    if not channels:
        xbmcgui.Dialog().notification('Starfleet', 'No channels found',
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    xbmcplugin.setPluginCategory(
        handle, '📺 All Channels (%d)' % len(channels))

    for ch in channels:
        sources    = ch['sources']
        src_count  = len(sources)
        source_str = ' | '.join(
            unified_live.SOURCE_LABELS.get(s['source'], s['source'])
            for s in sources
        )

        # Label shows source count as a hint
        if src_count > 1:
            label = '%s  [%d sources]' % (ch['title'], src_count)
        else:
            label = ch['title']

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': ch['title'],
            'plot':  source_str,
        })
        li.setProperty('IsPlayable', 'true')
        logo = ch.get('thumbnail', '')
        if logo:
            li.setArt({
                'thumb':  logo,
                'icon':   logo,
                'poster': logo,
                'fanart': logo,
            })

        xbmcplugin.addDirectoryItem(
            handle,
            build_url({
                'action':   'live_unified_play',
                'ch_key':   ch['key'],
                'ch_title': ch['title'],
            }),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── TVA / DAI ─────────────────────────────────────────────────────────────────

def list_live_tva(handle, build_url):
    from resources.lib import geo_spoof as _gs
    bypass_on = _gs.is_enabled()
    geo_note  = ' [COLOR lime][Geo-bypass ON][/COLOR]' if bypass_on else ' [COLOR grey][Canada only][/COLOR]'
    xbmcplugin.setPluginCategory(handle, 'GEOlocked — Canada: TVA / CBC / Global News')
    xbmcplugin.setContent(handle, 'files')
    channels = api.get_live_channels()
    if not channels:
        xbmcgui.Dialog().ok('En Direct', 'Aucune chaîne configurée.')
        return
    for ch in channels:
        logo  = ch.get('thumbnail', '')
        group = ch.get('group', '')
        label = ch['title'] + geo_note
        li    = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': ch['title'],
            'plot':  '[%s] %s' % (group, ch.get('description', '')) if group else ch.get('description', ''),
        })
        li.setProperty('IsPlayable', 'true')
        if logo:
            li.setArt({'thumb': logo, 'icon': logo, 'poster': logo, 'fanart': logo})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'play_live_dai',
                       'channel_id': ch['id'],
                       'title':      ch['title']}),
            li, False
        )
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Samsung ───────────────────────────────────────────────────────────────────

def list_live_samsung(handle, build_url):
    from resources.lib import live_sources
    xbmcplugin.setContent(handle, 'files')
    cold = live_sources._cache.get('samsung_ca') is None
    dlg  = _loading('Chargement Samsung TV+...') if cold else None
    channels = live_sources.get_samsung_channels()
    if dlg: dlg.close()
    if not channels:
        xbmcgui.Dialog().notification('Starfleet', 'Samsung TV+ indisponible',
                                       xbmcgui.NOTIFICATION_WARNING)
        return
    xbmcplugin.setPluginCategory(handle, 'Samsung TV+ (%d)' % len(channels))
    _group_menu(handle, build_url, channels, 'live_samsung_group', 'Samsung TV+')


def list_live_samsung_group(handle, build_url, group):
    from resources.lib import live_sources
    xbmcplugin.setPluginCategory(handle, 'Samsung TV+ — %s' % group)
    xbmcplugin.setContent(handle, 'files')
    _list_channels(handle, build_url,
                   [c for c in live_sources.get_samsung_channels()
                    if c.get('group') == group], 'Samsung TV+')


# ── Plex ──────────────────────────────────────────────────────────────────────

def list_live_plex(handle, build_url):
    from resources.lib import live_sources
    xbmcplugin.setContent(handle, 'files')
    cold = live_sources._cache.get('plex_all') is None
    dlg  = _loading('Chargement Plex...') if cold else None
    channels = live_sources.get_plex_channels()
    if dlg: dlg.close()
    if not channels:
        xbmcgui.Dialog().notification('Starfleet', 'Plex indisponible',
                                       xbmcgui.NOTIFICATION_WARNING)
        return
    xbmcplugin.setPluginCategory(handle, 'Plex FAST (%d)' % len(channels))
    _group_menu(handle, build_url, channels, 'live_plex_group', 'Plex')


def list_live_plex_group(handle, build_url, group):
    from resources.lib import live_sources
    xbmcplugin.setPluginCategory(handle, 'Plex — %s' % group)
    xbmcplugin.setContent(handle, 'files')
    _list_channels(handle, build_url,
                   [c for c in live_sources.get_plex_channels()
                    if c.get('group') == group], 'Plex')


# ── Pluto ─────────────────────────────────────────────────────────────────────

def list_live_pluto(handle, build_url):
    from resources.lib import live_sources
    xbmcplugin.setContent(handle, 'files')
    cold = live_sources._cache.get('pluto_meta') is None
    dlg  = _loading('Chargement Pluto TV...') if cold else None
    channels = live_sources.get_pluto_channels()
    if dlg: dlg.close()
    if not channels:
        xbmcgui.Dialog().notification(
            'Starfleet', 'Pluto TV indisponible — essayez Rafraîchir',
            xbmcgui.NOTIFICATION_WARNING)
        return
    xbmcplugin.setPluginCategory(handle, 'Pluto TV (%d)' % len(channels))
    _group_menu(handle, build_url, channels, 'live_pluto_group', 'Pluto TV')


def list_live_pluto_group(handle, build_url, group):
    from resources.lib import live_sources
    xbmcplugin.setPluginCategory(handle, 'Pluto TV — %s' % group)
    xbmcplugin.setContent(handle, 'files')
    _list_channels(handle, build_url,
                   [c for c in live_sources.get_pluto_channels()
                    if c.get('group') == group], 'Pluto TV')


# ── Export ────────────────────────────────────────────────────────────────────

def export_iptv(handle, build_url):
    from resources.lib import live_sources
    epg = live_sources.get_epg_urls()
    msg = (
        'Pour une vraie grille EPG dans Kodi:\n\n'
        '1. Installez pvr.iptvsimple\n'
        '2. Samsung M3U: https://i.mjh.nz/SamsungTVPlus/ca.m3u8\n'
        '3. Plex M3U:    https://i.mjh.nz/Plex/all.m3u8\n\n'
        'EPG XMLTV:\n'
        '  Samsung: %s\n'
        '  Plex:    %s'
        % (epg.get('Samsung TV+', ''), epg.get('Plex', ''))
    )
    xbmcgui.Dialog().textviewer('Starfleet — Configuration EPG', msg)
    xbmcplugin.endOfDirectory(handle, succeeded=False)


# ── Playback ──────────────────────────────────────────────────────────────────

def list_live_toutv(handle, build_url):
    """ICI / Noovo free Radio-Canada live channels."""
    from resources.lib import live_sources
    xbmcplugin.setPluginCategory(handle, '🍁 ICI / Noovo — Radio-Canada')
    xbmcplugin.setContent(handle, 'files')
    channels = live_sources.get_toutv_live_channels()
    _list_channels(handle, build_url, channels, source='Tou.tv')
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)


def list_live_news(handle, build_url):
    """Free worldwide news and entertainment channels — hardcoded reliable HLS streams."""
    from resources.lib import live_sources
    xbmcplugin.setPluginCategory(handle, '🌍 Free Worldwide News & Channels')
    xbmcplugin.setContent(handle, 'files')
    channels = live_sources.get_news_channels()
    _list_channels(handle, build_url, channels, source='Free News')
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)


def list_live_tvnow(handle, build_url):
    """Live TV country picker, backed by daddylive.json's pre-resolved catalogue
    (json_data.get_live_tv_channels_by_country()) instead of a live tvnow247.top
    scrape — every channel already carries a playable_url, so there's no
    per-channel resolve step left at play time."""
    from resources.lib import json_data as _jd
    xbmcplugin.setPluginCategory(handle, '📡 Live Channels — By Country')
    xbmcplugin.setContent(handle, 'files')
    grouped = _jd.get_live_tv_channels_by_country()
    if not grouped:
        xbmcgui.Dialog().notification('Live TV', 'No channels found', xbmcgui.NOTIFICATION_INFO)
        return
    for country in sorted(grouped):
        count = len(grouped[country])
        _add_dir(handle, build_url,
                 label='%s  (%d)' % (country, count),
                 params={'action': 'live_tvnow_country', 'country': country},
                 plot='%d channels' % count)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def list_live_tvnow_country(handle, build_url, country=''):
    """Channel list for one country from the pre-resolved Live TV catalogue."""
    from resources.lib import json_data as _jd
    xbmcplugin.setPluginCategory(handle, '📡 %s' % country)
    xbmcplugin.setContent(handle, 'files')
    channels = _jd.get_live_tv_channels_by_country().get(country, [])
    if not channels:
        xbmcgui.Dialog().notification('Live TV', 'No channels found', xbmcgui.NOTIFICATION_INFO)
        return
    for ch in channels:
        li = xbmcgui.ListItem(label=ch['title'])
        li.setInfo('video', {'title': ch['title'], 'plot': 'Live TV — %s' % country})
        li.setProperty('IsPlayable', 'true')
        logo = ch.get('logo', '')
        if logo:
            li.setArt({'thumb': logo, 'icon': logo, 'poster': logo, 'fanart': logo})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'live_tvnow_play',
                       'playable_url': ch['playable_url'], 'title': ch['title']}),
            li, False
        )
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def live_tvnow_play(handle, playable_url='', title=''):
    """Play an already-resolved Live TV channel URL — no fresh resolve needed,
    the scraper already produced a pipe-tagged url|Referer=...&User-Agent=... string."""
    if not playable_url:
        xbmcgui.Dialog().notification('Live TV', 'Missing stream URL for %s' % title,
                                       xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(handle, True, _hls_item(playable_url, title))


def play_tvnow_channel(handle, channel_id='', title=''):
    """Fresh-resolve a tvnow247.top channel by its own channel_id at play
    time — separate from live_tvnow_play above, which only ever plays an
    already-resolved daddylive JSON catalogue URL. This backs the direct
    tvnow247 catalogue (live_sources.get_tvnow_channels(), 800+ channels)
    once it's wired into an export/menu, since that catalogue's channels
    have no pre-resolved stream and must be resolved live per play."""
    from resources.lib import live_sources
    stream_url = live_sources.resolve_tvnow_stream(channel_id)
    if not stream_url:
        xbmcgui.Dialog().notification('Live TV', 'No live stream for %s' % title,
                                       xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(handle, True, _hls_item(stream_url, title))


def live_channel_picker(handle, key=''):
    """Play-time entry point for a channel pvr_export.py merged from
    daddylive_channels.json + tvnow247 (same real channel, two catalogues,
    confirmed live by name match) — shows a Dialog().select() of every
    available source and resolves whichever one the user picks, the same
    'one listing, dialog shows every source' pattern this addon's own
    sports section already uses for cross-scraper game deduplication.
    channel_sources_path()'s JSON is (re)written by _channel_entries()
    on every 'Export to TV Guide' run, keyed by the merge key baked into
    this channel's own M3U play_url."""
    from resources.lib import pvr_export
    import json
    candidates = []
    try:
        with open(pvr_export.channel_sources_path(), 'r', encoding='utf-8') as f:
            merge_map = json.load(f)
        candidates = merge_map.get(key) or []
    except Exception as e:
        xbmc.log('[Starfleet/PVR] live_channel_picker read error: %s' % e, xbmc.LOGWARNING)
    if not candidates:
        xbmcgui.Dialog().notification('Live TV', 'No sources found for this channel',
                                       xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    idx = xbmcgui.Dialog().select('Choose a source', [c.get('label', '?') for c in candidates])
    if idx < 0:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    chosen = candidates[idx]
    action = chosen.get('action', '')
    params = chosen.get('params', {})
    if action == 'play_direct':
        play_direct(handle, params.get('stream_url', ''), '', '', params.get('title', ''))
    elif action == 'live_tvnow_channel_play':
        play_tvnow_channel(handle, params.get('channel_id', ''), params.get('title', ''))
    else:
        xbmcgui.Dialog().notification('Live TV', 'Unknown source type', xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def play_live_dai(handle, asset_key='', title='', channel_id=''):
    dlg = _pdlg.DialogProgress()
    dlg.create('Starfleet', 'Connexion à %s...' % title)
    # Prefer channel_id lookup (new); fall back to bare asset_key (legacy)
    if channel_id:
        from resources.lib.api import DAI_LIVE_CHANNELS
        ch = next((c for c in DAI_LIVE_CHANNELS if c['id'] == channel_id), None)
        url = api.get_live_stream_url(ch) if ch else None
    else:
        url = api.get_live_stream_url(asset_key)
    dlg.close()
    if not url:
        xbmcgui.Dialog().ok('Starfleet', 'Impossible d\'obtenir le flux pour %s.' % title)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(handle, True, _hls_item(url, title))


def play_sinclair(handle, callsign='', domain='', title=''):
    """Sinclair Broadcast Group local station — same lazy per-play
    resolution as play_live_dai, just a plain public HLS manifest instead
    of a Google DAI session (see sinclair_live.py)."""
    from resources.lib import sinclair_live
    dlg = _pdlg.DialogProgress()
    dlg.create('Starfleet', 'Connecting to %s...' % title)
    url = sinclair_live.resolve_stream_url(callsign, domain)
    dlg.close()
    if not url:
        xbmcgui.Dialog().ok('Starfleet', 'Could not get stream for %s.' % title)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(handle, True, _hls_item(url, title))


def play_direct(handle, stream_url, ch_id='', source='', title=''):
    from resources.lib import live_sources
    from resources.lib.resolvers import resolve, _is_direct
    if not stream_url or ('jwt=' in stream_url and 'pluto.tv' in stream_url):
        if ch_id and source == 'Pluto TV':
            stream_url = live_sources.get_pluto_stream(ch_id) or stream_url
    if not stream_url:
        xbmcgui.Dialog().ok('Starfleet', 'URL de lecture manquante.')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    # Run through premium resolvers (RD/AD/PM) for non-direct URLs
    stream_url = resolve(stream_url)
    # Plex FAST and Samsung TV+ channels are always HLS master playlists,
    # even though their community-M3U URLs don't carry a '.m3u8' extension —
    # force inputstream.adaptive rather than relying on _hls_item()'s sniff.
    force_hls = source in ('Plex', 'Samsung TV+')
    xbmcplugin.setResolvedUrl(handle, True, _hls_item(stream_url, title, force_hls=force_hls))



# ── Adult Menu entry (added to main_menu separately) ─────────────────────────
# Called from default.py — kept here for consistency
def adult_menu_entry(handle, build_url):
    """Thin wrapper — actual menu is in afdb_router.py"""
    from resources.lib import afdb_router
    afdb_router.adult_menu(handle, build_url)
