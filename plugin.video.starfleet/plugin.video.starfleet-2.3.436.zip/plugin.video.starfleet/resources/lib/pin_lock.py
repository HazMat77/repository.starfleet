﻿# -*- coding: utf-8 -*-
"""
resources/lib/pin_lock.py

PIN protection and visibility control for the Adult section.

Settings used:
  adult_enabled    — bool  — show/hide Adult in main menu
  adult_pin_enabled — bool — require PIN before entering
  adult_pin        — str   — the 4-digit PIN (stored hidden)

Session state:
  PIN is only asked ONCE per Kodi session (persisted to a lock file, not
  memory — this addon runs with reuselanguageinvoker=false, so every
  plugin:// call is a fresh Python process with no shared globals; an
  in-memory flag would silently re-prompt on every single call).
  Restarting Kodi resets the session lock (the file only lives under
  Kodi's own userdata, but is only cleared by explicit Lock/re-lock —
  see lock_session()).
  Navigating away and back does NOT re-ask for PIN.
"""

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os

ADDON = xbmcaddon.Addon('plugin.video.starfleet')


def _unlock_marker_path():
    data_dir = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    return os.path.join(data_dir, 'adult_session.lock')


def adult_visible():
    """Return True if the Adult section should appear in the main menu."""
    return ADDON.getSetting('adult_enabled') == 'true'


def pin_required():
    """Return True if PIN protection is enabled and a PIN has been set."""
    return (ADDON.getSetting('adult_pin_enabled') == 'true' and
            bool(ADDON.getSetting('adult_pin').strip()))


def is_unlocked():
    """Return True if already unlocked this session."""
    return os.path.isfile(_unlock_marker_path())


def prompt_pin():
    """
    Show a numeric PIN entry dialog.
    Returns True if PIN correct, False if wrong or cancelled.
    Persists unlock state to a marker file (see module docstring for why
    not an in-memory flag) until lock_session() removes it.
    """
    # Already unlocked this session
    if is_unlocked():
        return True

    stored_pin = ADDON.getSetting('adult_pin').strip()
    if not stored_pin:
        # No PIN set — allow access
        _mark_unlocked()
        return True

    # Show keyboard for PIN entry
    kb = xbmc.Keyboard('', 'Enter Adult Section PIN', True)  # True = hidden input
    kb.doModal()

    if not kb.isConfirmed():
        return False   # user cancelled

    entered = kb.getText().strip()

    if entered == stored_pin:
        _mark_unlocked()
        xbmc.log('[Starfleet] Adult section unlocked for this session', xbmc.LOGINFO)
        return True
    else:
        xbmcgui.Dialog().notification(
            'Starfleet',
            'Incorrect PIN',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        xbmc.log('[Starfleet] Adult section PIN incorrect', xbmc.LOGWARNING)
        return False


def _mark_unlocked():
    try:
        open(_unlock_marker_path(), 'w').write('1')
    except Exception:
        pass


def set_pin():
    """
    Interactive PIN setup wizard.
    Asks for new PIN twice to confirm, then saves to settings.
    Called from Settings → Adult Section → Set / Change PIN.
    """
    # Step 1: Enter new PIN
    kb1 = xbmc.Keyboard('', 'Enter new PIN (4 digits)', True)
    kb1.doModal()
    if not kb1.isConfirmed():
        return

    pin1 = kb1.getText().strip()

    if not pin1:
        xbmcgui.Dialog().ok('Starfleet', 'PIN cannot be empty.')
        return

    if not pin1.isdigit():
        xbmcgui.Dialog().ok('Starfleet', 'PIN must contain digits only.')
        return

    if len(pin1) < 4:
        xbmcgui.Dialog().ok('Starfleet', 'PIN must be at least 4 digits.')
        return

    # Step 2: Confirm PIN
    kb2 = xbmc.Keyboard('', 'Confirm new PIN', True)
    kb2.doModal()
    if not kb2.isConfirmed():
        return

    pin2 = kb2.getText().strip()

    if pin1 != pin2:
        xbmcgui.Dialog().ok('Starfleet', 'PINs do not match. Please try again.')
        return

    # Save
    ADDON.setSetting('adult_pin', pin1)
    ADDON.setSetting('adult_pin_enabled', 'true')
    xbmcgui.Dialog().notification(
        'Starfleet', 'PIN set successfully', xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.log('[Starfleet] Adult PIN updated', xbmc.LOGINFO)


def _clear_unlock_marker():
    try:
        os.remove(_unlock_marker_path())
    except Exception:
        pass


def clear_pin():
    """Remove PIN and disable PIN protection."""
    ADDON.setSetting('adult_pin', '')
    ADDON.setSetting('adult_pin_enabled', 'false')
    _clear_unlock_marker()
    xbmcgui.Dialog().notification(
        'Starfleet', 'PIN removed', xbmcgui.NOTIFICATION_INFO, 2000)


def lock_session():
    """
    Manually re-lock the adult section for this session.
    Useful if you want to lock again without restarting Kodi.
    """
    _clear_unlock_marker()
    xbmcgui.Dialog().notification(
        'Starfleet', 'Adult section locked', xbmcgui.NOTIFICATION_INFO, 2000)
