# -*- coding: utf-8 -*-
"""
resources/lib/nzb_sources.py — Usenet/NZB search.

binsearch.info is a free, public Usenet search engine that needs no
account/API key — confirmed live 2026-08-06: a plain GET returns real,
server-rendered results (title, size, file count, age), and each result's
opaque per-post id can be turned into a real, valid downloadable .nzb file
via a second plain GET, no login/session required at all.

NZBGeek and NZBPlanet are the opposite of Binsearch: real, paid, account-
gated indexers, but both speak the standard Newznab API (the same
Sonarr/Radarr/NZBHydra etc. all use) — confirmed live 2026-08-06, an
invalid API key against each got back a real, correctly-formatted Newznab
`<error code="101" .../>` response, confirming the endpoints and query
shape are right without needing a real account to verify. A valid user's
own API key turns this into a clean, structured XML search with a
ready-to-fetch NZB download URL already baked into each item's own <link>
— no HTML scraping, no CSRF, no junk-file filtering needed the way
Binsearch's raw post-search requires, since Newznab indexers already do
their own release grouping server-side.

Deliberately NOT wired into torrent_sources.search_all() — an NZB result
isn't a magnet: URI and has no info_hash, so it doesn't fit that pipeline's
shape, and more importantly it's only ever useful if Premiumize or TorBox
(the only two debrid services here with real NZB-caching support — Real-
Debrid and AllDebrid have none at all, confirmed live) are actually
enabled. debrid_torrent.py's search_nzb_streams() is the real gate for
that; this module is pure search, no debrid-awareness at all.
"""
import re
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
}

BINSEARCH_BASE = 'https://binsearch.info'

# One result row's full markup, from its "N." index cell through to the Age
# cell — confirmed live against real search output 2026-08-06. The
# checkbox's own `name` attribute is the opaque per-post id binsearch's own
# /nzb?q=<query>&<id>=on GET uses to build a real downloadable .nzb for
# just that one post (no other params needed).
_RE_ROW = re.compile(
    r'name="([^"]+)"/></td><td><div class="flex flex-col">'
    r'<a[^>]+href="/details/[^"]+">([^<]+)</a>'
    r'.*?<span[^>]*>([\d.]+\s*[KMGT]?i?B)</span>'
    r'.*?<td class="min-w-20">([^<]+)</td>',
    re.IGNORECASE | re.DOTALL
)

# A raw title search surfaces every post matching the query as its own
# row -- for a modern release that's mostly PAR2 recovery blocks, NFOs,
# and sample files scattered around the one post that's actually the real
# content (confirmed live: querying "The Agency" put five PAR2-block rows
# ahead of anything else, and NONE of the top 50 results for that query
# were a directly-quoted video filename at all — most real releases post
# as an .rar-compressed archive, e.g. "{Title.2160p.WEB-DL.H.265-x.rar}
# {id} yEnc", not a bare quoted .mkv). Premiumize/TorBox both unpack RAR
# archives server-side the same way they do for torrents, so a .rar post
# is just as usable as a direct video one — requiring a quoted video
# extension (tried first) rejected every real release for some queries.
# An EXCLUDE-based filter is more robust here: reject the specific
# extensions that are NEVER the actual content (recovery blocks, index/
# checksum files, cover art, text notes), and let everything else
# (.rar/.mkv/.mp4/.zip/etc.) through.
_RE_JUNK_FILE = re.compile(
    r'\.(?:par2|nfo|sfv|srr|jpg|jpeg|png|gif|txt|url|db|diz)["”}]',
    re.IGNORECASE
)


def _get(url, timeout=12):
    try:
        import requests
        r = requests.get(url, headers=_HEADERS, timeout=timeout)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log('[Starfleet/NZB] fetch error %s: %s' % (url[:80], e), xbmc.LOGWARNING)
    return ''


def search_binsearch_nzb(title, year=None, limit=10, media_type='movie'):
    """Search binsearch.info by title. Returns
    [{'title':..., 'size':..., 'age':..., 'nzb_url':..., 'source': 'Binsearch'}]
    — nzb_url is a direct, ready-to-fetch .nzb download link, not a search
    result page; no further hop needed to get a real NZB for it."""
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/?q=%s&max=100' % (BINSEARCH_BASE, _q(query))
        html = _get(url)
        if not html:
            return []

        import html as _html_lib
        results = []
        for m in _RE_ROW.finditer(html):
            if len(results) >= limit:
                break
            post_id, raw_title, size, age = m.groups()
            name = _html_lib.unescape(raw_title).strip()
            if not name or _RE_JUNK_FILE.search(name):
                continue
            name = name.strip('"')
            nzb_url = '%s/nzb?q=%s&%s=on' % (BINSEARCH_BASE, _q(query), post_id)
            results.append({
                'title':   name,
                'size':    size.strip(),
                'age':     age.strip(),
                'nzb_url': nzb_url,
                'source':  'Binsearch',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/NZB] Binsearch search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Newznab-API indexers (NZBGeek, NZBPlanet) — need the user's own key ──────

def _newznab_search(base_url, api_key, source_name, title, year=None, limit=10, media_type='movie'):
    """Generic Newznab `t=search` query — shared by every Newznab-compatible
    indexer (NZBGeek, NZBPlanet, and any other one added later), since the
    API shape itself is identical across all of them; only base_url/api_key
    differ per site."""
    if not api_key:
        return []
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s?t=search&q=%s&apikey=%s&extended=1&limit=%d' % (
            base_url, _q(query), _q(api_key), max(limit, 20))
        xml_text = _get(url, timeout=15)
        if not xml_text:
            return []

        import xml.etree.ElementTree as ET
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError:
            return []

        # A Newznab error response is a bare <error .../> root, not <rss>
        if root.tag == 'error':
            xbmc.log('[Starfleet/NZB] %s error: %s' % (source_name, root.get('description', '')),
                     xbmc.LOGWARNING)
            return []

        ns = {'newznab': 'http://www.newznab.com/DTD/2010/feeds/attributes/'}
        results = []
        for item in root.findall('.//item'):
            if len(results) >= limit:
                break
            name = (item.findtext('title') or '').strip()
            if not name:
                continue
            enclosure = item.find('enclosure')
            nzb_url = (enclosure.get('url') if enclosure is not None else '') or (item.findtext('link') or '')
            if not nzb_url:
                continue
            size_bytes = 0
            for attr in item.findall('newznab:attr', ns):
                if attr.get('name') == 'size':
                    try:
                        size_bytes = int(attr.get('value', 0))
                    except (TypeError, ValueError):
                        pass
                    break
            size = ''
            if size_bytes >= 1_073_741_824:
                size = '%.2f GB' % (size_bytes / 1_073_741_824)
            elif size_bytes >= 1_048_576:
                size = '%.0f MB' % (size_bytes / 1_048_576)
            results.append({
                'title':   name,
                'size':    size,
                'age':     (item.findtext('pubDate') or '').strip(),
                'nzb_url': nzb_url,
                'source':  source_name,
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/NZB] %s search error: %s' % (source_name, e), xbmc.LOGWARNING)
        return []


def search_nzbgeek(title, year=None, limit=10, media_type='movie'):
    api_key = ADDON.getSetting('nzbgeek_api_key').strip()
    if ADDON.getSetting('nzbgeek_enabled') != 'true' or not api_key:
        return []
    return _newznab_search('https://api.nzbgeek.info/api', api_key, 'NZBGeek',
                            title, year=year, limit=limit, media_type=media_type)


def search_nzbplanet(title, year=None, limit=10, media_type='movie'):
    api_key = ADDON.getSetting('nzbplanet_api_key').strip()
    if ADDON.getSetting('nzbplanet_enabled') != 'true' or not api_key:
        return []
    return _newznab_search('https://nzbplanet.net/api', api_key, 'NZBPlanet',
                            title, year=year, limit=limit, media_type=media_type)
