# -*- coding: utf-8 -*-
"""
resources/lib/title_utils.py

Shared title-cleaning for anything scraped from a source site (adult films,
movie/TV torrent results, embed-site listings) — strips resolution/quality/
codec/release-group junk so the SAME clean string is used for display AND
for matching against other sources' titles. A messy suffix on one side and
not the other is exactly what causes a real match to be missed.
"""

import re

# Season/episode markers (S01E02, 1x02) are deliberately never touched —
# only quality/encoding/source/release-group junk gets stripped.
_RE_SEP = re.compile(r'[._]+')
_RE_WS  = re.compile(r'\s+')

_RE_YEAR_TAG = re.compile(r'\s*[\[\(]\s*(?:19[0-9]\d|20[0-9]\d)\s*[\]\)]')
# A bare (unbracketed) year at the very END of the title, once everything
# after it has already been stripped away — e.g. "Anal.Players.9.2026.1080p.
# WEBRip.x265-RARTA" reduces to "Anal Players 9 2026" by the time quality/
# codec words are removed below. That trailing "2026" is release-name
# metadata, not part of the actual title, and left in place it breaks any
# caller that requires the cleaned title's words to appear as one
# contiguous phrase (there's real content — studio/tag text — between the
# real title and the year in the original release name). Requires a
# preceding space so a title that legitimately IS just a year (e.g. "1917")
# is never touched.
_RE_YEAR_BARE_TRAILING = re.compile(r'\s+(?:19[0-9]\d|20[0-9]\d)$')

_QUALITY_WORDS = (
    r'1080p|720p|480p|2160p|4k|uhd|hdr10?|sdr|'
    r'web[\-\s]?dl|webrip|bluray|brrip|bdrip|dvdrip|hdrip|hdtv|'
    r'x264|x265|hevc|avc|aac\d?(?:\.\d)?|ac3|dts(?:-hd)?|ddp?\d(?:\.\d)?|10bit|8bit'
)

_RE_QUALITY_BRACKET = re.compile(
    r'\s*[\[\(][^\[\]\(\)]{0,50}?(?:%s)[^\[\]\(\)]{0,50}?[\]\)]' % _QUALITY_WORDS,
    re.IGNORECASE
)
_RE_QUALITY_BARE = re.compile(r'\b(?:%s)\b' % _QUALITY_WORDS, re.IGNORECASE)

# Trailing "[RARBG]"/"[YTS.MX]"/"-GROUPNAME" style release-group tags —
# only at the END of the title, so a legitimate bracketed word mid-title
# (e.g. a subtitle) is never touched.
_RE_TRAILING_GROUP_BRACKET = re.compile(r'\s*[\[\(][A-Za-z0-9][A-Za-z0-9.\-]{1,20}[\]\)]\s*$')
_RE_TRAILING_GROUP_DASH    = re.compile(r'-[A-Za-z0-9]{2,15}$')


def clean_title(title):
    """Generic scraper-junk stripper for movie/TV titles (torrent results,
    embed-site listings, etc.). Safe to call on an already-clean title —
    returns it unchanged if nothing matches."""
    if not title:
        return title
    # Trailing release-group tag ("[YTS.MX]", "-RARBG") must be stripped
    # BEFORE dot/underscore separators get converted to spaces — otherwise
    # "[YTS.MX]" becomes "[YTS MX]" and no longer matches a no-space bracket.
    t = _RE_TRAILING_GROUP_BRACKET.sub('', title)
    m = _RE_TRAILING_GROUP_DASH.search(t)
    if m and len(t[:m.start()].strip()) > 3:
        t = t[:m.start()]
    t = _RE_SEP.sub(' ', t)
    t = _RE_YEAR_TAG.sub(' ', t)
    t = _RE_QUALITY_BRACKET.sub(' ', t)
    t = _RE_QUALITY_BARE.sub(' ', t)
    t = _RE_WS.sub(' ', t).strip(' -._')
    t = _RE_YEAR_BARE_TRAILING.sub('', t).strip()
    return t or title


# Adult titles get the same cleaning PLUS a bracketed (XXX)/[XXX] tag strip —
# but never a bare standalone "xxx" elsewhere in the title. Confirmed live:
# that's frequently a real, intentional part of a title (e.g. "The Odyssey:
# A XXX Parody"), not a junk marker, so it must never be touched.
_RE_XXX_BRACKET = re.compile(r'\s*[\[\(]\s*xxx\s*[\]\)]', re.IGNORECASE)


def clean_adult_title(title):
    """Adult-specific variant of clean_title() — same junk stripping, plus
    a bracketed (XXX) tag, minus ever touching a bare 'xxx' in the title."""
    if not title:
        return title
    t = clean_title(title)
    t = _RE_XXX_BRACKET.sub(' ', t)
    t = _RE_WS.sub(' ', t).strip(' -._')
    return t or title
