# -*- coding: utf-8 -*-
"""
resources/lib/javhd_sources.py — JAV source #2: javhd.today.

Same overall shape as javseen_sources.py (sitemap-based catalog, no
Cloudflare wall on the site's own pages, third-party embed-host aggregator
for actual playback — confirmed live it rotates through the SAME host pool
javseen.tv uses, e.g. mycloudz.cc, cloudwish.xyz), just a different markup
convention for the candidate list: instead of inline playEmbed('url') JS
calls, javhd.today's embed page renders a "Multi Server" dropdown where
each option carries the target URL base64-encoded in a data-embed
attribute (e.g. data-embed="aHR0cHM6Ly9teWNsb3Vkei5jYy92L2V1ZGM0dGw1b2t3Yw==").
Both sites' candidates ultimately feed the same resolvers.py chain, so
this module only needs to differ in how it *finds* those candidate URLs.
"""
import re
import base64
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

JAVHD_BASE = 'https://javhd.today'

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
    'Accept-Language': 'en-US,en;q=0.9',
}

PAGE_SIZE = 30
_LATEST_SITEMAP_URL = JAVHD_BASE + '/sitemaps/sitemap-videos-1.xml'
_LATEST_CACHE_KEY    = 'javhd_latest_all'
_LATEST_CACHE_TTL    = 6 * 3600

_RE_SITEMAP_ITEM = re.compile(
    r'<loc>https://javhd\.today/(\d+)/([a-z0-9\-]+)/</loc>', re.IGNORECASE
)
_RE_IFRAME_SRC   = re.compile(r'<iframe[^>]+src="([^"]+)"', re.IGNORECASE)
_RE_DATA_EMBED   = re.compile(r'data-embed="([^"]+)"')
_RE_OG_IMAGE     = re.compile(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', re.IGNORECASE)
_RE_OG_DESC      = re.compile(r'<meta[^>]+property="og:description"[^>]+content="([^"]+)"', re.IGNORECASE)


def _get(url, referer='', timeout=15):
    import requests
    headers = dict(_HEADERS)
    if referer:
        headers['Referer'] = referer
    try:
        r = requests.get(url, headers=headers, timeout=timeout)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log('[Starfleet/JAVHD] fetch error %s: %s' % (url[:80], e), xbmc.LOGWARNING)
    return ''


def _slug_title(slug):
    return re.sub(r'\s+', ' ', slug.replace('-', ' ')).strip().title()


def _detail_url(vid, slug):
    return '%s/%s/%s/' % (JAVHD_BASE, vid, slug)


def _load_latest_all():
    cached = _cache.get(_LATEST_CACHE_KEY)
    if cached is not None:
        return cached or []
    xml_text = _get(_LATEST_SITEMAP_URL)
    items = []
    if xml_text:
        for m in _RE_SITEMAP_ITEM.finditer(xml_text):
            vid, slug = m.group(1), m.group(2)
            items.append({'id': vid, 'slug': slug, 'title': _slug_title(slug), 'source': 'javhd'})
    _cache.set(_LATEST_CACHE_KEY, items or False, _LATEST_CACHE_TTL)
    xbmc.log('[Starfleet/JAVHD] sitemap parsed: %d items' % len(items), xbmc.LOGINFO)
    return items


def _populate_artwork(items):
    """Concurrently fetch each item's own detail page for its real cover
    art + description before the grid ever opens -- see javleak_sources.py's
    identical helper for the full reasoning (this site's sitemap-based
    listing is image-less the same way)."""
    if not items:
        return
    from concurrent.futures import ThreadPoolExecutor

    def _fetch(item):
        try:
            detail = get_javhd_detail(item['id'], item['slug'])
            if detail.get('fanart'):
                item['thumb']  = detail['fanart']
                item['fanart'] = detail['fanart']
            if detail.get('description'):
                item['plot'] = detail['description']
        except Exception:
            pass

    with ThreadPoolExecutor(max_workers=min(15, len(items))) as pool:
        list(pool.map(_fetch, items))


def browse_javhd_latest(page=1):
    items = _load_latest_all()
    start = (page - 1) * PAGE_SIZE
    page_items = items[start:start + PAGE_SIZE]
    _populate_artwork(page_items)
    return page_items


def get_javhd_detail(vid, slug):
    html = _get(_detail_url(vid, slug))
    if not html:
        return {}
    out = {}
    m = _RE_OG_IMAGE.search(html)
    if m:
        out['fanart'] = m.group(1)
    m = _RE_OG_DESC.search(html)
    if m:
        import html as _html_lib
        out['description'] = _html_lib.unescape(m.group(1))
    return out


def _candidate_embed_urls(vid, slug):
    """detail page -> its own /embed/<id>/ page -> decode every
    data-embed="<base64>" attribute in the server-selector dropdown.
    Confirmed live: these decode to the same third-party hosts (mycloudz,
    cloudwish, etc.) javseen.tv's own candidate list uses."""
    detail_url = _detail_url(vid, slug)
    html = _get(detail_url)
    if not html:
        return []

    m = _RE_IFRAME_SRC.search(html)
    if not m:
        return []
    embed_url = m.group(1)

    embed_html = _get(embed_url, referer=detail_url)
    if not embed_html:
        return []

    candidates = []
    for b64 in _RE_DATA_EMBED.findall(embed_html):
        try:
            decoded = base64.b64decode(b64).decode('utf-8', errors='ignore')
            if decoded.startswith('http') and decoded not in candidates:
                candidates.append(decoded)
        except Exception:
            continue
    return candidates


def resolve_javhd_stream(vid, slug):
    """Same resolvers.py hand-off as javseen_sources.resolve_javseen_stream
    — see that module's docstring for why no browser/harvest-service is
    needed for either site. Also gets the same vidhide_bypass.py direct
    shortcut for mycloudz.cc/cloudwish.xyz-template hosts, added
    2026-08-04 — see that module's own docstring."""
    candidates = _candidate_embed_urls(vid, slug)
    if not candidates:
        return ''

    from resources.lib import vidhide_bypass
    from resources.lib import resolvers as _resolvers
    for url in candidates:
        direct = vidhide_bypass.try_resolve(url)
        if direct:
            xbmc.log('[Starfleet/JAVHD] resolved via VidHide bypass %s' % url[:60], xbmc.LOGINFO)
            return direct
        try:
            resolved = _resolvers.resolve(url)
        except Exception as e:
            xbmc.log('[Starfleet/JAVHD] resolver error for %s: %s' % (url, e), xbmc.LOGWARNING)
            continue
        if resolved and resolved != url:
            xbmc.log('[Starfleet/JAVHD] resolved via %s' % url[:60], xbmc.LOGINFO)
            return resolved
    xbmc.log('[Starfleet/JAVHD] no candidate resolved (%d tried)' % len(candidates), xbmc.LOGWARNING)
    return ''
