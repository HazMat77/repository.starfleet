# -*- coding: utf-8 -*-
"""
resources/lib/simkl_sync.py

Push "watched" events AND real-time playback progress to a paired SIMKL
account, and pull saved progress back so a different device can resume
where another one left off. This is the actual payoff of simkl_auth.py's
pairing.

Two separate SIMKL mechanisms are both used here, for two different jobs:
  - POST /sync/history (verified against api.simkl.org's "Mark as watched"
    guide, 2026) — a fire-and-forget "record that a user finished a movie/
    episode" call. Used by mark_watched_movie()/mark_watched_episode()
    below exactly as before.
  - POST /scrobble/start|pause|stop and GET /sync/playback (verified
    against api.simkl.org's scrobble guide, 2026) — the actual session-
    progress mechanism, used for real cross-device resume. scrobble_start()
    opens a session when playback begins; scrobble_pause()/scrobble_stop()
    saves the final position when it ends (stop is used instead of pause
    once progress crosses SIMKL's own 80%-watched threshold, since /scrobble
    /stop marks watched server-side at that point same as /sync/history
    already does independently - harmless to have both agree). A different
    device later calls get_playback_progress() to read that saved
    percentage back via GET /sync/playback before it starts playing the
    same title, and watch_history.apply_resume() decides whether to honor
    it (see that function's own docstring for the exact merge logic and
    its one real limitation: converting a percentage back into seconds
    needs a known total duration, which isn't available the very first
    time a title is ever played on a given device).

Wired into watch_history.py (mark_played() for /sync/history,
start_playback_monitor()/apply_resume() for scrobble/playback) — everything
here no-ops immediately if no SIMKL account is paired, so nothing changes
when SIMKL isn't set up (same as how Trakt pairing being empty just no-ops
everywhere it's checked).

Adult content (Adult Section sources) never reaches SIMKL, confirmed live
as a real bug rather than assumed: watch_history.py's adult play paths
pass opaque keys like "ade:5122655" or "javseen:abc123" through the exact
same imdb_id parameter real content uses, and every function here used to
only check `if imdb_id or tmdb_id` — a non-empty junk string like
"ade:5122655" passed that check just fine, so it would have been sent to
SIMKL's API as a bogus IMDB id the moment a user had SIMKL paired. Fixed
by only ever treating imdb_id as valid when it actually matches real IMDB
id shape (tt<digits>) — every adult source's opaque key fails that check
and now gets silently dropped before anything is sent, independent of
(and in addition to) the separate local-only "Track adult watched
progress" Settings toggle in watch_history.py.
"""
import re
import threading
import xbmc

from resources.lib import simkl_auth

_IMDB_RE = re.compile(r'^tt\d+$')


def _real_imdb(imdb_id):
    """Returns imdb_id if it's shaped like a genuine IMDB id, else ''."""
    return imdb_id if imdb_id and _IMDB_RE.match(imdb_id) else ''

SIMKL_BASE = 'https://api.simkl.com'


def get_certification(imdb_id, media_type='movie'):
    """Content-rating certification (e.g. 'R', 'PG-13', 'TV-MA') for the
    detail screen's Parental Guide field — confirmed live against SIMKL's
    public /movies/{imdb}, /tv/{imdb} endpoints (GET /movies/tt15398776
    returned "certification":"R" for Oppenheimer; GET /tv/tt13111078
    returned "certification":"TV-MA" for Special Ops: Lioness). This is
    public metadata, not account data — uses the bundled client_id only
    (same shared-app model as everywhere else in this addon), no pairing
    or access token needed, so it works even for users who never pair
    SIMKL at all."""
    if not imdb_id:
        return ''
    try:
        import requests
        path = 'tv' if media_type == 'tv' else 'movies'
        r = requests.get('%s/%s/%s' % (SIMKL_BASE, path, imdb_id),
                         headers={'simkl-api-key': simkl_auth.SIMKL_CLIENT_ID}, timeout=8)
        r.raise_for_status()
        return r.json().get('certification', '') or ''
    except Exception as e:
        xbmc.log('[Starfleet/SIMKL] certification lookup error: %s' % e, xbmc.LOGWARNING)
        return ''


def _fresh_token():
    # Same "always construct a fresh Addon(), never reuse a cached one"
    # fix as favorites.py's _addon() and simkl_auth.py's is_paired() —
    # this runs from watch_history.py's playback-monitor thread, which can
    # easily be alive across a mid-session pairing.
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.starfleet').getSetting('simkl_access_token').strip()


def _headers():
    token = _fresh_token()
    return {
        'Authorization': 'Bearer %s' % token,
        'Content-Type':  'application/json',
        'User-Agent':    simkl_auth.USER_AGENT,
    }


def _params():
    return {'client_id': simkl_auth.SIMKL_CLIENT_ID, 'app-name': simkl_auth.APP_NAME,
            'app-version': simkl_auth.APP_VERSION}


def _post(payload, endpoint='/sync/history'):
    if not simkl_auth.is_paired():
        return
    token = _fresh_token()
    if not token:
        return
    try:
        import requests
        r = requests.post(SIMKL_BASE + endpoint, params=_params(),
                          headers=_headers(), json=payload, timeout=10)
        xbmc.log('[Starfleet/SIMKL] %s -> %s: %s' % (endpoint, r.status_code, payload),
                 xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/SIMKL] %s error: %s' % (endpoint, e), xbmc.LOGWARNING)


def _post_async(payload, endpoint='/sync/history'):
    threading.Thread(target=_post, args=(payload, endpoint), daemon=True).start()


def mark_watched_movie(imdb_id='', tmdb_id='', title=''):
    """Send every ID we actually have — SIMKL walks imdb/tmdb in priority
    order server-side and falls back to title match if neither resolves."""
    imdb_id = _real_imdb(imdb_id)
    if not simkl_auth.is_paired() or not (imdb_id or tmdb_id):
        return
    ids = {}
    if imdb_id:
        ids['imdb'] = imdb_id
    if tmdb_id:
        ids['tmdb'] = str(tmdb_id)
    entry = {'ids': ids}
    if title:
        entry['title'] = title
    _post_async({'movies': [entry]})


def mark_watched_episode(imdb_id='', tmdb_id='', title='', season=0, episode=0):
    imdb_id = _real_imdb(imdb_id)
    if not simkl_auth.is_paired() or not (imdb_id or tmdb_id) or not season or not episode:
        return
    ids = {}
    if imdb_id:
        ids['imdb'] = imdb_id
    if tmdb_id:
        ids['tmdb'] = str(tmdb_id)
    entry = {
        'ids': ids,
        'seasons': [{'number': int(season), 'episodes': [{'number': int(episode)}]}],
    }
    if title:
        entry['title'] = title
    _post_async({'shows': [entry]})


def mark_show_watched(imdb_id='', tmdb_id='', title='', season_episode_pairs=None):
    """Mark every given (season, episode) watched on SIMKL in one call.
    Confirmed live as the real reason a dismissed Continue Watching card
    kept reappearing even after dismiss_show()'s local mark_episodes_watched
    ran: continue_watching.py's own SIMKL merge tier (get_all_items_shows(),
    /sync/all-items/shows) independently recomputes each show's
    'next_to_watch' straight from SIMKL's OWN per-episode watched state —
    a purely local write never touches that, so SIMKL kept reporting the
    same unwatched next episode and continue_watching.py re-synthesized the
    card from that remote data on every single rebuild, regardless of what
    the local watch_history.json said. dismiss_show() must call this
    alongside its local write so both sides agree."""
    imdb_id = _real_imdb(imdb_id)
    if not simkl_auth.is_paired() or not (imdb_id or tmdb_id) or not season_episode_pairs:
        return
    ids = {}
    if imdb_id:
        ids['imdb'] = imdb_id
    if tmdb_id:
        ids['tmdb'] = str(tmdb_id)
    by_season = {}
    for season, episode in season_episode_pairs:
        by_season.setdefault(int(season), []).append({'number': int(episode)})
    entry = {
        'ids': ids,
        'seasons': [{'number': s, 'episodes': eps} for s, eps in sorted(by_season.items())],
    }
    if title:
        entry['title'] = title
    _post_async({'shows': [entry]})


# ── Scrobble (real cross-device resume) ────────────────────────────────────────

def _scrobble_body(progress, imdb_id='', tmdb_id='', title='', season=0, episode=0):
    ids = {}
    if imdb_id:
        ids['imdb'] = imdb_id
    if tmdb_id:
        ids['tmdb'] = str(tmdb_id)
    body = {'progress': float(progress)}
    if season and episode:
        show = {'ids': ids}
        if title:
            show['title'] = title
        body['show'] = show
        body['episode'] = {'season': int(season), 'number': int(episode)}
    else:
        movie = {'ids': ids}
        if title:
            movie['title'] = title
        body['movie'] = movie
    return body


def _scrobble(endpoint, imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    imdb_id = _real_imdb(imdb_id)
    if not simkl_auth.is_paired() or not (imdb_id or tmdb_id):
        return
    body = _scrobble_body(progress, imdb_id, tmdb_id, title, season, episode)
    _post_async(body, endpoint)


def scrobble_start(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback actually begins (see watch_history.py's
    start_playback_monitor()). progress should reflect where playback is
    actually starting from (e.g. a resumed position), not always 0."""
    _scrobble('/scrobble/start', imdb_id, tmdb_id, title, season, episode, progress)


def scrobble_pause(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback ends short of SIMKL's own 80%-watched mark —
    saves the position so get_playback_progress() below can find it from a
    different device later."""
    _scrobble('/scrobble/pause', imdb_id, tmdb_id, title, season, episode, progress)


def scrobble_stop(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback ends at/past SIMKL's own 80%-watched mark —
    finalizes the session; SIMKL marks it watched server-side at this
    threshold, same conclusion mark_watched_movie/episode already reaches
    independently via /sync/history at this addon's own 90% threshold."""
    _scrobble('/scrobble/stop', imdb_id, tmdb_id, title, season, episode, progress)


def _parse_iso_ts(s):
    """paused_at is documented as an ISO-8601 UTC timestamp - converts it
    to a unix epoch int so continue_watching.py can sort remote-only
    entries by recency alongside local ones. Returns 0 (sorts last, never
    crashes) on any format it doesn't recognize."""
    if not s:
        return 0
    try:
        import datetime
        try:
            dt = datetime.datetime.fromisoformat(s.replace('Z', '+00:00'))
            return int(dt.timestamp())
        except Exception:
            import calendar
            dt = datetime.datetime.strptime(s[:19], '%Y-%m-%dT%H:%M:%S')
            return calendar.timegm(dt.timetuple())
    except Exception:
        return 0


def _normalize_playback_item(item):
    """One /sync/playback item -> a flat dict, or None if its shape doesn't
    parse (unknown type, missing progress, episode with no season/number).
    Shared by get_playback_progress() (single-title lookup) and
    continue_watching.py (whole-list cross-device merge)."""
    is_episode = item.get('type') == 'episode' or bool(item.get('episode'))
    container = item.get('show') if is_episode else item.get('movie')
    if not container:
        return None
    try:
        progress = float(item.get('progress'))
    except (TypeError, ValueError):
        return None
    season = episode = 0
    if is_episode:
        ep = item.get('episode') or {}
        try:
            season, episode = int(ep.get('season', 0)), int(ep.get('number', 0))
        except (TypeError, ValueError):
            return None
        if not (season and episode):
            return None
    return {
        'is_episode': is_episode,
        'ids':        container.get('ids', {}) or {},
        'season':     season, 'episode': episode,
        'title':      container.get('title', ''),
        'year':       container.get('year', ''),
        'progress':   progress,
        'ts':         _parse_iso_ts(item.get('paused_at', '')),
    }


def get_normalized_playback():
    """Every one of this account's paused playback sessions (movies and
    episodes mixed), normalized to a flat dict per item. [] if not paired,
    the request fails, or nothing is currently paused."""
    if not simkl_auth.is_paired():
        return []
    try:
        import requests
        r = requests.get(SIMKL_BASE + '/sync/playback', params=_params(),
                         headers=_headers(), timeout=10)
        r.raise_for_status()
        items = r.json() or []
    except Exception as e:
        xbmc.log('[Starfleet/SIMKL] sync/playback error: %s' % e, xbmc.LOGWARNING)
        return []
    out = []
    for item in items:
        n = _normalize_playback_item(item)
        if n:
            out.append(n)
    return out


def get_all_items_shows():
    """Every show on this account with status == 'watching' (real progress,
    not just watchlisted/completed/dropped), normalized to a flat dict per
    show. This is the "full watched-history" endpoint continue_watching.py's
    own docstring flagged as deferred pending confidence in its exact
    response shape — now confirmed live: GET /sync/all-items/shows returns
    {'shows': [...]}, each with a 'next_to_watch' field like 'S01E08' that
    SIMKL already computed from its own per-episode watched state. This is
    what lets a show tracked ONLY on SIMKL (watched via a different device
    or app, e.g. gears, with nothing ever paused/local on THIS device) still
    show up in Continue Watching with the correct next episode, instead of
    needing a local TMDB-catalog walk that has nothing to anchor from.
    [] if not paired, the request fails, or nothing is in-progress."""
    if not simkl_auth.is_paired():
        return []
    try:
        import requests
        r = requests.get(SIMKL_BASE + '/sync/all-items/shows', params=_params(),
                         headers=_headers(), timeout=10)
        r.raise_for_status()
        data = r.json() or {}
    except Exception as e:
        xbmc.log('[Starfleet/SIMKL] sync/all-items/shows error: %s' % e, xbmc.LOGWARNING)
        return []
    out = []
    for item in (data.get('shows') or []):
        try:
            if item.get('status') != 'watching':
                continue
            m = re.match(r'^S(\d+)E(\d+)$', item.get('next_to_watch') or '', re.IGNORECASE)
            if not m:
                continue
            show = item.get('show') or {}
            out.append({
                'ids':          show.get('ids', {}) or {},
                'title':        show.get('title', ''),
                'year':         show.get('year', ''),
                'next_season':  int(m.group(1)),
                'next_episode': int(m.group(2)),
                'ts':           _parse_iso_ts(item.get('last_watched_at', '')),
            })
        except Exception:
            continue
    return out


def get_playback_progress(imdb_id='', tmdb_id='', season=0, episode=0):
    """Return the matching item's saved progress percentage (0-100) from
    get_normalized_playback() above, or None if nothing matches / not
    paired / the request fails. Movies match on ids alone; episodes also
    require season/episode to match exactly, since one show can have
    several different paused episodes saved at once."""
    if not (imdb_id or tmdb_id):
        return None
    is_episode = bool(season and episode)
    for item in get_normalized_playback():
        if item['is_episode'] != is_episode:
            continue
        ids = item['ids']
        if not ((imdb_id and str(ids.get('imdb', '')) == str(imdb_id)) or
                (tmdb_id and str(ids.get('tmdb', '')) == str(tmdb_id))):
            continue
        if is_episode and (item['season'] != int(season) or item['episode'] != int(episode)):
            continue
        return item['progress']
    return None
