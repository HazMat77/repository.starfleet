# -*- coding: utf-8 -*-
"""
resources/lib/trakt_widgets.py

"Anticipated" movies/shows for the home screen's Settings-hover carousel.

Originally called Trakt's own /movies/anticipated /shows/anticipated
endpoints (Trakt ranks by how many users have a title watchlisted), but that
required every installer to register their own Trakt API app just to see
this carousel populated at all — decided against that friction. This now
sources from TMDB alone (already required by the rest of the addon, zero
extra setup): unreleased titles sorted by TMDB's own popularity score
(metadata.get_movies_anticipated/get_tv_anticipated), which tracks
"most-hyped upcoming" closely enough without needing an account of any kind.

Trakt *account pairing* is a separate, independent feature now (see
trakt_auth.py) — no longer tied to this carousel.
"""
import xbmc

from resources.lib import metadata as _meta


def _build_row(items, media_type, limit):
    from concurrent.futures import ThreadPoolExecutor, as_completed

    stubs = [str(m.get('tmdb_id', '')) for m in items if m.get('tmdb_id')][:limit]

    def _enrich(tmdb_id):
        try:
            detail = (_meta.get_movie_detail(tmdb_id) if media_type == 'movie'
                      else _meta.get_tv_detail(tmdb_id))
        except Exception:
            detail = {}
        if not detail or not detail.get('title'):
            return None
        return {
            'id':         tmdb_id,
            'tmdb_id':    tmdb_id,
            'title':      detail.get('title', ''),
            'year':       detail.get('year', ''),
            'rating':     detail.get('rating', 0),
            'thumb':      detail.get('thumb', ''),
            'fanart':     detail.get('fanart', ''),
            'plot':       detail.get('overview', ''),
            'trailer':    detail.get('trailer', ''),
            'media_type': media_type,
            'source':     'anticipated_trailer',
        }

    results = []
    if stubs:
        with ThreadPoolExecutor(max_workers=min(10, len(stubs))) as pool:
            futures = [pool.submit(_enrich, t) for t in stubs]
            for fut in as_completed(futures, timeout=20):
                try:
                    r = fut.result()
                    if r:
                        results.append(r)
                except Exception:
                    pass

    # Preserve TMDB's own popularity ranking rather than thread-completion order
    order = {t: i for i, t in enumerate(stubs)}
    results.sort(key=lambda f: order.get(f['tmdb_id'], 999))
    return results


def _multi_page(fetch_fn, pages=4):
    """Fetch several sequential pages and concatenate — this widget's own
    limit= param used to be pure theater: get_movies_anticipated(page=1)
    only ever returned one ~20-item page no matter how high limit was set,
    so _build_row's own [:limit] slice never had more than ~20 to work
    with. Bumped to match every other carousel row on Home (~60-100 items
    instead of one page), per explicit request — see afdb_router.py's own
    identical helper for the full rationale on why this stops at a few
    pages rather than fetching every page a category has."""
    out = []
    for p in range(1, pages + 1):
        try:
            batch = fetch_fn(page=p) or []
        except Exception:
            batch = []
        if not batch:
            break
        out.extend(batch)
    return out


def get_anticipated_movies(limit=80):
    try:
        items = _multi_page(_meta.get_movies_anticipated)
        return _build_row(items, 'movie', limit)
    except Exception as e:
        xbmc.log('[Starfleet/Anticipated] movies error: %s' % e, xbmc.LOGWARNING)
        return []


def get_anticipated_shows(limit=80):
    try:
        items = _multi_page(_meta.get_tv_anticipated)
        return _build_row(items, 'tv', limit)
    except Exception as e:
        xbmc.log('[Starfleet/Anticipated] shows error: %s' % e, xbmc.LOGWARNING)
        return []
