"""
DNS-over-HTTPS fallback for hostnames whose local resolution is blocked
even though the domain itself is live. Confirmed for chat.cfbu247.sbs:
the local/ISP resolver returns NXDOMAIN (getaddrinfo failed) while
Cloudflare's own public DoH resolver returns a real, working A record for
the exact same query, and the resolved IP serves real content when hit
directly. Rather than hardcode that IP (it can rotate), this queries DoH
fresh on first failure, caches the answer briefly, and swaps it in only
for the single failing request via a scoped socket.getaddrinfo patch —
transparent to requests/urllib3/ssl (SNI/Host header untouched), so no
other error handling needs to change.
"""
import socket
import threading
import time

import requests

_DOH_CACHE = {}
_DOH_LOCK = threading.Lock()
_DOH_TTL = 300

_DOH_ENDPOINTS = [
    ('https://cloudflare-dns.com/dns-query', {'accept': 'application/dns-json'}),
    ('https://dns.google/resolve', {}),
]


def _doh_lookup(hostname):
    now = time.time()
    with _DOH_LOCK:
        cached = _DOH_CACHE.get(hostname)
        if cached and cached[1] > now:
            return cached[0]

    for endpoint, headers in _DOH_ENDPOINTS:
        try:
            r = requests.get(endpoint, params={'name': hostname, 'type': 'A'},
                              headers=headers, timeout=5)
            data = r.json()
            for ans in data.get('Answer', []):
                if ans.get('type') == 1:
                    ip = ans['data']
                    with _DOH_LOCK:
                        _DOH_CACHE[hostname] = (ip, now + _DOH_TTL)
                    return ip
        except Exception:
            continue
    return None


def _is_dns_failure(exc):
    msg = str(exc)
    return 'getaddrinfo failed' in msg or 'NameResolutionError' in msg or 'Name or service not known' in msg


def request(method, url, **kwargs):
    """requests.request(), but on a local DNS resolution failure, retries
    once with getaddrinfo scoped-patched to a fresh DoH-resolved IP for
    just that hostname. Re-raises the original error if DoH can't resolve
    it either (a genuinely dead domain still fails the same way as before)."""
    from urllib.parse import urlparse

    try:
        return requests.request(method, url, **kwargs)
    except requests.exceptions.ConnectionError as e:
        if not _is_dns_failure(e):
            raise
        hostname = urlparse(url).hostname
        ip = _doh_lookup(hostname)
        if not ip:
            raise

        real_getaddrinfo = socket.getaddrinfo

        def _patched(host, *a, **kw):
            if host == hostname:
                host = ip
            return real_getaddrinfo(host, *a, **kw)

        socket.getaddrinfo = _patched
        try:
            return requests.request(method, url, **kwargs)
        finally:
            socket.getaddrinfo = real_getaddrinfo


def get(url, **kwargs):
    return request('GET', url, **kwargs)
