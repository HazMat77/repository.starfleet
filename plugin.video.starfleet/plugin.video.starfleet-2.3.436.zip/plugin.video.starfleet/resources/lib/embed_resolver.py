# -*- coding: utf-8 -*-
"""
resources/lib/embed_resolver.py

Internal resolver for embed player URLs that ResolveURL cannot handle.
Covers the embed domains seen in adult stream scrapers:
  - my.embedseek.online/#hash
  - p.easyvidplayer.com/#hash
  - mixdrop.ag/e/ID
  - doodstream.com/e/ID  (bonus)
  - streamtape.com/e/ID  (bonus)

Attempts to extract a direct HLS/MP4 URL from the embed page without
a JavaScript engine by pattern-matching known JavaScript source patterns.
"""

import re
import base64
import xbmc

try:
    import requests as _req
except ImportError:
    _req = None

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)

_session = None

def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update({'User-Agent': _UA})
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=1, backoff_factor=0.3)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _fetch(url, referer='', timeout=10):
    s = _sess()
    if not s:
        return ''
    headers = {}
    if referer:
        headers['Referer'] = referer
    try:
        r = s.get(url, headers=headers, timeout=timeout)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Embed] fetch error %s: %s' % (url[:60], e), xbmc.LOGWARNING)
        return ''


# ── Generic source-extraction patterns ───────────────────────────────────────

_SOURCE_RE = [
    # JWPlayer / VideoJS / plyr style: file: "URL"
    re.compile(r'''["']?file["']?\s*:\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    # HTML5 <source src="URL">
    re.compile(r'''<source[^>]+src=["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    # Hls.js: Hls.loadSource("URL")
    re.compile(r'''loadSource\(["'](https?://[^"']+\.m3u8[^"']*)["']''', re.I),
    # var src = "URL"
    re.compile(r'''(?:var\s+)?(?:src|source|url|stream)\s*=\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    # Generic: "https://...m3u8" anywhere in the page
    re.compile(r'''["'](https?://[^\s"'<>]+\.m3u8[^\s"'<>]*)["']''', re.I),
    # Generic MP4
    re.compile(r'''["'](https?://[^\s"'<>]+\.mp4[^\s"'<>]*)["']''', re.I),
]


_RE_JS_UNICODE_ESCAPE = re.compile(r'\\u([0-9a-fA-F]{4})')


def _extract_from_html(html):
    """Try all patterns to find a direct stream URL in HTML/JS source."""
    for pattern in _SOURCE_RE:
        m = pattern.search(html)
        if m:
            url = m.group(1).replace('\\/', '/').strip()
            # Some pages embed the URL as a JS string literal with real
            # \uXXXX escape sequences left as literal 6-char text (e.g.
            # "...&e=..." instead of "...&e=...") — confirmed live on
            # a SportSurge embed chain, where the token query string's "&"
            # came through this way. Decode any of these back to the real
            # character rather than passing the literal escape text on to
            # the CDN, which the signed token doesn't recognize.
            if '\\u' in url:
                url = _RE_JS_UNICODE_ESCAPE.sub(lambda mm: chr(int(mm.group(1), 16)), url)
            if url.startswith('http'):
                return url
    return ''


def _try_atob_fragment(fragment):
    """Attempt base64-decode of the URL fragment to find a stream URL."""
    if not fragment:
        return ''
    for pad in ('', '=', '==', '==='):
        try:
            decoded = base64.b64decode(fragment + pad).decode('utf-8', errors='ignore')
            if decoded.startswith('http'):
                return decoded
        except Exception:
            continue
    return ''


# ── MixDrop embed resolver ─────────────────────────────────────────────────────

_MD_V_RE  = re.compile(r'MDCore\.(?:v|wurl|url)\s*=\s*["\'](https?://[^"\']+)["\']', re.I)
_MD_V2_RE = re.compile(r'MDCore\.\w+\s*=\s*["\']([a-zA-Z0-9_/-]+)["\']', re.I)
_MD_CDN   = re.compile(
    r'(?:mxcontent|mixdrop|mxtapes|mxvideo)\.(?:net|co|ag|com)/[^\s"\'<>]+\.(?:mp4|m3u8)[^\s"\'<>]*',
    re.I
)


def _resolve_mixdrop(url):
    """Extract direct stream from a mixdrop.ag/e/ID embed page."""
    html = _fetch(url, referer='https://mixdrop.ag/')
    if not html:
        return ''

    # Direct MDCore.wurl / MDCore.url with full HTTPS
    m = _MD_V_RE.search(html)
    if m:
        stream = m.group(1).replace('\\/', '/')
        xbmc.log('[Embed] MixDrop direct URL: %s' % stream[:60], xbmc.LOGINFO)
        return stream

    # CDN URL anywhere in page
    m = _MD_CDN.search(html)
    if m:
        stream = 'https://' + m.group(0).replace('\\/', '/')
        xbmc.log('[Embed] MixDrop CDN URL: %s' % stream[:60], xbmc.LOGINFO)
        return stream

    # Fall back to generic extractor
    return _extract_from_html(html)


# ── DoodStream resolver ────────────────────────────────────────────────────────

def _resolve_dood(url):
    """Extract stream from doodstream.com embed."""
    html = _fetch(url, referer='https://doodstream.com/')
    if not html:
        return ''
    # DoodStream specific pattern
    m = re.search(r"dsplayer\.hotlink\s*=\s*[\"'](https?://[^\"']+)[\"']", html, re.I)
    if m:
        return m.group(1)
    # Pass data and md5 to construct URL
    m2 = re.search(r"""/pass_md5/([^"']+)["']""", html, re.I)
    if m2:
        pass_url = 'https://doodstream.com/pass_md5/' + m2.group(1)
        token_html = _fetch(pass_url, referer=url)
        if token_html and token_html.startswith('http'):
            return token_html.strip() + '?token=dood&expiry=99999'
    return _extract_from_html(html)


# ── Streamtape resolver ────────────────────────────────────────────────────────

def _resolve_streamtape(url):
    """Extract stream from streamtape.com embed."""
    html = _fetch(url, referer='https://streamtape.com/')
    if not html:
        return ''
    # Streamtape obfuscated pattern
    m = re.search(
        r'id="ideoooo[^"]*"[^>]*>[^<]*<[^>]+>([^<]+)<',
        html, re.I
    )
    if m:
        partial = m.group(1).strip()
        if partial:
            return 'https:' + partial
    return _extract_from_html(html)


# ── Ply4me resolver ───────────────────────────────────────────────────────────

_PLY4ME_SRC_RE = [
    # Standard player setup: file: "url" or src: "url"
    re.compile(r'''["']?(?:file|src|source|url|hls|mp4|stream)["']?\s*[:=]\s*["'](https?://[^"']+\.(?:m3u8|mp4)[^"']*)["']''', re.I),
    # JWPlayer setup({file:"url"})
    re.compile(r'''setup\s*\(\s*\{[^}]*["']?file["']?\s*:\s*["'](https?://[^"']+)["']''', re.I),
    # var hls = "url" / var src = "url" / var mp4 = "url"
    re.compile(r'''var\s+(?:hls|src|source|url|mp4|stream|m3u8)\s*=\s*["'](https?://[^"']+)["']''', re.I),
    # atob("base64") — ply4me often base64-encodes stream URL
    re.compile(r'''atob\s*\(\s*["']([A-Za-z0-9+/=]{20,})["']\s*\)''', re.I),
    # eval(atob("base64")) — same but wrapped in eval
    re.compile(r'''eval\s*\(\s*atob\s*\(\s*["']([A-Za-z0-9+/=]{20,})["']\s*\)''', re.I),
]


def _try_base64(val):
    """Try to base64-decode val (with various padding) and return if it's a URL."""
    for pad in ('', '=', '==', '==='):
        try:
            decoded = base64.b64decode(val + pad).decode('utf-8', errors='ignore')
            # Strip null bytes / surrounding junk
            decoded = decoded.strip('\x00').strip()
            if decoded.startswith('http'):
                return decoded
        except Exception:
            pass
    return ''


def _resolve_ply4me(url):
    """Extract direct stream from a ply4me/easyvidplayer embed page."""
    html = _fetch(url, referer=url)
    if not html:
        xbmc.log('[Embed] ply4me: empty page for %s' % url[:60], xbmc.LOGWARNING)
        return ''

    xbmc.log('[Embed] ply4me: page fetched (%d bytes) for %s' % (len(html), url[:60]), xbmc.LOGWARNING)

    for pat in _PLY4ME_SRC_RE:
        m = pat.search(html)
        if m:
            val = m.group(1).strip()
            if val.startswith('http'):
                stream = val.replace('\\/', '/')
                xbmc.log('[Embed] ply4me direct URL: %s' % stream[:80], xbmc.LOGWARNING)
                return stream
            # Might be base64 — try decoding
            decoded = _try_base64(val)
            if decoded:
                xbmc.log('[Embed] ply4me base64 decoded: %s' % decoded[:80], xbmc.LOGWARNING)
                return decoded

    # Fall back to generic extraction (catches .m3u8 / .mp4 URLs anywhere in page)
    stream = _extract_from_html(html)
    if stream:
        xbmc.log('[Embed] ply4me generic extract: %s' % stream[:80], xbmc.LOGWARNING)
    else:
        xbmc.log('[Embed] ply4me: could not extract stream from page', xbmc.LOGWARNING)
    return stream


# ── Embed-page resolver (embedseek, easyvidplayer, generic) ──────────────────

def _resolve_generic_embed(url):
    """Resolve a generic embed page (embedseek.online, easyvidplayer.com, etc.)."""
    fragment = url.split('#', 1)[1] if '#' in url else ''

    # Try fetching the embed page
    html = _fetch(url, referer=url.split('#')[0])
    if html:
        direct = _extract_from_html(html)
        if direct:
            xbmc.log('[Embed] Generic direct URL: %s' % direct[:60], xbmc.LOGINFO)
            return direct

    # If page had no direct URL, try base64-decoding the fragment
    if fragment:
        decoded = _try_atob_fragment(fragment)
        if decoded:
            # Decoded fragment may itself be an embed URL — recurse once
            if decoded.startswith('http'):
                if any(ext in decoded for ext in ('.m3u8', '.mp4')):
                    return decoded
                return _resolve_generic_embed(decoded)

    return ''


# ── Generic iframe-chain follower (SportSurge reseller wrapper pages) ─────────
#
# SportSurge's per-game stream rows link to a wrapper page (e.g. resports.cfd)
# that's pure ad markup around a single <iframe>, which itself embeds ANOTHER
# wrapper page, which finally embeds a real player page with the signed .m3u8
# URLs inline in its own JS — none of these hosts are known to ResolveURL, and
# none of them are in the specific per-host resolvers above. Confirmed live
# with a real SportSurge link: 3 hops (resports.cfd -> streame.center/embed/
# chNN.php -> streame.center/embed/hls.php?stream=...) before the real
# https://edgestreamN.pro/hls/<id>.m3u8?st=...&e=... URLs finally appear.
# Those CDN URLs 403 with no Referer at all — confirmed live 200 only when
# Referer is set to the exact URL of the page the m3u8 was found on (not the
# original SportSurge page, and not just the bare origin — the full URL of
# that specific hop), which is what this returns alongside the stream URL.

_RE_IFRAME_SRC = re.compile(r'<iframe[^>]+src=["\']([^"\']+)["\']', re.I)


def _normalize_hop_url(url, base):
    if url.startswith('//'):
        return 'https:' + url
    if url.startswith('http'):
        return url
    from urllib.parse import urljoin
    return urljoin(base, url)


def resolve_generic_iframe_chain(url, referer='', max_depth=4):
    """Follow a chain of wrapper pages, each embedding the next via a plain
    <iframe src="...">, until a direct .m3u8/.mp4 URL is found inline in a
    page's own HTML/JS (same patterns _extract_from_html already uses).
    Returns (stream_url, referer) — referer is the URL of the exact page
    the stream URL was found on, since that's what these signed CDN links
    actually check. Returns (None, None) if no stream is found within
    max_depth hops, or a fetch fails."""
    current_url = url
    current_referer = referer
    for _ in range(max_depth):
        html = _fetch(current_url, referer=current_referer)
        if not html:
            return None, None
        direct = _extract_from_html(html)
        if direct:
            return direct, current_url
        im = _RE_IFRAME_SRC.search(html)
        if not im:
            return None, None
        next_url = _normalize_hop_url(im.group(1), current_url)
        current_referer = current_url
        current_url = next_url
    return None, None


# ── Public entry point ────────────────────────────────────────────────────────

def resolve(url):
    """
    Attempt to resolve an embed URL to a direct stream URL.
    Returns the resolved URL, or '' if resolution failed.

    Call this BEFORE passing to ResolveURL so that unsupported embed
    domains are handled internally.
    """
    if not url:
        return ''

    url_lower = url.lower()

    try:
        if 'mixdrop.' in url_lower:
            return _resolve_mixdrop(url)

        if 'doodstream.' in url_lower or 'dood.watch' in url_lower or 'd0o0d.' in url_lower:
            return _resolve_dood(url)

        if 'streamtape.' in url_lower and '/e/' in url_lower:
            return _resolve_streamtape(url)

        if 'ply4me' in url_lower or 'ply4.me' in url_lower:
            return _resolve_ply4me(url)

        # Embed player domains that use #hash fragments or JS source patterns
        if any(d in url_lower for d in [
            'embedseek.', 'easyvidplayer.', 'embedgram.', 'embedrise.',
            'vidmoly.', 'vidhide.', 'vidplay.', 'filemoon.', 'voe.sx',
            'callistanise.', 'noodlemagazine.', 'tubezaur.', 'cdnzz.',
            'highstream.', 'vidlox.', 'fembed.', 'hqq.', 'waaw.',
            'autoembed.', 'multiembed.',
        ]):
            return _resolve_generic_embed(url)

    except Exception as e:
        xbmc.log('[Embed] resolve error for %s: %s' % (url[:60], e), xbmc.LOGWARNING)

    return ''
