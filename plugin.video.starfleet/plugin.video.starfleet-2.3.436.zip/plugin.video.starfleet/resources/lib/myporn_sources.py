# -*- coding: utf-8 -*-
"""
resources/lib/myporn_sources.py

myporn.club adult source — same role as torrent_sources.search_xxxclub():
one more parallel candidate feed into the existing Adult play/search
pipeline (adult_ade_play_direct/adult_ade_play in afdb_router.py), not a
separate browsable section.

Site structure (confirmed live, not guessed): despite the "torrent"
framing (info-hash + magnet link on every post), most posts have 0
seeders/leechers — the magnet is frequently dead. The actual working
delivery mechanism for the overwhelming majority of posts is a
third-party embed/hoster URL (lulustream.com, vidara.so, luluvid.com,
playmogo.com, doodstream.com, etc.) the uploader pastes directly into the
post's own title/description text — which is confirmed present in the
raw server-rendered HTML (no JS execution needed), inside the anchor's
title="..." attribute on both listing and search-result pages:

    <a href='/t/<id>' class='tdn' title='<full description with links>'>

So both browse and search read straight off that one attribute — no
separate detail-page fetch needed, matching xxxclub's single-request
browse/search shape.
"""

import re
import html as _html
import urllib.request as _ureq
import urllib.parse as _uparse
import gzip as _gz
import xbmc

try:
    from resources.lib.title_utils import clean_adult_title as _clean_adult_title
except Exception:
    def _clean_adult_title(t):
        return t

try:
    from resources.lib import cache as _cache
    _HAS_CACHE = True
except Exception:
    _HAS_CACHE = False

MPC_BASE = 'https://myporn.club'

_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
}

# Matches each post row on both /ts (browse) and /s/<query> (search/tag) pages —
# the id + the raw title/description text (which carries the embedded hoster
# links) live in one anchor's href/title attributes. Confirmed live: /ts's
# links are plain '/t/<id>', but /s/<query>'s own links carry an extra
# '?sk=...&sp=...&ss=...' query-string suffix after the id before the
# closing quote — the id-only pattern matched /ts fine (40/40) but matched
# ZERO posts on every /s/<query> search page, since search is the only
# thing search_myporn_club() actually calls. [^']* tolerates any suffix
# (or none) between the id and the closing quote instead of assuming
# browse's plain shape everywhere.
_POST_RE = re.compile(r"<a href='/t/([A-Za-z0-9]+)[^']*' class='tdn' title='([^']*)'")

# Only match http(s) links to a real external host — excludes myporn.club's
# own '/t/', '/u/', '/s/' relative links, which never appear as bare http(s)
# URLs inside the title text anyway (those are always the site's own <a href>
# attributes, not text the uploader typed). The title attribute embeds
# multi-scene posts as "...url1\r\nSCENE 2 -> url2..." with LITERAL
# backslash-r-backslash-n two-character sequences, not real whitespace
# bytes — confirmed live these got glued onto the end of the URL since
# \S alone doesn't stop at a literal backslash. Path chars explicitly
# exclude backslash/quotes/whitespace instead of relying on \S.
_URL_RE = re.compile(r'https?://[a-zA-Z0-9][a-zA-Z0-9.\-]*\.[a-z]{2,}(?:/[^\s\\\'"<>]*)?', re.IGNORECASE)

_BROWSE_TTL = 1800  # 30 min — this is a fast-moving "latest uploads" feed


def _fetch_html(url):
    req = _ureq.Request(url)
    for k, v in _HEADERS.items():
        req.add_header(k, v)
    with _ureq.urlopen(req, timeout=12) as resp:
        raw = resp.read()
        if resp.headers.get('Content-Encoding') == 'gzip':
            raw = _gz.decompress(raw)
    return raw.decode('utf-8', errors='replace')


def _clean_title_text(raw):
    """The title attribute is 'Human Title #tag1 #tag2 ... FULL HD -> <url>
    [more scenes...]' — keep just the human-readable portion before the
    hashtag/link noise starts."""
    t = _html.unescape(raw)
    t = re.split(r'\s+#|\s*->|\s*https?://', t, 1)[0]
    return re.sub(r'\s+', ' ', t).strip()


def _parse_posts(html_text):
    out = []
    for post_id, raw_title in _POST_RE.findall(html_text):
        desc = _html.unescape(raw_title)
        urls = _URL_RE.findall(desc)
        if not urls:
            continue
        out.append({
            'id': post_id,
            'title': _clean_title_text(raw_title),
            'urls': urls,
        })
    return out


def browse_myporn_club(page=1, limit=30):
    """Latest uploads, newest first. page=1 is /ts, page>=2 is /ts/<page>."""
    page = int(page or 1)
    ck = 'mpc_browse_%d' % page
    if _HAS_CACHE:
        cached = _cache.get(ck)
        if cached is not None:
            return cached
    url = '%s/ts' % MPC_BASE if page <= 1 else '%s/ts/%d' % (MPC_BASE, page)
    try:
        html_text = _fetch_html(url)
        posts = _parse_posts(html_text)[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/MyPornClub] browse page=%d error: %s' % (page, e), xbmc.LOGWARNING)
        posts = []
    if _HAS_CACHE and posts:
        _cache.set(ck, posts, _BROWSE_TTL)
    return posts


_STOPWORDS = {'the', 'and', 'with', 'for', 'onlyfans', 'new', 'full', 'hd'}


def search_myporn_club(title, year=None, limit=8, media_type='adult'):
    """Adult stream search — same shape/role as torrent_sources.search_xxxclub():
    returns a flat list of {'label', 'url'} candidates the existing Adult
    play pipeline's stream picker already knows how to show and resolve
    (adult_stream_play() already handles both magnet: URIs and generic
    embed/hoster URLs via embed_resolver/ResolveURL — myporn.club only
    ever contributes the latter here).

    Confirmed live: myporn.club's /s/<query> endpoint only accepts a
    SINGLE word (it's really a tag-browse page, not a real search box —
    a multi-word query 404s outright). So this picks the single most
    distinctive word from the title (longest, stopwords excluded) to
    actually query with, then filters the results client-side requiring
    most of the OTHER query words to also appear in the result's own
    title — since the site itself won't narrow a multi-word title down
    any further than that one word.
    """
    if media_type != 'adult':
        return []
    query = _clean_adult_title(title) or title
    words = [w for w in re.findall(r'[a-zA-Z0-9]+', query.lower()) if w not in _STOPWORDS and len(w) > 2]
    if not words:
        return []
    primary = max(words, key=len)

    try:
        url = '%s/s/%s' % (MPC_BASE, _uparse.quote(primary))
        html_text = _fetch_html(url)
        posts = _parse_posts(html_text)
    except Exception as e:
        xbmc.log('[Starfleet/MyPornClub] search "%s" (word=%s) error: %s' % (query, primary, e), xbmc.LOGWARNING)
        return []

    other_words = set(words) - {primary}
    results = []
    for post in posts:
        t_words = set(re.findall(r'[a-z0-9]+', post['title'].lower()))
        # Require at least half of the OTHER query words to also show up —
        # skipped entirely if 'primary' was the only real word in the query.
        if other_words:
            hits = len(other_words & t_words)
            if hits < max(1, len(other_words) // 2):
                continue
        for i, u in enumerate(post['urls'], 1):
            label = '[MyPornClub] %s' % post['title']
            if len(post['urls']) > 1:
                label += ' (Scene %d)' % i
            results.append({'label': label, 'url': u})
            if len(results) >= limit:
                return results
    return results
