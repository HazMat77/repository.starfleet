# -*- coding: utf-8 -*-
"""
resources/lib/geo_spoof_us.py

US geo-bypass for Sinclair Broadcast Group local stations (WCYB, KATV,
WJLA, etc.) and any other US-geo-locked channel in Starfleet. Mirrors
geo_spoof.py's Canadian mechanism exactly (same two-layer header-spoof +
optional TCP proxy approach) with a separate US-ISP IP pool and its own
settings keys, kept as an independent module rather than a shared/
parameterized one so the proven Canadian path can't be affected by this.

Settings keys (settings.xml category "USA Channels"):
  geo_bypass_us_enabled   bool   master switch (default false)
  geo_bypass_us_ip_idx    enum   selects which US ISP IP to use
  geo_bypass_us_proxy     text   e.g. socks5://user:pass@host:port
                                or   http://host:port
"""
import threading
import requests
import xbmc
import xbmcaddon

_ADDON = xbmcaddon.Addon('plugin.video.starfleet')

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)

# US ISP IPs — index order MUST match the settings.xml enum values string
_US_IPS = [
    ('Comcast / Xfinity (national)',  '73.0.0.1'),
    ('AT&T (national)',               '99.0.0.1'),
    ('Verizon Fios (Northeast)',      '71.160.0.1'),
    ('Charter / Spectrum (national)', '76.0.0.1'),
    ('Cox Communications (South/SW)', '68.1.0.1'),
]

_session      = None
_session_lock = threading.Lock()


# ── Public helpers ────────────────────────────────────────────────────────────

def is_enabled():
    """Return True when the US geo-bypass master switch is on in settings."""
    return _ADDON.getSetting('geo_bypass_us_enabled') == 'true'


def us_ip():
    """Return the selected US ISP IP string."""
    try:
        idx = int(_ADDON.getSetting('geo_bypass_us_ip_idx') or '0')
        return _US_IPS[min(idx, len(_US_IPS) - 1)][1]
    except Exception:
        return _US_IPS[0][1]


def geo_headers(ip=None):
    """Return dict of all US IP spoofing headers."""
    ip = ip or us_ip()
    return {
        'X-Forwarded-For':  ip,
        'X-Real-IP':        ip,
        'CF-Connecting-IP': ip,
        'True-Client-IP':   ip,
        'X-Originating-IP': ip,
    }


def session():
    """
    Return the shared US geo-bypass requests.Session.
    Thread-safe, lazily built, process-lifetime cache.
    Call invalidate() after the user changes settings.
    """
    global _session
    if _session is None:
        with _session_lock:
            if _session is None:
                _session = _build_session()
    return _session


def invalidate():
    """Force a fresh session on next call (e.g. after settings change)."""
    global _session
    with _session_lock:
        _session = None


def decorate_url(url):
    """
    Append US IP headers to a stream URL using Kodi's | notation:
      https://cdn.example.com/live.m3u8|X-Forwarded-For=73.0.0.1&...

    Returns url unchanged when geo-bypass is disabled or url is empty.
    """
    if not is_enabled() or not url:
        return url
    ip  = us_ip()
    sep = '&' if '|' in url else '|'
    return (
        '%s%sX-Forwarded-For=%s&True-Client-IP=%s&User-Agent=%s'
        % (url, sep, ip, ip, requests.utils.quote(_UA))
    )


def stream_headers_str():
    """
    Return a header string suitable for
    li.setProperty('inputstream.adaptive.stream_headers', ...).
    Empty string when geo-bypass is disabled.
    """
    if not is_enabled():
        return ''
    ip = us_ip()
    return 'X-Forwarded-For=%s&True-Client-IP=%s&User-Agent=%s' % (
        ip, ip, requests.utils.quote(_UA)
    )


# ── Internal ──────────────────────────────────────────────────────────────────

def _build_session():
    s = requests.Session()
    s.headers.update({
        'User-Agent':      _UA,
        'Accept':          'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
    })
    ip = us_ip()
    s.headers.update(geo_headers(ip))
    xbmc.log('[GeoBypassUS] Session built — US IP: %s' % ip, xbmc.LOGINFO)

    proxy = (_ADDON.getSetting('geo_bypass_us_proxy') or '').strip()
    if proxy:
        s.proxies = {'http': proxy, 'https': proxy}
        log_p = proxy.split('@')[-1] if '@' in proxy else proxy
        xbmc.log('[GeoBypassUS] Proxy tunnel: %s' % log_p, xbmc.LOGINFO)

    adapter = requests.adapters.HTTPAdapter(
        pool_connections=4, pool_maxsize=10,
        max_retries=requests.adapters.Retry(total=2, backoff_factor=0.3),
    )
    s.mount('https://', adapter)
    s.mount('http://',  adapter)
    return s
