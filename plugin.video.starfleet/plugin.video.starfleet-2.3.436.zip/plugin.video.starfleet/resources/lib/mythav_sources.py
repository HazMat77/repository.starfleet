# -*- coding: utf-8 -*-
"""
resources/lib/mythav_sources.py — fourth JAV source (mythav.org), same
three-function shape as javseen_sources.py/javhd_sources.py/javleak_sources.py
so home.py's _JAV_SOURCES dict and _render_jav_category stay source-agnostic.

Confirmed live (plain requests.get(), no Cloudflare wall, no JS needed):
  - /update/ (and /update/page/<n>/) is a flat, paginated "every new upload
    across every site this aggregator carries" feed — no sitemap needed.
    Each item's <a href> already carries everything needed in one string:
    https://mythav.org/video/<numeric_id>/code-<jav-code>/<title-slug>
  - Detail pages embed a single <iframe src="https://mythav.org/player/
    r.php?r=<base64>">, where the base64 decodes to a real upload18.org
    play-page URL (e.g. https://upload18.org/play/index/<jav-code>).
  - That upload18.org page embeds a plain (non-obfuscated) JS object,
    window.PLAYER_CONFIG, whose "m3u8" field is a fully-signed, directly
    playable helvid.com HLS URL — confirmed live against 5 separate titles,
    every one resolved to a real #EXTM3U playlist with genuine segment URLs.
    No third-party resolvers.py hand-off needed at all here (unlike
    javseen/javhd/javleak, which hand embed-host URLs to resolvers.py) —
    this site's own chain already ends in a directly playable stream.
  - Checked and rejected as unreliable: javgiga.com. Its detail pages route
    through a WordPress "Video Server Fields" plugin that lazy-loads the
    real iframe via a POST to /wp-admin/admin-ajax.php (action=
    get_video_url_ajax) — but that specific endpoint sits behind a genuine
    Cloudflare challenge (confirmed live: even this addon's own vendored
    cloudscraper couldn't get past it), and only 1 of 7 sampled detail
    pages had a static, non-AJAX iframe instead. Not shippable as a
    reliable source.
"""
import re
import base64
import json
import urllib.parse
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

MYTHAV_BASE = 'https://mythav.org'

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
    'Accept-Language': 'en-US,en;q=0.9',
}

PAGE_SIZE = 20  # matches the site's own /update/ page size
_LATEST_CACHE_TTL = 15 * 60  # "latest uploads" feed changes often, unlike a static sitemap

_RE_LATEST_ITEM = re.compile(
    r'<a href="https://mythav\.org/video/(\d+)/(code-[^/]+/[^"]+)"[^>]*title="(\[[^\]]+\][^"]*)"',
    re.IGNORECASE
)
_RE_THUMB       = re.compile(r'data-src="(https://mythav\.org/i\.php\?i=[^"]+)"', re.IGNORECASE)
_RE_PLAYER_IFRAME = re.compile(r'<iframe[^>]+src="https://mythav\.org/player/r\.php\?r=([^"&]+)"', re.IGNORECASE)
_RE_OG_IMAGE    = re.compile(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', re.IGNORECASE)
_RE_PLAYER_M3U8 = re.compile(r'"m3u8":"([^"]+)"')


def _get(url, referer='', method='get', timeout=15):
    import requests
    headers = dict(_HEADERS)
    if referer:
        headers['Referer'] = referer
    try:
        r = requests.get(url, headers=headers, timeout=timeout)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Mythav] fetch error %s: %s' % (url[:80], e), xbmc.LOGWARNING)
    return ''


def _title_from_html(raw_title):
    import html as _html_lib
    return _html_lib.unescape(raw_title).strip()


def _detail_url(vid, slug):
    return '%s/video/%s/%s' % (MYTHAV_BASE, vid, slug)


# ── "New / Latest" browsing (flat paginated feed, no JS needed) ─────────────

def _page_url(page):
    if page <= 1:
        return '%s/update/' % MYTHAV_BASE
    return '%s/update/page/%d/' % (MYTHAV_BASE, page)


def browse_mythav_latest(page=1):
    ck = 'mythav_latest_p%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []

    html = _get(_page_url(page))
    items = []
    if html:
        thumbs = _RE_THUMB.findall(html)
        for i, m in enumerate(_RE_LATEST_ITEM.finditer(html)):
            vid, slug, raw_title = m.groups()
            thumb = thumbs[i] if i < len(thumbs) else ''
            items.append({
                'id': vid,
                'slug': slug,
                'title': _title_from_html(raw_title),
                'source': 'mythav',
                # CategoryListWindow's onInit() only ever reads an item's
                # 'thumb' key for the actual list icon -- 'poster' alone
                # (what this used to set) is never looked at there, so the
                # grid itself showed blank icons for every item despite
                # this site actually having real thumbnails available
                # up front, unlike javseen/javhd/javleak's sitemaps.
                'thumb':  thumb,
                'poster': thumb,
            })
    _cache.set(ck, items or False, _LATEST_CACHE_TTL)
    xbmc.log('[Starfleet/Mythav] page %d: %d items' % (page, len(items)), xbmc.LOGINFO)
    return items


def get_mythav_detail(vid, slug):
    """Lazily fetch a video's real (larger) cover image from its detail
    page — called on-demand, not for every item up front. There's no real
    per-title synopsis on this site (its own meta name="description" is
    just generic site boilerplate, confirmed live), so this only upgrades
    the listing-time thumbnail (cover-t.jpg) to the detail page's own
    og:image (cover-n.jpg, a larger variant of the same cover)."""
    html = _get(_detail_url(vid, slug))
    if not html:
        return {}
    out = {}
    m = _RE_OG_IMAGE.search(html)
    if m:
        out['poster'] = m.group(1)
        out['backdrop'] = m.group(1)
    return out


# ── Play-time resolution ─────────────────────────────────────────────────────

def _decode_player_redirect(html):
    """<iframe src=".../player/r.php?r=<base64>"> -> the base64 decodes to
    a plain upload18.org play-page URL (e.g. https://upload18.org/play/
    index/<jav-code>?ref=mythav.org)."""
    m = _RE_PLAYER_IFRAME.search(html)
    if not m:
        return ''
    b64 = m.group(1)
    try:
        pad = '=' * (-len(b64) % 4)
        return base64.b64decode(b64 + pad).decode('utf-8', 'ignore')
    except Exception:
        return ''


def resolve_mythav_stream(vid, slug):
    """detail page -> decoded upload18.org play page -> its own
    window.PLAYER_CONFIG.m3u8 field -> a fully-signed, directly playable
    helvid.com HLS URL. No resolvers.py hand-off needed — this chain
    already ends in a real stream, confirmed live against 5 titles.

    Returns a Kodi pipe-tagged 'url|Referer=...&User-Agent=...' string, NOT
    a bare URL — confirmed live 2026-08-03 that helvid.com 403s a bare
    fetch with no Referer (or one from mythav.org itself) and only accepts
    one from the upload18.org play page that issued the signed URL. This
    addon's own resolution request always sends that Referer, but Kodi's
    native player only inherits headers baked into the returned path this
    way (same convention as router.py's _hls_item/geo_spoof.decorate_url),
    so returning the bare m3u8 previously meant Kodi's own fetch always got
    403'd even though this function's own resolution succeeded."""
    detail_url = _detail_url(vid, slug)
    html = _get(detail_url)
    if not html:
        return ''

    player_url = _decode_player_redirect(html)
    if not player_url:
        xbmc.log('[Starfleet/Mythav] no player redirect found for %s' % slug, xbmc.LOGWARNING)
        return ''

    player_html = _get(player_url, referer=MYTHAV_BASE + '/')
    if not player_html:
        return ''

    m = _RE_PLAYER_M3U8.search(player_html)
    if not m:
        xbmc.log('[Starfleet/Mythav] no m3u8 in PLAYER_CONFIG for %s' % slug, xbmc.LOGWARNING)
        return ''

    try:
        m3u8 = json.loads('"' + m.group(1) + '"')
    except Exception:
        return ''

    return '%s|Referer=%s&User-Agent=%s' % (
        m3u8,
        urllib.parse.quote(player_url, safe=''),
        urllib.parse.quote(_HEADERS['User-Agent'], safe=''),
    )
