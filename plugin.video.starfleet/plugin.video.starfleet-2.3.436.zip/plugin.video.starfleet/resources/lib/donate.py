# -*- coding: utf-8 -*-
"""
resources/lib/donate.py

"Buy me a coffee" — Settings > Buy Me a Coffee shows one button per coin;
each opens a QR code for MY OWN deposit address (screenshots the user
supplied directly), with an optional amount the donor types in first so
their wallet app can pre-fill it on scan. No pairing, no account, no
obligation — this is a one-way display of a fixed address, not a live
payment flow.

Addresses below are the user's own Kraken deposit addresses (BTC/ETH/DOGE/
BCH/LTC/XRP), confirmed directly from their own account screenshots.
LINK was deliberately left out: it's an ERC-20 token, not native ETH, even
though it shares ETH's deposit address — a correct amount-prefilled URI
for it needs the token's own CONTRACT address and transfer encoding, not
the recipient's address in the same slot as a native-coin transfer, and
building that without directly confirming the contract address would
risk a malformed URI silently pointing at the wrong place.

URI schemes:
- BTC/DOGE/BCH/LTC all use the well-established BIP21 form
  ("<scheme>:<address>?amount=<coin-amount>") — supported broadly by
  wallets for exactly this pre-fill purpose.
- ETH uses EIP-681 ("ethereum:<address>?value=<wei>") — value must be an
  integer in wei, so the typed decimal ETH amount is converted with
  Decimal (not float) to avoid rounding drift on the multiply-by-1e18.
- XRP uses "ripple:<address>?amount=<amount>&dt=<tag>" as a best-effort
  pre-fill, but the destination tag is ALWAYS also shown as its own large,
  high-contrast line regardless of whether a wallet honors the URI query
  string — Kraken requires this exact tag on every XRP deposit to this
  address, and a wallet that ignores query params but drops the tag would
  otherwise misdirect the deposit on Kraken's end.
"""
from collections import OrderedDict
from decimal import Decimal, InvalidOperation

COINS = OrderedDict([
    ('btc', {
        'label': 'Bitcoin (BTC)',
        'address': '39QUadqeDaqWtXLtaKhS3MshEy5FFEC9HB',
        'scheme': 'bitcoin',
    }),
    ('eth', {
        'label': 'Ethereum (ETH)',
        'address': '0xa815d6D81A60497f03d003b1A759013d03fA3244',
        'scheme': 'ethereum',
    }),
    ('doge', {
        'label': 'Dogecoin (DOGE)',
        'address': 'DHBZzHG2TtjDhhHYVqfbpDCRZ1DBVEFw3M',
        'scheme': 'dogecoin',
    }),
    ('bch', {
        'label': 'Bitcoin Cash (BCH)',
        'address': 'pzm4pn7n0mxfknkwdvqrkggfkdqz6kz2hys96sjgw3',
        'scheme': 'bitcoincash',
    }),
    ('ltc', {
        'label': 'Litecoin (LTC)',
        'address': 'LLHMbHT7qJpua9cPtT8prLvbKX27Nib4qE',
        'scheme': 'litecoin',
    }),
    ('xrp', {
        'label': 'XRP (Ripple)',
        'address': 'rLHzPsX6oXkzU2qL12kHCH8G8cnZv1rBJh',
        'scheme': 'ripple',
        'tag': '652792457',
    }),
])


def build_uri(coin_key, amount_str=''):
    """Returns (uri_for_qr, note) — `note` is an extra line worth always
    showing the donor regardless of whether the URI pre-fill works (e.g.
    XRP's destination tag). Falls back to the plain address as the QR
    payload if no amount was given."""
    coin = COINS.get(coin_key)
    if not coin:
        return '', ''

    address = coin['address']
    scheme = coin['scheme']
    amount_str = (amount_str or '').strip()
    note = ''

    if coin_key == 'xrp':
        note = 'Destination tag (REQUIRED): %s' % coin['tag']
        if amount_str:
            try:
                Decimal(amount_str)
                return ('ripple:%s?amount=%s&dt=%s' % (address, amount_str, coin['tag']), note)
            except InvalidOperation:
                pass
        return ('ripple:%s?dt=%s' % (address, coin['tag']), note)

    if not amount_str:
        return '%s:%s' % (scheme, address), note

    try:
        amount = Decimal(amount_str)
    except InvalidOperation:
        return '%s:%s' % (scheme, address), note

    if coin_key == 'eth':
        wei = int(amount * (Decimal(10) ** 18))
        return ('ethereum:%s?value=%d' % (address, wei), note)

    # BTC / DOGE / BCH / LTC — BIP21-style plain decimal amount.
    return ('%s:%s?amount=%s' % (scheme, address, amount_str), note)


def show_donate_dialog(coin_key):
    """Settings > Buy Me a Coffee button handler for one coin: prompts for
    an optional amount via Kodi's native keyboard (same choice as the rest
    of this addon's search entry points — see home.py's _open_movies_search
    docstring for why the native xbmc.Keyboard is used over a custom-built
    on-screen one), builds the pre-fill URI, generates a QR, and shows it."""
    import xbmc
    import xbmcgui

    coin = COINS.get(coin_key)
    if not coin:
        return

    amount_str = ''
    try:
        kb = xbmc.Keyboard('', 'Amount in %s (optional — leave blank for address only)' % coin_key.upper())
        kb.doModal()
        if kb.isConfirmed():
            amount_str = kb.getText().strip()
    except Exception:
        pass

    uri, note = build_uri(coin_key, amount_str)

    from resources.lib.gui import qr_dialog
    qr_path = qr_dialog.make_qr(uri, 'starfleet_donate_%s_qr.png' % coin_key)
    if not qr_path:
        xbmcgui.Dialog().textviewer(coin['label'], '%s\n\n%s' % (coin['address'], note))
        return

    from resources.lib.gui.donate_dialog import DonateDialog
    dlg = DonateDialog(qr_path, coin['label'], coin['address'], note)
    dlg.doModal()
    del dlg
