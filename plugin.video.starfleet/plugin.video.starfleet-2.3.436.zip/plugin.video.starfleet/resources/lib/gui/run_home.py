"""
Starfleet Home GUI launcher.
Opens the home window immediately with cached data, then refreshes in the background.
"""
import sys
import os
import json
import threading
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon


def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)

    # dispatcher.run() calls cache.clear_if_updated() at the top of every
    # native plugin:// action, but this Home window is a SEPARATE entry
    # point (launched directly via RunScript, not through dispatcher) and
    # is normally the very first thing that runs after an update — so the
    # stale-cache-surviving-a-version-bump bug (clear_if_updated's own
    # docstring) kept happening even after that fix shipped, because this
    # path never called it. Must happen before the background refresh
    # thread below starts populating the cache under the new version.
    try:
        from resources.lib import cache as _cache
        _cache.clear_if_updated()
    except Exception as _e:
        xbmc.log('[Starfleet/Home] clear_if_updated error: %s' % _e, xbmc.LOGWARNING)

    data_dir  = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(data_dir, exist_ok=True)
    data_file    = os.path.join(data_dir, 'home_data.json')
    version_file = os.path.join(data_dir, 'last_version.txt')
    current_ver  = addon.getAddonInfo('version')

    # Prevent multiple home windows from opening simultaneously.
    # run_home.py is called via RunScript (separate Python process per call), so we
    # use an atomic file lock: O_CREAT|O_EXCL succeeds for exactly one process.
    import time as _time
    window_lock = os.path.join(data_dir, 'window.lock')
    _got_lock = False
    try:
        fd = os.open(window_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
        _got_lock = True
    except FileExistsError:
        try:
            age = _time.time() - os.path.getmtime(window_lock)
            if age < 30:
                xbmc.log('[Starfleet/Home] window already open, skipping', xbmc.LOGINFO)
                return
            # Stale lock — steal it
            os.remove(window_lock)
            fd = os.open(window_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            _got_lock = True
        except Exception:
            xbmc.log('[Starfleet/Home] window already open, skipping', xbmc.LOGINFO)
            return
    except Exception:
        _got_lock = True  # can't create lock — proceed anyway

    empty    = [[], [], [], []]
    contexts = {'default': empty, 'movies': empty, 'tv': empty,
                'sports': empty, 'live': empty, 'adult': empty,
                'trakt_anticipated': empty, 'radio': empty}

    # Check whether this is a first run / update
    try:
        with open(version_file, 'r') as _f:
            saved_ver = _f.read().strip()
    except Exception:
        saved_ver = ''
    is_new_version = (saved_ver != current_ver)

    # Only one instance should run the heavy refresh at a time.
    # Kodi widget loading can invoke run_home.py 2-3 times simultaneously on startup;
    # on low-RAM devices (FireStick) multiple parallel TMDB+ADE fetches cause freezes.
    lock_file = os.path.join(data_dir, 'refresh.lock')
    refresh_done   = threading.Event()
    refresh_result = [None]

    def _acquire_lock():
        """Return True if this instance gets the refresh lock."""
        try:
            import time as _time
            # Stale lock older than 90s is safe to take over
            if os.path.exists(lock_file):
                age = _time.time() - os.path.getmtime(lock_file)
                if age < 90:
                    return False
            with open(lock_file, 'w') as _lf:
                _lf.write(str(os.getpid()))
            return True
        except Exception:
            return True  # if lock fails, proceed anyway

    def _release_lock():
        try:
            os.remove(lock_file)
        except Exception:
            pass

    got_lock = _acquire_lock()

    def _refresh():
        try:
            from resources.lib import afdb_router as _ar
            _ctx = _ar.get_home_carousel_data()
            refresh_result[0] = _ctx
            _tmp = data_file + '.tmp'
            with open(_tmp, 'w', encoding='utf-8') as _f:
                json.dump(_ctx, _f)
            os.replace(_tmp, data_file)
            _d = _ctx.get('default', empty)
            xbmc.log('[Starfleet/Home] background refresh done: %d/%d/%d/%d' % (
                len(_d[0]), len(_d[1]), len(_d[2]), len(_d[3]) if len(_d) > 3 else 0), xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log('[Starfleet/Home] background refresh error: %s' % _e, xbmc.LOGWARNING)
        finally:
            _release_lock()
            refresh_done.set()

    if got_lock:
        t = threading.Thread(target=_refresh, daemon=True)
        t.start()
    else:
        # Another instance is refreshing — just signal done so splash/window don't wait
        xbmc.log('[Starfleet/Home] refresh lock held by another instance, skipping', xbmc.LOGINFO)
        refresh_done.set()

    if is_new_version:
        # On first run / update, write version immediately and open home with
        # whatever cache exists (or empty). Background refresh pushes data when ready.
        try:
            with open(version_file, 'w') as _f:
                _f.write(current_ver)
        except Exception:
            pass

    if True:  # shared cache-load block for both new and existing versions
        # Normal launch — load from cache instantly so the window is non-empty
        try:
            with open(data_file, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            if isinstance(raw, list):
                contexts['default'] = raw
                contexts['movies']  = raw
                contexts['tv']      = raw
            else:
                for k, v in raw.items():
                    contexts[k] = v
            d = contexts.get('default', empty)
            xbmc.log('[Starfleet/Home] loaded %d/%d/%d/%d films from cache' % (
                len(d[0]), len(d[1]), len(d[2]), len(d[3]) if len(d) > 3 else 0), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Home] no cache yet (%s)' % e, xbmc.LOGINFO)

        # If cache is empty, wait for the background refresh to finish before
        # opening the window — otherwise the home screen shows empty carousels.
        d = contexts.get('default', empty)
        if not any(row for row in d if row):
            xbmc.log('[Starfleet/Home] cache empty — waiting for background refresh', xbmc.LOGINFO)
            refresh_done.wait(timeout=45)
            if refresh_result[0] is not None:
                contexts = refresh_result[0]

    # If refresh finished during the splash, use the fresh data right away
    if refresh_result[0] is not None:
        contexts = refresh_result[0]

    try:
        from resources.lib.gui.home import HomeWindow
        _window_closed = threading.Event()
        win = HomeWindow('Starfleet-Home.xml', addon_path, 'Default', '1080i',
                         contexts=contexts, close_event=_window_closed)

        # If refresh is still running, push data into window when it finishes.
        def _push_when_ready():
            for _ in range(120):
                if _window_closed.is_set():
                    return
                if refresh_done.wait(timeout=1):
                    break
            if _window_closed.is_set():
                return
            if refresh_result[0] is not None:
                try:
                    # Re-check right before touching the window — a nav click
                    # can land in the gap between the check above and here
                    # (confirmed live: getControl() on an already-closing
                    # window threw "Non-Existent Control 100" in exactly
                    # this spot). Narrows the race further; home.py's _nav()
                    # also now sets this event as its very first action to
                    # shrink the window from the other side too.
                    if _window_closed.is_set():
                        return
                    win._contexts = refresh_result[0]
                    win._apply_context(win._current_ctx)
                    xbmc.log('[Starfleet/Home] pushed fresh data to live window', xbmc.LOGINFO)
                except Exception as _pe:
                    xbmc.log('[Starfleet/Home] push error: %s' % _pe, xbmc.LOGWARNING)
            if _window_closed.is_set():
                return
            try:
                win.setProperty('sf_loaded', '1')
            except Exception:
                pass

        if not refresh_done.is_set():
            threading.Thread(target=_push_when_ready, daemon=True).start()
        else:
            try:
                win.setProperty('sf_loaded', '1')
            except Exception:
                pass

        # Use show() instead of doModal() so the window is NOT a modal dialog.
        # doModal() sets Kodi's modal flag which causes ActivateWindow to be
        # refused with "active modal dialogs".  show() puts the window on the
        # stack as a normal full-screen window — ActivateWindow works, and
        # pressing Back from any section returns here automatically.
        win.show()

        # Verify it actually landed. Confirmed live: show() can silently not
        # bring the window to the front, leaving Kodi's own native empty
        # "Videos" listing on screen indefinitely (the addon's plugin call
        # always returns 0 items — the real UI is meant to be this window
        # taking over right after) — with this whole script alive and
        # otherwise working the entire time (background refresh, cache load,
        # the later push-into-window logic all ran normally), the user was
        # just stuck staring at an empty folder with no way in. Window 10025
        # is WINDOW_VIDEO_NAV, the native window Kodi opens automatically
        # before this script ever runs — if we're still looking at it after
        # show(), retry once, and if a lingering dialog is the culprit (the
        # same class of interference already documented for ActivateWindow
        # elsewhere in this addon), force-close it before the final attempt.
        xbmc.sleep(300)
        if xbmcgui.getCurrentWindowId() == 10025:
            xbmc.log('[Starfleet/Home] show() did not land — retrying once', xbmc.LOGWARNING)
            win.show()
            xbmc.sleep(300)
            if xbmcgui.getCurrentWindowId() == 10025:
                xbmc.log('[Starfleet/Home] show() failed twice — closing any lingering '
                         'dialog and forcing one more attempt', xbmc.LOGERROR)
                try:
                    xbmc.executebuiltin('Dialog.Close(all,true)')
                    xbmc.sleep(200)
                    win.show()
                except Exception:
                    pass

        # Keep the script alive while the window is visible.  _window_closed is
        # set by onAction() when the user presses Back/Escape on the home screen.
        _monitor = xbmc.Monitor()
        while not _window_closed.is_set():
            if _monitor.waitForAbort(0.5):
                break

        win.close()
        _window_closed.set()   # ensure _push_when_ready exits
        try:
            os.remove(window_lock)
        except Exception:
            pass
    except Exception as e:
        try:
            os.remove(window_lock)
        except Exception:
            pass
        xbmc.log('[Starfleet/Home] window error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
