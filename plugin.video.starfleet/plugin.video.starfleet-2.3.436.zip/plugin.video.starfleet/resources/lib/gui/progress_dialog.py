# -*- coding: utf-8 -*-
"""
resources/lib/gui/progress_dialog.py

Starfleet Progress Dialog — themed drop-in replacement for
xbmcgui.DialogProgress(), matching the rest of the addon's own
navy/orange skin instead of whatever the user's active system skin
looks like.

Native xbmcgui.DialogProgress() is rendered by whatever skin the user has
selected as their SYSTEM skin (Estuary by default) — it's dispatched by
window ID through Kodi's own core engine, which never looks inside our
addon's bundled resources/skins folder at all. That folder only gets used
for windows OUR OWN Python code explicitly loads by path (see
select_dialog.py for the same situation with Dialog().select()), so the
only way to brand this dialog is to stop calling the native one and use
our own WindowXMLDialog instead. See Starfleet-Progress.xml's own header
comment for the full explanation and the exact Estuary layout this mirrors.

Same usage contract as xbmcgui.DialogProgress(): .create(heading, message),
.update(percent, message=None), .iscanceled(), .close() — call sites just
need their constructor swapped, nothing else about how they use it changes.

Uses .show() (non-blocking) rather than .doModal() — real DialogProgress
usage is create() -> do work on the SAME thread, calling update() along
the way -> close(), so the window has to display without blocking that
thread the way a modal dialog would.

IMPORTANT — Cancel is NOT reliable on this themed dialog. Confirmed live,
twice, with two different implementations (show() on the caller's thread,
then doModal() on an internal background thread): update() calls clearly
reach the window every time, but clicking Cancel can fail to route to
onClick/onAction at all - a real NZB download was once "cancelled" and
kept running successfully for 16+ minutes anyway. Root cause not fully
understood; not worth a third guess right now. Given this dialog is used
in ~40 places across the addon (mostly short "loading..." spinners in
home.py/router.py/afdb_router.py where Cancel is a nicety, not essential,
and switching ALL of them to Kodi's native dialog was confirmed live to
make every one of them noticeably slower — native DialogProgress means a
real skin context-switch to the user's system skin (Estuary) and back
every time it's shown, paid on every single one of those ~40 call sites,
not just the two that actually need working Cancel), the fix is scoped:
this custom dialog stays the default everywhere, and get_native() below
is a SEPARATE, explicit opt-in for the couple of call sites (NZB
resolution, slow magnet resolution in resolvers.py) where a real,
multi-minute background wait makes a working Cancel button worth losing
the theming and paying the skin-switch cost for just that one dialog.
"""
import xbmc
import xbmcgui
import xbmcaddon

_ID_HEADER   = 410
_ID_MESSAGE  = 9
_ID_PROGRESS = 20
_ID_CANCEL   = 450


class StarfleetProgressDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self._canceled = False
        self._heading = ''
        self._message = ''
        super(StarfleetProgressDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            self.getControl(_ID_HEADER).setLabel(self._heading)
            self.getControl(_ID_MESSAGE).setText(self._message)
            self.getControl(_ID_PROGRESS).setPercent(0)
        except Exception as e:
            xbmc.log('[Starfleet/ProgressDialog] onInit: %s' % e, xbmc.LOGERROR)

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self._canceled = True

    def onClick(self, cid):
        if cid == _ID_CANCEL:
            self._canceled = True

    # ---- xbmcgui.DialogProgress-compatible API ----

    def create(self, heading, message=''):
        self._heading = heading
        self._message = message
        self.show()
        # onInit() already sets these from self._heading/_message, but a
        # caller may reuse one instance across multiple create() calls —
        # setting again here covers that case too.
        try:
            self.getControl(_ID_HEADER).setLabel(heading)
            self.getControl(_ID_MESSAGE).setText(message)
            self.getControl(_ID_PROGRESS).setPercent(0)
        except Exception:
            pass

    def update(self, percent, message=None):
        try:
            self.getControl(_ID_PROGRESS).setPercent(percent)
            if message is not None:
                self.getControl(_ID_MESSAGE).setText(message)
        except Exception as e:
            xbmc.log('[Starfleet/ProgressDialog] update: %s' % e, xbmc.LOGWARNING)

    def iscanceled(self):
        return self._canceled

    def close(self):
        try:
            super(StarfleetProgressDialog, self).close()
        except Exception as e:
            xbmc.log('[Starfleet/ProgressDialog] close: %s' % e, xbmc.LOGWARNING)


class DialogProgress(object):
    """Drop-in for xbmcgui.DialogProgress() — `dlg = DialogProgress()`
    works exactly like `dlg = xbmcgui.DialogProgress()` did. Falls back to
    the native dialog if anything about the themed one fails, so a skin
    bug never turns a progress-driven flow into a silent hang — same
    safety-net convention select_dialog.py already established.

    Cancel is not reliable on the themed path here (see module docstring)
    — callers where a real background wait needs a working Cancel button
    should use get_native() instead, not this."""

    def __new__(cls):
        try:
            return StarfleetProgressDialog(
                'Starfleet-Progress.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
            )
        except Exception as e:
            xbmc.log('[Starfleet/ProgressDialog] falling back to native: %s' % e, xbmc.LOGWARNING)
            return xbmcgui.DialogProgress()


def get_native():
    """Kodi's own native progress dialog, unthemed. Use only where Cancel
    actually has to work during a genuine multi-minute background wait
    (NZB resolution, slow magnet resolution) — see module docstring for
    why this isn't just the default everywhere."""
    return xbmcgui.DialogProgress()
