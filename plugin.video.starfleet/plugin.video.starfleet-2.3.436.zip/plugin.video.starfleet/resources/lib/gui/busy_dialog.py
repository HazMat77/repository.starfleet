# -*- coding: utf-8 -*-
"""
resources/lib/gui/busy_dialog.py

Starfleet Busy Spinner — themed drop-in replacement for
xbmc.executebuiltin('ActivateWindow(busydialognocancel)') /
('Dialog.Close(busydialognocancel)'), matching the rest of the addon's own
navy/orange skin and the Starfleet icon instead of Kodi's default spinner.

Native busydialognocancel is dispatched by window ID through Kodi's core
engine using whatever the user's ACTIVE SYSTEM skin is — our own bundled
resources/skins folder is invisible to it, same situation as
xbmcgui.DialogProgress() before progress_dialog.py replaced it. So this
is a real WindowXMLDialog of our own (DialogBusy.xml), shown non-blocking
via .show() so the calling code can keep doing work (the actual fetch/
resolve) while it's up, then closed when that work finishes.

Usage (mirrors the old ActivateWindow/Dialog.Close pair exactly):
    from resources.lib.gui import busy_dialog as _busy
    handle_ = _busy.show()
    try:
        ... do the slow work ...
    finally:
        _busy.close(handle_)
"""
import xbmc
import xbmcgui
import xbmcaddon


class _StarfleetBusyDialog(xbmcgui.WindowXMLDialog):
    pass


def show():
    """Show the busy spinner (non-blocking) and return a handle to pass to
    close(). Falls back to the native busy dialog if anything about the
    themed one fails, so a skin bug never leaves the screen without any
    busy indicator at all."""
    try:
        dlg = _StarfleetBusyDialog(
            'DialogBusy.xml',
            xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
            'Default', '1080i',
        )
        dlg.show()
        return dlg
    except Exception as e:
        xbmc.log('[Starfleet/BusyDialog] show: %s' % e, xbmc.LOGWARNING)
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        return None


def close(handle):
    """Close a handle returned by show(). Always also closes the native
    busydialognocancel window — harmless no-op if it was never opened,
    and covers the case show() fell back to it."""
    try:
        if handle is not None:
            handle.close()
    except Exception as e:
        xbmc.log('[Starfleet/BusyDialog] close: %s' % e, xbmc.LOGWARNING)
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
