# -*- coding: utf-8 -*-
"""
resources/lib/gui/select_dialog.py

Starfleet Select Dialog — themed drop-in replacement for
xbmcgui.Dialog().select(title, options), matching the rest of the addon's
own navy/charcoal + translucent-orange skin instead of the native Kodi
skin's default blue-highlight select list.

A real xbmcgui.WindowXMLDialog (not WindowXML like CategoryListWindow) —
genuinely modal at the C++ window-manager level, so it can be opened safely
regardless of what's already on screen underneath, the same reason the
native Dialog().select() was safe to call without closing an outer
CategoryListWindow first.

Same return contract as xbmcgui.Dialog().select(): the chosen index, or -1
on cancel/Back/Esc.
"""
import os
import xbmc
import xbmcgui
import xbmcaddon

_ID_LIST   = 500
_ID_CANCEL = 450

_ASSET_FILES = {
    'sf_asset_focus_row': 'sf_focus_row.png',
    'sf_asset_divider':   'sf_divider.png',
    # Solid-color box fills reference this instead of a bare relative
    # "media/white.png" — confirmed live (same as category_list.py's own
    # note) that relative local media paths silently fail to render in
    # this window type, while an absolute path via a Window Property
    # (exactly like the other two assets here) works.
    'sf_asset_white':     'white.png',
}


class SelectDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self._title   = kwargs.pop('title', '')
        self._options = kwargs.pop('options', [])
        self.result = -1
        super(SelectDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            self.setProperty('sf_select_title', self._title)
            addon_path = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
            media_dir = os.path.join(addon_path, 'resources', 'skins', 'Default', 'media')
            for prop, filename in _ASSET_FILES.items():
                self.setProperty(prop, os.path.join(media_dir, filename))

            ctrl = self.getControl(_ID_LIST)
            ctrl.reset()
            for opt in self._options:
                ctrl.addItem(xbmcgui.ListItem(label=opt))
            # Real, reliably-reachable Cancel: confirmed live that this
            # list never hands focus to the separate Cancel BUTTON via
            # d-pad (Up and Right both do nothing at the list boundary —
            # the list control swallows the key press before the window's
            # onAction() ever sees it, a genuine limitation of this bespoke
            # dialog, not something fixable from onAction()). The button
            # stays for mouse/touch clicks (onClick(_ID_CANCEL) still
            # works), but this extra row is the actual d-pad path — it
            # rides the exact same select-and-press-OK mechanism every
            # other row already uses, which IS confirmed reliable.
            ctrl.addItem(xbmcgui.ListItem(label='[COLOR FFFF8C00]Cancel[/COLOR]'))

            # Same focus-can't-land-on-a-freshly-populated-list issue
            # CategoryListWindow already works around — verify and retry.
            for _ in range(6):
                self.setFocusId(_ID_LIST)
                if self.getFocusId() == _ID_LIST:
                    break
                xbmc.sleep(50)
        except Exception as e:
            xbmc.log('[Starfleet/SelectDialog] onInit: %s' % e, xbmc.LOGERROR)

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                   xbmcgui.ACTION_STOP, xbmcgui.ACTION_PARENT_DIR):
            self.result = -1
            self.close()

    def onClick(self, cid):
        try:
            if cid == _ID_LIST:
                pos = self.getControl(_ID_LIST).getSelectedPosition()
                if pos == len(self._options):
                    # The synthetic Cancel row appended in onInit()
                    self.result = -1
                else:
                    self.result = pos if 0 <= pos < len(self._options) else -1
                self.close()
            elif cid == _ID_CANCEL:
                self.result = -1
                self.close()
        except Exception as e:
            xbmc.log('[Starfleet/SelectDialog] onClick: %s' % e, xbmc.LOGERROR)
            self.result = -1
            self.close()


def select(title, options):
    """Themed replacement for xbmcgui.Dialog().select(title, options).
    Falls back to the native dialog if anything about the custom one fails,
    so a skin bug never turns into a dead-end menu."""
    try:
        dlg = SelectDialog(
            'Starfleet-Select.xml',
            xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
            'Default', '1080i',
            title=title, options=options,
        )
        dlg.doModal()
        result = dlg.result
        del dlg
        return result
    except Exception as e:
        xbmc.log('[Starfleet/SelectDialog] select: %s' % e, xbmc.LOGERROR)
        return xbmcgui.Dialog().select(title, options)
