# -*- coding: utf-8 -*-
"""
resources/lib/gui/qr_dialog.py

Shared QR-code pairing dialog, used by every account-pairing flow that
needs to show a scannable QR code (simkl_auth.py, tmdb_auth.py) — extracted
out of simkl_auth.py (where it was first built) so tmdb_auth.py's own
pairing dialog isn't stuck showing a raw, un-typeable JWT URL as plain text
(confirmed live via a real screenshot: nobody's going to type out a
200+ character themoviedb.org/auth/access?request_token=... URL on a
Firestick remote). Works for both shapes of pairing flow this addon has:
a short PIN code to type alongside the QR (SIMKL), or a URL-only flow with
nothing to type at all once scanned (TMDB) — pass code='' for the latter.

Confirmed live (real screenshot) the first version of this was nearly
unreadable: a bare xbmcgui.WindowDialog has NO background of its own — it's
fully transparent, so whatever screen was open behind it showed straight
through and visually interlaced with the text on top of it. Fixed by adding
a real opaque background panel — white.png is this addon's own existing
tintable texture (already used by Starfleet-Progress.xml for the identical
"tint a plain white image via colordiffuse" technique), reused here at full
opacity so nothing behind can bleed through.

Coordinates below assume the fixed 1280x720 virtual coordinate space every
xbmcgui Python Window/WindowDialog control uses regardless of the real
display resolution (confirmed live: a first pass sized for a naive
1920x1080 assumption rendered a "400x400" QR at ~600x600 real pixels on a
1080p display — Kodi scales this virtual space up to whatever the actual
resolution is, 1.5x in that case)."""
import xbmcgui
import xbmcvfs

_WHITE_TEXTURE = 'special://home/addons/plugin.video.starfleet/resources/skins/Default/media/white.png'


def make_qr(url, temp_filename):
    """Best-effort QR PNG for `url` via pyqrcode (transitive resolveurl
    dependency, already required by this addon's addon.xml). Returns a
    file path, or '' if generation isn't possible for any reason —
    callers fall back to a plain-text dialog in that case."""
    try:
        import pyqrcode
        qr_path = xbmcvfs.translatePath('special://temp/%s' % temp_filename)
        pyqrcode.create(url).png(qr_path, scale=6)
        return qr_path
    except Exception:
        return ''


class QRDialog(xbmcgui.WindowDialog):
    """heading: dialog title. instruction: the line under the QR code
    (typically 'Scan, or go to <url>'). code: optional short code shown in
    its own large, letter-spaced, high-contrast line below the QR — pass ''
    for a flow with nothing to type (the QR alone is the whole action).

    update(message) sets a SEPARATE, short-lived status line below
    everything else — it must never be passed the same text as `instruction`
    (confirmed live: doing that made the URL line visually repeat itself
    every few seconds instead of showing a real status update)."""

    def __init__(self, qr_path, heading, instruction, code=''):
        super(QRDialog, self).__init__()
        self._cancelled = False

        panel_x, panel_y, panel_w, panel_h = 390, 80, 500, 560

        bg_path = xbmcvfs.translatePath(_WHITE_TEXTURE)
        bg = xbmcgui.ControlImage(panel_x, panel_y, panel_w, panel_h, bg_path)
        self.addControl(bg)
        try:
            bg.setColorDiffuse('FF0F171E')  # opaque dark navy — same as
            # Starfleet-Progress.xml's own header-bar background color
        except Exception:
            pass

        heading_lbl = xbmcgui.ControlLabel(panel_x, panel_y + 20, panel_w, 40, heading,
                                           alignment=2, font='font30', textColor='FFFFFFFF')
        self.addControl(heading_lbl)

        qr_size = 260
        qr_x = panel_x + (panel_w - qr_size) // 2
        self.addControl(xbmcgui.ControlImage(qr_x, panel_y + 70, qr_size, qr_size, qr_path))

        content_x, content_w = panel_x + 20, panel_w - 40
        y = panel_y + 70 + qr_size + 20
        instr_lbl = xbmcgui.ControlLabel(content_x, y, content_w, 60, instruction,
                                         alignment=2, textColor='FFB0BEC8')
        self.addControl(instr_lbl)
        y += 65

        if code:
            # Letter-spaced + a large font + a bright accent color, on its
            # own line, rather than one small line sharing space with the
            # URL text using whatever the default label size happens to be.
            code_spaced = ' '.join(list(code))
            code_lbl = xbmcgui.ControlLabel(content_x, y, content_w, 50, code_spaced,
                                            alignment=2, font='font30', textColor='FFFF8C00')
            self.addControl(code_lbl)
            y += 55

        self._status = xbmcgui.ControlLabel(content_x, y, content_w, 40,
                                            'Waiting for you to approve…',
                                            alignment=2, textColor='FFB0BEC8')
        self.addControl(self._status)

    def onAction(self, action):
        if action.getId() in (10, 92):  # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK
            self._cancelled = True
            self.close()

    def update(self, message):
        self._status.setLabel(message)

    def iscanceled(self):
        return self._cancelled
