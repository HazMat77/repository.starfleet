# -*- coding: utf-8 -*-
"""
resources/lib/my_events.py

Reminders for events that have no team to follow (UFC, boxing, BKFC, PFL, Formula 1, tennis): the upcoming list of each sport
(see starfleetscrapers.sports.upcoming), and the viewer's reminders on it, kept in my_events.json (one file per viewer profile).

A reminder is the event (title, start, the sport list its streams are searched in) plus how long before the start to be told
(`lead` minutes, 0 = at the start). myevents_alerts.py, run by the background service, shows the popup.
"""
import json
import os
import threading
import time

import xbmc

FILE = 'my_events.json'
_LOCK = threading.Lock()
KEEP_AFTER = 6 * 3600                      # a reminder stays in the list this long after the event started
LEADS = (0, 15, 30, 60, 1440)              # the choices offered in the long-press menu


def _log(msg):
    xbmc.log('[Starfleet/MyEvents] %s' % msg, xbmc.LOGINFO)


def _path():
    from resources.lib import profiles as _profiles
    return _profiles.data_path(FILE)


def reminders():
    """[{'id','sport','title','sub','venue','start_ts','approx','stream_slug','lead','sent'}] by start time, past ones dropped."""
    try:
        with open(_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
    except Exception:
        return []
    now = time.time()
    keep = [r for r in d if isinstance(r, dict) and r.get('id') and r.get('start_ts') and r['start_ts'] > now - KEEP_AFTER]
    return sorted(keep, key=lambda r: r['start_ts'])


def _save(lst):
    p = _path()
    with open(p + '.tmp', 'w', encoding='utf-8') as f:
        json.dump(lst, f)
    os.replace(p + '.tmp', p)


def get(event_id):
    return next((r for r in reminders() if r['id'] == event_id), None)


def is_set(event_id):
    return get(event_id) is not None


def lead_label(lead):
    return {0: 'when it starts', 15: '15 minutes before', 30: '30 minutes before', 60: '1 hour before',
            1440: 'the day before'}.get(int(lead), '%d minutes before' % int(lead))


def add(ev, lead=0):
    """Set (or change) the reminder for an event dict from upcoming.events(). Returns the stored reminder."""
    lead = int(lead or 0)
    rec = {'id': ev['id'], 'sport': ev.get('sport', ''), 'title': ev.get('title', ''), 'sub': ev.get('sub', ''),
           'venue': ev.get('venue', ''), 'start_ts': int(ev.get('start_ts') or 0), 'approx': bool(ev.get('approx')),
           'stream_slug': ev.get('stream_slug') or ev.get('sport', ''), 'lead': lead, 'sent': []}
    with _LOCK:
        lst = [r for r in reminders() if r['id'] != rec['id']]
        lst.append(rec)
        _save(lst)
    _log('reminder set: %s (%s)' % (rec['title'], lead_label(lead)))
    return rec


def remove(event_id):
    with _LOCK:
        lst = reminders()
        keep = [r for r in lst if r['id'] != event_id]
        if len(keep) != len(lst):
            _save(keep)
            return True
    return False


def mark_sent(event_id, stage):
    with _LOCK:
        lst = reminders()
        for r in lst:
            if r['id'] == event_id and stage not in r.get('sent', []):
                r['sent'] = list(r.get('sent', [])) + [stage]
        _save(lst)


def when_text(ts, approx=False):
    """'Sat Nov 7, 9:00 AM' in the device's time zone ('Sat Nov 7' with '~' when only the day is known)."""
    lt = time.localtime(int(ts))
    day = time.strftime('%a %b ', lt) + str(lt.tm_mday)
    if approx:
        return day + ' (time TBA)'
    return '%s, %s' % (day, time.strftime('%I:%M %p', lt).lstrip('0'))


def starts_in(ts):
    """'in 2 hours' / 'in 3 days' / 'now' / 'started 20 min ago'."""
    d = int(ts - time.time())
    if d < -60:
        return 'started %d min ago' % (-d // 60)
    if d < 60:
        return 'now'
    if d < 3600:
        return 'in %d min' % (d // 60)
    if d < 86400:
        h = d // 3600
        return 'in %d hour%s' % (h, '' if h == 1 else 's')
    days = d // 86400
    return 'in %d day%s' % (days, '' if days == 1 else 's')


def upcoming(sport):
    """The sport's upcoming events with a 'reminder' key (the lead in minutes, or None) added."""
    from starfleetscrapers.sports import upcoming as _up
    mine = {r['id']: r for r in reminders()}
    out = []
    now = time.time()
    for ev in _up.events(sport):
        e = dict(ev)
        r = mine.get(ev['id'])
        e['reminder'] = r['lead'] if r else None
        e['on_now'] = bool(ev['start_ts'] <= now < (ev.get('end_ts') or ev['start_ts'] + 4 * 3600))
        out.append(e)
    return out


def row_label(ev):
    """One list row: the local date and time in front of the title; a bell when a reminder is set."""
    if ev.get('on_now'):
        when = '[COLOR red]ON NOW[/COLOR]'
    else:
        when = '[COLOR yellow]%s[/COLOR]' % when_text(ev['start_ts'], ev.get('approx'))
    bell = '  [COLOR FFFFC000]⏰[/COLOR]' if ev.get('reminder') is not None else ''
    return '%s  %s%s' % (when, ev.get('title', ''), bell)
