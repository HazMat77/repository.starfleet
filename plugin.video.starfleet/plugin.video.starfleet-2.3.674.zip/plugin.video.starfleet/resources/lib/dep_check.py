# -*- coding: utf-8 -*-
"""Keeps Starfleet's two helper add-ons in step with the add-on.

Starfleet needs Starfleet Scrapers (every scraper) and Starfleet Resolver (every link). Both are declared as required
add-ons in addon.xml, so Kodi installs them together with Starfleet and pulls updates for them when Starfleet itself updates.
This module is the second line of defence, run by the background service:

  * right after Starfleet has been updated (its version differs from the one last seen) and at most once a day otherwise,
    the add-on repositories are refreshed so that a newer scraper or resolver release is picked up straight away;
  * if either helper is missing, or older than the release this version of Starfleet was built against, it is
    installed / updated and the viewer is told in one short notice.

stale() is also what Settings > Check helper add-ons shows."""
import json
import os
import re
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'plugin.video.starfleet'
# add-on id -> lowest release this version of Starfleet works with (keep in step with the <import> lines in addon.xml)
REQUIRED = {
    'script.module.starfleetscrapers': '1.3.34',
    'script.module.starfleetresolve': '1.4.10',
}
NAMES = {'script.module.starfleetscrapers': 'Starfleet Scrapers', 'script.module.starfleetresolve': 'Starfleet Resolver'}
EVERY = 24 * 3600


def _ver(text):
    return tuple(int(x) for x in re.findall(r'\d+', text or '')) or (0,)


def installed_version(addon_id):
    """'' when the add-on is not installed (or disabled)."""
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo('version') or ''
    except Exception:
        return ''


def stale():
    """[(add-on id, installed version or '', required version)] for every helper that is missing or too old."""
    out = []
    for addon_id, need in REQUIRED.items():
        have = installed_version(addon_id)
        if not have or _ver(have) < _ver(need):
            out.append((addon_id, have, need))
    return out


def _state_path():
    base = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile'))
    try:
        os.makedirs(base, exist_ok=True)
    except OSError:
        pass
    return os.path.join(base, 'dep_check.json')


def _load():
    try:
        with open(_state_path(), 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return {}


def _save(state):
    try:
        with open(_state_path(), 'w', encoding='utf-8') as fh:
            json.dump(state, fh)
    except Exception:
        pass


def run(force=False, notify=True):
    """Refresh the repositories when due and install / update whatever helper is missing or old. Returns stale() as it was."""
    try:
        plugin_version = xbmcaddon.Addon(ADDON_ID).getAddonInfo('version')
    except Exception:
        plugin_version = ''
    state = _load()
    due = force or state.get('plugin_version') != plugin_version or time.time() - state.get('checked_at', 0) > EVERY
    problems = stale()
    if due:
        xbmc.executebuiltin('UpdateAddonRepos')            # Kodi then updates whatever has a newer release
        state.update(plugin_version=plugin_version, checked_at=time.time())
        _save(state)
    for addon_id, have, need in problems:
        xbmc.log('[Starfleet] helper add-on %s is %s, needs %s - installing/updating' % (addon_id, have or 'missing', need),
                 xbmc.LOGWARNING)
        if not have:
            xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
    if problems and notify:
        names = ', '.join(NAMES.get(a, a) for a, _h, _n in problems)
        xbmcgui.Dialog().notification('Starfleet', 'Updating %s - restart Kodi if something misbehaves' % names,
                                      xbmcgui.NOTIFICATION_INFO, 6000)
    return problems


def run_in_background(force=False):
    import threading
    t = threading.Thread(target=run, kwargs={'force': force}, daemon=True)
    t.start()
    return t
