# -*- coding: utf-8 -*-
"""
resources/lib/downloads.py

Downloads for movies, TV episodes and adult films, through the viewer's debrid service only.

  Menu       the hold-OK menu of a movie, an episode or an adult film gets "Download (debrid)", but only while a debrid service is
             paired and switched on (menu_entry; Settings > Downloads can switch it off).
  Sources    the debrid side of the normal source search (debrid_torrent.get_debrid_streams: cached torrents, release-site hosters,
             the viewer's own debrid cloud) and nothing else: no free sites, embeds or Easynews. A torrent has to be cached on the
             service already (a quick check, nothing is started on the service); a hoster link is turned into a direct link by the
             debrid service itself (resolvers.resolve_debrid_only), never by ResolveURL's free hosters.
  Queue      downloads.json (every profile, each job tagged with its profile). The background service runs worker(): one download
             at a time, resumes a half-finished file after an interruption or a restart, and asks the debrid service for a fresh
             link when the old one has expired.
  Files      <folder>/Movies/<Title (Year)>/<Title (Year)>.mkv, <folder>/TV Shows/<Show>/Season 01/<Show> - S01E02.mkv; adult files
             go to the adult folder (default <folder>/Adult) and are announced without their title.
"""
import json
import os
import re
import shutil
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'plugin.video.starfleet'
FILE = 'downloads.json'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
DEFAULT_DIR = 'special://profile/addon_data/plugin.video.starfleet/downloads/'
_LOCK = threading.Lock()
_VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.m4v', '.mov', '.ts', '.wmv', '.mpg', '.mpeg', '.webm')


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/Downloads] %s' % msg, level)


def _setting(key, default=''):
    try:
        v = xbmcaddon.Addon(ADDON_ID).getSetting(key)
        return v if v != '' else default
    except Exception:
        return default


# ── is it offered? ────────────────────────────────────────────────────────────────────────────────────────────────────

def available():
    """True when a debrid service is paired and switched on, and Downloads is not switched off in Settings."""
    if _setting('dl_enabled', 'true') == 'false':
        return False
    try:
        from resources.lib import resolvers as _r
        return bool(_r.any_debrid_enabled())
    except Exception:
        return False


def _dl_url(**params):
    from urllib.parse import urlencode
    clean = {k: v for k, v in params.items() if v not in (None, '')}
    return 'RunPlugin(plugin://%s/?%s)' % (ADDON_ID, urlencode(dict(clean, action='dl_add')))


def menu_entry(spec):
    """(label, builtin) for a hold-OK menu, or None when nothing can be downloaded here (no debrid service, no title)."""
    if not spec or not spec.get('title') or not available():
        return None
    return ('Download (debrid)', _dl_url(**spec))


def movie_spec(film):
    """The spec of a Movies list item ({'tmdb_id', 'title', 'year', ...})."""
    if not isinstance(film, dict) or not film.get('title') or film.get('not_aired'):
        return None
    return {'media_type': 'movie', 'title': film.get('title', ''), 'year': str(film.get('year', '') or ''),
            'tmdb_id': str(film.get('tmdb_id', '') or ''), 'imdb_id': str(film.get('imdb_id', '') or '')}


def episode_spec(show_title, season, episode, tmdb_id='', imdb_id='', year='', not_aired=False):
    if not_aired or not show_title:
        return None
    return {'media_type': 'tv', 'show': show_title, 'season': str(season), 'episode': str(episode),
            'title': '%s S%02dE%02d' % (show_title, int(season), int(episode)), 'tmdb_id': str(tmdb_id or ''),
            'imdb_id': str(imdb_id or ''), 'year': str(year or '')}


def adult_spec(film):
    if not isinstance(film, dict) or not film.get('title'):
        return None
    return {'media_type': 'adult', 'title': film.get('title', ''), 'year': str(film.get('year', '') or '')}


# ── folders and names ─────────────────────────────────────────────────────────────────────────────────────────────────

def _local(path):
    """The local file-system path of a folder setting, or None for a network location this does not write to."""
    if not path:
        return None
    if '://' in path and not path.startswith('special://'):
        return None
    return xbmcvfs.translatePath(path)


def base_dir(adult=False):
    root = _setting('dl_folder') or DEFAULT_DIR
    if adult:
        path = _setting('dl_adult_folder')
        if path:
            return _local(path)
        r = _local(root)
        return os.path.join(r, 'Adult') if r else None
    return _local(root)


def _clean(name, limit=120):
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', name or '')
    name = re.sub(r'\s+', ' ', name).strip(' .')
    return name[:limit].rstrip(' .') or 'Download'


def _ext_of(url):
    from urllib.parse import urlparse, unquote
    ext = os.path.splitext(unquote(urlparse(url).path))[1].lower()
    return ext if ext in _VIDEO_EXT else '.mkv'


def target_path(spec, url):
    """The file the download ends up in, or None when the download folder is a network location."""
    kind = spec.get('media_type')
    root = base_dir(kind == 'adult')
    if not root:
        return None
    ext = _ext_of(url)
    year = (spec.get('year') or '').strip()
    if kind == 'tv':
        show = _clean(spec.get('show') or spec.get('title'))
        s, e = int(spec.get('season') or 0), int(spec.get('episode') or 0)
        return os.path.join(root, 'TV Shows', show, 'Season %02d' % s, '%s - S%02dE%02d%s' % (show, s, e, ext))
    if kind == 'adult':
        return os.path.join(root, _clean(spec.get('title')) + ext)
    name = _clean('%s (%s)' % (spec.get('title'), year) if year else spec.get('title'))
    return os.path.join(root, 'Movies', name, name + ext)


# ── the queue (one file shared by the add-on's processes) ─────────────────────────────────────────────────────────────

def _store():
    d = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, FILE)


def _profile():
    try:
        from resources.lib import profiles as _p
        return str(_p.active_id())
    except Exception:
        return ''


def _read():
    try:
        with open(_store(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except Exception:
        return []


def _write(jobs):
    p = _store()
    with open(p + '.tmp', 'w', encoding='utf-8') as f:
        json.dump(jobs, f)
    os.replace(p + '.tmp', p)


class _FileLock(object):
    """A lock file: the plug-in's invocations and the service are different processes that all write the queue."""

    def __enter__(self):
        self.path = _store() + '.lock'
        _LOCK.acquire()
        end = time.time() + 8
        while True:
            try:
                self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                return self
            except OSError:
                try:
                    if time.time() - os.path.getmtime(self.path) > 10:     # left behind by a process that died
                        os.remove(self.path)
                        continue
                except OSError:
                    pass
                if time.time() > end:
                    return self
                time.sleep(0.05)

    def __exit__(self, *a):
        try:
            os.close(self.fd)
            os.remove(self.path)
        except Exception:
            pass
        _LOCK.release()


def _update(fn):
    """Apply fn(list_of_jobs) -> list_of_jobs to the queue under the lock; returns what fn returned."""
    with _FileLock():
        jobs = _read()
        out = fn(jobs)
        _write(jobs if out is None else out)
        return out


def _set(job_id, **kw):
    def _f(jobs):
        for j in jobs:
            if j.get('id') == job_id and j.get('state') != 'cancelled':
                j.update(kw)
        return jobs
    _update(_f)


def _state(job_id):
    for j in _read():
        if j.get('id') == job_id:
            return j.get('state')
    return 'removed'


def jobs():
    """This profile's downloads, oldest first."""
    pid = _profile()
    return [j for j in _read() if j.get('profile', '') == pid]


# ── looking for something to download ─────────────────────────────────────────────────────────────────────────────────

def _candidates(spec):
    """Debrid-side sources of a title, best quality first: [{'label', 'url', 'kind': magnet|hoster|direct, 'quality'}]."""
    from resources.lib import debrid_torrent as _dt
    kind = spec.get('media_type', 'movie')
    season = int(spec['season']) if spec.get('season') else None
    episode = int(spec['episode']) if spec.get('episode') else None
    imdb, tmdb = spec.get('imdb_id') or None, spec.get('tmdb_id') or None
    if kind == 'tv' and not imdb and tmdb:
        try:
            from resources.lib import metadata as _md
            imdb = (_md.get_tv_detail(tmdb) or {}).get('imdb_id') or None
        except Exception:
            pass
    if kind == 'movie' and not imdb and tmdb:
        try:
            from resources.lib import metadata as _md
            imdb = (_md.get_movie_detail(tmdb) or {}).get('imdb_id') or None
        except Exception:
            pass
    raw = _dt.get_debrid_streams(spec['title'], year=spec.get('year') or None, media_type=kind, imdb_id=imdb,
                                 season=season, episode=episode, tmdb_id=tmdb) or []
    out = []
    for s in raw:
        url = (s.get('url') or '').strip()
        if not url or s.get('is_nzb'):                      # a Usenet release is fetched by the service in real time: not offered
            continue
        if url.startswith('magnet:'):
            k = 'magnet'
        elif s.get('is_ddl'):
            k = 'hoster'
        elif url.startswith('http'):
            k = 'direct'                                    # a file of the viewer's own debrid cloud
        else:
            continue
        out.append({'label': s.get('label', ''), 'url': url, 'kind': k, 'quality': s.get('quality', '')})
    try:
        from resources.lib import metadata_router as _mr
        out = _mr._sort_by_quality(out)
    except Exception:
        pass
    return out


def _clean_url(u):
    if not u:
        return ''
    u = str(u).split('|')[0].strip()
    if not u.startswith('http') or '.m3u8' in u.lower() or '.mpd' in u.lower():
        return ''
    return u


def resolve_src(src):
    """A candidate -> a direct file link from the debrid service, or '' (not cached / not offered by the service)."""
    from resources.lib import resolvers as _r
    kind, url = src.get('kind'), src.get('url', '')
    try:
        if kind == 'magnet':
            out = _r.resolve_magnet_candidates([url] + list(src.get('alts') or []), season=src.get('season'),
                                               episode=src.get('episode'), background=True)
        elif kind == 'hoster':
            out = _r.resolve_debrid_only(url)
        else:
            out = url
    except Exception as e:
        _log('resolve %s: %s' % (kind, e), xbmc.LOGWARNING)
        out = None
    return _clean_url(out)


def _label(c):
    lab = re.sub(r'\s+', ' ', c.get('label', '')).strip()
    return lab[:90] or 'Source'


def _note(title, text, adult=False, seconds=4000, warn=False):
    xbmcgui.Dialog().notification('Downloads' if adult else (title or 'Downloads'), text,
                                  xbmcgui.NOTIFICATION_WARNING if warn else xbmcgui.NOTIFICATION_INFO, seconds)


def add(p):
    """The "Download (debrid)" choice: find sources, pick one, resolve it and queue the file (see the module docstring)."""
    spec = {k: (p.get(k) or '') for k in ('media_type', 'title', 'year', 'tmdb_id', 'imdb_id', 'season', 'episode', 'show')}
    spec['media_type'] = spec['media_type'] or 'movie'
    adult = spec['media_type'] == 'adult'
    title = spec['title']
    if not title:
        return
    if not available():
        _note('Downloads', 'Downloads need a paired debrid service (Settings > Premium Services)', warn=True, seconds=5000)
        return
    if base_dir(adult) is None:
        _note('Downloads', 'The download folder is a network location: choose a folder on this device or a USB drive '
                           '(Settings > Downloads)', adult, warn=True, seconds=6000)
        return

    try:
        from resources.lib.gui import progress_dialog as _pdlg
        pd = _pdlg.DialogProgress()
        pd.create('Starfleet', 'Looking for sources your debrid service can download...')
    except Exception:
        pd = None
    try:
        cands = _candidates(spec)
    except Exception as e:
        _log('search: %s' % e, xbmc.LOGWARNING)
        cands = []
    finally:
        if pd is not None:
            pd.close()
    if not cands:
        xbmcgui.Dialog().ok('Download', 'No source your debrid service can download was found for this title.')
        return

    season = int(spec['season']) if spec['season'] else None
    episode = int(spec['episode']) if spec['episode'] else None
    ask = _setting('dl_pick', '0') == '0'
    one = None
    if ask:
        labels = ['Best available (automatic)'] + [_label(c) for c in cands]
        pick = xbmcgui.Dialog().select('Download - choose a source', labels)
        if pick < 0:
            return
        if pick > 0:
            one = pick - 1
    if one is not None:
        order = [one]
    else:                                   # the best source of each quality first, then the rest: a handful of cache checks at most
        seen, first, rest = set(), [], []
        for i, c in enumerate(cands):
            q = c.get('quality') or ''
            (rest if q in seen else first).append(i)
            seen.add(q)
        order = (first + rest)[:8]

    try:
        from resources.lib.gui import progress_dialog as _pdlg
        pd = _pdlg.DialogProgress()
        pd.create('Starfleet', 'Checking that your debrid service has it ready...')
    except Exception:
        pd = None
    chosen, url = None, ''
    try:
        for n, i in enumerate(order):
            c = cands[i]
            if pd is not None:
                if pd.iscanceled():
                    return
                pd.update(int(100.0 * n / max(1, len(order))), 'Checking source %d of %d...' % (n + 1, len(order)))
            alts = [x['url'] for x in cands if x is not c and c['kind'] == 'magnet' and x['kind'] == 'magnet'
                    and x.get('quality') == c.get('quality')][:6]
            src = {'kind': c['kind'], 'url': c['url'], 'season': season, 'episode': episode, 'alts': alts}
            url = resolve_src(src)
            if url:
                chosen = dict(c, src=src)
                break
    finally:
        if pd is not None:
            pd.close()
    if not chosen:
        xbmcgui.Dialog().ok('Download', 'Your debrid service does not have this ready yet.\n\nPick another source, or try again later.'
                            if ask else 'None of the sources is ready on your debrid service yet. Try again later.')
        return

    path = target_path(spec, url)
    if os.path.exists(path):
        _note(title, 'Already downloaded', adult)
        return
    job = {'id': '%d%03d' % (time.time() * 1000, os.getpid() % 1000), 'profile': _profile(), 'title': title,
           'media_type': spec['media_type'], 'url': url, 'src': chosen['src'], 'path': path, 'state': 'queued',
           'done': 0, 'total': 0, 'added': int(time.time()), 'err': ''}

    def _add(js):
        if any(j.get('path') == path and j.get('state') in ('queued', 'running') for j in js):
            return None
        js.append(job)
        return js
    if _update(_add) is None:
        _note(title, 'Already in the download list', adult)
        return
    _note(title, 'Added to the download list' if not adult else 'Download added', adult)


# ── the worker (runs in the background service) ──────────────────────────────────────────────────────────────────────

def _fmt_size(n):
    n = float(n or 0)
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024 or unit == 'GB':
            return ('%.0f %s' % (n, unit)) if unit in ('B', 'KB') else ('%.1f %s' % (n, unit))
        n /= 1024.0


def _fail(job, why):
    _log('%s failed: %s' % (job.get('title'), why), xbmc.LOGWARNING)
    _set(job['id'], state='failed', err=why[:120])
    _note(job.get('title'), 'Download failed: %s' % why[:60], job.get('media_type') == 'adult', 6000, warn=True)


def _run_job(job, monitor):
    import requests
    jid, path = job['id'], job['path']
    part = path + '.part'
    adult = job.get('media_type') == 'adult'
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    except Exception as e:
        return _fail(job, 'cannot create the folder (%s)' % e)
    url, refreshed, attempts, announced = job['url'], False, 0, False
    while True:
        if monitor.abortRequested():
            _set(jid, state='queued')
            return
        st = _state(jid)
        if st in ('cancelled', 'removed'):
            _discard(part)
            return
        pos = os.path.getsize(part) if os.path.exists(part) else 0
        hdr = {'User-Agent': UA}
        if pos:
            hdr['Range'] = 'bytes=%d-' % pos
        try:
            r = requests.get(url, headers=hdr, stream=True, timeout=(20, 60), allow_redirects=True)
        except Exception as e:
            attempts += 1
            if attempts > 5:
                return _fail(job, 'no connection (%s)' % type(e).__name__)
            if monitor.waitForAbort(5 * attempts):
                _set(jid, state='queued')
                return
            continue
        code = r.status_code
        if code in (401, 403, 404, 410) and not refreshed and job.get('src'):
            refreshed = True                       # the debrid link has expired: ask the service for a fresh one
            r.close()
            new = resolve_src(job['src'])
            if new:
                url = new
                _set(jid, url=new)
                continue
        if code == 416 and pos:                    # the part file is already the whole file
            r.close()
            _discard_part_complete(part, path)
            _set(jid, state='done', done=pos, total=pos)
            return
        if code not in (200, 206):
            r.close()
            return _fail(job, 'the service answered %d' % code)
        length = int(r.headers.get('Content-Length') or 0)
        if code == 206 and pos:
            total, done, mode = pos + length, pos, 'ab'
        else:
            total, done, mode = length, 0, 'wb'
        if total:
            try:
                free = shutil.disk_usage(os.path.dirname(path)).free
                if free < (total - done) + 200 * 1024 * 1024:
                    r.close()
                    return _fail(job, 'not enough free space (%s needed)' % _fmt_size(total - done))
            except Exception:
                pass
        _set(jid, state='running', done=done, total=total, err='')
        if not announced:
            announced = True
            _note(job.get('title'), 'Download started' if adult else 'Download started (%s)' % (_fmt_size(total) if total else '?'),
                  adult, 3000)
        try:
            with open(part, mode) as f:
                last_save = last_chk = time.time()
                for chunk in r.iter_content(1024 * 1024):
                    if not chunk:
                        continue
                    f.write(chunk)
                    done += len(chunk)
                    now = time.time()
                    if now - last_save >= 3:
                        last_save = now
                        _set(jid, done=done, total=total)
                    if now - last_chk >= 2:
                        last_chk = now
                        if monitor.abortRequested():
                            r.close()
                            _set(jid, state='queued', done=done)
                            return
                        if _state(jid) in ('cancelled', 'removed'):
                            r.close()
                            break
        except Exception as e:
            if not isinstance(e, (requests.exceptions.RequestException, ConnectionError, TimeoutError)):
                return _fail(job, 'cannot write the file (%s)' % e)       # the disk, not the network
            attempts += 1
            _log('interrupted at %d: %s' % (done, e), xbmc.LOGINFO)
            if attempts > 8:
                return _fail(job, 'the connection kept dropping')
            if monitor.waitForAbort(5):
                _set(jid, state='queued', done=done)
                return
            continue
        finally:
            try:
                r.close()
            except Exception:
                pass
        if _state(jid) in ('cancelled', 'removed'):
            _discard(part)
            return
        have = os.path.getsize(part) if os.path.exists(part) else 0
        if total and have < total:
            attempts += 1
            if attempts > 8:
                return _fail(job, 'the file stopped short (%s of %s)' % (_fmt_size(have), _fmt_size(total)))
            continue
        final = _unique(path)
        os.replace(part, final)
        _set(jid, state='done', done=have, total=have or total, path=final)
        _note(job.get('title'), 'Download finished' if adult else 'Download finished (%s)' % _fmt_size(have), adult, 5000)
        _log('finished %s (%d bytes)' % (final, have))
        return


def _discard(part):
    try:
        if os.path.exists(part):
            os.remove(part)
    except Exception:
        pass


def _discard_part_complete(part, path):
    try:
        os.replace(part, _unique(path))
    except Exception:
        pass


def _unique(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    n = 1
    while os.path.exists('%s (%d)%s' % (base, n, ext)):
        n += 1
    return '%s (%d)%s' % (base, n, ext)


def worker(monitor):
    """Background service loop: one download at a time, oldest queued job first."""
    def _reset(js):                                   # a job that was running when Kodi closed starts again (it resumes)
        for j in js:
            if j.get('state') == 'running':
                j['state'] = 'queued'
        return js
    try:
        _update(_reset)
    except Exception:
        pass
    while not monitor.abortRequested():
        job = next((j for j in _read() if j.get('state') == 'queued'), None)
        if job is None:
            if monitor.waitForAbort(3):
                break
            continue
        try:
            _run_job(job, monitor)
        except Exception as e:
            _log('job crashed: %s' % e, xbmc.LOGERROR)
            try:
                _set(job['id'], state='failed', err=str(e)[:100])
            except Exception:
                pass


# ── the list (Settings > Downloads > Show downloads) ──────────────────────────────────────────────────────────────────

_STATE_TEXT = {'queued': 'Waiting', 'running': 'Downloading', 'done': 'Finished', 'failed': 'Failed', 'cancelled': 'Cancelled'}


def _row(j):
    st = j.get('state', '')
    total, done = j.get('total') or 0, j.get('done') or 0
    pct = ' %d%%' % int(100.0 * done / total) if total and st in ('running', 'queued') and done else ''
    extra = ''
    if st == 'running' and total:
        extra = '  (%s of %s)' % (_fmt_size(done), _fmt_size(total))
    elif st == 'failed' and j.get('err'):
        extra = '  (%s)' % j['err']
    return '[%s%s] %s%s' % (_STATE_TEXT.get(st, st), pct, j.get('title', ''), extra)


def status():
    while True:
        mine = jobs()
        if not mine:
            xbmcgui.Dialog().notification('Downloads', 'Nothing in the download list', xbmcgui.NOTIFICATION_INFO, 3000)
            return
        rows = [_row(j) for j in mine]
        finished = [j for j in mine if j.get('state') in ('done', 'failed', 'cancelled')]
        extra = ['Clear finished, failed and cancelled'] if finished else []
        pick = xbmcgui.Dialog().select('Downloads', rows + extra)
        if pick < 0:
            return
        if pick >= len(rows):
            ids = {j['id'] for j in finished}
            _update(lambda js: [j for j in js if j.get('id') not in ids])
            continue
        j = mine[pick]
        st = j.get('state')
        opts = []
        if st in ('queued', 'running'):
            opts = [('Cancel this download', 'cancel')]
        else:
            if st in ('failed', 'cancelled'):
                opts.append(('Try again', 'retry'))
            opts.append(('Remove from the list', 'remove'))
        c = xbmcgui.Dialog().select(j.get('title', 'Download'), [o[0] for o in opts])
        if c < 0:
            continue
        act = opts[c][1]
        if act == 'cancel':
            _update(lambda js: [dict(x, state='cancelled') if x.get('id') == j['id'] else x for x in js])
            _discard(j.get('path', '') + '.part')
        elif act == 'remove':
            _update(lambda js: [x for x in js if x.get('id') != j['id']])
        elif act == 'retry':
            _update(lambda js: [dict(x, state='queued', err='') if x.get('id') == j['id'] else x for x in js])


def choose_folder(which=''):
    key = 'dl_adult_folder' if which == 'adult' else 'dl_folder'
    start = _setting(key) or DEFAULT_DIR
    path = xbmcgui.Dialog().browseSingle(3, 'Choose the folder for %s' % ('adult downloads' if which == 'adult' else 'downloads'),
                                         'files', '', False, True, start)
    if path:
        xbmcaddon.Addon(ADDON_ID).setSetting(key, path)
