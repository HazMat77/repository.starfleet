# -*- coding: utf-8 -*-
"""
resources/lib/airing_prep.py

Episodes that air today, ready when their links appear. For the shows the active profile has been watching, the background
service looks (from 10:00 on the air day: hourly until 18:00, then every 30 minutes; never while something is playing) for an episode that TMDB lists as airing today and that has
not been watched, and searches for it. Links are not there at air time - they show up a little later - so the search is repeated
until it finds something playable (cached on the viewer's debrid service, or a free source) or the day ends. The ranked sources
are then kept for six hours, so opening the episode starts at once, and a notice (or, when nothing is playing, "Watch now?")
says it is ready.

Deliberately small: only today's episodes, only shows the viewer already watches (at most 5 a day), one search at a time, no
sports (their links do not exist until the game is on) and nothing at all when no debrid service is set up. The next episode of
a show that is playing is handled by metadata_router._start_next_prefetch, not here.
"""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui

STATE = 'airing_prep.json'
GAP = 30 * 60                 # between two searches for the same episode in the evening
GAP_DAY = 60 * 60              # ... and before EVENING (it is only a hunch that this one is out early)
READY_FROM = 10 * 60           # minute of the day (10:00) of the first look at an episode dated today: some are out early
EVENING = 18 * 60              # from here the looks come every GAP: most episodes appear a few hours after their air time
MAX_TRIES = 24                 # 10:00 to 18:00 hourly (9 looks), then half-hourly into the night
MAX_SHOWS = 5
READY_TTL = 6 * 3600          # how long the ranked sources of a ready episode are kept
_tv_cache = {}


def _log(msg):
    xbmc.log('[Starfleet/AiringPrep] %s' % msg, xbmc.LOGINFO)


def _setting(key, default='true'):
    try:
        v = xbmcaddon.Addon('plugin.video.starfleet').getSetting(key)
        return v if v != '' else default
    except Exception:
        return default


def _state_path():
    from resources.lib import profiles as _profiles
    return _profiles.data_path(STATE)


def _load():
    try:
        with open(_state_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        today = time.strftime('%Y-%m-%d')
        return {k: v for k, v in d.items() if v.get('date') == today}
    except Exception:
        return {}


def _save(st):
    try:
        p = _state_path()
        with open(p + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(st, f)
        os.replace(p + '.tmp', p)
    except Exception:
        pass


def _recent_shows(now, days=120, limit=12):
    """[(tmdb_id, imdb_id, title)] of the shows watched lately, newest first."""
    from resources.lib import watch_history as _wh
    best = {}
    for e in _wh._load().values():
        if not (e.get('season') and e.get('episode') and e.get('tmdb_id')):
            continue
        ts = e.get('ts', 0)
        if now - ts > days * 86400:
            continue
        k = str(e['tmdb_id'])
        if k not in best or ts > best[k][0]:
            best[k] = (ts, e.get('imdb_id', ''), e.get('title', ''))
    ordered = sorted(best.items(), key=lambda kv: -kv[1][0])[:limit]
    return [(k, v[1], v[2]) for k, v in ordered]


def _tv(tmdb_id):
    hit = _tv_cache.get(tmdb_id)
    if hit and time.time() - hit[0] < 6 * 3600:
        return hit[1]
    from resources.lib import metadata as _md
    data = _md._tmdb_get('/tv/%s' % tmdb_id, {'append_to_response': 'external_ids'})
    _tv_cache[tmdb_id] = (time.time(), data)
    return data


def airing_today(now=None):
    """[{'tmdb_id', 'imdb_id', 'show', 'season', 'episode', 'name'}] for unwatched episodes TMDB dates today."""
    now = now or time.time()
    today = time.strftime('%Y-%m-%d', time.localtime(now))
    from resources.lib import watch_history as _wh
    out = []
    for tmdb_id, imdb_id, title in _recent_shows(now):
        try:
            tv = _tv(tmdb_id)
        except Exception as e:
            _log('tmdb %s: %s' % (tmdb_id, e))
            continue
        imdb_id = imdb_id or (tv.get('external_ids') or {}).get('imdb_id') or ''
        for kind in ('last_episode_to_air', 'next_episode_to_air'):
            ep = tv.get(kind) or {}
            if (ep.get('air_date') or '')[:10] != today or not ep.get('season_number') or not ep.get('episode_number'):
                continue
            s, e = int(ep['season_number']), int(ep['episode_number'])
            try:
                if _wh.is_watched(imdb_id, s, e):
                    continue
            except Exception:
                pass
            out.append({'tmdb_id': str(tmdb_id), 'imdb_id': imdb_id, 'show': tv.get('name') or title, 'season': s, 'episode': e,
                        'name': ep.get('name', '')})
            break
    return out


def _prepare(item):
    """Search the episode and keep the ranked sources. True when something playable was found."""
    from resources.lib import metadata_router as _mr
    from resources.lib import playback_assist as _assist
    title = '%s S%02dE%02d' % (item['show'], item['season'], item['episode'])
    key = _assist.title_key('tv', item['tmdb_id'], item['imdb_id'] or None, item['season'], item['episode'], title)
    try:
        _mr._unified_source_search(-1, title, media_type='tv', imdb_id=item['imdb_id'] or None, tmdb_id=item['tmdb_id'],
                                   season=item['season'], episode=item['episode'], auto=True, prefetch=True)
    except Exception as e:
        _log('search for %s failed: %s' % (title, e))
        return False
    cands = _assist.load_candidates(key) or []
    ok = any(c.get('pre_resolved') or (c.get('url') and not str(c.get('url')).startswith('magnet:') and not c.get('pre_failed'))
             for c in cands)
    if ok:
        _assist.save_candidates(key, cands, ttl=READY_TTL)
    return ok


def _announce(item):
    title = '%s S%02dE%02d' % (item['show'], item['season'], item['episode'])
    text = '%s is ready to watch.' % title
    _log(text)
    try:
        playing = xbmc.Player().isPlaying()
    except Exception:
        playing = False
    if not playing and _setting('airing_prompt') != 'false':
        try:
            if xbmcgui.Dialog().yesno('New episode', text + '\n\nWatch now?', nolabel='Not now', yeslabel='Watch', autoclose=25000):
                from urllib.parse import quote
                url = ('plugin://plugin.video.starfleet/?action=meta_ep_play&tmdb_id=%s&season_num=%s&episode_num=%s&title=%s&auto=1'
                       % (item['tmdb_id'], item['season'], item['episode'], quote(title)))
                li = xbmcgui.ListItem(title)
                li.setProperty('IsPlayable', 'true')
                xbmc.Player().play(url, li)
            return
        except Exception as e:
            _log('prompt failed: %s' % e)
    xbmcgui.Dialog().notification('New episode', text, xbmcgui.NOTIFICATION_INFO, 7000)


def tick(now=None):
    """One pass; returns how many episodes were announced. Never raises."""
    now = now or time.time()
    if _setting('airing_prep') == 'false':
        return 0
    try:
        if xbmc.Player().isPlaying():
            return 0
        from resources.lib import resolvers as _resolvers
        if not _resolvers.any_debrid_enabled():
            return 0
    except Exception:
        return 0
    # Today's episodes are first looked for at 10:00 (some come out early), then every hour until the evening and every half hour after
    # that (most appear a few hours after air time). Fake pre-air "releases" are filtered out of the results, so an early look that
    # finds only fakes simply finds nothing and tries again later.
    lt = time.localtime(now)
    minute = lt.tm_hour * 60 + lt.tm_min
    if minute < READY_FROM:
        return 0
    st = _load()
    announced = 0
    todo = [it for it in airing_today(now)][:MAX_SHOWS]
    for it in todo:
        k = '%s:%d:%d' % (it['tmdb_id'], it['season'], it['episode'])
        e = st.get(k) or {'date': time.strftime('%Y-%m-%d', time.localtime(now)), 'tries': 0, 'ready': False, 'next': 0}
        if e['ready'] or e['tries'] >= MAX_TRIES or now < e.get('next', 0):
            st[k] = e
            continue
        if xbmc.Player().isPlaying():
            break
        ok = _prepare(it)
        e['tries'] += 1
        e['next'] = now + (GAP if minute >= EVENING else GAP_DAY)
        if ok:
            e['ready'] = True
            _save(dict(st, **{k: e}))
            _announce(it)
            announced += 1
        st[k] = e
    _save(st)
    return announced


def run(monitor):
    """Service thread body: a pass every 30 minutes until Kodi shuts down."""
    if monitor.waitForAbort(180):                        # let Kodi and the add-on settle first
        return
    while not monitor.abortRequested():
        try:
            from resources.lib import memguard as _mg
            if _mg.low():
                if monitor.waitForAbort(300):
                    break
                continue
            tick()
        except Exception as e:
            _log('pass failed: %s' % e)
        if monitor.waitForAbort(GAP):
            break
