# -*- coding: utf-8 -*-
"""Elementum is never downloaded unasked. Without a debrid service Starfleet only uses its free sources; Settings > "Use Elementum for
torrents when no debrid service is set up" is off until the viewer turns it on, and turning it on (or playing a torrent with it on but
not installed) asks whether to download Elementum now. Keeping it out of the add-on keeps Starfleet small."""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ELEMENTUM_ID = 'plugin.video.elementum'
_PROP = 'sf_elementum_prompt'


def installed():
    try:
        return bool(xbmc.getCondVisibility('System.HasAddon(%s)' % ELEMENTUM_ID))
    except Exception:
        return False


def enabled():
    try:
        return xbmcaddon.Addon('plugin.video.starfleet').getSetting('elementum_enabled') == 'true'
    except Exception:
        return False


def _switch_off():
    try:
        xbmcaddon.Addon('plugin.video.starfleet').setSetting('elementum_enabled', 'false')
    except Exception:
        pass


def offer_install():
    """Ask whether to download Elementum now. True when the install was started (Kodi fetches it from the Starfleet repository
    and asks for its own confirmation); False when declined, in which case the Elementum setting goes back off."""
    win = xbmcgui.Window(10000)
    if win.getProperty(_PROP) == '1':
        return False                                   # already asking
    win.setProperty(_PROP, '1')
    try:
        yes = xbmcgui.Dialog().yesno(
            'Starfleet - Elementum',
            'Elementum plays torrents when no debrid service is paired. It is not installed on this device.\n'
            'Download and install it now? It is a large download.',
            nolabel='Not now', yeslabel='Download')
        if yes:
            xbmc.executebuiltin('InstallAddon(%s)' % ELEMENTUM_ID)
            xbmcgui.Dialog().notification('Starfleet', 'Installing Elementum - confirm in Kodi if asked',
                                          xbmcgui.NOTIFICATION_INFO, 6000)
            return True
        _switch_off()
        return False
    finally:
        win.clearProperty(_PROP)


def ready():
    """True when Elementum can be used right now. When it is not installed the viewer is asked about downloading it (and the
    torrent is not started: try again once it is installed)."""
    if installed():
        return True
    offer_install()
    return False


def on_settings_changed():
    """Called when Starfleet's settings changed: Elementum switched on but not installed -> offer the download."""
    if enabled() and not installed():
        offer_install()


# ── one-time clean-up when a debrid service is paired ───────────────────────────────────────────────────────────────────────

_CLEANUP_IDS = ('plugin.video.elementum', 'script.elementum.burst')      # Elementum first, then the add-on it depends on


def _marker_path():
    base = xbmcvfs.translatePath(xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('profile'))
    try:
        os.makedirs(base, exist_ok=True)
    except OSError:
        pass
    return os.path.join(base, 'elementum_cleanup.json')


def _remove(addon_id):
    """Switch the add-on off (stops its background service), then delete its folder. Its data folder (library, downloads) is left alone.
    True when the folder is gone."""
    try:
        xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled',
                                        'params': {'addonid': addon_id, 'enabled': False}}))
    except Exception:
        pass
    path = xbmcvfs.translatePath('special://home/addons/%s' % addon_id)
    for _ in range(4):                                   # its service needs a moment to let go of its files
        if not os.path.isdir(path):
            return True
        time.sleep(3)
        try:
            xbmcvfs.rmdir(path, force=True)
        except Exception:
            pass
    return not os.path.isdir(path)


def cleanup_if_debrid():
    """Once: with a debrid service paired, Elementum is never used (a torrent debrid cannot resolve is not handed to it), so Elementum and
    Elementum Burst are removed from the device and the viewer is told. Done once only (one attempt, recorded in the profile folder), so a later reinstall or opt-in is left alone.
    -> list of the add-on ids removed."""
    marker = _marker_path()
    if os.path.exists(marker):
        return []
    try:
        from resources.lib import resolvers
        if not resolvers.any_debrid_enabled():
            return []                                    # no debrid: nothing is touched
    except Exception:
        return []
    present = [i for i in _CLEANUP_IDS if os.path.isdir(xbmcvfs.translatePath('special://home/addons/%s' % i))]
    removed = []
    for addon_id in present:
        if _remove(addon_id):
            removed.append(addon_id)
        else:
            xbmc.log('[Starfleet] could not remove %s (it can be uninstalled by hand; this is not tried again)' % addon_id, xbmc.LOGINFO)
    try:                                                 # one attempt only, whatever the outcome: it is never repeated
        with open(marker, 'w') as f:
            json.dump({'done': int(time.time()), 'removed': removed, 'left': [i for i in present if i not in removed]}, f)
    except OSError:
        pass
    if removed:
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmcgui.Dialog().notification('Starfleet', 'Removed Elementum - not needed with your debrid service',
                                      xbmcgui.NOTIFICATION_INFO, 6000)
        xbmc.log('[Starfleet] removed %s (debrid is paired)' % ', '.join(removed), xbmc.LOGINFO)
    return removed
