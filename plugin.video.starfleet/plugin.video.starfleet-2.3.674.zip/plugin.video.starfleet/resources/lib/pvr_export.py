# -*- coding: utf-8 -*-
"""
resources/lib/pvr_export.py

"Export to TV Guide" — builds an M3U8 playlist of Starfleet's Live TV
channels and hands it, plus the best-matching free EPG source, to Kodi's
pvr.iptvsimple client, so channels + program guide show up in Kodi's own
native PVR/TV Guide UI (channel-up/down zapping, EPG grid), not just our
in-app browsing. Declared as an optional dependency in addon.xml so Kodi
offers to auto-install it alongside Starfleet.

Every M3U entry points at one of THIS addon's own plugin:// play actions,
never a raw stream URL — pvr.iptvsimple's own README documents plugin://
channel URLs as a first-class supported format ("Channel K" example: a
plugin:// line used directly as the stream URL). Routing through our own
actions reuses every bit of existing resolution logic (geo-proxy
selection, Sinclair's inputstream setup, TVA's DAI tokens, Pluto's JWT)
instead of re-deriving fragile/token-expiring raw URLs into a static file.

EPG: Pluto TV / Samsung TV+ / Plex channels have a free, reliably
ID-matched EPG source — i.mjh.nz publishes XMLTV guides keyed by each
service's own native channel id, and this addon's channel lists for those
three sources already carry that exact id (Pluto's raw API "_id";
Samsung/Plex's tvg-id, sourced from a community M3U built specifically to
pair with i.mjh.nz's guide — see live_sources.py's MJH_SAMSUNG_EPG/
MJH_PLEX_EPG, already present but never wired to a real PVR client before
now). Sinclair and TVA each get a scraped XMLTV source instead (see
SINCLAIR_EPG_URL / TVA_EPG_URL below). TVA Sports/TVA Sports 2 were
dropped entirely (see api.py's TVA_CHANNELS) — TVA Sports Direct now
requires a paid subscriber login, confirmed live, so there was never a
real EPG-worthy channel behind those two tvg-ids to begin with.
json_data's per-country (offline daddylive_channels.json) catalogue still
has no confident free EPG match, so those channels ship with no tvg-id —
they show in the guide with no program data, which is honest, not broken.

live_sources.get_tvnow_channels() (tvnow247.top's own 800+-channel live
scrape — a separate catalogue from json_data's offline one, not yet wired
into any user-facing menu) DOES now have a free EPG: scraper_daddylive_epg.py
(run manually on the scraper PC, output hosted at DADDYLIVE_EPG_URL below)
name-matches it against epgshare01.online's free XMLTV feeds per-country,
confirmed live at ~68% coverage (566/827 channels) — the rest are honest
content gaps (premium sports channels like Cyprus's Cytavision Sports or
Saudi's SSC Sport simply have no free EPG schedule anywhere, confirmed by
inspecting the raw feeds directly). Matched channels get a tvg-id of
"dl_<tvnow-slug>" (see DADDYLIVE_EPG_MATCHES_URL below for the match list);
unmatched ones ship with no tvg-id, same honest-gap treatment as Sinclair's
own partial coverage.

pvr.iptvsimple is a multi-instance PVR client add-on (Settings > PVR &
Live TV > TV add-ons > Configure > "Add instance" normally creates this
by hand) — its real per-instance config is a plain XML file at
special://userdata/addon_data/pvr.iptvsimple/instance-settings-<N>.xml,
NOT the classic xbmcaddon.Addon.setSetting() API (confirmed against a
live instance file on this machine; setSetting() only touches settings
that predate multi-instance support). _write_instance_settings() below
reads/patches that file directly, preserving every field it doesn't
touch, then toggles the add-on off/on via JSON-RPC so pvr.iptvsimple
re-reads it — the same lifecycle Kodi's own PVR manager uses when you
save changes in its settings dialog.
"""
import os
import re
import json
import time
import unicodedata
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.starfleet')
PLUGIN_BASE = 'plugin://plugin.video.starfleet/'

PVR_ADDON_ID = 'pvr.iptvsimple'
INSTANCE_NAME = 'Starfleet Live TV'

# Guides for these sources are built when the TV guide is set up, from each service's own API (see
# starfleetscrapers.live.epg_scrapers) - nothing is downloaded from a third-party guide host.
_OWN_EPG = ('Pluto TV', 'Plex', 'LG Channels')


# Sinclair callsign -> iptv-org/epg channel id — confirmed live against
# iptv-org/epg's own channel database (their channel IDs don't map 1:1 to
# plain station callsigns, so only these 9 of Starfleet's 31 recovered
# Sinclair stations have a confirmed match). Real programme data for these
# comes from tvtv.us's JSON API (the same source iptv-org/epg's own tvtv.us
# grabber uses — ported to Python in scraper_sinclair_epg.py on the
# scraper PC, since iptv-org/epg itself has no live-hosted public output
# right now), refreshed alongside the other scraped data and hosted at
# SINCLAIR_EPG_URL above.
SINCLAIR_TVG_IDS = {
    'KMPH': 'KMPHTV261.us', 'WJLA': 'WJLATV71.us', 'WWMT': 'WWMT31.us',
    'WPDE': 'WPDETV151.us', 'KRCR': 'KRCRTV71.us', 'KECI': 'KECITV131.us',
    'WCTI': 'WCTITV121.us', 'WJAC': 'WJACTV61.us', 'KOMO': 'KOMOTV511.us',
}


# api.py's TVA_CHANNELS 'id' field -> scraper_tva_epg.py's XMLTV channel id
# (real programme data pulled from TV Passport's own public grid API —
# Cogeco's "Horaire télé" guide resells the exact same lineup — see
# scraper_tva_epg.py's own docstring for why plain requests work here with
# no auth/session needed).
TVA_TVG_IDS = {
    'tva': 'TVA.ca',
}

# scraper_daddylive_epg.py's combined XMLTV output + the match report that
# says which tvnow247 slugs it actually covers (see module docstring above).
DADDYLIVE_EPG_URL = 'https://hazmat77.github.io/repository.starfleet/data/daddylive_epg.xml'
DADDYLIVE_EPG_MATCHES_URL = 'https://hazmat77.github.io/repository.starfleet/data/daddylive_epg_matches.json'

# json_data.get_live_tv_channels_by_country()'s offline daddylive_channels.json
# catalogue and live_sources.get_tvnow_channels()'s live tvnow247 scrape are
# the same underlying DaddyLive catalogue via two different scrape paths —
# confirmed live: identical "<Name> <COUNTRY>" naming, same current embed
# host inside daddylive_channels.json's own playable_url strings. Rather
# than re-matching this catalogue against epgshare01 from scratch,
# bridge_daddylive_channels_epg.py (run on the scraper PC) name-matches its
# titles against tvnow247's own catalogue and inherits the tvg-id of
# whichever tvnow247 channel already has a confirmed EPG match — 334 of 773
# channels (43%) recovered this way with zero extra epgshare01 fetches.
DADDYLIVE_CHANNELS_EPG_BRIDGE_URL = 'https://hazmat77.github.io/repository.starfleet/data/daddylive_channels_epg_bridge.json'


# These two small JSON files only change when the scraper PC re-runs its
# matchers (manual/weekly, not something a user's export can ever race) —
# caching them (same 12h window live_sources.get_tvnow_channels() already
# uses for the same underlying data) means every "Export to TV Guide" after
# the first one skips 2 real network round-trips for no loss of freshness.
def _ensure_cache():
    from resources.lib import cache as _cache
    _cache.init(os.path.join(_profile_dir(), 'cache.db'))
    return _cache


def _tvnow_epg_matched_slugs():
    _cache = _ensure_cache()
    ck = 'pvr_daddylive_epg_matches_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    import requests
    try:
        r = requests.get(DADDYLIVE_EPG_MATCHES_URL, timeout=10)
        r.raise_for_status()
        result = set(r.json().keys())
    except Exception as e:
        xbmc.log('[Starfleet/PVR] daddylive_epg_matches fetch error: %s' % e, xbmc.LOGWARNING)
        return set()
    _cache.set(ck, result, 12 * 3600)
    return result


def _daddylive_channels_epg_bridge():
    _cache = _ensure_cache()
    ck = 'pvr_daddylive_channels_epg_bridge_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    import requests
    try:
        r = requests.get(DADDYLIVE_CHANNELS_EPG_BRIDGE_URL, timeout=10)
        r.raise_for_status()
        result = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/PVR] daddylive_channels_epg_bridge fetch error: %s' % e, xbmc.LOGWARNING)
        return {}
    _cache.set(ck, result, 12 * 3600)
    return result

# Prefer sources with a real, directly-playable stream_url and/or a
# confident free EPG match over ones that need special per-play
# resolution (Sinclair/TVA+) when a channel is offered by more than one.
_SOURCE_PREF = {'Pluto TV': 0, 'Samsung TV+': 1, 'Plex': 2, 'Sinclair': 3, 'TVA+': 4, 'Roku': 5, 'LG Channels': 6}


# ── Paths ─────────────────────────────────────────────────────────────────────

def _profile_dir():
    d = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/')
    if not xbmcvfs.exists(d):
        xbmcvfs.mkdirs(d)
    return d


def m3u_path():
    return os.path.join(_profile_dir(), 'starfleet_live.m3u8')


def channel_sources_path():
    return os.path.join(_profile_dir(), 'starfleet_live_channel_sources.json')


# ── Duplicate-channel merging ─────────────────────────────────────────────────
# json_data's offline daddylive_channels.json catalogue and live_sources'
# tvnow247 live scrape are confirmed live to be the SAME underlying
# DaddyLive channel set scraped two different ways (see
# DADDYLIVE_CHANNELS_EPG_BRIDGE_URL's own docstring above) — 425 of
# daddylive_channels.json's 773 channels match a tvnow247 channel by name.
# Rather than exporting both as separate M3U rows/EPG entries for the same
# real channel, this merges any name-match within a country into ONE row;
# a merged row's play_url routes through live_channel_picker, which shows a
# Dialog().select() of the available sources and resolves whichever one the
# user picks — the exact same "one listing, dialog shows every source"
# pattern this addon's own sports section already uses for cross-scraper
# game deduplication.

_RE_NONALNUM = re.compile(r'[^a-z0-9 ]')
_RE_MULTI_SP = re.compile(r' {2,}')
_RE_LETTER_DIGIT = re.compile(r'(?<=[a-z])(?=[0-9])')
_RE_DIGIT_LETTER = re.compile(r'(?<=[0-9])(?=[a-z])')
_MERGE_STRIP_TAIL = {'television', 'channel', 'network', 'tv', 'plus', 'hd', 'sd'}


def _merge_normalize(name):
    n = (name or '').lower()
    n = unicodedata.normalize('NFD', n)
    n = ''.join(c for c in n if unicodedata.category(c) != 'Mn')
    n = _RE_LETTER_DIGIT.sub(' ', n)
    n = _RE_DIGIT_LETTER.sub(' ', n)
    n = _RE_NONALNUM.sub(' ', n)
    n = _RE_MULTI_SP.sub(' ', n).strip()
    parts = [p for p in n.split() if p not in _MERGE_STRIP_TAIL]
    return ' '.join(parts)


def _merge_score(a, b):
    aw, bw = set(a.split()), set(b.split())
    if not aw or not bw:
        return 0.0
    if a == b:
        return 1.0
    return len(aw & bw) / max(len(aw), len(bw))


def _merged_channel_entries(dl_by_country, tvnow_channels, dl_bridge, tvnow_matched_slugs):
    """Returns (entries, merge_map). entries: list of (title, group, logo,
    tvg_id, play_url) — one per real channel, merged across json_data's
    offline catalogue and tvnow247's live scrape wherever they match by
    name within the same country. merge_map: {key: [candidate, ...]} for
    every merged (2+ source) row, written to disk by _channel_entries() for
    live_channel_picker to read at play time."""
    tvnow_by_country = {}
    for ch in (tvnow_channels or []):
        tvnow_by_country.setdefault(ch.get('group', 'Other'), []).append(ch)

    entries = []
    merge_map = {}
    merge_idx = 0

    for country, dl_chans in dl_by_country.items():
        tvnow_chans = tvnow_by_country.pop(country, [])
        norm_tvnow = [(_merge_normalize(c['title']), c) for c in tvnow_chans]
        claimed_tvnow_ids = set()

        for dl_ch in dl_chans:
            title = dl_ch.get('title', '')
            if not title:
                continue
            dl_tvg = dl_bridge.get(title, '')
            # Confirmed live 2026-08-29: dl_ch['playable_url'] is baked in
            # once by an external orchestrator scrape and goes stale/dead
            # well before a user actually clicks play (real report: a
            # channel exported this way failed with a plain HTTP error,
            # traced to an expired dlstreams.st-chain token). Routes
            # through play_daddylive_catalog instead, which re-resolves
            # fresh at play time against this addon's own already-working
            # dlstreams.st catalogue/resolver — see that function's own
            # docstring in router.py.
            dl_candidate = {'label': 'DaddyLive', 'action': 'play_daddylive_catalog',
                            'params': {'title': title}}

            norm_q = _merge_normalize(title)
            best_tvnow, best_score = None, 0
            if norm_q:
                for norm_name, tvnow_ch in norm_tvnow:
                    if tvnow_ch['id'] in claimed_tvnow_ids:
                        continue
                    s = _merge_score(norm_q, norm_name)
                    if s >= 0.6 and s > best_score:
                        best_tvnow, best_score = tvnow_ch, s

            if not best_tvnow:
                # See the merged (2+ source) branch below for why this
                # doesn't play dl_ch['playable_url'] directly any more —
                # same staleness bug, just without live_channel_picker to
                # route through here since there's only ever one candidate.
                entries.append((title, 'Live TV — %s' % country, dl_ch.get('logo', ''),
                                dl_tvg, '%s?action=play_daddylive_catalog&title=%s' %
                                (PLUGIN_BASE, _q(title))))
                continue

            claimed_tvnow_ids.add(best_tvnow['id'])
            tvnow_tvg = ('dl_%s' % best_tvnow['slug']) if best_tvnow['slug'] in tvnow_matched_slugs else ''
            tvnow_candidate = {'label': 'tvnow247', 'action': 'live_tvnow_channel_play',
                               'params': {'channel_id': best_tvnow['id'], 'title': best_tvnow['title']}}
            tvg_id = dl_tvg or tvnow_tvg
            logo = dl_ch.get('logo', '') or best_tvnow.get('thumbnail', '')

            key = '%s-%d' % (country, merge_idx)
            merge_idx += 1
            merge_map[key] = [dl_candidate, tvnow_candidate]
            play_url = '%s?action=live_channel_picker&key=%s' % (PLUGIN_BASE, _q(key))
            entries.append((title, 'Live TV — %s' % country, logo, tvg_id, play_url))

        # Any tvnow247 channels in this country that never matched a
        # daddylive_channels.json entry are still exported on their own,
        # exactly as before.
        for norm_name, tvnow_ch in norm_tvnow:
            if tvnow_ch['id'] in claimed_tvnow_ids:
                continue
            slug = tvnow_ch.get('slug', '')
            tvg_id = 'dl_%s' % slug if slug in tvnow_matched_slugs else ''
            entries.append((tvnow_ch['title'], 'Live TV — %s' % country, tvnow_ch.get('thumbnail', ''),
                            tvg_id, '%s?action=live_tvnow_channel_play&channel_id=%s&title=%s' %
                            (PLUGIN_BASE, _q(tvnow_ch['id']), _q(tvnow_ch['title']))))

    # tvnow247-only countries (no daddylive_channels.json entries at all for
    # that country) never went through the loop above — export as-is.
    for country, tvnow_chans in tvnow_by_country.items():
        for tvnow_ch in tvnow_chans:
            title = tvnow_ch.get('title', '')
            channel_id = tvnow_ch.get('id', '')
            if not title or not channel_id:
                continue
            slug = tvnow_ch.get('slug', '')
            tvg_id = 'dl_%s' % slug if slug in tvnow_matched_slugs else ''
            entries.append((title, 'Live TV — %s' % country, tvnow_ch.get('thumbnail', ''),
                            tvg_id, '%s?action=live_tvnow_channel_play&channel_id=%s&title=%s' %
                            (PLUGIN_BASE, _q(channel_id), _q(title))))

    return entries, merge_map


def _pvr_addon_data_dir():
    return xbmcvfs.translatePath('special://userdata/addon_data/%s/' % PVR_ADDON_ID)


def _instance_settings_path():
    """First existing instance-settings-N.xml, or -1 if none exists yet
    (a completely fresh pvr.iptvsimple install that's never been started)."""
    d = _pvr_addon_data_dir()
    if xbmcvfs.exists(d):
        dirs, files = xbmcvfs.listdir(d)
        candidates = sorted(f for f in files if re.match(r'instance-settings-\d+\.xml$', f))
        if candidates:
            return os.path.join(d, candidates[0])
    return os.path.join(d, 'instance-settings-1.xml')


# ── M3U building ──────────────────────────────────────────────────────────────

def _q(s):
    from urllib.parse import quote
    return quote(s or '', safe='')


def _esc(s):
    return (s or '').replace('"', "'").replace('\n', ' ').replace(',', ' ')


def _fetch_unified_group():
    """TVA + unified_live are the only two calls in _channel_entries() with
    a real dependency on each other (unified_live.get_all_channels() needs
    tva_channels as an argument) — kept as one sequential pair, run as a
    single task alongside the other independent fetches below."""
    from resources.lib import unified_live
    from resources.lib import api as _api
    tva_channels = _api.get_live_channels()
    return unified_live.get_all_channels(tva_channels=tva_channels) or []


_LIVE_EPG_XML = b''


def _entry_country(group):
    if group.startswith('Live TV — '):
        return group.split('— ', 1)[1].strip()
    if group == 'USTVNow':
        return 'US'
    if group.startswith('IPTV-org — '):
        return group.split('— ', 1)[1].strip().upper()
    return ''


def _guide_countries():
    """The countries whose channels get guide data: the ones picked for the TV guide (default US and Canada). Channels of every other
    country are still exported and play, they just have no programme list: fetching and scanning forty countries' guide packs
    (60 files, 160 MB) was what made the TV Guide take minutes - far longer on a Fire TV Stick."""
    codes = {'US', 'CA'}
    try:
        from resources.lib import iptvorg_live
        codes = {c.upper() for c in iptvorg_live.pvr_countries()} or codes
    except Exception:
        pass
    if 'GB' in codes:
        codes.add('UK')
    return codes


def _apply_live_epg(entries):
    """Give every country / USTVNow channel a guide id matched against epgshare01's current packs
    (see epg_live.py). The hosted daddylive_epg.xml these channels used to rely on is a manual
    scraper-PC export and had gone two months stale; its ids are only kept when the live match
    itself is unavailable (offline)."""
    global _LIVE_EPG_XML
    _LIVE_EPG_XML = b''
    home = _guide_countries()
    todo = [(str(i), e[0], _entry_country(e[1])) for i, e in enumerate(entries)
            if _entry_country(e[1]) in home and (not e[3] or e[3].startswith('dl_'))]
    if not todo:
        return entries
    try:
        from resources.lib import epg_live
        ids, xml, stats = epg_live.build(todo)
    except Exception as e:
        xbmc.log('[Starfleet/PVR] live guide build failed: %s' % e, xbmc.LOGWARNING)
        return entries
    if not ids:
        return entries
    _LIVE_EPG_XML = xml
    out = []
    for i, e in enumerate(entries):
        key = str(i)
        if key in ids:
            e = (e[0], e[1], e[2], ids[key], e[4])
        elif e[3].startswith('dl_'):
            e = (e[0], e[1], e[2], '', e[4])       # stale hosted ids would point at nothing now
        out.append(e)
    return out


def _channel_entries():
    """Every exportable channel as a
    (title, group, logo, tvg_id, play_url) tuple.

    The 6 network-touching fetches below (TVA+unified_live as one pair,
    json_data's by-country catalogue, tvnow247's live scrape, the DaddyLive
    EPG bridge, the tvnow EPG match-list, and Free Live Sports) don't
    actually depend on each other despite the old code fetching them one
    after another — _daddylive_channels_epg_bridge()/_tvnow_epg_matched_
    slugs() each hit their own fixed URL regardless of by_country/
    tvnow_channels' contents (confirmed live: they only ever gated on
    truthiness, never read the other's data). Confirmed live this was
    genuinely additive: 6 sequential calls, each with its own multi-second
    timeout, stacked into one long wait for the slowest possible sum
    instead of being bounded by the single slowest one — same footgun already
    fixed in metadata_router.py's _unified_source_search. Running them
    concurrently instead cuts a cold-cache "Export to TV Guide" build down
    to roughly its slowest single fetch rather than the sum of all six."""
    from resources.lib import json_data, live_sources
    from concurrent.futures import ThreadPoolExecutor
    entries = []

    def _safe(fn, label, default):
        try:
            return fn() or default
        except Exception as e:
            xbmc.log('[Starfleet/PVR] %s fetch error: %s' % (label, e), xbmc.LOGWARNING)
            return default

    # NOT a `with` block — same reason as every other ThreadPoolExecutor in
    # this codebase (metadata_router.py, scraper_sources.py, etc):
    # __exit__ would call shutdown(wait=True) and block on every submitted
    # task even after a straggler's own result is no longer needed.
    pool = ThreadPoolExecutor(max_workers=6)
    try:
        f_unified = pool.submit(_safe, _fetch_unified_group, 'unified_live', [])
        f_country = pool.submit(_safe, json_data.get_live_tv_channels_by_country, 'json_data', {})
        f_tvnow   = pool.submit(_safe, live_sources.get_tvnow_channels, 'tvnow247', [])
        f_bridge  = pool.submit(_safe, _daddylive_channels_epg_bridge, 'daddylive_channels_epg_bridge', {})
        f_matched = pool.submit(_safe, _tvnow_epg_matched_slugs, 'daddylive_epg_matches', set())
        f_fls     = pool.submit(_safe, live_sources.get_free_live_sports_channels, 'Free Live Sports', [])

        unified_groups      = f_unified.result()
        by_country          = f_country.result()
        tvnow_channels      = f_tvnow.result()
        dl_bridge           = f_bridge.result()
        tvnow_matched_slugs = f_matched.result()
        fls_channels        = f_fls.result()
    finally:
        pool.shutdown(wait=False)

    for group in unified_groups:
        sources = group.get('sources') or []
        if not sources:
            continue
        src = sorted(sources, key=lambda s: _SOURCE_PREF.get(s.get('source', ''), 9))[0]
        source = src.get('source', '')
        title  = group.get('title', '')
        ch_key = group.get('key', '')
        logo   = group.get('thumbnail', '') or src.get('thumbnail', '')
        if not title or not ch_key:
            continue

        if source in _OWN_EPG:
            tvg_id = src.get('ch_id', '')
        elif source == 'Sinclair':
            tvg_id = SINCLAIR_TVG_IDS.get(src.get('callsign', ''), '')
        elif source == 'TVA+':
            tvg_id = TVA_TVG_IDS.get(src.get('ch_id', ''), '')
        else:
            tvg_id = ''

        # Same plugin:// action + params as _open_live_tv_category's own
        # _on_play — one shared entry point that already knows how to pick
        # the right per-source resolver (play_live_dai/play_sinclair/
        # play_direct) for whichever source ends up being used at play time.
        play_url = '%s?action=live_unified_play&ch_key=%s&ch_title=%s' % (
            PLUGIN_BASE, _q(ch_key), _q(title))

        entries.append((title, source, logo, tvg_id, play_url))

    merged_entries, merge_map = _merged_channel_entries(
        by_country, tvnow_channels, dl_bridge, tvnow_matched_slugs)
    entries.extend(merged_entries)

    # Free Live Sports — simple direct-URL channels, no merge/picker needed
    # (one source, no dupes to reconcile against). Unlike everything above,
    # this source's EPG is embedded per-channel (live_sources.
    # get_free_live_sports_channels's 'epg_entries') rather than a separate
    # feed to fetch — _epg_urls_needed/_merge_xmltv below build it locally
    # instead of pointing at a URL.
    for ch in fls_channels:
        play_url = '%s?action=play_direct&stream_url=%s&ch_id=%s&source=%s&title=%s' % (
            PLUGIN_BASE, _q(ch['stream_url']), _q(ch['id']), _q('Free Live Sports'), _q(ch['title']))
        entries.append((ch['title'], 'Free Live Sports', ch['thumbnail'], ch['id'], play_url))

    # USTVNow: ~120 real U.S. channels with their own lazy resolver - not in any merged catalogue above
    try:
        for ch in (live_sources.get_ustvnow_channels() or []):
            link = (ch.get('stream_url') or '').split(':', 1)[-1]
            if not link or not ch.get('title'):
                continue
            entries.append((ch['title'], 'USTVNow', ch.get('thumbnail', ''), '',
                            '%s?action=play_ustvnow&ch_link=%s&title=%s' % (PLUGIN_BASE, _q(link), _q(ch['title']))))
    except Exception as e:
        xbmc.log('[Starfleet/PVR] USTVNow export error: %s' % e, xbmc.LOGWARNING)

    # IPTV-org: the countries the user picked (default US + Canada), newest lists; guide ids are matched below
    try:
        from resources.lib import iptvorg_live
        for title, stream_url, logo, cc in iptvorg_live.export_channels(iptvorg_live.pvr_countries()):
            entries.append((title, 'IPTV-org — %s' % cc, logo, '',
                            '%s?action=play_direct&stream_url=%s&ch_id=&source=IPTV-org&title=%s' % (
                                PLUGIN_BASE, _q(stream_url), _q(title))))
    except Exception as e:
        xbmc.log('[Starfleet/PVR] IPTV-org export error: %s' % e, xbmc.LOGWARNING)

    entries = _apply_live_epg(entries)

    try:
        with open(channel_sources_path(), 'w', encoding='utf-8') as f:
            json.dump(merge_map, f)
    except Exception as e:
        xbmc.log('[Starfleet/PVR] channel_sources write error: %s' % e, xbmc.LOGWARNING)

    return entries


def build_m3u(entries):
    lines = ['#EXTM3U']
    for title, group, logo, tvg_id, play_url in entries:
        attrs = 'tvg-id="%s" tvg-logo="%s" group-title="%s"' % (
            _esc(tvg_id), _esc(logo), _esc(group))
        lines.append('#EXTINF:-1 %s,%s' % (attrs, _esc(title)))
        lines.append(play_url)
    return '\n'.join(lines) + '\n'


def _epg_urls_needed(entries):
    sources_with_epg = set(e[1] for e in entries if e[3])  # group == source name, has tvg_id
    urls = []
    from resources.lib import epg_scrapers
    for src in _OWN_EPG:
        if src in sources_with_epg:
            data = epg_scrapers.inline_xmltv(src)
            if data:
                urls.append(('inline', data))
    if 'Sinclair' in sources_with_epg:
        data = epg_scrapers.sinclair_xmltv()
        if data:
            urls.append(('inline', data))
    if 'TVA+' in sources_with_epg:
        data = epg_scrapers.tva_xmltv()
        if data:
            urls.append(('inline', data))
    # tvnow247 entries are grouped by country ("Live TV — US"), not source
    # name, so they can't use the sources_with_epg lookup above — detect
    # them by their own "dl_" tvg-id prefix instead (see _channel_entries).
    if _LIVE_EPG_XML:
        urls.append(('inline', _LIVE_EPG_XML))
    elif any((e[3] or '').startswith('dl_') for e in entries):
        urls.append(DADDYLIVE_EPG_URL)
    if any((e[3] or '').startswith('fls-') for e in entries):
        urls.append(('inline', _free_live_sports_xmltv_bytes()))
    return urls


def _fls_xmltv_time(iso_str):
    """'2026-08-19T20:30:00.000Z' -> XMLTV's 'YYYYMMDDHHMMSS +0000'."""
    try:
        s = iso_str.replace('Z', '').split('.')[0]
        date_part, time_part = s.split('T')
        return date_part.replace('-', '') + time_part.replace(':', '') + ' +0000'
    except Exception:
        return ''


def _free_live_sports_xmltv_bytes():
    """Builds real XMLTV bytes directly from this source's own embedded
    per-channel schedule (live_sources.get_free_live_sports_channels's
    'epg_entries') — no third-party feed exists or is needed, unlike every
    other source's *_EPG_URL above."""
    import xml.etree.ElementTree as ET
    from resources.lib import live_sources
    root = ET.Element('tv', {'generator-info-name': 'starfleet-fls'})
    try:
        channels = live_sources.get_free_live_sports_channels() or []
    except Exception as e:
        xbmc.log('[Starfleet/PVR] Free Live Sports EPG build error: %s' % e, xbmc.LOGWARNING)
        channels = []
    for ch in channels:
        chan_el = ET.SubElement(root, 'channel', {'id': ch['id']})
        ET.SubElement(chan_el, 'display-name').text = ch['title']
        for prog in (ch.get('epg_entries') or []):
            start = _fls_xmltv_time(prog.get('start', ''))
            stop = _fls_xmltv_time(prog.get('stop', ''))
            if not start or not stop:
                continue
            prog_el = ET.SubElement(root, 'programme', {
                'start': start, 'stop': stop, 'channel': ch['id'],
            })
            ET.SubElement(prog_el, 'title').text = prog.get('title', '') or ch['title']
            if prog.get('description'):
                ET.SubElement(prog_el, 'desc').text = prog['description']
    return ET.tostring(root, encoding='utf-8')


def epg_path():
    return os.path.join(_profile_dir(), 'starfleet_epg.xml')


def _fetch_xmltv_bytes(url, timeout=25):
    import requests
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    data = r.content
    if url.endswith('.gz'):
        import gzip
        data = gzip.decompress(data)
    return data


def _merge_xmltv(urls, wanted=None):
    """pvr.iptvsimple only accepts ONE xmltv location per instance (its C++
    Epg::LoadEPG reads a single m_xmltvLocation string, not a list) —
    confirmed against its own source after a first version of this file
    wrongly assumed epgUrl took a comma-separated list, which silently
    loaded nothing at all. So instead of pointing at multiple remote URLs,
    fetch every needed source ourselves and merge their <channel>/
    <programme> elements into one combined local XMLTV file."""
    import xml.etree.ElementTree as ET

    root = ET.Element('tv', {'generator-info-name': 'starfleet'})
    fetched = 0
    for url in urls:
        try:
            if isinstance(url, tuple) and url[0] == 'inline':
                data = url[1]
            else:
                data = _fetch_xmltv_bytes(url)
            src_root = ET.fromstring(data)
            for child in src_root:
                if child.tag == 'channel' and (wanted is None or child.get('id') in wanted):
                    root.append(child)
                elif child.tag == 'programme' and (wanted is None or child.get('channel') in wanted):
                    root.append(child)
            fetched += 1
        except Exception as e:
            label = url if isinstance(url, str) else 'built-in guide (inline)'
            xbmc.log('[Starfleet/PVR] EPG fetch/parse failed for %s: %s' % (label[:70], e),
                      xbmc.LOGWARNING)

    path = epg_path()
    ET.ElementTree(root).write(path, encoding='utf-8', xml_declaration=True)
    return path, fetched


# ── pvr.iptvsimple instance config ────────────────────────────────────────────

# Full known schema of a real instance-settings-N.xml, captured from a live
# file on Kodi 21 / pvr.iptvsimple 21.11.0 — used only to create a brand
# new instance file from scratch when none exists yet. An EXISTING file is
# patched in place instead (every field it already has is preserved).
_DEFAULT_INSTANCE_FIELDS = [
    ('m3uPathType', '0'), ('m3uPath', ''), ('m3uUrl', ''), ('m3uCache', 'false'),
    ('startNum', '1'), ('numberByOrder', 'false'),
    ('m3uRefreshMode', '0'), ('m3uRefreshIntervalMins', '60'), ('m3uRefreshHour', '4'),
    ('connectioncheckinterval', '10'), ('connectionchecktimeout', '20'),
    ('defaultProviderName', ''), ('enableProviderMappings', 'false'),
    ('providerMappingFile', 'special://userdata/addon_data/pvr.iptvsimple/providers/providerMappings.xml'),
    ('tvGroupMode', '0'), ('numTvGroups', '1'),
    ('oneTvGroup', ''), ('twoTvGroup', ''), ('threeTvGroup', ''), ('fourTvGroup', ''), ('fiveTvGroup', ''),
    ('customTvGroupsFile', 'special://userdata/addon_data/pvr.iptvsimple/channelGroups/customTVGroups-example.xml'),
    ('tvChannelGroupsOnly', 'false'),
    ('radioGroupMode', '0'), ('numRadioGroups', '1'),
    ('oneRadioGroup', ''), ('twoRadioGroup', ''), ('threeRadioGroup', ''), ('fourRadioGroup', ''), ('fiveRadioGroup', ''),
    ('customRadioGroupsFile', 'special://userdata/addon_data/pvr.iptvsimple/channelGroups/customRadioGroups-example.xml'),
    ('radioChannelGroupsOnly', 'false'),
    ('epgPathType', '1'), ('epgPath', ''), ('epgUrl', ''), ('epgCache', 'false'),
    ('epgTimeShift', '0'), ('epgTSOverride', 'false'), ('epgIgnoreCaseForChannelIds', 'true'),
    ('useEpgGenreText', 'false'), ('genresPathType', '0'),
    ('genresPath', 'special://userdata/addon_data/pvr.iptvsimple/genres/genreTextMappings/genres.xml'),
    ('genresUrl', ''),
    ('logoPathType', '1'), ('logoPath', ''), ('logoBaseUrl', ''),
    ('useLogosLocalPathOnly', 'false'), ('logoFromEpg', '1'),
    ('mediaEnabled', 'true'), ('mediaGroupByTitle', 'true'), ('mediaGroupBySeason', 'true'),
    ('mediaTitleSeasonEpisode', 'false'), ('mediaM3UGroupPath', '2'),
    ('mediaForcePlaylist', 'false'), ('mediaVODAsRecordings', 'true'),
    ('timeshiftEnabled', 'false'), ('timeshiftEnabledAll', 'true'),
    ('timeshiftEnabledHttp', 'true'), ('timeshiftEnabledUdp', 'true'), ('timeshiftEnabledCustom', 'false'),
    ('catchupEnabled', 'false'), ('catchupQueryFormat', ''), ('catchupDays', '5'),
    ('allChannelsCatchupMode', '0'), ('catchupOverrideMode', '0'), ('catchupCorrection', '0'),
    ('catchupPlayEpgAsLive', 'false'), ('catchupWatchEpgBeginBufferMins', '5'),
    ('catchupWatchEpgEndBufferMins', '15'), ('catchupOnlyOnFinishedProgrammes', 'false'),
    ('transformMulticastStreamUrls', 'false'),
    ('udpxyHost', '127.0.0.1'), ('udpxyPort', '4022'),
    ('useFFmpegReconnect', 'true'), ('useInputstreamAdaptiveforHls', 'false'),
    ('defaultUserAgent', ''), ('defaultInputstream', ''), ('defaultMimeType', ''),
]


def _parse_instance_xml(text):
    """Minimal, dependency-free parse of <setting id="x">value</setting>
    into an ordered {id: value} dict — avoids pulling in a full XML lib
    just to round-trip this simple, flat format."""
    fields = {}
    for m in re.finditer(r'<setting id="([^"]+)"[^>]*>(.*?)</setting>|<setting id="([^"]+)"[^>]*/>', text):
        if m.group(1) is not None:
            fields[m.group(1)] = m.group(2)
        else:
            fields[m.group(3)] = ''
    return fields


def _write_instance_xml(path, fields):
    lines = ['<settings version="2">']
    for k, v in fields.items():
        if v == '':
            lines.append('    <setting id="%s" />' % k)
        else:
            lines.append('    <setting id="%s">%s</setting>' % (k, v))
    lines.append('</settings>')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def _configure_iptv_simple(m3u_file, epg_file):
    path = _instance_settings_path()
    d = os.path.dirname(path)
    if not xbmcvfs.exists(d + ('/' if not d.endswith(('/', '\\')) else '')):
        xbmcvfs.mkdirs(d)

    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            fields = _parse_instance_xml(f.read())
    else:
        fields = {'kodi_addon_instance_name': INSTANCE_NAME,
                  'kodi_addon_instance_enabled': 'true'}
        for k, v in _DEFAULT_INSTANCE_FIELDS:
            fields.setdefault(k, v)

    fields['kodi_addon_instance_name']    = fields.get('kodi_addon_instance_name') or INSTANCE_NAME
    fields['kodi_addon_instance_enabled'] = 'true'
    fields['m3uPathType'] = '0'          # 0 = local path
    fields['m3uPath']     = m3u_file
    fields['m3uCache']    = 'false'      # our file already reflects the latest export
    if epg_file:
        fields['epgPathType'] = '0'      # 0 = local path — merged combined XMLTV, see _merge_xmltv
        fields['epgPath']     = epg_file
        fields['epgUrl']      = ''       # clear any stale remote URL from an older export
        fields['epgCache']    = 'false'

    _write_instance_xml(path, fields)
    return True


def _restart_pvr_addon():
    """Toggle pvr.iptvsimple off/on via JSON-RPC so it re-reads the
    instance file — the same lifecycle Kodi's own PVR settings dialog
    triggers when you save changes there."""
    import json as _json

    def _call(method, params):
        req = _json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})
        try:
            return _json.loads(xbmc.executeJSONRPC(req))
        except Exception as e:
            xbmc.log('[Starfleet/PVR] JSON-RPC %s error: %s' % (method, e), xbmc.LOGWARNING)
            return {}

    _call('Addons.SetAddonEnabled', {'addonid': PVR_ADDON_ID, 'enabled': False})
    xbmc.sleep(700)
    result = _call('Addons.SetAddonEnabled', {'addonid': PVR_ADDON_ID, 'enabled': True})
    return 'error' not in result


def is_pvr_addon_installed():
    try:
        xbmcaddon.Addon(PVR_ADDON_ID)
        return True
    except Exception:
        return False


def install_pvr_addon(timeout=25):
    """Trigger Kodi's own JSON-RPC Addons.InstallAddon for pvr.iptvsimple
    instead of just telling the user to go install it themselves — it's an
    official-repo addon (already declared as an optional dependency in
    addon.xml), so Kodi can fetch and install it on request the same way it
    already auto-offers to during a Starfleet update, just without waiting
    for that update. Polls is_pvr_addon_installed() afterward since
    InstallAddon's own JSON-RPC response returns before the actual
    download/install finishes. Returns True once installed (or already
    was), False if it never completed within `timeout` seconds.

    Confirmed live 2026-08-20 this can genuinely fail silently: the old
    version of this function never logged the JSON-RPC call's own response,
    so a real attempt just showed 25s of is_pvr_addon_installed()'s own
    "Unknown addon id" polling noise with zero indication of WHETHER
    InstallAddon itself returned a real error (unsupported method, addon
    not visible in any enabled repo, etc.) or a genuine success that simply
    hadn't finished downloading yet. Logging the raw response now so the
    next real attempt's log says which one actually happened instead of
    guessing a 2nd fix blind."""
    import json as _json
    if is_pvr_addon_installed():
        return True
    try:
        req = _json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.InstallAddon',
                           'params': {'addonid': PVR_ADDON_ID}})
        resp = xbmc.executeJSONRPC(req)
        xbmc.log('[Starfleet/PVR] Addons.InstallAddon response: %s' % resp, xbmc.LOGINFO)
        parsed = _json.loads(resp)
        if 'error' in parsed:
            xbmc.log('[Starfleet/PVR] Addons.InstallAddon returned an error, not attempting to poll: %s'
                     % parsed['error'], xbmc.LOGWARNING)
            return False
    except Exception as e:
        xbmc.log('[Starfleet/PVR] Addons.InstallAddon error: %s' % e, xbmc.LOGWARNING)
        return False

    waited = 0.0
    while waited < timeout:
        xbmc.sleep(500)
        waited += 0.5
        if is_pvr_addon_installed():
            xbmc.log('[Starfleet/PVR] pvr.iptvsimple became installed after %.1fs' % waited, xbmc.LOGINFO)
            return True
    xbmc.log('[Starfleet/PVR] pvr.iptvsimple still not installed after %.1fs — giving up' % timeout,
             xbmc.LOGWARNING)
    return False


_FRESH_SECS = 6 * 3600


def _meta_path():
    return os.path.join(_profile_dir(), 'pvr_export_meta.json')


def _read_meta():
    try:
        with open(_meta_path(), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def export_and_configure(force=False, restart=True):
    """Build the M3U, write it to disk, merge every needed free EPG source
    into one local XMLTV file, point pvr.iptvsimple at both, and restart
    the PVR client so Kodi picks it up. Returns
    (channel_count, epg_source_count, ok).

    A list and guide built in the last six hours (and a PVR client that is installed and already pointed at them) are reused: the
    TV Guide then opens at once. `force` rebuilds anyway; `restart=False` (the background refresh) leaves the PVR client alone."""
    meta = _read_meta()
    if (not force and meta.get('t') and time.time() - meta['t'] < _FRESH_SECS and os.path.exists(m3u_path())
            and (not meta.get('epg') or os.path.exists(epg_path())) and is_pvr_addon_installed()):
        xbmc.log('[Starfleet/PVR] reusing the guide built %d min ago' % ((time.time() - meta['t']) // 60), xbmc.LOGINFO)
        return meta.get('count', 0), meta.get('epg_count', 0), True
    entries = _channel_entries()
    m3u_text = build_m3u(entries)
    path = m3u_path()
    with open(path, 'w', encoding='utf-8') as f:
        f.write(m3u_text)

    epg_urls = _epg_urls_needed(entries)
    epg_file, epg_fetched = (None, 0)
    if epg_urls:
        epg_file, epg_fetched = _merge_xmltv(epg_urls, {e[3] for e in entries if e[3]})   # only channels we export

    if not is_pvr_addon_installed():
        xbmc.log('[Starfleet/PVR] pvr.iptvsimple not installed', xbmc.LOGWARNING)
        return len(entries), epg_fetched, False

    _configure_iptv_simple(path, epg_file)
    ok = _restart_pvr_addon() if restart else True
    if ok:
        try:
            with open(_meta_path(), 'w', encoding='utf-8') as f:
                json.dump({'t': time.time(), 'count': len(entries), 'epg_count': epg_fetched, 'epg': bool(epg_file)}, f)
        except Exception:
            pass
    return len(entries), epg_fetched, ok


def refresh_if_used():
    """Background job: once the TV Guide has been used, rebuild it every few hours (quietly, without restarting the PVR client) so the
    next visit finds it ready."""
    meta = _read_meta()
    if meta.get('t') and time.time() - meta['t'] > _FRESH_SECS - 3600:
        export_and_configure(force=True, restart=False)
    return None
