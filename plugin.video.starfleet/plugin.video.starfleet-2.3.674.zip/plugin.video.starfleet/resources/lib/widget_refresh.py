# -*- coding: utf-8 -*-
"""
resources/lib/widget_refresh.py

A full refresh of every Home widget row (Movies, TV, Anime, Sports, Live, Radio, Adult, the profile's recommendations), done on
demand instead of at the next launch.

Home reads its rows from home_data.json, which a background refresh rewrites each time Home opens. The Adult rows are only built
while "Show Adult section in main menu" is on, so turning it on left the Adult tab empty until Kodi was closed and Home opened
again. Now that setting being switched on (from Home's Settings button, or from anywhere else: the service watches for it) runs
refresh_all(), which rebuilds all of the rows, saves them for the next Home and hands them to a Home window that is open.

refresh_all() takes the same refresh.lock Home's own background refresh uses, so two refreshes never run at once: one that finds
the lock held waits for it to end and then uses what that refresh saved.
"""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcvfs

LOCK_STALE = 90                       # seconds after which a refresh.lock is taken over (the same limit run_home.py uses)
WAIT_MAX = 100


def _log(msg):
    xbmc.log('[Starfleet/WidgetRefresh] %s' % msg, xbmc.LOGINFO)


def adult_on():
    try:
        return xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
    except Exception:
        return False


def _paths():
    from resources.lib import profiles as _profiles
    data_dir = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(data_dir, exist_ok=True)
    return os.path.join(data_dir, 'refresh.lock'), os.path.join(_profiles.data_dir(), 'home_data.json')


def load_saved():
    """The rows Home last saved ({context: [row, row, row, row]}), or None."""
    try:
        with open(_paths()[1], 'r', encoding='utf-8') as f:
            raw = json.load(f)
        return raw if isinstance(raw, dict) else None
    except Exception:
        return None


def _take_lock(lock):
    try:
        if os.path.exists(lock) and time.time() - os.path.getmtime(lock) < LOCK_STALE:
            return False
        with open(lock, 'w') as f:
            f.write('widget_refresh')
        return True
    except Exception:
        return True                   # the lock itself failing is no reason not to refresh


def refresh_all(reason=''):
    """Rebuild every Home row now and save them; returns the rows ({context: [...]}) or None when nothing could be built.
    Safe to call from any process. Blocks for as long as the build takes (seconds to a minute): run it from a thread."""
    try:
        lock, data_file = _paths()
        if not _take_lock(lock):                                     # another refresh is running: wait for it, use its result
            _log('a refresh is already running - waiting for it (%s)' % reason)
            mon = xbmc.Monitor()
            end = time.time() + WAIT_MAX
            while os.path.exists(lock) and time.time() < end and not mon.abortRequested():
                if mon.waitForAbort(1):
                    return None
            saved = load_saved()
            if saved and (not adult_on() or any(row for row in saved.get('adult', []))):
                return saved
            if not _take_lock(lock):
                return saved
        try:
            t0 = time.time()
            from resources.lib import afdb_router as _ar
            from resources.lib import profiles as _profiles
            if adult_on():
                try:
                    _ar.prewarm_adult_rows()                         # the slow part of the Adult rows, remembered on disk
                except Exception as e:
                    _log('adult prewarm: %s' % e)
            rows = _profiles.filter_rows(_ar.get_home_carousel_data())
            tmp = data_file + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(rows, f)
            os.replace(tmp, data_file)
            _log('all widgets refreshed in %.1f s (%s): %s' % (time.time() - t0, reason or 'on request',
                 ', '.join('%s=%d' % (k, sum(len(r) for r in v)) for k, v in rows.items() if isinstance(v, list))))
            try:
                import xbmcgui
                xbmcgui.Window(10000).setProperty('sf_widgets_refreshed', str(int(time.time())))
            except Exception:
                pass
            return rows
        finally:
            try:
                os.remove(lock)
            except Exception:
                pass
    except Exception as e:
        _log('refresh failed: %s' % e)
        return None
