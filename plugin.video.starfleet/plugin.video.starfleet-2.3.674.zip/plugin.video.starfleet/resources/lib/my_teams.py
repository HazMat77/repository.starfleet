# -*- coding: utf-8 -*-
"""
resources/lib/my_teams.py

My Teams: the teams the viewer follows (stored in my_teams.json), each team's live or next game with its start time in local
time or its live score, the Home sports row built from them, and the lists used to add a team.

A game is found by matching the team name against the two teams in the sports event list (any common spelling: "Celtics",
"Boston Celtics", "LA Clippers"/"Los Angeles Clippers" - see live_scores.team_matches). Live scores come from the same
scoreboards the sports lists use. Nothing here makes the viewer wait: every network call goes through the event / scoreboard
caches the sports lists already use.
"""
import json
import os
import re
import threading
import time

import xbmc

FILE = 'my_teams.json'
# sports that have teams (individual sports - UFC, boxing, F1, tennis - have none to follow: see my_events.py)
TEAM_SPORTS = ('nfl', 'nba', 'mlb', 'nhl', 'soccer', 'cfb', 'ncaab', 'cfl', 'wnba', 'pwhl', 'ncaaw', 'ncaah')
_LOCK = threading.Lock()
_SPLIT = re.compile(r'\s+(?:vs\.?|v|@|at)\s+|\s+-\s+', re.I)


def _log(msg):
    xbmc.log('[Starfleet/MyTeams] %s' % msg, xbmc.LOGINFO)


def _path():
    from resources.lib import profiles as _profiles          # each viewer profile follows its own teams
    return _profiles.data_path(FILE)


def teams():
    """[{'name', 'sport', 'logo'}] in the order they were followed."""
    try:
        with open(_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return [t for t in d if isinstance(t, dict) and t.get('name') and t.get('sport')]
    except Exception:
        return []


def _save(lst):
    p = _path()
    with open(p + '.tmp', 'w', encoding='utf-8') as f:
        json.dump(lst, f)
    os.replace(p + '.tmp', p)


def _same(a, b):
    return re.sub(r'\W+', '', a.lower()) == re.sub(r'\W+', '', b.lower())


def is_followed(name, sport):
    return any(_same(t['name'], name) and t['sport'] == sport for t in teams())


def follow(name, sport, logo=''):
    """True when the team was added (False: already followed or empty name)."""
    name = (name or '').strip()
    if not name or not sport:
        return False
    with _LOCK:
        lst = teams()
        if any(_same(t['name'], name) and t['sport'] == sport for t in lst):
            return False
        lst.append({'name': name, 'sport': sport, 'logo': logo or ''})
        _save(lst)
    _log('following %s (%s)' % (name, sport))
    return True


def unfollow(name, sport):
    with _LOCK:
        lst = teams()
        keep = [t for t in lst if not (_same(t['name'], name) and t['sport'] == sport)]
        if len(keep) != len(lst):
            _save(keep)
            return True
    return False


# ── games ───────────────────────────────────────────────────────────────────────────────────────────────────────────

def parse_teams(title):
    """The two team names in an event title: 'NHL : Montreal Canadiens vs Chicago Blackhawks' -> (Montreal Canadiens, Chicago
    Blackhawks). One name (and '') when the title does not split."""
    t = title or ''
    if ' : ' in t:
        t = t.split(' : ')[-1]
    parts = _SPLIT.split(t, maxsplit=1)                              # split first: '@' is a separator, not noise
    parts = [re.sub(r'\s+', ' ', re.sub(r'[^\w\s.\'&/-]', ' ', p, flags=re.UNICODE)).strip() for p in parts]   # flags, emoji
    return (parts[0], parts[1]) if len(parts) == 2 else (parts[0], '')


def event_has_team(ev, name):
    from starfleetscrapers.sports import live_scores as _ls
    a, b = parse_teams(ev.get('match_title') or ev.get('title') or '')
    return bool((a and _ls.team_matches(name, a)) or (b and _ls.team_matches(name, b)))


def _team_logo(ev, name):
    from starfleetscrapers.sports import live_scores as _ls
    home = ev.get('home_team') or ''
    if home and _ls.team_matches(name, home):
        return ev.get('home_badge') or ev.get('logo') or ''
    return ev.get('away_badge') or ev.get('logo') or ev.get('home_badge') or ''


def _events(sport):
    """The sport's event list with live scores attached (both cached by the sports lists themselves)."""
    from resources.lib import sports_sources as _ss
    from resources.lib import sports_router as _sr
    return _sr.prepare_events(sport, _ss.get_sport_events(sport))


def next_game(team, events=None):
    """The team's live game, else its next one (the latest one that started in the last 3 hours counts as still on)."""
    evs = events if events is not None else _events(team['sport'])
    now = time.time()
    mine = [e for e in evs if event_has_team(e, team['name']) and e.get('game_state') != 'post']
    live = [e for e in mine if e.get('is_live')]
    if live:
        return live[0]
    upcoming = sorted((e for e in mine if (e.get('start_ts') or 0) >= now - 3 * 3600), key=lambda e: e['start_ts'])
    return upcoming[0] if upcoming else None


def rows():
    """[(team dict, its live / next game or None)] for the My Teams screen, live games first, then by start time."""
    cache, out = {}, []
    for t in teams():
        if t['sport'] not in cache:
            try:
                cache[t['sport']] = _events(t['sport'])
            except Exception as e:
                _log('events for %s: %s' % (t['sport'], e))
                cache[t['sport']] = []
        out.append((t, next_game(t, cache[t['sport']])))
    out.sort(key=lambda r: (0 if (r[1] and r[1].get('is_live')) else 1, (r[1] or {}).get('start_ts') or 9e12))
    return out


def home_row(per_row=20):
    """Home carousel items (same shape as the sports rows) for the followed teams' live / next games, one game once."""
    items, seen = [], set()
    for t, ev in rows():
        if not ev or ev.get('id') in seen:
            continue
        seen.add(ev.get('id'))
        from resources.lib import sports_router as _sr
        when, _c = _sr.event_when(ev)
        plot = '%s%s' % (when, (' • ' + ev['score_line']) if ev.get('score_line') else '')
        logo = _team_logo(ev, t['name']) or t.get('logo', '')
        items.append({
            'id': ev.get('id', ''), 'title': ev.get('match_title') or ev.get('title', ''), 'thumb': logo,
            'fanart': ev.get('away_badge') or ev.get('logo') or logo, 'plot': '%s — %s' % (t['name'], plot),
            'source': 'sports', 'sport_slug': t['sport'], 'event_id': ev.get('id', ''), 'event_path': ev.get('path', ''),
            'media_type': 'event',
        })
        if len(items) >= per_row:
            break
    return items


# ── adding a team ───────────────────────────────────────────────────────────────────────────────────────────────────

def candidates(sport):
    """[(team name, logo)] for the sport: the scoreboard's teams first (their official names), then the event list's."""
    from starfleetscrapers.sports import live_scores as _ls
    out, seen = [], set()

    def add(name, logo=''):
        k = re.sub(r'\W+', '', (name or '').lower())
        if k and k not in seen and not is_followed(name, sport):
            seen.add(k)
            out.append((name.strip(), logo))
    try:
        for g in _ls.games(sport):
            add(g['home'])
            add(g['away'])
    except Exception as e:
        _log('scoreboard teams: %s' % e)
    try:
        for ev in _events(sport):
            a, b = parse_teams(ev.get('match_title') or ev.get('title') or '')
            if b:                                   # a real "A vs B" game, not a channel
                add(a, ev.get('away_badge') or ev.get('logo') or '')
                add(b, ev.get('home_badge') or '')
    except Exception as e:
        _log('event teams: %s' % e)
    return sorted(out, key=lambda t: t[0].lower())
