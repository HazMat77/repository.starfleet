# -*- coding: utf-8 -*-
"""
resources/lib/setup.py

First-run dependency checker. Auto-installs ResolveURL directly from
GitHub releases (no repository addon needed) if it is missing.
"""

import os
import zipfile
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

_GUJAL_API_URL  = 'https://api.github.com/repos/Gujal00/ResolveURL/releases/latest'
_ADDONS_DIR     = 'special://home/addons/'


def _addon_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except RuntimeError:
        return False


def _get_resolveurl_asset_url():
    """
    Use the GitHub API to find the actual download URL for the latest
    script.module.resolveurl zip — avoids hard-coding a filename that
    may not match the release assets.
    """
    import requests
    try:
        r = requests.get(_GUJAL_API_URL, timeout=15)
        r.raise_for_status()
        for asset in r.json().get('assets', []):
            name = asset.get('name', '')
            if 'resolveurl' in name.lower() and name.endswith('.zip'):
                url = asset['browser_download_url']
                xbmc.log('[Starfleet/Setup] ResolveURL asset: %s' % url, xbmc.LOGINFO)
                return url
    except Exception as e:
        xbmc.log('[Starfleet/Setup] GitHub API error: %s' % e, xbmc.LOGERROR)
    return None


def _download_to_tmp(url):
    """Stream-download url to a temp file. Returns local path or None."""
    import requests
    tmp = xbmcvfs.translatePath('special://temp/script.module.resolveurl.zip')
    try:
        r = requests.get(url, timeout=60, stream=True)
        r.raise_for_status()
        with open(tmp, 'wb') as f:
            for chunk in r.iter_content(65536):
                f.write(chunk)
        if os.path.exists(tmp) and os.path.getsize(tmp) > 1000:
            return tmp
    except Exception as e:
        xbmc.log('[Starfleet/Setup] download error: %s' % e, xbmc.LOGERROR)
    return None


def _extract_zip(zip_path):
    addons_path = xbmcvfs.translatePath(_ADDONS_DIR)
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(addons_path)
        return True
    except Exception as e:
        xbmc.log('[Starfleet/Setup] extract error: %s' % e, xbmc.LOGERROR)
        return False


def _install_resolveurl():
    """Download the latest ResolveURL zip directly from GitHub and extract it."""
    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet Setup', 'Finding latest ResolveURL...')
    dlg.update(10)

    url = _get_resolveurl_asset_url()
    if not url:
        dlg.close()
        xbmcgui.Dialog().ok(
            'Starfleet Setup',
            'Could not locate ResolveURL release on GitHub.\n\n'
            'Install manually:\n'
            '1. Go to github.com/Gujal00/ResolveURL\n'
            '2. Download the latest script.module.resolveurl zip\n'
            '3. Add-ons → Install from zip'
        )
        return False

    dlg.update(20, 'Downloading ResolveURL...')
    tmp = _download_to_tmp(url)
    dlg.update(70)

    if not tmp:
        dlg.close()
        xbmcgui.Dialog().ok(
            'Starfleet Setup',
            'Download failed.\nCheck your internet connection and try again.\n\n'
            'Or install manually from: github.com/Gujal00/ResolveURL'
        )
        return False

    dlg.update(80, 'Installing ResolveURL...')
    ok = _extract_zip(tmp)
    dlg.update(100)
    dlg.close()

    if ok:
        xbmc.executebuiltin('UpdateLocalAddons', True)
        xbmc.sleep(1000)
    return ok


def check_and_guide():
    """
    Check for ResolveURL on every startup.
    If missing, offer to auto-install directly from GitHub releases.
    No repository addon required.
    """
    if _addon_installed('script.module.resolveurl'):
        return

    xbmc.log('[Starfleet/Setup] ResolveURL not found — prompting install', xbmc.LOGINFO)

    answer = xbmcgui.Dialog().yesno(
        'Starfleet — Install ResolveURL?',
        'ResolveURL is not installed.\n\n'
        'It resolves stream links for Adult streams and other hosters '
        '(StreamTape, DoodStream, MyVidPlay, etc.).\n\n'
        'Install now? (downloads latest from github.com/Gujal00/ResolveURL)'
    )

    if not answer:
        return

    ok = _install_resolveurl()

    if ok and _addon_installed('script.module.resolveurl'):
        xbmcgui.Dialog().notification(
            'Starfleet Setup',
            'ResolveURL installed successfully!',
            xbmcgui.NOTIFICATION_INFO, 4000
        )
        xbmc.log('[Starfleet/Setup] ResolveURL installed OK', xbmc.LOGINFO)
    elif ok:
        xbmcgui.Dialog().ok(
            'Starfleet Setup',
            'ResolveURL was extracted but Kodi has not registered it yet.\n'
            'Please restart Kodi, then it should work.'
        )
    else:
        xbmcgui.Dialog().ok(
            'Starfleet Setup',
            'ResolveURL could not be installed automatically.\n\n'
            'Install manually:\n'
            '1. Go to github.com/Gujal00/ResolveURL\n'
            '2. Download the latest script.module.resolveurl zip\n'
            '3. Add-ons → Install from zip'
        )
