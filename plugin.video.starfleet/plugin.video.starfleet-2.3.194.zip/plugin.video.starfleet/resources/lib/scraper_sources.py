﻿# -*- coding: utf-8 -*-
"""
resources/lib/scraper_sources.py

Free streaming scrapers for movies, TV shows, and adult content.
Covers sites from the user-supplied list that are not already handled
by free_sources.py (Popcornflix/Tubi) or adult_streams.py.

Sources:
  cuevana3.eu     — Spanish-language streaming, iframe embeds
  hdtodayz.to     — General streaming aggregator, iframe embeds
  netmirror.app   — Mirror/aggregator, embed players
  zaxflix.com     — WordPress streaming, iframe embeds
  rarefilmm.com   — Classic/rare film archive, direct links
  1shows.org      — TV shows + movies, WordPress streaming
  456movie.nl     — General streaming, iframe embeds
  msearch.vercel.app — Meta-search aggregator (JSON API)

Each site scraper:
  1. Hits the site's search endpoint with the query title
  2. Parses film cards from the results HTML
  3. Fetches each film's detail page to extract embed/stream URLs
  4. Returns a list of film dicts compatible with adult_streams.py format:
     { 'id', 'title', 'title_norm', 'thumb', 'description', 'url',
       'source', 'streams': [{'label', 'url'}] }

search_all_scrapers(title, media_type) runs all scrapers in parallel and
returns a flat list of stream dicts: [{'label', 'url', 'source'}].
"""

import re
import unicodedata
import xbmc
import xbmcaddon
import xbmcvfs

ADDON     = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

try:
    import requests as _requests
    from resources.lib import cache as _cache
    _cache.init(_CACHE_DB)
    _HAS_REQUESTS = True
except Exception:
    _HAS_REQUESTS = False

CUEVANA3_BASE  = 'https://www.cuevana3.eu'
HDTODAYZ_BASE  = 'https://hdtodayz.to'
NETMIRROR_BASE = 'https://netmirror.app'
ZAXFLIX_BASE   = 'https://zaxflix.com'
RAREFILMM_BASE = 'https://rarefilmm.com'
SHOWS1_BASE    = 'https://www.1shows.org'
M456_BASE      = 'https://456movie.nl'
MSEARCH_BASE   = 'https://msearch.vercel.app'

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
}

_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE = re.compile(r'\s+')
_RE_NONALNUM   = re.compile(r'[^a-z0-9 ]')
_STREAM_SKIP   = re.compile(
    r'(?:rapidgator|nitroflare|keep2share|uploaded\.net|frdl\.io|'
    r'facebook\.com|twitter\.com|google\.com|youtube\.com)',
    re.IGNORECASE
)

_session    = None
_cf_session = None


def _sess():
    global _session
    if not _HAS_REQUESTS:
        return None
    if _session is None:
        _session = _requests.Session()
        _session.headers.update(_HEADERS)
        a = _requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=12,
            max_retries=_requests.adapters.Retry(total=0)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _cf_sess():
    """Cloudflare-bypass session: cloudscraper if available, else plain requests."""
    global _cf_session
    if _cf_session is not None:
        return _cf_session
    try:
        import cloudscraper as _cs
        _cf_session = _cs.create_scraper(
            browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
        )
        _cf_session.headers.update(_HEADERS)
        return _cf_session
    except Exception:
        pass
    _cf_session = _sess()
    return _cf_session


# Domains known to use Cloudflare — use _cf_sess() for these
_CF_DOMAINS = (
    'hdtodayz.to', 'zaxflix.com', '456movie.nl', '1shows.org',
    'bbflix.watch', 'fmoviess.org', 'filmslook.com',
)


def _get(url, timeout=(6, 12)):
    s = _cf_sess() if any(d in url for d in _CF_DOMAINS) else _sess()
    if not s:
        return ''
    try:
        r = s.get(url, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] GET failed (%s): %s' % (url[:70], e), xbmc.LOGWARNING)
        return ''


def _get_json(url, timeout=(6, 12)):
    s = _cf_sess() if any(d in url for d in _CF_DOMAINS) else _sess()
    if not s:
        return None
    try:
        r = s.get(url, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] JSON GET failed (%s): %s' % (url[:70], e), xbmc.LOGWARNING)
        return None


def _clean(text):
    text = _RE_STRIP_TAGS.sub(' ', text)
    return _RE_WHITESPACE.sub(' ', text).strip()


def _og(html, prop):
    """Extract og: meta property value."""
    m = re.search(
        r'<meta[^>]+property=["\']og:%s["\'][^>]+content=["\']([^"\']+)["\']' % re.escape(prop),
        html, re.IGNORECASE
    )
    if not m:
        m = re.search(
            r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:%s["\']' % re.escape(prop),
            html, re.IGNORECASE
        )
    return _clean(m.group(1)) if m else ''


def _norm_title(title):
    title = title.lower()
    title = ''.join(
        c for c in unicodedata.normalize('NFD', title)
        if unicodedata.category(c) != 'Mn'
    )
    title = _RE_NONALNUM.sub('', title)
    return _RE_WHITESPACE.sub(' ', title).strip()


def _extract_embeds(html):
    """Extract all playable iframe/embed/data-* URLs from an HTML page."""
    seen, embeds = set(), []

    # iframes
    for m in re.finditer(
        r'<iframe[^>]+(?:src|data-src)=["\']([^"\']{10,})["\']', html, re.IGNORECASE
    ):
        url = m.group(1).strip()
        if not url.startswith('http') or url in seen:
            continue
        if _STREAM_SKIP.search(url):
            continue
        seen.add(url)
        dom = re.search(r'https?://(?:www\.)?([^./]+)', url)
        label = dom.group(1).capitalize() if dom else 'Embed'
        embeds.append({'label': label, 'url': url})

    # data-* stream attributes (DooPlay / TPostMv themes)
    for m in re.finditer(
        r'data-(?:fl-url|src|embed|player|lazy-src)=["\']([^"\']{10,})["\']',
        html, re.IGNORECASE
    ):
        url = m.group(1).strip()
        if not url.startswith('http') or url in seen:
            continue
        if _STREAM_SKIP.search(url):
            continue
        seen.add(url)
        dom = re.search(r'https?://(?:www\.)?([^./]+)', url)
        label = dom.group(1).capitalize() if dom else 'Stream'
        embeds.append({'label': label, 'url': url})

    # Direct video file links (mp4 / m3u8 / mkv)
    for m in re.finditer(
        r'["\' ](https?://[^"\'<\s]+\.(?:mp4|m3u8|mkv|avi|mov)[^"\'<\s]*)["\' ]',
        html, re.IGNORECASE
    ):
        url = m.group(1).strip()
        if url in seen:
            continue
        seen.add(url)
        embeds.append({'label': 'Direct', 'url': url})

    return embeds


def _h1_title(html):
    m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
    return _clean(m.group(1)) if m else ''


def _strip_site_suffix(title):
    return re.sub(r'\s*[|\-–—].*$', '', title).strip()


def _cache_get(key):
    try:
        return _cache.get(key)
    except Exception:
        return None


def _cache_set(key, value, ttl):
    try:
        _cache.set(key, value, ttl)
    except Exception:
        pass


def _pfetch(stubs, fn, limit=5):
    """Fetch up to limit stubs concurrently, return non-None results."""
    from concurrent.futures import ThreadPoolExecutor
    batch = stubs[:limit]
    if not batch:
        return []
    with ThreadPoolExecutor(max_workers=min(len(batch), 5)) as pool:
        results = list(pool.map(fn, batch, timeout=20))
    return [r for r in results if r and r.get('streams')]


# ── cuevana3.eu ───────────────────────────────────────────────────────────────

_RE_CUEVANA_CARD = re.compile(
    r'href="(https?://(?:www\.)?cuevana3\.[a-z]+/(?:peliculas?|movies?|series?|ver)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_CUEVANA_SKIP = {
    'page', 'category', 'tag', 'search', 'genre', 'actor', 'director',
    'year', 'country', 'tipo', 'fecha', 'calidad', 'idioma',
}


def _cuevana3_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (CUEVANA3_BASE, _q(title)))
    stubs, seen = [], set()
    for m in _RE_CUEVANA_CARD.finditer(html):
        url, slug = m.group(1), m.group(2)
        if slug not in _CUEVANA_SKIP and slug not in seen:
            seen.add(slug)
            stubs.append({'url': url, 'slug': slug})
    return stubs


def _cuevana3_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_cuevana3_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    title = re.sub(r'^(?:ver|watch)\s+', '', title, flags=re.IGNORECASE).strip()
    embeds = _extract_embeds(html)
    film = {
        'id': 'cuevana3_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'cuevana3', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_cuevana3(title, media_type='movie'):
    try:
        stubs = _cuevana3_search_stubs(title)
        return _pfetch(stubs, _cuevana3_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] cuevana3 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── hdtodayz.to ───────────────────────────────────────────────────────────────

_RE_HDTODAYZ_CARD = re.compile(
    r'href="(https?://hdtodayz\.to/(?:movie|watch|tv)?/?([a-z0-9][a-z0-9-]+)[^"]*)"',
    re.IGNORECASE
)
_HDTODAYZ_SKIP = {
    'page', 'category', 'tag', 'genre', 'actor', 'director', 'country',
    'year', 'search', 'watchlist', 'request', 'contact',
}


def _hdtodayz_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (HDTODAYZ_BASE, _q(title)))
    stubs, seen = [], set()
    for m in _RE_HDTODAYZ_CARD.finditer(html):
        url, slug = m.group(1), m.group(2)
        if slug not in _HDTODAYZ_SKIP and slug not in seen:
            seen.add(slug)
            stubs.append({'url': url, 'slug': slug})
    return stubs


def _hdtodayz_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_hdtodayz_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': 'hdtodayz_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'hdtodayz', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_hdtodayz(title, media_type='movie'):
    try:
        stubs = _hdtodayz_search_stubs(title)
        return _pfetch(stubs, _hdtodayz_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] hdtodayz error: %s' % e, xbmc.LOGWARNING)
        return []


# ── netmirror.app ─────────────────────────────────────────────────────────────

_RE_NETMIRROR_CARD = re.compile(
    r'href="(https?://(?:www\.)?netmirror\.app/(?:movie|show|watch|film)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_RE_NETMIRROR_CARD_ALT = re.compile(
    r'href="(https?://(?:www\.)?netmirror\.app/([a-z0-9][a-z0-9/-]+)[^"]*)"',
    re.IGNORECASE
)
_NETMIRROR_SKIP = {
    'page', 'category', 'tag', 'genre', 'search', 'about',
    'contact', 'privacy', 'dmca', 'sitemap',
}


def _netmirror_search_stubs(title):
    from urllib.parse import quote as _q
    for search_url in [
        '%s/search?q=%s' % (NETMIRROR_BASE, _q(title)),
        '%s/?s=%s' % (NETMIRROR_BASE, _q(title)),
    ]:
        html = _get(search_url)
        if not html:
            continue
        stubs, seen = [], set()
        for pattern in (_RE_NETMIRROR_CARD, _RE_NETMIRROR_CARD_ALT):
            for m in pattern.finditer(html):
                url, slug = m.group(1), m.group(2).strip('/')
                slug_key = slug.split('/')[0]
                if slug_key not in _NETMIRROR_SKIP and slug not in seen:
                    seen.add(slug)
                    stubs.append({'url': url, 'slug': re.sub(r'[^a-z0-9-]', '-', slug_key)})
        if stubs:
            return stubs
    return []


def _netmirror_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_netmirror_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': 'netmirror_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'netmirror', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_netmirror(title, media_type='movie'):
    try:
        stubs = _netmirror_search_stubs(title)
        return _pfetch(stubs, _netmirror_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] netmirror error: %s' % e, xbmc.LOGWARNING)
        return []


# ── zaxflix.com ───────────────────────────────────────────────────────────────

_RE_ZAXFLIX_CARD = re.compile(
    r'href="(https?://(?:www\.)?zaxflix\.com/(?:film|movie|serie|show|watch|ver)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_RE_ZAXFLIX_CARD_ALT = re.compile(
    r'href="(https?://(?:www\.)?zaxflix\.com/([a-z0-9][a-z0-9-]+)/?)"',
    re.IGNORECASE
)
_ZAXFLIX_SKIP = {
    'page', 'category', 'tag', 'genre', 'search', 'about', 'contact',
    'privacy', 'dmca', 'sitemap', 'login', 'register',
}


def _zaxflix_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (ZAXFLIX_BASE, _q(title)))
    stubs, seen = [], set()
    for pattern in (_RE_ZAXFLIX_CARD, _RE_ZAXFLIX_CARD_ALT):
        for m in pattern.finditer(html):
            url, slug = m.group(1), m.group(2)
            if slug not in _ZAXFLIX_SKIP and slug not in seen:
                seen.add(slug)
                stubs.append({'url': url, 'slug': slug})
    return stubs


def _zaxflix_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_zaxflix_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': 'zaxflix_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'zaxflix', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_zaxflix(title, media_type='movie'):
    try:
        stubs = _zaxflix_search_stubs(title)
        return _pfetch(stubs, _zaxflix_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] zaxflix error: %s' % e, xbmc.LOGWARNING)
        return []


# ── rarefilmm.com ─────────────────────────────────────────────────────────────
# Classic/rare film archive. Film pages often have direct MP4/embed links.

_RE_RAREFILMM_RESULT = re.compile(
    r'<h2[^>]+class="[^"]*entry-title[^"]*"[^>]*>\s*<a[^>]+href="([^"]+)"',
    re.IGNORECASE
)
_RE_RAREFILMM_RESULT_ALT = re.compile(
    r'href="(https?://rarefilmm\.com/\d{4}/\d{2}/[^"/?#]+/?)(?:")',
    re.IGNORECASE
)
_RE_RAREFILMM_STREAM = re.compile(
    r'(https?://[^"\'<\s]+\.(?:mp4|m3u8|mkv|avi|mov)(?:\?[^"\'<\s]*)?)',
    re.IGNORECASE
)
_RE_RAREFILMM_ARCHIVE = re.compile(
    r'href="(https?://(?:archive\.org|ia800[^.]+\.us\.archive\.org)/[^"]+\.(?:mp4|mkv|ogv))"',
    re.IGNORECASE
)


def search_rarefilmm(title, media_type='movie'):
    from urllib.parse import quote as _q
    try:
        html = _get('%s/?s=%s' % (RAREFILMM_BASE, _q(title)))
        film_urls = []
        seen = set()
        for pattern in (_RE_RAREFILMM_RESULT, _RE_RAREFILMM_RESULT_ALT):
            for m in pattern.finditer(html):
                u = m.group(1)
                if u not in seen and 'rarefilmm.com' in u:
                    seen.add(u)
                    film_urls.append(u)

        results = []
        for film_url in film_urls[:5]:
            try:
                detail_html = _get(film_url)
                if not detail_html:
                    continue
                film_title = _h1_title(detail_html) or _strip_site_suffix(_og(detail_html, 'title')) or ''
                if not film_title:
                    continue
                thumb   = _og(detail_html, 'image')
                streams = []
                for sm in _RE_RAREFILMM_STREAM.finditer(detail_html):
                    su = sm.group(1)
                    if su not in {s['url'] for s in streams}:
                        streams.append({'label': 'RareFilmm Direct', 'url': su})
                for sm in _RE_RAREFILMM_ARCHIVE.finditer(detail_html):
                    su = sm.group(1)
                    if su not in {s['url'] for s in streams}:
                        streams.append({'label': 'Archive.org', 'url': su})
                streams.extend(_extract_embeds(detail_html))
                if streams:
                    results.append({
                        'id':          'rarefilmm_%s' % re.sub(r'[^a-z0-9]', '_', film_title.lower())[:40],
                        'title':       film_title,
                        'title_norm':  _norm_title(film_title),
                        'thumb':       thumb,
                        'description': _og(detail_html, 'description')[:300],
                        'url':         film_url,
                        'source':      'rarefilmm',
                        'streams':     streams,
                    })
            except Exception as de:
                xbmc.log('[Starfleet/Scrapers] rarefilmm detail error: %s' % de, xbmc.LOGWARNING)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] rarefilmm search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 1shows.org ────────────────────────────────────────────────────────────────

_RE_1SHOWS_CARD = re.compile(
    r'href="(https?://(?:www\.)?1shows\.org/(?:[a-z0-9-]+/)*([a-z0-9][a-z0-9-]+)/?)"',
    re.IGNORECASE
)
_1SHOWS_SKIP = {
    'page', 'category', 'tag', 'genre', 'country', 'year', 'actor',
    'search', 'watchlist', 'request', 'contact', 'dmca', 'privacy',
    'movies', 'series', 'shows', 'home',
}


def _1shows_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (SHOWS1_BASE, _q(title)))
    stubs, seen = [], set()
    for m in _RE_1SHOWS_CARD.finditer(html):
        url, slug = m.group(1), m.group(2)
        if slug not in _1SHOWS_SKIP and slug not in seen:
            seen.add(slug)
            stubs.append({'url': url, 'slug': slug})
    return stubs


def _1shows_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_1shows_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': '1shows_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': '1shows', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_1shows(title, media_type='movie'):
    try:
        stubs = _1shows_search_stubs(title)
        return _pfetch(stubs, _1shows_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] 1shows error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 456movie.nl ───────────────────────────────────────────────────────────────

_RE_456_CARD = re.compile(
    r'href="(https?://(?:www\.)?456movie\.nl/(?:movie|film|series|watch)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_RE_456_CARD_ALT = re.compile(
    r'href="(https?://(?:www\.)?456movie\.nl/([a-z0-9][a-z0-9-]+)/?)"',
    re.IGNORECASE
)
_456_SKIP = {
    'page', 'category', 'tag', 'genre', 'search', 'about', 'contact',
    'privacy', 'dmca', 'sitemap', 'movies', 'series', 'home',
}


def _456_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (M456_BASE, _q(title)))
    stubs, seen = [], set()
    for pattern in (_RE_456_CARD, _RE_456_CARD_ALT):
        for m in pattern.finditer(html):
            url, slug = m.group(1), m.group(2)
            if slug not in _456_SKIP and slug not in seen:
                seen.add(slug)
                stubs.append({'url': url, 'slug': slug})
    return stubs


def _456_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_456movie_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': '456movie_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': '456movie', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_456movie(title, media_type='movie'):
    try:
        stubs = _456_search_stubs(title)
        return _pfetch(stubs, _456_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] 456movie error: %s' % e, xbmc.LOGWARNING)
        return []


# ── msearch.vercel.app ────────────────────────────────────────────────────────
# Meta-search aggregator. Tries JSON API first, falls back to HTML scrape.

_RE_MSEARCH_STREAM = re.compile(
    r'(https?://[^"\'<\s]+\.(?:mp4|m3u8|mkv)[^"\'<\s]*)',
    re.IGNORECASE
)


def search_msearch(title, media_type='movie'):
    from urllib.parse import quote as _q
    try:
        # Try JSON API endpoint (common for Vercel Next.js apps)
        data = _get_json('%s/api/search?q=%s&type=%s' % (MSEARCH_BASE, _q(title), media_type))
        if data and isinstance(data, (list, dict)):
            results_raw = data if isinstance(data, list) else (
                data.get('results') or data.get('data') or data.get('items') or []
            )
            films = []
            for item in results_raw[:8]:
                film_title = (
                    item.get('title') or item.get('name') or item.get('t') or ''
                )
                if not film_title:
                    continue
                streams = []
                for key in ('stream', 'url', 'src', 'link', 'video'):
                    su = item.get(key, '')
                    if su and su.startswith('http') and su not in {s['url'] for s in streams}:
                        streams.append({'label': 'MSearch', 'url': su})
                for su in (item.get('sources') or item.get('streams') or []):
                    u = su if isinstance(su, str) else su.get('url', '')
                    if u and u not in {s['url'] for s in streams}:
                        streams.append({'label': 'MSearch', 'url': u})
                if streams:
                    films.append({
                        'id': 'msearch_%s' % re.sub(r'[^a-z0-9]', '_', film_title.lower())[:40],
                        'title': film_title, 'title_norm': _norm_title(film_title),
                        'thumb': item.get('poster') or item.get('thumb') or item.get('image') or '',
                        'description': item.get('plot') or item.get('description') or '',
                        'url': item.get('url') or MSEARCH_BASE, 'source': 'msearch',
                        'streams': streams,
                    })
            if films:
                return films

        # Fallback: HTML scrape
        html = _get('%s/search?q=%s' % (MSEARCH_BASE, _q(title)))
        if not html:
            html = _get('%s/?s=%s' % (MSEARCH_BASE, _q(title)))
        if html:
            streams = []
            for m in _RE_MSEARCH_STREAM.finditer(html):
                su = m.group(1)
                if su not in {s['url'] for s in streams}:
                    streams.append({'label': 'MSearch', 'url': su})
            embeds = _extract_embeds(html)
            streams.extend(embeds)
            if streams:
                return [{
                    'id': 'msearch_results', 'title': title,
                    'title_norm': _norm_title(title), 'thumb': '',
                    'description': '', 'url': MSEARCH_BASE,
                    'source': 'msearch', 'streams': streams,
                }]
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] msearch error: %s' % e, xbmc.LOGWARNING)
    return []


# ── bflix.se ─────────────────────────────────────────────────────────────────

BFLIX_BASE = 'https://bbflix.watch'

_RE_BFLIX_CARD = re.compile(
    r'href="(https?://(?:www\.)?bbflix\.watch/(?:movie|watch|series|tv)/([^"/?#\s]{3,120})[^"]*)"[^>]*>\s*(?:[^<]*<[^>]+>)*\s*([^<]{3,100})',
    re.IGNORECASE | re.DOTALL
)
_RE_BFLIX_CARD2 = re.compile(
    r'href="(/(?:movie|watch|series|tv)/[^"/?#\s]{3,120})"',
    re.IGNORECASE
)


def search_bflix(title, media_type='movie'):
    from urllib.parse import quote as _q
    # bbflix.watch uses /search?keyword= for both movies and series
    urls = [
        '%s/search?keyword=%s' % (BFLIX_BASE, _q(title)),
    ]
    html = ''
    for u in urls:
        html = _get(u)
        if html and len(html) > 500:
            break
    if not html:
        return []

    # bbflix uses /movie/ for movies and /series/ for TV
    path_re = re.compile(r'href="(/(?:movie|series|watch|tv)/[^"/?#\s]{3,120})"', re.IGNORECASE)
    seen, stubs = set(), []
    for m in path_re.finditer(html):
        path = m.group(1)
        if path in seen:
            continue
        # filter by type
        if media_type == 'tv' and '/movie/' in path:
            continue
        if media_type == 'movie' and '/series/' in path:
            continue
        seen.add(path)
        start = max(0, m.start() - 50)
        ctx   = html[start:m.end() + 200]
        mt    = re.search(r'(?:title=["\']|alt=["\']|<span[^>]*>|<h\d[^>]*>)\s*([^"\'<]{4,80})', ctx, re.IGNORECASE)
        card_title = _clean(mt.group(1)) if mt else path.rsplit('/', 2)[-2].replace('-', ' ').title()
        stubs.append({'path': BFLIX_BASE + path, 'title': card_title})
        if len(stubs) >= 5:
            break

    def _fetch_bflix(stub):
        detail_html = _get(stub['path'])
        if not detail_html:
            return None
        embeds = _extract_embeds(detail_html)
        if not embeds:
            return None
        return {
            'id': 'bflix_' + re.sub(r'\W+', '_', stub['title'].lower())[:40],
            'title': stub['title'], 'title_norm': _norm_title(stub['title']),
            'thumb': _og(detail_html, 'image'), 'description': _og(detail_html, 'description'),
            'url': stub['path'], 'source': 'bflix',
            'streams': [{'label': e['label'], 'url': e['url']} for e in embeds],
        }

    results = _pfetch(stubs, _fetch_bflix, limit=4)
    xbmc.log('[Starfleet/Scrapers] bflix "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── fmoviess.org ──────────────────────────────────────────────────────────────

FMOVIESS_BASE = 'https://fmoviess.org'

_RE_FMOVIESS_CARD = re.compile(
    r'href="(https?://(?:www\.)?fmoviess\.org/(?:movie|watch|film)/[^"/?#\s]{3,120})"',
    re.IGNORECASE
)


def search_fmoviess(title, media_type='movie'):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (FMOVIESS_BASE, _q(title)))
    if not html:
        html = _get('%s/search/%s' % (FMOVIESS_BASE, _q(title).replace('+', '-').replace('%20', '-')))
    if not html:
        return []

    seen, stubs = set(), []
    for m in _RE_FMOVIESS_CARD.finditer(html):
        url = m.group(1)
        if url in seen:
            continue
        seen.add(url)
        ctx = html[m.end():m.end() + 300]
        mt  = re.search(r'(?:title=["\']|alt=["\']|class="[^"]*title[^"]*"[^>]*>)\s*([^"\'<]{4,80})', ctx, re.IGNORECASE)
        card_title = _clean(mt.group(1)) if mt else title
        stubs.append({'url': url, 'title': card_title})
        if len(stubs) >= 5:
            break

    def _fetch_fm(stub):
        dh = _get(stub['url'])
        if not dh:
            return None
        embeds = _extract_embeds(dh)
        if not embeds:
            return None
        return {
            'id': 'fmoviess_' + re.sub(r'\W+', '_', stub['title'].lower())[:40],
            'title': stub['title'], 'title_norm': _norm_title(stub['title']),
            'thumb': _og(dh, 'image'), 'description': _og(dh, 'description'),
            'url': stub['url'], 'source': 'fmoviess',
            'streams': [{'label': e['label'], 'url': e['url']} for e in embeds],
        }

    results = _pfetch(stubs, _fetch_fm, limit=4)
    xbmc.log('[Starfleet/Scrapers] fmoviess "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── solarmovie.net.pk ─────────────────────────────────────────────────────────

SOLAR_BASE = 'https://www.solarmovie.net.pk'

_RE_SOLAR_CARD = re.compile(
    r'href="(https?://(?:www\.)?solarmovie\.net\.pk/(?:movie|watch|film|play)/[^"/?#\s]{3,120})"',
    re.IGNORECASE
)


def search_solarmovie(title, media_type='movie'):
    from urllib.parse import quote as _q
    urls = [
        '%s/search/?q=%s' % (SOLAR_BASE, _q(title)),
        '%s/?s=%s' % (SOLAR_BASE, _q(title)),
        '%s/search/%s/' % (SOLAR_BASE, _q(title).replace('+', '-').replace('%20', '-')),
    ]
    html = ''
    for u in urls:
        html = _get(u)
        if html and len(html) > 500:
            break
    if not html:
        return []

    seen, stubs = set(), []
    for m in _RE_SOLAR_CARD.finditer(html):
        url = m.group(1)
        if url in seen:
            continue
        seen.add(url)
        ctx = html[m.end():m.end() + 300]
        mt  = re.search(r'(?:title=["\']|alt=["\']|<h\d[^>]*>|class="[^"]*title[^"]*"[^>]*>)\s*([^"\'<]{4,80})', ctx, re.IGNORECASE)
        card_title = _clean(mt.group(1)) if mt else title
        stubs.append({'url': url, 'title': card_title})
        if len(stubs) >= 5:
            break

    def _fetch_solar(stub):
        dh = _get(stub['url'])
        if not dh:
            return None
        embeds = _extract_embeds(dh)
        if not embeds:
            return None
        return {
            'id': 'solar_' + re.sub(r'\W+', '_', stub['title'].lower())[:40],
            'title': stub['title'], 'title_norm': _norm_title(stub['title']),
            'thumb': _og(dh, 'image'), 'description': _og(dh, 'description'),
            'url': stub['url'], 'source': 'solarmovie',
            'streams': [{'label': e['label'], 'url': e['url']} for e in embeds],
        }

    results = _pfetch(stubs, _fetch_solar, limit=4)
    xbmc.log('[Starfleet/Scrapers] solarmovie "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── filmslook.com ─────────────────────────────────────────────────────────────

FILMSLOOK_BASE = 'https://filmslook.com'

_RE_FILMSLOOK_CARD = re.compile(
    r'href="(https?://(?:www\.)?filmslook\.com/(?:movies?|watch|film|series|tv)/[^"/?#\s]{3,120})"',
    re.IGNORECASE
)


def search_filmslook(title, media_type='movie'):
    from urllib.parse import quote as _q
    urls = [
        '%s/?s=%s' % (FILMSLOOK_BASE, _q(title)),
        '%s/search?q=%s' % (FILMSLOOK_BASE, _q(title)),
        '%s/search/%s/' % (FILMSLOOK_BASE, _q(title).replace('+', '-').replace('%20', '-')),
    ]
    html = ''
    for u in urls:
        html = _get(u)
        if html and len(html) > 500:
            break
    if not html:
        return []

    seen, stubs = set(), []
    for m in _RE_FILMSLOOK_CARD.finditer(html):
        url = m.group(1)
        if url in seen:
            continue
        seen.add(url)
        ctx = html[m.end():m.end() + 300]
        mt  = re.search(r'(?:title=["\']|alt=["\']|<h\d[^>]*>|class="[^"]*title[^"]*"[^>]*>)\s*([^"\'<]{4,80})', ctx, re.IGNORECASE)
        card_title = _clean(mt.group(1)) if mt else title
        stubs.append({'url': url, 'title': card_title})
        if len(stubs) >= 5:
            break

    def _fetch_fl(stub):
        dh = _get(stub['url'])
        if not dh:
            return None
        embeds = _extract_embeds(dh)
        if not embeds:
            return None
        return {
            'id': 'filmslook_' + re.sub(r'\W+', '_', stub['title'].lower())[:40],
            'title': stub['title'], 'title_norm': _norm_title(stub['title']),
            'thumb': _og(dh, 'image'), 'description': _og(dh, 'description'),
            'url': stub['url'], 'source': 'filmslook',
            'streams': [{'label': e['label'], 'url': e['url']} for e in embeds],
        }

    results = _pfetch(stubs, _fetch_fl, limit=4)
    xbmc.log('[Starfleet/Scrapers] filmslook "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── ici.tou.tv (Radio-Canada OTT catalog) ────────────────────────────────────

TOUTV_CATALOG = 'https://services.radio-canada.ca/ott/catalog/v2/toutv'
TOUTV_STREAM  = 'https://services.radio-canada.ca/media/validation/v2/'

_RE_TOUTV_M3U8 = re.compile(r'url["\s]*:["\s]*(https?://[^"\'<\s]+\.m3u8[^"\'<\s]*)', re.IGNORECASE)


def _toutv_stream_url(media_id):
    """Resolve a tou.tv mediaId to an HLS stream URL (free content only)."""
    from urllib.parse import urlencode
    params = urlencode({
        'appCode':        'toutv',
        'idMedia':        str(media_id),
        'connectionType': 'hd',
        'deviceType':     'ipad',
        'manifestType':   'm3u8',
        'output':         'json',
    })
    try:
        s = _sess()
        if not s:
            return ''
        r = s.get('%s?%s' % (TOUTV_STREAM, params), timeout=(6, 12),
                  headers=dict(_HEADERS, Referer='https://ici.tou.tv/'))
        if r.status_code != 200:
            return ''
        data = r.json()
        url = (data.get('url') or data.get('mediaUrl') or
               (data.get('validationData') or {}).get('url', ''))
        return url or ''
    except Exception:
        return ''


def search_toutv(title, media_type='movie'):
    """Search ici.tou.tv for free French-Canadian content."""
    from urllib.parse import quote as _q
    try:
        s    = _sess()
        if not s:
            return []
        data = s.get(
            '%s/search?q=%s&locale=fr_CA&items=10' % (TOUTV_CATALOG, _q(title)),
            timeout=(6, 12), headers=dict(_HEADERS, Referer='https://ici.tou.tv/')
        ).json()
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] toutv search error: %s' % e, xbmc.LOGWARNING)
        return []

    items = (data.get('items') or data.get('medias') or
             data.get('results') or data.get('data') or [])
    if not items and isinstance(data, list):
        items = data

    results = []
    for item in items[:8]:
        media_id = (item.get('mediaId') or item.get('id') or item.get('appMediaId') or '')
        film_title = (item.get('title') or item.get('label') or
                      item.get('name') or item.get('mediaTitle') or '')
        if not film_title:
            continue
        is_free = not item.get('isExtra', False)
        thumb = ''
        for img_key in ('thumbnail', 'image', 'poster', 'logo'):
            img = item.get(img_key)
            if isinstance(img, str):
                thumb = img
                break
            elif isinstance(img, dict):
                thumb = img.get('url', img.get('src', img.get('path', '')))
                if thumb:
                    break

        streams = []
        if media_id and is_free:
            su = _toutv_stream_url(media_id)
            if su:
                streams.append({'label': 'Tou.tv', 'url': su})

        # Always include the page URL as a fallback embed
        page_url = 'https://ici.tou.tv/%s' % (
            item.get('url') or item.get('slug') or media_id or ''
        )
        if not streams and media_id:
            streams.append({'label': 'Tou.tv (auth required)', 'url': page_url})

        if streams:
            results.append({
                'id': 'toutv_%s' % str(media_id),
                'title': film_title, 'title_norm': _norm_title(film_title),
                'thumb': thumb, 'description': item.get('description', ''),
                'url': page_url, 'source': 'toutv', 'streams': streams,
            })

    xbmc.log('[Starfleet/Scrapers] toutv "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── Title matching ────────────────────────────────────────────────────────────

def _title_matches(norm_query, norm_film):
    """Return True if the normalised query matches a film title closely enough."""
    if not norm_query or not norm_film:
        return False
    if norm_query == norm_film:
        return True
    q_words = norm_query.split()
    f_words = norm_film.split()
    if len(q_words) >= 2 and all(w in norm_film for w in q_words):
        return True
    if len(f_words) >= 2 and all(w in norm_query for w in f_words):
        return True
    return False


# ── Unified search ────────────────────────────────────────────────────────────

# ── LookMovie2 ────────────────────────────────────────────────────────────────

_LM2_BASE = 'https://www.lookmovie2.to'

def search_lookmovie2(title, media_type='movie', season=None, episode=None):
    """
    lookmovie2.to — search → extract server-signed hash → call stream API → direct HLS.

    Flow:
      1. Search /movies/search/?q= or /shows/search/?q=
      2. Fetch play page, parse window['movie_storage'] or window['show_storage']
      3. POST to /api/v1/security/movie-access or episode-access with id+hash+expires
      4. Return direct m3u8 stream URLs (480p/720p/1080p)
    """
    from urllib.parse import quote as _q
    import json as _json
    if not _HAS_REQUESTS or not title:
        return []
    try:
        s = _sess()
        if s is None:
            return []

        if media_type == 'tv':
            search_html = _get('%s/shows/search/?q=%s' % (_LM2_BASE, _q(title)))
            link_m = re.search(r'href="(/shows/view/([^"]+))"', search_html)
            if not link_m:
                return []
            view_path = link_m.group(1)
            play_path = view_path.replace('/view/', '/play/')

            play_html = _get(_LM2_BASE + play_path)
            storage_m = re.search(r"window\['show_storage'\]\s*=\s*\{([^;]+)\};", play_html, re.DOTALL)
            if not storage_m:
                return []
            raw = storage_m.group(1)

            hash_m    = re.search(r"hash:\s*['\"]([^'\"]+)['\"]", raw)
            expires_m = re.search(r'expires:\s*(\d+)', raw)
            if not (hash_m and expires_m):
                return []

            # Find id_episode matching requested season+episode
            target_s = str(season or 1)
            target_e = str(episode or 1)
            # seasons list has objects: {title, index, episode, id_episode, season}
            ep_id = None
            for ep_m in re.finditer(r'\{[^}]+id_episode:\s*(\d+)[^}]+\}', raw):
                blk = ep_m.group(0)
                s_m = re.search(r"season:\s*['\"]?(%s)['\"]?" % re.escape(target_s), blk)
                e_m = re.search(r"episode:\s*['\"]?(%s)['\"]?" % re.escape(target_e), blk)
                if s_m and e_m:
                    ep_id = ep_m.group(1)
                    break
            if not ep_id:
                return []

            api_url = ('%s/api/v1/security/episode-access?id_episode=%s&hash=%s&expires=%s'
                       % (_LM2_BASE, ep_id, hash_m.group(1), expires_m.group(1)))
            api_ref  = _LM2_BASE + play_path

        else:
            search_html = _get('%s/movies/search/?q=%s' % (_LM2_BASE, _q(title)))
            link_m = re.search(r'href="(/movies/view/([^"]+))"', search_html)
            if not link_m:
                return []
            view_path = link_m.group(1)
            play_path = view_path.replace('/view/', '/play/')

            play_html = _get(_LM2_BASE + play_path)
            storage_m = re.search(r"window\['movie_storage'\]\s*=\s*\{([^}]+)\}", play_html, re.DOTALL)
            if not storage_m:
                return []
            raw = storage_m.group(1)

            id_m      = re.search(r'id_movie:\s*(\d+)', raw)
            hash_m    = re.search(r"hash:\s*['\"]([^'\"]+)['\"]", raw)
            expires_m = re.search(r'expires:\s*(\d+)', raw)
            if not (id_m and hash_m and expires_m):
                return []

            api_url = ('%s/api/v1/security/movie-access?id_movie=%s&hash=%s&expires=%s'
                       % (_LM2_BASE, id_m.group(1), hash_m.group(1), expires_m.group(1)))
            api_ref  = _LM2_BASE + play_path

        r = _sess().get(api_url, headers=dict(_HEADERS, Referer=api_ref), timeout=10)
        data = r.json()
        if not data.get('success'):
            return []

        results = []
        streams = data.get('streams', {})
        for quality in ('1080p', '720p', '480p'):
            url = streams.get(quality)
            if url and isinstance(url, str):
                results.append({
                    'title': title, 'title_norm': _norm_title(title),
                    'streams': [{'label': 'LookMovie2 [%s]' % quality, 'url': url}],
                    'source': 'lookmovie2',
                })
        xbmc.log('[Starfleet/Scrapers] lookmovie2 "%s" → %d streams' % (title, len(results)), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] lookmovie2 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Nuvio (IMDb-based Stremio-compatible direct stream API) ───────────────────

NUVIO_BASE = 'https://nuviostreams.hayd.uk'
_RE_QUALITY = re.compile(
    r'\b(4K|2160p?|UHD|1080p?|1080i|720p?|480p?|WEB-?DL|WEBRip|BluRay|HDTV|HDRip)\b',
    re.IGNORECASE
)


def search_nuvio(imdb_id, media_type='movie', season=None, episode=None):
    """Nuvio free direct stream API — IMDb-ID based, no auth required."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/stream/series/%s:%s:%s.json' % (NUVIO_BASE, imdb_id, season, episode)
        else:
            url = '%s/stream/movie/%s.json' % (NUVIO_BASE, imdb_id)
        data = _get_json(url, timeout=(8, 35))
        if not data or not isinstance(data.get('streams'), list):
            return []
        results = []
        for stream in data['streams']:
            stream_url = stream.get('url', '')
            if not stream_url:
                continue
            name = stream.get('title', '')
            q_m = _RE_QUALITY.search(name)
            label = q_m.group(0).upper() if q_m else (name[:30] if name else 'Stream')
            results.append({
                'label':  '[NUVIO] %s' % label,
                'url':    stream_url,
                'source': 'nuvio',
            })
        xbmc.log('[Starfleet/Nuvio] %s → %d streams' % (imdb_id, len(results)), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Nuvio] error: %s' % e, xbmc.LOGWARNING)
        return []


# ── WebStreamer (IMDb-based Stremio-compatible direct stream API) ──────────────

WEBSTREAMER_BASE = 'https://webstreamr.hayd.uk'
_RE_FLAG_EMOJI = re.compile(
    u'[\U0001F1E0-\U0001F1FF\U0001F300-\U0001F9FF☀-⛿✀-➿]',
    re.UNICODE
)


def search_webstreamer(imdb_id, media_type='movie', season=None, episode=None):
    """WebStreamer free direct stream API — IMDb-ID based, no auth required."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/stream/series/%s:%s:%s.json' % (WEBSTREAMER_BASE, imdb_id, season, episode)
        else:
            url = '%s/stream/movie/%s.json' % (WEBSTREAMER_BASE, imdb_id)
        data = _get_json(url, timeout=(8, 25))
        if not data or not isinstance(data.get('streams'), list):
            return []
        results = []
        for stream in data['streams']:
            stream_url = stream.get('url', '')
            if not stream_url:
                continue
            if 'video-downloads.googleusercontent' in stream_url:
                continue
            stream_url = stream_url.replace('pixeldrain.dev/u/', 'pixeldrain.dev/api/file/')
            raw_title = stream.get('title', '')
            name = _RE_FLAG_EMOJI.sub('', raw_title).split('\n')[0].strip()
            q_m = _RE_QUALITY.search(name)
            label = q_m.group(0).upper() if q_m else (name[:30] if name else 'Stream')
            results.append({
                'label':  '[WEBSTREAMER] %s' % label,
                'url':    stream_url,
                'source': 'webstreamer',
            })
        xbmc.log('[Starfleet/WebStreamer] %s → %d streams' % (imdb_id, len(results)), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/WebStreamer] error: %s' % e, xbmc.LOGWARNING)
        return []


def search_all_scrapers(title, media_type='movie', season=None, episode=None, imdb_id=None):
    """
    Search all scraper sources in parallel for the given title.
    Works for media_type 'movie', 'tv', or 'adult' — no content is filtered
    at the scraper level; resolution happens via ResolveURL at play time.

    When imdb_id is provided, also queries Nuvio and WebStreamer direct APIs.
    Returns list of {'label', 'url', 'source'} stream dicts.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    if not _HAS_REQUESTS or not title:
        return []

    norm_query = _norm_title(title)

    # Title-based HTML scrapers — return film dicts with 'streams' lists
    title_tasks = {
        'cuevana3':   lambda: search_cuevana3(title, media_type),
        # hdtodayz.to: dead (connection refused) — removed 2026-07-04
        'bflix':      lambda: search_bflix(title, media_type),
        'zaxflix':    lambda: search_zaxflix(title, media_type),
        'rarefilmm':  lambda: search_rarefilmm(title, media_type),
        '1shows':     lambda: search_1shows(title, media_type),
        '456movie':   lambda: search_456movie(title, media_type),
        'fmoviess':   lambda: search_fmoviess(title, media_type),
        'filmslook':  lambda: search_filmslook(title, media_type),
        'toutv':       lambda: search_toutv(title, media_type),
        'lookmovie2':  lambda: search_lookmovie2(title, media_type, season=season, episode=episode),
    }

    # IMDb-based API scrapers — return flat stream dicts directly (only when imdb_id known)
    imdb_tasks = {}
    if imdb_id and media_type in ('movie', 'tv'):
        imdb_tasks = {
            'nuvio':        lambda: search_nuvio(imdb_id, media_type, season, episode),
            'webstreamer':  lambda: search_webstreamer(imdb_id, media_type, season, episode),
        }

    streams    = []
    seen_urls  = set()

    all_tasks = dict(list(title_tasks.items()) + list(imdb_tasks.items()))
    with ThreadPoolExecutor(max_workers=len(all_tasks)) as pool:
        futures = {pool.submit(fn): name for name, fn in all_tasks.items()}
        try:
            for future in as_completed(futures, timeout=35):
                name = futures[future]
                try:
                    result = future.result() or []
                    if name in imdb_tasks:
                        # IMDb scrapers return flat [{'label', 'url', 'source'}]
                        for s in result:
                            if s.get('url') and s['url'] not in seen_urls:
                                seen_urls.add(s['url'])
                                streams.append(s)
                    else:
                        # Title scrapers return film dicts with 'streams' lists
                        for film in result:
                            if not film:
                                continue
                            if _title_matches(norm_query, film.get('title_norm', '')):
                                for s in film.get('streams', []):
                                    if s.get('url') and s['url'] not in seen_urls:
                                        seen_urls.add(s['url'])
                                        streams.append({
                                            'label':  '[%s] %s' % (name.upper(), s.get('label', 'Stream')),
                                            'url':    s['url'],
                                            'source': name,
                                        })
                except Exception as e:
                    xbmc.log('[Starfleet/Scrapers] %s search error: %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Scrapers] search_all_scrapers timeout: %s' % e, xbmc.LOGWARNING)

    xbmc.log(
        '[Starfleet/Scrapers] search_all_scrapers "%s" (%s) → %d streams'
        % (title, media_type, len(streams)),
        xbmc.LOGINFO
    )
    return streams
