# -*- coding: utf-8 -*-
"""
resources/lib/router.py — Starfleet Kodi Plugin
Main menu + Live TV section directory builder.
Radio section is handled by radio_router.py.
"""

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import api

ADDON = xbmcaddon.Addon()

LIVE_SOURCES_MENU = [
    ('live_tva',    '📡  GEOlocked — Canada (TVA / Global News)',
     'TVA, TVA Sports, Global News (14 regions) — live via Google DAI. Canada only.'),
    ('live_samsung','📺  Samsung TV+',
     'Free Samsung TV Plus channels — Canada'),
    ('live_plex',   '🟠  Plex FAST Channels',
     'Free Plex channels — news, movies, entertainment'),
    ('live_pluto',  '🪐  Pluto TV Canada',
     '110+ Pluto TV channels — free and legal'),
    ('live_news',   '🌍  Free Worldwide News & Channels',
     'Al Jazeera, France 24, DW, Euronews, NASA TV, CGTN, ABC Australia and more — free worldwide streams'),
]


def _add_dir(handle, build_url, label, params, thumb='', plot=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_play(handle, build_url, label, params, thumb='', plot='', info=None):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', dict({'title': label, 'plot': plot}, **(info or {})))
    li.setProperty('IsPlayable', 'true')
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, False)


def _hls_item(url, title=''):
    li = xbmcgui.ListItem(path=url)
    li.setInfo('video', {'title': title})
    if '.m3u8' in url.lower():
        try:
            import inputstreamhelper
            h = inputstreamhelper.Helper('hls')
            if h.check_inputstream():
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        except ImportError:
            pass
    return li


def _loading(msg):
    d = xbmcgui.DialogProgress()
    d.create('Starfleet', msg)
    return d


def _list_channels(handle, build_url, channels, source=''):
    for ch in channels:
        logo  = ch.get('thumbnail', '')
        label = ch['title']
        li    = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': label,
            'plot':  '%s — %s' % (ch.get('source', source), ch.get('group', '')),
        })
        li.setProperty('IsPlayable', 'true')
        if logo:
            li.setArt({
                'thumb':  logo,
                'icon':   logo,
                'poster': logo,
                # Use logo as fanart too — better than blank background
                'fanart': logo,
            })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'play_direct',
                       'stream_url': ch.get('stream_url', ''),
                       'ch_id':      ch.get('id', ''),
                       'source':     ch.get('source', source),
                       'title':      ch['title']}),
            li, False
        )
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def _group_menu(handle, build_url, channels, group_action, source_label):
    groups = {}
    for ch in channels:
        groups.setdefault(ch.get('group', 'Autres'), []).append(ch)
    for g in sorted(groups):
        _add_dir(handle, build_url,
                 label='%s  (%d)' % (g, len(groups[g])),
                 params={'action': group_action, 'group': g},
                 plot='%d chaînes' % len(groups[g]))
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Main Menu ─────────────────────────────────────────────────────────────────

def main_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Starfleet')
    xbmcplugin.setContent(handle, 'files')

    _add_dir(handle, build_url, '⭐  Favorites',
             {'action': 'favorites_menu'},
             plot='Your saved movies and TV shows')

    _add_dir(handle, build_url, '📺  TV Shows',
             {'action': 'meta_tv_menu'},
             plot='Browse TV shows — Popular, Top Rated, by Genre, Search (TMDB + TVDB)')

    _add_dir(handle, build_url, '🎬  Movies',
             {'action': 'meta_movies_menu'},
             plot='Browse movies — Popular, Top Rated, Now Playing, by Genre, Search (TMDB)')

    _add_dir(handle, build_url, '🏟️  Sports',
             {'action': 'sports_menu'},
             plot='Live sports — NFL, NBA, MLB, NHL, UFC, Soccer, F1 and more. Stream links from istreameast.cx and crackstreams.mx')

    _add_dir(handle, build_url, '🆓  Free Streaming',
             {'action': 'free_menu'},
             plot='Free movies and TV shows — Popcornflix, Fawesome, Filmzie, BounceTV, Midnight Pulp, DistroTV and more')

    _add_dir(handle, build_url, '📡  Live TV — Toutes les sources',
             {'action': 'live_menu'},
             plot='Starfleet, Samsung TV+, Plex, Pluto TV — toutes gratuites')

    _add_dir(handle, build_url, '📻  Radio',
             {'action': 'radio_menu'},
             plot='90 000+ stations radio — Monde entier par pays, région, ville')

    # Adult section — only shown if enabled in settings
    from resources.lib import pin_lock
    if pin_lock.adult_visible():
        _add_dir(handle, build_url, '🔞  Adult',
                 {'action': 'adult_menu'},
                 plot='Adult Film Database — Metadata, cast, studios, categories')

    _add_dir(handle, build_url, '⚙️  Settings',
             {'action': 'open_settings'},
             plot='Configure premium services, PIN, metadata language')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Live Menu ─────────────────────────────────────────────────────────────────

def live_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Live TV')
    xbmcplugin.setContent(handle, 'files')

    # Pre-warm all live sources in background threads while menu renders
    try:
        from resources.lib.live_sources import prewarm_all
        prewarm_all()
    except Exception:
        pass

    # ── Unified list first ────────────────────────────────────────────────
    _add_dir(handle, build_url,
             label='📺  All Channels (Unified)',
             params={'action': 'live_all'},
             plot='All channels from all sources in one list — duplicates show a source picker')

    _add_dir(handle, build_url,
             label='─' * 30,
             params={'action': 'live_menu'},
             plot='')

    # ── Individual sources ────────────────────────────────────────────────
    for action, label, plot in LIVE_SOURCES_MENU:
        _add_dir(handle, build_url, label, {'action': action}, plot=plot)

    _add_dir(handle, build_url, '⚙️  Exporter M3U + EPG pour pvr.iptvsimple',
             {'action': 'export_iptv'},
             plot='Génère URLs M3U + XMLTV pour la grille EPG Kodi')
    _add_dir(handle, build_url, '🔄  Rafraîchir tout / Refresh All',
             {'action': 'live_refresh_all'},
             plot='Force refresh all channel lists and unified cache')
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def settings_menu(handle, build_url):
    """Quick-access settings and account status."""
    xbmcplugin.setPluginCategory(handle, '⚙️ Settings')
    xbmcplugin.setContent(handle, 'files')

    _add_dir(handle, build_url, '⚙️  Open Settings',
             {'action': 'open_settings'},
             plot='Configure premium services, PIN, TVA+ keys, metadata options')

    _add_dir(handle, build_url, '🔑  Premium Service Status',
             {'action': 'premium_status'},
             plot='Check Real-Debrid, AllDebrid, Premiumize account status')

    _add_dir(handle, build_url, '🔒  Lock Adult Section Now',
             {'action': 'adult_lock'},
             plot='Re-lock the adult section for this session')

    _add_dir(handle, build_url, '🔓  Set / Change Adult PIN',
             {'action': 'set_adult_pin'},
             plot='Set or change the 4-digit adult section PIN')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Unified Channel List ─────────────────────────────────────────────────────

def list_live_all(handle, build_url):
    """
    All channels from all sources in one alphabetical list.
    Channels available from multiple sources show a source-picker dialog on play.
    """
    from resources.lib import unified_live
    from resources.lib import api as _api

    xbmcplugin.setContent(handle, 'files')

    # Show progress only on cold cache
    from resources.lib import cache as _c
    cold = _c.get('unified_live_all') is None
    dlg  = None
    if cold:
        dlg = xbmcgui.DialogProgress()
        dlg.create('Starfleet', 'Loading all channels...')
        dlg.update(10, 'Fetching Samsung TV+...')

    tva_channels = _api.get_live_channels()  # TVA DAI channels

    if dlg:
        dlg.update(50, 'Fetching Plex & Pluto TV...')

    channels = unified_live.get_all_channels(tva_channels=tva_channels)

    if dlg:
        dlg.update(100)
        dlg.close()

    if not channels:
        xbmcgui.Dialog().notification('Starfleet', 'No channels found',
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    xbmcplugin.setPluginCategory(
        handle, '📺 All Channels (%d)' % len(channels))

    for ch in channels:
        sources    = ch['sources']
        src_count  = len(sources)
        source_str = ' | '.join(
            unified_live.SOURCE_LABELS.get(s['source'], s['source'])
            for s in sources
        )

        # Label shows source count as a hint
        if src_count > 1:
            label = '%s  [%d sources]' % (ch['title'], src_count)
        else:
            label = ch['title']

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': ch['title'],
            'plot':  source_str,
        })
        li.setProperty('IsPlayable', 'true')
        logo = ch.get('thumbnail', '')
        if logo:
            li.setArt({
                'thumb':  logo,
                'icon':   logo,
                'poster': logo,
                'fanart': logo,
            })

        xbmcplugin.addDirectoryItem(
            handle,
            build_url({
                'action':   'live_unified_play',
                'ch_key':   ch['key'],
                'ch_title': ch['title'],
            }),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── TVA / DAI ─────────────────────────────────────────────────────────────────

def list_live_tva(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'GEOlocked — Canada: TVA / Global News')
    xbmcplugin.setContent(handle, 'files')
    channels = api.get_live_channels()
    if not channels:
        xbmcgui.Dialog().ok('En Direct', 'Aucune chaîne configurée.')
        return
    for ch in channels:
        logo  = ch.get('thumbnail', '')
        group = ch.get('group', '')
        li    = xbmcgui.ListItem(label=ch['title'])
        li.setInfo('video', {
            'title': ch['title'],
            'plot':  '[%s] %s' % (group, ch.get('description', '')) if group else ch.get('description', ''),
        })
        li.setProperty('IsPlayable', 'true')
        if logo:
            li.setArt({'thumb': logo, 'icon': logo, 'poster': logo, 'fanart': logo})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'play_live_dai',
                       'channel_id': ch['id'],
                       'title':      ch['title']}),
            li, False
        )
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Samsung ───────────────────────────────────────────────────────────────────

def list_live_samsung(handle, build_url):
    from resources.lib import live_sources
    xbmcplugin.setContent(handle, 'files')
    cold = live_sources._cache.get('samsung_ca') is None
    dlg  = _loading('Chargement Samsung TV+...') if cold else None
    channels = live_sources.get_samsung_channels()
    if dlg: dlg.close()
    if not channels:
        xbmcgui.Dialog().notification('Starfleet', 'Samsung TV+ indisponible',
                                       xbmcgui.NOTIFICATION_WARNING)
        return
    xbmcplugin.setPluginCategory(handle, 'Samsung TV+ (%d)' % len(channels))
    _group_menu(handle, build_url, channels, 'live_samsung_group', 'Samsung TV+')


def list_live_samsung_group(handle, build_url, group):
    from resources.lib import live_sources
    xbmcplugin.setPluginCategory(handle, 'Samsung TV+ — %s' % group)
    xbmcplugin.setContent(handle, 'files')
    _list_channels(handle, build_url,
                   [c for c in live_sources.get_samsung_channels()
                    if c.get('group') == group], 'Samsung TV+')


# ── Plex ──────────────────────────────────────────────────────────────────────

def list_live_plex(handle, build_url):
    from resources.lib import live_sources
    xbmcplugin.setContent(handle, 'files')
    cold = live_sources._cache.get('plex_all') is None
    dlg  = _loading('Chargement Plex...') if cold else None
    channels = live_sources.get_plex_channels()
    if dlg: dlg.close()
    if not channels:
        xbmcgui.Dialog().notification('Starfleet', 'Plex indisponible',
                                       xbmcgui.NOTIFICATION_WARNING)
        return
    xbmcplugin.setPluginCategory(handle, 'Plex FAST (%d)' % len(channels))
    _group_menu(handle, build_url, channels, 'live_plex_group', 'Plex')


def list_live_plex_group(handle, build_url, group):
    from resources.lib import live_sources
    xbmcplugin.setPluginCategory(handle, 'Plex — %s' % group)
    xbmcplugin.setContent(handle, 'files')
    _list_channels(handle, build_url,
                   [c for c in live_sources.get_plex_channels()
                    if c.get('group') == group], 'Plex')


# ── Pluto ─────────────────────────────────────────────────────────────────────

def list_live_pluto(handle, build_url):
    from resources.lib import live_sources
    xbmcplugin.setContent(handle, 'files')
    cold = live_sources._cache.get('pluto_meta') is None
    dlg  = _loading('Chargement Pluto TV...') if cold else None
    channels = live_sources.get_pluto_channels()
    if dlg: dlg.close()
    if not channels:
        xbmcgui.Dialog().notification(
            'Starfleet', 'Pluto TV indisponible — essayez Rafraîchir',
            xbmcgui.NOTIFICATION_WARNING)
        return
    xbmcplugin.setPluginCategory(handle, 'Pluto TV (%d)' % len(channels))
    _group_menu(handle, build_url, channels, 'live_pluto_group', 'Pluto TV')


def list_live_pluto_group(handle, build_url, group):
    from resources.lib import live_sources
    xbmcplugin.setPluginCategory(handle, 'Pluto TV — %s' % group)
    xbmcplugin.setContent(handle, 'files')
    _list_channels(handle, build_url,
                   [c for c in live_sources.get_pluto_channels()
                    if c.get('group') == group], 'Pluto TV')


# ── Export ────────────────────────────────────────────────────────────────────

def export_iptv(handle, build_url):
    from resources.lib import live_sources
    epg = live_sources.get_epg_urls()
    msg = (
        'Pour une vraie grille EPG dans Kodi:\n\n'
        '1. Installez pvr.iptvsimple\n'
        '2. Samsung M3U: https://i.mjh.nz/SamsungTVPlus/ca.m3u8\n'
        '3. Plex M3U:    https://i.mjh.nz/Plex/all.m3u8\n\n'
        'EPG XMLTV:\n'
        '  Samsung: %s\n'
        '  Plex:    %s'
        % (epg.get('Samsung TV+', ''), epg.get('Plex', ''))
    )
    xbmcgui.Dialog().textviewer('Starfleet — Configuration EPG', msg)
    xbmcplugin.endOfDirectory(handle, succeeded=False)


# ── Playback ──────────────────────────────────────────────────────────────────

def list_live_news(handle, build_url):
    """Free worldwide news and entertainment channels — hardcoded reliable HLS streams."""
    from resources.lib import live_sources
    xbmcplugin.setPluginCategory(handle, '🌍 Free Worldwide News & Channels')
    xbmcplugin.setContent(handle, 'files')
    channels = live_sources.get_news_channels()
    _list_channels(handle, build_url, channels, source='Free News')
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)


def play_live_dai(handle, asset_key='', title='', channel_id=''):
    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet', 'Connexion à %s...' % title)
    # Prefer channel_id lookup (new); fall back to bare asset_key (legacy)
    if channel_id:
        from resources.lib.api import DAI_LIVE_CHANNELS
        ch = next((c for c in DAI_LIVE_CHANNELS if c['id'] == channel_id), None)
        url = api.get_live_stream_url(ch) if ch else None
    else:
        url = api.get_live_stream_url(asset_key)
    dlg.close()
    if not url:
        xbmcgui.Dialog().ok('Starfleet', 'Impossible d\'obtenir le flux pour %s.' % title)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(handle, True, _hls_item(url, title))


def play_direct(handle, stream_url, ch_id='', source='', title=''):
    from resources.lib import live_sources
    from resources.lib.resolvers import resolve, _is_direct
    if not stream_url or ('jwt=' in stream_url and 'pluto.tv' in stream_url):
        if ch_id and source == 'Pluto TV':
            stream_url = live_sources.get_pluto_stream(ch_id) or stream_url
    if not stream_url:
        xbmcgui.Dialog().ok('Starfleet', 'URL de lecture manquante.')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    # Run through premium resolvers (RD/AD/PM) for non-direct URLs
    stream_url = resolve(stream_url)
    xbmcplugin.setResolvedUrl(handle, True, _hls_item(stream_url, title))



# ── Adult Menu entry (added to main_menu separately) ─────────────────────────
# Called from default.py — kept here for consistency
def adult_menu_entry(handle, build_url):
    """Thin wrapper — actual menu is in afdb_router.py"""
    from resources.lib import afdb_router
    afdb_router.adult_menu(handle, build_url)
