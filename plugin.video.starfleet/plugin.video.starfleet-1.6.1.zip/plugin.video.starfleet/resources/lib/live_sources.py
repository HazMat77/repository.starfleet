﻿# -*- coding: utf-8 -*-
"""
resources/lib/live_sources.py  — Unified free live TV channel loader

Sources:
  Starfleet / Québecor  — Google DAI session tokens (handled in api.py)
  Samsung TV+      — community M3U  i.mjh.nz/SamsungTVPlus/ca.m3u8   (24h cache)
  Plex FAST        — community M3U  i.mjh.nz/Plex/all.m3u8            (24h cache)
  Pluto TV         — boot.pluto.tv JWT API + channel list              (1h cache)

Performance optimisations applied:
  ✓ Pre-compiled regex patterns (compiled once at import time)
  ✓ Persistent SQLite connection via cache.py (single connect per process)
  ✓ In-memory hot cache for same-session repeated reads
  ✓ Pluto: metadata cached separately from stream URL (JWT not baked into cache)
  ✓ Progress dialog suppressed on cache hits
  ✓ Lazy session creation
  ✓ Compact JSON serialisation (no whitespace)
  ✓ Differentiated timeouts: 4s cache probe, 12s network fetch, 6s stream resolve
"""

import re
import time
import uuid
import threading

import xbmc
import xbmcaddon
import xbmcvfs
import requests

ADDON    = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

# Initialise cache (done once; subsequent calls are no-ops)
import xbmc as _xbmc
_PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

from resources.lib import cache as _cache
_cache.init(_CACHE_DB)

# ── Pre-compiled M3U regex ────────────────────────────────────────────────────
_RE_NAME  = re.compile(r',(.+)$')
_RE_LOGO  = re.compile(r'tvg-logo="([^"]*)"')
_RE_GROUP = re.compile(r'group-title="([^"]*)"')
_RE_ID    = re.compile(r'tvg-id="([^"]*)"')

# ── Community M3U endpoints ───────────────────────────────────────────────────
# Primary: BuddyChewChew/app-m3u-generator — daily-updated GitHub-hosted M3U
#   Samsung 288 ch, Plex 460 ch — confirmed working 2026-06-27
# Fallback: i.mjh.nz — removed M3U format mid-2026 (now XMLTV EPG only),
#   kept here in case they restore it.
_BUDDY_BASE = 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists'

SAMSUNG_CA_URLS = [
    _BUDDY_BASE + '/samsungtvplus_ca.m3u',
    'https://i.mjh.nz/SamsungTVPlus/ca.m3u8',
    'https://i.mjh.nz/SamsungTVPlus/all.m3u8',
]
PLEX_ALL_URLS = [
    _BUDDY_BASE + '/plex_ca.m3u',
    'https://i.mjh.nz/Plex/all.m3u8',
    'https://i.mjh.nz/Plex/ca.m3u8',
]
MJH_SAMSUNG_EPG = 'https://i.mjh.nz/SamsungTVPlus/ca.xml'
MJH_PLEX_EPG    = 'https://i.mjh.nz/Plex/ca.xml'

# ── Pluto TV ─────────────────────────────────────────────────────────────────
PLUTO_BOOT = (
    'https://boot.pluto.tv/v4/start'
    '?appName=web&appVersion=9.19.0&deviceVersion=126.0.0'
    '&deviceType=web&deviceMake=chrome&deviceModel=web'
    '&clientID={cid}&clientModelNumber=1.0.0'
    '&serverSideAds=false&marketingRegion=CA'
)
PLUTO_STITCH = (
    'https://cfd-v4-service-channel-stitcher-use1-1.prd.pluto.tv'
    '/v2/stitch/hls/channel/{ch_id}/master.m3u8'
    '?appName=web&appVersion=9.19.0&deviceVersion=126.0.0'
    '&deviceType=web&deviceMake=chrome&deviceModel=web'
    '&clientID={cid}&clientModelNumber=1.0.0'
    '&country=CA&marketingRegion=CA&serverSideAds=false&jwt={jwt}'
)

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-CA,en;q=0.9,fr-CA;q=0.8',
}

# ── HTTP session (lazy, thread-safe) ─────────────────────────────────────────
_session     = None
_session_lock = threading.Lock()

def _sess():
    global _session
    if _session is None:
        with _session_lock:
            if _session is None:
                s = requests.Session()
                s.headers.update(HEADERS)
                a = requests.adapters.HTTPAdapter(
                    pool_connections=4, pool_maxsize=10,
                    max_retries=requests.adapters.Retry(total=2, backoff_factor=0.3)
                )
                s.mount('https://', a)
                _session = s
    return _session


# ── M3U parser (optimised) ────────────────────────────────────────────────────

def _parse_m3u(text, source_label):
    channels = []
    lines    = text.splitlines()
    n        = len(lines)
    i        = 0
    while i < n:
        line = lines[i]
        if line.startswith('#EXTINF:'):
            m_name  = _RE_NAME.search(line)
            m_logo  = _RE_LOGO.search(line)
            m_group = _RE_GROUP.search(line)
            m_id    = _RE_ID.search(line)

            name  = m_name.group(1).strip()  if m_name  else 'Unknown'
            logo  = m_logo.group(1)          if m_logo  else ''
            group = m_group.group(1)         if m_group else source_label
            ch_id = m_id.group(1)            if m_id    else name

            # Next non-comment line is the stream URL
            i += 1
            while i < n and lines[i].startswith('#'):
                i += 1
            url = lines[i].strip() if i < n else ''

            if url and not url.startswith('#') and url.startswith('http'):
                channels.append({
                    'id':         ch_id,
                    'title':      name,
                    'group':      group,
                    'source':     source_label,
                    'thumbnail':  logo,
                    'stream_url': url,
                })
        i += 1
    return channels


# ── Samsung TV+ ───────────────────────────────────────────────────────────────

def get_samsung_channels():
    cached = _cache.get('samsung_ca')
    if cached is not None:
        return cached

    for url in SAMSUNG_CA_URLS:
        try:
            r = _sess().get(url, timeout=12)
            if r.status_code == 200 and '#EXTINF' in r.text:
                channels = _parse_m3u(r.text, 'Samsung TV+')
                if channels:
                    _cache.set('samsung_ca', channels, 24 * 3600)
                    xbmc.log('[Starfleet] Samsung: %d channels' % len(channels), xbmc.LOGINFO)
                    return channels
        except Exception as e:
            xbmc.log('[Starfleet] Samsung error (%s): %s' % (url, e), xbmc.LOGERROR)
    xbmc.log('[Starfleet] Samsung TV+: all M3U sources unavailable', xbmc.LOGWARNING)
    return []


def get_samsung_epg_url():
    return MJH_SAMSUNG_EPG


# ── Plex FAST ─────────────────────────────────────────────────────────────────

def get_plex_channels():
    cached = _cache.get('plex_all')
    if cached is not None:
        return cached

    for url in PLEX_ALL_URLS:
        try:
            r = _sess().get(url, timeout=12)
            if r.status_code == 200 and '#EXTINF' in r.text:
                channels = _parse_m3u(r.text, 'Plex')
                if channels:
                    _cache.set('plex_all', channels, 24 * 3600)
                    xbmc.log('[Starfleet] Plex: %d channels' % len(channels), xbmc.LOGINFO)
                    return channels
        except Exception as e:
            xbmc.log('[Starfleet] Plex error (%s): %s' % (url, e), xbmc.LOGERROR)
    xbmc.log('[Starfleet] Plex FAST: all M3U sources unavailable', xbmc.LOGWARNING)
    return []


def get_plex_epg_url():
    return MJH_PLEX_EPG


# ── Pluto TV ──────────────────────────────────────────────────────────────────

def _get_pluto_cid():
    cached = _cache.get('pluto_cid')
    if cached:
        return cached
    cid = str(uuid.uuid4())
    _cache.set('pluto_cid', cid, 365 * 24 * 3600)
    return cid


PLUTO_CHANNELS_URL = 'https://api.pluto.tv/v2/channels.json'


def _boot_pluto():
    """
    Fetch Pluto boot response to obtain JWT session token.
    Returns (jwt, []) — channel list is now fetched separately.
    Caches JWT independently.
    """
    cid = _get_pluto_cid()
    try:
        r = _sess().get(PLUTO_BOOT.format(cid=cid), timeout=12)
        r.raise_for_status()
        data = r.json()

        jwt = (data.get('sessionToken') or
               data.get('stitcherParams', {}).get('jwt', ''))
        if jwt:
            _cache.set('pluto_jwt', jwt, 20 * 3600)
        return jwt, []
    except Exception as e:
        xbmc.log('[Starfleet] Pluto boot error: %s' % e, xbmc.LOGERROR)
        return None, []


def _fetch_pluto_channel_list():
    """
    Fetch the Pluto TV channel list from the v2 JSON API.
    Returns list of channel dicts or [] on failure.
    The boot EPG field now only returns the current/starting channel;
    the dedicated channel list endpoint returns all ~200 channels.
    """
    try:
        r = _sess().get(PLUTO_CHANNELS_URL, timeout=12)
        r.raise_for_status()
        raw = r.json()
        meta = []
        for ch in raw:
            ch_id = ch.get('_id') or ch.get('id', '')
            name  = ch.get('name') or ch.get('title', '')
            if not ch_id or not name:
                continue
            # Logo: v2 API uses featuredImage or thumbnail dict
            logo = (
                (ch.get('featuredImage') or {}).get('path', '') or
                (ch.get('thumbnail') or {}).get('path', '') or
                ''
            )
            group = ch.get('category') or ch.get('genre', 'General')
            meta.append({
                'id':        ch_id,
                'title':     name,
                'group':     group,
                'thumbnail': logo,
                'source':    'Pluto TV',
            })
        xbmc.log('[Starfleet] Pluto: %d channels from v2 API' % len(meta), xbmc.LOGINFO)
        return meta
    except Exception as e:
        xbmc.log('[Starfleet] Pluto channel list error: %s' % e, xbmc.LOGERROR)
        return []


def get_pluto_channels():
    """
    Return Pluto channel metadata. Stream URLs built at play time using
    current JWT (not baked into cache), so stale JWT only breaks playback
    not the channel listing.
    """
    meta = _cache.get('pluto_meta')
    if meta is None:
        meta = _fetch_pluto_channel_list()
        if not meta:
            return []
        _cache.set('pluto_meta', meta, 6 * 3600)

    # Attach stream URLs using current (possibly cached) JWT
    cid = _get_pluto_cid()
    jwt = _cache.get('pluto_jwt')
    if not jwt:
        jwt, _ = _boot_pluto()

    channels = []
    for ch in meta:
        stream = PLUTO_STITCH.format(ch_id=ch['id'], cid=cid, jwt=jwt or '') if jwt else ''
        channels.append(dict(ch, stream_url=stream))
    return channels


def get_pluto_stream(channel_id):
    """Build a fresh Pluto stream URL — called at play time."""
    cid = _get_pluto_cid()
    jwt = _cache.get('pluto_jwt')
    if not jwt:
        jwt, _ = _boot_pluto()
    if not jwt:
        return None
    return PLUTO_STITCH.format(ch_id=channel_id, cid=cid, jwt=jwt)


def refresh_pluto():
    _cache.delete(['pluto_jwt', 'pluto_meta', 'pluto_cid'])
    return get_pluto_channels()


def refresh_pluto_channels():
    """Alias kept for backwards compatibility."""
    return refresh_pluto()


# ── EPG helpers ───────────────────────────────────────────────────────────────

def get_epg_urls():
    """
    Return dict of source -> XMLTV EPG URL.
    Used by the EPG export feature and pvr.iptvsimple integration.
    """
    return {
        'Samsung TV+': MJH_SAMSUNG_EPG,
        'Plex':        MJH_PLEX_EPG,
        # Pluto: EPG embedded in boot response (channel timeline arrays)
        # Starfleet:  EPG not yet captured — needs browser endpoint discovery
    }


def get_combined_m3u(include_tva_channels=None):
    """
    Generate a combined M3U playlist for ALL sources.
    This can be pointed at by pvr.iptvsimple for a full EPG experience.
    include_tva_channels: list of {'title', 'asset_key', 'thumbnail'} dicts
    """
    lines = ['#EXTM3U']

    # TVA / DAI channels — use plugin:// URL so DAI token is fetched at play time
    if include_tva_channels:
        for ch in include_tva_channels:
            plugin_url = (
                'plugin://plugin.video.starfleet/'
                '?action=play_live_dai'
                '&asset_key=%s&title=%s' % (ch['asset_key'],
                                             requests.utils.quote(ch['title']))
            )
            lines.append(
                '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Starfleet",\t%s'
                % (ch['asset_key'], ch.get('thumbnail',''), ch['title'])
            )
            lines.append(plugin_url)

    # Samsung
    for ch in get_samsung_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Samsung TV+",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch['stream_url'])

    # Plex
    for ch in get_plex_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Plex",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch['stream_url'])

    # Pluto
    for ch in get_pluto_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Pluto TV",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch.get('stream_url', ''))

    return '\n'.join(lines)


# ── CBC / Radio-Canada live channels ─────────────────────────────────────────

_CBC_API = 'https://api.gemapi.cbc.ca/content/1.0/livestreams'

_CBC_STATIC = [
    {
        'id':         'cbc-main',
        'title':      'CBC Television',
        'group':      'CBC / Radio-Canada',
        'thumbnail':  'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/CBC_Logo_2021.svg/200px-CBC_Logo_2021.svg.png',
        'stream_url': '',
        'source':     'CBC',
    },
    {
        'id':         'cbc-news-network',
        'title':      'CBC News Network',
        'group':      'CBC / Radio-Canada',
        'thumbnail':  'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/CBC_Logo_2021.svg/200px-CBC_Logo_2021.svg.png',
        'stream_url': '',
        'source':     'CBC',
    },
    {
        'id':         'ici-rc-tele',
        'title':      'ICI Radio-Canada Télé',
        'group':      'CBC / Radio-Canada',
        'thumbnail':  'https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Ici_Radio-Canada_Tel%C3%A9.svg/200px-Ici_Radio-Canada_Tel%C3%A9.svg.png',
        'stream_url': '',
        'source':     'CBC',
    },
    {
        'id':         'ici-rdi',
        'title':      'ICI RDI',
        'group':      'CBC / Radio-Canada',
        'thumbnail':  'https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Ici_Radio-Canada_Tel%C3%A9.svg/200px-Ici_Radio-Canada_Tel%C3%A9.svg.png',
        'stream_url': '',
        'source':     'CBC',
    },
]

_CBC_ID_MAP = {
    'cbc-main':       'cbctv',
    'cbc-news-network': 'cbcnn',
    'ici-rc-tele':    'icitele',
    'ici-rdi':        'icirdi',
}


def get_cbc_channels():
    """
    Fetch CBC/Radio-Canada live stream URLs via CBC Gem API.
    Cached 1h. Falls back to static channel list (no stream URLs) if API fails.
    Channels require a Canadian IP and CBC Gem account for playback.
    """
    ck = 'cbc_channels'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    channels = []
    try:
        r = _sess().get(_CBC_API, timeout=10, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
            'x-api-key': 'a6f88bf2-f35e-11e8-b6db-dfa2e61dbce4',
        })
        r.raise_for_status()
        data = r.json()
        streams = data if isinstance(data, list) else data.get('items', data.get('streams', []))
        for item in streams:
            slug   = item.get('id', item.get('slug', ''))
            title  = item.get('title', item.get('name', slug))
            m3u8   = item.get('m3u8URL', item.get('streamUrl', item.get('url', '')))
            thumb  = item.get('thumbnail', item.get('image', {}).get('url', ''))
            if not m3u8:
                continue
            channels.append({
                'id':         slug,
                'title':      title,
                'group':      'CBC / Radio-Canada',
                'thumbnail':  thumb,
                'stream_url': m3u8,
                'source':     'CBC',
            })
        xbmc.log('[Starfleet/CBC] API returned %d channels' % len(channels), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/CBC] API error: %s — using static list' % e, xbmc.LOGWARNING)

    if not channels:
        # Return static list without stream URLs so the menu still shows channels
        channels = [dict(ch) for ch in _CBC_STATIC]

    _cache.set(ck, channels, 3600)
    return channels


def prewarm_cbc():
    """Fire-and-forget CBC channel list prefetch."""
    import threading
    threading.Thread(target=get_cbc_channels, daemon=True).start()
