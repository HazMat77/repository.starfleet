# -*- coding: utf-8 -*-
"""
resources/lib/torrent_sources.py

Search multiple torrent sites for a title and return magnet links.
Results are used with debrid services (Real-Debrid, AllDebrid, Premiumize, TorBox)
to get instant cached streams — uncached torrents are skipped.

Sources:
  YTS          — JSON API, movies only, high quality
  1337x        — HTML scraping, mirror rotation + CF bypass
  The Pirate Bay — JSON API, movies + TV + adult
  EZTV         — JSON API, TV shows
  Bitsearch    — DHT index scrape
  TorrentGalaxy — HTML scraping + CF bypass
  YourBitTorrent — HTML scraping
  Bitlord      — HTML scraping
  Knaben       — aggregated JSON API (movies/TV/adult)
  Torrentio    — Stremio IMDB-based API
  Torrentdownload — HTML scraping
"""

import re
import time
import xbmc

try:
    import requests as _req
except ImportError:
    _req = None

# ── Quality helpers ───────────────────────────────────────────────────────────

# High-quality markers
_QUALITY_HQ = re.compile(
    r'\b(?:720p?|1080p?|1080i|2160p?|4k|uhd|3d|bd(?:rip|remux)|bluray|blu[-\s]?ray)\b',
    re.IGNORECASE
)
# Any recognisable video quality marker (accepts HDTV/WEB/x265 without resolution)
_QUALITY_ANY = re.compile(
    r'\b(?:720|1080|2160|4k|uhd|3d|bluray|blu.ray|bdrip|bdremux|'
    r'web[-.]?dl|webdl|webrip|web.rip|hdtv|hdrip|dvdrip|dvd|'
    r'x264|x265|hevc|h\.?264|h\.?265|xvid|avc|hevcrip|remux|'
    r'hdcam|scr|screener|dvdscr)\b',
    re.IGNORECASE
)
# Definitively low-quality markers
_QUALITY_LQ = re.compile(
    r'\b(?:480p?|360p?|240p?|camrip|hdcam|scr|screener|dvdscr)\b',
    re.IGNORECASE
)


def _meets_quality(text, media_type='movie'):
    """
    Return True if this torrent is acceptable quality.
    Only hard-reject explicitly low quality (480p, cam, screener).
    Accept anything without a quality tag — debrid cache check filters further.
    """
    if media_type == 'adult':
        return True
    s = (text or '').lower()
    return not bool(_QUALITY_LQ.search(s))


def _extract_quality(text):
    text = text or ''
    for pat, label in [
        (r'\b2160p?\b|\b4k\b|\buhd\b',           '4K'),
        (r'\b1080p?\b|\b1080i\b',                 '1080p'),
        (r'\b720p?\b',                             '720p'),
        (r'\b3d\b',                                '3D'),
        (r'\bbluray\b|\bbl(?:u[-\s]?ray)\b',       'Blu-ray'),
        (r'\bweb[-.]?dl\b|\bwebdl\b',             'WEB-DL'),
        (r'\bwebrip\b',                            'WEBRip'),
        (r'\bhdtv\b',                              'HDTV'),
    ]:
        if re.search(pat, text, re.IGNORECASE):
            return label
    return ''


# ── HTTP session & Cloudflare bypass ─────────────────────────────────────────

_BROWSER_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'DNT': '1',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
}

_session = None
_cf_session = None  # cloudscraper session (created lazily)


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_BROWSER_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5, redirect=False)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get_cf_session():
    """Return a cloudscraper session if available, else None."""
    global _cf_session
    if _cf_session is not None:
        return _cf_session
    try:
        import cloudscraper
        _cf_session = cloudscraper.create_scraper(
            browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
        )
        xbmc.log('[Starfleet/Torrents] cloudscraper loaded', xbmc.LOGINFO)
        return _cf_session
    except ImportError:
        pass
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] cloudscraper init failed: %s' % e, xbmc.LOGWARNING)
    return None


def _get(url, timeout=10, cf=False):
    """HTTP GET. If cf=True, try cloudscraper first to bypass Cloudflare."""
    if cf:
        cs = _get_cf_session()
        if cs:
            try:
                r = cs.get(url, timeout=timeout)
                r.raise_for_status()
                return r.text
            except Exception as e:
                xbmc.log('[Starfleet/Torrents] CF session failed (%s): %s' % (url[:60], e),
                         xbmc.LOGWARNING)
    s = _sess()
    if not s:
        return ''
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _get_json(url, timeout=10):
    s = _sess()
    if not s:
        return None
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _make_magnet(info_hash, name=''):
    trackers = [
        'udp://tracker.opentrackr.org:1337/announce',
        'udp://open.tracker.cl:1337/announce',
        'udp://tracker.openbittorrent.com:6969/announce',
        'udp://tracker.torrent.eu.org:451/announce',
    ]
    dn = ('&dn=' + _req.utils.quote(name)) if name and _req else ''
    tr = ''.join('&tr=' + t for t in trackers)
    return 'magnet:?xt=urn:btih:%s%s%s' % (info_hash.lower(), dn, tr)


# ── YTS ──────────────────────────────────────────────────────────────────────

_YTS_DOMAINS = [
    'https://yts.lt',
    'https://yts.mx',
    'https://yts.proxyninja.org',
]


def search_yts(title, year=None, limit=5, media_type='movie'):
    if media_type not in ('movie', 'adult'):
        return []
    try:
        params = {'query_term': title, 'limit': limit, 'sort_by': 'seeds'}
        if year:
            params['query_term'] = '%s %s' % (title, year)
        qs = '&'.join('%s=%s' % (k, v) for k, v in params.items())
        data = None
        for domain in _YTS_DOMAINS:
            data = _get_json(domain + '/api/v2/list_movies.json?' + qs)
            if data and data.get('status') == 'ok':
                break
            data = None
        if not data:
            return []
        movies = data.get('data', {}).get('movies') or []
        results = []
        for movie in movies:
            for tor in movie.get('torrents', []):
                ih = tor.get('hash', '')
                if not ih:
                    continue
                quality = tor.get('quality', '')
                if not _meets_quality(quality, media_type):
                    continue
                results.append({
                    'title':     movie.get('title_english') or movie.get('title', ''),
                    'year':      movie.get('year', ''),
                    'quality':   _extract_quality(quality) or quality,
                    'info_hash': ih,
                    'magnet':    _make_magnet(ih, movie.get('title', '')),
                    'seeds':     tor.get('seeds', 0),
                    'size':      tor.get('size', ''),
                    'source':    'YTS',
                })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YTS error: %s' % e, xbmc.LOGWARNING)
        return []


# ── The Pirate Bay ────────────────────────────────────────────────────────────

TPB_BASE = 'https://apibay.org'


def search_tpb(title, year=None, category=200, limit=10, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        data = _get_json(TPB_BASE + '/q.php?q=%s&cat=%d' % (query, category), timeout=8)
        if not data or not isinstance(data, list):
            return []
        results = []
        for item in data[:limit]:
            ih = item.get('info_hash', '')
            if not ih or ih == '0000000000000000000000000000000000000000':
                continue
            name = item.get('name', '')
            if not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(item.get('seeders', 0)),
                'size':      item.get('size', ''),
                'source':    'TPB',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TPB error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 1337x (mirror rotation + Cloudflare bypass) ───────────────────────────────

_LEET_MIRRORS = [
    '1337x.se', '1337x.tw', '1337x.pro', '1337x.to',
    '1337x.st', '1337x.ws', '1337x.gd', 'www.1377x.is',
]
_leet_working = {}  # {'url': ..., 'ts': ...}

_RE_LEET_MAGNET = re.compile(r'href="(magnet:[^"]+)"', re.IGNORECASE)


def _get_leet_base():
    """Return a working 1337x mirror, cached for 1 hour."""
    cached = _leet_working.get('url')
    ts = _leet_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached

    for mirror in _LEET_MIRRORS:
        try:
            url = 'https://%s' % mirror
            html = _get(url + '/home/', timeout=7, cf=True)
            if html and '1337x' in html.lower():
                _leet_working['url'] = url
                _leet_working['ts'] = time.time()
                xbmc.log('[Starfleet/Torrents] 1337x using mirror: %s' % url, xbmc.LOGINFO)
                return url
        except Exception:
            continue

    fallback = 'https://' + _LEET_MIRRORS[0]
    xbmc.log('[Starfleet/Torrents] 1337x all mirrors failed, using: %s' % fallback, xbmc.LOGWARNING)
    return fallback


def _leet_get_magnet(path, base):
    try:
        html = _get(base + path, timeout=8, cf=True)
        m = _RE_LEET_MAGNET.search(html)
        if m:
            return m.group(1).split('&tr=')[0]
    except Exception:
        pass
    return ''


_RE_LEET_ROW = re.compile(
    r'<td[^>]+class="[^"]*coll-1[^"]*"[^>]*>.*?'
    r'href="(/torrent/\d+/[^"]+)"[^>]*>([^<]+)</a>.*?'
    r'<td[^>]+class="[^"]*coll-2[^"]*"[^>]*>(\d+)<',
    re.IGNORECASE | re.DOTALL
)


def search_1337x(title, year=None, limit=5, media_type='movie'):
    try:
        base = _get_leet_base()
        cat = 'TV' if media_type == 'tv' else 'Movies'
        query = title.replace(' ', '+')
        if year and media_type != 'adult':
            query += '+' + str(year)

        if media_type == 'adult':
            url = '%s/search/%s/1/' % (base, query)
        else:
            url = '%s/sort-category-search/%s/%s/seeders/desc/1/' % (base, query, cat)

        html = _get(url, timeout=10, cf=True)
        if not html:
            return []

        candidates = []
        for m in _RE_LEET_ROW.finditer(html):
            if len(candidates) >= limit:
                break
            path, name, seeds = m.group(1), m.group(2).strip(), m.group(3)
            if not _meets_quality(name, media_type):
                continue
            candidates.append((path, name, int(seeds)))

        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor, as_completed as _ac2
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 5)) as pool:
            fmap = {pool.submit(_leet_get_magnet, path, base): (name, seeds)
                    for path, name, seeds in candidates}
            for fut in _ac2(fmap, timeout=12):
                name, seeds = fmap[fut]
                try:
                    magnet = fut.result()
                except Exception:
                    magnet = ''
                if not magnet:
                    continue
                ih_m = re.search(r'urn:btih:([a-fA-F0-9]{40})', magnet)
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': ih_m.group(1).lower() if ih_m else '',
                    'magnet':    magnet,
                    'seeds':     seeds,
                    'size':      '',
                    'source':    '1337x',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] 1337x error: %s' % e, xbmc.LOGWARNING)
        return []


# ── EZTV (TV shows) ───────────────────────────────────────────────────────────

EZTV_BASE = 'https://eztvx.to'


def search_eztv(title, year=None, limit=5):
    try:
        query = title
        if year:
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        data = _get_json('%s/api/get-torrents?search=%s&limit=%d' % (
            EZTV_BASE, query, max(limit * 3, 15)), timeout=8)
        if not data or not isinstance(data.get('torrents'), list):
            return []
        results = []
        for item in data['torrents']:
            name = item.get('filename', '') or item.get('title', '')
            ih = item.get('hash', '')
            if not ih or not name:
                continue
            if not _meets_quality(name, 'tv'):
                continue
            magnet = item.get('magnet_url', '') or _make_magnet(ih, name)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    magnet,
                'seeds':     int(item.get('seeds', 0)),
                'size':      str(item.get('size_bytes', '')),
                'source':    'EZTV',
            })
            if len(results) >= limit:
                break
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] EZTV error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitsearch ─────────────────────────────────────────────────────────────────

BITSEARCH_BASE = 'https://bitsearch.to'
_BS_CARD  = 'p-6 hover:shadow-md'
_RE_BS_TITLE = re.compile(r'<h3[^>]*>\s*<a[^>]*>\s*(.*?)\s*</a>', re.IGNORECASE | re.DOTALL)
_RE_BS_SEEDS = re.compile(r'font-medium">(\d+)</span>\s*<span>seeders</span>', re.IGNORECASE)
_RE_BS_SIZE  = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_bitsearch(title, year=None, limit=5, media_type='movie'):
    try:
        import html as _html
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/search?q=%s&sort=seeders' % (BITSEARCH_BASE, query)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        text = _html.unescape(html_raw)
        results = []
        for card in text.split(_BS_CARD)[1:]:
            if len(results) >= limit:
                break
            try:
                mag_m = re.search(r'href="(magnet:\?[^"]+)"', card, re.IGNORECASE)
                if not mag_m:
                    continue
                magnet = mag_m.group(1).replace('&amp;', '&')
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if not ih_m:
                    continue
                info_hash = ih_m.group(1).lower()
                t_m = _RE_BS_TITLE.search(card)
                name = re.sub(r'\s+', ' ', t_m.group(1)).strip() if t_m else ''
                name = re.sub(r'<[^>]+>', '', name).strip()
                if not name or not _meets_quality(name, media_type):
                    continue
                seeds = 0
                s_m = _RE_BS_SEEDS.search(card)
                if s_m:
                    seeds = int(s_m.group(1))
                size = ''
                z_m = _RE_BS_SIZE.search(card)
                if z_m:
                    size = z_m.group(0)
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': info_hash,
                    'magnet':    magnet,
                    'seeds':     seeds,
                    'size':      size,
                    'source':    'Bitsearch',
                })
            except Exception:
                continue
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitsearch error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentGalaxy (CF bypass) ────────────────────────────────────────────────

_TGX_MIRRORS = ['torrentgalaxy.mx', 'torrentgalaxy.to', 'tgx.rs']
_tgx_working = {}

_RE_TGX_MAGNET = re.compile(r'a\s+href="(magnet:[^"]+)"', re.IGNORECASE)
_RE_TGX_SIZE   = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)
_TGX_SKIP_LANG = re.compile(r'\b(FRENCH|TRUEFRENCH|ITALIAN|Ita|SPANISH|DUBBED|LAT|Dublado)\b',
                             re.IGNORECASE)


def _get_tgx_base():
    cached = _tgx_working.get('url')
    ts = _tgx_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _TGX_MIRRORS:
        try:
            url = 'https://%s' % mirror
            html = _get(url + '/torrents.php', timeout=7, cf=True)
            if html and 'torrent' in html.lower():
                _tgx_working['url'] = url
                _tgx_working['ts'] = time.time()
                xbmc.log('[Starfleet/Torrents] TGX using mirror: %s' % url, xbmc.LOGINFO)
                return url
        except Exception:
            continue
    return 'https://' + _TGX_MIRRORS[0]


def search_torrentgalaxy(title, year=None, limit=5, media_type='movie'):
    try:
        base = _get_tgx_base()
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/torrents.php?search=%s' % (base, query)
        html_raw = _get(url, timeout=10, cf=True)
        if not html_raw:
            return []
        results = []
        for row in re.finditer(r'<div[^>]+class="[^"]*tgxtable[^"]*"[^>]*>(.*?)</div>',
                                html_raw, re.IGNORECASE | re.DOTALL):
            if len(results) >= limit:
                break
            row_text = row.group(1)
            mag_m = _RE_TGX_MAGNET.search(row_text)
            if not mag_m:
                continue
            magnet = mag_m.group(1)
            if _TGX_SKIP_LANG.search(magnet):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            dn_m = re.search(r'[&?]dn=([^&]+)', magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else info_hash
            if not _meets_quality(name, media_type):
                continue
            z_m = _RE_TGX_SIZE.search(row_text)
            size = z_m.group(0) if z_m else ''
            seeds_m = re.search(r'<span[^>]+>(\d+)</span>\s*seeders', row_text, re.IGNORECASE)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'TGX',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentGalaxy error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Knaben meta-search (movies / TV / adult) ──────────────────────────────────

KNABEN_API     = 'https://api.knaben.org/v1'
# Updated category IDs — Knaben changed from string "3_000_000" to integer u64
KNABEN_MOVIES  = [3001000, 3000000]   # Movies/HD first, then general Movies
KNABEN_TV      = [2001000, 2000000]   # TV/HD first, then general TV
# No fixed adult category — search without category filter for adult

_KNABEN_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept':       'application/json',
    'Content-Type': 'application/json',
}


def search_knaben(title, year=None, media_type='movie', limit=10):
    try:
        import json as _json
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)

        body = {'query': query, 'order_by': 'seeders'}
        if media_type == 'tv':
            body['categories'] = KNABEN_TV
        elif media_type == 'movie':
            body['categories'] = KNABEN_MOVIES
        # adult: no category filter — search everything

        if not _req:
            return []
        r = _sess().post(KNABEN_API, json=body, headers=_KNABEN_HEADERS, timeout=10)
        if r.status_code >= 400:
            return []
        hits = r.json().get('hits', [])
        results = []
        for entry in hits:
            if len(results) >= limit:
                break
            name = entry.get('title', '')
            if not name or not _meets_quality(name, media_type):
                continue
            ih = (entry.get('hash') or '').lower()
            if not ih or len(ih) != 40:
                continue
            magnet = entry.get('magnetUrl') or _make_magnet(ih, name)
            seeds  = int(entry.get('seeders') or 0)
            b = entry.get('bytes') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'Knaben',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Knaben error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentio (IMDB-based Stremio API) ───────────────────────────────────────

TORRENTIO_BASE = 'https://torrentio.strem.fun'
_RE_TIO_INFO = re.compile(r'👤.*')


def search_torrentio(imdb_id, media_type='movie', season=None, episode=None, limit=20):
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/stream/series/%s:%s:%s.json' % (TORRENTIO_BASE, imdb_id, season, episode)
        else:
            url = '%s/stream/movie/%s.json' % (TORRENTIO_BASE, imdb_id)
        data = _get_json(url, timeout=15)
        if not data or not isinstance(data.get('streams'), list):
            return []
        results = []
        for stream in data['streams'][:limit]:
            ih = stream.get('infoHash')
            if not ih:
                continue
            title_parts = (stream.get('title') or '').split('\n')
            name = title_parts[0].strip()
            if not name:
                continue
            info_lines = [x for x in title_parts if _RE_TIO_INFO.match(x)]
            seeds = 0
            size = ''
            if info_lines:
                s_m = re.search(r'(\d+)', info_lines[0])
                if s_m:
                    seeds = int(s_m.group(1))
                z_m = re.search(r'(\d+(?:\.\d+)?)\s*(GB|GiB|MB|MiB)', info_lines[0], re.IGNORECASE)
                if z_m:
                    size = z_m.group(0)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Torrentio',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torrentio error: %s' % e, xbmc.LOGWARNING)
        return []


# ── YourBitTorrent ────────────────────────────────────────────────────────────

YBT_BASE = 'https://yourbittorrent2.com'
_RE_YBT_LINK = re.compile(r'<a href="(/torrent/[^"]+)"', re.IGNORECASE)
_RE_YBT_HASH = re.compile(r'<kbd>([a-fA-F0-9]{40})<', re.IGNORECASE)
_RE_YBT_NAME = re.compile(r'<h3 class="card-title">([^<]+)<', re.IGNORECASE)
_RE_YBT_SIZE = re.compile(r'File size:</div><div class="col">([^<]+)<', re.IGNORECASE)
_RE_YBT_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_yourbittorrent(title, year=None, limit=5, media_type='movie'):
    try:
        from concurrent.futures import ThreadPoolExecutor
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        from urllib.parse import quote_plus as _qp
        query_enc = _qp(query).replace('+', '-')
        html_raw = _get('%s?q=%s' % (YBT_BASE, query_enc), timeout=8)
        if not html_raw:
            return []
        links = _RE_YBT_LINK.findall(html_raw)[:limit]

        def _fetch(link):
            try:
                detail = _get(YBT_BASE + link, timeout=8)
                ih_m = _RE_YBT_HASH.search(detail)
                nm_m = _RE_YBT_NAME.search(detail)
                if not ih_m or not nm_m:
                    return None
                ih = ih_m.group(1).lower()
                name = nm_m.group(1).strip()
                if not _meets_quality(name, media_type):
                    return None
                if _RE_YBT_LANG.search(name):
                    return None
                sz_m = _RE_YBT_SIZE.search(detail)
                size = sz_m.group(1).strip() if sz_m else ''
                return {
                    'title': name, 'year': '', 'quality': _extract_quality(name),
                    'info_hash': ih, 'magnet': _make_magnet(ih, name),
                    'seeds': 0, 'size': size, 'source': 'YourBT',
                }
            except Exception:
                return None

        results = []
        with ThreadPoolExecutor(max_workers=min(len(links), limit)) as pool:
            for r in pool.map(_fetch, links, timeout=10):
                if r and len(results) < limit:
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YourBitTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentdownload.info (Tordl) ──────────────────────────────────────────────

TORDL_BASE = 'https://www.torrentdownload.info'
_RE_TORDL_LINK = re.compile(r'href="/([a-fA-F0-9]{40})/([^"]+)"', re.IGNORECASE)
_RE_TORDL_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_tordl(title, year=None, limit=5, media_type='movie'):
    try:
        from urllib.parse import quote_plus as _qp
        query = title.lower()
        if year and media_type != 'adult':
            query = '%s %s' % (query, year)
        url = '%s/search?q=%s' % (TORDL_BASE, _qp(query))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for m in _RE_TORDL_LINK.finditer(html):
            if len(results) >= limit:
                break
            ih = m.group(1).lower()
            name = m.group(2).replace('+', ' ').replace('-', ' ')
            name = re.sub(r'[_%]', ' ', name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            # Size is approximate from listing
            magnet = _make_magnet(ih, name)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     0,
                'size':      '',
                'source':    'Tordl',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Tordl error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitlord ───────────────────────────────────────────────────────────────────

BITLORD_BASE = 'http://www.bitlordsearch.com'
_RE_BL_MAG  = re.compile(
    r'class="btn btn-default magnet-button[^"]*"[^>]+href="([^"]+)"', re.IGNORECASE
)
_RE_BL_SIZE = re.compile(r'<td class="size">(\d+)</td>', re.IGNORECASE)
_RE_BL_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_bitlord(title, year=None, limit=5, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        html_raw = _get('%s/search?q=%s' % (BITLORD_BASE, query), timeout=10)
        if not html_raw:
            return []
        magnets = _RE_BL_MAG.findall(html_raw)
        sizes   = _RE_BL_SIZE.findall(html_raw)
        results = []
        for i, mag in enumerate(magnets):
            if len(results) >= limit:
                break
            mag = mag.replace('&amp;', '&').split('&tr=')[0]
            if 'magnet' not in mag:
                continue
            dn_m = re.search(r'&dn=([^&]+)', mag)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else ''
            if not name or not _meets_quality(name, media_type):
                continue
            if _RE_BL_LANG.search(name):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', mag, re.IGNORECASE)
            info_hash = ih_m.group(1).lower() if ih_m else ''
            size = ''
            if i < len(sizes):
                try:
                    b = int(sizes[i])
                    if b >= 1_073_741_824:
                        size = '%.1f GB' % (b / 1_073_741_824)
                    elif b >= 1_048_576:
                        size = '%.0f MB' % (b / 1_048_576)
                except Exception:
                    pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': mag,
                'seeds': 0, 'size': size, 'source': 'Bitlord',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitlord error: %s' % e, xbmc.LOGWARNING)
        return []


# ── MagnetDL ──────────────────────────────────────────────────────────────────

MAGNETDL_BASE = 'https://www.magnetdl.hair'
_RE_MDL_ROW  = re.compile(
    r'href="(/([a-fA-F0-9]{40})/([^"]+))"', re.IGNORECASE
)


def search_magnetdl(title, year=None, limit=5, media_type='movie'):
    """MagnetDL — magnets are embedded in search-result URLs, no per-page fetch."""
    try:
        from urllib.parse import quote as _q2
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        slug = re.sub(r'[^\w\s-]', '', query.lower()).strip()
        slug = re.sub(r'[\s_]+', '-', slug)
        first = slug[0] if slug else 'm'
        url = '%s/%s/%s/' % (MAGNETDL_BASE, first, slug)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        seen_hashes = set()
        for m in _RE_MDL_ROW.finditer(html_raw):
            if len(results) >= limit:
                break
            ih = m.group(2).lower()
            if ih in seen_hashes:
                continue
            raw_name = m.group(3)
            name = re.sub(r'[_+]+', ' ', raw_name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            seen_hashes.add(ih)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      '',
                'source':    'MagnetDL',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] MagnetDL error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentDownloads (RSS) ────────────────────────────────────────────────────

TDOWNLOADS_BASE = 'https://www.torrentdownloads.pro'
_RE_TD_ITEM = re.compile(
    r'<info_hash>([a-fA-F0-9]{40})</info_hash>.*?'
    r'<title>(.+?)</title>.*?'
    r'<size>(\d+)</size>.*?'
    r'<seeders>(\d+)</seeders>',
    re.IGNORECASE | re.DOTALL
)


def search_torrentdownloads(title, year=None, limit=5, media_type='movie'):
    """TorrentDownloads — RSS feed returns info_hash directly, very fast."""
    try:
        from urllib.parse import quote as _q3
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        cat = '8' if media_type == 'tv' else '4'  # 4=Movies, 8=TV
        if media_type == 'adult':
            cat = '6'
        url = '%s/rss.xml?new=1&type=search&cid=%s&search=%s' % (
            TDOWNLOADS_BASE, cat, _q3(query))
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        for m in _RE_TD_ITEM.finditer(html_raw):
            if len(results) >= limit:
                break
            ih, name, size_b, seeders = (
                m.group(1).lower(), m.group(2).strip(),
                int(m.group(3)), int(m.group(4))
            )
            if not name or not _meets_quality(name, media_type):
                continue
            size = ''
            if size_b >= 1_073_741_824:
                size = '%.1f GB' % (size_b / 1_073_741_824)
            elif size_b >= 1_048_576:
                size = '%d MB' % (size_b // 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeders,
                'size':      size,
                'source':    'TorrentDL',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentDownloads error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Glodls ───────────────────────────────────────────────────────────────────

_GLODLS_BASE = 'https://glodls.to'
_GLODLS_TV   = 'search_results.php?search={q}&cat=41&incldead=0&inclexternal=0&lang=1&sort=seeders&order=desc'
_GLODLS_MOV  = 'search_results.php?search={q}&cat=1&incldead=0&inclexternal=0&lang=1&sort=size&order=desc'
_RE_GL_NAME  = re.compile(r'<a[^>]+title="([^"]+)"', re.IGNORECASE)
_RE_GL_MAG   = re.compile(r'href="(magnet:\?[^"]+)"', re.IGNORECASE)
_RE_GL_SIZE  = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)


def search_glodls(title, year=None, limit=5, media_type='movie'):
    try:
        if not _req:
            return []
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)
        q = _req.utils.quote(query)
        tmpl = _GLODLS_TV if media_type == 'tv' else _GLODLS_MOV
        url = '%s/%s' % (_GLODLS_BASE, tmpl.format(q=q))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        # Parse t-row table rows
        for row in html.split('class="t-row"')[1:]:
            if len(results) >= limit:
                break
            try:
                mag_m = _RE_GL_MAG.search(row)
                if not mag_m:
                    continue
                magnet = mag_m.group(1).replace('&amp;', '&')
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if not ih_m:
                    continue
                info_hash = ih_m.group(1).lower()
                # Title from <a title="...">
                name_m = _RE_GL_NAME.search(row)
                name = name_m.group(1) if name_m else ''
                if not name or not _meets_quality(name, media_type):
                    continue
                # Size
                sz_m = _RE_GL_SIZE.search(row)
                size = sz_m.group(0) if sz_m else ''
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': info_hash,
                    'magnet':    magnet.split('&tr')[0],
                    'seeds':     0,
                    'size':      size,
                    'source':    'Glodls',
                })
            except Exception:
                continue
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Glodls error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Unified search ────────────────────────────────────────────────────────────

def search_all(title, year=None, media_type='movie', max_per_source=5, imdb_id=None,
               season=None, episode=None):
    """
    Search all torrent sources in parallel. Returns combined list sorted by seeds.
    media_type: 'movie', 'tv', or 'adult'
    imdb_id: optional tt... ID for Torrentio
    season/episode: for TV episodes
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    tpb_cat = 500 if media_type == 'adult' else (201 if media_type == 'movie' else 205)

    tasks = {
        'Knaben':       lambda: search_knaben(title, year, media_type, max_per_source * 2),
        'TPB':          lambda: search_tpb(title, year, tpb_cat, max_per_source, media_type),
        '1337x':        lambda: search_1337x(title, year, max_per_source, media_type),
        'Bitsearch':    lambda: search_bitsearch(title, year, max_per_source, media_type),
        'TGX':          lambda: search_torrentgalaxy(title, year, max_per_source, media_type),
        'YourBT':       lambda: search_yourbittorrent(title, year, max_per_source, media_type),
        'Bitlord':      lambda: search_bitlord(title, year, max_per_source, media_type),
        'Tordl':        lambda: search_tordl(title, year, max_per_source, media_type),
        'MagnetDL':     lambda: search_magnetdl(title, year, max_per_source, media_type),
        'TorrentDL':    lambda: search_torrentdownloads(title, year, max_per_source, media_type),
        'Glodls':       lambda: search_glodls(title, year, max_per_source, media_type),
    }

    # Type-specific sources
    if media_type in ('movie', 'adult'):
        tasks['YTS'] = lambda: search_yts(title, year, max_per_source, media_type)
    if media_type == 'tv':
        tasks['EZTV'] = lambda: search_eztv(title, year, max_per_source)
    if imdb_id:
        tasks['Torrentio'] = lambda: search_torrentio(
            imdb_id, media_type, season, episode, max_per_source * 4)

    all_results = []
    with ThreadPoolExecutor(max_workers=min(len(tasks), 12)) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        try:
            for future in as_completed(futures, timeout=15):
                try:
                    all_results.extend(future.result())
                except Exception as e:
                    xbmc.log('[Starfleet/Torrents] %s search failed: %s' % (
                        futures[future], e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Torrents] search_all timeout: %s' % e, xbmc.LOGWARNING)

    # Deduplicate by info_hash
    seen = set()
    unique = []
    for r in all_results:
        ih = r.get('info_hash', '').lower()
        if ih and ih not in seen:
            seen.add(ih)
            unique.append(r)

    unique.sort(key=lambda x: x.get('seeds', 0), reverse=True)
    return unique
