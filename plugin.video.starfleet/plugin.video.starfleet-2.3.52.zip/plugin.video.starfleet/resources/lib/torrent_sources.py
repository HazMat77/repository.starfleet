# -*- coding: utf-8 -*-
"""
resources/lib/torrent_sources.py

Search multiple torrent sites for a title and return magnet links.
Results are used with debrid services (Real-Debrid, AllDebrid, Premiumize, TorBox)
to get instant cached streams — uncached torrents are skipped.

Sources:
  YTS          — JSON API, movies only, high quality
  1337x        — HTML scraping, mirror rotation + CF bypass
  The Pirate Bay — JSON API, movies + TV + adult
  EZTV         — JSON API, TV shows
  Bitsearch    — DHT index scrape
  TorrentGalaxy — HTML scraping + CF bypass
  YourBitTorrent — HTML scraping
  Bitlord      — HTML scraping
  Knaben       — aggregated JSON API (movies/TV/adult)
  Torrentio    — Stremio IMDB-based API
  Torrentdownload — HTML scraping
  XXXClub        — HTML scraping, adult only
"""

import re
import time
import xbmc
import xbmcaddon
import xbmcvfs

try:
    import requests as _req
except ImportError:
    _req = None

try:
    from resources.lib import cache as _cache
    _PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    _cache.init(_PROFILE + '/cache.db')
    _HAS_CACHE = True
except Exception:
    _HAS_CACHE = False

# ── Quality helpers ───────────────────────────────────────────────────────────

# High-quality markers
_QUALITY_HQ = re.compile(
    r'\b(?:720p?|1080p?|1080i|2160p?|4k|uhd|3d|bd(?:rip|remux)|bluray|blu[-\s]?ray)\b',
    re.IGNORECASE
)
# Any recognisable video quality marker (accepts HDTV/WEB/x265 without resolution)
_QUALITY_ANY = re.compile(
    r'\b(?:720|1080|2160|4k|uhd|3d|bluray|blu.ray|bdrip|bdremux|'
    r'web[-.]?dl|webdl|webrip|web.rip|hdtv|hdrip|dvdrip|dvd|'
    r'x264|x265|hevc|h\.?264|h\.?265|xvid|avc|hevcrip|remux|'
    r'hdcam|scr|screener|dvdscr)\b',
    re.IGNORECASE
)
# Definitively low-quality markers
_QUALITY_LQ = re.compile(
    r'\b(?:480p?|360p?|240p?|camrip|hdcam|scr|screener|dvdscr)\b',
    re.IGNORECASE
)
# Patterns that identify non-video content (games, software, ebooks, music)
_NON_VIDEO = re.compile(
    r'(?:'
    r'\[(?:Nintendo\s*Switch|NSZ|XCI|NSW|PS[345]|XBOX|PC\s*Game|NDS|3DS|GBA)\]'
    r'|Nintendo\s*Switch'
    r'|(?<!\d)v\d+\.\d+[\.\d]*(?:[- ]|$)'  # software version like v2025.11.22
    r'|\bBuild\s+\d{5,}\b'                  # game build numbers like "Build 13275298"
    r'|\bUpdate\s+v\d'                       # "Update v1" game update pattern
    r'|\bNSZ\b|\bXCI\b|\bNSP\b' # Switch formats
    r'|\[P\]'                    # Knaben game/app marker
    r'|\bAndroid\b|\biOS\b|\bAPK\b'
    r'|-(?:TENOKE|RELOADED|CODEX|SKIDROW|PLAZA|FLT|HOODLUM|GOG|DARKSIDERS|CPY)\b'  # game crack groups
    r')',
    re.IGNORECASE
)
# Adult content markers — excluded from movie/tv results
_IS_ADULT = re.compile(r'\b(?:XXX|adult|porn|sex)\b', re.IGNORECASE)


def _meets_quality(text, media_type='movie'):
    """
    Return True if this torrent is acceptable quality.
    Rejects explicit LQ markers (480p, cam, screener) and non-video content
    (games, software) for movie/tv searches.
    """
    if media_type == 'adult':
        return True
    s = text or ''
    if _QUALITY_LQ.search(s):
        return False
    if media_type in ('movie', 'tv'):
        if _NON_VIDEO.search(s):
            return False
        if _IS_ADULT.search(s):
            return False
    return True


def _extract_quality(text):
    text = text or ''
    for pat, label in [
        (r'\b2160p?\b|\b4k\b|\buhd\b',           '4K'),
        (r'\b1080p?\b|\b1080i\b',                 '1080p'),
        (r'\b720p?\b',                             '720p'),
        (r'\b3d\b',                                '3D'),
        (r'\bbluray\b|\bbl(?:u[-\s]?ray)\b',       'Blu-ray'),
        (r'\bweb[-.]?dl\b|\bwebdl\b',             'WEB-DL'),
        (r'\bwebrip\b',                            'WEBRip'),
        (r'\bhdtv\b',                              'HDTV'),
    ]:
        if re.search(pat, text, re.IGNORECASE):
            return label
    return ''


# ── HTTP session & Cloudflare bypass ─────────────────────────────────────────

_BROWSER_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'DNT': '1',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
}

# Full Chrome headers for CF-protected sites (includes sec-ch-ua and sec-fetch-* fields)
_CF_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cache-Control': 'max-age=0',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',
    'Connection': 'keep-alive',
}

_session = None
_cf_session = None  # cloudscraper session (created lazily)


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_BROWSER_HEADERS)
        # No retries — scrapers each have explicit timeouts; retrying a timed-out
        # connection wastes 3× the time (e.g. EZTV hitting 24s instead of 8s).
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=0, redirect=False)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get_cf_session():
    """Return a cfscrape session (The Crew's module) if available, else None."""
    global _cf_session
    if _cf_session is not None:
        return _cf_session
    try:
        import sys as _sys
        _sys.path.insert(0, r'C:\Users\danlo\AppData\Roaming\Kodi\addons\script.module.thecrew\lib\resources\lib\modules')
        import cfscrape
        _cf_session = cfscrape.create_scraper()
        xbmc.log('[Starfleet/Torrents] cfscrape loaded', xbmc.LOGINFO)
        return _cf_session
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] cfscrape init failed: %s' % e, xbmc.LOGWARNING)
    return None


def _get(url, timeout=10, cf=False):
    """HTTP GET. If cf=True, try cloudscraper first to bypass Cloudflare."""
    if cf:
        cs = _get_cf_session()
        if cs:
            try:
                r = cs.get(url, timeout=timeout)
                r.raise_for_status()
                return r.text
            except Exception as e:
                xbmc.log('[Starfleet/Torrents] CF session failed (%s): %s' % (url[:60], e),
                         xbmc.LOGWARNING)
    s = _sess()
    if s:
        r = s.get(url, timeout=timeout)
        r.raise_for_status()
        return r.text
    # Fallback: urllib (always available in Kodi's Python)
    try:
        import urllib.request as _ur
        req = _ur.Request(url, headers=_BROWSER_HEADERS)
        with _ur.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] urllib fallback failed (%s): %s' % (url[:60], e),
                 xbmc.LOGWARNING)
        return ''


def _get_json(url, timeout=10):
    s = _sess()
    if not s:
        return None
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _make_magnet(info_hash, name=''):
    trackers = [
        'udp://tracker.opentrackr.org:1337/announce',
        'udp://open.tracker.cl:1337/announce',
        'udp://tracker.openbittorrent.com:6969/announce',
        'udp://tracker.torrent.eu.org:451/announce',
    ]
    dn = ('&dn=' + _req.utils.quote(name)) if name and _req else ''
    tr = ''.join('&tr=' + t for t in trackers)
    return 'magnet:?xt=urn:btih:%s%s%s' % (info_hash.lower(), dn, tr)


# ── YTS ──────────────────────────────────────────────────────────────────────

_YTS_DOMAINS = [
    'https://yts.lt',
    'https://yts.mx',
    'https://yts.proxyninja.org',
]


def search_yts(title, year=None, limit=5, media_type='movie'):
    if media_type not in ('movie', 'adult'):
        return []
    try:
        # Don't append year — YTS API is strict with full-string matching,
        # title-only gets more results (year can be checked post-fetch if needed)
        params = {'query_term': title, 'limit': limit, 'sort_by': 'seeds'}
        qs = '&'.join('%s=%s' % (k, v) for k, v in params.items())
        data = None
        for domain in _YTS_DOMAINS:
            data = _get_json(domain + '/api/v2/list_movies.json?' + qs)
            if data and data.get('status') == 'ok':
                break
            data = None
        if not data:
            return []
        movies = data.get('data', {}).get('movies') or []
        results = []
        for movie in movies:
            for tor in movie.get('torrents', []):
                ih = tor.get('hash', '')
                if not ih:
                    continue
                quality = tor.get('quality', '')
                if not _meets_quality(quality, media_type):
                    continue
                results.append({
                    'title':     movie.get('title_english') or movie.get('title', ''),
                    'year':      movie.get('year', ''),
                    'quality':   _extract_quality(quality) or quality,
                    'info_hash': ih,
                    'magnet':    _make_magnet(ih, movie.get('title', '')),
                    'seeds':     tor.get('seeds', 0),
                    'size':      tor.get('size', ''),
                    'source':    'YTS',
                })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YTS error: %s' % e, xbmc.LOGWARNING)
        return []


# ── The Pirate Bay ────────────────────────────────────────────────────────────

TPB_BASE = 'https://apibay.org'


def search_tpb(title, year=None, category=200, limit=10, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        data = _get_json(TPB_BASE + '/q.php?q=%s&cat=%d' % (query, category), timeout=8)
        if not data or not isinstance(data, list):
            return []
        results = []
        for item in data[:limit]:
            ih = item.get('info_hash', '')
            if not ih or ih == '0000000000000000000000000000000000000000':
                continue
            name = item.get('name', '')
            if not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(item.get('seeders', 0)),
                'size':      item.get('size', ''),
                'source':    'TPB',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TPB error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 1337x (mirror rotation + Cloudflare bypass) ───────────────────────────────

_LEET_MIRRORS = [
    '1337x.se', '1337x.tw', '1337x.pro', '1337x.to',
    '1337x.st', '1337x.ws', '1337x.gd', 'www.1377x.is',
]
_leet_working = {}  # {'url': ..., 'ts': ...}

_RE_LEET_MAGNET = re.compile(r'href="(magnet:[^"]+)"', re.IGNORECASE)


def _get_leet_base():
    """Return a working 1337x mirror, cached for 1 hour."""
    cached = _leet_working.get('url')
    ts = _leet_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached

    for mirror in _LEET_MIRRORS:
        try:
            url = 'https://%s' % mirror
            html = _get(url + '/home/', timeout=7, cf=True)
            if html and '1337x' in html.lower():
                _leet_working['url'] = url
                _leet_working['ts'] = time.time()
                xbmc.log('[Starfleet/Torrents] 1337x using mirror: %s' % url, xbmc.LOGINFO)
                return url
        except Exception:
            continue

    fallback = 'https://' + _LEET_MIRRORS[0]
    xbmc.log('[Starfleet/Torrents] 1337x all mirrors failed, using: %s' % fallback, xbmc.LOGWARNING)
    return fallback


def _leet_get_magnet(path, base):
    try:
        html = _get(base + path, timeout=8, cf=True)
        m = _RE_LEET_MAGNET.search(html)
        if m:
            return m.group(1).split('&tr=')[0]
    except Exception:
        pass
    return ''


_RE_LEET_ROW = re.compile(
    r'<td[^>]+class="[^"]*coll-1[^"]*"[^>]*>.*?'
    r'href="(/torrent/\d+/[^"]+)"[^>]*>([^<]+)</a>.*?'
    r'<td[^>]+class="[^"]*coll-2[^"]*"[^>]*>(\d+)<',
    re.IGNORECASE | re.DOTALL
)


def search_1337x(title, year=None, limit=5, media_type='movie'):
    try:
        base = _get_leet_base()
        cat = 'TV' if media_type == 'tv' else 'Movies'
        query = title.replace(' ', '+')
        if year and media_type != 'adult':
            query += '+' + str(year)

        if media_type == 'adult':
            url = '%s/search/%s/1/' % (base, query)
        else:
            url = '%s/sort-category-search/%s/%s/seeders/desc/1/' % (base, query, cat)

        html = _get(url, timeout=10, cf=True)
        if not html:
            return []

        candidates = []
        for m in _RE_LEET_ROW.finditer(html):
            if len(candidates) >= limit:
                break
            path, name, seeds = m.group(1), m.group(2).strip(), m.group(3)
            if not _meets_quality(name, media_type):
                continue
            candidates.append((path, name, int(seeds)))

        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor, as_completed as _ac2
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 5)) as pool:
            fmap = {pool.submit(_leet_get_magnet, path, base): (name, seeds)
                    for path, name, seeds in candidates}
            for fut in _ac2(fmap, timeout=12):
                name, seeds = fmap[fut]
                try:
                    magnet = fut.result()
                except Exception:
                    magnet = ''
                if not magnet:
                    continue
                ih_m = re.search(r'urn:btih:([a-fA-F0-9]{40})', magnet)
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': ih_m.group(1).lower() if ih_m else '',
                    'magnet':    magnet,
                    'seeds':     seeds,
                    'size':      '',
                    'source':    '1337x',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] 1337x error: %s' % e, xbmc.LOGWARNING)
        return []


# ── EZTV (TV shows) ───────────────────────────────────────────────────────────

EZTV_BASE = 'https://eztvx.to'


def search_eztv(title, year=None, limit=5):
    """
    EZTV HTML scrape via cfscrape (API /api/get-torrents ignores keywords — broken).
    Scrapes /search/{show-name} which respects the query.
    """
    try:
        slug = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')
        url = '%s/search/%s' % (EZTV_BASE, slug)
        cs = _get_cf_session()
        html = (cs.get(url, timeout=10).text if cs else
                _get(url, timeout=10, cf=True))
        if not html:
            return []
        # Rows: <tr class="forum_header_border">
        magnets = re.findall(r'(magnet:\?xt=urn:btih:[a-fA-F0-9]{40}[^"\'<\s]*)', html)
        names   = re.findall(r'class="epinfo"[^>]*>([^<]+)</a>', html)
        seeds_all = re.findall(r'class="[^"]*seeds[^"]*"[^>]*>(\d+)<', html, re.IGNORECASE)
        results = []
        for i, mag in enumerate(magnets):
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', mag, re.IGNORECASE)
            if not ih_m:
                continue
            ih   = ih_m.group(1).lower()
            name = names[i] if i < len(names) else ''
            if not name:
                dn = re.search(r'[&?]dn=([^&"\'<\s]+)', mag)
                name = _req.utils.unquote(dn.group(1)).replace('+', ' ') if dn and _req else ih
            seeds = int(seeds_all[i]) if i < len(seeds_all) else 0
            if not _meets_quality(name, 'tv'):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    mag,
                'seeds':     seeds,
                'size':      '',
                'source':    'EZTV',
            })
            if len(results) >= limit:
                break
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] EZTV error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitsearch ─────────────────────────────────────────────────────────────────

BITSEARCH_BASE = 'https://bitsearch.to'
_RE_BS_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_bitsearch(title, year=None, limit=5, media_type='movie'):
    """
    Bitsearch scraper. Anchors on magnet: links rather than CSS card classes
    so it survives HTML/CSS redesigns on bitsearch.to.
    """
    try:
        import html as _html
        query = title
        # No year in query — title-only gets more results
        if _req:
            query = _req.utils.quote(query)
        url = '%s/search?q=%s&sort=seeders' % (BITSEARCH_BASE, query)
        cs = _get_cf_session()
        html_raw = (cs.get(url, timeout=10).text if cs else _get(url, timeout=10))
        if not html_raw:
            return []
        text = _html.unescape(html_raw)

        # Split on magnet: links — one per result card, CSS-class-independent
        parts = re.split(r'(magnet:\?[^"\'<\s]+)', text)
        # parts = [pre, magnet1, after1, magnet2, after2, ...]
        results = []
        i = 1
        while i < len(parts) - 1 and len(results) < limit:
            raw_magnet = parts[i].replace('&amp;', '&')
            before = parts[i - 1][-800:]
            after  = parts[i + 1][:400]
            context = before + after
            i += 2

            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', raw_magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()

            # Name: prefer &dn= from magnet (already URL-decoded title)
            name = ''
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', raw_magnet)
            if dn_m and _req:
                name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip()
            if not name:
                # Fall back: nearest heading/link text before the magnet
                t_m = re.search(
                    r'<(?:h\d|a)\b[^>]*>\s*(?:<[^>]+>)?\s*([^<]{5,80}?)\s*(?:</[^>]+>)?\s*</(?:h\d|a)>',
                    before, re.IGNORECASE | re.DOTALL
                )
                if t_m:
                    name = re.sub(r'<[^>]+>', '', t_m.group(1)).strip()
                    name = re.sub(r'\s+', ' ', name)
            if not name or not _meets_quality(name, media_type):
                continue

            seeds = 0
            s_m = re.search(r'(\d+)\s*[<\s]*(?:seeder|seed)\b', context, re.IGNORECASE)
            if s_m:
                seeds = int(s_m.group(1))

            size = ''
            z_m = _RE_BS_SIZE.search(context)
            if z_m:
                size = z_m.group(0)

            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    raw_magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'Bitsearch',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitsearch error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentGalaxy (CF bypass) ────────────────────────────────────────────────

_TGX_MIRRORS = [
    'torrentgalaxy-official.is', 'torrentgalaxy.one', 'torrentgalaxy.info',
    'torrentgalaxy.hair', 'torrentgalaxy.mx', 'torrentgalaxy.to', 'tgx.rs',
]
_tgx_working = {}

_RE_TGX_MAGNET = re.compile(r'a\s+href="(magnet:[^"]+)"', re.IGNORECASE)
_RE_TGX_SIZE   = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)
_TGX_SKIP_LANG = re.compile(r'\b(FRENCH|TRUEFRENCH|ITALIAN|Ita|SPANISH|DUBBED|LAT|Dublado)\b',
                             re.IGNORECASE)


def _get_tgx_base():
    cached = _tgx_working.get('url')
    ts = _tgx_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _TGX_MIRRORS:
        try:
            url = 'https://%s' % mirror
            html = _get(url + '/torrents.php', timeout=7, cf=True)
            if html and 'torrent' in html.lower():
                _tgx_working['url'] = url
                _tgx_working['ts'] = time.time()
                xbmc.log('[Starfleet/Torrents] TGX using mirror: %s' % url, xbmc.LOGINFO)
                return url
        except Exception:
            continue
    return 'https://' + _TGX_MIRRORS[0]


def search_torrentgalaxy(title, year=None, limit=5, media_type='movie'):
    try:
        base = _get_tgx_base()
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/torrents.php?search=%s' % (base, query)
        html_raw = _get(url, timeout=10, cf=True)
        if not html_raw:
            return []
        results = []
        for row in re.finditer(r'<div[^>]+class="[^"]*tgxtable[^"]*"[^>]*>(.*?)</div>',
                                html_raw, re.IGNORECASE | re.DOTALL):
            if len(results) >= limit:
                break
            row_text = row.group(1)
            mag_m = _RE_TGX_MAGNET.search(row_text)
            if not mag_m:
                continue
            magnet = mag_m.group(1)
            if _TGX_SKIP_LANG.search(magnet):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            dn_m = re.search(r'[&?]dn=([^&]+)', magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else info_hash
            if not _meets_quality(name, media_type):
                continue
            z_m = _RE_TGX_SIZE.search(row_text)
            size = z_m.group(0) if z_m else ''
            seeds_m = re.search(r'<span[^>]+>(\d+)</span>\s*seeders', row_text, re.IGNORECASE)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'TGX',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentGalaxy error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Knaben meta-search (movies / TV / adult) ──────────────────────────────────

KNABEN_API = 'https://api.knaben.org/v1'
# Knaben category filters are unreliable (returns empty when set) — skip them
# and rely on the title/word filter in search_all to remove wrong-media results.

_KNABEN_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept':       'application/json',
    'Content-Type': 'application/json',
}


def search_knaben(title, year=None, media_type='movie', limit=10):
    try:
        import json as _json
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)

        body = {'query': query, 'order_by': 'seeders', 'take': max(limit * 3, 30)}
        # No category filter — Knaben category IDs are broken (return empty)
        # Use a fresh Session per call: the shared _sess() pool causes empty responses
        # for this large JSON endpoint (211KB response body).
        if not _req:
            return []
        with _req.Session() as _ks:
            r = _ks.post(KNABEN_API, json=body, headers=_KNABEN_HEADERS, timeout=12)
        if r.status_code >= 400:
            return []
        if not r.text or not r.text.strip():
            xbmc.log('[Starfleet/Torrents] Knaben: empty response', xbmc.LOGWARNING)
            return []
        data = r.json()
        # API returns 'hits' (old) or 'result' (new) depending on version
        hits = data.get('hits') or data.get('result') or data.get('results') or []
        results = []
        for entry in hits:
            if len(results) >= limit:
                break
            name = entry.get('title', '')
            if not name or not _meets_quality(name, media_type):
                continue
            # Knaben marks games/software with [DL] prefix — skip for movie/tv searches
            if media_type in ('movie', 'tv') and name.startswith('[DL]'):
                continue
            ih = (entry.get('hash') or '').lower()
            if not ih or len(ih) != 40:
                continue
            magnet = entry.get('magnetUrl') or _make_magnet(ih, name)
            seeds  = int(entry.get('seeders') or 0)
            b = entry.get('bytes') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'Knaben',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Knaben error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentio (IMDB-based Stremio API) ───────────────────────────────────────

TORRENTIO_BASE = 'https://torrentio.strem.fun'
_RE_TIO_INFO = re.compile(r'👤.*')


def search_torrentio(imdb_id, media_type='movie', season=None, episode=None, limit=20):
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/stream/series/%s:%s:%s.json' % (TORRENTIO_BASE, imdb_id, season, episode)
        else:
            url = '%s/stream/movie/%s.json' % (TORRENTIO_BASE, imdb_id)
        data = _get_json(url, timeout=15)
        if not data or not isinstance(data.get('streams'), list):
            return []
        results = []
        for stream in data['streams'][:limit]:
            ih = stream.get('infoHash')
            if not ih:
                continue
            title_parts = (stream.get('title') or '').split('\n')
            name = title_parts[0].strip()
            if not name:
                continue
            info_lines = [x for x in title_parts if _RE_TIO_INFO.match(x)]
            seeds = 0
            size = ''
            if info_lines:
                s_m = re.search(r'(\d+)', info_lines[0])
                if s_m:
                    seeds = int(s_m.group(1))
                z_m = re.search(r'(\d+(?:\.\d+)?)\s*(GB|GiB|MB|MiB)', info_lines[0], re.IGNORECASE)
                if z_m:
                    size = z_m.group(0)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Torrentio',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torrentio error: %s' % e, xbmc.LOGWARNING)
        return []


# ── YourBitTorrent ────────────────────────────────────────────────────────────

YBT_BASE = 'https://yourbittorrent2.com'
_RE_YBT_LINK = re.compile(r'<a href="(/torrent/[^"]+)"', re.IGNORECASE)
_RE_YBT_HASH = re.compile(r'<kbd>([a-fA-F0-9]{40})<', re.IGNORECASE)
_RE_YBT_NAME = re.compile(r'<h3 class="card-title">([^<]+)<', re.IGNORECASE)
_RE_YBT_SIZE = re.compile(r'File size:</div><div class="col">([^<]+)<', re.IGNORECASE)
_RE_YBT_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_yourbittorrent(title, year=None, limit=5, media_type='movie'):
    try:
        from concurrent.futures import ThreadPoolExecutor
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        from urllib.parse import quote_plus as _qp
        query_enc = _qp(query).replace('+', '-')
        html_raw = _get('%s?q=%s' % (YBT_BASE, query_enc), timeout=8)
        if not html_raw:
            return []
        links = _RE_YBT_LINK.findall(html_raw)[:limit]

        def _fetch(link):
            try:
                detail = _get(YBT_BASE + link, timeout=8)
                ih_m = _RE_YBT_HASH.search(detail)
                nm_m = _RE_YBT_NAME.search(detail)
                if not ih_m or not nm_m:
                    return None
                ih = ih_m.group(1).lower()
                name = nm_m.group(1).strip()
                if not _meets_quality(name, media_type):
                    return None
                if _RE_YBT_LANG.search(name):
                    return None
                sz_m = _RE_YBT_SIZE.search(detail)
                size = sz_m.group(1).strip() if sz_m else ''
                return {
                    'title': name, 'year': '', 'quality': _extract_quality(name),
                    'info_hash': ih, 'magnet': _make_magnet(ih, name),
                    'seeds': 0, 'size': size, 'source': 'YourBT',
                }
            except Exception:
                return None

        if not links:
            return []
        results = []
        with ThreadPoolExecutor(max_workers=max(min(len(links), limit), 1)) as pool:
            for r in pool.map(_fetch, links, timeout=10):
                if r and len(results) < limit:
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YourBitTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentdownload.info (Tordl) ──────────────────────────────────────────────

TORDL_BASE = 'https://www.torrentdownload.info'
_RE_TORDL_LINK = re.compile(r'href="/([a-fA-F0-9]{40})/([^"]+)"', re.IGNORECASE)
_RE_TORDL_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_tordl(title, year=None, limit=5, media_type='movie'):
    try:
        from urllib.parse import quote_plus as _qp
        query = title.lower()
        if year and media_type != 'adult':
            query = '%s %s' % (query, year)
        url = '%s/search?q=%s' % (TORDL_BASE, _qp(query))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for m in _RE_TORDL_LINK.finditer(html):
            if len(results) >= limit:
                break
            ih = m.group(1).lower()
            name = m.group(2).replace('+', ' ').replace('-', ' ')
            name = re.sub(r'[_%]', ' ', name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            # Size is approximate from listing
            magnet = _make_magnet(ih, name)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     0,
                'size':      '',
                'source':    'Tordl',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Tordl error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitlord ───────────────────────────────────────────────────────────────────

BITLORD_BASE = 'http://www.bitlordsearch.com'
_RE_BL_MAG  = re.compile(
    r'class="btn btn-default magnet-button[^"]*"[^>]+href="([^"]+)"', re.IGNORECASE
)
_RE_BL_SIZE = re.compile(r'<td class="size">(\d+)</td>', re.IGNORECASE)
_RE_BL_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_bitlord(title, year=None, limit=5, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        html_raw = _get('%s/search?q=%s' % (BITLORD_BASE, query), timeout=10)
        if not html_raw:
            return []
        magnets = _RE_BL_MAG.findall(html_raw)
        sizes   = _RE_BL_SIZE.findall(html_raw)
        results = []
        for i, mag in enumerate(magnets):
            if len(results) >= limit:
                break
            mag = mag.replace('&amp;', '&').split('&tr=')[0]
            if 'magnet' not in mag:
                continue
            dn_m = re.search(r'&dn=([^&]+)', mag)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else ''
            if not name or not _meets_quality(name, media_type):
                continue
            if _RE_BL_LANG.search(name):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', mag, re.IGNORECASE)
            info_hash = ih_m.group(1).lower() if ih_m else ''
            size = ''
            if i < len(sizes):
                try:
                    b = int(sizes[i])
                    if b >= 1_073_741_824:
                        size = '%.1f GB' % (b / 1_073_741_824)
                    elif b >= 1_048_576:
                        size = '%.0f MB' % (b / 1_048_576)
                except Exception:
                    pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': mag,
                'seeds': 0, 'size': size, 'source': 'Bitlord',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitlord error: %s' % e, xbmc.LOGWARNING)
        return []


# ── MagnetDL ──────────────────────────────────────────────────────────────────

MAGNETDL_BASE = 'https://www.magnetdl.hair'
_RE_MDL_ROW  = re.compile(
    r'href="(/([a-fA-F0-9]{40})/([^"]+))"', re.IGNORECASE
)


def search_magnetdl(title, year=None, limit=5, media_type='movie'):
    """MagnetDL — magnets are embedded in search-result URLs, no per-page fetch."""
    try:
        from urllib.parse import quote as _q2
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        slug = re.sub(r'[^\w\s-]', '', query.lower()).strip()
        slug = re.sub(r'[\s_]+', '-', slug)
        first = slug[0] if slug else 'm'
        url = '%s/%s/%s/' % (MAGNETDL_BASE, first, slug)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        seen_hashes = set()
        for m in _RE_MDL_ROW.finditer(html_raw):
            if len(results) >= limit:
                break
            ih = m.group(2).lower()
            if ih in seen_hashes:
                continue
            raw_name = m.group(3)
            name = re.sub(r'[_+]+', ' ', raw_name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            seen_hashes.add(ih)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      '',
                'source':    'MagnetDL',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] MagnetDL error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentDownloads (RSS) ────────────────────────────────────────────────────

TDOWNLOADS_BASE = 'https://www.torrentdownloads.pro'
_RE_TD_ITEM = re.compile(
    r'<info_hash>([a-fA-F0-9]{40})</info_hash>.*?'
    r'<title>(.+?)</title>.*?'
    r'<size>(\d+)</size>.*?'
    r'<seeders>(\d+)</seeders>',
    re.IGNORECASE | re.DOTALL
)


def search_torrentdownloads(title, year=None, limit=5, media_type='movie'):
    """TorrentDownloads — RSS feed returns info_hash directly, very fast."""
    try:
        from urllib.parse import quote as _q3
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        cat = '8' if media_type == 'tv' else '4'  # 4=Movies, 8=TV
        if media_type == 'adult':
            cat = '6'
        url = '%s/rss.xml?new=1&type=search&cid=%s&search=%s' % (
            TDOWNLOADS_BASE, cat, _q3(query))
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        for m in _RE_TD_ITEM.finditer(html_raw):
            if len(results) >= limit:
                break
            ih, name, size_b, seeders = (
                m.group(1).lower(), m.group(2).strip(),
                int(m.group(3)), int(m.group(4))
            )
            if not name or not _meets_quality(name, media_type):
                continue
            size = ''
            if size_b >= 1_073_741_824:
                size = '%.1f GB' % (size_b / 1_073_741_824)
            elif size_b >= 1_048_576:
                size = '%d MB' % (size_b // 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeders,
                'size':      size,
                'source':    'TorrentDL',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentDownloads error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Glodls ───────────────────────────────────────────────────────────────────

_GLODLS_BASE = 'https://glodls.to'
_GLODLS_TV   = 'search_results.php?search={q}&cat=41&incldead=0&inclexternal=0&lang=1&sort=seeders&order=desc'
_GLODLS_MOV  = 'search_results.php?search={q}&cat=1&incldead=0&inclexternal=0&lang=1&sort=size&order=desc'
_RE_GL_NAME  = re.compile(r'<a[^>]+title="([^"]+)"', re.IGNORECASE)
_RE_GL_MAG   = re.compile(r'href="(magnet:\?[^"]+)"', re.IGNORECASE)
_RE_GL_SIZE  = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)


def search_glodls(title, year=None, limit=5, media_type='movie'):
    try:
        if not _req:
            return []
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)
        q = _req.utils.quote(query)
        tmpl = _GLODLS_TV if media_type == 'tv' else _GLODLS_MOV
        url = '%s/%s' % (_GLODLS_BASE, tmpl.format(q=q))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        # Parse t-row table rows
        for row in html.split('class="t-row"')[1:]:
            if len(results) >= limit:
                break
            try:
                mag_m = _RE_GL_MAG.search(row)
                if not mag_m:
                    continue
                magnet = mag_m.group(1).replace('&amp;', '&')
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if not ih_m:
                    continue
                info_hash = ih_m.group(1).lower()
                # Title from <a title="...">
                name_m = _RE_GL_NAME.search(row)
                name = name_m.group(1) if name_m else ''
                if not name or not _meets_quality(name, media_type):
                    continue
                # Size
                sz_m = _RE_GL_SIZE.search(row)
                size = sz_m.group(0) if sz_m else ''
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': info_hash,
                    'magnet':    magnet.split('&tr')[0],
                    'seeds':     0,
                    'size':      size,
                    'source':    'Glodls',
                })
            except Exception:
                continue
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Glodls error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Ext.to (CF-protected) ────────────────────────────────────────────────────

EXTTO_BASE = 'https://ext.to'
_RE_EXTTO_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_extto(title, year=None, limit=5, media_type='movie'):
    """ext.to — large torrent index. CF-protected; uses cloudscraper if available."""
    try:
        if _req:
            q = _req.utils.quote(title)
        else:
            return []
        url = '%s/search/?q=%s&type=torrent&c=video' % (EXTTO_BASE, q)
        html_raw = _get(url, timeout=12, cf=True)
        if not html_raw:
            return []
        import html as _html
        text = _html.unescape(html_raw)
        parts = re.split(r'(magnet:\?[^"\'<\s]+)', text)
        results = []
        i = 1
        while i < len(parts) - 1 and len(results) < limit:
            raw_magnet = parts[i].replace('&amp;', '&')
            before = parts[i - 1][-800:]
            i += 2
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', raw_magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', raw_magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip() if dn_m else ''
            if not name:
                t_m = re.search(r'<a[^>]+class="[^"]*title[^"]*"[^>]*>([^<]{5,80})<', before, re.IGNORECASE)
                if t_m:
                    name = t_m.group(1).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            sz_m = _RE_EXTTO_SIZE.search(before[-400:])
            size = sz_m.group(0) if sz_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': raw_magnet,
                'seeds': 0, 'size': size, 'source': 'ext.to',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] ext.to error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentFunk (CF-protected) ────────────────────────────────────────────────

_TORRENTFUNK_MIRRORS = ['www.torrentfunk.com', 'torrentfunk.net']
_RE_TF_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_torrentfunk(title, year=None, limit=5, media_type='movie'):
    """TorrentFunk — CF-protected; uses cloudscraper if available."""
    try:
        if not _req:
            return []
        q = _req.utils.quote(title)
        for mirror in _TORRENTFUNK_MIRRORS:
            try:
                url = 'https://%s/search.php?q=%s&c=0' % (mirror, q)
                html_raw = _get(url, timeout=10, cf=True)
                if html_raw and 'torrent' in html_raw.lower():
                    break
                html_raw = ''
            except Exception:
                html_raw = ''
        if not html_raw:
            return []
        import html as _html
        text = _html.unescape(html_raw)
        parts = re.split(r'(magnet:\?[^"\'<\s]+)', text)
        results = []
        i = 1
        while i < len(parts) - 1 and len(results) < limit:
            raw_magnet = parts[i].replace('&amp;', '&')
            before = parts[i - 1][-800:]
            i += 2
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', raw_magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', raw_magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip() if dn_m else ''
            if not name or not _meets_quality(name, media_type):
                continue
            sz_m = _RE_TF_SIZE.search(before[-400:])
            size = sz_m.group(0) if sz_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': raw_magnet,
                'seeds': 0, 'size': size, 'source': 'TorrentFunk',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentFunk error: %s' % e, xbmc.LOGWARNING)
        return []


# ── BitTorrented ──────────────────────────────────────────────────────────────

BITTORRENTED_BASE = 'https://bittorrented.com'
_RE_BT_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_bittorrented(title, year=None, limit=5, media_type='movie'):
    """BitTorrented — HTML scraper, may be CF-protected."""
    try:
        if not _req:
            return []
        q = _req.utils.quote(title)
        url = '%s/search/?q=%s&category=0' % (BITTORRENTED_BASE, q)
        html_raw = _get(url, timeout=10, cf=True)
        if not html_raw:
            return []
        import html as _html
        text = _html.unescape(html_raw)
        parts = re.split(r'(magnet:\?[^"\'<\s]+)', text)
        results = []
        i = 1
        while i < len(parts) - 1 and len(results) < limit:
            raw_magnet = parts[i].replace('&amp;', '&')
            before = parts[i - 1][-800:]
            i += 2
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', raw_magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', raw_magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip() if dn_m else ''
            if not name:
                t_m = re.search(r'<a[^>]+class="[^"]*name[^"]*"[^>]*>([^<]{5,80})<', before, re.IGNORECASE)
                if t_m:
                    name = t_m.group(1).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            sz_m = _RE_BT_SIZE.search(before[-400:])
            size = sz_m.group(0) if sz_m else ''
            seeds_m = re.search(r'(\d+)\s*seeder', before[-400:], re.IGNORECASE)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': raw_magnet,
                'seeds': seeds, 'size': size, 'source': 'BitTorrented',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] BitTorrented error: %s' % e, xbmc.LOGWARNING)
        return []


XXXCLUB_BASE = 'https://xxxclub.to'


_SPLIT_SCENE_RE = re.compile(r'\bsplit[\s._-]*scenes?\b', re.IGNORECASE)
_XXXCLUB_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
}


_XXXCLUB_BROWSE_TTL = 21600  # 6 hours


def browse_xxxclub(cursor='', limit=51):
    """
    Browse latest adult torrents from xxxclub.to via direct HTML scrape.
    cursor: '' or '1' → first page; a long digit string → actual xxxclub cursor
            for subsequent pages (extracted from the site's Next link).
    Returns (results_list, next_site_cursor) where next_site_cursor is the raw
    cursor string from the site's Next link (empty string if no next page).
    """
    import urllib.request as _ureq
    import gzip as _gz

    cat = 3  # Movies/DVD/WEB category

    # Decide whether cursor is a real site cursor (long number) or page 1
    is_page1 = (not cursor) or (cursor.isdigit() and int(cursor) <= 1)
    site_cursor = '' if is_page1 else cursor  # the actual xxxclub cursor for page 2+

    ck = 'xxxclub_browse_1' if is_page1 else ('xxxclub_browse_c_%s' % site_cursor[:20])
    if _HAS_CACHE:
        cached = _cache.get(ck)
        if cached is not None:
            results, next_site_cursor = cached
            xbmc.log('[Starfleet/XXXClub] cache hit cursor=%s (%d items)' % (site_cursor or '1', len(results)), xbmc.LOGINFO)
            return results, next_site_cursor

    def _fetch_html(url):
        req = _ureq.Request(url)
        for k, v in _XXXCLUB_HEADERS.items():
            req.add_header(k, v)
        with _ureq.urlopen(req, timeout=12) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip':
                raw = _gz.decompress(raw)
        return raw.decode('utf-8', errors='replace')

    try:
        if site_cursor:
            url = '%s/torrents/browse/%d/%s' % (XXXCLUB_BASE, cat, site_cursor)
        else:
            url = '%s/torrents/browse/%d/' % (XXXCLUB_BASE, cat)

        html = _fetch_html(url)
        rows = re.findall(
            r'id="#i([a-fA-F0-9]{40})"[^>]*onpointerleave="hideImage\(\)">(.*?)</a>'
            r'.*?src=.(https://imgxclub\.com/[^\'\"]+).'
            r'.*?class="siz[^"]*">([^<]*)</span>'
            r'.*?class="see[^"]*">([^<]*)</span>',
            html, re.DOTALL
        )
        xbmc.log('[Starfleet/XXXClub] direct cursor=%s rows=%d' % (site_cursor or '1', len(rows)), xbmc.LOGWARNING)
        if len(rows) < 3:
            raise ValueError('too few rows')

        results = []
        for ih, title, thumb, size, seeds in rows:
            title = title.strip()
            if not title or _SPLIT_SCENE_RE.search(title):
                continue
            results.append({
                'title': title,
                'info_hash': ih.lower(),
                'magnet': _make_magnet(ih, title),
                'thumb': thumb.strip(),
                'size': size.strip(),
                'seeds': seeds.strip(),
            })
            if len(results) >= limit:
                break

        # Extract the Next page cursor from the site HTML
        next_m = re.search(r'href=["\']?/torrents/browse/%d/(\d{8,})["\']?' % cat, html, re.IGNORECASE)
        next_site_cursor = next_m.group(1) if next_m else ''

        if _HAS_CACHE:
            _cache.set(ck, (results, next_site_cursor), _XXXCLUB_BROWSE_TTL)
        return results, next_site_cursor
    except Exception as e:
        xbmc.log('[Starfleet/XXXClub] direct scrape failed (%s), falling back to Knaben' % e, xbmc.LOGWARNING)
    try:
        offset = (page - 1) * limit
        body = {'query': 'xxx', 'order_by': 'date', 'take': limit, 'skip': offset}
        if not _req:
            return [], ''
        r = _sess().post(KNABEN_API, json=body, headers=_KNABEN_HEADERS, timeout=12)
        if r.status_code >= 400 or not r.text.strip():
            return [], ''
        data = r.json()
        hits = data.get('hits') or data.get('result') or data.get('results') or []
        xbmc.log('[Starfleet/XXXClub] Knaben fallback returned %d hits' % len(hits), xbmc.LOGWARNING)
        results = []
        for entry in hits:
            name = entry.get('title', '').strip()
            if not name or _SPLIT_SCENE_RE.search(name):
                continue
            ih = (entry.get('hash') or '').lower()
            if not ih:
                continue
            magnet = entry.get('magnetUrl') or _make_magnet(ih, name)
            b = entry.get('bytes') or 0
            size = '%.1f GB' % (b / 1_073_741_824) if b >= 1_073_741_824 else '%.0f MB' % (b / 1_048_576) if b >= 1_048_576 else ''
            results.append({'title': name, 'info_hash': ih, 'magnet': magnet, 'thumb': '', 'size': size})
            if len(results) >= limit:
                break
        next_cursor = str(page + 1) if len(hits) >= limit else ''
        if _HAS_CACHE:
            _cache.set(ck, (results, next_cursor), _XXXCLUB_BROWSE_TTL)
        return results, next_cursor
    except Exception as e2:
        xbmc.log('[Starfleet/XXXClub] Knaben fallback error: %s' % e2, xbmc.LOGWARNING)
        return [], ''


def search_xxxclub(title, year=None, limit=10, media_type='movie'):
    """Adult torrent search via Knaben (replaces direct xxxclub.to scrape — CF blocked)."""
    if media_type != 'adult':
        return []
    try:
        if not _req:
            return []
        body = {'query': title, 'order_by': 'seeders', 'take': limit}
        r = _sess().post(KNABEN_API, json=body, headers=_KNABEN_HEADERS, timeout=10)
        if r.status_code >= 400 or not r.text.strip():
            return []
        hits = (r.json().get('hits') or r.json().get('result') or [])
        results = []
        for entry in hits:
            name = entry.get('title', '').strip()
            if not name or _SPLIT_SCENE_RE.search(name):
                continue
            ih = (entry.get('hash') or '').lower()
            if not ih:
                continue
            magnet = entry.get('magnetUrl') or _make_magnet(ih, name)
            b    = entry.get('bytes') or 0
            size = '%.1f GB' % (b/1e9) if b >= 1e9 else '%.0f MB' % (b/1e6) if b >= 1e6 else ''
            results.append({
                'title':     name,
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     int(entry.get('seeders') or 0),
                'size':      size,
                'source':    'XXXClub/Knaben',
            })
            if len(results) >= limit:
                break
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] XXXClub search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Nyaa.si (anime / Japanese media, also has live-action movies) ─────────────

_NYAA_RSS = 'https://nyaa.si/?page=rss&q={q}&c=0_0&f=0'
_RE_NYAA_HASH  = re.compile(r'<nyaa:infoHash>([a-fA-F0-9]{40})</nyaa:infoHash>', re.IGNORECASE)
_RE_NYAA_SEED  = re.compile(r'<nyaa:seeders>(\d+)</nyaa:seeders>', re.IGNORECASE)
_RE_NYAA_SIZE  = re.compile(r'<nyaa:size>([^<]+)</nyaa:size>', re.IGNORECASE)
_RE_NYAA_TITLE = re.compile(r'<title><!\[CDATA\[([^\]]+)\]\]></title>', re.IGNORECASE)
_RE_NYAA_ITEM  = re.compile(r'<item>(.*?)</item>', re.IGNORECASE | re.DOTALL)


def search_nyaa(title, year=None, limit=8, media_type='movie'):
    """Nyaa.si RSS search — best for anime; also indexes live-action J-movies."""
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)
        url = _NYAA_RSS.format(q=_q(query))
        rss = _get(url, timeout=10)
        if not rss:
            return []
        results = []
        for item_m in _RE_NYAA_ITEM.finditer(rss):
            if len(results) >= limit:
                break
            item = item_m.group(1)
            ih_m = _RE_NYAA_HASH.search(item)
            if not ih_m:
                continue
            ih = ih_m.group(1).lower()
            title_m = _RE_NYAA_TITLE.search(item)
            name = title_m.group(1).strip() if title_m else ''
            if not name or not _meets_quality(name, media_type):
                continue
            seeds_m = _RE_NYAA_SEED.search(item)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = _RE_NYAA_SIZE.search(item)
            size = size_m.group(1).strip() if size_m else ''
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Nyaa',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Nyaa error: %s' % e, xbmc.LOGWARNING)
        return []


# ── LimeTorrents (limetorrents.info + mirrors) ────────────────────────────────

_LIME_MIRRORS = [
    'https://www.limetorrents.info',
    'https://limetorrents.cc',
    'https://limetorrents.fun',
    'https://limetor.com',
]
_lime_working = {}

_RE_LIME_ROW  = re.compile(
    r'<div[^>]+class="[^"]*tt-name[^"]*"[^>]*>.*?'
    r'<a[^>]+href="(/torrent/[^"]+)"[^>]*>([^<]+)</a>.*?'
    r'<td[^>]+class="[^"]*tdseed[^"]*"[^>]*>(\d+)<',
    re.IGNORECASE | re.DOTALL
)
_RE_LIME_HASH = re.compile(r'/torrent/[^/]+/([a-fA-F0-9]{40})/', re.IGNORECASE)
_RE_LIME_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def _get_lime_base():
    cached = _lime_working.get('url')
    ts     = _lime_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _LIME_MIRRORS:
        try:
            html = _get(mirror + '/', timeout=7)
            if html and 'torrent' in html.lower():
                _lime_working['url'] = mirror
                _lime_working['ts']  = time.time()
                return mirror
        except Exception:
            continue
    return _LIME_MIRRORS[0]


def search_limetorrents(title, year=None, limit=5, media_type='movie'):
    """LimeTorrents — HTML scrape with mirror rotation."""
    try:
        base  = _get_lime_base()
        query = re.sub(r'\s+', '-', title.lower())
        if year and media_type != 'adult':
            query = '%s-%s' % (query, year)
        url  = '%s/search/all/%s/seeds/1/' % (base, query)
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for row_m in _RE_LIME_ROW.finditer(html):
            if len(results) >= limit:
                break
            path, name, seeds = row_m.group(1), row_m.group(2).strip(), row_m.group(3)
            if not _meets_quality(name, media_type):
                continue
            # Hash embedded in torrent detail path
            ih_m = _RE_LIME_HASH.search(path)
            if ih_m:
                ih = ih_m.group(1).lower()
            else:
                # Fetch detail page for hash
                try:
                    detail = _get(base + path, timeout=7)
                    ih_m2  = re.search(r'magnet:.*?btih:([a-fA-F0-9]{40})', detail, re.IGNORECASE)
                    ih     = ih_m2.group(1).lower() if ih_m2 else ''
                except Exception:
                    ih = ''
            if not ih:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(seeds),
                'size':      '',
                'source':    'LimeTorrents',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] LimeTorrents error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorLock (torlock.com) ─────────────────────────────────────────────────────

_TORLOCK_MIRRORS = ['https://www.torlock.com', 'https://www.torlock2.com']
_torlock_working = {}

_RE_TORLOCK_ROW = re.compile(
    r'<a[^>]+href="/torrent/(\d+)/([^"]+\.html)"[^>]*>([^<]+)</a>'
    r'.*?<td[^>]*>(\d+)</td>',
    re.IGNORECASE | re.DOTALL
)
_RE_TORLOCK_HASH = re.compile(r'<td[^>]*>([a-fA-F0-9]{40})</td>', re.IGNORECASE)
_RE_TORLOCK_MAG  = re.compile(r'href="(magnet:\?[^"]+)"', re.IGNORECASE)


def _get_torlock_base():
    cached = _torlock_working.get('url')
    ts     = _torlock_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _TORLOCK_MIRRORS:
        try:
            html = _get(mirror + '/', timeout=7)
            if html and 'torrent' in html.lower():
                _torlock_working['url'] = mirror
                _torlock_working['ts']  = time.time()
                return mirror
        except Exception:
            continue
    return _TORLOCK_MIRRORS[0]


def search_torlock(title, year=None, limit=5, media_type='movie'):
    """TorLock — HTML scrape."""
    try:
        base  = _get_torlock_base()
        query = re.sub(r'\s+', '-', title.lower())
        if year and media_type != 'adult':
            query = '%s-%s' % (query, year)
        cat_path = 'all'
        if media_type == 'movie':
            cat_path = 'movie'
        elif media_type == 'tv':
            cat_path = 'television'
        url  = '%s/%s/torrents/%s.html?sort=seeds' % (base, cat_path, query)
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for row_m in _RE_TORLOCK_ROW.finditer(html):
            if len(results) >= limit:
                break
            tid, _, name, seeds = (
                row_m.group(1), row_m.group(2),
                row_m.group(3).strip(), row_m.group(4)
            )
            if not _meets_quality(name, media_type):
                continue
            # Magnet from detail page
            try:
                detail = _get('%s/torrent/%s/x.html' % (base, tid), timeout=8)
                mag_m  = _RE_TORLOCK_MAG.search(detail)
                if not mag_m:
                    ih_m = _RE_TORLOCK_HASH.search(detail)
                    if ih_m:
                        ih     = ih_m.group(1).lower()
                        magnet = _make_magnet(ih, name)
                    else:
                        continue
                else:
                    magnet = mag_m.group(1).replace('&amp;', '&').split('&tr=')[0]
                    ih_m   = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                    ih     = ih_m.group(1).lower() if ih_m else ''
            except Exception:
                continue
            if not ih:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     int(seeds),
                'size':      '',
                'source':    'TorLock',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorLock error: %s' % e, xbmc.LOGWARNING)
        return []


# ── msearch.vercel.app (meta-search JSON API) ─────────────────────────────────

_MSEARCH_API = 'https://msearch.vercel.app/api/search'
_MSEARCH_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept':     'application/json',
    'Referer':    'https://msearch.vercel.app/',
}


def search_msearch_torrents(title, year=None, limit=10, media_type='movie'):
    """
    msearch.vercel.app — meta-search aggregator.
    Returns magnet links aggregated from multiple indexers via JSON API.
    """
    try:
        if not _req:
            return []
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        # Try common Vercel Next.js API patterns
        for api_url in [
            '%s?q=%s&type=torrent' % (_MSEARCH_API, _q(query)),
            'https://msearch.vercel.app/api/torrents?q=%s' % _q(query),
            'https://msearch.vercel.app/api/search?q=%s&category=%s' % (
                _q(query), 'adult' if media_type == 'adult' else 'all'),
        ]:
            try:
                r = _sess().get(api_url, headers=_MSEARCH_HEADERS, timeout=12)
                if r.status_code == 404:
                    continue
                r.raise_for_status()
                data = r.json()
            except Exception:
                continue
            # Normalise response — could be list or dict with results key
            if isinstance(data, list):
                items = data
            elif isinstance(data, dict):
                items = (data.get('results') or data.get('data') or
                         data.get('torrents') or data.get('items') or [])
            else:
                items = []
            if not items:
                continue
            results = []
            for item in items:
                if len(results) >= limit:
                    break
                name = (item.get('title') or item.get('name') or
                        item.get('torrent_title') or '').strip()
                if not name or not _meets_quality(name, media_type):
                    continue
                ih = (item.get('hash') or item.get('info_hash') or
                      item.get('infoHash') or '').lower()
                magnet = (item.get('magnet') or item.get('magnet_link') or
                          item.get('magnetUrl') or '')
                if not ih and magnet:
                    ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                    if ih_m:
                        ih = ih_m.group(1).lower()
                if not ih:
                    continue
                if not magnet:
                    magnet = _make_magnet(ih, name)
                seeds = int(item.get('seeds') or item.get('seeders') or 0)
                b     = item.get('size') or item.get('bytes') or 0
                size  = ''
                if isinstance(b, int):
                    if b >= 1_073_741_824:
                        size = '%.1f GB' % (b / 1_073_741_824)
                    elif b >= 1_048_576:
                        size = '%.0f MB' % (b / 1_048_576)
                elif isinstance(b, str):
                    size = b
                results.append({
                    'title': name, 'year': '', 'quality': _extract_quality(name),
                    'info_hash': ih, 'magnet': magnet,
                    'seeds': seeds, 'size': size, 'source': 'MSearch',
                })
            if results:
                return sorted(results, key=lambda x: x['seeds'], reverse=True)
        return []
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] MSearch error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentio (IMDB-based, requires imdb_id) ──────────────────────────────────

TORRENTIO_BASE = 'https://torrentio.strem.fun'

def search_torrentio(imdb_id, season=None, episode=None, limit=10):
    """Query Torrentio API by IMDB ID. Returns magnet list sorted by seeds."""
    if not imdb_id:
        return []
    try:
        import urllib.request as _ureq, json as _json
        if season is not None and episode is not None:
            path = '/stream/series/%s:%d:%d.json' % (imdb_id, int(season), int(episode))
        else:
            path = '/stream/movie/%s.json' % imdb_id
        url = TORRENTIO_BASE + path
        req = _ureq.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with _ureq.urlopen(req, timeout=12) as resp:
            data = _json.loads(resp.read().decode('utf-8'))
        results = []
        for stream in data.get('streams', []):
            ih = stream.get('infoHash', '')
            if not ih:
                continue
            raw_title = stream.get('title', '') or ''
            name = raw_title.split('\n')[0].strip()
            # Parse seeds from title lines (emoji 👤 + number)
            seeds = 0
            for line in raw_title.split('\n')[1:]:
                m = re.search(r'(\d+)', line)
                if m:
                    seeds = int(m.group(1))
                    break
            magnet = 'magnet:?xt=urn:btih:%s&dn=%s' % (ih, _ureq.quote(name))
            results.append({
                'title':     name,
                'info_hash': ih.lower(),
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      0,
                'source':    'Torrentio',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torrentio error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Unified search ────────────────────────────────────────────────────────────

def search_all(title, year=None, media_type='movie', max_per_source=5, imdb_id=None,
               season=None, episode=None):
    """
    Search all torrent sources in parallel. Returns combined list sorted by seeds.
    media_type: 'movie', 'tv', or 'adult'
    imdb_id: optional tt... ID for Torrentio
    season/episode: for TV episodes
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    # TPB categories: 500=adult, 201=Movies/HD, 208=TV/HD (205 is broken/empty)
    tpb_cat = 500 if media_type == 'adult' else (201 if media_type == 'movie' else 208)

    # Previously removed for being CF-blocked; re-enabled with cfscraper fallback.
    # TGX: magnets may be JS-rendered on some mirrors — cfscraper handles most.
    # ext.to: CF-protected but cfscraper bypass works when the session is warm.
    # Dead permanently: isohunt2 (404), EZTV (CF 403), 1337x all domains (403),
    #   TorrentFunk (CF 403), Bitlord (0 results), YourBT (0 results)
    tasks = {
        'TPB':              lambda: search_tpb(title, year, tpb_cat, max_per_source, media_type),
        'Bitsearch':        lambda: search_bitsearch(title, None, max_per_source, media_type),
        'Knaben':           lambda: search_knaben(title, year, media_type, max_per_source * 2),
        'MagnetDL':         lambda: search_magnetdl(title, None, max_per_source, media_type),
        'BitTorrented':     lambda: search_bittorrented(title, None, max_per_source, media_type),
        'TorrentDL':        lambda: search_torrentdownloads(title, year, max_per_source, media_type),
        'Nyaa':             lambda: search_nyaa(title, year, max_per_source, media_type),
        'LimeTorrents':     lambda: search_limetorrents(title, year, max_per_source, media_type),
        'TorLock':          lambda: search_torlock(title, year, max_per_source, media_type),
        'MSearch':          lambda: search_msearch_torrents(title, year, max_per_source * 2, media_type),
        'TGX':              lambda: search_torrentgalaxy(title, year, max_per_source, media_type),
        'ext.to':           lambda: search_extto(title, year, max_per_source, media_type),
    }

    # Torrentio: API-based, needs IMDB ID, works great for TV and movies
    if imdb_id and media_type in ('movie', 'tv'):
        if media_type == 'tv' and season is not None and episode is not None:
            tasks['Torrentio'] = lambda: search_torrentio(imdb_id, season, episode, max_per_source * 2)
        elif media_type == 'movie':
            tasks['Torrentio'] = lambda: search_torrentio(imdb_id, limit=max_per_source * 2)

    if media_type in ('movie', 'adult'):
        tasks['YTS'] = lambda: search_yts(title, year, max_per_source, media_type)
    if media_type == 'adult':
        tasks['XXXClub'] = lambda: search_xxxclub(title, year, max_per_source * 2, media_type)

    all_results = []
    with ThreadPoolExecutor(max_workers=min(len(tasks), 12)) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        try:
            for future in as_completed(futures, timeout=15):
                name = futures[future]
                try:
                    results = future.result()
                    xbmc.log('[Starfleet/Torrents] %s: %d results' % (name, len(results)), xbmc.LOGINFO)
                    all_results.extend(results)
                except Exception as e:
                    xbmc.log('[Starfleet/Torrents] %s failed: %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Torrents] search_all timeout: %s' % e, xbmc.LOGWARNING)

    # For non-adult, filter out false matches where the show/movie name
    # doesn't appear as whole words in the torrent title.
    # Prevents e.g. "Farmhouse Rules S04E10" matching search "FROM S04E10"
    # because "from" appears as a substring inside "farmhouse".
    if media_type != 'adult' and title:
        _skip_words = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'or', 'and'}
        _search_words = [
            w.lower() for w in re.split(r'\W+', title)
            if len(w) >= 2 and w.lower() not in _skip_words
        ]
        if _search_words:
            def _title_matches(torrent_name):
                norm = re.sub(r'[._\-\[\]()+]', ' ', torrent_name.lower())
                norm = re.sub(r'\s+', ' ', norm)
                return all(
                    re.search(r'\b' + re.escape(w) + r'\b', norm)
                    for w in _search_words
                )
            before = len(all_results)
            all_results = [r for r in all_results if _title_matches(r.get('title', ''))]
            filtered = before - len(all_results)
            if filtered:
                xbmc.log('[Starfleet/Torrents] Title filter removed %d false matches' % filtered, xbmc.LOGINFO)

    # Deduplicate by info_hash
    seen = set()
    unique = []
    for r in all_results:
        ih = r.get('info_hash', '').lower()
        if ih and ih not in seen:
            seen.add(ih)
            unique.append(r)

    unique.sort(key=lambda x: x.get('seeds', 0), reverse=True)
    return unique
