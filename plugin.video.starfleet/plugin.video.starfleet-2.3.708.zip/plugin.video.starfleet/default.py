# -*- coding: utf-8 -*-
"""
Starfleet — default.py

Intentionally minimal entry point.
All routing logic lives in resources/lib/dispatcher.py.

With reuselanguageinvoker=true, Python keeps this module alive
between navigation calls — dispatcher.py is imported once and
all subsequent calls reuse the loaded module with zero re-import cost.
"""

import sys

try:                                  # Android: let the scrapers list the sources that need the Starfleet Helper add-on (never a dependency)
    from resources.lib import webhelper
    webhelper.enable_env()
except Exception:
    pass

from resources.lib.dispatcher import run

run(
    handle      = int(sys.argv[1]),
    base_url    = sys.argv[0],
    query_string= sys.argv[2],
)
