# -*- coding: utf-8 -*-
"""
Starfleet Helper (Android only): the little companion app that opens a player page in a hidden web view, the way the HazMat TV app does,
and gives back the stream the page plays. Kodi itself has no web view, so sources whose player is built by obfuscated JavaScript
(marked 'sfweb:<page>' by the scrapers) need it. It is NOT a dependency: everything else works without it, and when a source that needs it
is chosen, a pop-up offers to install it.

    enable_env()            set HAZMAT_WEBVIEW so the scrapers list the sources that need the helper (Android only)
    available()             True when the helper answers (it is started when it is installed but not running)
    sniff(page, referer)    -> 'stream|Header=value&..' or ''
    resolve_page(page, ...) -> the stream for a page, with the install pop-up, a progress notice and error messages; '' when there is none
"""
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

PORT = 18765
_BASE = 'http://127.0.0.1:%d' % PORT
PACKAGE = 'com.starfleet.helper'
HELPER_APK = 'StarfleetHelper-1.0.0.apk'
HELPER_URL = 'https://raw.githubusercontent.com/HazMat77/repository.starfleet/main/helper/' + HELPER_APK

ENABLED = False             # off until the helper has been tested on a device: web-view sources stay unlisted (enable_env does nothing)

_declined_at = 0.0          # the pop-up is not shown again for 10 minutes after "Cancel" (a list of streams can hold several of these sources)


def is_android():
    try:
        return bool(xbmc.getCondVisibility('System.Platform.Android'))
    except Exception:
        return False


def enable_env():
    """Tell the scrapers that web-view sources can be offered (they are listed whether or not the helper is installed yet)."""
    if ENABLED and is_android():
        os.environ.setdefault('HAZMAT_WEBVIEW', '1')


def _get(path, timeout):
    import urllib.request
    with urllib.request.urlopen(_BASE + path, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8', 'replace'))


def ping(timeout=1.5):
    try:
        d = _get('/ping', timeout)
        return d if d.get('ok') else None
    except Exception:
        return None


def _start(wait=8.0):
    """Opens the helper's invisible start screen (it starts the service and closes at once) and waits for it to answer."""
    xbmc.executebuiltin('StartAndroidActivity("%s","com.starfleet.helper.START")' % PACKAGE)
    end = time.time() + wait
    while time.time() < end:
        if ping(1.0):
            return True
        xbmc.sleep(400)
    return False


def available(start=True):
    """True when the helper answers; with `start`, an installed helper that is not running is started first."""
    if not is_android():
        return False
    if ping():
        return True
    return _start() if start else False


def sniff(page, referer='', timeout=25):
    """Asks the helper for the stream a player page plays. '' when the page gave none in time."""
    from urllib.parse import quote
    try:
        d = _get('/sniff?url=%s&referer=%s&timeout=%d' % (quote(page, safe=''), quote(referer or '', safe=''), int(timeout)), timeout + 8)
        return d.get('url') or ''
    except Exception as e:
        xbmc.log('[Starfleet/Helper] sniff failed: %s' % e, xbmc.LOGWARNING)
        return ''


# ---- the install offer -----------------------------------------------------------------------------------------------------------------

def _download(dest):
    import urllib.request
    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet Helper', 'Downloading the Starfleet Helper add-on...')
    try:
        with urllib.request.urlopen(HELPER_URL, timeout=30) as r, open(dest, 'wb') as f:
            total = int(r.headers.get('Content-Length') or 0)
            got = 0
            while True:
                chunk = r.read(64 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if total:
                    dlg.update(min(99, got * 100 // total))
                if dlg.iscanceled():
                    return False
        return got > 100000
    except Exception as e:
        xbmc.log('[Starfleet/Helper] download failed: %s' % e, xbmc.LOGWARNING)
        return False
    finally:
        dlg.close()


def _install():
    """Downloads the helper and opens Android's installer for it. The user taps Install there."""
    folders = ['/storage/emulated/0/Download', '/sdcard/Download', xbmcvfs.translatePath('special://temp/')]
    dest = ''
    for d in folders:
        try:
            if os.path.isdir(d) and os.access(d, os.W_OK):
                dest = os.path.join(d, HELPER_APK)
                break
        except Exception:
            pass
    if not dest or not _download(dest):
        xbmcgui.Dialog().ok('Starfleet Helper', 'The download did not work.[CR]You can get it yourself at:[CR]' + HELPER_URL)
        return False
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file://%s")' % dest)
    xbmcgui.Dialog().ok('Starfleet Helper',
                        'Tap [B]Install[/B] on the screen that opens.[CR]If it does not open, install the file [B]%s[/B] from your Downloads folder, '
                        'then choose the source again.' % HELPER_APK)
    return True


def offer_install():
    """The pop-up: this source needs the helper; OK downloads and installs it."""
    global _declined_at
    if time.time() - _declined_at < 600:
        return False
    if xbmcgui.Dialog().yesno('Starfleet Helper',
                              'This source needs the Starfleet Helper add-on.[CR]Would you like to install it?',
                              nolabel='Cancel', yeslabel='OK'):
        return _install()
    _declined_at = time.time()
    return False


# ---- what the routers call -------------------------------------------------------------------------------------------------------------

def resolve_page(page, referer='', title='', timeout=25):
    """The stream of a web player page ('url|headers'), or '' when there is none (the user has been told why)."""
    page = (page or '')
    if page.startswith('sfweb:'):
        page = page[len('sfweb:'):]
    if not is_android():
        xbmcgui.Dialog().notification('Starfleet', 'This source needs an Android device', xbmcgui.NOTIFICATION_INFO, 4000)
        return ''
    if not available():
        offer_install()
        return ''
    xbmcgui.Dialog().notification('Starfleet', 'Opening the web player...', xbmcgui.NOTIFICATION_INFO, 3000)
    got = sniff(page, referer, timeout)
    if not got:
        xbmcgui.Dialog().notification('Starfleet', 'The web player did not give a stream', xbmcgui.NOTIFICATION_INFO, 4000)
    return got
