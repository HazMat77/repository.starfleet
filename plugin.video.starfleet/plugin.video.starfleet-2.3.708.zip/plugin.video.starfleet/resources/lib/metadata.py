﻿# -*- coding: utf-8 -*-
"""
resources/lib/metadata.py

Unified metadata client for TV Shows and Movies.

Sources:
  TMDB (The Movie Database) — movies + TV shows, images, cast, ratings
  TVDB (The TV Database)    — TV show episode details, aired dates
  IMDB ID                   — cross-reference via TMDB external_ids

API Keys (from Enterprise-Toolbox/my_common.py):
  TMDB: rotated across 6 keys to stay under rate limits
  TVDB: single key, JWT auth token cached 24h

Cache TTLs:
  Search results      → 1h
  Movie detail        → 7d  (rarely changes)
  TV show detail      → 24h
  Season/episodes     → 24h
  Cast                → 7d
  Images              → 7d
  TVDB token          → 23h (token valid 24h)

Image base URL: https://image.tmdb.org/t/p/
  Poster/thumb:  w500{poster_path}
  Fanart:        original{backdrop_path}
  Cast photo:    w185{profile_path}
  Still (ep):    w300{still_path}
"""

import random
import time
from functools import lru_cache
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

# ── API Keys ──────────────────────────────────────────────────────────────────

TMDB_KEYS = [
    'df33d5fbe29640895eb99174c801dbc7',
    'a7ebe77c68d738c3dd38348ee0c8f70f',
    'fe07cdedea76c769f430982de6c14842',
    '6cb7bcda188b8c9028544da7182242fd',
    'c577de0778f2ba33846ec5003332dbb6',
    '948f72aef4062585f9075b91b9c0c226',
]
TMDB_TOKEN  = 'c46469cc91ef531c87b21d10267ca47a6r8db'
TVDB_KEY    = '32b17143-9e3d-4b91-813f-c36bf66185a7'  # old key confirmed dead (401 InvalidAPIKey) — replaced with a fresh one, verified live

# v4 "API Read Access Token" — bootstraps the tmdb_auth.py pairing handshake
# (see the v4 auth section below). Same shared-app model as TMDB_KEYS above:
# this identifies the Starfleet app to TMDB, it does NOT grant access to any
# particular account's data — every installer still personally logs into
# their own TMDB account and approves during pairing, getting their own
# separate access_token, exactly like every other Starfleet user sharing
# TMDB_KEYS above for search/metadata never exposes anyone's own account.
# Confirmed live against /4/auth/request_token before bundling.
TMDB_V4_READ_TOKEN = ('eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4MmM0NTQyNjc2OGM5MTAzN2Iw'
                      'NzBhZGEwMmZlZTg4OCIsIm5iZiI6MTY5NDU1OTI0NS4wNzIsInN1YiI6'
                      'IjY1MDBlYzBkZjI5ZDY2MDExZDVjOWEwNCIsInNjb3BlcyI6WyJhcGlf'
                      'cmVhZCJdLCJ2ZXJzaW9uIjoxfQ.rYzJrWFbkRliHhfsI--NhNgx40qZ'
                      'Fo3jsU_FyKU1xMc')

TMDB_BASE    = 'https://api.themoviedb.org/3'
TMDB_BASE_V4 = 'https://api.themoviedb.org/4'
TMDB_IMG    = 'https://image.tmdb.org/t/p'
DETAIL_POSTER = 'w500'          # the big poster of a movie / show detail screen
TVDB_BASE   = 'https://api4.thetvdb.com/v4'   # TVDB v4 API

# ── HTTP Session ──────────────────────────────────────────────────────────────

_session = None

def _sess():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update({
            'User-Agent': 'plugin.video.starfleet/1.0',
            'Accept':     'application/json',
        })
        a = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=10,
            max_retries=requests.adapters.Retry(total=3, backoff_factor=0.4)
        )
        _session.mount('https://', a)
    return _session


def _tmdb_key():
    """Rotate through TMDB keys to spread rate limit."""
    return random.choice(TMDB_KEYS)


# ── TMDB HTTP ─────────────────────────────────────────────────────────────────

def _tmdb_get(endpoint, params=None, timeout=10):
    """GET from TMDB API with API key injected."""
    p = {'api_key': _tmdb_key(), 'language': 'en-US'}
    if params:
        p.update(params)
    r = _sess().get(TMDB_BASE + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def get_tmdb_list_v4(list_id, access_token):
    """The same list read as its owner (TMDB v4 with the paired account's token): works for a PRIVATE list, which the shared v3 key cannot see.
    Items come back shaped like the v3 ones ('id', 'media_type', 'title' / 'name', dates, poster / backdrop). [] on any error."""
    try:
        items = []
        page, total_pages = 1, 1
        while page <= total_pages:
            r = _sess().get(TMDB_BASE_V4 + '/list/%s' % list_id, params={'page': page, 'language': 'en-US'},
                            headers={'Authorization': 'Bearer %s' % access_token, 'Content-Type': 'application/json'}, timeout=12)
            r.raise_for_status()
            data = r.json()
            items.extend(data.get('results') or [])
            total_pages = min(int(data.get('total_pages') or 1), 100)
            page += 1
        return items
    except Exception as e:
        xbmc.log('[Starfleet/Metadata] get_tmdb_list_v4(%s) error: %s' % (list_id, e), xbmc.LOGWARNING)
        return []


def _list_page(list_id, page, tries=3):
    """One page of a TMDB list, tried again a couple of times (one slow or refused request must not empty a whole favorites row)."""
    last = None
    for i in range(tries):
        try:
            return _tmdb_get('/list/%s' % list_id, params={'page': page}, timeout=15)
        except Exception as e:
            last = e
            time.sleep(0.4 * (i + 1))
    raise last


def get_tmdb_list(list_id):
    """Fetch a public TMDB v3 List (the same list at themoviedb.org/list/<id>) by ID: the Favorites 'sync from a TMDB List' setting.
    TMDB's own /list/{id} endpoint tags every item with 'media_type' ('movie' or 'tv'), so one list can mix both. The list paginates at about
    20 items a page, so the first page says how many there are and the rest are asked for four at a time, each page tried again if it fails.
    A page that still fails is skipped (what the other pages hold is returned); [] only when nothing could be read."""
    try:
        first = _list_page(list_id, 1)
    except Exception as e:
        xbmc.log('[Starfleet/Metadata] get_tmdb_list(%s) error: %s' % (list_id, e), xbmc.LOGWARNING)
        return []
    pages = {1: first.get('items') or []}
    total = min(int(first.get('total_pages') or 1), 100)
    if total > 1:
        from concurrent.futures import ThreadPoolExecutor

        def one(p):
            try:
                return p, _list_page(list_id, p).get('items') or []
            except Exception as e:
                xbmc.log('[Starfleet/Metadata] get_tmdb_list(%s) page %s error: %s' % (list_id, p, e), xbmc.LOGWARNING)
                return p, []
        with ThreadPoolExecutor(max_workers=4) as ex:
            for p, its in ex.map(one, range(2, total + 1)):
                pages[p] = its
    items = []
    for p in sorted(pages):
        items.extend(pages[p])
    return items


# ── TMDB v4 account auth + list write ──────────────────────────────────────────
# Separate, unrelated auth system from the v3 api_key above. TMDB's v3 list
# write endpoints (list/{id}/add_item) only ever accept a bare movie
# media_id — confirmed live they're literally titled "Add Movie"/"Remove
# Movie" in TMDB's own API reference, no media_type field exists to pass a
# TV id through. Since this addon's Favorites already mix movies and TV in
# one list (see get_tmdb_list() above), only v4's list-write endpoint
# (which does take a media_type per item) can push both kinds back. v4 has
# its own, unrelated OAuth-ish handshake: the caller needs a personal "API
# Read Access Token (v4 auth)" (from the account's own themoviedb.org
# Settings > API page — there's no bundle-wide token like TMDB_KEYS above,
# each user registers/owns their own) as the Bearer for the 2 handshake
# calls below; the resulting access_token from step 2 (not the read
# token) is what actually authorizes list writes afterward.

def tmdb_v4_request_token(read_token):
    """Step 1 of v4 pairing. Returns (request_token, error_message) — one
    is always '' on success/failure respectively."""
    try:
        r = _sess().post(TMDB_BASE_V4 + '/auth/request_token', json={},
                          headers={'Authorization': 'Bearer %s' % read_token,
                                   'Content-Type': 'application/json'},
                          timeout=10)
        data = r.json()
        if data.get('success') and data.get('request_token'):
            return data['request_token'], ''
        return '', data.get('status_message', 'Unknown error')
    except Exception as e:
        xbmc.log('[Starfleet/Metadata] tmdb_v4_request_token error: %s' % e, xbmc.LOGWARNING)
        return '', str(e)


def tmdb_v4_create_access_token(read_token, request_token):
    """Step 2 of v4 pairing — call only after the user has approved
    request_token at themoviedb.org/auth/access. Returns a dict with
    'success' (bool) plus 'access_token'/'account_id' on success —
    'success': False with no exception is the normal "not approved yet"
    response, since TMDB has no separate pending-status check to poll."""
    try:
        r = _sess().post(TMDB_BASE_V4 + '/auth/access_token',
                          json={'request_token': request_token},
                          headers={'Authorization': 'Bearer %s' % read_token,
                                   'Content-Type': 'application/json'},
                          timeout=10)
        return r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Metadata] tmdb_v4_create_access_token error: %s' % e, xbmc.LOGWARNING)
        return {'success': False}


def _tmdb_v4_list_write(method, list_id, access_token, media_type, media_id):
    try:
        r = _sess().request(
            method, TMDB_BASE_V4 + '/list/%s/items' % list_id,
            json={'items': [{'media_type': media_type, 'media_id': int(media_id)}]},
            headers={'Authorization': 'Bearer %s' % access_token,
                     'Content-Type': 'application/json'},
            timeout=10)
        data = r.json()
        results = data.get('results') or []
        ok = bool(results and results[0].get('success'))
        # Always log the raw response, not just on exception - a clean HTTP
        # 200 with results[0].success=False (wrong list owner, bad/expired
        # access_token, media_id not actually in the list on remove, etc.)
        # previously vanished with zero trace in kodi.log, making a report
        # like "it silently didn't work" undiagnosable after the fact.
        xbmc.log('[Starfleet/Metadata] tmdb_v4_list_write(%s, list=%s, %s/%s) -> '
                 'HTTP %s ok=%s body=%s' % (method, list_id, media_type, media_id,
                                            r.status_code, ok, data), xbmc.LOGINFO)
        return ok
    except Exception as e:
        xbmc.log('[Starfleet/Metadata] tmdb_v4_list_write(%s, list=%s, %s/%s) error: %s' %
                 (method, list_id, media_type, media_id, e), xbmc.LOGWARNING)
        return False


def tmdb_v4_list_add_item(list_id, access_token, media_type, media_id):
    return _tmdb_v4_list_write('POST', list_id, access_token, media_type, media_id)


def tmdb_v4_list_remove_item(list_id, access_token, media_type, media_id):
    return _tmdb_v4_list_write('DELETE', list_id, access_token, media_type, media_id)


# ── Image URL helpers ─────────────────────────────────────────────────────────

@lru_cache(maxsize=2000)
def poster(path, size='w342'):
    # Every poster call across the whole addon (list/carousel thumbs AND
    # the single big detail-screen poster) went through this one default,
    # and it was 'original' — TMDB's full source-resolution image, often
    # 2000x3000px+ and several hundred KB to low-MB EACH. Confirmed live
    # this addon's own detail screens never actually display a poster
    # wider than ~500-600px on a 1920px-wide layout, so nothing here was
    # ever using the extra resolution - it was pure wasted bandwidth and
    # decode/resize cost multiplied across every item in every widget
    # carousel (Home alone loads ~480 posters across its rows). w780
    # (780x1170) stays sharp at any size this addon actually renders a
    # poster, while being a small fraction of 'original's file size.
    #
    # 2026-10: lists and carousels show a poster at about 200x315, so they now ask for w342 (a fifth of w780's pixels): on a Fire
    # TV Stick (1.7 GB, Kodi killed for low memory once) every poster in Home's rows is decoded and held as a texture. The detail
    # screens, which draw one big poster, ask for w500 (see DETAIL_POSTER below).
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''

@lru_cache(maxsize=2000)
def fanart(path, size='w1280'):          # was 'original' (up to 3840 px wide): w1280 is plenty behind a 1080p screen's overlays
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''

@lru_cache(maxsize=2000)
def still(path, size='w300'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''

@lru_cache(maxsize=2000)
def profile(path, size='w185'):
    return '%s/%s%s' % (TMDB_IMG, size, path) if path else ''


# ── Find by external ID (IMDB) ───────────────────────────────────────────────

def find_movie_by_imdb(imdb_id):
    """TMDB's /find endpoint — resolves a plain IMDB id ("tt1234567") to
    real TMDB poster/fanart/overview with a single lightweight call (no
    need for a full get_movie_detail() round trip just to enrich a
    listing thumb). Used by resources/lib/gui/home.py's Requests section
    (resources/lib/request_sources.py's movie entries only carry an
    imdb_id, not a tmdb_id, since that's what the orchestrator's own
    source filenames already embed). Returns {} if imdb_id is blank or
    TMDB has no match (a hand-typed id that doesn't exist, or a title not
    yet in TMDB) — callers should fall back to a blank thumb, same as
    every other best-effort enrichment call in this module."""
    if not imdb_id:
        return {}
    ck = 'meta_find_imdb_%s' % imdb_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached or {}
    try:
        data = _tmdb_get('/find/%s' % imdb_id, {'external_source': 'imdb_id'})
        results = data.get('movie_results') or []
        if not results:
            _cache.set(ck, False, 24 * 3600)
            return {}
        m = results[0]
        result = {
            'tmdb_id':  str(m.get('id', '')),
            'title':    m.get('title', m.get('original_title', '')),
            'year':     str(m.get('release_date', '') or '')[:4],
            'thumb':    poster(m.get('poster_path', '')),
            'fanart':   fanart(m.get('backdrop_path', '')),
            'overview': m.get('overview', ''),
        }
        _cache.set(ck, result, 7 * 24 * 3600)
        return result
    except Exception as e:
        xbmc.log('[Starfleet/Meta] find_movie_by_imdb(%s) error: %s' % (imdb_id, e), xbmc.LOGWARNING)
        return {}


def find_tv_by_imdb(imdb_id):
    """find_movie_by_imdb() for shows: a plain IMDB id -> TMDB id / poster / fanart / overview. {} when there is no match."""
    if not imdb_id:
        return {}
    ck = 'meta_find_tv_imdb_%s' % imdb_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached or {}
    try:
        data = _tmdb_get('/find/%s' % imdb_id, {'external_source': 'imdb_id'})
        results = data.get('tv_results') or []
        if not results:
            _cache.set(ck, False, 24 * 3600)
            return {}
        m = results[0]
        result = {
            'tmdb_id':  str(m.get('id', '')),
            'title':    m.get('name', m.get('original_name', '')),
            'year':     str(m.get('first_air_date', '') or '')[:4],
            'thumb':    poster(m.get('poster_path', '')),
            'fanart':   fanart(m.get('backdrop_path', '')),
            'overview': m.get('overview', ''),
        }
        _cache.set(ck, result, 7 * 24 * 3600)
        return result
    except Exception as e:
        xbmc.log('[Starfleet/Meta] find_tv_by_imdb(%s) error: %s' % (imdb_id, e), xbmc.LOGWARNING)
        return {}


# ── MOVIE — Search ────────────────────────────────────────────────────────────

def search_movies(query, page=1):
    """
    Search TMDB for movies matching query.
    Returns list of slim dicts for fast list rendering.
    """
    ck = 'tmdb_movie_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        data    = _tmdb_get('/search/movie', {'query': query, 'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] search_movies error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_popular(page=1):
    ck = 'tmdb_movies_popular_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/popular', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_popular error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_top_rated(page=1):
    ck = 'tmdb_movies_top_rated_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/top_rated', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_top_rated error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_new(page=1):
    ck = 'tmdb_movies_new_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/now_playing', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_new error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_trending(page=1):
    """Weekly trending movies from TMDB."""
    ck = 'tmdb_movies_trending_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/trending/movie/week', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])
                   if m.get('vote_count', 0) >= 10]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_trending error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_upcoming(page=1):
    """Upcoming movies from TMDB."""
    ck = 'tmdb_movies_upcoming_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/movie/upcoming', {'page': page})
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_upcoming error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_anticipated(page=1):
    """'Most anticipated' upcoming movies, approximated from TMDB alone (no
    Trakt dependency): unreleased titles sorted by TMDB's own popularity
    score, rather than /movie/upcoming's plain nearest-release-date order
    (which surfaces obscure titles releasing next week over a genuinely
    hyped one releasing in 3 months)."""
    import datetime as _dt
    ck = 'tmdb_movies_anticipated_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        today = _dt.date.today().isoformat()
        data = _tmdb_get('/discover/movie', {
            'sort_by': 'popularity.desc',
            'primary_release_date.gte': today,
            'page': page,
        })
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3 * 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_anticipated error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_anticipated(page=1):
    """'Most anticipated' upcoming TV shows — same approach as
    get_movies_anticipated but for /discover/tv."""
    import datetime as _dt
    ck = 'tmdb_tv_anticipated_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        today = _dt.date.today().isoformat()
        data = _tmdb_get('/discover/tv', {
            'sort_by': 'popularity.desc',
            'first_air_date.gte': today,
            'page': page,
        })
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3 * 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_anticipated error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_by_date(page=1):
    """Movies sorted by release date descending — newest first."""
    import datetime as _dt
    ck = 'tmdb_movies_by_date_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        today = _dt.date.today().isoformat()
        data = _tmdb_get('/discover/movie', {
            'page': page,
            'sort_by': 'release_date.desc',
            'release_date.lte': today,
            'vote_count.gte': 10,
            'with_original_language': 'en',
        })
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_by_date error: %s' % e, xbmc.LOGERROR)
        return []


def get_by_year(media, year_from, year_to, genre_id='', page=1):
    """Movies or TV shows released between two years (either may be empty), optionally in one genre, best known first."""
    ck = 'tmdb_year_%s_%s_%s_%s_%d' % (media, year_from, year_to, genre_id, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        tv = media == 'tv'
        key = 'first_air_date' if tv else 'primary_release_date'
        params = {'page': page, 'sort_by': 'popularity.desc', 'vote_count.gte': 20}
        if year_from:
            params[key + '.gte'] = '%04d-01-01' % int(year_from)
        if year_to:
            params[key + '.lte'] = '%04d-12-31' % int(year_to)
        if genre_id:
            params['with_genres'] = genre_id
        data = _tmdb_get('/discover/tv' if tv else '/discover/movie', params)
        slim = _slim_tv if tv else _slim_movie
        results = [slim(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_by_year error: %s' % e, xbmc.LOGERROR)
        return []


def get_movie_genres():
    ck = 'tmdb_movie_genres'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data   = _tmdb_get('/genre/movie/list')
        genres = data.get('genres', [])
        _cache.set(ck, genres, 7 * 24 * 3600)
        return genres
    except Exception as e:
        xbmc.log('[Meta] get_movie_genres error: %s' % e, xbmc.LOGERROR)
        return []


def get_movies_by_genre(genre_id, page=1):
    ck = 'tmdb_movies_genre_%s_%d' % (genre_id, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/discover/movie', {
            'with_genres': genre_id, 'page': page,
            'sort_by': 'popularity.desc'
        })
        results = [_slim_movie(m) for m in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_movies_by_genre error: %s' % e, xbmc.LOGERROR)
        return []


# ── MOVIE — Collections (Box Sets) ───────────────────────────────────────────

def _slim_collection(c):
    """Minimal collection dict for list views."""
    return {
        'collection_id': str(c.get('id', '')),
        'title':         c.get('name', ''),
        'thumb':         poster(c.get('poster_path', '')),
        'fanart':        fanart(c.get('backdrop_path', '')),
        'overview':      c.get('overview', ''),
    }


def get_collection_detail(collection_id):
    """Full TMDB collection (box set/franchise) detail: name/overview/
    artwork plus every movie in the set. TMDB's /collection/{id} 'parts'
    array already comes back complete in one call — collections aren't
    paginated the way /discover/movie is, there's no 'next page' of a
    box set. Sorted chronologically by release date, per how a box set is
    actually meant to be watched."""
    if not collection_id:
        return {}
    ck = 'tmdb_collection_%s' % collection_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached or {}
    try:
        data = _tmdb_get('/collection/%s' % collection_id)
        parts = sorted(data.get('parts') or [],
                        key=lambda m: m.get('release_date') or '9999-99-99')
        result = {
            'collection_id': str(collection_id),
            'title':         data.get('name', ''),
            'overview':      data.get('overview', ''),
            'thumb':         poster(data.get('poster_path', '')),
            'fanart':        fanart(data.get('backdrop_path', '')),
            'movies':        [_slim_movie(m) for m in parts],
        }
        _cache.set(ck, result, 30 * 24 * 3600)
        return result
    except Exception as e:
        xbmc.log('[Meta] get_collection_detail(%s) error: %s' % (collection_id, e), xbmc.LOGERROR)
        return {}


# Curated seed list for the Box Sets browse menu — TMDB has no "discover
# collections" endpoint (only /search/collection, which needs a query
# already), so this hardcodes real, verified TMDB collection ids for ~70
# well-known franchises rather than requiring the user to search first
# before anything shows up. Hand-verified one-by-one against
# /search/collection rather than trusting the raw top search hit — several
# plain-name searches return an unrelated same-named collection first (e.g.
# "Rocky" top-matches "The Rocky Horror Picture Show Collection", "Alien"
# top-matches "Alien Sharks Collection", "The Conjuring" top-matches
# "Conjuring the Genie Collection", confirmed live).
_POPULAR_COLLECTIONS = [
    (263,    'The Dark Knight Collection'),
    (120794, 'Batman Collection'),
    (10,     'Star Wars Collection'),
    (645,    'James Bond Collection'),
    (9485,   'The Fast and the Furious Collection'),
    (1241,   'Harry Potter Collection'),
    (119,    'The Lord of the Rings Collection'),
    (121938, 'The Hobbit Collection'),
    (87359,  'Mission: Impossible Collection'),
    (404609, 'John Wick Collection'),
    (328,    'Jurassic Park Collection'),
    (8091,   'Alien Collection'),
    (399,    'Predator Collection'),
    (528,    'The Terminator Collection'),
    (1575,   'Rocky Collection'),
    (748,    'X-Men Collection'),
    (556,    'Spider-Man Collection'),
    (531241, 'Spider-Man (MCU) Collection'),
    (125574, 'The Amazing Spider-Man Collection'),
    (573436, 'Spider-Man: Spider-Verse Collection'),
    (10194,  'Toy Story Collection'),
    (2150,   'Shrek Collection'),
    (8354,   'Ice Age Collection'),
    (8650,   'Transformers Collection'),
    (2344,   'The Matrix Collection'),
    (295,    'Pirates of the Caribbean Collection'),
    (84,     'Indiana Jones Collection'),
    (86055,  'Men in Black Collection'),
    (304,    "Ocean's Collection"),
    (31562,  'The Bourne Collection'),
    (656,    'Saw Collection'),
    (313086, 'The Conjuring Collection'),
    (86066,  'Despicable Me Collection'),
    (89137,  'How to Train Your Dragon Collection'),
    (77816,  'Kung Fu Panda Collection'),
    (33514,  'Twilight Collection'),
    (131635, 'The Hunger Games Collection'),
    (283579, 'Divergent Collection'),
    (295130, 'The Maze Runner Collection'),
    (1709,   'Planet of the Apes (Original) Collection'),
    (173710, 'Planet of the Apes (Reboot) Collection'),
    (435259, 'Fantastic Beasts Collection'),
    (86311,  'The Avengers Collection'),
    (131292, 'Iron Man Collection'),
    (131295, 'Captain America Collection'),
    (131296, 'Thor Collection'),
    (284433, 'Guardians of the Galaxy Collection'),
    (151,    'Star Trek: The Original Series Collection'),
    (115570, 'Star Trek: The Next Generation Collection'),
    (115575, 'Star Trek: Alternate Reality Collection'),
    (86119,  'The Hangover Collection'),
    (14740,  'Madagascar Collection'),
    (87118,  'Cars Collection'),
    (256322, 'The Purge Collection'),
    (91361,  'Halloween Collection'),
    (8581,   'A Nightmare on Elm Street Collection'),
    (2602,   'Scream Collection'),
    (8864,   'Final Destination Collection'),
    (17255,  'Resident Evil Collection'),
    (2326,   'Underworld Collection'),
    (5039,   'Rambo Collection'),
    (1570,   'Die Hard Collection'),
    (945,    'Lethal Weapon Collection'),
    (52984,  'National Treasure Collection'),
    (535313, 'Godzilla Collection'),
    (495527, 'Jumanji Collection'),
    (382685, 'Now You See Me Collection'),
    (102322, 'Sherlock Holmes Collection'),
    (391860, 'Kingsman Collection'),
    (448150, 'Deadpool Collection'),
    (558216, 'Venom Collection'),
    (8580,   'The Karate Kid Collection'),
    (468552, 'Wonder Woman Collection'),
    (573693, 'Aquaman Collection'),
]


def get_popular_collections():
    """Curated Box Sets browse list. Fetches each curated collection's full
    detail concurrently (rotating across TMDB_KEYS already spreads the
    rate-limit load) and reuses get_collection_detail()'s own per-collection
    cache entry — opening this menu warms the cache for whichever one the
    user actually drills into next, no separate lightweight fetch needed."""
    ck = 'tmdb_popular_collections_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    from concurrent.futures import ThreadPoolExecutor
    results = []
    try:
        with ThreadPoolExecutor(max_workers=12) as ex:
            details = list(ex.map(lambda pair: get_collection_detail(pair[0]), _POPULAR_COLLECTIONS))
        for d in details:
            if d:
                results.append({
                    'collection_id': d['collection_id'], 'title': d['title'],
                    'thumb': d['thumb'], 'fanart': d['fanart'], 'overview': d['overview'],
                })
        results.sort(key=lambda c: c['title'])
    except Exception as e:
        xbmc.log('[Meta] get_popular_collections error: %s' % e, xbmc.LOGERROR)
    if results:
        _cache.set(ck, results, 30 * 24 * 3600)
    return results


def search_collections(query, page=1):
    """Search TMDB collections (franchises/box sets) by name — the
    fallback for anything not in the curated get_popular_collections()
    list above."""
    ck = 'tmdb_collection_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/search/collection', {'query': query, 'page': page})
        results = [_slim_collection(c) for c in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] search_collections error: %s' % e, xbmc.LOGERROR)
        return []


# ── MOVIE — Detail ────────────────────────────────────────────────────────────

def _fill_mpaa_from_simkl(detail, media_type):
    """TMDB's own certification (release_dates for movies, content_ratings
    for TV) sometimes comes back empty — non-US titles, newer releases,
    or ones TMDB just hasn't backfilled. SIMKL's public /movies|tv/{imdb}
    endpoint (no pairing needed) often has it when TMDB doesn't, confirmed
    live (R for Oppenheimer, TV-MA for Special Ops: Lioness), so it's used
    as a same-cache-window fallback only — never overwrites a TMDB value
    that's already there, and costs nothing when TMDB already had one."""
    if detail.get('mpaa') or not detail.get('imdb_id'):
        return
    try:
        from resources.lib import simkl_sync as _simkl_sync
        cert = _simkl_sync.get_certification(detail['imdb_id'], media_type)
        if cert:
            detail['mpaa'] = cert
    except Exception as e:
        xbmc.log('[Meta] SIMKL certification fallback error: %s' % e, xbmc.LOGWARNING)


_PARENTS_GUIDE_QUERY = """
query TitleParentsGuideFull($tconst: ID!, $first: Int!) {
  title(id: $tconst) {
    id
    parentsGuide {
      categories {
        category { id text }
        severity { id text votedFor }
        totalSeverityVotes
        guideItems(first: $first) {
          edges {
            node {
              text { plainText }
              isSpoiler
            }
          }
        }
      }
    }
  }
}
"""


def get_parental_guide(imdb_id):
    """Itemized IMDb Parents Guide (Sex & Nudity / Violence & Gore /
    Profanity / Alcohol, Drugs & Smoking / Frightening & Intense Scenes) —
    each with a crowd-voted severity level and specific example bullet
    points, well beyond the single broad MPAA-style letter in 'mpaa'
    above. IMDb's own HTML parents-guide page is bot-walled (confirmed
    live: plain fetch gets an empty HTTP 202), but its GraphQL API at
    api.graphql.imdb.com is not — confirmed live, no login/cookies/API key
    needed, just the right Referer/Origin headers. Best-effort only (same
    reasoning as _episodate_episodes above): a single attempt, no retries,
    short timeout, so a hiccup here never blocks the rest of the detail
    page. Cached for 30 days since guide items rarely change once a title
    has enough votes.

    Note: IMDb's response carries a non-commercial/non-public-use
    disclaimer on this data — fine for this addon's own personal use, but
    not a general-purpose licensed API."""
    if not imdb_id:
        return []
    ck = 'imdb_parents_guide_%s' % imdb_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        body = {
            'operationName': 'TitleParentsGuideFull',
            'query': _PARENTS_GUIDE_QUERY,
            'variables': {'tconst': imdb_id, 'first': 12},
        }
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                          '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
            'Referer': 'https://www.imdb.com/title/%s/parentalguide/' % imdb_id,
            'Origin': 'https://www.imdb.com',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }
        r = requests.post('https://api.graphql.imdb.com/', json=body,
                           headers=headers, timeout=6)
        r.raise_for_status()
        cats = ((r.json() or {}).get('data', {}).get('title') or {}) \
            .get('parentsGuide', {}).get('categories') or []
        out = []
        for c in cats:
            items = []
            for edge in (c.get('guideItems') or {}).get('edges', []):
                node = edge.get('node') or {}
                text = (node.get('text') or {}).get('plainText', '').strip()
                if text:
                    items.append({'text': text, 'spoiler': bool(node.get('isSpoiler'))})
            out.append({
                'id':       (c.get('category') or {}).get('id', ''),
                'name':     (c.get('category') or {}).get('text', ''),
                'severity': (c.get('severity') or {}).get('text', ''),
                'votes':    c.get('totalSeverityVotes', 0),
                'items':    items,
            })
        _cache.set(ck, out, 30 * 24 * 3600)
        return out
    except Exception as e:
        xbmc.log('[Meta] get_parental_guide(%s) error: %s' % (imdb_id, e), xbmc.LOGWARNING)
        return []


def _needs_release_recheck(detail):
    """A cached movie/TV detail fetched BEFORE its own release/air date
    keeps whatever pre-release status TMDB reported at fetch time (e.g.
    'Post Production') for the rest of its normal TTL - up to a further 7
    days for movies - even once the title has actually released, since
    nothing about a plain cache hit ever re-examines the data it's
    returning. Confirmed live: this is the real mechanism behind
    "Not Yet Released" reappearing after a title has genuinely come out -
    not a version/restart/cache-clear problem, a stale pre-release
    snapshot quietly outliving the moment it stopped being accurate.

    Cheap, narrow, self-healing fix: if the cached release date has
    already passed but the cached status doesn't yet reflect that, treat
    this specific cache entry as a miss and force one fresh re-fetch
    (which then re-caches the now-correct, now-Released copy for its full
    normal TTL). Only ever triggers extra network cost for a title in
    exactly this transition state - every other cache hit, released or
    still upcoming, is completely unaffected."""
    date_str = detail.get('release_date') or detail.get('first_air_date') or ''
    if not date_str:
        return False
    try:
        import datetime
        d = datetime.datetime.strptime(date_str[:10], '%Y-%m-%d').date()
        if d > datetime.date.today():
            return False
    except Exception:
        return False
    status = (detail.get('status') or '').strip().lower()
    return status not in ('released', 'ended', 'returning series', 'canceled', 'cancelled', 'in production')


def get_movie_detail(tmdb_id):
    """
    Full movie metadata including cast, crew, videos, external IDs.
    Returns rich dict ready for Kodi ListItem.
    """
    ck = 'tmdb_movie_%s' % tmdb_id
    cached = _cache.get(ck)
    if cached is not None and not _needs_release_recheck(cached):
        return cached

    try:
        data = _tmdb_get('/movie/%s' % tmdb_id, {
            'append_to_response': 'credits,videos,external_ids,images,release_dates'
        })
        detail = _parse_movie(data)
        _fill_mpaa_from_simkl(detail, 'movie')
        _cache.set(ck, detail, 7 * 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[Meta] get_movie_detail(%s) error: %s' % (tmdb_id, e), xbmc.LOGERROR)
        return {}


def _slim_movie(m):
    """Minimal movie dict for list views — fast to render."""
    return {
        'tmdb_id':      str(m.get('id', '')),
        'title':        m.get('title', m.get('original_title', '')),
        'year':         str(m.get('release_date', ''))[:4],
        'release_date': str(m.get('release_date', '')),
        'rating':       round(float(m.get('vote_average', 0)), 1),
        'thumb':        poster(m.get('poster_path', '')),
        'fanart':       fanart(m.get('backdrop_path', '')),
        'overview':     m.get('overview', ''),
        'genre_ids':    m.get('genre_ids', []),
        'media_type':   'movie',
    }


def _movie_certification(data):
    """US MPAA-style certification (G/PG/PG-13/R/NC-17) from TMDB's own
    release_dates append_to_response block — no IMDb scraping involved
    (IMDb's own Parents Guide page is bot-walled now, confirmed live: a
    plain fetch gets an HTTP 202 with an empty body, not real content).
    Falls back to GB's own board rating if the US entry has none, so a
    non-US-released title still shows something rather than blank."""
    for preferred in ('US', 'GB'):
        for entry in data.get('release_dates', {}).get('results', []):
            if entry.get('iso_3166_1') != preferred:
                continue
            for rd in entry.get('release_dates', []):
                cert = (rd.get('certification') or '').strip()
                if cert:
                    return cert
    return ''


def _parse_movie(data):
    """Full movie detail dict from TMDB append_to_response response."""
    genres    = [g['name'] for g in data.get('genres', [])]
    studios   = [s['name'] for s in data.get('production_companies', [])]

    # Credits
    credits   = data.get('credits', {})
    cast      = []
    for a in credits.get('cast', [])[:20]:
        cast.append({
            'name':      a.get('name', ''),
            'character': a.get('character', ''),
            'photo':     profile(a.get('profile_path', '')),
            'order':     a.get('order', 99),
        })
    director = ''
    writers  = []
    for c in credits.get('crew', []):
        if c.get('job') == 'Director':
            director = c.get('name', '')
        elif c.get('department') == 'Writing':
            writers.append(c.get('name', ''))

    # Trailer
    trailer = ''
    for v in data.get('videos', {}).get('results', []):
        if v.get('type') == 'Trailer' and v.get('site') == 'YouTube':
            trailer = 'plugin://plugin.video.starfleet/?action=trailer_play&video_id=%s' % v['key']
            break

    # External IDs
    ext     = data.get('external_ids', {})
    imdb_id = ext.get('imdb_id', data.get('imdb_id', ''))

    # Additional images (backdrops)
    images    = data.get('images', {})
    backdrops = [fanart(i['file_path']) for i in images.get('backdrops', [])[:5]]
    posters   = [poster(i['file_path']) for i in images.get('posters', [])[:5]]

    return {
        'tmdb_id':    str(data.get('id', '')),
        'imdb_id':    imdb_id,
        'title':      data.get('title', data.get('original_title', '')),
        'year':       str(data.get('release_date', ''))[:4],
        'rating':     round(float(data.get('vote_average', 0)), 1),
        'votes':      data.get('vote_count', 0),
        'runtime':    data.get('runtime', 0),
        'overview':   data.get('overview', ''),
        'tagline':    data.get('tagline', ''),
        'genres':     genres,
        'studios':    studios,
        'director':   director,
        'writers':    writers,
        'cast':       cast,
        'thumb':      poster(data.get('poster_path', ''), DETAIL_POSTER),
        'fanart':     fanart(data.get('backdrop_path', '')),
        'backdrops':  backdrops,
        'posters':    posters,
        'trailer':    trailer,
        'status':       data.get('status', ''),
        'release_date': str(data.get('release_date', '')),
        'mpaa':         _movie_certification(data),
        'media_type':   'movie',
    }


# ── TV SHOWS — Search ─────────────────────────────────────────────────────────

def search_tv(query, page=1):
    ck = 'tmdb_tv_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/search/tv', {'query': query, 'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] search_tv error: %s' % e, xbmc.LOGERROR)
        return []


# ── PERSON — Search + credits ─────────────────────────────────────────────────
# TMDB's /search/movie and /search/tv only match against titles — a query
# like "Tom Cruise" typed into Movies/TV Search returns nothing at all, even
# though TMDB has every actor's full filmography available. search_person()
# + get_person_*_credits() close that gap; search_movies_and_people()/
# search_tv_and_people() below are the actual drop-in replacements for the
# search entry points, since title search still needs to run too (a query
# could be a real title AND a person's name, e.g. "Elvis").

def search_person(query, page=1):
    """Search TMDB for a person (actor/actress/director/etc) by name."""
    ck = 'tmdb_person_search_%s_%d' % (query.lower().replace(' ', '_'), page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/search/person', {'query': query, 'page': page})
        results = [{
            'person_id':  str(p.get('id', '')),
            'name':       p.get('name', ''),
            'photo':      profile(p.get('profile_path', '')),
            'popularity': p.get('popularity', 0),
        } for p in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] search_person error: %s' % e, xbmc.LOGERROR)
        return []


def get_person_movie_credits(person_id):
    """Movies a person appears in as cast, newest first. TMDB's own
    /person/{id}/movie_credits cast entries carry the same fields
    _slim_movie() already expects from a /search/movie result, so no
    separate parsing is needed."""
    ck = 'tmdb_person_movie_credits_%s' % person_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/person/%s/movie_credits' % person_id)
        results = [_slim_movie(m) for m in data.get('cast', [])]
        results.sort(key=lambda m: m.get('release_date', ''), reverse=True)
        _cache.set(ck, results, 3600 * 24)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_person_movie_credits error: %s' % e, xbmc.LOGERROR)
        return []


def get_person_tv_credits(person_id):
    """TV shows a person appears in as cast, newest first — same reuse of
    _slim_tv() as get_person_movie_credits does for _slim_movie()."""
    ck = 'tmdb_person_tv_credits_%s' % person_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/person/%s/tv_credits' % person_id)
        results = [_slim_tv(s) for s in data.get('cast', [])]
        results.sort(key=lambda s: s.get('first_air_date', ''), reverse=True)
        _cache.set(ck, results, 3600 * 24)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_person_tv_credits error: %s' % e, xbmc.LOGERROR)
        return []


def search_movies_and_people(query, page=1):
    """Title search merged with a person-name match. Title results come
    first; if the query also matches a real person (best/most popular
    match), that person's own filmography is appended, deduped by
    tmdb_id — so "Tom Cruise" surfaces his movies instead of nothing, while
    "Top Gun" still works exactly as before."""
    results = search_movies(query, page=page)
    seen = {m['tmdb_id'] for m in results}
    try:
        people = search_person(query)
        if people:
            for m in get_person_movie_credits(people[0]['person_id']):
                if m['tmdb_id'] not in seen:
                    results.append(m)
                    seen.add(m['tmdb_id'])
    except Exception as e:
        xbmc.log('[Meta] search_movies_and_people person merge error: %s' % e, xbmc.LOGWARNING)
    return results


def search_tv_and_people(query, page=1):
    """Same as search_movies_and_people, for TV shows."""
    results = search_tv(query, page=page)
    seen = {s['tmdb_id'] for s in results}
    try:
        people = search_person(query)
        if people:
            for s in get_person_tv_credits(people[0]['person_id']):
                if s['tmdb_id'] not in seen:
                    results.append(s)
                    seen.add(s['tmdb_id'])
    except Exception as e:
        xbmc.log('[Meta] search_tv_and_people person merge error: %s' % e, xbmc.LOGWARNING)
    return results


def get_tv_popular(page=1):
    ck = 'tmdb_tv_popular_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/popular', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_popular error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_top_rated(page=1):
    ck = 'tmdb_tv_top_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/top_rated', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_top_rated error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_on_the_air(page=1):
    """TV shows currently on the air from TMDB."""
    ck = 'tmdb_tv_onair_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/on_the_air', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_on_the_air error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_airing_today(page=1):
    ck = 'tmdb_tv_airing_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/airing_today', {'page': page})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 1800)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_airing_today error: %s' % e, xbmc.LOGERROR)
        return []


NEW_SHOW_MONTHS = 8      # a show counts as new for this long after its first episode aired


def get_tv_new(page=1):
    """Shows whose first episode aired in the last NEW_SHOW_MONTHS months, most popular first (TMDB has no list of its own for it)."""
    import datetime
    since = (datetime.date.today() - datetime.timedelta(days=int(NEW_SHOW_MONTHS * 30.4))).isoformat()
    ck = 'tmdb_tv_new_%s_%d' % (since, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/discover/tv', {'page': page, 'sort_by': 'popularity.desc', 'first_air_date.gte': since})
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_new error: %s' % e, xbmc.LOGERROR)
        return []


# "Urban" movies and shows: TMDB has no such genre, so the rows are the titles of the studios and networks that make Black cinema and TV
# (Tyler Perry Studios, Will Packer, Array, Hoorae, HartBeat, Rainforest, Our Stories, BET and BET+ ...) together with the titles TMDB tags
# african american / black cinema / black culture / black people / black-led / hip hop culture. Each source is asked for on its own (TMDB
# combines its filters with AND) and the answers are merged, most popular first.
_URBAN_COMPANIES = '3096|49968|26571|158680|302956|40268|211352|71960|210689|89210|11964'
_URBAN_KEYWORDS = '256015|246126|288242|358563|362507|371253'
_URBAN_NETWORKS = '24|3343'
URBAN_NEW_MOVIE_DAYS = 183


def _urban(tv, new, page):
    import datetime
    today = datetime.date.today()
    since = (today - datetime.timedelta(days=URBAN_NEW_MOVIE_DAYS if not tv else int(NEW_SHOW_MONTHS * 30.4))).isoformat()
    ck = 'tmdb_urban_%s_%s_%s_%d' % ('tv' if tv else 'movie', 'new' if new else 'all', since if new else '', page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    base = {'page': page, 'sort_by': 'popularity.desc'}
    if new:
        base['first_air_date.gte' if tv else 'primary_release_date.gte'] = since
        if not tv:
            base['primary_release_date.lte'] = today.isoformat()
    else:
        base['vote_count.gte'] = 30
    sources = [{'with_companies': _URBAN_COMPANIES}, {'with_keywords': _URBAN_KEYWORDS}] + ([{'with_networks': _URBAN_NETWORKS}] if tv else [])
    found, seen = [], set()
    for src in sources:
        try:
            data = _tmdb_get('/discover/tv' if tv else '/discover/movie', dict(base, **src))
        except Exception as e:
            xbmc.log('[Meta] urban %s error: %s' % ('tv' if tv else 'movie', e), xbmc.LOGERROR)
            continue
        for r in data.get('results', []):
            if r.get('id') not in seen and r.get('poster_path'):
                seen.add(r.get('id'))
                found.append(r)
    found.sort(key=lambda r: -(r.get('popularity') or 0))
    results = [(_slim_tv if tv else _slim_movie)(r) for r in found]
    if results:
        _cache.set(ck, results, 3600)
    return results


# Franchise collections (TMDB collection ids): a menu of the big series, and the films of one, oldest first.
COLLECTIONS = [
    ('Star Wars', 10), ('Harry Potter', 1241), ('The Lord of the Rings', 119), ('Fast & Furious', 9485), ('James Bond', 645), ('Mission: Impossible', 87359),
    ('John Wick', 404609), ('Jurassic Park', 328), ('The Dark Knight', 263), ('Alien', 8091), ('Terminator', 528), ('The Matrix', 2344), ('Toy Story', 10194),
    ('Pirates of the Caribbean', 295), ('The Hunger Games', 131635), ('X-Men', 748), ('Rocky', 1575), ('Creed', 553717), ('Die Hard', 1570), ('Indiana Jones', 84),
    ('Back to the Future', 264), ('Shrek', 2150), ('Predator', 399), ('Transformers', 8650), ('Bourne', 31562), ('Despicable Me', 86066), ('Ice Age', 8354),
    ('Scream', 2602), ('Saw', 656), ('The Conjuring', 313086), ('Dune', 726871),
]


def get_collection_movies(collection_id):
    ck = 'tmdb_collection_%s' % collection_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _tmdb_get('/collection/%s' % collection_id)
    except Exception as e:
        xbmc.log('[Meta] collection %s error: %s' % (collection_id, e), xbmc.LOGERROR)
        return []
    parts = sorted([r for r in data.get('parts', []) if r.get('poster_path')], key=lambda r: r.get('release_date') or '9999')
    results = [_slim_movie(r) for r in parts]
    if results:
        _cache.set(ck, results, 6 * 3600)
    return results


def get_urban_movies(page=1):
    return _urban(False, False, page)


def get_urban_movies_new(page=1):
    return _urban(False, True, page)


def get_urban_shows(page=1):
    return _urban(True, False, page)


def get_urban_shows_new(page=1):
    return _urban(True, True, page)


# "Classic" movies and shows: TMDB has no such list, so it is asked for the titles from before the cut-off (movies up to 1989, shows that first
# aired up to 1999) with the most votes, the best known first. Shows are English language only.
CLASSIC_MOVIE_LAST = '1989-12-31'
CLASSIC_SHOW_LAST = '1999-12-31'


def _classic(tv, page):
    ck = 'tmdb_classic_%s_%d' % ('tv' if tv else 'movie', page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    params = {'page': page, 'sort_by': 'vote_count.desc'}
    if tv:
        params.update({'first_air_date.lte': CLASSIC_SHOW_LAST, 'vote_count.gte': 300, 'with_original_language': 'en'})
    else:
        params.update({'primary_release_date.lte': CLASSIC_MOVIE_LAST, 'vote_count.gte': 1500})
    try:
        data = _tmdb_get('/discover/tv' if tv else '/discover/movie', params)
    except Exception as e:
        xbmc.log('[Meta] classic %s error: %s' % ('tv' if tv else 'movie', e), xbmc.LOGERROR)
        return []
    results = [(_slim_tv if tv else _slim_movie)(r) for r in data.get('results', []) if r.get('poster_path')]
    if results:
        _cache.set(ck, results, 3600)
    return results


def get_classic_movies(page=1):
    return _classic(False, page)


def get_classic_shows(page=1):
    return _classic(True, page)


def get_tv_genres():
    ck = 'tmdb_tv_genres'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data   = _tmdb_get('/genre/tv/list')
        genres = data.get('genres', [])
        _cache.set(ck, genres, 7 * 24 * 3600)
        return genres
    except Exception as e:
        xbmc.log('[Meta] get_tv_genres error: %s' % e, xbmc.LOGERROR)
        return []


def get_tv_by_genre(genre_id, page=1):
    ck = 'tmdb_tv_genre_%s_%d' % (genre_id, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/discover/tv', {
            'with_genres': genre_id, 'page': page,
            'sort_by': 'popularity.desc'
        })
        results = [_slim_tv(s) for s in data.get('results', [])]
        _cache.set(ck, results, 3600)
        return results
    except Exception as e:
        xbmc.log('[Meta] get_tv_by_genre error: %s' % e, xbmc.LOGERROR)
        return []


# ── TV SHOWS — Detail ─────────────────────────────────────────────────────────

def get_tv_detail(tmdb_id):
    """Full TV show detail including seasons, cast, external IDs."""
    ck = 'tmdb_tv_%s' % tmdb_id
    cached = _cache.get(ck)
    if cached is not None and not _needs_release_recheck(cached):
        return cached
    try:
        data   = _tmdb_get('/tv/%s' % tmdb_id, {
            'append_to_response': 'credits,external_ids,images,videos,content_ratings'
        })
        detail = _parse_tv(data)
        _fill_mpaa_from_simkl(detail, 'tv')
        _cache.set(ck, detail, 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[Meta] get_tv_detail(%s) error: %s' % (tmdb_id, e), xbmc.LOGERROR)
        return {}


def _episodate_episodes(show_title, season_num, year=''):
    """Cross-check episodate.com — a free service needing no API key,
    built on TheTVDB's own dataset — for episodes TMDB simply doesn't
    have listed yet at all. TMDB is community-edited and can genuinely
    lag real air dates by days or weeks for smaller/reality shows;
    confirmed live (via the real TMDB API, not guesswork) that a real
    show's TMDB season page still showed only episode 1 after episode 2
    had already aired and was watchable elsewhere, while episodate.com
    already had it. This never overrides a TMDB episode that already
    exists — see get_season_detail below, which only adds an entry from
    here for an episode number TMDB is missing entirely — it exists
    purely to catch that gap, not to replace TMDB as the primary source."""
    if not show_title:
        return []
    import re as _re
    ck = 'episodate_%s_%s_s%s' % (_re.sub(r'[^a-z0-9]', '', show_title.lower())[:60], year or 'x', season_num)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        # Deliberately NOT using _sess() here — that shared session's
        # HTTPAdapter has 3 retries with backoff mounted on it (fine for
        # the primary TMDB/TVDB calls elsewhere in this file), but
        # episodate.com is a best-effort backstop only (see this
        # function's own docstring) — confirmed live it can go fully
        # unreachable for a stretch, and 2 calls x 3 retries x an 8s read
        # timeout stacked up to a ~36 second freeze on the episode list
        # for something that's explicitly optional. A single quick
        # attempt with no retries is the right cost for a nice-to-have.
        r = requests.get('https://www.episodate.com/api/search',
                         params={'q': show_title}, timeout=4)
        results = (r.json() or {}).get('tv_shows') or []
        if not results:
            _cache.set(ck, [], 3600)
            return []
        # Several different series share one title (Dark Matter 2015 vs 2024 ...): taking the first hit
        # bled the older show's episodes into the newer one's season list. Only a result whose start
        # year matches the TMDB show is accepted.
        want = _re.sub(r'[^a-z0-9]', '', show_title.lower())
        pick = None
        for cand in results:
            same = _re.sub(r'[^a-z0-9]', '', (cand.get('name') or '').lower()) == want
            cy = str(cand.get('start_date') or '')[:4]
            if same and (not year or cy == str(year)):
                pick = cand
                break
        if pick is None and not year:
            pick = results[0]
        permalink = (pick or {}).get('permalink', '')
        if not permalink:
            _cache.set(ck, [], 3600)
            return []
        r2 = requests.get('https://www.episodate.com/api/show-details',
                          params={'q': permalink}, timeout=4)
        eps = (r2.json() or {}).get('tvShow', {}).get('episodes') or []
        out = []
        for e in eps:
            if e.get('season') != season_num:
                continue
            out.append({
                'episode':  e.get('episode', 0),
                'season':   season_num,
                'title':    e.get('name', ''),
                'overview': '',
                'aired':    (e.get('air_date') or '')[:10],
                'rating':   0,
                'runtime':  0,
                'still':    '',
                'tmdb_id':  '',
            })
        _cache.set(ck, out, 6 * 3600)
        return out
    except Exception as e:
        xbmc.log('[Meta] _episodate_episodes error: %s' % e, xbmc.LOGWARNING)
        return []


def _aired_plausible(ep, show_detail):
    """An episode from a cross-check source can't have aired before the show itself began (a year of slack)."""
    try:
        first = int(str(show_detail.get('first_air_date') or show_detail.get('year') or '')[:4])
        aired = int(str(ep.get('aired') or '')[:4])
        return not (first and aired and aired < first - 1)
    except Exception:
        return True


def _season_looks_complete(episodes, expected):
    """True when TMDB's season needs no second opinion: every episode is dated, the last one aired more than three weeks ago and
    the count matches what the show page says the season has."""
    import datetime as _dt
    if not episodes or any(not e.get('aired') for e in episodes):
        return False
    cutoff = (_dt.date.today() - _dt.timedelta(days=21)).isoformat()
    if max(e['aired'] for e in episodes) >= cutoff:
        return False
    return not expected or len(episodes) >= expected


def get_season_detail(tmdb_id, season_num):
    """Full season detail including all episodes with stills and overviews.
    Cross-checks two other sources for any episode TMDB doesn't have
    listed at all yet — TMDB is community-edited and can genuinely lag
    real air dates by days or weeks for smaller/reality shows. TVDB tried
    first (needs the show's tvdb_id, which TMDB's own detail response
    already carries): confirmed live it's the richer of the two, with
    real per-episode overviews and even future episode titles/dates
    already listed for shows well ahead of their air date, not just the
    next one. episodate.com (free, no API key) is a second, cheaper
    backstop for whatever TVDB doesn't have (no tvdb_id resolved, or TVDB
    itself doesn't carry the show) — its own episodes have no
    overview/still at all, so it only ever fills a genuine gap, never
    displaces a TVDB or TMDB entry for the same episode."""
    ck = 'tmdb_season_%s_%s' % (tmdb_id, season_num)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data    = _tmdb_get('/tv/%s/season/%s' % (tmdb_id, season_num))
        episodes = []
        seen_nums = set()
        for ep in data.get('episodes', []):
            enum = ep.get('episode_number', 0)
            seen_nums.add(enum)
            episodes.append({
                'episode':   enum,
                'season':    ep.get('season_number', season_num),
                'title':     ep.get('name', ''),
                'overview':  ep.get('overview', ''),
                'aired':     ep.get('air_date', ''),
                'rating':    round(float(ep.get('vote_average', 0)), 1),
                'runtime':   ep.get('runtime', 0),
                'still':     still(ep.get('still_path', '')),
                'tmdb_id':   str(ep.get('id', '')),
            })
        try:
            show_detail = get_tv_detail(tmdb_id) or {}
            tvdb_id = show_detail.get('tvdb_id', '')
            expected = next((s.get('episode_count', 0) for s in show_detail.get('seasons', []) if str(s.get('season')) == str(season_num)), 0)
            if not _season_looks_complete(episodes, expected):
                from concurrent.futures import ThreadPoolExecutor as _TPE
                with _TPE(max_workers=2) as _pool:
                    f_tvdb = _pool.submit(get_tvdb_episodes, tvdb_id, season_num) if tvdb_id else None
                    f_epi = _pool.submit(_episodate_episodes, show_detail.get('title', ''), season_num, show_detail.get('year', ''))
                    for fut in (f_tvdb, f_epi):
                        if fut is None:
                            continue
                        try:
                            extras = fut.result(timeout=8) or []
                        except Exception:
                            extras = []
                        for extra in extras:
                            if extra['episode'] and extra['episode'] not in seen_nums and _aired_plausible(extra, show_detail):
                                episodes.append(extra)
                                seen_nums.add(extra['episode'])
                episodes.sort(key=lambda e: e['episode'])
        except Exception as e:
            xbmc.log('[Meta] TVDB/episodate cross-check error: %s' % e, xbmc.LOGWARNING)
        result = {
            'season':    season_num,
            'name':      data.get('name', 'Season %s' % season_num),
            'overview':  data.get('overview', ''),
            'air_date':  data.get('air_date', ''),
            'thumb':     poster(data.get('poster_path', '')),
            'episodes':  episodes,
        }
        _cache.set(ck, result, 24 * 3600)
        return result
    except Exception as e:
        xbmc.log('[Meta] get_season_detail error: %s' % e, xbmc.LOGERROR)
        return {'episodes': []}


def _slim_tv(s):
    return {
        'tmdb_id':        str(s.get('id', '')),
        'title':          s.get('name', s.get('original_name', '')),
        'year':           str(s.get('first_air_date', ''))[:4],
        'first_air_date': str(s.get('first_air_date', '')),
        'rating':         round(float(s.get('vote_average', 0)), 1),
        'thumb':          poster(s.get('poster_path', '')),
        'fanart':         fanart(s.get('backdrop_path', '')),
        'overview':       s.get('overview', ''),
        'genre_ids':      s.get('genre_ids', []),
        'media_type':     'tv',
    }


def _tv_certification(data):
    """US TV content rating (TV-Y/TV-PG/TV-14/TV-MA/etc) from TMDB's own
    content_ratings append_to_response block — same reasoning as
    _movie_certification above (no IMDb scraping — that page is bot-walled
    now). Falls back to GB if no US rating is listed."""
    for preferred in ('US', 'GB'):
        for entry in data.get('content_ratings', {}).get('results', []):
            if entry.get('iso_3166_1') != preferred:
                continue
            rating = (entry.get('rating') or '').strip()
            if rating:
                return rating
    return ''


def _parse_tv(data):
    genres   = [g['name'] for g in data.get('genres', [])]
    networks = [n['name'] for n in data.get('networks', [])]
    studios  = [s['name'] for s in data.get('production_companies', [])]

    # Seasons (skip season 0 / specials unless it has episodes)
    seasons = []
    for s in data.get('seasons', []):
        if s.get('season_number', 0) == 0 and s.get('episode_count', 0) == 0:
            continue
        seasons.append({
            'season':        s.get('season_number', 0),
            'name':          s.get('name', 'Season %s' % s.get('season_number')),
            'episode_count': s.get('episode_count', 0),
            'air_date':      s.get('air_date', ''),
            'thumb':         poster(s.get('poster_path', '')),
            'overview':      s.get('overview', ''),
        })

    # Cast
    credits = data.get('credits', {})
    cast    = []
    for a in credits.get('cast', [])[:20]:
        cast.append({
            'name':      a.get('name', ''),
            'character': a.get('character', ''),
            'photo':     profile(a.get('profile_path', '')),
        })
    creators = [c.get('name', '') for c in data.get('created_by', [])]

    # External IDs
    ext     = data.get('external_ids', {})
    imdb_id = ext.get('imdb_id', '')
    tvdb_id = str(ext.get('tvdb_id', ''))

    # Trailer
    trailer = ''
    for v in data.get('videos', {}).get('results', []):
        if v.get('type') == 'Trailer' and v.get('site') == 'YouTube':
            trailer = 'plugin://plugin.video.starfleet/?action=trailer_play&video_id=%s' % v['key']
            break

    # Images
    images    = data.get('images', {})
    backdrops = [fanart(i['file_path']) for i in images.get('backdrops', [])[:5]]

    return {
        'tmdb_id':      str(data.get('id', '')),
        'imdb_id':      imdb_id,
        'tvdb_id':      tvdb_id,
        'title':        data.get('name', data.get('original_name', '')),
        'year':         str(data.get('first_air_date', ''))[:4],
        'first_air_date': data.get('first_air_date', ''),
        'rating':       round(float(data.get('vote_average', 0)), 1),
        'votes':        data.get('vote_count', 0),
        'runtime':      (data.get('episode_run_time') or [0])[0],
        'overview':     data.get('overview', ''),
        'tagline':      data.get('tagline', ''),
        'genres':       genres,
        'networks':     networks,
        'studios':      studios,
        'creators':     creators,
        'cast':         cast,
        'seasons':      seasons,
        'status':       data.get('status', ''),
        'thumb':        poster(data.get('poster_path', ''), DETAIL_POSTER),
        'fanart':       fanart(data.get('backdrop_path', '')),
        'backdrops':    backdrops,
        'trailer':      trailer,
        'mpaa':         _tv_certification(data),
        'media_type':   'tv',
    }


# ── TVDB — Episode detail via TVDB v4 ─────────────────────────────────────────

def _get_tvdb_token():
    """Get/refresh TVDB JWT auth token. Cached 23h."""
    cached = _cache.get('tvdb_token')
    if cached:
        return cached

    if _cache.get('tvdb_token_failed'):
        return ''

    try:
        r = _sess().post(TVDB_BASE + '/login',
                         json={'apikey': TVDB_KEY}, timeout=10)
        r.raise_for_status()
        token = r.json().get('data', {}).get('token', '')
        if token:
            _cache.set('tvdb_token', token, 23 * 3600)
            xbmc.log('[Meta] TVDB token obtained', xbmc.LOGINFO)
        return token
    except Exception as e:
        xbmc.log('[Meta] TVDB auth error (TV episode metadata unavailable): %s' % e, xbmc.LOGWARNING)
        _cache.set('tvdb_token_failed', True, 2 * 3600)
        return ''


def get_tvdb_episodes(tvdb_id, season_num):
    """
    Get episode list from TVDB for a given series and season.
    Falls back gracefully to TMDB data if TVDB unavailable.
    """
    ck = 'tvdb_eps_%s_%s' % (tvdb_id, season_num)
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    token = _get_tvdb_token()
    if not token:
        return []

    try:
        headers = {'Authorization': 'Bearer %s' % token}
        r = _sess().get(
            '%s/series/%s/episodes/official' % (TVDB_BASE, tvdb_id),
            headers=headers,
            params={'season': season_num, 'page': 0},
            timeout=10
        )
        r.raise_for_status()
        data     = r.json()
        episodes = []
        for ep in data.get('data', {}).get('episodes', []):
            episodes.append({
                'episode':  ep.get('number', 0),
                'season':   ep.get('seasonNumber', season_num),
                'title':    ep.get('name', ''),
                'overview': ep.get('overview', ''),
                'aired':    ep.get('aired', ''),
                'runtime':  ep.get('runtime', 0),
                # TVDB v4's own 'image' field is already a full URL
                # (confirmed live: "https://artworks.thetvdb.com/banners/
                # ..."), not a relative path — prepending the base URL
                # again produced a broken doubled-domain link that could
                # never load. This never surfaced before now because the
                # dead API key meant this code path never actually ran.
                'still':    ep.get('image', '') or '',
                'tvdb_id':  str(ep.get('id', '')),
            })
        _cache.set(ck, episodes, 24 * 3600)
        return episodes
    except Exception as e:
        xbmc.log('[Meta] get_tvdb_episodes error: %s' % e, xbmc.LOGERROR)
        return []


# ── Unified episode fetcher ───────────────────────────────────────────────────

def get_episodes(tmdb_id, season_num, tvdb_id=None):
    """
    Get episodes for a season. Tries TMDB first (has stills + overview),
    enriches with TVDB data if tvdb_id available.
    """
    # TMDB is primary — richer image data
    season = get_season_detail(tmdb_id, season_num)
    episodes = season.get('episodes', [])

    # If we have a TVDB id, merge in any missing data
    if tvdb_id and episodes and any(not ep.get('still') or not ep.get('overview') for ep in episodes):
        tvdb_eps = {ep['episode']: ep for ep in get_tvdb_episodes(tvdb_id, season_num)}
        for ep in episodes:
            tvdb_ep = tvdb_eps.get(ep['episode'], {})
            # Fill in missing still from TVDB
            if not ep.get('still') and tvdb_ep.get('still'):
                ep['still'] = tvdb_ep['still']
            # Fill in missing overview from TVDB
            if not ep.get('overview') and tvdb_ep.get('overview'):
                ep['overview'] = tvdb_ep['overview']

    return episodes


def find_tv_episode_by_title(title, season, episode):
    """Resolve a plain show title + season/episode — the "Requests" TV
    schema (resources/lib/request_sources.py) has no imdb_id the way
    movies do, since scene-release filenames don't embed one — to real
    TMDB show art, preferring that specific episode's own still/overview
    over the show's own poster/overview when TMDB has it. Used by
    resources/lib/gui/home.py's Requests section. Falls back to the
    show's own poster/fanart/overview if the specific episode has no
    still yet (a very recent episode, etc), and to {} entirely if TMDB
    has no match for the title at all — same best-effort contract as
    find_movie_by_imdb."""
    if not title:
        return {}
    ck = 'meta_find_tv_ep_%s_s%se%s' % (title.lower().replace(' ', '_'), season, episode)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or {}
    try:
        results = search_tv(title)
        if not results:
            _cache.set(ck, False, 24 * 3600)
            return {}
        show = results[0]
        result = {
            'tmdb_id':  show.get('tmdb_id', ''),
            'title':    show.get('title', title),
            'thumb':    show.get('thumb', ''),
            'fanart':   show.get('fanart', ''),
            'overview': show.get('overview', ''),
        }
        if season and episode and result['tmdb_id']:
            try:
                eps = get_episodes(result['tmdb_id'], int(season))
                for ep in eps:
                    if str(ep.get('episode')) == str(episode):
                        if ep.get('still'):
                            result['thumb'] = ep['still']
                        if ep.get('overview'):
                            result['overview'] = ep['overview']
                        break
            except Exception:
                pass
        _cache.set(ck, result, 7 * 24 * 3600)
        return result
    except Exception as e:
        xbmc.log('[Starfleet/Meta] find_tv_episode_by_title error: %s' % e, xbmc.LOGWARNING)
        return {}


# ── Cross-search: find TMDB ID from title ─────────────────────────────────────

def find_tmdb_id(title, year=None, media_type='movie'):
    """
    Search TMDB for a title and return the best matching TMDB ID.
    Used to link external content (e.g. a file on StreamTape) to metadata.
    """
    try:
        endpoint = '/search/movie' if media_type == 'movie' else '/search/tv'
        params   = {'query': title}
        if year:
            params['year' if media_type == 'movie' else 'first_air_date_year'] = year
        data    = _tmdb_get(endpoint, params)
        results = data.get('results', [])
        if results:
            return str(results[0]['id'])
    except Exception as e:
        xbmc.log('[Meta] find_tmdb_id error: %s' % e, xbmc.LOGERROR)
    return None
