"""
Starfleet Home GUI launcher.
Opens the home window immediately with cached data, then refreshes in the background.
"""
import sys
import os
import json
import threading
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon


def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)

    # dispatcher.run() calls cache.clear_if_updated() at the top of every
    # native plugin:// action, but this Home window is a SEPARATE entry
    # point (launched directly via RunScript, not through dispatcher) and
    # is normally the very first thing that runs after an update — so the
    # stale-cache-surviving-a-version-bump bug (clear_if_updated's own
    # docstring) kept happening even after that fix shipped, because this
    # path never called it. Must happen before the background refresh
    # thread below starts populating the cache under the new version.
    try:
        from resources.lib import cache as _cache
        _cache.clear_if_updated()
    except Exception as _e:
        xbmc.log('[Starfleet/Home] clear_if_updated error: %s' % _e, xbmc.LOGWARNING)

    try:                                       # a quick "has my tracker changed?" check whenever Home opens (see tracker_sync.py)
        from resources.lib import tracker_sync as _tsync
        _tsync.kick()
    except Exception as _e:
        xbmc.log('[Starfleet/Home] tracker sync (non-fatal): %s' % _e, xbmc.LOGWARNING)

    data_dir  = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(data_dir, exist_ok=True)
    from resources.lib import profiles as _profiles
    data_file    = os.path.join(_profiles.data_dir(), 'home_data.json')     # each profile's own rows
    version_file = os.path.join(data_dir, 'last_version.txt')
    current_ver  = addon.getAddonInfo('version')

    # Prevent multiple home windows from opening simultaneously.
    # run_home.py is called via RunScript (separate Python process per call), so we
    # use an atomic file lock: O_CREAT|O_EXCL succeeds for exactly one process.
    import time as _time
    window_lock = os.path.join(data_dir, 'window.lock')
    _got_lock = False
    try:
        fd = os.open(window_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
        _got_lock = True
    except FileExistsError:
        try:
            age = _time.time() - os.path.getmtime(window_lock)
            if age < 30:
                xbmc.log('[Starfleet/Home] window already open, skipping', xbmc.LOGINFO)
                return
            # Stale lock — steal it
            os.remove(window_lock)
            fd = os.open(window_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            _got_lock = True
        except Exception:
            xbmc.log('[Starfleet/Home] window already open, skipping', xbmc.LOGINFO)
            return
    except Exception:
        _got_lock = True  # can't create lock — proceed anyway

    empty    = [[], [], [], []]
    contexts = {'default': empty, 'movies': empty, 'tv': empty, 'anime': empty,
                'sports': empty, 'live': empty, 'adult': empty,
                'trakt_anticipated': empty, 'radio': empty, 'profile': empty}

    # Check whether this is a first run / update
    try:
        with open(version_file, 'r') as _f:
            saved_ver = _f.read().strip()
    except Exception:
        saved_ver = ''
    is_new_version = (saved_ver != current_ver)

    # Only one instance should run the heavy refresh at a time.
    # Kodi widget loading can invoke run_home.py 2-3 times simultaneously on startup;
    # on low-RAM devices (FireStick) multiple parallel TMDB+ADE fetches cause freezes.
    lock_file = os.path.join(data_dir, 'refresh.lock')
    refresh_done   = threading.Event()
    refresh_result = [None]

    def _acquire_lock():
        """Return True if this instance gets the refresh lock."""
        try:
            import time as _time
            # Stale lock older than 90s is safe to take over
            if os.path.exists(lock_file):
                age = _time.time() - os.path.getmtime(lock_file)
                if age < 90:
                    return False
            with open(lock_file, 'w') as _lf:
                _lf.write(str(os.getpid()))
            return True
        except Exception:
            return True  # if lock fails, proceed anyway

    def _release_lock():
        try:
            os.remove(lock_file)
        except Exception:
            pass

    got_lock = _acquire_lock()

    def _refresh():
        try:
            from resources.lib import afdb_router as _ar
            _ctx = _profiles.filter_rows(_ar.get_home_carousel_data())     # the profile's content limit
            refresh_result[0] = _ctx
            _tmp = data_file + '.tmp'
            with open(_tmp, 'w', encoding='utf-8') as _f:
                json.dump(_ctx, _f)
            os.replace(_tmp, data_file)
            _d = _ctx.get('default', empty)
            xbmc.log('[Starfleet/Home] background refresh done: %d/%d/%d/%d' % (
                len(_d[0]), len(_d[1]), len(_d[2]), len(_d[3]) if len(_d) > 3 else 0), xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log('[Starfleet/Home] background refresh error: %s' % _e, xbmc.LOGWARNING)
        finally:
            _release_lock()
            refresh_done.set()

    if got_lock:
        t = threading.Thread(target=_refresh, daemon=True)
        t.start()
    else:
        # Another instance is refreshing — just signal done so splash/window don't wait.
        # Real bug found live via a Firestick kodi.log 2026-08-16 (same device this
        # file's own comment above already flags as more prone to concurrent
        # run_home.py launches on low-RAM devices): refresh_result[0] is ONLY ever
        # set inside THIS instance's own _refresh(), which never runs when got_lock
        # is False — so it stays None forever for this instance. That silently
        # defeats _push_when_ready below in two ways: its refresh_result[0] check
        # can never pass, AND (since refresh_done is already set here) the block
        # that starts _push_when_ready at all is skipped entirely — this instance's
        # window opens with whatever was in home_data.json at that moment and NEVER
        # gets updated again, no matter how long it stays open. Confirmed live as
        # the actual cause of a "Not Yet Released" report that survived a correctly-
        # firing clear_if_updated() and a correctly-completing background refresh
        # from the OTHER (lock-winning) instance — this one just never heard about
        # it. _push_from_other_instance below is this instance's own independent
        # path to the same fresh data: wait for the winning instance's lock file to
        # go away, then re-read the shared data_file it wrote, rather than relying
        # on state only the winner ever populates.
        xbmc.log('[Starfleet/Home] refresh lock held by another instance, skipping', xbmc.LOGINFO)
        refresh_done.set()

    if is_new_version:
        # On first run / update, write version immediately and open home with
        # whatever cache exists (or empty). Background refresh pushes data when ready.
        try:
            with open(version_file, 'w') as _f:
                _f.write(current_ver)
        except Exception:
            pass

    if True:  # shared cache-load block for both new and existing versions
        # Normal launch — load from cache instantly so the window is non-empty
        try:
            with open(data_file, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            if isinstance(raw, list):
                contexts['default'] = raw
                contexts['movies']  = raw
                contexts['tv']      = raw
            else:
                for k, v in raw.items():
                    contexts[k] = v
            d = contexts.get('default', empty)
            xbmc.log('[Starfleet/Home] loaded %d/%d/%d/%d films from cache' % (
                len(d[0]), len(d[1]), len(d[2]), len(d[3]) if len(d) > 3 else 0), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Home] no cache yet (%s)' % e, xbmc.LOGINFO)

        # If cache is empty, wait for the background refresh to finish before
        # opening the window — otherwise the home screen shows empty carousels.
        d = contexts.get('default', empty)
        if not any(row for row in d if row):
            xbmc.log('[Starfleet/Home] cache empty — waiting for background refresh', xbmc.LOGINFO)
            refresh_done.wait(timeout=45)
            if refresh_result[0] is not None:
                contexts = refresh_result[0]

    # If refresh finished during the splash, use the fresh data right away
    if refresh_result[0] is not None:
        contexts = refresh_result[0]

    try:
        from resources.lib.gui.home import HomeWindow
        _window_closed = threading.Event()
        from resources.lib.gui.home import layout_xml
        try:
            _mode = xbmcaddon.Addon('plugin.video.starfleet').getSetting('home_layout')
        except Exception:
            _mode = '0'
        win = HomeWindow(layout_xml(_mode), addon_path, 'Default', '1080i',
                         contexts=contexts, close_event=_window_closed)

        # If refresh is still running, push data into window when it finishes.
        def _push_when_ready():
            for _ in range(120):
                if _window_closed.is_set():
                    return
                if refresh_done.wait(timeout=1):
                    break
            if _window_closed.is_set():
                return
            if refresh_result[0] is not None:
                try:
                    # Re-check right before touching the window — a nav click
                    # can land in the gap between the check above and here
                    # (confirmed live: getControl() on an already-closing
                    # window threw "Non-Existent Control 100" in exactly
                    # this spot). Narrows the race further; home.py's _nav()
                    # also now sets this event as its very first action to
                    # shrink the window from the other side too.
                    if _window_closed.is_set():
                        return
                    win._contexts = refresh_result[0]
                    win._apply_context(win._current_ctx)
                    xbmc.log('[Starfleet/Home] pushed fresh data to live window', xbmc.LOGINFO)
                except Exception as _pe:
                    xbmc.log('[Starfleet/Home] push error: %s' % _pe, xbmc.LOGWARNING)
            if _window_closed.is_set():
                return
            try:
                win.setProperty('sf_loaded', '1')
            except Exception:
                pass

        def _push_from_other_instance():
            """This instance lost the refresh-lock race (got_lock was False) —
            refresh_result[0]/refresh_done are meaningless here, only ever
            populated by THIS instance's own _refresh(), which never ran. Wait
            for the winning instance's lock file to disappear (it releases it
            in _refresh()'s own finally block), then re-read the shared
            data_file it wrote, same parsing as the initial cache-load above.
            Bounded to ~90s so a crashed winner (stale lock) doesn't hang this
            thread forever — same case _acquire_lock() already treats as
            stealable."""
            import time as _time
            for _ in range(90):
                if _window_closed.is_set():
                    return
                if not os.path.exists(lock_file):
                    break
                _time.sleep(1)
            if _window_closed.is_set():
                return
            try:
                with open(data_file, 'r', encoding='utf-8') as f:
                    raw = json.load(f)
                if isinstance(raw, list):
                    fresh = {'default': raw, 'movies': raw, 'tv': raw}
                else:
                    fresh = raw
                if _window_closed.is_set():
                    return
                win._contexts = fresh
                win._apply_context(win._current_ctx)
                xbmc.log('[Starfleet/Home] pushed fresh data from other instance\'s refresh',
                          xbmc.LOGINFO)
            except Exception as _pe:
                xbmc.log('[Starfleet/Home] push-from-other-instance error: %s' % _pe,
                          xbmc.LOGWARNING)

        if not refresh_done.is_set():
            threading.Thread(target=_push_when_ready, daemon=True).start()
        else:
            if not got_lock:
                threading.Thread(target=_push_from_other_instance, daemon=True).start()
            try:
                win.setProperty('sf_loaded', '1')
            except Exception:
                pass

        # Use show() instead of doModal() so the window is NOT a modal dialog.
        # doModal() sets Kodi's modal flag which causes ActivateWindow to be
        # refused with "active modal dialogs".  show() puts the window on the
        # stack as a normal full-screen window — ActivateWindow works, and
        # pressing Back from any section returns here automatically.
        # Show Home and make sure it really landed. show() is refused ("Activate of window refused because there are active modal
        # dialogs") while a busy spinner is up, and one is up right after Home closed itself for a relaunch (a Layout or profile
        # change): Kodi falls back to its own Videos list, which loads this add-on's folder behind a busy dialog. So wait for the
        # dialogs to go, close what is left, and try again until a Home window (ids from 13000) is the one on screen.
        _mon0 = xbmc.Monitor()
        _landed = False
        for _try in range(8):
            for _w in range(40):                                       # up to ~8 s for busy / modal dialogs to finish
                if not xbmc.getCondVisibility('System.HasModalDialog | Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)'):
                    break
                if _mon0.waitForAbort(0.2):
                    break
            if xbmc.getCondVisibility('System.HasModalDialog | Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)'):
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.sleep(300)
            win.show()
            xbmc.sleep(500)
            if xbmcgui.getCurrentWindowId() >= 13000:
                _landed = True
                break
            xbmc.log('[Starfleet/Home] show() did not land (window %s) - try %d' % (xbmcgui.getCurrentWindowId(), _try + 1), xbmc.LOGWARNING)
        if not _landed:
            xbmc.log('[Starfleet/Home] Home could not be shown', xbmc.LOGERROR)

        # Keep the script alive while the window is visible.  _window_closed is
        # set by onAction() when the user presses Back/Escape on the home screen.
        _monitor = xbmc.Monitor()
        while not _window_closed.is_set():
            if _monitor.waitForAbort(0.5):
                break

        try:
            win._stop_trailer()
        except Exception:
            pass
        win.close()
        _window_closed.set()   # ensure _push_when_ready exits
        try:
            os.remove(window_lock)
        except Exception:
            pass
    except Exception as e:
        try:
            os.remove(window_lock)
        except Exception:
            pass
        xbmc.log('[Starfleet/Home] window error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
