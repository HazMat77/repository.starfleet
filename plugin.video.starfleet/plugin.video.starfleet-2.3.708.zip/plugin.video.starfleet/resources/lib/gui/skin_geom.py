# -*- coding: utf-8 -*-
"""Cursor geometry of the Home skins (written by StarfleetSkinGen/gen_skins.py; do not edit by hand)."""
GEOM = {'Enterprise': {'row_left': 150, 'row_top': 610, 'item_w': 227, 'inset': 0, 'border': 6, 'max_pos': 6}}
