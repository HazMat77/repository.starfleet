# -*- coding: utf-8 -*-
"""
resources/lib/listinfo.py - Starfleet Kodi Plugin
Fills a ListItem through the InfoTag setters (Kodi 20+). ListItem.setInfo() is deprecated and Kodi 22 logs a warning for every
call; this helper takes the same (type, dict) arguments, so existing call sites only change their spelling:

    li.setInfo('video', {...})   ->   set_info(li, 'video', {...})

Any key the helper does not know, or any value a setter rejects, sends the whole call to the old setInfo() so nothing is ever
lost; the result is the same on Kodi 21 and Kodi 22.
"""

import xbmc
import xbmcgui


def new_item(*args, **kwargs):
    """xbmcgui.ListItem(...) for plugin directory listings: offscreen=True skips the GUI lock Kodi otherwise takes for every item
    (Kodi 19+, faster on long lists; the same on Kodi 21 and 22)."""
    kwargs.setdefault('offscreen', True)
    return xbmcgui.ListItem(*args, **kwargs)


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _split(v):
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v if x]
    return [x.strip() for x in str(v or '').replace(' / ', ',').split(',') if x.strip()]


def _cast(tag, v):
    tag.setCast([xbmc.Actor(str(c)) for c in (v or []) if c])


# key -> function(tag, value); every setter used here exists in Kodi 20 and later
_VIDEO = {
    'title':         lambda t, v: t.setTitle(str(v or '')),
    'originaltitle': lambda t, v: t.setOriginalTitle(str(v or '')),
    'sorttitle':     lambda t, v: t.setSortTitle(str(v or '')),
    'plot':          lambda t, v: t.setPlot(str(v or '')),
    'plotoutline':   lambda t, v: t.setPlotOutline(str(v or '')),
    'tagline':       lambda t, v: t.setTagLine(str(v or '')),
    'mpaa':          lambda t, v: t.setMpaa(str(v or '')),
    'mediatype':     lambda t, v: t.setMediaType(str(v or '')),
    'year':          lambda t, v: t.setYear(_int(v)),
    'season':        lambda t, v: t.setSeason(_int(v)),
    'episode':       lambda t, v: t.setEpisode(_int(v)),
    'duration':      lambda t, v: t.setDuration(_int(v)),
    'playcount':     lambda t, v: t.setPlaycount(_int(v)),
    'rating':        lambda t, v: t.setRating(float(v or 0)),
    'imdbnumber':    lambda t, v: t.setIMDBNumber(str(v or '')),
    'tvshowtitle':   lambda t, v: t.setTvShowTitle(str(v or '')),
    'aired':         lambda t, v: t.setFirstAired(str(v or '')),
    'premiered':     lambda t, v: t.setPremiered(str(v or '')),
    'trailer':       lambda t, v: t.setTrailer(str(v or '')),
    'dateadded':     lambda t, v: t.setDateAdded(str(v or '')),
    'lastplayed':    lambda t, v: t.setLastPlayed(str(v or '')),
    'genre':         lambda t, v: t.setGenres(_split(v)),
    'studio':        lambda t, v: t.setStudios(_split(v)),
    'country':       lambda t, v: t.setCountries(_split(v)),
    'director':      lambda t, v: t.setDirectors(_split(v)),
    'writer':        lambda t, v: t.setWriters(_split(v)),
    'cast':          _cast,
}

_MUSIC = {
    'title':   lambda t, v: t.setTitle(str(v or '')),
    'comment': lambda t, v: t.setComment(str(v or '')),
    'artist':  lambda t, v: t.setArtist(str(v or '')),
    'album':   lambda t, v: t.setAlbum(str(v or '')),
    'genre':   lambda t, v: t.setGenres(_split(v)),
}


def set_info(li, kind, info):
    """Same arguments as ListItem.setInfo(kind, info)."""
    info = info or {}
    table = _MUSIC if kind == 'music' else _VIDEO if kind == 'video' else None
    try:
        if table is not None and all(k in table for k in info):
            tag = li.getMusicInfoTag() if kind == 'music' else li.getVideoInfoTag()
            for k, v in info.items():
                table[k](tag, v)
            return
    except Exception:
        pass
    li.setInfo(kind, info)
