# -*- coding: utf-8 -*-
"""
resources/lib/free_sources.py

Free streaming site catalog scrapers.

Sites:
  BounceTV      ? bouncetv.com  ? HTML scrapable. TV shows only.
  Popcornflix   ? popcornflix.com ? JS-rendered, use TMDB browse with site reference
  Fawesome       ? fawesome.tv   ? JS-rendered, use TMDB browse with site reference
  Filmzie        ? filmzie.com   ? JS-rendered, use TMDB browse with site reference
  Midnight Pulp  ? midnightpulp.com ? JS-rendered
  DistroTV       ? distro.tv     ? FAST channels, JS-rendered
  Radial Ent.    ? radialentertainment.com ? JS-rendered

For JS-rendered sites, we provide a catalogue of their known content categories
(comedy, horror, etc.) backed by TMDB discovery, with the site listed as a
free streaming reference source in the play dialog.

BounceTV returns actual show listings for TMDB lookup.
"""

import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
}

_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
    return _session

def _get(url, timeout=10):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


# ?? Free streaming service registry ??????????????????????????????????????????

# Each entry: id, label, icon_url, media_type ('movies'|'tv'|'both'), scrapable
FREE_SERVICES = [
    {
        'id':         'archive',
        'label':      'Internet Archive (Public Domain)',
        'icon':       'https://archive.org/images/glogo.png',
        'media_type': 'movies',
        'scrapable':  True,
        'url':        'https://archive.org/details/feature_films',
    },
    {
        'id':         'popcornflix',
        'label':      'Popcornflix',
        'icon':       'https://www.popcornflix.com/favicon.ico',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://www.popcornflix.com',
    },
    {
        'id':         'fawesome',
        'label':      'Fawesome',
        'icon':       'https://fawesome.tv/favicon.ico',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://fawesome.tv',
    },
    {
        'id':         'filmzie',
        'label':      'Filmzie',
        'icon':       'https://filmzie.com/favicon.ico',
        'media_type': 'movies',
        'scrapable':  False,
        'url':        'https://filmzie.com',
    },
    {
        'id':         'midnightpulp',
        'label':      'Midnight Pulp',
        'icon':       'https://www.midnightpulp.com/favicon.ico',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://www.midnightpulp.com',
    },
    {
        'id':         'distrotv',
        'label':      'DistroTV',
        'icon':       'https://www.distro.tv/favicon.ico',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://www.distro.tv',
    },
    {
        'id':         'bouncetv',
        'label':      'BounceTV',
        'icon':       'https://www.bouncetv.com/favicon.ico',
        'media_type': 'tv',
        'scrapable':  True,
        'url':        'https://www.bouncetv.com',
    },
    {
        'id':         'radial',
        'label':      'Radial Entertainment',
        'icon':       'https://www.radialentertainment.com/favicon.ico',
        'media_type': 'movies',
        'scrapable':  False,
        'url':        'https://www.radialentertainment.com',
    },
]


def get_free_services(media_type=None):
    """Return list of free service dicts, optionally filtered by media_type."""
    if media_type is None:
        return FREE_SERVICES
    return [s for s in FREE_SERVICES if s['media_type'] in (media_type, 'both')]


# ?? BounceTV scraper ??????????????????????????????????????????????????????????

BOUNCE_BASE = 'https://www.bouncetv.com'

_RE_BOUNCE_SHOW = re.compile(
    r'href="(/show/([a-z0-9][a-z0-9-]+)/(\d+))"',
    re.IGNORECASE
)
_RE_BOUNCE_THUMB = re.compile(
    r'<img[^>]+(?:data-src|src)="(https://storage\.googleapis\.com/[^"]+)"[^>]+alt="([^"]+)"',
    re.IGNORECASE
)


def get_bouncetv_shows():
    """
    Scrape BounceTV show listings.
    Returns list of: {'id', 'slug', 'title', 'thumb', 'url'}
    """
    ck = 'free_bouncetv_shows'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html  = _get(BOUNCE_BASE + '/shows')
        shows = []
        seen  = set()

        # Match show links
        for m in _RE_BOUNCE_SHOW.finditer(html):
            path, slug, show_id = m.group(1), m.group(2), m.group(3)
            if show_id in seen:
                continue
            seen.add(show_id)

            # Find thumbnail near this link
            block = html[m.start():m.start() + 400]
            im    = _RE_BOUNCE_THUMB.search(block)
            thumb = im.group(1) if im else ''
            title = slug.replace('-', ' ').title()

            shows.append({
                'id':    show_id,
                'slug':  slug,
                'title': title,
                'thumb': thumb,
                'url':   BOUNCE_BASE + path,
            })

        _cache.set(ck, shows, 6 * 3600)
        xbmc.log('[Starfleet/Free] BounceTV: %d shows' % len(shows), xbmc.LOGINFO)
        return shows
    except Exception as e:
        xbmc.log('[Starfleet/Free] BounceTV error: %s' % e, xbmc.LOGERROR)
        return []


# ?? TMDB-backed show/movie list for non-scrapable sites ??????????????????????

def get_free_movies_tmdb(genre_id=None, page=1):
    """
    Return popular free-tier friendly movies from TMDB.
    Used to populate Popcornflix, Fawesome, Filmzie etc.
    """
    from resources.lib import metadata as meta
    try:
        if genre_id:
            return meta.get_movies_by_genre(genre_id, page=page)
        return meta.get_movies_popular(page=page)
    except Exception as e:
        xbmc.log('[Starfleet/Free] TMDB movies error: %s' % e, xbmc.LOGWARNING)
        return []


def get_free_tv_tmdb(genre_id=None, page=1):
    """Return popular free-tier friendly TV shows from TMDB."""
    from resources.lib import metadata as meta
    try:
        if genre_id:
            return meta.get_tv_by_genre(genre_id, page=page)
        return meta.get_tv_popular(page=page)
    except Exception as e:
        xbmc.log('[Starfleet/Free] TMDB tv error: %s' % e, xbmc.LOGWARNING)
        return []


# ?? Popcornflix API ???????????????????????????????????????????????????????????
# Backend: rapi.ifood.tv (FutureToday shared backend)
# siteId=1518 = Popcornflix web; platform_id=1217575 = PLATFORM_WEBSITE

_PCF_RAPI   = 'http://rapi.ifood.tv'
_PCF_PARAMS = (
    'appId=9&siteId=1518&platform_id=1217575&deviceId=starfleet'
    '&apiEnv=production&session-id=0&auth-token=1217575'
    '&gridstyle=flat-movie&keys='
)


def get_popcornflix_movies(page=1):
    """
    Return movies from Popcornflix with direct HLS stream URLs.
    Uses the rapi.ifood.tv backend ? stream URLs are in the listing response.
    """
    ck = 'free_pcf_movies_p%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    per_page = 20
    start    = (page - 1) * per_page
    url = (
        '%s/recipes.php?searchType=popular&%s'
        '&max-results=%d&start-index=%d&country=CA'
        % (_PCF_RAPI, _PCF_PARAMS, per_page, start)
    )

    try:
        r = _sess().get(url, timeout=12)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Free] Popcornflix list error: %s' % e, xbmc.LOGERROR)
        return []

    if data.get('status') != 'ok':
        xbmc.log('[Starfleet/Free] Popcornflix API: %s' % data.get('data', {}).get('description', ''), xbmc.LOGWARNING)
        return []

    items = []
    for m in (data.get('results') or []):
        title = m.get('title') or ''
        if not title:
            continue

        # Stream URL ? HLS preferred, fallback to MP4
        hls = m.get('video_hls_url') or m.get('video_url') or ''

        items.append({
            'title':      title,
            'year':       str(m.get('year') or ''),
            'plot':       (m.get('description') or '')[:300],
            'thumb':      m.get('main_picture') or m.get('picture') or '',
            'fanart':     '',
            'rating':     str(m.get('rating_average') or ''),
            'tmdb_id':    '',
            'archive_id': '',
            'stream_url': hls,
            'pcf_id':     str(m.get('node_id') or ''),
        })

    _cache.set(ck, items, 1800)
    xbmc.log('[Starfleet/Free] Popcornflix: %d movies (page %d)' % (len(items), page), xbmc.LOGINFO)
    return items


# ?? Internet Archive public domain movies ?????????????????????????????????????

_ARCHIVE_SEARCH = (
    'https://archive.org/advancedsearch.php'
    '?q=collection%%3Afeature_films+mediatype%%3Amovies'
    '&fl[]=identifier,title,description,year'
    '&output=json&rows=20&sort[]=downloads+desc&page=%d'
)

_ARCHIVE_META = 'https://archive.org/metadata/%s'
_ARCHIVE_IMG  = 'https://archive.org/services/img/%s'
_ARCHIVE_DL   = 'https://archive.org/download/%s/%s'


def get_archive_movies(page=1):
    """
    Return public domain feature films from archive.org with direct playback.
    Each item has 'archive_id' set so free_play can resolve the MP4 URL.
    """
    ck = 'free_archive_p%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        r = _sess().get(_ARCHIVE_SEARCH % page, timeout=12)
        r.raise_for_status()
        docs = r.json().get('response', {}).get('docs', [])
    except Exception as e:
        xbmc.log('[Starfleet/Free] Archive.org search error: %s' % e, xbmc.LOGERROR)
        return []

    items = []
    for doc in docs:
        ident = doc.get('identifier', '')
        if not ident:
            continue
        title = doc.get('title') or ident.replace('_', ' ').replace('-', ' ').title()
        year  = str(doc.get('year', '') or '')
        plot  = doc.get('description', '')
        if isinstance(plot, list):
            plot = ' '.join(plot)
        # Strip HTML tags from description
        plot = _RE_STRIP.sub(' ', plot or '').strip()

        items.append({
            'title':      title,
            'year':       year,
            'plot':       plot[:300] if plot else '',
            'thumb':      _ARCHIVE_IMG % ident,
            'fanart':     '',
            'rating':     '',
            'tmdb_id':    '',
            'archive_id': ident,
        })

    _cache.set(ck, items, 3600)
    xbmc.log('[Starfleet/Free] Archive.org: %d movies (page %d)' % (len(items), page), xbmc.LOGINFO)
    return items


def resolve_archive_stream(archive_id):
    """
    Fetch archive.org item metadata and return direct MP4 URL.
    Returns empty string on failure.
    """
    try:
        r = _sess().get(_ARCHIVE_META % archive_id, timeout=12)
        r.raise_for_status()
        files = r.json().get('files', [])
    except Exception as e:
        xbmc.log('[Starfleet/Free] Archive.org metadata error (%s): %s' % (archive_id, e), xbmc.LOGERROR)
        return ''

    # Prefer 512kb (smaller/faster) MP4, then any MP4, then any video
    mp4_files = [f for f in files if f.get('format', '').upper() in ('MPEG4', 'H.264')]
    if not mp4_files:
        mp4_files = [f for f in files if f.get('name', '').lower().endswith('.mp4')]

    if not mp4_files:
        return ''

    # Pick smallest/most compatible — prefer files ending in .mp4 that aren't .thumbs
    chosen = None
    for f in mp4_files:
        name = f.get('name', '')
        if '.thumbs' in name or name.endswith('.jpg'):
            continue
        if chosen is None:
            chosen = f
        # Prefer 512kb version
        elif '512' in name and '512' not in (chosen.get('name') or ''):
            chosen = f

    if not chosen:
        return ''

    return _ARCHIVE_DL % (archive_id, chosen['name'])


# ── Title-based stream search ─────────────────────────────────────────────────

import unicodedata

def _norm_title(t):
    """Normalise title for comparison: lowercase, strip accents, alphanumeric only."""
    t = t.lower()
    t = ''.join(c for c in unicodedata.normalize('NFD', t)
                if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9 ]', '', t).strip()


def _title_score(query_norm, candidate_norm):
    """Word-overlap score 0..1 between normalised title strings."""
    q = set(query_norm.split())
    c = set(candidate_norm.split())
    if not q:
        return 0.0
    return len(q & c) / max(len(q), len(c))


# Popcornflix search via their public API (Screen Media)
_PCF_SEARCH_URLS = [
    lambda title: (
        'https://www.popcornflix.com/api/popcornflix/v4/search?searchString=%s&platform=web'
        % (_req.utils.quote(title) if _req else title)
    ),
    lambda title: (
        'https://popcornflix.com/api/search?q=%s'
        % (_req.utils.quote(title) if _req else title)
    ),
]


def search_popcornflix(title, media_type='movie'):
    """
    Search Popcornflix by title. Tries multiple API endpoints in order.
    Returns list of {'label', 'url', 'source'} for matched items.
    """
    norm_q = _norm_title(title)
    data = None

    for url_fn in _PCF_SEARCH_URLS:
        try:
            url = url_fn(title)
            r = _sess().get(url, timeout=10)
            r.raise_for_status()
            data = r.json()
            if data and (data.get('results') or data.get('items') or data.get('data')):
                break
        except Exception as e:
            xbmc.log('[Starfleet/Free] Popcornflix endpoint failed: %s' % e, xbmc.LOGWARNING)
            data = None
            continue

    if not data:
        return []

    # Handle different response shapes
    entries = data.get('results') or data.get('items') or data.get('data') or []
    results = []
    for m in entries:
        t = m.get('title', '') or m.get('name', '')
        if not t:
            continue
        if _title_score(norm_q, _norm_title(t)) < 0.5:
            continue
        stream = m.get('video_hls_url') or m.get('video_url') or m.get('streamUrl', '')
        if not stream:
            continue
        year = str(m.get('year', '') or m.get('releaseYear', '') or '')
        label = '[FREE] Popcornflix — %s%s' % (t, ' (%s)' % year if year else '')
        results.append({'label': label, 'url': stream, 'source': 'popcornflix'})

    xbmc.log('[Starfleet/Free] Popcornflix search "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── Tubi TV ───────────────────────────────────────────────────────────────────
# Tubi is the largest free AVOD service. Their content API is accessible
# without authentication for metadata. Stream URLs are HLS manifests.

_TUBI_SEARCH   = 'https://tubitv.com/oz/row/search?q=%s&type=%s&platform=web'
_TUBI_VOD      = 'https://tubitv.com/api/usercontents/retrieve_vod/%s?devicetype=web'
_TUBI_HEADERS  = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json',
    'Referer': 'https://tubitv.com/',
}


def _tubi_stream_url(content_id):
    """Try to get a playable HLS URL from Tubi for a content_id."""
    try:
        r = _sess().get(_TUBI_VOD % content_id, headers=_TUBI_HEADERS, timeout=10)
        if r.status_code != 200:
            return ''
        data = r.json()
        # Response has video_resources list with manifest URLs
        resources = data.get('video_resources') or []
        for res in resources:
            url = res.get('manifest', {}).get('url', '') or res.get('url', '')
            if url and ('.m3u8' in url or '.mp4' in url):
                return url
    except Exception:
        pass
    return ''


def search_tubi(title, media_type='movie'):
    """
    Search Tubi TV by title. Returns list of {'label', 'url', 'source'}.
    media_type: 'movie' or 'tv'
    """
    norm_q = _norm_title(title)
    tubi_type = 'movie' if media_type != 'tv' else 'tv_movie'
    try:
        from urllib.parse import quote as _q
        url = _TUBI_SEARCH % (_q(title), tubi_type)
        r = _sess().get(url, headers=_TUBI_HEADERS, timeout=12)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Free] Tubi search error: %s' % e, xbmc.LOGWARNING)
        return []

    results_raw = data.get('results') or data.get('data') or []
    # Tubi sometimes nests under a key matching the type
    if isinstance(results_raw, dict):
        results_raw = results_raw.get('movies') or results_raw.get('series') or []

    results = []
    for item in results_raw[:10]:
        t = item.get('title', '') or item.get('name', '')
        if not t or _title_score(norm_q, _norm_title(t)) < 0.5:
            continue
        content_id = str(item.get('id', '') or item.get('content_id', ''))
        if not content_id:
            continue

        stream_url = _tubi_stream_url(content_id)
        if not stream_url:
            continue

        year = str(item.get('year', '') or item.get('release_year', '') or '')
        label = '[FREE] Tubi — %s%s' % (t, ' (%s)' % year if year else '')
        results.append({'label': label, 'url': stream_url, 'source': 'tubi'})

    xbmc.log('[Starfleet/Free] Tubi search "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


_ARCHIVE_TITLE_SEARCH = (
    'https://archive.org/advancedsearch.php'
    '?q=title%%3A%%22%s%%22+collection%%3Afeature_films+mediatype%%3Amovies'
    '&fl[]=identifier,title,year&output=json&rows=5&sort[]=downloads+desc&page=1'
)


def search_archive(title):
    """
    Search Archive.org for a specific movie title.
    Returns list of {'label', 'url', 'source'} — url is 'archive://IDENTIFIER'.
    Caller must call resolve_archive_stream(identifier) to get a playable URL.
    """
    import requests as _r
    norm_q = _norm_title(title)
    try:
        url = _ARCHIVE_TITLE_SEARCH % _r.utils.quote(title)
        r = _sess().get(url, timeout=12)
        r.raise_for_status()
        docs = r.json().get('response', {}).get('docs', [])
    except Exception as e:
        xbmc.log('[Starfleet/Free] Archive search error: %s' % e, xbmc.LOGWARNING)
        return []

    results = []
    for doc in docs:
        ident = doc.get('identifier', '')
        t = doc.get('title', '') or ident.replace('_', ' ')
        if not ident:
            continue
        if _title_score(norm_q, _norm_title(t)) < 0.4:
            continue
        year = str(doc.get('year', '') or '')
        label = '[FREE] Archive.org — %s%s' % (t, ' (%s)' % year if year else '')
        results.append({'label': label, 'url': 'archive://' + ident, 'source': 'archive'})

    xbmc.log('[Starfleet/Free] Archive search "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


def search_free_streams(title, year=None, media_type='movie'):
    """
    Search all scrapable free sources for a given title in parallel.
    Returns list of {'label', 'url', 'source'}.
    Works for movies, TV shows (pass show+episode title), and adult content.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    tasks = {
        'popcornflix': lambda: search_popcornflix(title, media_type),
        'tubi':        lambda: search_tubi(title, media_type),
    }
    # Archive only makes sense for movies (it's a public-domain feature film catalog)
    if media_type in ('movie',):
        tasks['archive'] = lambda: search_archive(title)

    results = []
    with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        for future in as_completed(futures, timeout=22):
            try:
                results.extend(future.result())
            except Exception as e:
                xbmc.log('[Starfleet/Free] %s search failed: %s' % (futures[future], e),
                         xbmc.LOGWARNING)
    return results
