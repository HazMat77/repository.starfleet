"""
Starfleet Home Window.
Data is pre-loaded before doModal() so onInit populates on the GUI thread safely.
"""
import xbmc
import xbmcgui
import xbmcaddon

try:
    _ADDON = xbmcaddon.Addon('plugin.video.starfleet')
except Exception:
    _ADDON = None

_ID_PLAY    = 20
_ID_INFO    = 21
_ID_NAV_MOV = 41
_ID_NAV_TV  = 42
_ID_NAV_SPT = 43
_ID_NAV_LIV = 44
_ID_NAV_ADU = 45
_ID_ROW0    = 100
_ID_ROW1    = 200
_ID_ROW2    = 300

_ROW_LABELS = ['New Releases', 'Popular', 'Trending']


class HomeWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        self._film_rows  = kwargs.pop('film_rows', [[], [], []])
        self._hero_row   = 0
        self._hero_pos   = 0
        super(HomeWindow, self).__init__(*args, **kwargs)

    # ---------------------------------------------------------------- lifecycle

    def onInit(self):
        try:
            # Set row labels
            for i, lbl in enumerate(_ROW_LABELS):
                self.setProperty('sf_row%d_label' % i, lbl)

            # Populate all three carousels — safe here (GUI thread)
            self._populate_carousels()

            # Set hero from first film
            if self._film_rows and self._film_rows[0]:
                self._set_hero(self._film_rows[0][0])
            else:
                self.setProperty('sf_hero_title', 'No content available')

        except Exception as e:
            xbmc.log('[Starfleet/Home] onInit: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                   xbmcgui.ACTION_STOP, xbmcgui.ACTION_PARENT_DIR):
            self.close()
        elif aid in (xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT,
                     xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN):
            self._update_hero_from_focus()

    def _update_hero_from_focus(self):
        try:
            rmap = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2}
            cid  = self.getFocusId()
            if cid in rmap:
                row   = rmap[cid]
                ctrl  = self.getControl(cid)
                pos   = ctrl.getSelectedPosition()
                films = self._film_rows[row] if row < len(self._film_rows) else []
                if films and 0 <= pos < len(films):
                    self._hero_row = row
                    self._hero_pos = pos
                    self._set_hero(films[pos])
        except Exception:
            pass

    def onClick(self, cid):
        try:
            if cid == _ID_PLAY:
                self._play_hero()
            elif cid == _ID_INFO:
                self._show_info()
            elif cid == _ID_NAV_MOV:
                self._nav('main_menu_movies')
            elif cid == _ID_NAV_TV:
                self._nav('main_menu_tv')
            elif cid == _ID_NAV_SPT:
                self._nav('main_menu_sports')
            elif cid == _ID_NAV_LIV:
                self._nav('live_menu')
            elif cid == _ID_NAV_ADU:
                self._nav('adult_movies_library')
            elif cid in (_ID_ROW0, _ID_ROW1, _ID_ROW2):
                self._play_row_item(cid)
        except Exception as e:
            xbmc.log('[Starfleet/Home] onClick %d: %s' % (cid, e), xbmc.LOGERROR)

    def onFocus(self, cid):
        self._update_hero_from_focus()

    # ---------------------------------------------------------------- populate

    def _populate_carousels(self):
        for row_idx, list_id in enumerate([_ID_ROW0, _ID_ROW1, _ID_ROW2]):
            films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
            ctrl  = self.getControl(list_id)
            ctrl.reset()
            for film in films:
                li = xbmcgui.ListItem(label=film.get('title', ''))
                li.setArt({
                    'thumb':  film.get('thumb', ''),
                    'fanart': film.get('fanart', film.get('thumb', '')),
                })
                li.setProperty('film_id',     str(film.get('id', '')))
                li.setProperty('film_url',    film.get('url', ''))
                li.setProperty('film_source', film.get('source', 'afdb'))
                li.setProperty('film_slug',   film.get('slug', ''))
                ctrl.addItem(li)
            xbmc.log('[Starfleet/Home] row %d: %d items added' % (row_idx, len(films)), xbmc.LOGINFO)

    def _set_hero(self, film):
        title   = film.get('title', '')
        year    = str(film.get('year', ''))
        rating  = str(film.get('rating', ''))
        runtime = str(film.get('runtime', ''))
        meta    = '  |  '.join(p for p in [year, rating, runtime] if p)
        self.setProperty('sf_hero_title',  title)
        self.setProperty('sf_hero_meta',   meta)
        self.setProperty('sf_hero_plot',   film.get('plot', film.get('description', '')))
        self.setProperty('sf_hero_fanart', film.get('fanart', film.get('thumb', '')))
        self.setProperty('sf_hero_badge',  film.get('source', 'AFDB').upper())

    # ---------------------------------------------------------------- actions

    def _play_hero(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        pos = self._hero_pos if self._hero_pos < len(films) else 0
        self.close()
        self._play_film(films[pos])

    def _play_row_item(self, cid):
        rmap = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2}
        row  = rmap[cid]
        try:
            ctrl  = self.getControl(cid)
            pos   = ctrl.getSelectedPosition()
            films = self._film_rows[row] if row < len(self._film_rows) else []
            if films and 0 <= pos < len(films):
                self.close()
                self._play_film(films[pos])
        except Exception as e:
            xbmc.log('[Starfleet/Home] _play_row_item: %s' % e, xbmc.LOGERROR)

    def _play_film(self, film):
        import urllib.parse as _up
        source  = film.get('source', 'tmdb')
        slug    = film.get('slug', '')
        film_id = str(film.get('id', film.get('tmdb_id', '')))
        url     = film.get('url', '')
        title   = _up.quote(film.get('title', ''))
        if source == 'tmdb':
            tmdb_id = str(film.get('tmdb_id', film_id))
            year    = _up.quote(str(film.get('year', '')))
            cmd = "RunPlugin(plugin://plugin.video.starfleet/?action=meta_movie_play&tmdb_id=%s&title=%s&year=%s)" % (tmdb_id, title, year)
        elif source == 'pandamovies':
            cmd = "RunPlugin(plugin://plugin.video.starfleet/?action=adult_panda_play&slug=%s&film_url=%s&title=%s)" % (slug, url, title)
        elif source == 'hqporner':
            cmd = "RunPlugin(plugin://plugin.video.starfleet/?action=adult_hqp_play&slug=%s&film_url=%s&title=%s)" % (slug, url, title)
        elif source in ('freeomovie','xxxmoviestream','pornwatch','watchpornfree','speedporn','xxxscenes','xmovix'):
            cmd = "RunPlugin(plugin://plugin.video.starfleet/?action=adult_stream_sources&film_id=%s&film_url=%s&title=%s)" % (film_id, url, title)
        else:
            cmd = "RunPlugin(plugin://plugin.video.starfleet/?action=afdb_play_search&film_id=%s&film_slug=%s&film_title=%s)" % (film_id, slug, title)
        xbmc.executebuiltin(cmd)

    def _show_info(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        film = films[self._hero_pos] if self._hero_pos < len(films) else films[0]
        xbmcgui.Dialog().textviewer(
            film.get('title', 'Info'),
            film.get('plot', film.get('description', 'No description available.'))
        )

    def _nav(self, action):
        self.close()
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=%s)' % action)
