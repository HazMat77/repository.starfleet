"""
Standalone script entry point for the Starfleet Home GUI window.
Called via xbmc.executebuiltin('RunScript(...)') so it runs in its own
Python invoker thread — safe to call doModal() here.
"""
import sys
import os
import xbmcaddon
import xbmc

def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    # Ensure addon root is on sys.path so package imports resolve
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)
    try:
        from resources.lib.gui.home import HomeWindow
        win = HomeWindow('Starfleet-Home.xml', addon_path, 'Default', '1080i')
        win.doModal()
        del win
    except Exception as e:
        xbmc.log('[Starfleet/Home] run_home error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

if __name__ == '__main__':
    main()
