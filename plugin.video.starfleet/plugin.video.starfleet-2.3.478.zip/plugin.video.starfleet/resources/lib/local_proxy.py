# -*- coding: utf-8 -*-
"""
resources/lib/local_proxy.py — a tiny loopback-only HTTP relay built to
close the real, live-confirmed gap behind OK.ru replays failing to play
(see sports_router._resolve_okru's own docstring for the tamper test that
proved it): okcdn.ru signs its CDN URLs with a `srcIp=<ip>` query param it
actively validates server-side. The metadata call that obtains that signed
URL runs through this addon's own Python `requests` session, but the
ACTUAL video fetch was being handed to Kodi's player to make on its own,
through a completely separate network stack (inputstream.ffmpegdirect's
own cURL/ffmpeg layer). Confirmed live those two calls, though seconds
apart on the same physical device, can go out under different apparent
public IPs on some networks (VPN, CGNAT, per-connection IP rotation) —
okcdn.ru then rejects the second one even though the first succeeded.

This relay collapses that gap instead of continuing to guess at it: Kodi's
player is handed a plain http://127.0.0.1:<port>/relay?... URL, so the only
network stack Kodi's side ever touches is loopback. The real upstream fetch
to okcdn.ru happens here, using the exact same requests library/process
that resolved the signed URL a moment earlier, and the response is streamed
straight back to the player. Same process end-to-end removes the
"different network stack, possibly different egress IP" variable entirely
instead of trusting Kodi's own player to reproduce it correctly.

Deliberately minimal — one route, GET-only, Range-header passthrough for
seeking, no attempt at a general-purpose proxy. If the server can't start
for any reason (port bind failure, module unavailable), build_relay_url()
raises and callers fall back to the pre-existing direct-URL behavior, so
this can't make anything worse than before it existed.
"""
import threading
import xbmc

_server = None
_port = None
_lock = threading.Lock()


def _find_free_port():
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _ensure_server():
    global _server, _port
    with _lock:
        if _server is not None:
            return _port

        import http.server
        import requests as _req

        class _Handler(http.server.BaseHTTPRequestHandler):
            # HTTP/1.0, not 1.1: this only ever serves one response per
            # connection (a whole video, or one Range chunk), so keep-alive
            # buys nothing on loopback but does trip a noisy (harmless)
            # ConnectionResetError in socketserver's own next-request read
            # whenever the player disconnects mid-stream (pause/seek/stop) —
            # confirmed live. Plain connection-per-request sidesteps it.
            protocol_version = 'HTTP/1.0'

            def log_message(self, fmt, *args):
                pass  # default logs every request to stderr — real errors already go through xbmc.log below

            def do_GET(self):
                from urllib.parse import urlparse, parse_qs, unquote
                q = parse_qs(urlparse(self.path).query)
                target = unquote(q.get('url', [''])[0])
                ua = unquote(q.get('ua', [''])[0])
                if not target:
                    self.send_response(400)
                    self.end_headers()
                    return

                headers = {}
                if ua:
                    headers['User-Agent'] = ua
                rng = self.headers.get('Range')
                if rng:
                    headers['Range'] = rng

                try:
                    upstream = _req.get(target, headers=headers, stream=True, timeout=20)
                except Exception as e:
                    xbmc.log('[Starfleet/LocalProxy] upstream fetch error: %s' % e, xbmc.LOGWARNING)
                    self.send_response(502)
                    self.end_headers()
                    return

                try:
                    self.send_response(upstream.status_code)
                    for h in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges'):
                        v = upstream.headers.get(h)
                        if v:
                            self.send_header(h, v)
                    self.end_headers()
                    for chunk in upstream.iter_content(chunk_size=65536):
                        if chunk:
                            self.wfile.write(chunk)
                except Exception:
                    pass  # player closed the connection early (seek/stop/exit) — not a real error
                finally:
                    upstream.close()

        port = _find_free_port()
        _server = http.server.ThreadingHTTPServer(('127.0.0.1', port), _Handler)
        _port = port
        t = threading.Thread(target=_server.serve_forever, daemon=True)
        t.start()
        xbmc.log('[Starfleet/LocalProxy] started on 127.0.0.1:%d' % port, xbmc.LOGINFO)
        return _port


def build_relay_url(target_url, user_agent=''):
    """Returns a http://127.0.0.1:<port>/relay?url=...&ua=... URL that,
    when fetched by Kodi's player, makes THIS process's own requests
    session perform the real upstream fetch instead of Kodi's player doing
    it independently — see module docstring for why that's the actual fix,
    not a workaround. Raises on any failure to start the local server so
    callers can fall back to their pre-existing direct-URL behavior."""
    port = _ensure_server()
    from urllib.parse import quote as _uq
    url = 'http://127.0.0.1:%d/relay?url=%s' % (port, _uq(target_url, safe=''))
    if user_agent:
        url += '&ua=%s' % _uq(user_agent, safe='')
    return url
