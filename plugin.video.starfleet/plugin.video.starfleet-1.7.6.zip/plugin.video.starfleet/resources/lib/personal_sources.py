# -*- coding: utf-8 -*-
"""
resources/lib/personal_sources.py

Search the user's personal cloud storage libraries for a matching title.

Supported services:
  MixDrop  — searches Movies and Porn folders via API
  Streamtape — searches all uploaded files via API (requires login token)

Credentials are stored as constants here since they are specific to this
installation. If credentials change, update the constants below.
"""

import re
import xbmc
from resources.lib import cache as _cache

# ── MixDrop ───────────────────────────────────────────────────────────────────

_MD_EMAIL   = 'hazmatrevelation@gmail.com'
_MD_KEY     = 'KqVDq4GQ363ju4gCV'
_MD_API     = 'https://api.mixdrop.ag'
_MD_FOLDERS = ['Movies', 'Porn', 'TV Shows']   # folder names to search

try:
    import requests as _req
except ImportError:
    _req = None

_session = None

def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _api_get(endpoint, params=None, timeout=10):
    s = _sess()
    if not s:
        return {}
    p = {'email': _MD_EMAIL, 'key': _MD_KEY}
    if params:
        p.update(params)
    r = s.get(_MD_API + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _get_folder_id(name):
    """Resolve a folder name to its MixDrop folder ref. Cached 7 days."""
    ck = 'mixdrop_folder_%s' % name.lower().replace(' ', '_')
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _api_get('/folderlist')
        folders = data.get('result', {})
        if isinstance(folders, list):
            items = folders
        elif isinstance(folders, dict):
            items = folders.get('folders', []) or list(folders.values())
        else:
            items = []
        for f in items:
            if isinstance(f, dict) and f.get('title', '').lower() == name.lower():
                fid = f.get('ref') or f.get('id') or ''
                _cache.set(ck, fid, 7 * 24 * 3600)
                return fid
    except Exception as e:
        xbmc.log('[Personal/MixDrop] folder lookup error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, '', 3600)
    return ''


def _list_folder_files(folder_ref):
    """List files in a MixDrop folder. Cached 1h."""
    ck = 'mixdrop_files_%s' % folder_ref
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        data = _api_get('/folderlist', {'ref': folder_ref})
        result = data.get('result', {})
        files = result.get('files', []) if isinstance(result, dict) else []
        _cache.set(ck, files, 3600)
        return files
    except Exception as e:
        xbmc.log('[Personal/MixDrop] list files error for %s: %s' % (folder_ref, e), xbmc.LOGWARNING)
        _cache.set(ck, [], 3600)
        return []


def _get_stream_url(file_ref):
    """Fetch the direct stream URL for a MixDrop file ref."""
    try:
        data = _api_get('/fileref2', {'ref': file_ref})
        result = data.get('result', {})
        if isinstance(result, dict):
            return result.get('url', '') or result.get('stream', '')
        return ''
    except Exception as e:
        xbmc.log('[Personal/MixDrop] stream URL error for %s: %s' % (file_ref, e), xbmc.LOGWARNING)
        return ''


_RE_ADE_PREFIX = re.compile(r'^(\d{4,7})\s+(.+)$')


def _extract_ade_id(filename):
    """
    Extract leading ADE product ID from a filename like '12345 Movie Title.mp4'.
    Returns (ade_id_str, clean_title) or ('', '') if no numeric prefix.
    """
    name = re.sub(r'\.[a-z0-9]{2,5}$', '', filename, flags=re.IGNORECASE).strip()
    m = _RE_ADE_PREFIX.match(name)
    if m:
        return m.group(1), m.group(2).strip()
    return '', ''


def _title_matches(filename, title, year=None):
    """Fuzzy match a title against a filename.
    Handles files prefixed with ADE product ID: '12345 Movie Title.mp4'."""
    fname = re.sub(r'\.[a-z0-9]{2,5}$', '', filename, flags=re.IGNORECASE)
    fname_clean = re.sub(r'[._\-]', ' ', fname).lower().strip()

    # Strip leading numeric ID (ADE prefix) for cleaner matching
    fname_no_id = re.sub(r'^\d{4,7}\s+', '', fname_clean).strip()

    title_clean = title.lower().strip()
    for candidate in (fname_clean, fname_no_id):
        if title_clean in candidate:
            if year:
                return str(year) in candidate
            return True
        words = [w for w in title_clean.split() if len(w) > 2]
        if words and all(w in candidate for w in words):
            return True
    return False


def search_mixdrop(title, year=None, media_type='movie'):
    """
    Search the user's MixDrop library for files matching title.
    Returns list of {'label': str, 'url': str} source dicts.
    Adult content (media_type='adult') searches Porn and Movies folders.
    Files prefixed with an ADE ID ('12345 Title.mp4') are matched with the ID stripped.
    """
    if not _req:
        return []

    # Adult content lives in Porn and Movies; TV in TV Shows; regular movies in Movies+Porn
    if media_type in ('adult', 'movie'):
        folders = ['Porn', 'Movies']
    elif media_type == 'tv':
        folders = ['TV Shows']
    else:
        folders = _MD_FOLDERS[:]

    sources = []
    for folder_name in folders:
        fid = _get_folder_id(folder_name)
        if not fid:
            continue
        files = _list_folder_files(fid)
        for f in files:
            if not isinstance(f, dict):
                continue
            fname = f.get('title') or f.get('name') or ''
            if not fname:
                continue
            if not _title_matches(fname, title, year):
                continue
            fref = f.get('ref') or f.get('fileref') or ''
            if not fref:
                continue
            stream = _get_stream_url(fref)
            if not stream:
                continue
            sources.append({
                'label': '[MixDrop] %s' % fname,
                'url':   stream,
            })
            # If filename has an ADE product ID prefix, fire a background ADE lookup
            # so the detail page shows full metadata next visit
            ade_id, ade_title = _extract_ade_id(fname)
            if ade_id:
                try:
                    import threading
                    from resources.lib import ade as _ade
                    def _lookup_ade(aid, atitle):
                        try:
                            _ade.search_by_title(atitle or title)
                        except Exception:
                            pass
                    threading.Thread(
                        target=_lookup_ade, args=(ade_id, ade_title), daemon=True
                    ).start()
                except Exception:
                    pass

    if sources:
        xbmc.log('[Personal/MixDrop] Found %d match(es) for "%s"' % (len(sources), title),
                 xbmc.LOGINFO)
    return sources


# ── Streamtape ────────────────────────────────────────────────────────────────
#
# Folder layout on the account:
#   Home/Movies/         — files named "tt1234567 Title (Year) Quality.mp4"
#   Home/TV Shows/       — subfolders "tt1234567 Show Name"
#                            → subfolders "tt1234567 Season N"
#                              → episode files
#   Home/Porn/           — adult files, matched by title
#
# IMDB IDs embedded in names allow exact matching when imdb_id is known.

_ST_USER    = '3002fb47d0df5c2b160d'
_ST_API     = 'https://api.streamtape.com'
_RE_ST_IMDB = re.compile(r'\btt(\d{7,8})\b', re.IGNORECASE)
_RE_ST_SxEx = re.compile(r'\bS(\d{1,2})E(\d{1,2})\b', re.IGNORECASE)


def _st_key():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('st_api_key').strip()
    except Exception:
        return ''


def _st_on():
    try:
        import xbmcaddon
        a = xbmcaddon.Addon()
        return a.getSetting('st_enabled') == 'true' and bool(a.getSetting('st_api_key').strip())
    except Exception:
        return False


def _st_get(endpoint, params=None, timeout=10):
    s = _sess()
    key = _st_key()
    if not s or not key:
        return {}
    p = {'login': _ST_USER, 'key': key}
    if params:
        p.update(params)
    r = s.get(_ST_API + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _st_list_folder(folder_id=''):
    """List contents of a Streamtape folder. Returns (folders, files). Cached 1h."""
    ck = 'st_folder_%s' % (folder_id or 'root')
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        params = {'folder': folder_id} if folder_id else {}
        data = _st_get('/file/listfolder', params)
        result = data.get('result', {})
        if not isinstance(result, dict):
            raise ValueError('bad result: %r' % result)
        folders = result.get('folders', []) or []
        files   = result.get('files',   []) or []
        out = (folders, files)
        _cache.set(ck, out, 3600)
        return out
    except Exception as e:
        xbmc.log('[Personal/Streamtape] listfolder %r error: %s' % (folder_id, e), xbmc.LOGWARNING)
        _cache.set(ck, ([], []), 3600)
        return [], []


def _st_root_folders():
    """Return dict of {name_lower: folder_id} for root-level folders. Cached 7d."""
    ck = 'st_root_folders'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    folders, _ = _st_list_folder('')
    mapping = {}
    for f in folders:
        name = (f.get('name') or '').strip()
        fid  = f.get('id') or ''
        if name and fid:
            mapping[name.lower()] = fid
    _cache.set(ck, mapping, 7 * 24 * 3600)
    return mapping


def _st_stream_url(file_id):
    """Get a playable direct URL for a Streamtape file ID."""
    try:
        data = _st_get('/file/dlticket', {'file': file_id})
        res  = data.get('result', {})
        ticket = res.get('ticket', '')
        if not ticket:
            return ''
        data2 = _st_get('/file/dl', {'file': file_id, 'ticket': ticket})
        return data2.get('result', {}).get('url', '')
    except Exception as e:
        xbmc.log('[Personal/Streamtape] stream URL error for %s: %s' % (file_id, e), xbmc.LOGWARNING)
        return ''


def _st_imdb_from_name(name):
    """Extract numeric IMDB ID string from a filename/folder name, e.g. 'tt0303461 Firefly' → '0303461'."""
    m = _RE_ST_IMDB.search(name)
    return m.group(1) if m else ''


def _st_find_episode_file(season_folder_id, season_num, episode_num):
    """Return the linkid of an episode file matching S{season}E{episode}."""
    _, files = _st_list_folder(season_folder_id)
    target_s = int(season_num)
    target_e = int(episode_num)
    for f in files:
        fname = f.get('name') or ''
        m = _RE_ST_SxEx.search(fname)
        if m and int(m.group(1)) == target_s and int(m.group(2)) == target_e:
            return f.get('linkid') or f.get('id') or ''
    return ''


def search_streamtape(title, year=None, media_type='movie', imdb_id=None,
                      season=None, episode=None):
    """
    Search the user's Streamtape library for a matching file.

    - Movies:  searches Home/Movies/, matches by IMDB ID or title
    - TV:      searches Home/TV Shows/{show folder}/{season folder}/episode file
    - Adult:   searches Home/Porn/, matches by title
    """
    if not _req or not _st_on():
        return []

    roots = _st_root_folders()

    # ── choose which root folder(s) to search ────────────────────────────────
    if media_type == 'tv':
        target_roots = ['tv shows']
    elif media_type == 'adult':
        target_roots = ['porn']
    else:  # movie
        target_roots = ['movies']

    sources = []

    # Strip leading 'tt' if caller passed 'tt1234567'
    clean_imdb = ''
    if imdb_id:
        m = _RE_ST_IMDB.search(imdb_id)
        clean_imdb = m.group(1) if m else imdb_id.lstrip('t')

    for root_name in target_roots:
        root_id = roots.get(root_name)
        if not root_id:
            xbmc.log('[Personal/Streamtape] root folder "%s" not found' % root_name, xbmc.LOGWARNING)
            continue

        if media_type == 'tv':
            # ── TV: navigate Show → Season → Episode ─────────────────────────
            show_folders, _ = _st_list_folder(root_id)
            show_folder_id = ''
            for sf in show_folders:
                sf_name  = sf.get('name') or ''
                sf_imdb  = _st_imdb_from_name(sf_name)
                if clean_imdb and sf_imdb == clean_imdb:
                    show_folder_id = sf.get('id') or ''
                    break
                if not clean_imdb and _title_matches(sf_name, title):
                    show_folder_id = sf.get('id') or ''
                    break
            if not show_folder_id:
                continue

            season_folders, _ = _st_list_folder(show_folder_id)
            season_folder_id = ''
            target_s = int(season) if season else 1
            for sf in season_folders:
                sf_name = sf.get('name') or ''
                # match "Season N" or "tt... Season N"
                if re.search(r'\bSeason\s+%d\b' % target_s, sf_name, re.IGNORECASE):
                    season_folder_id = sf.get('id') or ''
                    break
            if not season_folder_id:
                continue

            ep_file_id = _st_find_episode_file(season_folder_id, target_s, episode or 1)
            if not ep_file_id:
                continue

            url = _st_stream_url(ep_file_id)
            if url:
                sources.append({
                    'label': '[Streamtape] %s S%02dE%02d' % (title, target_s, episode or 1),
                    'url':   url,
                })

        else:
            # ── Movies / Adult: list folder, match each file ──────────────────
            _, files = _st_list_folder(root_id)
            for f in files:
                fname  = f.get('name') or ''
                f_imdb = _st_imdb_from_name(fname)
                # Prefer IMDB-based exact match; fall back to title match
                matched = False
                if clean_imdb and f_imdb:
                    matched = (f_imdb == clean_imdb)
                if not matched:
                    matched = _title_matches(fname, title, year)
                if not matched:
                    continue
                fid = f.get('linkid') or f.get('id') or ''
                if not fid:
                    continue
                url = _st_stream_url(fid)
                if not url:
                    continue
                sources.append({
                    'label': '[Streamtape] %s' % fname,
                    'url':   url,
                })

    if sources:
        xbmc.log('[Personal/Streamtape] Found %d match(es) for "%s"' % (len(sources), title),
                 xbmc.LOGINFO)
    return sources


# ── Unified personal library search ──────────────────────────────────────────

def search_personal(title, year=None, media_type='movie', imdb_id=None,
                    season=None, episode=None):
    """Search all personal library services and return combined source list."""
    sources = []
    try:
        sources += search_mixdrop(title, year=year, media_type=media_type)
    except Exception as e:
        xbmc.log('[Personal] MixDrop search error: %s' % e, xbmc.LOGWARNING)
    try:
        sources += search_streamtape(title, year=year, media_type=media_type,
                                     imdb_id=imdb_id, season=season, episode=episode)
    except Exception as e:
        xbmc.log('[Personal] Streamtape search error: %s' % e, xbmc.LOGWARNING)
    return sources
