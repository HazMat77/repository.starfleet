# -*- coding: utf-8 -*-
"""
resources/lib/ade.py — Adult DVD Empire metadata scraper

URL patterns (as of 2024):
  Search:  GET https://www.adultdvdempire.com/allsearch/search?q=TITLE&type=product
  Detail:  https://www.adultdvdempire.com/{id}/{slug}.html
  Covers:  https://imgs1cdn.adultempire.com/products/{id[-2:]}/{id}h.jpg  (front cover)
           https://imgs1cdn.adultempire.com/products/{id[-2:]}/{id}bh.jpg (back cover)

Age confirmation: site requires a POST to /Account/AgeConfirmation before any content.
Cache TTLs:
  Search results  → 6 h
  Film detail     → 24 h
"""

import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

import requests
from resources.lib import cache as _cache
_cache.init(_CACHE_DB)

BASE = 'https://www.adultdvdempire.com'

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': BASE + '/',
}

# ── Pre-compiled patterns ──────────────────────────────────────────────────────

_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE  = re.compile(r'\s+')

# Search result card: <a href="/ID/slug.html" ... title="Movie Title"
_RE_SEARCH_CARD = re.compile(
    r'href="/([\d]+)/([a-z0-9][a-z0-9-]*porn-movies\.html)"[^>]*title="([^"]+)"',
    re.IGNORECASE
)
# Also match cards where title attr is before href
_RE_SEARCH_CARD2 = re.compile(
    r'title="([^"]+)"[^>]*href="/([\d]+)/([a-z0-9][a-z0-9-]*porn-movies\.html)"',
    re.IGNORECASE
)
# product-details__item-title anchor: class="product-details__item-title" title="..."
_RE_SEARCH_TITLE_ANCHOR = re.compile(
    r'class="product-details__item-title"[^>]*href="/([\d]+)/([a-z0-9][a-z0-9-]*\.html)"[^>]*title="([^"]+)"',
    re.IGNORECASE
)
_RE_SEARCH_TITLE_ANCHOR2 = re.compile(
    r'href="/([\d]+)/([a-z0-9][a-z0-9-]*\.html)"[^>]*class="product-details__item-title"[^>]*title="([^"]+)"',
    re.IGNORECASE
)

# Detail page: title
_RE_TITLE = re.compile(
    r'class="movie-page__heading__title"[^>]*>\s*([^<]+)\s*<',
    re.IGNORECASE
)
_RE_TITLE_H1 = re.compile(r'<h1[^>]*>([^<]+)<', re.IGNORECASE)

# Synopsis
_RE_SYNOPSIS = re.compile(
    r'class="synopsis-content"[^>]*>\s*<p[^>]*>(.*?)</p>',
    re.IGNORECASE | re.DOTALL
)
_RE_SYNOPSIS2 = re.compile(
    r'class="synopsis-content"[^>]*>(.*?)</div>',
    re.IGNORECASE | re.DOTALL
)

# Studio: <a href="/studio-id/studio/name-porn-movies.html">Studio Name</a> near heading
_RE_STUDIO = re.compile(
    r'href="/\d+/[^"]+porn-movies\.html"[^>]*class="[^"]*studio[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_STUDIO2 = re.compile(
    r'<a[^>]+href="/\d+/[^"]*studios?-porn-movies\.html"[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_STUDIO3 = re.compile(
    r'(?:Studio|Label)[:\s]*(?:<[^>]+>)+([^<]{2,60})',
    re.IGNORECASE
)

# Year: <small>(YYYY)</small>
_RE_YEAR_SMALL = re.compile(r'<small>\s*\((\d{4})\)\s*</small>', re.IGNORECASE)
_RE_YEAR = re.compile(r'(?:Release\s*Date|Production\s*Year|Year)[^<]*(\d{4})', re.IGNORECASE)

# Cast: <a class="PerformerName" href="...">Name</a>
_RE_CAST = re.compile(
    r'class="PerformerName"[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_CAST2 = re.compile(
    r'href="/\d+/[^"]*pornstars?\.html"[^>]*>([^<]+)<',
    re.IGNORECASE
)

# Director
_RE_DIRECTOR = re.compile(
    r'(?:Director)[:\s]*(?:<[^>]+>)+([^<]{2,60})',
    re.IGNORECASE
)

# Runtime
_RE_RUNTIME = re.compile(
    r'(?:Run\s*Time|Runtime|Length)[:\s]*(\d+)',
    re.IGNORECASE
)

# Rating
_RE_RATING = re.compile(
    r'(?:rating|score)[^>]*>\s*([0-9.]+)\s*(?:out\s*of|/)?',
    re.IGNORECASE
)

# Genres/categories
_RE_GENRES = re.compile(
    r'href="/\d+/[^"]*categories?-porn-movies\.html"[^>]*>([^<]+)<',
    re.IGNORECASE
)
_RE_GENRES2 = re.compile(
    r'href="/\d+/[^/]*/category/[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE
)

# Browse listing cards
_RE_BROWSE_CARD = re.compile(
    r'href="/([\d]+)/([a-z0-9][a-z0-9-]*porn-movies\.html)"[^>]*title="([^"]+)"',
    re.IGNORECASE
)
_RE_BROWSE_CARD2 = re.compile(
    r'title="([^"]+)"[^>]*href="/([\d]+)/([a-z0-9][a-z0-9-]*porn-movies\.html)"',
    re.IGNORECASE
)

# CDN images (caps1cdn or imgs1cdn)
_RE_CDN_IMG = re.compile(
    r'src="(https?://[a-z0-9.-]*(?:caps1cdn|imgs1cdn)[^"]+(?:\.jpg|\.jpeg|\.png|\.webp))"',
    re.IGNORECASE
)


# ── HTTP session ───────────────────────────────────────────────────────────────

_session = None
_age_confirmed = False


def _sess():
    global _session, _age_confirmed
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        a = requests.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=requests.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)

    if not _age_confirmed:
        try:
            _session.get(BASE + '/', timeout=10)
            _session.post(
                BASE + '/Account/AgeConfirmation',
                data={'ageConfirmationClicked': 'true'},
                headers={**HEADERS, 'X-Requested-With': 'XMLHttpRequest'},
                timeout=10
            )
            _age_confirmed = True
        except Exception as e:
            xbmc.log('[ADE] age confirm error: %s' % e, xbmc.LOGWARNING)

    return _session


def _get(url, params=None, timeout=12):
    r = _sess().get(url, params=params, timeout=timeout)
    r.raise_for_status()
    return r.text


def _clean(text):
    text = _RE_STRIP_TAGS.sub(' ', text)
    return _RE_WHITESPACE.sub(' ', text).strip()


def _cover_url(film_id, variant='h'):
    """Build CDN cover URL from film ID. variant: 'h'=front high, 'bh'=back high."""
    sid = str(film_id)
    return 'https://imgs1cdn.adultempire.com/products/%s/%s%s.jpg' % (sid[-2:], sid, variant)


# ── Public API ─────────────────────────────────────────────────────────────────

def search_by_title(title):
    """
    Search ADE for `title`. Returns a metadata dict or None.
    Cached 6 hours.
    """
    ck = 'ade_search_%s' % re.sub(r'[^a-z0-9]', '_', title.lower())[:80]
    cached = _cache.get(ck)
    if cached is not None:
        return cached if cached else None

    try:
        html = _get(BASE + '/allsearch/search', params={'q': title, 'type': 'product'})
    except Exception as e:
        xbmc.log('[ADE] search error for "%s": %s' % (title, e), xbmc.LOGWARNING)
        return None

    film = _parse_search_result(html, title)
    _cache.set(ck, film if film else False, 6 * 3600)

    if film:
        xbmc.log('[ADE] search "%s" → "%s"' % (title, film.get('title', '')), xbmc.LOGINFO)
    else:
        xbmc.log('[ADE] search "%s" → no match' % title, xbmc.LOGINFO)

    return film


def get_film_detail(film_id, film_slug):
    """
    Fetch full ADE detail page for a known film.
    Returns metadata dict. Cached 24 h.
    """
    ck = 'ade_detail_%s' % film_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    # New URL format uses .html extension
    slug = film_slug if film_slug.endswith('.html') else film_slug
    url = '%s/%s/%s' % (BASE, film_id, slug)
    if not url.endswith('.html'):
        url = url.rstrip('/') + '.html'

    try:
        html = _get(url)
        detail = _parse_detail(film_id, film_slug, html)
        _cache.set(ck, detail, 24 * 3600)
        return detail
    except Exception as e:
        xbmc.log('[ADE] detail(%s) error: %s' % (film_id, e), xbmc.LOGWARNING)
        return _minimal(film_id, film_slug)


def get_trailer_url(title):
    """
    ADE does not provide free public trailers.
    Always returns '' — kept for API compatibility.
    """
    return ''


def browse_new_releases(page=1):
    """
    Fetch ADE new releases listing. Returns list of film stub dicts. Cached 6 h.
    """
    ck = 'ade_new_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []

    url = BASE + '/new-releases-porn-movies.html'
    if page > 1:
        url = '%s/new-releases-porn-movies/%d.html' % (BASE, page)

    try:
        html  = _get(url)
        films = _parse_browse_page(html)
        _cache.set(ck, films or False, 6 * 3600)
        xbmc.log('[ADE] browse_new_releases page=%d → %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[ADE] browse_new_releases error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, False, 3600)
        return []


# ── Parsers ────────────────────────────────────────────────────────────────────

def _minimal(film_id, slug):
    return {
        'id':          film_id,
        'slug':        slug,
        'title':       re.sub(r'-porn-movies.*', '', slug).replace('-', ' ').title(),
        'description': '',
        'year':        '',
        'runtime':     0,
        'studio':      '',
        'director':    '',
        'rating':      0.0,
        'cast':        [],
        'categories':  [],
        'thumb':       _cover_url(film_id, 'h'),
        'fanart':      _cover_url(film_id, 'bh'),
        'backcover':   _cover_url(film_id, 'bh'),
        'trailer':     '',
        'source':      'ade',
    }


def _parse_search_result(html, query):
    """
    Parse the first relevant movie from an ADE search results page.
    Returns a metadata dict or None.
    """
    import unicodedata

    def _norm(t):
        t = t.lower()
        t = ''.join(c for c in unicodedata.normalize('NFD', t)
                    if unicodedata.category(c) != 'Mn')
        t = re.sub(r'[^a-z0-9 ]', '', t)
        return re.sub(r'\s+', ' ', t).strip()

    norm_q = _norm(query)
    candidates = []  # (film_id, slug, title)

    def _add_candidate(fid, fslug, ftitle):
        fid = fid.strip()
        fslug = fslug.strip()
        ftitle = _clean(ftitle)
        if fid and fslug and ftitle and not any(c[0] == fid for c in candidates):
            candidates.append((fid, fslug, ftitle))

    # Pattern: class="product-details__item-title" with title attr
    for m in _RE_SEARCH_TITLE_ANCHOR.finditer(html):
        _add_candidate(m.group(1), m.group(2), m.group(3))
    for m in _RE_SEARCH_TITLE_ANCHOR2.finditer(html):
        _add_candidate(m.group(1), m.group(2), m.group(3))

    # Pattern: href="/ID/slug.html" title="Title"
    for m in _RE_SEARCH_CARD.finditer(html):
        _add_candidate(m.group(1), m.group(2), m.group(3))
    for m in _RE_SEARCH_CARD2.finditer(html):
        _add_candidate(m.group(2), m.group(3), m.group(1))

    # Broad fallback: any /ID/slug-porn-movies.html with a title attr
    if not candidates:
        for m in re.finditer(
            r'href="/([\d]+)/([a-z0-9][a-z0-9-]*porn-movies\.html)"',
            html, re.IGNORECASE
        ):
            fid, fslug = m.group(1), m.group(2)
            # Look for a nearby title attribute or text
            region = html[max(0, m.start() - 50): m.end() + 200]
            tm = re.search(r'title="([^"]+)"', region)
            if tm:
                _add_candidate(fid, fslug, tm.group(1))

    if not candidates:
        return None

    # Score candidates
    best = None
    best_score = -1
    for fid, fslug, ftitle in candidates:
        norm_t = _norm(ftitle)
        if norm_t == norm_q:
            best = (fid, fslug, ftitle)
            break
        q_words = set(norm_q.split())
        t_words = set(norm_t.split())
        score   = len(q_words & t_words) / max(len(q_words), 1)
        if score > best_score:
            best_score = score
            best = (fid, fslug, ftitle)

    if not best or best_score < 0.4:
        # If we have candidates but no good match, return first one anyway
        if candidates:
            best = candidates[0]
        else:
            return None

    film_id, film_slug, film_title = best

    detail = _minimal(film_id, film_slug)
    detail['title'] = film_title
    # Thumb already set by _minimal via _cover_url
    return detail


def _parse_browse_page(html):
    """Parse a browse/listing page, returning list of film stub dicts."""
    films = []
    seen  = set()

    def _add(fid, fslug, ftitle):
        if fid in seen or not fid or not fslug or not ftitle:
            return
        seen.add(fid)
        d = _minimal(fid, fslug)
        d['title'] = _clean(ftitle)
        films.append(d)

    for m in _RE_BROWSE_CARD.finditer(html):
        _add(m.group(1), m.group(2), m.group(3))
    for m in _RE_BROWSE_CARD2.finditer(html):
        _add(m.group(2), m.group(3), m.group(1))

    return films


def _parse_detail(film_id, film_slug, html):
    detail = _minimal(film_id, film_slug)

    # Title
    m = _RE_TITLE.search(html)
    if not m:
        m = _RE_TITLE_H1.search(html)
    if m:
        detail['title'] = _clean(m.group(1))

    # Cover — use CDN URL built from ID (always available, no scraping needed)
    # _minimal already sets these via _cover_url(); no need to override

    # Synopsis
    m = _RE_SYNOPSIS.search(html)
    if not m:
        m = _RE_SYNOPSIS2.search(html)
    if m:
        detail['description'] = _clean(m.group(1))[:800]

    # Studio
    m = _RE_STUDIO.search(html) or _RE_STUDIO2.search(html) or _RE_STUDIO3.search(html)
    if m:
        detail['studio'] = _clean(m.group(1))

    # Director
    m = _RE_DIRECTOR.search(html)
    if m:
        detail['director'] = _clean(m.group(1))

    # Year — try <small>(YYYY)</small> first
    m = _RE_YEAR_SMALL.search(html)
    if not m:
        m = _RE_YEAR.search(html)
    if m:
        detail['year'] = m.group(1)

    # Runtime
    m = _RE_RUNTIME.search(html)
    if m:
        try:
            detail['runtime'] = int(m.group(1))
        except ValueError:
            pass

    # Rating
    m = _RE_RATING.search(html)
    if m:
        try:
            detail['rating'] = float(m.group(1))
        except ValueError:
            pass

    # Cast
    cast = []
    seen_cast = set()
    for pat in (_RE_CAST, _RE_CAST2):
        for m in pat.finditer(html):
            name = _clean(m.group(1))
            if name and name not in seen_cast and len(name) > 2:
                seen_cast.add(name)
                cast.append({'id': '', 'slug': '', 'name': name})
    detail['cast'] = cast

    # Genres
    cats = []
    seen_c = set()
    for pat in (_RE_GENRES, _RE_GENRES2):
        for m in pat.finditer(html):
            cat = _clean(m.group(1))
            if cat and cat not in seen_c and len(cat) > 1:
                seen_c.add(cat)
                cats.append(cat)
    detail['categories'] = cats

    # No free trailers available on ADE
    detail['trailer'] = ''

    return detail
