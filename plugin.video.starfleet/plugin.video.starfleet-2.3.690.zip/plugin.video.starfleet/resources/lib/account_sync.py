# -*- coding: utf-8 -*-
"""
resources/lib/account_sync.py

Settings > Sync accounts: back up the viewer's linked accounts (debrid, trackers, Usenet, private sites...) and bring them to another
device with a passphrase. Shared by the Kodi add-on, the HazMat TV app and the desktop app (the app packages this same file).

How it travels: the data is packed into JSON, compressed and ENCRYPTED HERE with a key made from the viewer's passphrase (PBKDF2-HMAC-SHA256,
HMAC-SHA256 counter-mode keystream, encrypt-then-MAC; standard library only, so it runs everywhere). Only the encrypted text is sent to the
relay, which keeps it for 30 days under the viewer's paired Telegram account; any other device paired to the same Telegram account can fetch
it and decrypt it with the same passphrase. Nobody else, the relay included, can read it. A forgotten passphrase cannot be recovered.

Platform extras: the Android and desktop apps also keep things outside the add-on settings (IPTV providers, Plex / Jellyfin / Emby servers,
network shares). They hand those over as the `extra` dictionary of pack() and receive it back from unpack().
"""
import base64
import hashlib
import hmac
import json
import os
import time
import zlib

RELAY = 'https://hazmat-relay.hazmat-tv-aad5.workers.dev'
_UA = {'User-Agent': 'Starfleet-Sync'}
_ITER = 200000
_MAGIC = 'HZ1'

# The add-on settings that hold an account: tokens, keys, logins, and the switches that go with them.
SETTING_IDS = (
    'rd_api_key', 'ad_api_key', 'pm_api_key', 'tb_api_key', 'dl_api_key', 'oc_api_key',
    'easynews_username', 'easynews_password',
    'nzbgeek_api_key', 'nzbgeek_enabled', 'nzbplanet_api_key', 'nzbplanet_enabled',
    'md_username', 'md_password', 'sd_username', 'sd_password',
    'trakt_client_id', 'trakt_client_secret', 'trakt_access_token', 'trakt_refresh_token',
    'simkl_access_token',
    'wetrakr_api_url', 'wetrakr_access_token', 'wetrakr_username',
    'mdblist_api_key', 'mdblist_enabled', 'md_personal_email', 'md_personal_key',
    'st_personal_login', 'st_personal_key',
    'bitporn_api_token', 'podzemlje_api_token',
    'hf_username', 'hf_password', 'hf_cookies',
    'tmdb_v4_access_token', 'tmdb_v4_account_id', 'tmdb_favorites_list_id',
)


def _b64(b):
    return base64.urlsafe_b64encode(b).decode('ascii').rstrip('=')


def _unb64(s):
    return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))


def _keys(passphrase, salt):
    dk = hashlib.pbkdf2_hmac('sha256', passphrase.encode('utf-8'), salt, _ITER, 64)
    return dk[:32], dk[32:]


def _stream(key, iv, n):
    out = bytearray()
    i = 0
    while len(out) < n:
        out += hmac.new(key, iv + i.to_bytes(4, 'big'), hashlib.sha256).digest()
        i += 1
    return bytes(out[:n])


def encrypt(obj, passphrase):
    """obj (JSON-able) -> 'HZ1:salt:iv:ciphertext:tag' (URL-safe text)."""
    plain = zlib.compress(json.dumps(obj, separators=(',', ':')).encode('utf-8'), 9)
    salt, iv = os.urandom(16), os.urandom(16)
    ek, mk = _keys(passphrase, salt)
    ct = (int.from_bytes(plain, 'big') ^ int.from_bytes(_stream(ek, iv, len(plain)), 'big')).to_bytes(len(plain), 'big')
    tag = hmac.new(mk, _MAGIC.encode() + salt + iv + ct, hashlib.sha256).digest()
    return ':'.join((_MAGIC, _b64(salt), _b64(iv), _b64(ct), _b64(tag)))


def decrypt(blob, passphrase):
    """The inverse of encrypt(). Raises ValueError('wrong passphrase') when the passphrase or the data is wrong."""
    try:
        magic, s, i, c, t = blob.strip().split(':')
        if magic != _MAGIC:
            raise ValueError
        salt, iv, ct, tag = _unb64(s), _unb64(i), _unb64(c), _unb64(t)
    except Exception:
        raise ValueError('this is not an account backup')
    ek, mk = _keys(passphrase, salt)
    if not hmac.compare_digest(hmac.new(mk, _MAGIC.encode() + salt + iv + ct, hashlib.sha256).digest(), tag):
        raise ValueError('wrong passphrase')
    plain = (int.from_bytes(ct, 'big') ^ int.from_bytes(_stream(ek, iv, len(ct)), 'big')).to_bytes(len(ct), 'big')
    return json.loads(zlib.decompress(plain).decode('utf-8'))


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.starfleet')


def collect():
    """The linked accounts found in the add-on settings (empty ones are left out)."""
    a = _addon()
    out = {}
    for k in SETTING_IDS:
        try:
            v = a.getSetting(k)
        except Exception:
            v = ''
        if v and v.strip():
            out[k] = v
    return out


def pack(passphrase, extra=None):
    """Everything to back up -> encrypted text. `extra` is what the platform keeps outside the settings (a JSON-able dictionary)."""
    return encrypt({'v': 1, 'ts': int(time.time()), 'settings': collect(), 'extra': extra or {}}, passphrase)


def unpack(blob, passphrase):
    """Decrypts a backup, puts the settings back (only the known account settings are accepted) and returns {'count': n, 'extra': {...}}."""
    data = decrypt(blob, passphrase)
    if not isinstance(data, dict):
        raise ValueError('this is not an account backup')
    a = _addon()
    n = 0
    for k, v in (data.get('settings') or {}).items():
        if k in SETTING_IDS and isinstance(v, str) and v.strip():
            try:
                a.setSetting(k, v)
                n += 1
            except Exception:
                pass
    try:                                     # hand the debrid accounts to the Starfleet resolver, as a fresh pairing does
        from resources.lib import sf_debrid as _sfd
        if _sfd.available():
            _sfd.sync(force=True)
    except Exception:
        pass
    return {'count': n, 'extra': data.get('extra') or {}}


# ---- the relay ----------------------------------------------------------------------------------------------------------------------

def _req():
    import requests
    return requests


def upload(code, blob):
    """'' when stored (kept 30 days); else a sentence about what failed."""
    try:
        r = _req().put('%s/sync' % RELAY, data=blob.encode('ascii'), headers=dict(_UA, **{'X-Code': code, 'Content-Type': 'text/plain'}), timeout=30)
        if r.status_code == 200:
            return ''
        if r.status_code == 403:
            return 'Telegram is not paired on this device'
        if r.status_code == 429:
            return 'Too many backups in the last hour - try again later'
        return 'The relay answered with an error (%s)' % r.status_code
    except Exception as e:
        return 'Could not reach the relay (%s)' % e


def download(code):
    """(blob, '') or (None, a sentence about what went wrong)."""
    try:
        r = _req().get('%s/sync' % RELAY, headers=dict(_UA, **{'X-Code': code}), timeout=30)
        if r.status_code == 200:
            return r.text, ''
        if r.status_code == 404:
            return None, 'No backup found. Back up on the other device first (backups are kept for 30 days).'
        if r.status_code == 403:
            return None, 'Telegram is not paired on this device'
        if r.status_code == 429:
            return None, 'Too many tries in the last hour - try again later'
        return None, 'The relay answered with an error (%s)' % r.status_code
    except Exception as e:
        return None, 'Could not reach the relay (%s)' % e


def remove(code):
    """'' when the stored copy was deleted."""
    try:
        r = _req().delete('%s/sync' % RELAY, headers=dict(_UA, **{'X-Code': code}), timeout=20)
        return '' if r.status_code == 200 else 'The relay answered with an error (%s)' % r.status_code
    except Exception as e:
        return 'Could not reach the relay (%s)' % e


# ---- Kodi: Settings > General > Sync accounts -----------------------------------------------------------------------------------------

def kodi_menu():
    """Back up / Restore / Delete, with the Telegram pairing and the passphrase asked as needed."""
    import xbmcgui
    from resources.lib import telegram_link as tg
    dlg = xbmcgui.Dialog()
    if not tg.linked_name():
        if not dlg.yesno('Sync accounts', 'Syncing goes through your Telegram account. Pair Telegram now? (Use the same Telegram account on every device.)'):
            return
        if not tg.pair():
            return
    pick = dlg.select('Sync accounts (Telegram: %s)' % tg.linked_name(),
                      ['Back up my accounts now', 'Restore my accounts from the backup', 'Delete the backup'])
    if pick < 0:
        return
    if pick == 2:
        err = remove(tg.code())
        dlg.notification('Starfleet', 'Backup deleted' if not err else err, xbmcgui.NOTIFICATION_INFO if not err else xbmcgui.NOTIFICATION_ERROR, 5000)
        return
    pw = dlg.input('Passphrase (you need the same one to restore; it cannot be recovered)', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not pw:
        return
    busy = xbmcgui.DialogProgress()
    busy.create('Sync accounts', 'Please wait...')
    try:
        if pick == 0:
            pw2 = None
            busy.close()
            pw2 = dlg.input('Type the passphrase again', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if pw2 != pw:
                dlg.ok('Sync accounts', 'The two passphrases are different. Nothing was saved.')
                return
            busy.create('Sync accounts', 'Encrypting and saving...')
            n = len(collect())
            err = upload(tg.code(), pack(pw))
            busy.close()
            dlg.ok('Sync accounts', ('Backed up %d account settings. They are kept for 30 days; restore them on another device with this passphrase.' % n) if not err else err)
        else:
            blob, err = download(tg.code())
            if blob is None:
                busy.close()
                dlg.ok('Sync accounts', err)
                return
            try:
                res = unpack(blob, pw)
            except ValueError as e:
                busy.close()
                dlg.ok('Sync accounts', 'That passphrase does not open the backup.' if 'passphrase' in str(e) else str(e))
                return
            busy.close()
            dlg.ok('Sync accounts', 'Restored %d account settings.' % res['count'])
    finally:
        try:
            busy.close()
        except Exception:
            pass
