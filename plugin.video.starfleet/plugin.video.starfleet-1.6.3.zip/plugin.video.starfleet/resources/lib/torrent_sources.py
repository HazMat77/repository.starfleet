# -*- coding: utf-8 -*-
"""
resources/lib/torrent_sources.py

Search multiple torrent sites for a title and return magnet links.
Results are used with debrid services (Real-Debrid, AllDebrid, Premiumize, TorBox)
to get instant cached streams — uncached torrents are skipped.

Sources:
  YTS          — JSON API, movies only, high quality
  1337x        — HTML scraping, movies + TV
  The Pirate Bay — JSON API, movies + TV
  Zooqle        — HTML scraping, movies + TV
"""

import re
import xbmc

# Minimum quality filter — only return results at 720p or better
_QUALITY_WHITELIST = re.compile(
    r'\b(?:720p?|1080p?|1080i|2160p?|4k|uhd|3d|bd(?:rip|remux)|bluray|blu[-\s]?ray)\b',
    re.IGNORECASE
)
_QUALITY_BLACKLIST = re.compile(
    r'\b(?:480p?|360p?|240p?|cam|camrip|hdcam|scr|screener|dvdscr|hdrip(?!\s*1080))\b',
    re.IGNORECASE
)

def _meets_quality(title_or_quality):
    """Return True if this torrent meets the 720p+ quality threshold."""
    s = (title_or_quality or '').lower()
    if _QUALITY_BLACKLIST.search(s):
        return False
    return bool(_QUALITY_WHITELIST.search(s))

def _extract_quality(text):
    """Extract a display quality label from a torrent title or quality field."""
    text = text or ''
    for pat, label in [
        (r'\b2160p?\b|\b4k\b|\buhd\b',          '4K'),
        (r'\b1080p?\b|\b1080i\b',                '1080p'),
        (r'\b720p?\b',                            '720p'),
        (r'\b3d\b',                               '3D'),
        (r'\bbluray\b|\bbl(?:u[-\s]?ray)\b',      'Blu-ray'),
    ]:
        if re.search(pat, text, re.IGNORECASE):
            return label
    return ''

try:
    import requests as _req
except ImportError:
    _req = None

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
}

_session = None

def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get(url, timeout=10):
    s = _sess()
    if not s:
        return ''
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _get_json(url, timeout=10):
    s = _sess()
    if not s:
        return None
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _make_magnet(info_hash, name=''):
    """Build a magnet link from an info hash."""
    trackers = [
        'udp://tracker.opentrackr.org:1337/announce',
        'udp://open.tracker.cl:1337/announce',
        'udp://tracker.openbittorrent.com:6969/announce',
    ]
    dn = ('&dn=' + _req.utils.quote(name)) if name and _req else ''
    tr = ''.join('&tr=' + t for t in trackers)
    return 'magnet:?xt=urn:btih:%s%s%s' % (info_hash.lower(), dn, tr)


# ── YTS ──────────────────────────────────────────────────────────────────────

_YTS_DOMAINS = ['yts.mx', 'yts.to', 'yts.ag', 'yts-official.mx']


def _yts_get(path):
    """Try YTS domains in order until one responds."""
    for domain in _YTS_DOMAINS:
        try:
            return _get_json('https://%s%s' % (domain, path), timeout=8)
        except Exception:
            continue
    return None


def search_yts(title, year=None, limit=5, allow_lq=False):
    """
    Search YTS JSON API. Returns list of dicts:
      {'title', 'year', 'quality', 'info_hash', 'magnet', 'seeds', 'size'}
    """
    try:
        query = '%s %s' % (title, year) if year else title
        if _req:
            query = _req.utils.quote(query)
        data = _yts_get('/api/v2/list_movies.json?query_term=%s&limit=%d&sort_by=seeds' % (
            query, limit))
        if not data or data.get('status') != 'ok':
            return []
        movies = data.get('data', {}).get('movies') or []
        results = []
        for movie in movies:
            for tor in movie.get('torrents', []):
                ih  = tor.get('hash', '')
                if not ih:
                    continue
                quality = tor.get('quality', '')
                # YTS qualities: 720p, 1080p, 2160p, 3D — all meet threshold
                if not allow_lq and not _meets_quality(quality):
                    continue
                results.append({
                    'title':     movie.get('title_english') or movie.get('title', ''),
                    'year':      movie.get('year', ''),
                    'quality':   _extract_quality(quality) or quality,
                    'info_hash': ih,
                    'magnet':    _make_magnet(ih, movie.get('title', '')),
                    'seeds':     tor.get('seeds', 0),
                    'size':      tor.get('size', ''),
                    'source':    'YTS',
                })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YTS error: %s' % e, xbmc.LOGWARNING)
        return []


# ── The Pirate Bay ────────────────────────────────────────────────────────────

TPB_BASE = 'https://apibay.org'

def search_tpb(title, year=None, category=200, limit=10, allow_lq=False):
    """
    Search TPB via apibay.org JSON API.
    category 200 = Video (all), 201 = Movies, 205 = TV.
    Returns list of dicts: {'title', 'info_hash', 'magnet', 'seeds', 'size', 'source'}
    """
    try:
        query = title
        if year:
            query = '%s %s' % (title, year)
        data = _get_json(TPB_BASE + '/q.php?q=%s&cat=%d' % (
            _req.utils.quote(query) if _req else query, category))
        # apibay returns [{"name":"No results returned","info_hash":"0000..."}] on empty
        if not data or not isinstance(data, list):
            return []
        results = []
        for item in data[:limit]:
            ih = item.get('info_hash', '')
            if not ih or ih == '0000000000000000000000000000000000000000':
                continue
            name = item.get('name', '')
            if not allow_lq and not _meets_quality(name):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(item.get('seeders', 0)),
                'size':      item.get('size', ''),
                'source':    'TPB',
            })
        # Sort by seeds descending
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TPB error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 1337x ─────────────────────────────────────────────────────────────────────

LEET_BASE = 'https://1337x.to'

_RE_LEET_ROW = re.compile(
    r'<td[^>]+class="[^"]*coll-1[^"]*"[^>]*>.*?'
    r'href="(/torrent/\d+/[^"]+)"[^>]*>([^<]+)</a>.*?'
    r'<td[^>]+class="[^"]*coll-2[^"]*"[^>]*>(\d+)<.*?'
    r'<td[^>]+class="[^"]*coll-3[^"]*"[^>]*>(\d+)<',
    re.IGNORECASE | re.DOTALL
)
_RE_LEET_MAGNET = re.compile(r'href="(magnet:[^"]+)"', re.IGNORECASE)


def _leet_get_magnet(path):
    """Fetch the detail page for a 1337x torrent and extract the magnet link."""
    try:
        html = _get(LEET_BASE + path, timeout=8)
        m = _RE_LEET_MAGNET.search(html)
        return m.group(1) if m else ''
    except Exception:
        return ''


def search_1337x(title, year=None, limit=5, allow_lq=False):
    """
    Search 1337x and return list of dicts with magnet links.
    Fetches detail pages for top results to get magnets.
    """
    try:
        query = title.replace(' ', '+')
        if year:
            query += '+' + str(year)
        html = _get(LEET_BASE + '/search/%s/1/' % query, timeout=10)
        results = []
        for m in _RE_LEET_ROW.finditer(html):
            path, name, seeds, leechers = m.group(1), m.group(2), m.group(3), m.group(4)
            if len(results) >= limit:
                break
            name = name.strip()
            if not allow_lq and not _meets_quality(name):
                continue
            magnet = _leet_get_magnet(path)
            if not magnet:
                continue
            ih_m = re.search(r'urn:btih:([a-fA-F0-9]{40})', magnet)
            info_hash = ih_m.group(1) if ih_m else ''
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    magnet,
                'seeds':     int(seeds),
                'size':      '',
                'source':    '1337x',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] 1337x error: %s' % e, xbmc.LOGWARNING)
        return []


# ── EZTV (TV shows) ───────────────────────────────────────────────────────────

EZTV_BASE = 'https://eztvx.to'

def search_eztv(title, year=None, limit=5, allow_lq=False):
    """
    Search EZTV JSON API for TV show episodes.
    Returns list of dicts with magnet links (720p+ only).
    """
    try:
        query = title
        if year:
            query = '%s %s' % (title, year)
        data = _get_json('%s/api/get-torrents?search=%s&limit=%d' % (
            EZTV_BASE,
            _req.utils.quote(query) if _req else query,
            max(limit * 3, 15)  # fetch more since we filter by quality
        ))
        if not data or not isinstance(data.get('torrents'), list):
            return []
        results = []
        for item in data['torrents']:
            name = item.get('filename', '') or item.get('title', '')
            ih   = item.get('hash', '')
            if not ih or not name:
                continue
            if not allow_lq and not _meets_quality(name):
                continue
            magnet = item.get('magnet_url', '') or _make_magnet(ih, name)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    magnet,
                'seeds':     int(item.get('seeds', 0)),
                'size':      item.get('size_bytes', ''),
                'source':    'EZTV',
            })
            if len(results) >= limit:
                break
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] EZTV error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitsearch (bitsearch.to) ──────────────────────────────────────────────────

BITSEARCH_BASE = 'https://bitsearch.to'
_BS_CARD  = 'p-6 hover:shadow-md'
_RE_BS_TITLE = re.compile(r'<h3[^>]*>\s*<a[^>]*>\s*(.*?)\s*</a>', re.IGNORECASE | re.DOTALL)
_RE_BS_SEEDS = re.compile(r'font-medium">(\d+)</span>\s*<span>seeders</span>', re.IGNORECASE)
_RE_BS_SIZE  = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_bitsearch(title, year=None, limit=5, allow_lq=False):
    """Search bitsearch.to DHT index. Returns list of torrent dicts."""
    try:
        import html as _html
        query = title
        if year:
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/search?q=%s&sort=seeders' % (BITSEARCH_BASE, query)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        text = _html.unescape(html_raw)
        results = []
        for card in text.split(_BS_CARD)[1:]:
            if len(results) >= limit:
                break
            try:
                mag_m = re.search(r'href="(magnet:\?[^"]+)"', card, re.IGNORECASE)
                if not mag_m:
                    continue
                magnet = mag_m.group(1).replace('&amp;', '&')
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if not ih_m:
                    continue
                info_hash = ih_m.group(1).lower()
                t_m = _RE_BS_TITLE.search(card)
                name = re.sub(r'\s+', ' ', t_m.group(1)).strip() if t_m else ''
                name = re.sub(r'<[^>]+>', '', name).strip()
                if not name or (not allow_lq and not _meets_quality(name)):
                    continue
                seeds = 0
                s_m = _RE_BS_SEEDS.search(card)
                if s_m:
                    seeds = int(s_m.group(1))
                size = ''
                z_m = _RE_BS_SIZE.search(card)
                if z_m:
                    size = z_m.group(0)
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': info_hash,
                    'magnet':    magnet,
                    'seeds':     seeds,
                    'size':      size,
                    'source':    'Bitsearch',
                })
            except Exception:
                continue
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitsearch error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentGalaxy (tgx.rs) ────────────────────────────────────────────────────

TGX_BASE = 'https://torrentgalaxy.mx'
_RE_TGX_ROW    = re.compile(r'<div[^>]+class="[^"]*tgxtable[^"]*"[^>]*>(.*?)</div>', re.IGNORECASE | re.DOTALL)
_RE_TGX_MAGNET = re.compile(r'a\s+href="(magnet:[^"]+)"', re.IGNORECASE)
_RE_TGX_SIZE   = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)
_TGX_SKIP_LANG = re.compile(r'\b(FRENCH|TRUEFRENCH|ITALIAN|Ita|SPANISH|DUBBED|LAT|Dublado)\b', re.IGNORECASE)


def search_torrentgalaxy(title, year=None, limit=5, allow_lq=False):
    """Search TorrentGalaxy (tgx.rs). Returns list of torrent dicts."""
    try:
        query = title
        if year:
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/torrents.php?search=%s' % (TGX_BASE, query)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        for row_m in _RE_TGX_ROW.finditer(html_raw):
            if len(results) >= limit:
                break
            row = row_m.group(1)
            mag_m = _RE_TGX_MAGNET.search(row)
            if not mag_m:
                continue
            magnet = mag_m.group(1)
            if _TGX_SKIP_LANG.search(magnet):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            # Title from dn= param in magnet
            dn_m = re.search(r'[&?]dn=([^&]+)', magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else info_hash
            if not allow_lq and not _meets_quality(name):
                continue
            size = ''
            z_m = _RE_TGX_SIZE.search(row)
            if z_m:
                size = z_m.group(0)
            seeds_m = re.search(r'<span[^>]+>(\d+)</span>\s*seeders', row, re.IGNORECASE)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'TGX',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentGalaxy error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Knaben meta-search API (api.knaben.org) ───────────────────────────────────
# Aggregates many torrent indexers behind a single JSON endpoint.
# Reliable, no scraping, returns magnet links with seeders + size.

KNABEN_API  = 'https://api.knaben.org/v1'
KNABEN_MOVIES = 3_000_000
KNABEN_TV     = 2_000_000

_KNABEN_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept':     'application/json',
    'Content-Type': 'application/json',
}


def search_knaben(title, year=None, media_type='movie', limit=10, allow_lq=False):
    """Search Knaben aggregated torrent index. Returns list of torrent dicts."""
    try:
        import json as _json
        query = title
        if year:
            query = '%s %s' % (title, year)
        category = KNABEN_MOVIES if media_type == 'movie' else KNABEN_TV
        body = {'query': query, 'categories': [category], 'order_by': 'seeders'}
        s = _sess()
        if not s:
            return []
        r = s.post(KNABEN_API, headers=_KNABEN_HEADERS,
                   data=_json.dumps(body), timeout=12)
        if r.status_code >= 400:
            return []
        hits = r.json().get('hits', [])
        results = []
        for entry in hits:
            if len(results) >= limit:
                break
            name = entry.get('title', '')
            if not name or (not allow_lq and not _meets_quality(name)):
                continue
            ih = (entry.get('hash') or '').lower()
            if not ih or len(ih) != 40:
                continue
            magnet = entry.get('magnetUrl') or _make_magnet(ih, name)
            seeds  = int(entry.get('seeders') or 0)
            size   = ''
            b = entry.get('bytes') or 0
            if b:
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'Knaben',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Knaben error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentio (torrentio.strem.fun) ──────────────────────────────────────────
# IMDB-based Stremio addon API — most reliable source when an IMDB ID is known.

TORRENTIO_BASE = 'https://torrentio.strem.fun'
_RE_TIO_INFO = re.compile(r'👤.*')


def search_torrentio(imdb_id, media_type='movie', season=None, episode=None, limit=20):
    """
    Query Torrentio via IMDB ID. Requires a valid tt... ID.
    For TV: pass season and episode numbers.
    """
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/stream/series/%s:%s:%s.json' % (TORRENTIO_BASE, imdb_id, season, episode)
        else:
            url = '%s/stream/movie/%s.json' % (TORRENTIO_BASE, imdb_id)
        data = _get_json(url, timeout=15)
        if not data or not isinstance(data.get('streams'), list):
            return []
        results = []
        for stream in data['streams'][:limit]:
            ih = stream.get('infoHash')
            if not ih:
                continue
            title_parts = (stream.get('title') or '').split('\n')
            name = title_parts[0].strip()
            if not name:
                continue
            info_lines = [x for x in title_parts if _RE_TIO_INFO.match(x)]
            seeds = 0
            size = ''
            if info_lines:
                s_m = re.search(r'(\d+)', info_lines[0])
                if s_m:
                    seeds = int(s_m.group(1))
                z_m = re.search(r'(\d+(?:\.\d+)?)\s*(GB|GiB|MB|MiB)', info_lines[0], re.IGNORECASE)
                if z_m:
                    size = z_m.group(0)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Torrentio',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torrentio error: %s' % e, xbmc.LOGWARNING)
        return []


# ── YourBitTorrent (yourbittorrent2.com) ─────────────────────────────────────

YBT_BASE = 'https://yourbittorrent2.com'
_RE_YBT_LINK = re.compile(r'<a href="(/torrent/[^"]+)"', re.IGNORECASE)
_RE_YBT_HASH = re.compile(r'<kbd>([a-fA-F0-9]{40})<', re.IGNORECASE)
_RE_YBT_NAME = re.compile(r'<h3 class="card-title">([^<]+)<', re.IGNORECASE)
_RE_YBT_SIZE = re.compile(r'File size:</div><div class="col">([^<]+)<', re.IGNORECASE)
_RE_YBT_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_yourbittorrent(title, year=None, limit=5, allow_lq=False):
    """Search YourBitTorrent (yourbittorrent2.com). Returns list of torrent dicts."""
    try:
        from concurrent.futures import ThreadPoolExecutor
        from urllib.parse import quote_plus as _qp
        query = title
        if year:
            query = '%s %s' % (title, year)
        query_enc = _qp(query).replace('+', '-')
        url = '%s?q=%s' % (YBT_BASE, query_enc)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        links = _RE_YBT_LINK.findall(html_raw)[:15]

        def _fetch(link):
            try:
                detail = _get(YBT_BASE + link, timeout=8)
                ih_m = _RE_YBT_HASH.search(detail)
                nm_m = _RE_YBT_NAME.search(detail)
                if not ih_m or not nm_m:
                    return None
                ih = ih_m.group(1).lower()
                name = nm_m.group(1).strip()
                if not allow_lq and not _meets_quality(name):
                    return None
                if _RE_YBT_LANG.search(name):
                    return None
                sz_m = _RE_YBT_SIZE.search(detail)
                size = sz_m.group(1).strip() if sz_m else ''
                return {
                    'title': name, 'year': '', 'quality': _extract_quality(name),
                    'info_hash': ih, 'magnet': _make_magnet(ih, name),
                    'seeds': 0, 'size': size, 'source': 'YourBT',
                }
            except Exception:
                return None

        results = []
        with ThreadPoolExecutor(max_workers=5) as pool:
            for r in pool.map(_fetch, links):
                if r and len(results) < limit:
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YourBitTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitlord (bitlordsearch.com) ───────────────────────────────────────────────

BITLORD_BASE = 'http://www.bitlordsearch.com'
_RE_BL_MAG  = re.compile(
    r'class="btn btn-default magnet-button[^"]*"[^>]+href="([^"]+)"', re.IGNORECASE
)
_RE_BL_SIZE = re.compile(r'<td class="size">(\d+)</td>', re.IGNORECASE)
_RE_BL_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_bitlord(title, year=None, limit=5, allow_lq=False):
    """Search Bitlord (bitlordsearch.com). Returns list of torrent dicts."""
    try:
        query = title
        if year:
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/search?q=%s' % (BITLORD_BASE, query)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        magnets = _RE_BL_MAG.findall(html_raw)
        sizes   = _RE_BL_SIZE.findall(html_raw)
        results = []
        for i, mag in enumerate(magnets):
            if len(results) >= limit:
                break
            mag = mag.replace('&amp;', '&').split('&tr=')[0]
            if 'magnet' not in mag:
                continue
            dn_m = re.search(r'&dn=([^&]+)', mag)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else ''
            if not name:
                continue
            if not allow_lq and not _meets_quality(name):
                continue
            if _RE_BL_LANG.search(name):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', mag, re.IGNORECASE)
            info_hash = ih_m.group(1).lower() if ih_m else ''
            size = ''
            if i < len(sizes):
                try:
                    b = int(sizes[i])
                    if b >= 1_073_741_824:
                        size = '%.1f GB' % (b / 1_073_741_824)
                    elif b >= 1_048_576:
                        size = '%.0f MB' % (b / 1_048_576)
                except Exception:
                    pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': mag,
                'seeds': 0, 'size': size, 'source': 'Bitlord',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitlord error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Unified search ────────────────────────────────────────────────────────────

def search_all(title, year=None, media_type='movie', max_per_source=5, imdb_id=None,
               season=None, episode=None):
    """
    Search all torrent sources in parallel. Returns combined list sorted by seeds.
    media_type: 'movie', 'tv', or 'adult'
    imdb_id: optional IMDB tt... ID, enables Torrentio
    season/episode: for TV episodes (used with Torrentio)
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    allow_lq = media_type == 'adult'
    tpb_cat  = 500 if media_type == 'adult' else (201 if media_type == 'movie' else 205)
    knaben_type = 'tv' if media_type == 'tv' else 'movie'

    tasks = {
        'Knaben':         lambda: search_knaben(title, year, knaben_type, max_per_source * 2, allow_lq),
        'YTS':            lambda: search_yts(title, year, max_per_source, allow_lq) if media_type != 'tv' else [],
        'TPB':            lambda: search_tpb(title, year, tpb_cat, max_per_source, allow_lq),
        '1337x':          lambda: search_1337x(title, year, max_per_source, allow_lq),
        'EZTV':           lambda: search_eztv(title, year, max_per_source) if media_type == 'tv' else [],
        'Bitsearch':      lambda: search_bitsearch(title, year, max_per_source, allow_lq),
        'TGX':            lambda: search_torrentgalaxy(title, year, max_per_source, allow_lq),
        'YourBT':         lambda: search_yourbittorrent(title, year, max_per_source, allow_lq),
        'Bitlord':        lambda: search_bitlord(title, year, max_per_source, allow_lq),
        'Torrentio':      lambda: search_torrentio(imdb_id, media_type, season, episode, max_per_source * 4) if imdb_id else [],
    }

    all_results = []
    with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        try:
            done_iter = as_completed(futures, timeout=20)
            for future in done_iter:
                try:
                    all_results.extend(future.result())
                except Exception as e:
                    xbmc.log('[Starfleet/Torrents] %s search failed: %s' % (futures[future], e),
                             xbmc.LOGWARNING)
        except Exception:
            # as_completed TimeoutError — collect whatever finished
            for future, name in futures.items():
                if future.done():
                    try:
                        all_results.extend(future.result())
                    except Exception:
                        pass
                else:
                    xbmc.log('[Starfleet/Torrents] %s timed out' % name, xbmc.LOGWARNING)

    # Deduplicate by info_hash
    seen = set()
    unique = []
    for r in all_results:
        ih = r.get('info_hash', '').lower()
        if ih and ih not in seen:
            seen.add(ih)
            unique.append(r)

    unique.sort(key=lambda x: x.get('seeds', 0), reverse=True)
    return unique
