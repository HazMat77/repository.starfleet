# -*- coding: utf-8 -*-
"""
resources/lib/telegram_link.py

Settings > General > "Pair Telegram": link this Kodi install to a Telegram account with a code (scan the QR code, press Start in the bot),
after which "Send Debug Log" delivers the redacted kodi.log straight to the developer's Telegram through the relay, with the sender's name
and a few words about the problem. The bot's token lives only in the relay; the add-on knows the relay's address and its own random code.
The same relay and code scheme as the HazMat TV app (TelegramLink.kt), so the developer sees both the same way.
"""
import json
import os
import time
import uuid
import xbmc
import xbmcgui
import xbmcvfs
import requests as _req

RELAY = 'https://hazmat-relay.hazmat-tv-aad5.workers.dev'
BOT = 'kuckointraderbot'

_MAX_LOG = 400 * 1024            # the newest part of the log is the part that matters
_UA = {'User-Agent': 'Starfleet-Kodi'}


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/Telegram] %s' % msg, level)


def _path():
    d = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'telegram.json')


def _load():
    try:
        with open(_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d):
    try:
        with open(_path(), 'w', encoding='utf-8') as f:
            json.dump(d, f)
    except Exception as e:
        _log('could not save: %s' % e, xbmc.LOGWARNING)


def code():
    d = _load()
    if not d.get('code'):
        d['code'] = uuid.uuid4().hex[:16]
        _save(d)
    return d['code']


def linked_name():
    return (_load().get('name') or '').strip() or None


def link_address():
    return 'https://t.me/%s?start=%s' % (BOT, code())


def unlink():
    _save({})


def poll():
    """True once the code was started in the bot (the name is kept); False while waiting or when the relay does not answer."""
    try:
        r = _req.get('%s/link' % RELAY, params={'code': code()}, headers=_UA, timeout=10)
        if r.status_code != 200:
            return False
        o = r.json()
        if o.get('linked'):
            d = _load()
            d['name'] = o.get('name') or 'linked'
            _save(d)
            return True
    except Exception as e:
        _log('poll: %s' % e)
    return False


def pair():
    """Show the QR code and wait (up to ten minutes) for the Start press. True when linked."""
    from resources.lib.gui import qr_dialog as _q
    link = link_address()
    qr_path = _q.make_qr(link, 'starfleet_telegram_qr.png')
    if not qr_path:
        xbmcgui.Dialog().textviewer('Pair Telegram', 'Open this link on your phone and press Start:\n\n%s' % link)
        return poll()
    dlg = _q.QRDialog(qr_path, 'Pair Telegram', 'Scan the code with your phone, open it in Telegram and press Start.')
    dlg.show()
    mon = xbmc.Monitor()
    ok = False
    try:
        waited = 0
        while waited < 600 and not dlg.iscanceled() and not mon.abortRequested():
            if mon.waitForAbort(3):
                break
            waited += 3
            if poll():
                ok = True
                break
    finally:
        dlg.close()
    if ok:
        xbmcgui.Dialog().notification('Starfleet', 'Telegram paired as %s' % linked_name(), xbmcgui.NOTIFICATION_INFO, 4000)
    return ok


def send_log(text, issue=''):
    """Sends the (already redacted) log through the relay. '' when it went; else a sentence about what failed."""
    if not linked_name():
        return 'Telegram is not linked'
    try:
        import xbmcaddon
        ver = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('version')
    except Exception:
        ver = '?'
    info = 'Starfleet %s - Kodi %s - %s' % (ver, xbmc.getInfoLabel('System.BuildVersion').split(' ')[0], xbmc.getInfoLabel('System.OSVersionInfo') or 'unknown OS')
    try:
        from urllib.parse import quote
        r = _req.post('%s/log' % RELAY, data=text.encode('utf-8', 'ignore'), timeout=40,
                      headers={'X-Code': code(), 'X-Info': info.encode('ascii', 'ignore').decode(), 'X-Issue': quote(issue[:400]),
                               'Content-Type': 'text/plain', **_UA})
        if r.status_code == 200:
            return ''
        if r.status_code == 429:
            return 'Too many logs sent in the last hour - try again later'
        if r.status_code == 403:
            unlink()
            return 'This install is no longer linked - pair Telegram again'
        return 'The relay answered with an error (%s)' % r.status_code
    except Exception as e:
        return 'Could not reach the relay (%s)' % e


def send_debug_log():
    """The Send Debug Log flow. True when the log reached Telegram (False: not paired, cancelled or failed, so the caller falls back)."""
    dlg = xbmcgui.Dialog()
    if not linked_name():
        if not dlg.yesno('Send Debug Log', 'Telegram is not paired. Pair it now? Your log (keys and tokens removed) then goes straight to the '
                                           'developer on Telegram, with your name and a few words about the problem.',
                         nolabel='Use a link instead', yeslabel='Pair Telegram'):
            return False
        if not pair():
            return False
    issue = dlg.input('What went wrong? (a few words)', type=xbmcgui.INPUT_ALPHANUM)
    from resources.lib import debug_log as _dbg
    raw = _dbg._read_recent_log()
    if not raw:
        dlg.notification('Starfleet', 'Could not read the log file', xbmcgui.NOTIFICATION_ERROR, 4000)
        return True
    text = _dbg._redact(raw)[-_MAX_LOG:]
    busy = xbmcgui.DialogProgress()
    busy.create('Starfleet', 'Sending the log to Telegram...')
    try:
        fail = send_log(text, issue or '')
    finally:
        busy.close()
    if not fail:
        dlg.ok('Debug log', 'The log was sent to the developer on Telegram. Thank you - it will be looked at as soon as possible.')
        return True
    _log('send failed: %s' % fail, xbmc.LOGWARNING)
    dlg.notification('Starfleet', fail, xbmcgui.NOTIFICATION_ERROR, 5000)
    return False
