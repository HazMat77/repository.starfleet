﻿# -*- coding: utf-8 -*-
"""
resources/lib/metadata_router.py

TV Shows and Movies sections powered by TMDB + TVDB.

Menu structure:
  📺 TV Shows
    ├── 🔥 Popular
    ├── ⭐ Top Rated
    ├── 🎭 Browse by Genre
    ├── 🔍 Search
    └── [Show] → Seasons → Episodes

  🎬 Movies
    ├── 🔥 Popular
    ├── ⭐ Top Rated
    ├── 🆕 Now Playing
    ├── 🎭 Browse by Genre
    └── 🔍 Search
"""

import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from resources.lib.gui import progress_dialog as _pdlg
from resources.lib.gui.select_dialog import select as _select_dialog

from resources.lib import metadata as meta
from concurrent.futures import ThreadPoolExecutor
import time

ADDON     = xbmcaddon.Addon('plugin.video.starfleet')
PAGE_SIZE = 20


# ── Helpers ───────────────────────────────────────────────────────────────────

def _add_dir(handle, build_url, label, params, thumb='', plot='', fanart=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    if fanart:
        li.setArt({'fanart': fanart})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_playable(handle, build_url, label, params, art=None, info=None):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', info or {'title': label})
    li.setProperty('IsPlayable', 'true')
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, False)


def _movie_art(m):
    return {
        'thumb':  m.get('thumb', ''),
        'poster': m.get('thumb', ''),
        'fanart': m.get('fanart', ''),
        'banner': m.get('fanart', ''),
    }


def _movie_info(m):
    return {
        'title':    m.get('title', ''),
        'year':     int(m['year']) if str(m.get('year', '')).isdigit() else 0,
        'rating':   float(m.get('rating', 0)),
        'plot':     m.get('overview', ''),
        'genre':    ', '.join(m.get('genres', [])),
        'studio':   ', '.join(m.get('studios', [])),
        'director': m.get('director', ''),
        'duration': int(m.get('runtime', 0)) * 60,
        'cast':     [c['name'] for c in m.get('cast', [])],
        'trailer':  m.get('trailer', ''),
        'mpaa':     m.get('mpaa', ''),
        'mediatype': 'movie',
    }


def _tv_info(s):
    return {
        'title':     s.get('title', ''),
        'year':      int(s['year']) if str(s.get('year', '')).isdigit() else 0,
        'rating':    float(s.get('rating', 0)),
        'plot':      s.get('overview', ''),
        'genre':     ', '.join(s.get('genres', [])),
        'studio':    ', '.join(s.get('networks', [])),
        'cast':      [c['name'] for c in s.get('cast', [])],
        'trailer':   s.get('trailer', ''),
        'mpaa':      s.get('mpaa', ''),
        'mediatype': 'tvshow',
    }


def _need_fetch(key):
    from resources.lib import cache as _cache
    return _cache.get(key) is None


def _progress(msg):
    d = _pdlg.DialogProgress()
    d.create('Starfleet', msg)
    return d


def _install_elementum_via_repo():
    """Download and extract the correct Elementum build from the elementumorg local server."""
    import urllib.request as _ur
    import zipfile as _zf
    import os as _os
    import xbmcvfs

    ELEM_ID = 'plugin.video.elementum'
    ELEM_VER = '0.1.113'
    zip_url = 'http://127.0.0.1:65223/{id}/{id}-{v}.zip'.format(id=ELEM_ID, v=ELEM_VER)
    addons_dir = xbmcvfs.translatePath('special://home/addons/')
    dest_dir = _os.path.join(addons_dir, ELEM_ID)

    pbar = _pdlg.DialogProgress()
    pbar.create('Starfleet', 'Installing Elementum (correct build)...')
    try:
        pbar.update(10, 'Downloading from Elementum Repository...')
        with _ur.urlopen(zip_url, timeout=30) as resp:
            data = resp.read()
        pbar.update(60, 'Extracting...')
        import io
        with _zf.ZipFile(io.BytesIO(data)) as zf:
            for member in zf.infolist():
                # strip leading "plugin.video.elementum/" prefix
                parts = member.filename.split('/', 1)
                if len(parts) < 2 or not parts[1]:
                    continue
                out_path = _os.path.join(dest_dir, parts[1].replace('/', _os.sep))
                if member.filename.endswith('/'):
                    _os.makedirs(out_path, exist_ok=True)
                else:
                    _os.makedirs(_os.path.dirname(out_path), exist_ok=True)
                    with open(out_path, 'wb') as f:
                        f.write(zf.read(member.filename))
        pbar.update(100, 'Done.')
        pbar.close()
        xbmc.log('[Starfleet] Elementum extracted from elementumorg build to ' + dest_dir, xbmc.LOGINFO)
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmcgui.Dialog().notification('Starfleet', 'Elementum installed — try again', xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception as e:
        pbar.close()
        xbmc.log('[Starfleet] Elementum auto-install failed: ' + str(e), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            'Starfleet — Install Elementum manually',
            'Auto-install failed. Please install from:\n'
            '[B]Add-ons → Install from repository → Elementum Repository → Video add-ons → Elementum[/B]'
        )


def _next_page(handle, build_url, action, page, extra=None):
    params = {'action': action, 'page': page + 1}
    if extra:
        params.update(extra)
    _add_dir(handle, build_url,
             label='~~ Next Page (%d) ~~' % (page + 1),
             params=params)


# ── Movie Menus ───────────────────────────────────────────────────────────────

def _prewarm_movie_details(films):
    """
    Fire-and-forget background pre-fetch of full movie detail for
    each slim result in a list view. By the time the user clicks
    any item, the detail is already cached — no loading dialog shown.
    Only fetches items whose detail cache is currently cold.
    """
    cold_ids = [
        m['tmdb_id'] for m in films
        if _need_fetch('tmdb_movie_%s' % m['tmdb_id'])
    ]
    if not cold_ids:
        return
    def _fetch(tmdb_id):
        try:
            meta.get_movie_detail(tmdb_id)
        except Exception:
            pass
    pool = ThreadPoolExecutor(max_workers=5)
    for tmdb_id in cold_ids:
        pool.submit(_fetch, tmdb_id)
    pool.shutdown(wait=False)   # fire and forget — never blocks the UI


def _prewarm_tv_details(shows):
    """Same pattern for TV show detail pages."""
    cold_ids = [
        s['tmdb_id'] for s in shows
        if _need_fetch('tmdb_tv_%s' % s['tmdb_id'])
    ]
    if not cold_ids:
        return
    def _fetch(tmdb_id):
        try:
            meta.get_tv_detail(tmdb_id)
        except Exception:
            pass
    pool = ThreadPoolExecutor(max_workers=5)
    for tmdb_id in cold_ids:
        pool.submit(_fetch, tmdb_id)
    pool.shutdown(wait=False)


def movies_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎬 Movies')
    xbmcplugin.setContent(handle, 'movies')

    _add_dir(handle, build_url, '📅  New Releases',
             {'action': 'meta_movies_by_date', 'page': 1},
             plot='Most recently released movies sorted by release date')
    _add_dir(handle, build_url, '🔥  Popular',
             {'action': 'meta_movies_popular', 'page': 1},
             plot='Most popular movies right now')
    _add_dir(handle, build_url, '⭐  Top Rated',
             {'action': 'meta_movies_top', 'page': 1},
             plot='Highest rated movies of all time')
    _add_dir(handle, build_url, '🆕  Now Playing',
             {'action': 'meta_movies_new', 'page': 1},
             plot='Movies currently in theatres')
    _add_dir(handle, build_url, '📈  Trending Now',
             {'action': 'meta_movies_upcoming', 'page': 1},
             plot='Top movies trending this week (mirrors IMDB Movie Meter)')
    _add_dir(handle, build_url, '❤️  Favorites',
             {'action': 'favorites_movies'},
             plot='Your saved movies')
    _add_dir(handle, build_url, '🎭  Browse by Genre',
             {'action': 'meta_movie_genres'},
             plot='Browse movies by genre')
    _add_dir(handle, build_url, '🔍  Search',
             {'action': 'meta_movies_search'},
             plot='Search movies by title')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_popular(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🔥 Popular Movies')
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_popular_%d' % page)
    dlg   = _progress('Loading popular movies...') if cold else None
    films = meta.get_movies_popular(page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_popular', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_top_rated(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '⭐ Top Rated Movies')
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_top_rated_%d' % page)
    dlg   = _progress('Loading top rated movies...') if cold else None
    films = meta.get_movies_top_rated(page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_top', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_now_playing(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🆕 Now Playing')
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_new_%d' % page)
    dlg   = _progress('Loading now playing...') if cold else None
    films = meta.get_movies_new(page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_new', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_by_date(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '📅 New Releases')
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_by_date_%d' % page)
    dlg   = _progress('Loading new releases...') if cold else None
    films = meta.get_movies_by_date(page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_by_date', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_upcoming(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '📈 Trending This Week')
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_trending_%d' % page)
    dlg   = _progress('Loading new releases...') if cold else None
    films = meta.get_movies_upcoming(page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_upcoming', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movie_genres(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎭 Movie Genres')
    xbmcplugin.setContent(handle, 'files')

    cold   = _need_fetch('tmdb_movie_genres')
    dlg    = _progress('Loading genres...') if cold else None
    genres = meta.get_movie_genres()
    if dlg: dlg.close()

    for g in genres:
        _add_dir(handle, build_url,
                 label=g['name'],
                 params={'action': 'meta_movies_by_genre',
                         'genre_id': g['id'], 'genre_name': g['name'], 'page': 1},
                 plot='Browse %s movies' % g['name'])
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def movies_by_genre(handle, build_url, genre_id, genre_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '🎭 %s' % genre_name)
    xbmcplugin.setContent(handle, 'movies')

    cold  = _need_fetch('tmdb_movies_genre_%s_%d' % (genre_id, page))
    dlg   = _progress('Loading %s...' % genre_name) if cold else None
    films = meta.get_movies_by_genre(genre_id, page=page)
    if dlg: dlg.close()

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_movies_by_genre', page,
                   extra={'genre_id': genre_id, 'genre_name': genre_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def movies_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search Movies')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '🔍 Movies: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    dlg   = _progress('Searching...')
    films = meta.search_movies(query)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Movies', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    _render_movie_list(handle, build_url, films)
    _prewarm_movie_details(films)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def movie_detail(handle, build_url, tmdb_id):
    """Load full movie metadata and show detail view with cast."""
    cold   = _need_fetch('tmdb_movie_%s' % tmdb_id)
    dlg    = _progress('Loading movie info...') if cold else None
    film   = meta.get_movie_detail(tmdb_id)
    if dlg: dlg.close()

    if not film:
        xbmcgui.Dialog().notification('Movies', 'Could not load metadata',
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    xbmcplugin.setPluginCategory(handle, film.get('title', ''))
    xbmcplugin.setContent(handle, 'movies')

    art  = _movie_art(film)
    info = _movie_info(film)

    # Play item — include watched indicator from history
    _play_label = '▶  Play — %s' % film.get('title', '')
    try:
        from resources.lib import watch_history as _wh
        _wh_lbl = _wh.progress_label(film.get('imdb_id', ''))
        if _wh_lbl:
            _play_label += _wh_lbl
            info['playcount'] = 1 if _wh.is_watched(film.get('imdb_id', '')) else 0
    except Exception:
        pass
    li = xbmcgui.ListItem(label=_play_label)
    li.setInfo('video', info)
    li.setArt(art)
    li.setProperty('IsPlayable', 'true')
    try:
        from resources.lib import favorites as _fav
        if _fav.is_favorite('movie', tmdb_id):
            _fav_lbl = 'Remove from Favorites'
            _fav_act = 'favorites_remove'
        else:
            _fav_lbl = 'Add to Favorites'
            _fav_act = 'favorites_add'
        li.addContextMenuItems([(_fav_lbl, 'RunPlugin(%s)' % build_url({
            'action': _fav_act, 'media_type': 'movie', 'tmdb_id': tmdb_id,
            'title': film.get('title', ''), 'year': str(film.get('year', '') or ''),
            'imdb_id': film.get('imdb_id', ''), 'thumb': film.get('thumb', ''),
            'fanart': film.get('fanart', ''),
        }))])
    except Exception:
        pass
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({'action': 'meta_movie_play',
                   'tmdb_id': tmdb_id,
                   'title': film.get('title', ''),
                   'imdb_id': film.get('imdb_id', ''),
                   'year': str(film.get('year', '') or '')}),
        li, False
    )

    # Trailer button — convert YouTube URL to YouTube plugin URL so Kodi can play it
    if film.get('trailer'):
        trailer_url = film['trailer']
        yt_m = re.search(r'(?:v=|youtu\.be/)([A-Za-z0-9_-]{11})', trailer_url)
        if yt_m:
            trailer_url = 'plugin://plugin.video.youtube/play/?video_id=%s' % yt_m.group(1)
        tli = xbmcgui.ListItem(label='🎬  Watch Trailer')
        tli.setInfo('video', {'title': 'Trailer: %s' % film.get('title', '')})
        tli.setArt(art)
        tli.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle, trailer_url, tli, False)

    # Cast list
    for actor in film.get('cast', []):
        li = xbmcgui.ListItem(label='👤  %s  as  %s' % (
            actor['name'], actor.get('character', '')))
        li.setInfo('video', {'title': actor['name']})
        li.setArt({'thumb': actor.get('photo', ''),
                   'icon':  actor.get('photo', ''),
                   'fanart': film.get('fanart', '')})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'meta_person',
                       'name': actor['name'],
                       'media_type': 'movie'}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def _render_movie_list(handle, build_url, films):
    """Render a list of slim movie dicts as Kodi items. Click → source picker.
    If full detail is already cached (from a prior prewarm), uses cast/genre/director."""
    from resources.lib import cache as _rcache
    for m in films:
        full = _rcache.get('tmdb_movie_%s' % m['tmdb_id'])
        d    = full if full else m

        label = d['title']
        release_date = d.get('release_date', '') or ''
        if release_date and len(release_date) >= 10:
            label += '  (%s)' % release_date[:10]
        elif d.get('year'):
            label += '  (%s)' % d['year']
        if d.get('rating'):
            label += '  ★%.1f' % d['rating']

        li = xbmcgui.ListItem(label=label)

        info = {
            'title':     d['title'],
            'year':      int(d['year']) if str(d.get('year', '')).isdigit() else 0,
            'rating':    float(d.get('rating', 0)),
            'plot':      d.get('overview', ''),
            'mediatype': 'movie',
        }
        if release_date:
            info['premiered'] = release_date
        if d.get('genres'):
            info['genre'] = ', '.join(d['genres'])
        if d.get('director'):
            info['director'] = d['director']
        if d.get('runtime'):
            info['duration'] = int(d['runtime']) * 60
        if d.get('trailer'):
            info['trailer'] = d['trailer']
        if d.get('mpaa'):
            info['mpaa'] = d['mpaa']

        li.setInfo('video', info)

        art = {
            'thumb':  d.get('thumb', ''),
            'poster': d.get('thumb', ''),
            'fanart': d.get('fanart', ''),
        }
        if full and full.get('backdrops'):
            art['extrafanart'] = full['backdrops'][0]
        li.setArt(art)

        # Cast via InfoTagVideo when full detail available
        if full and full.get('cast'):
            try:
                tag = li.getVideoInfoTag()
                actors = []
                for c in full['cast']:
                    a = xbmcgui.Actor(c['name'], c.get('character', ''),
                                      0, c.get('photo', ''))
                    actors.append(a)
                tag.setCast(actors)
            except Exception:
                pass

        li.setProperty('IsPlayable', 'true')

        # Context menu: Add / Remove from Favorites
        try:
            from resources.lib import favorites as _fav
            if _fav.is_favorite('movie', m['tmdb_id']):
                fav_label = 'Remove from Favorites'
                fav_action = 'favorites_remove'
            else:
                fav_label = 'Add to Favorites'
                fav_action = 'favorites_add'
            li.addContextMenuItems([(fav_label, 'RunPlugin(%s)' % build_url({
                'action':     fav_action,
                'media_type': 'movie',
                'tmdb_id':    m['tmdb_id'],
                'title':      m['title'],
                'year':       str(m.get('year', '') or ''),
                'imdb_id':    m.get('imdb_id', ''),
                'thumb':      d.get('thumb', ''),
                'fanart':     d.get('fanart', ''),
            }))])
        except Exception:
            pass

        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':   'meta_movie_play',
                       'tmdb_id':  m['tmdb_id'],
                       'title':    m['title'],
                       'imdb_id':  m.get('imdb_id', ''),
                       'year':     str(m.get('year', '') or '')}),
            li, False
        )


# ── TV Show Menus ─────────────────────────────────────────────────────────────

def tv_menu(handle, build_url):
    # Plain text, not emoji — several of these (TV/fire/calendar/theater
    # mask/magnifier) render as broken tofu-box placeholder glyphs on this
    # Estuary build, same class of bug already fixed for a stadium emoji
    # in v2.3.220.
    xbmcplugin.setPluginCategory(handle, 'TV Shows')
    xbmcplugin.setContent(handle, 'tvshows')

    _add_dir(handle, build_url, 'Popular',
             {'action': 'meta_tv_popular', 'page': 1},
             plot='Most popular TV shows right now')
    _add_dir(handle, build_url, 'Top Rated',
             {'action': 'meta_tv_top', 'page': 1},
             plot='Highest rated TV shows of all time')
    _add_dir(handle, build_url, 'Airing Today',
             {'action': 'meta_tv_airing', 'page': 1},
             plot='TV shows airing today')
    _add_dir(handle, build_url, 'Favorites',
             {'action': 'favorites_tv'},
             plot='Your saved TV shows')
    _add_dir(handle, build_url, 'Browse by Genre',
             {'action': 'meta_tv_genres'},
             plot='Browse TV shows by genre')
    _add_dir(handle, build_url, 'Search',
             {'action': 'meta_tv_search'},
             plot='Search TV shows by title')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_popular(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🔥 Popular TV Shows')
    xbmcplugin.setContent(handle, 'tvshows')

    cold  = _need_fetch('tmdb_tv_popular_%d' % page)
    dlg   = _progress('Loading popular shows...') if cold else None
    shows = meta.get_tv_popular(page=page)
    if dlg: dlg.close()

    _render_tv_list(handle, build_url, shows)
    _prewarm_tv_details(shows)
    if len(shows) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_tv_popular', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_top_rated(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '⭐ Top Rated TV Shows')
    xbmcplugin.setContent(handle, 'tvshows')

    cold  = _need_fetch('tmdb_tv_top_%d' % page)
    dlg   = _progress('Loading top rated shows...') if cold else None
    shows = meta.get_tv_top_rated(page=page)
    if dlg: dlg.close()

    _render_tv_list(handle, build_url, shows)
    _prewarm_tv_details(shows)
    if len(shows) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_tv_top', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_airing_today(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '📅 Airing Today')
    xbmcplugin.setContent(handle, 'tvshows')

    cold  = _need_fetch('tmdb_tv_airing_%d' % page)
    dlg   = _progress('Loading shows airing today...') if cold else None
    shows = meta.get_tv_airing_today(page=page)
    if dlg: dlg.close()

    _render_tv_list(handle, build_url, shows)
    _prewarm_tv_details(shows)
    if len(shows) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_tv_airing', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_genres(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎭 TV Genres')
    xbmcplugin.setContent(handle, 'files')

    cold   = _need_fetch('tmdb_tv_genres')
    dlg    = _progress('Loading genres...') if cold else None
    genres = meta.get_tv_genres()
    if dlg: dlg.close()

    for g in genres:
        _add_dir(handle, build_url,
                 label=g['name'],
                 params={'action': 'meta_tv_by_genre',
                         'genre_id': g['id'], 'genre_name': g['name'], 'page': 1},
                 plot='Browse %s shows' % g['name'])
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def tv_by_genre(handle, build_url, genre_id, genre_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '🎭 %s' % genre_name)
    xbmcplugin.setContent(handle, 'tvshows')

    cold  = _need_fetch('tmdb_tv_genre_%s_%d' % (genre_id, page))
    dlg   = _progress('Loading %s...' % genre_name) if cold else None
    shows = meta.get_tv_by_genre(genre_id, page=page)
    if dlg: dlg.close()

    _render_tv_list(handle, build_url, shows)
    _prewarm_tv_details(shows)
    if len(shows) >= PAGE_SIZE:
        _next_page(handle, build_url, 'meta_tv_by_genre', page,
                   extra={'genre_id': genre_id, 'genre_name': genre_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search TV Shows')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '🔍 TV: %s' % query)
    xbmcplugin.setContent(handle, 'tvshows')

    dlg   = _progress('Searching...')
    shows = meta.search_tv(query)
    dlg.close()

    if not shows:
        xbmcgui.Dialog().notification('TV Shows', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    _render_tv_list(handle, build_url, shows)
    _prewarm_tv_details(shows)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def tv_show_detail(handle, build_url, tmdb_id):
    """Load full show info and list seasons."""
    cold  = _need_fetch('tmdb_tv_%s' % tmdb_id)
    dlg   = _progress('Loading show info...') if cold else None
    show  = meta.get_tv_detail(tmdb_id)
    if dlg: dlg.close()

    if not show:
        xbmcgui.Dialog().notification('TV Shows', 'Could not load metadata',
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    xbmcplugin.setPluginCategory(handle, show.get('title', ''))
    xbmcplugin.setContent(handle, 'seasons')

    seasons = show.get('seasons', [])
    # Previously auto-skipped straight to episodes when len(seasons) == 1 —
    # removed after a real bug: a stale 24h cache entry for a show's detail
    # (tmdb_tv_<id>) can hold an old single-season snapshot from before later
    # seasons were added to TMDB, silently trapping the user on Season 1's
    # episode list with no way to reach Season 2+ until the cache expires.
    # Always showing the season picker costs one extra click for a genuinely
    # single-season show but is never wrong.

    # Pre-warm first season's episodes in background
    if seasons:
        first = seasons[0]
        def _prewarm_first_season():
            try:
                meta.get_episodes(tmdb_id, first['season'],
                                  show.get('tvdb_id') or None)
            except Exception:
                pass
        if _need_fetch('tmdb_season_%s_%s' % (tmdb_id, first['season'])):
            ThreadPoolExecutor(max_workers=1).submit(_prewarm_first_season)

    for s in seasons:
        label = '%s  (%d episodes)' % (s['name'], s.get('episode_count', 0))
        li    = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':   s['name'],
            'season':  s['season'],
            'plot':    s.get('overview', ''),
            'mediatype': 'season',
        })
        li.setArt({
            'thumb':  s.get('thumb', '') or show.get('thumb', ''),
            'poster': s.get('thumb', '') or show.get('thumb', ''),
            'fanart': show.get('fanart', ''),
        })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'meta_tv_episodes',
                       'tmdb_id':    tmdb_id,
                       'season_num': s['season'],
                       'tvdb_id':    show.get('tvdb_id', ''),
                       'show_title': show.get('title', ''),
                       'show_fanart': show.get('fanart', '')}),
            li, True
        )
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def tv_season_episodes(handle, build_url, tmdb_id, season_num,
                       tvdb_id='', show_title='', show_fanart=''):
    """List all episodes in a season."""
    xbmcplugin.setPluginCategory(
        handle, '%s — Season %s' % (show_title, season_num))
    xbmcplugin.setContent(handle, 'episodes')

    cold     = _need_fetch('tmdb_season_%s_%s' % (tmdb_id, season_num))
    dlg      = _progress('Loading episodes...') if cold else None
    episodes = meta.get_episodes(tmdb_id, season_num, tvdb_id or None)
    if dlg: dlg.close()

    # Confirmed live: every episode TMDB lists for a season was shown here
    # unconditionally, including ones with a blank or future air_date — a
    # season page routinely has next week's (or the whole rest of the
    # season's) episodes already listed with placeholder/no artwork long
    # before they've actually aired. Same "blank or future counts as not
    # aired yet" rule continue_watching.py's own upcoming-episode check
    # already uses, applied here so unaired episodes don't show as
    # (falsely) playable directory items at all.
    _today = time.strftime('%Y-%m-%d')
    episodes = [ep for ep in episodes if ep.get('aired') and ep.get('aired') <= _today]

    if not episodes:
        xbmcgui.Dialog().notification('TV Shows', 'No episodes found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    # Load watch history once for all episodes in this season. Must use the
    # SAME key episode_play() actually writes under — confirmed live: that
    # function resolves and writes watch_history under the show's real
    # imdb_id (needed for SIMKL sync, which only understands imdb/tvdb ids,
    # not TMDB's own), but this listing was checking watched status under
    # "tvdb_id or tmdb_id" instead — a completely different id than what
    # was actually written, so every episode always read back as unwatched
    # here regardless of what had actually been played.
    try:
        from resources.lib import watch_history as _wh
        _wh_active = True
        _wh_key = None
        try:
            show = meta.get_tv_detail(tmdb_id)
            _wh_key = show.get('imdb_id') or None
        except Exception:
            pass
        _wh_key = _wh_key or tvdb_id or tmdb_id or ''
    except Exception:
        _wh_active = False

    for ep in episodes:
        ep_label = 'S%02dE%02d — %s' % (
            int(season_num), ep['episode'], ep.get('title', ''))
        ep_playcount = 0
        if _wh_active:
            try:
                _ep_wlbl = _wh.progress_label(_wh_key, season_num, ep['episode'])
                if _ep_wlbl:
                    ep_label += _ep_wlbl
                if _wh.is_watched(_wh_key, season_num, ep['episode']):
                    ep_playcount = 1
            except Exception:
                pass
        label = ep_label
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':       ep.get('title', ''),
            'plot':        ep.get('overview', ''),
            'season':      int(season_num),
            'episode':     ep['episode'],
            'aired':       ep.get('aired', ''),
            'rating':      float(ep.get('rating', 0)),
            'duration':    int(ep.get('runtime') or 0) * 60,
            'tvshowtitle': show_title,
            'mediatype':   'episode',
            'playcount':   ep_playcount,
        })
        li.setArt({
            'thumb':  ep.get('still', ''),
            'icon':   ep.get('still', ''),
            'fanart': show_fanart,
        })
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':      'meta_ep_play',
                       'tmdb_id':     tmdb_id,
                       'season_num':  season_num,
                       'episode_num': ep['episode'],
                       'title':       '%s S%02dE%02d' % (
                           show_title, int(season_num), ep['episode'])}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_EPISODE)


def _render_tv_list(handle, build_url, shows):
    from resources.lib import cache as _rcache
    for s in shows:
        full = _rcache.get('tmdb_tv_%s' % s.get('tmdb_id', ''))
        d = full if full else s

        label = s['title']
        first_air = s.get('first_air_date', '') or ''
        if first_air and len(first_air) >= 10:
            label += '  (%s)' % first_air[:10]
        elif s.get('year'):
            label += '  (%s)' % s['year']
        if s.get('rating'):
            label += '  ★%.1f' % s['rating']

        li = xbmcgui.ListItem(label=label)
        tv_info = {
            'title':     s['title'],
            'year':      int(s['year']) if str(s.get('year', '')).isdigit() else 0,
            'rating':    float(s.get('rating', 0)),
            'plot':      s.get('overview', ''),
            'mediatype': 'tvshow',
        }
        if first_air:
            tv_info['premiered'] = first_air
        if d.get('mpaa'):
            tv_info['mpaa'] = d['mpaa']
        li.setInfo('video', tv_info)
        li.setArt({
            'thumb':  s.get('thumb', ''),
            'poster': s.get('thumb', ''),
            'fanart': s.get('fanart', ''),
        })
        # Context menu: Add / Remove from Favorites
        try:
            from resources.lib import favorites as _fav
            if _fav.is_favorite('tv', s['tmdb_id']):
                fav_label = 'Remove from Favorites'
                fav_action = 'favorites_remove'
            else:
                fav_label = 'Add to Favorites'
                fav_action = 'favorites_add'
            li.addContextMenuItems([(fav_label, 'RunPlugin(%s)' % build_url({
                'action':     fav_action,
                'media_type': 'tv',
                'tmdb_id':    s['tmdb_id'],
                'title':      s['title'],
                'year':       str(s.get('year', '') or ''),
                'imdb_id':    s.get('imdb_id', ''),
                'thumb':      s.get('thumb', ''),
                'fanart':     s.get('fanart', ''),
            }))])
        except Exception:
            pass

        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'meta_tv_show',
                       'tmdb_id': s['tmdb_id']}),
            li, True
        )


# ── Playback placeholders (stream URL supplied externally) ────────────────────

def _resolve_stream_url(url):
    """
    Resolve an embed or hoster URL to a direct playable stream URL.
    Tries embed_resolver first (internal), then ResolveURL addon.
    Returns the resolved URL, or the original if resolution fails/isn't needed.
    """
    if not url or url.startswith('magnet:') or url.startswith('plugin://'):
        return url

    # Step 1: try our internal embed resolver (MixDrop, DoodStream, Streamtape, VidSrc, etc.)
    try:
        from resources.lib import embed_resolver as _er
        resolved = _er.resolve(url)
        if resolved and resolved != url:
            xbmc.log('[Starfleet] embed_resolver: %s' % resolved[:80], xbmc.LOGINFO)
            return resolved
    except Exception as e:
        xbmc.log('[Starfleet] embed_resolver error: %s' % e, xbmc.LOGWARNING)

    # Step 2: try ResolveURL addon for supported hosters
    try:
        import resolveurl as _ru
        hmf = _ru.HostedMediaFile(url)
        if hmf.valid_url():
            resolved = hmf.resolve()
            if resolved:
                xbmc.log('[Starfleet] ResolveURL: %s' % resolved[:80], xbmc.LOGINFO)
                return resolved
    except ImportError:
        pass
    except Exception as e:
        xbmc.log('[Starfleet] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    return url


# Highest-to-lowest — only torrent/debrid release names and personal-source
# labels reliably state real resolution, so this only ever runs against
# those two groups (see _sort_by_quality below), never free/embed hosters.
#
# Must cover every label torrent_sources._extract_quality() can actually
# return, not just resolution numbers — confirmed live this was silently
# missing 'Blu-ray'/'WEB-DL'/'WEBRip'/'HDTV'/'3D', so any torrent whose
# only detected quality was one of those (common — many real releases
# don't carry an explicit resolution tag at all, just BluRay/WEB-DL) sank
# to the bottom of the picker as "no quality detected" even though it
# genuinely had one; this is why a real 4K/good release could "seem" to
# have no quality shown even when torrent_sources.py itself extracted it
# correctly (verified separately, live, against real Torrentio results).
_QUALITY_RE = re.compile(
    r'\b(2160p|4k|1080p|720p|480p|360p|blu-ray|bluray|web-dl|webdl|webrip|hdtv|3d|hdcam|hdts|dvdscr|cam)\b',
    re.IGNORECASE
)
_QUALITY_RANK = {
    '2160p': 7, '4k': 7,
    '1080p': 6,
    '720p':  5,
    'blu-ray': 4, 'bluray': 4, 'web-dl': 4, 'webdl': 4, 'webrip': 4, 'hdtv': 4, '3d': 4,
    '480p': 3,
    '360p': 2,
    'hdcam': 1, 'hdts': 1, 'dvdscr': 1, 'cam': 1,
}


def _sort_by_quality(sources):
    """Stable sort by detected quality tier, highest first. Anything with
    no detectable quality tag (rank 0) sinks to the bottom of this group
    but stays above the separate free-hoster bucket, which is appended
    after this regardless of sort result."""
    def _rank(s):
        m = _QUALITY_RE.search(s.get('label', ''))
        return _QUALITY_RANK.get(m.group(1).lower(), 0) if m else 0
    return sorted(sources, key=_rank, reverse=True)


def _unified_source_search(handle, title, year=None, media_type='movie', imdb_id=None,
                           season=None, episode=None, trailer_url=None, tmdb_id=None):
    """
    Search free sources, embed providers, AND torrent/debrid in parallel.
    Shows a unified source picker dialog, then plays the chosen stream.
    Order: trailer first, then personal/torrent/debrid sorted by real
    declared quality (4K/2160p down to SD), then free/embed hosters last.
    """
    pd = _pdlg.DialogProgress()
    pd.create('Starfleet', 'Searching best available sources...')
    pd.update(5)

    def _search_free():
        try:
            from resources.lib import free_sources as _fs
            return _fs.search_free_streams(title, year=year, media_type=media_type,
                                           imdb_id=imdb_id, season=season, episode=episode)
        except Exception as e:
            xbmc.log('[Starfleet] free_sources error: %s' % e, xbmc.LOGERROR)
            return []

    def _search_embed():
        try:
            from resources.lib import embed_sources as _es
            return _es.search_embed_providers(imdb_id, media_type, season, episode)
        except Exception as e:
            xbmc.log('[Starfleet] embed_sources error: %s' % e, xbmc.LOGERROR)
            return []

    def _search_debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            return _dt.get_debrid_streams(title, year=year, media_type=media_type,
                                          imdb_id=imdb_id, season=season, episode=episode,
                                          tmdb_id=tmdb_id)
        except Exception as e:
            xbmc.log('[Starfleet] debrid_torrent error: %s' % e, xbmc.LOGERROR)
            return []

    def _search_personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(title, year=year, media_type=media_type,
                                       imdb_id=imdb_id, season=season, episode=episode)
        except Exception as e:
            xbmc.log('[Starfleet] personal_sources error: %s' % e, xbmc.LOGERROR)
            return []

    def _search_easynews():
        try:
            from resources.lib import easynews_sources as _en
            return _en.search_easynews(title, year=year, media_type=media_type)
        except Exception as e:
            xbmc.log('[Starfleet] easynews_sources error: %s' % e, xbmc.LOGERROR)
            return []

    def _search_requests():
        """Manually curated Requests JSON (resources/lib/request_sources.py)
        — matched exactly by imdb_id (movies) or title+season+episode (TV)
        rather than fuzzy title search, per direct request. Real, hand-
        picked links, not a scraper — shown first in the picker below.
        One matched entry can carry several candidate urls
        (request_sources.entry_urls) — every one of them gets its own
        [Request] line here, numbered when there's more than one, rather
        than only ever surfacing the first and silently dropping the
        rest."""
        try:
            from resources.lib import request_sources as _reqsrc
            if media_type == 'movie':
                match = _reqsrc.find_movie_request(imdb_id)
            elif media_type == 'tv':
                match = _reqsrc.find_tv_request(title, season, episode)
            else:
                match = None
            if not match:
                return []
            urls = _reqsrc.entry_urls(match)
            label_base = match.get('title') or title
            results = []
            for i, u in enumerate(urls, 1):
                resolved = _reqsrc.resolve_request_stream(u)
                if not resolved:
                    continue
                label = '[Request] %s' % label_base if len(urls) == 1 else \
                        '[Request] %s (Source %d)' % (label_base, i)
                results.append({'label': label, 'url': resolved})
            return results
        except Exception as e:
            xbmc.log('[Starfleet] request_sources error: %s' % e, xbmc.LOGERROR)
            return []

    def _run_search_pass():
        # NOT a `with` block on purpose: ThreadPoolExecutor.__exit__ always
        # calls shutdown(wait=True), which blocks until every submitted task
        # actually finishes — even ones already abandoned past their own
        # .result(timeout=X) below. Fixed once already (same footgun already
        # fixed in debrid_torrent.py's inner pool), but the ~98s hang this
        # was meant to fix persisted after that alone — see the real cause
        # below.
        #
        # The actual cause, confirmed live via kodi.log timestamps: personal/
        # free/embed/debrid all run concurrently in the pool, but were each
        # awaited with their OWN separate .result(timeout=X) call, one after
        # another, in sequence. Those timeouts stack ADDITIVELY even though
        # the work itself overlaps — if personal genuinely burns its full 15s
        # (thread stuck/slow) before the code even looks at free's future,
        # then free burns its own full 45s, then embed its own 18s, that's
        # 15+45+18=78s of pure sequential waiting BEFORE debrid is even
        # checked, regardless of debrid having finished in under 10s in the
        # background the whole time. Confirmed exactly this: one real run
        # had every debrid stream resolved within ~8.5s, yet the picker
        # still didn't appear for another ~98s — nothing in the debrid path
        # itself was slow, the wait was purely this stacking bug.
        #
        # First attempt at a fix collapsed all four onto one shared 110s
        # deadline via as_completed(...) — that removed the additive
        # stacking, but introduced a different problem: personal/free/embed
        # were deliberately given SMALLER budgets (15/45/18s) because
        # they're lower-priority/less-trustworthy sources, and a single
        # shared deadline let a stuck one of those run all the way out to
        # debrid's much longer 110s instead of being cut off at its own,
        # smaller budget — so a stall in personal/free/embed could still
        # make the whole search take just as long as before.
        # Real fix: poll all four concurrently, but give each its own
        # deadline (start + its own budget) — a task is dropped (treated as
        # empty) the moment ITS OWN budget elapses, regardless of what the
        # others are still doing, so total wait is bounded by the largest
        # single budget (110s, debrid's) only if debrid itself is what's
        # slow — not inflated by a stuck lower-priority source.
        pool = ThreadPoolExecutor(max_workers=6)
        try:
            start = time.time()
            budgets = {
                'personal':  (pool.submit(_search_personal),  15),
                'easynews':  (pool.submit(_search_easynews),  15),
                'requests':  (pool.submit(_search_requests),  15),
                'free':      (pool.submit(_search_free),      45),
                'embed':     (pool.submit(_search_embed),     18),
                # Was 110s. torrent_sources.search_all() itself (the bulk
                # of this branch's work) already caps at 25s internally,
                # plus a handful of small fixed-cost calls around it
                # (Cinemeta IMDB lookup, AllDebrid-library check, cumulative
                # magnet-library fetch) that together add at most another
                # ~15-20s even in a bad run - 60s leaves real headroom
                # above that worst case without leaving a stalled run to
                # eat nearly two full minutes before the picker gives up on
                # it, compared to gears' equivalent search phase (~20s).
                'debrid':   (pool.submit(_search_debrid),   60),
            }
            pd.update(20)

            collected = {}
            pending = dict(budgets)
            user_canceled = False
            while pending:
                # Confirmed live this is the real reason Cancel visibly did
                # nothing on this specific dialog (up to a 60s wait, the
                # longest budget above) while it works fine on the
                # next-episode countdown: that dialog's own wait loop polls
                # iscanceled() every second it's showing, so a click always
                # gets picked up on the very next iteration - this loop
                # never called iscanceled() at all, so nothing here could
                # ever have responded to a click no matter how reliably the
                # dialog itself routed it. Not the same "Cancel sometimes
                # doesn't register" issue progress_dialog.py's own docstring
                # already documents for short spinner-style uses of this
                # dialog - this is a real gap in THIS loop specifically,
                # checked every 0.25s same as the rest of the loop already
                # polls at.
                if pd.iscanceled():
                    user_canceled = True
                    break
                elapsed = time.time() - start
                done_now = []
                for name, (fut, budget) in pending.items():
                    if fut.done():
                        try:
                            collected[name] = fut.result()
                        except Exception:
                            collected[name] = []
                        done_now.append(name)
                    elif elapsed >= budget:
                        # This task's own budget ran out — stop waiting on
                        # it specifically; it keeps running in the
                        # background (abandoned, discarded via
                        # shutdown(wait=False) below) but no longer holds
                        # up the others.
                        collected[name] = []
                        done_now.append(name)
                for name in done_now:
                    xbmc.log('[Starfleet/Timing] %s settled at %.1fs' % (name, elapsed),
                             xbmc.LOGINFO)
                    del pending[name]
                if pending:
                    time.sleep(0.25)
            if user_canceled:
                xbmc.log('[Starfleet/Timing] _run_search_pass canceled by user at %.1fs' %
                         (time.time() - start), xbmc.LOGINFO)
                return None
            xbmc.log('[Starfleet/Timing] _run_search_pass total wait: %.1fs' %
                     (time.time() - start), xbmc.LOGINFO)
            pd.update(70)

            personal_results  = collected.get('personal', [])
            easynews_results  = collected.get('easynews', [])
            requests_results  = collected.get('requests', [])
            free_results      = collected.get('free', [])
            embed_results     = collected.get('embed', [])
            debrid_results    = collected.get('debrid', [])
        finally:
            pool.shutdown(wait=False)

        # debrid_torrent.py already builds a "[Torrent] Source Quality"
        # label for magnet results — re-wrapping it here duplicated the
        # "[Torrent] " prefix (confirmed live: real labels read
        # "[Torrent] [Torrent] Torrentio 4K"), so this only adds the
        # "[Debrid] " prefix for the actual non-magnet debrid-link case,
        # which never has one of its own. NZB results are also a non-magnet
        # URL and used to fall into that same "else" branch, which rebuilt
        # a brand-new dict without the 'is_nzb' flag - confirmed live via
        # kodi.log that this made the play code below fall straight through
        # to the generic "just play this URL" path instead of routing
        # through resolve_nzb()/Premiumize, handing Kodi's player the raw
        # binsearch.info search-page URL directly (which of course isn't a
        # media file - FFmpeg immediately failed to probe it). NZB entries
        # now get their own branch that preserves the flag and keeps their
        # already-correct label untouched (already carries [NZB] plus the
        # real release title/quality tags, not a "[Debrid] " prefix).
        debrid_sources = []
        for s in debrid_results:
            if s.get('is_nzb'):
                debrid_sources.append({'label': s['label'], 'url': s['url'], 'is_nzb': True})
            elif s['url'].startswith('magnet:'):
                debrid_sources.append({'label': s['label'], 'url': s['url'], 'quality': s.get('quality', '')})
            else:
                debrid_sources.append({'label': '[Debrid] %s' % s['label'], 'url': s['url']})
        embed_sources_labeled = [
            {'label': '[Embed] %s' % s['label'], 'url': s['url']}
            for s in embed_results
        ]
        easynews_sources_labeled = [
            {'label': '[Easynews] %s' % s['label'], 'url': s['url']}
            for s in easynews_results
        ]
        quality_ranked = _sort_by_quality(personal_results + debrid_sources + easynews_sources_labeled)
        free_hosters   = free_results + embed_sources_labeled
        # Requests (resources/lib/request_sources.py) are exact-matched,
        # hand-picked links, not a scraper guess — shown ahead of even the
        # free-hoster bucket per direct request.
        return requests_results + free_hosters + quality_ranked

    combined_sources = _run_search_pass()
    if combined_sources is None:
        # User canceled the search dialog itself — stop here, same exit
        # path already used below for "no sources found"/"picker canceled",
        # not the empty-results retry (that's for a genuinely empty pass,
        # not a user-requested stop).
        pd.close()
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    if not combined_sources:
        xbmc.log('[Starfleet/Timing] first pass returned 0 combined sources — retrying', xbmc.LOGWARNING)
        # Live scraping across a dozen+ torrent/embed sites is inherently
        # a little flaky moment to moment — a Cloudflare block or
        # rate-limit hitting a couple of sites at the exact instant this
        # runs can knock a whole pass down to zero. Confirmed live: the
        # exact same episode returned "No sources found" once, then found
        # 15 torrents and resolved working debrid streams on an
        # unmodified retry seconds later. One automatic retry here before
        # actually giving up costs a few extra seconds but catches
        # exactly that transient case instead of forcing the user to
        # back out and try again themselves.
        pd.update(75, 'No sources found — retrying once...')
        combined_sources = _run_search_pass()
        if combined_sources is None:
            pd.close()
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return

    pd.close()

    # Get watched label suffix for the picker
    try:
        from resources.lib import watch_history as _wh
        _wlabel = _wh.progress_label(imdb_id or '', season or 0, episode or 0)
    except Exception:
        _wlabel = ''

    # Order: trailer always first, then free hosters/embeds (no cost, no
    # debrid/account needed) — per direct request — then everything with a
    # real declared quality (personal sources, torrent/debrid — the only
    # ones that actually state resolution in their name) sorted 4K/2160p
    # down to SD.
    trailer_sources = []
    if trailer_url:
        trailer_sources = [{'label': '[Trailer] Watch Trailer', 'url': trailer_url}]

    all_sources = trailer_sources + combined_sources
    if _wlabel:
        for s in all_sources:
            s['label'] = s['label'] + _wlabel

    if not all_sources:
        xbmcgui.Dialog().notification(
            'Starfleet',
            'No sources found for "%s"' % title,
            xbmcgui.NOTIFICATION_WARNING,
            5000
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(all_sources) == 1:
        chosen = all_sources[0]
    else:
        idx = _select_dialog(
            '"%s" — Choose source' % title,
            [s['label'] for s in all_sources]
        )
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = all_sources[idx]

    chosen_url = chosen['url']
    # A trailer pick has nothing to do with the movie/episode's own saved
    # progress (it's a separate few-minute video) — resume must never be
    # applied to it, or picking Trailer after a mostly-watched title would
    # try to seek past the trailer's whole runtime.
    _is_trailer = str(chosen.get('label', '')).startswith('[Trailer]')

    def _on_finished(finished):
        # Only relevant for TV episodes with a real tmdb_id to look up the
        # next one from; a manual early stop (finished=False, <90% played)
        # never triggers it, same threshold the 'watched' flag itself uses.
        if not (finished and media_type == 'tv' and season and episode and tmdb_id):
            return
        try:
            if xbmcaddon.Addon('plugin.video.starfleet').getSetting('tv_autoplay_next') != 'true':
                return
        except Exception:
            return
        _autoplay_next_episode(tmdb_id, season, episode)

    # Magnet links: try enabled debrid services first (instant-cache only
    # — see resolvers.resolve_magnet_candidates' own docstring), Elementum
    # only as the fallback for whatever they can't resolve. Confirmed live
    # this was unconditionally hitting Elementum before, regardless of
    # which debrid services were enabled — resolve_magnet() didn't exist
    # yet.
    #
    # Pass along a few other same-quality-tier magnet candidates too, not
    # just the one clicked — resolve_magnet_candidates quick-checks each
    # for an instant cache hit before ever committing to a real wait, so
    # picking "a 1080p option" is much more likely to just play immediately
    # even if this EXACT release isn't the one that happens to be cached.
    if chosen_url.startswith('magnet:'):
        try:
            from resources.lib import resolvers as _resolvers
            _same_tier = [
                s['url'] for s in all_sources
                if s is not chosen and s.get('url', '').startswith('magnet:')
                and s.get('quality') == chosen.get('quality')
            ][:6]
            debrid_resolved = _resolvers.resolve_magnet_candidates([chosen_url] + _same_tier,
                                                                    season=season, episode=episode)
        except Exception as e:
            xbmc.log('[Starfleet] resolve_magnet error: %s' % e, xbmc.LOGWARNING)
            debrid_resolved = None

        if debrid_resolved:
            xbmc.log('[Starfleet] Magnet resolved via debrid: %s' % debrid_resolved[:80],
                     xbmc.LOGINFO)
            dli = xbmcgui.ListItem(path=debrid_resolved)
            dli.setContentLookup(False)
            dli.setInfo('video', {
                'title':      title,
                'year':       int(year) if year else 0,
                'imdbnumber': imdb_id or '',
                'mediatype':  'episode' if media_type == 'tv' else 'movie',
                'season':     int(season)  if season  else 0,
                'episode':    int(episode) if episode else 0,
            })
            _url_lc = debrid_resolved.lower()
            if '.m3u8' in _url_lc:
                dli.setMimeType('application/x-mpegURL')
            elif '.mp4' in _url_lc:
                dli.setMimeType('video/mp4')
            elif '.mkv' in _url_lc:
                dli.setMimeType('video/x-matroska')
            if not _is_trailer:
                try:
                    from resources.lib import watch_history as _wh0
                    _wh0.apply_resume(dli, imdb_id or '', season=season or 0, episode=episode or 0, tmdb_id=tmdb_id)
                except Exception:
                    pass
            xbmcplugin.setResolvedUrl(handle, True, dli)
            try:
                from resources.lib import watch_history as _wh
                _wh.start_playback_monitor(imdb_id or '', title=title,
                                           season=season or 0, episode=episode or 0,
                                           tmdb_id=tmdb_id, on_finished=_on_finished)
            except Exception:
                pass
            return

    # NZB links: same deferred-resolution shape as magnets above, but
    # there's no Elementum-style P2P fallback for Usenet (no swarm to fall
    # back to) — if Premiumize/TorBox don't have it cached, this specific
    # release just isn't playable right now, so report that cleanly
    # instead of falling through to the magnet-only Elementum logic below
    # (which chosen_url wouldn't match anyway, since it's an http(s) NZB
    # link, not a magnet: URI).
    if chosen.get('is_nzb'):
        try:
            from resources.lib import resolvers as _resolvers
            debrid_resolved = _resolvers.resolve_nzb(chosen_url, title=title, media_type=media_type,
                                                      season=season, episode=episode)
        except Exception as e:
            xbmc.log('[Starfleet] resolve_nzb error: %s' % e, xbmc.LOGWARNING)
            debrid_resolved = None

        if debrid_resolved:
            xbmc.log('[Starfleet] NZB resolved via debrid: %s' % debrid_resolved[:80],
                     xbmc.LOGINFO)
            dli = xbmcgui.ListItem(path=debrid_resolved)
            dli.setContentLookup(False)
            dli.setInfo('video', {
                'title':      title,
                'year':       int(year) if year else 0,
                'imdbnumber': imdb_id or '',
                'mediatype':  'episode' if media_type == 'tv' else 'movie',
                'season':     int(season)  if season  else 0,
                'episode':    int(episode) if episode else 0,
            })
            _url_lc = debrid_resolved.lower()
            if '.m3u8' in _url_lc:
                dli.setMimeType('application/x-mpegURL')
            elif '.mp4' in _url_lc:
                dli.setMimeType('video/mp4')
            elif '.mkv' in _url_lc:
                dli.setMimeType('video/x-matroska')
            try:
                from resources.lib import watch_history as _wh0
                _wh0.apply_resume(dli, imdb_id or '', season=season or 0, episode=episode or 0, tmdb_id=tmdb_id)
            except Exception:
                pass
            xbmcplugin.setResolvedUrl(handle, True, dli)
            try:
                from resources.lib import watch_history as _wh
                _wh.start_playback_monitor(imdb_id or '', title=title,
                                           season=season or 0, episode=episode or 0,
                                           tmdb_id=tmdb_id, on_finished=_on_finished)
            except Exception:
                pass
            return

        xbmcgui.Dialog().notification(
            'Starfleet', 'Debrid could not resolve this NZB',
            xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # No debrid cache hit — route magnet links through Elementum, but ONLY
    # when no debrid service is enabled at all. Per explicit instruction:
    # once any debrid service is on, a magnet it couldn't resolve should
    # fail cleanly instead of falling through to Elementum anyway —
    # Elementum is the fallback for the no-debrid-configured case only.
    if chosen_url.startswith('magnet:'):
        try:
            from resources.lib import resolvers as _resolvers
            if _resolvers.any_debrid_enabled():
                xbmc.log('[Starfleet] Debrid enabled but could not resolve this magnet — '
                         'not falling back to Elementum per current policy', xbmc.LOGWARNING)
                xbmcgui.Dialog().notification(
                    'Starfleet', 'Debrid could not resolve this torrent',
                    xbmcgui.NOTIFICATION_WARNING, 4000)
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                return
        except Exception as e:
            xbmc.log('[Starfleet] any_debrid_enabled check error: %s' % e, xbmc.LOGWARNING)

        import xbmcaddon as _xba
        elementum_ok = False
        elementum_broken = False
        try:
            _elem_addon = _xba.Addon('plugin.video.elementum')
            # Verify the bundled site-packages include platform_detect (missing in some builds)
            import os as _os
            _elem_path = _elem_addon.getAddonInfo('path')
            _site = _os.path.join(_elem_path, 'resources', 'site-packages')
            if _os.path.isdir(_os.path.join(_site, 'platform_detect')):
                elementum_ok = True
            else:
                elementum_broken = True
        except Exception:
            pass
        if elementum_broken:
            xbmc.log('[Starfleet] Elementum missing platform_detect — auto-repairing from elementumorg', xbmc.LOGWARNING)
            _install_elementum_via_repo()
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        if not elementum_ok:
            xbmc.log('[Starfleet] Elementum not installed — installing directly', xbmc.LOGINFO)
            _install_elementum_via_repo()
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        import urllib.parse as _ul
        elementum_url = 'plugin://plugin.video.elementum/play?uri=' + _ul.quote(chosen_url, safe='')
        xbmc.log('[Starfleet] Routing magnet via Elementum: ' + elementum_url[:80], xbmc.LOGINFO)
        eli = xbmcgui.ListItem(path=elementum_url)
        eli.setInfo('video', {
            'title':      title,
            'year':       int(year) if year else 0,
            'imdbnumber': imdb_id or '',
            'mediatype':  'episode' if media_type == 'tv' else 'movie',
            'season':     int(season)  if season  else 0,
            'episode':    int(episode) if episode else 0,
        })
        if not _is_trailer:
            try:
                from resources.lib import watch_history as _wh0
                _wh0.apply_resume(eli, imdb_id or '', season=season or 0, episode=episode or 0, tmdb_id=tmdb_id)
            except Exception:
                pass
        xbmcplugin.setResolvedUrl(handle, True, eli)
        try:
            from resources.lib import watch_history as _wh
            _wh.start_playback_monitor(imdb_id or '', title=title,
                                       season=season or 0, episode=episode or 0,
                                       tmdb_id=tmdb_id, on_finished=_on_finished)
        except Exception:
            pass
        return

    # Resolve embed/hoster URLs to direct playable streams
    play_url = _resolve_stream_url(chosen_url)

    li = xbmcgui.ListItem(path=play_url)
    li.setContentLookup(False)
    li.setInfo('video', {
        'title':      title,
        'year':       int(year) if year else 0,
        'imdbnumber': imdb_id or '',
        'mediatype':  'episode' if media_type == 'tv' else 'movie',
        'season':     int(season)  if season  else 0,
        'episode':    int(episode) if episode else 0,
    })
    # Set mime type based on URL extension to help Kodi pick the right player
    play_lower = play_url.lower()
    if '.m3u8' in play_lower:
        li.setMimeType('application/x-mpegURL')
        # inputstream.adaptive is required for HLS on Android (and preferred on all platforms)
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    elif '.mp4' in play_lower:
        li.setMimeType('video/mp4')
    elif '.mkv' in play_lower:
        li.setMimeType('video/x-matroska')
    if not _is_trailer:
        try:
            from resources.lib import watch_history as _wh0
            _wh0.apply_resume(li, imdb_id or '', season=season or 0, episode=episode or 0, tmdb_id=tmdb_id)
        except Exception:
            pass
    xbmcplugin.setResolvedUrl(handle, True, li)
    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor(imdb_id or '', title=title,
                                   season=season or 0, episode=episode or 0,
                                   tmdb_id=tmdb_id, on_finished=_on_finished)
    except Exception:
        pass


def _autoplay_next_episode(tmdb_id, season, episode):
    """Resolves and plays the next episode after the just-finished one,
    behind a short cancellable countdown. Called from the playback
    monitor's on_finished callback, so it runs on a background thread —
    xbmc.Player().play()/DialogProgress are safe to drive from there, the
    same pattern already used for direct-play (e.g. adult_ade_play_direct).
    Deliberately reuses the normal meta_ep_play plugin:// action for the
    actual play, rather than re-implementing source resolution here, so
    the next episode gets its own picker (if needed) and its own
    _unified_source_search()/on_finished chain — that's what makes this
    keep auto-advancing across an entire season/series, not just once."""
    from urllib.parse import quote
    try:
        from resources.lib import metadata as _meta
        show = _meta.get_tv_detail(tmdb_id) or {}
        show_title = show.get('title', '')
        episodes = _meta.get_episodes(tmdb_id, season) or []
        next_ep, next_season = None, season
        for i, ep in enumerate(episodes):
            if int(ep.get('episode', 0)) == int(episode):
                if i + 1 < len(episodes):
                    next_ep = episodes[i + 1]
                break
        if not next_ep:
            # metadata.get_tv_detail()'s season dicts key the season number
            # as 'season' (matches home.py's own _open_tv_seasons reading
            # of it), not 'season_num' — that's only the name this
            # addon's own item dicts use once mapped for display.
            later_seasons = sorted(
                int(s['season']) for s in show.get('seasons', [])
                if s.get('season') and int(s['season']) > int(season)
            )
            if later_seasons:
                next_season = later_seasons[0]
                next_eps = _meta.get_episodes(tmdb_id, next_season) or []
                if next_eps:
                    next_ep = next_eps[0]
        if not next_ep:
            return  # Series finished — nothing left to auto-play
        # Same "blank or future air_date means not aired yet" rule applied
        # in tv_season_episodes()/continue_watching.py — without this,
        # finishing the latest-aired episode auto-advanced straight into
        # TMDB's already-listed-but-not-yet-released next episode, which
        # has no real source to find yet.
        if not next_ep.get('aired') or next_ep.get('aired') > time.strftime('%Y-%m-%d'):
            return
    except Exception as e:
        xbmc.log('[Starfleet] _autoplay_next_episode lookup: %s' % e, xbmc.LOGERROR)
        return

    next_ep_num = next_ep.get('episode', 0)
    next_title = '%s S%02dE%02d — %s' % (
        show_title, int(next_season), int(next_ep_num), next_ep.get('title', ''))

    try:
        secs = int(xbmcaddon.Addon('plugin.video.starfleet').getSetting('tv_autoplay_countdown') or '8')
    except Exception:
        secs = 8

    dp = _pdlg.DialogProgress()
    dp.create('Starfleet', 'Up next: %s' % next_title)
    monitor = xbmc.Monitor()
    canceled = False
    for remaining in range(secs, 0, -1):
        if dp.iscanceled():
            canceled = True
            break
        dp.update(int((secs - remaining + 1) * 100 / secs) if secs else 100,
                  'Playing in %ds — select Cancel to stop' % remaining)
        if monitor.waitForAbort(1):
            canceled = True
            break
    dp.close()
    if canceled:
        return

    ep_title_q = quote('%s S%02dE%02d' % (show_title, int(next_season), int(next_ep_num)))
    url = ('plugin://plugin.video.starfleet/?action=meta_ep_play'
           '&tmdb_id=%s&season_num=%s&episode_num=%s&title=%s' % (
               tmdb_id, next_season, next_ep_num, ep_title_q))
    li = xbmcgui.ListItem(next_title)
    li.setProperty('IsPlayable', 'true')
    xbmc.Player().play(url, li)


def movie_play(handle, tmdb_id='', title='', imdb_id='', year=''):
    """Search free + torrent/debrid sources for a movie and show a picker."""
    if not title:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    resolved_imdb = imdb_id or None
    trailer_url = None
    if tmdb_id:
        try:
            from resources.lib import metadata as _md
            film = _md.get_movie_detail(tmdb_id)
            resolved_imdb = resolved_imdb or film.get('imdb_id') or None
            trailer_url = film.get('trailer') or None
        except Exception:
            pass
    _unified_source_search(handle, title, year=year or None, media_type='movie',
                           imdb_id=resolved_imdb, trailer_url=trailer_url,
                           tmdb_id=tmdb_id or None)


def episode_play(handle, tmdb_id='', season_num=1, episode_num=1, title='', year='',
                 imdb_id=''):
    """Search free + torrent/debrid sources for a TV episode and show a picker."""
    if not title:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    resolved_imdb = imdb_id or None
    if not resolved_imdb and tmdb_id:
        try:
            from resources.lib import metadata as _md
            show = _md.get_tv_detail(tmdb_id)
            resolved_imdb = show.get('imdb_id') or None
        except Exception:
            pass
    # title is already "Show S01E01" (set by tv_season_episodes)
    _unified_source_search(handle, title, year=year or None, media_type='tv',
                           imdb_id=resolved_imdb, tmdb_id=tmdb_id or None,
                           season=int(season_num), episode=int(episode_num))


# ── Person / Actor search ─────────────────────────────────────────────────────

def person_movies(handle, build_url, name, media_type='movie'):
    """Filmography for an actor, by name.

    Previously called meta.search_movies(name)/search_tv(name) — TMDB's
    /search/movie and /search/tv only match TITLES, so searching for e.g.
    "Tom Cruise" as if it were a movie title always returned zero results.
    Now resolves the name to a real TMDB person id via search_person()
    first, then pulls their actual cast credits."""
    xbmcplugin.setPluginCategory(handle, '👤 %s' % name)
    xbmcplugin.setContent(handle, 'movies' if media_type == 'movie' else 'tvshows')

    dlg   = _progress('Searching for %s...' % name)
    people = meta.search_person(name)
    if people:
        if media_type == 'movie':
            results = meta.get_person_movie_credits(people[0]['person_id'])
        else:
            results = meta.get_person_tv_credits(people[0]['person_id'])
    else:
        results = []
    dlg.close()

    if media_type == 'movie':
        _render_movie_list(handle, build_url, results)
    else:
        _render_tv_list(handle, build_url, results)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
