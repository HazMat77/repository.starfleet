# -*- coding: utf-8 -*-
"""
resources/lib/free_router.py

Kodi UI for the Free Streaming section.

Menu:
  Free Streaming ? Movies ? [service list] ? Browse movies ? click ? dialog(debrid sources) ? play
  Free Streaming ? TV Shows ? [service list] ? Browse shows ? click ? episodes ? play

For scrapable sites (BounceTV): shows scraped catalog with TMDB art.
For JS-rendered sites: shows TMDB popular content labelled as available on that service.

Play dialog uses the torrent debrid pipeline (720p+).
"""

import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmcplugin

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')


def _progress(msg):
    d = xbmcgui.DialogProgress()
    d.create('Starfleet', msg)
    d.update(5)
    return d


# ?? Free streaming top-level menu (movies vs TV) ??????????????????????????????

def free_menu(handle, build_url):
    """Top-level free streaming menu ? Movies and TV Shows."""
    xbmcplugin.setPluginCategory(handle, '?  Free Streaming')
    xbmcplugin.setContent(handle, 'files')

    li = xbmcgui.ListItem(label='?  Free Movies')
    li.setArt({'thumb': 'https://www.popcornflix.com/favicon.ico',
               'icon':  'https://www.popcornflix.com/favicon.ico'})
    xbmcplugin.addDirectoryItem(
        handle, build_url({'action': 'free_services', 'media_type': 'movies'}), li, True)

    li = xbmcgui.ListItem(label='?  Free TV Shows')
    li.setArt({'thumb': 'https://www.bouncetv.com/favicon.ico',
               'icon':  'https://www.bouncetv.com/favicon.ico'})
    xbmcplugin.addDirectoryItem(
        handle, build_url({'action': 'free_services', 'media_type': 'tv'}), li, True)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ?? Service list ??????????????????????????????????????????????????????????????

def free_services(handle, build_url, media_type='movies'):
    """List available free services for movies or TV."""
    from resources.lib import free_sources as _fs

    label = 'Free Movies' if media_type == 'movies' else 'Free TV Shows'
    xbmcplugin.setPluginCategory(handle, '?  %s' % label)
    xbmcplugin.setContent(handle, 'files')

    services = _fs.get_free_services(media_type)

    for svc in services:
        li = xbmcgui.ListItem(label=svc['label'])
        li.setArt({'thumb': svc['icon'], 'icon': svc['icon']})
        li.setInfo('video', {'plot': 'Browse %s available on %s' % (
            'movies' if media_type == 'movies' else 'TV shows', svc['label'])})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':     'free_browse',
                       'service_id': svc['id'],
                       'media_type': media_type,
                       'page':       '1'}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ?? Browse content for a service ?????????????????????????????????????????????

def free_browse(handle, build_url, service_id, media_type='movies', page=1):
    """Browse movies or TV shows available on a specific free service."""
    from resources.lib import free_sources as _fs
    from resources.lib import metadata_router as _mr

    # Look up service metadata
    services = {s['id']: s for s in _fs.FREE_SERVICES}
    svc = services.get(service_id, {})
    svc_label = svc.get('label', service_id)

    label = '%s ? %s' % (svc_label, 'Movies' if media_type == 'movies' else 'TV Shows')
    xbmcplugin.setPluginCategory(handle, label)
    xbmcplugin.setContent(handle, 'movies' if media_type == 'movies' else 'tvshows')

    dlg = _progress('Loading %s...' % svc_label)

    if service_id == 'archive':
        items = _fs.get_archive_movies(page=page)
    elif service_id == 'popcornflix' and media_type == 'movies':
        items = _fs.get_popcornflix_movies(page=page)
    elif service_id == 'bouncetv' and media_type == 'tv':
        # BounceTV: scrape actual show list + enrich with TMDB
        items = _get_bouncetv_enriched(page)
    elif media_type == 'movies':
        items = _fs.get_free_movies_tmdb(service_id=service_id, page=page)
    else:
        items = _fs.get_free_tv_tmdb(service_id=service_id, page=page)

    dlg.close()

    if not items:
        xbmcgui.Dialog().notification('Starfleet', 'No content found', xbmcgui.NOTIFICATION_INFO)
        return

    if media_type == 'movies':
        _render_free_movies(handle, build_url, items, svc_label)
    else:
        _render_free_tv(handle, build_url, items, svc_label)

    # Next page
    li = xbmcgui.ListItem(label='?  Next Page (%d)' % (page + 1))
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({'action': 'free_browse', 'service_id': service_id,
                   'media_type': media_type, 'page': str(page + 1)}),
        li, True
    )
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def _get_bouncetv_enriched(page=1):
    """Get BounceTV shows enriched with TMDB metadata."""
    from resources.lib import free_sources as _fs
    from resources.lib import metadata as meta

    shows = _fs.get_bouncetv_shows()
    # Paginate
    per_page = 20
    start = (page - 1) * per_page
    page_shows = shows[start:start + per_page]

    enriched = []
    for show in page_shows:
        # Search TMDB for this show title
        results = meta.search_tv(show['title'])
        if results:
            tv = results[0]
            # Prefer BounceTV thumb if TMDB has none
            if not tv.get('thumb') and show.get('thumb'):
                tv['thumb'] = show['thumb']
            enriched.append(tv)
        else:
            # Fallback: use raw BounceTV data
            enriched.append({
                'tmdb_id': '',
                'title':   show['title'],
                'thumb':   show.get('thumb', ''),
                'fanart':  '',
                'plot':    '',
                'year':    '',
                'rating':  '',
            })
    return enriched


def _render_free_movies(handle, build_url, movies, svc_label):
    """Render movie list items with debrid play action."""
    for film in movies:
        title = film.get('title', '')
        if not title:
            continue

        li = xbmcgui.ListItem(label=title)
        info = {
            'title':   title,
            'plot':    film.get('plot', ''),
            'year':    film.get('year', ''),
            'rating':  film.get('rating', ''),
            'mpaa':    film.get('mpaa', ''),
        }
        li.setInfo('video', info)

        art = {}
        if film.get('thumb'):  art['thumb'] = art['poster'] = film['thumb']
        if film.get('fanart'): art['fanart'] = film['fanart']
        if art: li.setArt(art)

        li.setProperty('IsPlayable', 'true')
        url_params = {
            'action':     'free_play',
            'tmdb_id':    str(film.get('tmdb_id', '')),
            'title':      title,
            'year':       str(film.get('year', '')),
            'media_type': 'movie',
            'svc_label':  svc_label,
        }
        if film.get('archive_id'):
            url_params['archive_id'] = film['archive_id']
        if film.get('stream_url'):
            url_params['stream_url'] = film['stream_url']
        xbmcplugin.addDirectoryItem(handle, build_url(url_params), li, False)


def _render_free_tv(handle, build_url, shows, svc_label):
    """Render TV show list items. Clicking opens the show detail/season browser."""
    for show in shows:
        title = show.get('title', '') or show.get('name', '')
        if not title:
            continue

        li = xbmcgui.ListItem(label=title)
        info = {
            'title':  title,
            'plot':   show.get('plot', ''),
            'year':   show.get('year', ''),
            'rating': show.get('rating', ''),
            'tvshowtitle': title,
        }
        li.setInfo('video', info)

        art = {}
        if show.get('thumb'):  art['thumb'] = art['poster'] = show['thumb']
        if show.get('fanart'): art['fanart'] = show['fanart']
        if art: li.setArt(art)

        tmdb_id = str(show.get('tmdb_id', ''))

        if tmdb_id:
            # Has TMDB ID ? open full show detail (reuse existing metadata router)
            xbmcplugin.addDirectoryItem(
                handle,
                build_url({'action': 'meta_tv_show', 'tmdb_id': tmdb_id, 'title': title}),
                li, True
            )
        else:
            # No TMDB ID ? play via debrid search
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(
                handle,
                build_url({'action': 'free_play', 'tmdb_id': '', 'title': title,
                           'year': '', 'media_type': 'tv', 'svc_label': svc_label}),
                li, False
            )


# ?? Play: search debrid sources + show picker dialog ?????????????????????????

def free_play(handle, tmdb_id='', title='', year='', media_type='movie', svc_label='', archive_id='', stream_url=''):
    """
    Gather ALL available sources (direct stream URL, Internet Archive MP4, debrid torrent links)
    in parallel and show them all in one combined source-picker dialog.
    """
    if not title:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    pd = xbmcgui.DialogProgress()
    pd.create('Starfleet', 'Gathering sources for "%s"...' % title)
    pd.update(10)

    from concurrent.futures import ThreadPoolExecutor

    def _get_direct():
        if not stream_url:
            return []
        return [{'label': '?  %s (Free / Direct)' % (svc_label or 'Stream'), 'url': stream_url}]

    def _get_archive():
        if not archive_id:
            return []
        try:
            from resources.lib import free_sources as _fs
            url = _fs.resolve_archive_stream(archive_id)
            return [{'label': '?  Internet Archive (Free / Direct)', 'url': url}] if url else []
        except Exception as e:
            xbmc.log('[Starfleet/Free] Archive resolve error: %s' % e, xbmc.LOGERROR)
            return []

    def _get_debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            return _dt.get_debrid_streams(title, year=year or None, media_type=media_type)
        except Exception as e:
            xbmc.log('[Starfleet/Free] debrid error: %s' % e, xbmc.LOGERROR)
            return []

    all_sources = []
    # Direct stream (Popcornflix etc.) is instant ? no thread needed
    all_sources.extend(_get_direct())

    with ThreadPoolExecutor(max_workers=2) as pool:
        f_archive = pool.submit(_get_archive)
        f_debrid  = pool.submit(_get_debrid)
        try:
            all_sources.extend(f_archive.result(timeout=20))
        except Exception:
            pass
        try:
            all_sources.extend(f_debrid.result(timeout=30))
        except Exception:
            pass

    pd.close()

    if not all_sources:
        xbmcgui.Dialog().notification(
            'Starfleet ? %s' % (svc_label or 'Free Streaming'),
            'No sources found for "%s"' % title,
            xbmcgui.NOTIFICATION_WARNING, 5000
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(all_sources) == 1:
        chosen_url = all_sources[0]['url']
    else:
        options = [s['label'] for s in all_sources]
        idx = xbmcgui.Dialog().select('"%s" ? Choose source' % title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen_url = all_sources[idx]['url']

    if chosen_url.startswith('magnet:'):
        import urllib.parse as _ul
        chosen_url = 'plugin://plugin.video.elementum/play?uri=' + _ul.quote(chosen_url, safe='')

    li = xbmcgui.ListItem(path=chosen_url)
    li.setInfo('video', {'title': title})
    xbmcplugin.setResolvedUrl(handle, True, li)
