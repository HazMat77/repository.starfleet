# -*- coding: utf-8 -*-
"""
resources/lib/sports_sources.py

Sports live-stream scraper.

Event sources (priority order):
  1. ESPN API          — NFL, NBA, MLB, NHL, CFB, NCAAB, CFL (official logos + scores)
  2. TheSportsDB       — UFC, Boxing, WWE (free tier, API key 3)
  3. istreameast.cx    — fallback / soccer / F1 / anything else
  4. streamseast.cx    — supplementary (merged, deduplicated)
  5. crackstreams.mx   — supplementary (merged, deduplicated)
  6. mlb24all.ir       — MLB-specific supplementary
  7. nhl24all.ir       — NHL-specific supplementary
  8. nfl24all.ir       — NFL-specific supplementary
  9. nba24all.ir       — NBA-specific supplementary
 10. totalsportek24.is — multi-sport (soccer/NFL/NBA/NHL/MLB/UFC/boxing/F1/CFB/NCAAB/WWE)
 11. onhockey.tv       — NHL-specific supplementary
 12. totalsportek      — multi-sport (NHL/NFL/NBA/MLB/soccer/UFC/boxing/F1/CFB/NCAAB/WWE)

Stream sources (merged):
  1. istreameast.cx    — /links/{slug} stream table when live
  2. roxiestreams.info — sport-page links matched by event title
  3. streamseast.cx    — supplementary stream source
  4. crackstreams.mx   — supplementary stream source
  5. v2.sportsurge.net — Cloudflare-protected, via cfscrape
  6. mlb24all.ir       — MLB-specific stream source
  7. nhl24all.ir       — NHL-specific stream source
  8. nfl24all.ir       — NFL-specific stream source
  9. nba24all.ir       — NBA-specific stream source
 10. totalsportek24.is — multi-sport stream source
 11. onhockey.tv       — NHL-specific stream source (direct + cross-ref by title)
 12. totalsportek      — multi-sport stream source (direct + cross-ref by title)

Cache: event list 10 min (live data), stream list 5 min
"""

import re
import datetime
import time
import xbmc
import xbmcaddon
import xbmcvfs
from concurrent.futures import ThreadPoolExecutor, as_completed

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

ISE_BASE        = 'https://istreameast.cx'
CRACK_BASE      = 'https://crackstreams.mx'
_CRACK_MIRRORS  = ['https://crackstreams.mx', 'https://crackstreams.biz',
                   'https://crackstreams.app', 'https://crack.sx']
ROXIE_BASE      = 'https://roxiestreams.info'
SEAST_BASE      = 'https://streamseast.is'
TSTEK_BASE      = 'https://totalsportek24.is'
SPORTSURGE_BASE = 'https://v2.sportsurge.net'
_SPORTSURGE_BASES = ['https://v2.sportsurge.net', 'https://sportsurge.net',
                     'https://sportsurge.club', 'https://sportsurge.cc']
PPV_BASE        = 'https://ppv.to'
ONHOCKEY_BASE   = 'https://onhockey.tv'

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5, redirect=False)
        )
        _session.mount('https://', a)
    return _session


_cf_session = None

def _cf_sess():
    """Return a Cloudflare-bypass session. Tries cloudscraper first, then cfscrape, then plain requests."""
    global _cf_session
    if _cf_session is None:
        # 1. Try cloudscraper (pip install cloudscraper — works on most platforms)
        try:
            import cloudscraper as _cs
            _cf_session = _cs.create_scraper(
                browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
            )
            _cf_session.headers.update(_HEADERS)
            xbmc.log('[Starfleet/Sports] CF bypass: cloudscraper OK', xbmc.LOGINFO)
            return _cf_session
        except Exception:
            pass
        # 2. Try cfscrape from script.module.thecrew (Kodi addon)
        try:
            import sys as _sys
            import xbmcvfs as _vfs
            _kodi_addons = _vfs.translatePath('special://home/addons')
            _sys.path.insert(0, _kodi_addons + '/script.module.thecrew/lib/resources/lib/modules')
            import cfscrape
            _cf_session = cfscrape.create_scraper()
            _cf_session.headers.update(_HEADERS)
            xbmc.log('[Starfleet/Sports] CF bypass: cfscrape OK', xbmc.LOGINFO)
            return _cf_session
        except Exception as e:
            xbmc.log('[Starfleet/Sports] CF bypass unavailable, using plain session: %s' % e, xbmc.LOGWARNING)
            _cf_session = _sess()
    return _cf_session


def _get(url, timeout=12):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _get_json(url, timeout=10):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()


def _ts_to_dt(date_str):
    """Parse ISO 8601 UTC date string to (unix_timestamp, display_string). Returns (0, '') on failure."""
    if not date_str:
        return 0, ''
    try:
        # Normalise: strip timezone marker and fractional seconds
        clean = date_str.strip()
        clean = clean.split('.')[0]          # drop .000
        clean = clean.rstrip('Z')            # drop trailing Z
        if '+' in clean:
            clean = clean.split('+')[0]      # drop +00:00
        # Try with seconds (19 chars) then without (16 chars)
        dt = None
        for fmt, n in (('%Y-%m-%dT%H:%M:%S', 19), ('%Y-%m-%dT%H:%M', 16)):
            try:
                dt = datetime.datetime.strptime(clean[:n], fmt)
                break
            except Exception:
                pass
        if dt is None:
            return 0, date_str
        ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
        return ts, dt.strftime('%b %d %H:%M UTC')
    except Exception:
        return 0, date_str


_RE_SCORE = re.compile(r'\b\d+\s*[-:]\s*\d+\b')


def _strip_score(title):
    """Remove live score like '3 - 2' or '1:0' from a match title for cross-source matching."""
    return _RE_WS.sub(' ', _RE_SCORE.sub('', title)).strip(' -')


def _title_score(title_a, title_b):
    """Return number of significant words (len>3) from title_a that appear in title_b (case-insensitive)."""
    words_a = [w.lower() for w in re.split(r'\W+', _strip_score(title_a)) if len(w) > 3]
    b_lower = _strip_score(title_b).lower()
    return sum(1 for w in words_a if w in b_lower)


def _titles_match(title_a, title_b, threshold=2):
    """Return True if at least `threshold` significant words from title_a appear in title_b."""
    return _title_score(title_a, title_b) >= threshold


# ── Sport categories ──────────────────────────────────────────────────────────

_CATEGORIES = [
    {'slug': 'nfl',     'label': 'NFL',                      'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nfl.png'},
    {'slug': 'nba',     'label': 'NBA',                      'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nba.png'},
    {'slug': 'mlb',     'label': 'MLB',                      'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/mlb.png'},
    {'slug': 'nhl',     'label': 'NHL',                      'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'},
    {'slug': 'ufc',     'label': 'UFC / MMA',                'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ufc.png'},
    {'slug': 'boxing',  'label': 'Boxing',                   'icon': 'https://iili.io/3aqk6js.webp'},
    {'slug': 'soccer',  'label': 'Soccer',                   'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/fifa.png'},
    {'slug': 'tennis',  'label': 'Tennis',                   'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/asdh2v1548684497.jpg/preview'},
    {'slug': 'rugby',   'label': 'Rugby',                    'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/vbki5v1547214439.jpg/preview'},
    {'slug': 'cricket', 'label': 'Cricket',                  'icon': 'https://www.thesportsdb.com/images/media/sport/thumb/cricket1519439826.jpg/preview'},
    {'slug': 'motogp',  'label': 'MotoGP',                   'icon': 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/MotoGP_logo.svg/200px-MotoGP_logo.svg.png'},
    {'slug': 'f1',      'label': 'Formula 1',                'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/f1.png'},
    {'slug': 'cfb',     'label': 'College Football (CFB)',   'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaaf.png'},
    {'slug': 'ncaab',   'label': 'College Basketball (NCAAB)', 'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaab.png'},
    {'slug': 'cfl',     'label': 'CFL',                      'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/cfl.png'},
    {'slug': 'wwe',     'label': 'WWE / Wrestling',          'icon': 'https://r2.thesportsdb.com/images/media/league/badge/r43xns1461424282.png/tiny'},
]

def get_sport_categories():
    return _CATEGORIES


def get_onhockey_events():
    """Return all onhockey.tv events with their league field populated."""
    return _onhockey_events()


# ── ESPN API ──────────────────────────────────────────────────────────────────

_ESPN_SPORTS = {
    'nfl':   ('football',   'nfl'),
    'nba':   ('basketball', 'nba'),
    'mlb':   ('baseball',   'mlb'),
    'nhl':   ('hockey',     'nhl'),
    'cfb':   ('football',   'college-football'),
    'ncaab': ('basketball', 'mens-college-basketball'),
    'cfl':   ('football',   'cfl'),
    'soccer': ('soccer',   'fifa.world'),   # FIFA World Cup 2026 (Jun–Jul 2026)
}
# Additional soccer leagues polled after the primary
_ESPN_SOCCER_EXTRA = ['eng.1', 'usa.1', 'uefa.champions', 'uefa.europa']
_ESPN_API = 'https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard'


def _espn_events(sport_slug):
    if sport_slug not in _ESPN_SPORTS:
        return []
    sport, league = _ESPN_SPORTS[sport_slug]
    url = _ESPN_API.format(sport=sport, league=league)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ESPN API (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in data.get('events', []):
        state   = ev.get('status', {}).get('type', {}).get('state', 'pre')
        is_live = (state == 'in')

        comp        = (ev.get('competitions') or [{}])[0]
        competitors = comp.get('competitors', [])
        venue       = comp.get('venue', {}).get('fullName', '')

        match_title = ev.get('name', ev.get('shortName', ''))
        if len(competitors) >= 2:
            teams  = [c.get('team', {}).get('displayName', '') for c in competitors]
            scores = [c.get('score', '') for c in competitors]
            match_title = ' vs '.join(teams)
            title_str   = match_title
            if is_live and all(scores):
                title_str = '%s %s - %s %s' % (teams[0], scores[0], scores[1], teams[1])
        else:
            title_str = match_title

        logo = ''
        if competitors:
            logo = competitors[0].get('team', {}).get('logo', '')

        start_ts, datetime_str = _ts_to_dt(ev.get('date', ''))

        events.append({
            'id':          ev.get('id', ''),
            'slug':        ev.get('id', ''),
            'path':        '',
            'title':       title_str,
            'match_title': match_title,
            'datetime':    datetime_str,
            'league':      sport_slug.upper(),
            'logo':        logo,
            'is_live':     is_live,
            'start_ts':    start_ts,
            'venue':       venue,
        })

    return events


# ── TheSportsDB (UFC / Boxing / WWE) ─────────────────────────────────────────

_TSDB_LEAGUES = {
    'ufc':    '4407',
    'boxing': '4414',
    'wwe':    '4412',
}
_TSDB_NEXT = 'https://www.thesportsdb.com/api/v1/json/3/eventsnextleague.php'


def _tsdb_events(sport_slug):
    league_id = _TSDB_LEAGUES.get(sport_slug)
    if not league_id:
        return []
    url = '%s?id=%s' % (_TSDB_NEXT, league_id)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in (data.get('events') or []):
        date_str = ev.get('dateEvent', '')
        time_str = (ev.get('strTime') or '00:00:00')[:8]
        try:
            dt = datetime.datetime.strptime('%s %s' % (date_str, time_str), '%Y-%m-%d %H:%M:%S')
            start_ts  = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
            datetime_str = dt.strftime('%b %d %H:%M')
        except Exception:
            start_ts, datetime_str = 0, date_str

        title_str = ev.get('strEvent', ev.get('strFilename', ''))
        logo = ev.get('strThumb', '') or ev.get('strBanner', '') or ''

        events.append({
            'id':       str(ev.get('idEvent', '')),
            'slug':     str(ev.get('idEvent', '')),
            'path':     '',
            'title':    title_str,
            'datetime': datetime_str,
            'league':   ev.get('strLeague', sport_slug.upper()),
            'logo':     logo,
            'is_live':  False,
            'start_ts': start_ts,
        })

    return events


# ── istreameast.cx events (fallback) ─────────────────────────────────────────

_RE_ISE_CARD = re.compile(
    r'class="event-card"[^>]*onclick="window\.location\.href=[^\']*\'(/links/([^\']+))\''
    r'[^>]*data-event-id="(\d+)"[^>]*data-start-ts="(\d+)"',
    re.IGNORECASE | re.DOTALL
)
_RE_ISE_LOGO = re.compile(
    r'<img[^>]+src="(https://[^"]+thesportsdb[^"]+|https://[^"]+espncdn[^"]+)"[^>]*alt="([^"]*)"',
    re.IGNORECASE
)
_RE_ISE_TITLE    = re.compile(r'class="event-title"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_DATETIME = re.compile(r'class="event-datetime"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_LEAGUE   = re.compile(r'class="event-league"\s*>(.*?)</div>', re.IGNORECASE | re.DOTALL)
_RE_ISE_STATUS   = re.compile(r'class="event-status\s+([^"]+)"\s*>(.*?)</span>', re.IGNORECASE)


def _parse_ise_block(block):
    m_title = _RE_ISE_TITLE.search(block)
    m_dt    = _RE_ISE_DATETIME.search(block)
    m_lg    = _RE_ISE_LEAGUE.search(block)
    m_st    = _RE_ISE_STATUS.search(block)
    m_logo  = _RE_ISE_LOGO.search(block)

    title    = _clean(m_title.group(1)) if m_title else ''
    dt_str   = _clean(m_dt.group(1))   if m_dt    else ''
    league   = _clean(_RE_STRIP.sub(' ', m_lg.group(1))) if m_lg else ''
    league   = re.sub(r'\s+\d+\s+(?:hours?|minutes?)\s+from\s+now.*', '', league, flags=re.IGNORECASE).strip()
    status_class = m_st.group(1).strip() if m_st else 'upcoming'
    is_live  = 'live' in status_class.lower()
    logo_url = m_logo.group(1) if m_logo else ''
    return title, dt_str, league, logo_url, is_live


def _ise_events(sport_slug):
    url = ISE_BASE + '/schedule/%s' % sport_slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE schedule error (%s): %s' % (sport_slug, e), xbmc.LOGERROR)
        try:
            html = _get(ISE_BASE + '/')
        except Exception:
            return []

    events = []
    seen   = set()

    for m in _RE_ISE_CARD.finditer(html):
        path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
        if event_id in seen:
            continue
        seen.add(event_id)
        block = html[m.end():m.end() + 900]
        title, dt_str, league, logo_url, is_live = _parse_ise_block(block)

        _soccer_words = ('football', 'soccer', 'fifa', 'premier', 'champions', 'mls', 'laliga', 'bundesliga', 'serie')
        if sport_slug == 'soccer':
            if league and not any(w in league.lower() for w in _soccer_words):
                continue
        elif sport_slug != 'nfl' and league and sport_slug.lower() not in league.lower():
            continue

        events.append({
            'id':       event_id,
            'slug':     slug,
            'path':     path,
            'title':    title or slug.replace('-', ' ').title(),
            'datetime': dt_str,
            'league':   league,
            'logo':     logo_url,
            'is_live':  is_live,
            'start_ts': int(start_ts_str),
        })

    return events


# ── streamseast.cx events (supplementary) ────────────────────────────────────

_SEAST_SLUGS = {
    'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'nhl': 'nhl',
    'ufc': 'mma', 'boxing': 'boxing', 'soccer': 'soccer',
    'f1': 'f1', 'cfb': 'nfl', 'wwe': 'wwe',
}

# streamseast.cx uses similar HTML structure to istreameast.cx
_RE_SEAST_CARD = re.compile(
    r'class="event-card"[^>]*onclick="window\.location\.href=[^\']*\'(/links/([^\']+))\''
    r'[^>]*data-event-id="(\d+)"[^>]*data-start-ts="(\d+)"',
    re.IGNORECASE | re.DOTALL
)


def _seast_events(sport_slug):
    slug = _SEAST_SLUGS.get(sport_slug)
    if not slug:
        return []
    url = SEAST_BASE + '/%s' % slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast schedule error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()

    for m in _RE_SEAST_CARD.finditer(html):
        path, ev_slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
        if event_id in seen:
            continue
        seen.add(event_id)
        block = html[m.end():m.end() + 900]
        title, dt_str, league, logo_url, is_live = _parse_ise_block(block)

        events.append({
            'id':       'seast_' + event_id,
            'slug':     ev_slug,
            'path':     'streamseast:' + path,  # prefix so stream fetcher knows source
            'title':    title or ev_slug.replace('-', ' ').title(),
            'datetime': dt_str,
            'league':   league,
            'logo':     logo_url,
            'is_live':  is_live,
            'start_ts': int(start_ts_str),
        })

    return events


def _seast_event_streams(event_path):
    """event_path may be 'streamseast:/links/...' or just '/links/...'"""
    path = event_path.replace('streamseast:', '')
    url  = SEAST_BASE + path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=SEAST_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, 'streamseast.cx', 'StreamsEast')
    xbmc.log('[Starfleet/Sports] StreamsEast streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# ── Public event API ──────────────────────────────────────────────────────────

def _merge_events(primary, supplementary):
    """Merge supplementary events into primary, deduplicating by title similarity."""
    merged = list(primary)
    primary_titles = [e['title'] for e in primary]

    for ev in supplementary:
        # Check if a similar event already exists
        duplicate = False
        for pt in primary_titles:
            if _titles_match(ev['title'], pt, threshold=2):
                duplicate = True
                break
        if not duplicate:
            merged.append(ev)
            primary_titles.append(ev['title'])

    return merged


def get_sport_events(sport_slug='nfl'):
    ck = 'sport_ev3_%s' % sport_slug   # v3: bust old caches that had start_ts=0
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    events = []

    espn_found = False
    if sport_slug in _ESPN_SPORTS:
        events = _espn_events(sport_slug)
        espn_found = len(events) > 0

    # For soccer: also poll extra leagues (PL, MLS, UCL, UEL) and merge
    if sport_slug == 'soccer':
        for _xl in _ESPN_SOCCER_EXTRA:
            try:
                _xdata = _get_json(_ESPN_API.format(sport='soccer', league=_xl))
                _xevs  = []
                for ev in _xdata.get('events', []):
                    _st   = ev.get('status', {}).get('type', {}).get('state', 'pre')
                    _comp = (ev.get('competitions') or [{}])[0]
                    _cmps = _comp.get('competitors', [])
                    if len(_cmps) >= 2:
                        _teams = [c.get('team', {}).get('displayName', '') for c in _cmps]
                        _title = ' vs '.join(_teams)
                    else:
                        _title = ev.get('name', ev.get('shortName', ''))
                    _logo = _cmps[0].get('team', {}).get('logo', '') if _cmps else ''
                    _ts, _dt = _ts_to_dt(ev.get('date', ''))
                    _xevs.append({'id': ev.get('id', ''), 'slug': ev.get('id', ''),
                                  'path': '', 'title': _title, 'datetime': _dt,
                                  'league': _xl.upper(), 'logo': _logo,
                                  'is_live': (_st == 'in'), 'start_ts': _ts})
                if _xevs:
                    events = _merge_events(events, _xevs)
            except Exception:
                pass

    if not events and sport_slug in _TSDB_LEAGUES:
        events = _tsdb_events(sport_slug)

    if not events:
        events = _ise_events(sport_slug)

    # Run supplementary sources in parallel (shutdown(wait=False) avoids blocking on hung futures)
    supplementary_futures = {}
    ex = ThreadPoolExecutor(max_workers=8)
    try:
        supplementary_futures['seast'] = ex.submit(_seast_events, sport_slug)
        if sport_slug in _TSTEK_SLUGS:
            supplementary_futures['tstek'] = ex.submit(_tstek_events, sport_slug)
        supplementary_futures['ppvto'] = ex.submit(_ppvto_events, sport_slug)
        if sport_slug == 'mlb' and espn_found:
            supplementary_futures['mlb24'] = ex.submit(_mlb24_events)
        if sport_slug == 'nhl' and espn_found:
            supplementary_futures['nhl24'] = ex.submit(_nhl24_events)
        # onhockey covers ALL hockey leagues — run for any hockey sport slug
        _HOCKEY_SLUGS = {'nhl', 'ahl', 'khl', 'shl', 'ohl', 'whl', 'qmjhl',
                         'echl', 'ncaa-hockey', 'pwhl', 'iihf', 'hockey'}
        if sport_slug in _HOCKEY_SLUGS:
            def _onhockey_for_slug(slug=sport_slug):
                evs = _onhockey_events()
                if slug == 'hockey':
                    return evs   # all leagues
                # filter to events whose detected league matches the slug
                slug_upper = slug.upper()
                return [e for e in evs if e.get('league', 'NHL').upper() == slug_upper]
            supplementary_futures['onhockey'] = ex.submit(_onhockey_for_slug)
        if sport_slug == 'nfl' and espn_found:
            supplementary_futures['nfl24'] = ex.submit(_nfl24_events)
        if sport_slug == 'nba' and espn_found:
            supplementary_futures['nba24'] = ex.submit(_nba24_events)
        if sport_slug in _TSPORTEK_SPORT_PATHS:
            supplementary_futures['tsportek'] = ex.submit(_tsportek_events, sport_slug)

        for name, fut in supplementary_futures.items():
            try:
                extra = fut.result(timeout=12)
                if extra:
                    events = _merge_events(events, extra)
                    xbmc.log('[Starfleet/Sports] %s merged %d events from %s' % (sport_slug, len(extra), name), xbmc.LOGINFO)
            except Exception as e:
                xbmc.log('[Starfleet/Sports] supplementary events error (%s/%s): %s' % (sport_slug, name, e), xbmc.LOGWARNING)
    finally:
        ex.shutdown(wait=False)  # don't block on any still-running futures

    events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def get_all_events():
    ck = 'sports_events_all'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(ISE_BASE + '/')
        events = []
        seen   = set()

        for m in _RE_ISE_CARD.finditer(html):
            path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[m.end():m.end() + 900]
            title, dt_str, league, logo_url, is_live = _parse_ise_block(block)
            events.append({
                'id':       event_id,
                'slug':     slug,
                'path':     path,
                'title':    title or slug.replace('-', ' ').title(),
                'datetime': dt_str,
                'league':   league,
                'logo':     logo_url,
                'is_live':  is_live,
                'start_ts': int(start_ts_str),
            })

        events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
        _cache.set(ck, events, 10 * 60)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] all events error: %s' % e, xbmc.LOGERROR)
        return []


# ── Stream links ──────────────────────────────────────────────────────────────

# Known streaming embed/player domains — used as fallback link detection
_STREAM_EMBED_DOMAINS = (
    '720pstream', 'livetv', 'streamtape', 'cloudy.pk', 'stopstream',
    'nbaat', 'vecloud', 'embedstream', 'nlstreams', 'theflixer',
    'sportshdlive', 'daddylive', 'sportsurge', 'buffstream', 'atdhe',
    'firstrowsports', 'livesport', 'sportsbay', 'streameast',
    'crackstreams', 'volokit', 'acestream',
)

# istreameast.cx stream table row — flexible: 3 or more TDs, last with <a href>
_RE_ISE_STREAM_ROW = re.compile(
    r'<tr[^>]*>\s*'
    r'<td[^>]*>(.*?)</td>\s*'          # col 1: streamer/name
    r'<td[^>]*>(.*?)</td>\s*'          # col 2: channel/quality
    r'(?:<td[^>]*>.*?</td>\s*)*'       # optional extra cols
    r'<td[^>]*><a[^>]+href="([^"#][^"]*)"[^>]*>',
    re.IGNORECASE | re.DOTALL
)

# Fallback: any external <a> with href on a stream page
_RE_EXT_LINK = re.compile(
    r'<a[^>]+href="(https?://([^/"]+)[^"]*)"[^>]*>([^<]{1,80})</a>',
    re.IGNORECASE
)
# Fallback: iframes with external src
_RE_IFRAME_SRC = re.compile(r'<iframe[^>]+src="(https?://[^"]+)"', re.IGNORECASE)


def _extract_stream_links(html, base_domain, source_label):
    """
    Try structured table parse first, then fall back to link/iframe extraction.
    Returns list of stream dicts.
    """
    streams = []

    # 1. Try structured table rows
    for m in _RE_ISE_STREAM_ROW.finditer(html):
        col1 = _clean(m.group(1))
        col2 = _clean(m.group(2))
        url  = m.group(3).strip()
        if not url or url == '#':
            continue
        label = ('%s %s' % (col1, col2)).strip() or source_label
        streams.append({
            'label':    label,
            'url':      url,
            'quality':  col2,
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 2. Fallback: iframes
    for m in _RE_IFRAME_SRC.finditer(html):
        src = m.group(1).strip()
        if base_domain and base_domain in src:
            continue
        streams.append({
            'label':    source_label + ' Embedded',
            'url':      src,
            'quality':  '',
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 3. Fallback: known stream embed domain links
    for m in _RE_EXT_LINK.finditer(html):
        href   = m.group(1).strip()
        domain = m.group(2).lower()
        text   = _clean(m.group(3))
        if base_domain and base_domain in domain:
            continue
        if any(d in domain for d in _STREAM_EMBED_DOMAINS):
            streams.append({
                'label':    text or (source_label + ' Stream'),
                'url':      href,
                'quality':  '',
                'language': '',
                'source':   source_label,
            })

    return streams


def _ise_event_streams(event_path, event_id=''):
    url = ISE_BASE + event_path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=ISE_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE stream page error (%s): %s' % (event_path, e), xbmc.LOGERROR)
        return []

    streams = _extract_stream_links(html, 'istreameast.cx', 'StreamEast')
    xbmc.log('[Starfleet/Sports] ISE streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# Roxiestreams
_ROXIE_SLUGS = {
    'nfl':    'nfl',
    'nba':    'nba',
    'mlb':    'mlb',
    'nhl':    'nhl',
    'ufc':    'fighting',
    'boxing': 'fighting',
    'soccer': 'soccer',
    'wwe':    'wwe',
    'cfb':    'ncaaf',
    'ncaab':  'ncaab',
    'f1':     'f1',
    'cfl':    'cfl',
}

_RE_ROXIE_ROW = re.compile(
    r'<a[^>]+href="(/[^"#\s]{3,80})"[^>]*>\s*([^<]{3,120}?)\s*</a>',
    re.IGNORECASE
)


def _roxie_streams(sport_slug, event_title=''):
    slug = _ROXIE_SLUGS.get(sport_slug)
    if not slug:
        return []
    url = ROXIE_BASE + '/' + slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Roxie (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    streams = []
    title_words = [w.lower() for w in re.split(r'\W+', event_title) if len(w) > 3] if event_title else []

    for m in _RE_ROXIE_ROW.finditer(html):
        link_path = m.group(1)
        row_text  = _clean(m.group(2))

        # Skip nav/generic links
        if not row_text or len(row_text) < 4:
            continue
        skip_words = ('home', 'menu', 'schedule', 'login', 'register', 'about', 'contact')
        if row_text.lower() in skip_words:
            continue

        # If we have an event title, require at least one keyword match
        if title_words:
            row_lower = row_text.lower()
            if not any(w in row_lower for w in title_words):
                continue

        full_url = ROXIE_BASE + link_path if not link_path.startswith('http') else link_path
        streams.append({
            'label':    row_text,
            'url':      full_url,
            'quality':  '',
            'language': '',
            'source':   'RoxieStreams',
        })
        if len(streams) >= 8:
            break

    xbmc.log('[Starfleet/Sports] Roxie %s "%s": %d streams' % (sport_slug, event_title, len(streams)), xbmc.LOGINFO)
    return streams


# ── Crackstreams (supplementary) ─────────────────────────────────────────────

_CRACK_SLUGS = {
    'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'nhl': 'nhl',
    'ufc': 'mma', 'boxing': 'boxing', 'soccer': 'soccer', 'f1': 'f1', 'wwe': 'wwe',
}

# Primary card pattern: /watch-live/{sport}/{team1}/{team2}/{id}
_RE_CRACK_CARD = re.compile(
    r'<a[^>]+href="(/watch-live/([^/\"]+)/([^/\"]+)/([^/\"]+)/(\d+))"[^>]*>'
    r'(?:(?!</a>).)*?'
    r'<div[^>]*class="[^"]*event-title[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE | re.DOTALL
)
# Fallback card pattern: any internal /watch-* or /nfl|nba|mlb|nhl|mma|boxing/* link with title text
_RE_CRACK_CARD2 = re.compile(
    r'<a[^>]+href="(/(?:watch|nfl|nba|mlb|nhl|mma|boxing|soccer|f1|wwe|fighting)/[^"#\s]{3,80})"[^>]*>'
    r'([^<]{5,120})'
    r'(?:</a>|<)',
    re.IGNORECASE
)
_RE_CRACK_IMG = re.compile(
    r'<img[^>]+src="(https://[^"]+(?:espncdn|thesportsdb)[^"]+)"[^>]+alt="([^"]*)"',
    re.IGNORECASE
)
# Watch links on event page: "Watch", "Stream", "Link N", "HD" etc.
_RE_CRACK_WATCH_LINK = re.compile(
    r'<a[^>]+href="(https?://[^"]+)"[^>]*>[^<]*(?:[Ww]atch|[Ss]tream|[Ll]ink\s*\d|HD|Live)[^<]*</a>',
    re.IGNORECASE
)


def get_crack_events():
    ck = 'sports_crack_events'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    html = None
    used_base = CRACK_BASE
    for _mirror in _CRACK_MIRRORS:
        try:
            r = _sess().get(_mirror + '/', timeout=12, headers=dict(_HEADERS, Referer='https://www.google.com/'))
            if r.status_code == 200:
                html = r.text
                used_base = _mirror
                break
        except Exception:
            continue
    if html is None:
        xbmc.log('[Starfleet/Sports] crackstreams all mirrors failed', xbmc.LOGWARNING)
        return []
    try:
        events = []
        seen   = set()

        # Primary pattern: structured /watch-live/{sport}/{team1}/{team2}/{id}
        for m in _RE_CRACK_CARD.finditer(html):
            path, sport = m.group(1), m.group(2)
            event_id    = m.group(5)
            title       = _clean(m.group(6))
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[max(0, m.start() - 400):m.start()]
            im    = _RE_CRACK_IMG.search(block)
            logo  = im.group(1) if im else ''
            events.append({
                'id':    event_id,
                'title': title,
                'sport': sport,
                'path':  path,
                'logo':  logo,
            })

        # Fallback pattern: simpler /sport/... links
        if not events:
            xbmc.log('[Starfleet/Sports] CrackStreams primary regex matched nothing, trying fallback', xbmc.LOGINFO)
            for m in _RE_CRACK_CARD2.finditer(html):
                path  = m.group(1)
                title = _clean(m.group(2))
                if not title or len(title) < 4:
                    continue
                skip = ('home', 'schedule', 'about', 'contact', 'nfl', 'nba', 'mlb', 'nhl', 'login')
                if title.lower().strip() in skip:
                    continue
                uid = re.sub(r'\W+', '_', path)
                if uid in seen:
                    continue
                seen.add(uid)
                # Determine sport from path
                sport_part = path.strip('/').split('/')[0].lower()
                events.append({
                    'id':    uid,
                    'title': title,
                    'sport': sport_part,
                    'path':  path,
                    'logo':  '',
                })

        # Third fallback: scrape each sport sub-page directly
        if not events:
            xbmc.log('[Starfleet/Sports] CrackStreams both regexes matched nothing, trying sport sub-pages', xbmc.LOGINFO)
            for sport_path in ('/soccer/', '/nfl/', '/nba/', '/mlb/', '/nhl/', '/mma/', '/boxing/'):
                try:
                    sp_html = _sess().get(used_base + sport_path, timeout=8,
                                          headers=dict(_HEADERS, Referer=used_base + '/')).text
                    for m in _RE_CRACK_CARD.finditer(sp_html):
                        path, sport = m.group(1), m.group(2)
                        event_id    = m.group(5)
                        title_t     = _clean(m.group(6))
                        if event_id in seen:
                            continue
                        seen.add(event_id)
                        events.append({'id': event_id, 'title': title_t, 'sport': sport, 'path': path, 'logo': ''})
                    for m in _RE_CRACK_CARD2.finditer(sp_html):
                        path  = m.group(1)
                        title_t = _clean(m.group(2))
                        if not title_t or len(title_t) < 4:
                            continue
                        uid = re.sub(r'\W+', '_', path)
                        if uid in seen:
                            continue
                        seen.add(uid)
                        sport_part = path.strip('/').split('/')[0].lower()
                        events.append({'id': uid, 'title': title_t, 'sport': sport_part, 'path': path, 'logo': ''})
                except Exception:
                    pass
            xbmc.log('[Starfleet/Sports] CrackStreams sub-page fallback: %d events' % len(events), xbmc.LOGINFO)

        _cache.set(ck, events, 10 * 60)
        _cache.set('sports_crack_base', used_base, 10 * 60)
        xbmc.log('[Starfleet/Sports] CrackStreams events found: %d (mirror: %s)' % (len(events), used_base), xbmc.LOGINFO)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] crackstreams events error: %s' % e, xbmc.LOGWARNING)
        return []


def _crack_event_streams(sport_slug, event_title):
    """Find matching crackstreams event and scrape its stream watch links."""
    slug = _CRACK_SLUGS.get(sport_slug)
    if not slug:
        return []

    try:
        crack_events = get_crack_events()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] crackstreams get_events error: %s' % e, xbmc.LOGWARNING)
        return []

    # Find best matching event
    best_path  = None
    best_score = 0
    for ev in crack_events:
        # Filter by sport slug if possible
        ev_sport = ev.get('sport', '')
        if slug and ev_sport and ev_sport.lower() != slug.lower():
            continue
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']

    if not best_path or best_score < 2:
        xbmc.log('[Starfleet/Sports] crackstreams no match for "%s" (best=%d)' % (event_title, best_score), xbmc.LOGINFO)
        return []

    active_base = _cache.get('sports_crack_base') or CRACK_BASE
    url = active_base + best_path if best_path.startswith('/') else best_path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=active_base + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] crackstreams event page error (%s): %s' % (best_path, e), xbmc.LOGWARNING)
        return []

    # Try specific "Watch/Stream/Link" anchors first
    streams = []
    for m in _RE_CRACK_WATCH_LINK.finditer(html):
        watch_url = m.group(1).strip()
        if not watch_url or watch_url == '#':
            continue
        streams.append({
            'label':    'CrackStreams ' + _clean(m.group(0).split('>')[1].split('<')[0]) or 'Stream',
            'url':      watch_url,
            'quality':  '',
            'language': '',
            'source':   'CrackStreams',
        })

    # Fallback to general link/iframe extraction
    if not streams:
        streams = _extract_stream_links(html, 'crackstreams', 'CrackStreams')

    xbmc.log('[Starfleet/Sports] CrackStreams "%s": %d streams' % (event_title, len(streams)), xbmc.LOGINFO)
    return streams


# ── Sportsurge (supplementary, Cloudflare-protected) ─────────────────────────

_SPORTSURGE_SLUGS = {
    'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'nhl': 'nhl',
    'ufc': 'mma', 'boxing': 'boxing', 'soccer': 'soccer', 'f1': 'motorsports',
}

_RE_SPORTSURGE_LINK = re.compile(
    r'<a[^>]+href="(https?://[^"]+)"[^>]*>\s*([^<]+)\s*</a>',
    re.IGNORECASE
)


_RE_NEXT_DATA = re.compile(r'<script[^>]+id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.IGNORECASE | re.DOTALL)


def _sportsurge_streams(sport_slug, event_title=''):
    if sport_slug not in _SPORTSURGE_SLUGS:
        return []

    surge_slug = _SPORTSURGE_SLUGS[sport_slug]
    title_words = [w.lower() for w in re.split(r'\W+', event_title) if len(w) > 3] if event_title else []
    streams = []

    # Strategy 1: Try the REST API endpoints that Next.js sites commonly expose
    api_urls = []
    for _sb in _SPORTSURGE_BASES:
        api_urls += [
            '%s/api/streams?sport=%s' % (_sb, surge_slug),
            '%s/api/events?sport=%s' % (_sb, surge_slug),
            '%s/api/%s' % (_sb, surge_slug),
        ]
    for api_url in api_urls:
        try:
            r = _cf_sess().get(api_url, timeout=10, headers=dict(_HEADERS, Accept='application/json'))
            if r.status_code == 200 and 'json' in r.headers.get('content-type', ''):
                data = r.json()
                # Flatten any list structures and look for stream URLs
                items = data if isinstance(data, list) else data.get('streams', data.get('events', data.get('data', [])))
                for item in (items if isinstance(items, list) else []):
                    item_title = item.get('title', item.get('name', item.get('event', '')))
                    item_url   = item.get('url', item.get('stream', item.get('link', '')))
                    if not item_url:
                        continue
                    if title_words and not any(w in item_title.lower() for w in title_words):
                        continue
                    streams.append({
                        'label':    item_title or 'Sportsurge Stream',
                        'url':      item_url,
                        'quality':  item.get('quality', ''),
                        'language': '',
                        'source':   'Sportsurge',
                    })
                if streams:
                    xbmc.log('[Starfleet/Sports] Sportsurge API "%s": %d streams' % (event_title, len(streams)), xbmc.LOGINFO)
                    return streams
        except Exception:
            pass

    # Strategy 2: Fetch the page and parse __NEXT_DATA__ JSON (Next.js hydration data)
    html = None
    for _surge_base in _SPORTSURGE_BASES:
        try:
            r = _cf_sess().get(_surge_base + '/' + surge_slug, timeout=15,
                               headers=dict(_HEADERS, Referer='https://www.google.com/'))
            if r.status_code == 200:
                html = r.text
                break
        except Exception as e:
            xbmc.log('[Starfleet/Sports] Sportsurge page fetch error (%s): %s' % (_surge_base, e), xbmc.LOGWARNING)
    if html is None:
        xbmc.log('[Starfleet/Sports] Sportsurge all base URLs failed for %s' % surge_slug, xbmc.LOGWARNING)
        return []

    m_nd = _RE_NEXT_DATA.search(html)
    if m_nd:
        try:
            import json as _json
            nd = _json.loads(m_nd.group(1))
            # Walk the props tree looking for stream/event data
            def _walk(obj, depth=0):
                if depth > 8:
                    return
                if isinstance(obj, dict):
                    url = obj.get('url', obj.get('stream', obj.get('link', '')))
                    title = obj.get('title', obj.get('name', obj.get('event', '')))
                    if url and url.startswith('http'):
                        if not title_words or any(w in str(title).lower() for w in title_words):
                            streams.append({
                                'label':    str(title) or 'Sportsurge Stream',
                                'url':      url,
                                'quality':  str(obj.get('quality', '')),
                                'language': '',
                                'source':   'Sportsurge',
                            })
                    for v in obj.values():
                        _walk(v, depth + 1)
                elif isinstance(obj, list):
                    for v in obj:
                        _walk(v, depth + 1)
            _walk(nd)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] Sportsurge __NEXT_DATA__ parse error: %s' % e, xbmc.LOGWARNING)

    if streams:
        xbmc.log('[Starfleet/Sports] Sportsurge NEXT_DATA "%s": %d streams' % (event_title, len(streams)), xbmc.LOGINFO)
        return streams[:10]

    # Strategy 3: Fall back to plain link extraction from HTML
    # On a sport-specific page all links are for that sport — don't filter by title
    # (stream texts like "Stream 1" / "Watch" never contain team names)
    for m in _RE_SPORTSURGE_LINK.finditer(html):
        link_url  = m.group(1).strip()
        link_text = _clean(m.group(2))
        if not link_text or len(link_text) < 3:
            continue
        streams.append({
            'label':    link_text,
            'url':      link_url,
            'quality':  '',
            'language': '',
            'source':   'Sportsurge',
        })
        if len(streams) >= 10:
            break

    xbmc.log('[Starfleet/Sports] Sportsurge HTML "%s": %d streams' % (event_title, len(streams)), xbmc.LOGINFO)
    return streams


# ── TotalSportek24 (multi-sport) ─────────────────────────────────────────────

# Maps our internal slugs to TotalSportek24 URL path segments
_TSTEK_SLUGS = {
    'soccer':  'soccer-streams',
    'nfl':     'nfl-streams',
    'nba':     'nba-streams',
    'nhl':     'nhl-streams',
    'mlb':     'mlb-streams',
    'ufc':     'ufc-streams',
    'boxing':  'boxing-streams',
    'f1':      'f1-streams',
    'cfb':     'college-football-streams',
    'ncaab':   'college-basketball-streams',
    'wwe':     'wwe-streams',
    'tennis':  'tennis-streams',
    'rugby':   'rugby-streams',
    'cricket': 'cricket-streams',
    'motogp':  'motogp-streams',
}

# Event card: <a href="/game/..."><div>...<span>TIME UTC</span>...<div class="row my-auto">TITLE</div>...</div></a>
_RE_TSTEK_GAME_CARD = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/game/[^"#\s]{4,120})"[^>]*>'
    r'.*?<span>\s*(\d+:\d+\s*(?:am|pm)[^<]*?)\s*</span>'
    r'.*?<div[^>]+class="row[^"]*my-auto[^"]*"[^>]*>\s*([^<]{3,120}?)\s*</div>',
    re.IGNORECASE | re.DOTALL
)

# Fallback: plain text anchor (older page layout)
_RE_TSTEK_EVENT = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^"#\s]{4,120})"[^>]*>'
    r'\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

# Nav links used to discover which sport sections actually exist on the site
_RE_TSTEK_NAV = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^/"]+/?)"[^>]*>'
    r'\s*([^<]{2,40}?)\s*</a>',
    re.IGNORECASE
)

# Cache the scraped nav/sport-section map across calls
_tstek_sport_urls = {}   # slug → full URL to that sport's schedule page


def _tstek_discover():
    """
    Fetch TotalSportek24 homepage and build a map of sport-slug → URL.
    Caches the result in _tstek_sport_urls for the session.
    """
    global _tstek_sport_urls
    if _tstek_sport_urls:
        return _tstek_sport_urls

    ck = 'tstek_sport_urls'
    cached = _cache.get(ck)
    if cached:
        _tstek_sport_urls = cached
        return _tstek_sport_urls

    try:
        html = _sess().get(TSTEK_BASE + '/', timeout=12,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 homepage error: %s' % e, xbmc.LOGWARNING)
        return {}

    # Build reverse map: url-path-segment → our slug
    reverse = {v: k for k, v in _TSTEK_SLUGS.items()}
    result  = {}

    for m in _RE_TSTEK_NAV.finditer(html):
        href    = m.group(1).rstrip('/')
        segment = href.rstrip('/').rsplit('/', 1)[-1].lower()
        if segment in reverse:
            our_slug = reverse[segment]
            result[our_slug] = href
            xbmc.log('[Starfleet/Sports] TotalSportek24 found sport: %s → %s' % (our_slug, href), xbmc.LOGINFO)

    # Fallback: construct URLs from the known slug map for any missing sports
    for our_slug, tstek_slug in _TSTEK_SLUGS.items():
        if our_slug not in result:
            result[our_slug] = '%s/%s/' % (TSTEK_BASE, tstek_slug)

    _tstek_sport_urls = result
    _cache.set(ck, result, 60 * 60)  # cache 1 hour
    return result


def _tstek_events(sport_slug):
    """Scrape TotalSportek24 for events matching the given sport slug."""
    import calendar as _cal

    ck = 'sports_tstek_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    sport_url = '%s/%s' % (TSTEK_BASE, _TSTEK_SLUGS.get(sport_slug, sport_slug + '-streams'))
    try:
        html = _sess().get(sport_url, timeout=12,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 sport page error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()
    now_utc = datetime.datetime.utcnow()

    # Primary: new card layout with /game/ URLs, inline time and title
    for m in _RE_TSTEK_GAME_CARD.finditer(html):
        href     = m.group(1).strip()
        raw_time = m.group(2).strip()   # e.g. "01:00 am  UTC"
        title    = _clean(m.group(3))
        if not title or href in seen:
            continue
        seen.add(href)

        # Parse UTC time into a timestamp (assume today or tomorrow)
        start_ts = 0
        try:
            time_only = re.search(r'(\d+):(\d+)\s*(am|pm)', raw_time, re.I)
            if time_only:
                hh = int(time_only.group(1)) % 12
                if time_only.group(3).lower() == 'pm':
                    hh += 12
                mm = int(time_only.group(2))
                dt_utc = now_utc.replace(hour=hh, minute=mm, second=0, microsecond=0)
                # If time already passed today, assume it's tomorrow
                if dt_utc < now_utc and (now_utc - dt_utc).seconds > 3600:
                    dt_utc = dt_utc + datetime.timedelta(days=1)
                start_ts = int(_cal.timegm(dt_utc.timetuple()))
        except Exception:
            pass

        events.append({
            'id':       'tstek_' + re.sub(r'\W+', '_', href),
            'slug':     href.replace(TSTEK_BASE, '').strip('/'),
            'path':     'tstek:' + href,
            'title':    title,
            'datetime': raw_time,
            'league':   sport_slug.upper(),
            'logo':     '',
            'is_live':  False,
            'start_ts': start_ts or int(time.time()),
        })

    # Fallback: older plain-text anchor layout
    if not events:
        tstek_seg  = _TSTEK_SLUGS.get(sport_slug, sport_slug)
        is_soccer  = (sport_slug == 'soccer')
        other_segs = set(_TSTEK_SLUGS.values()) - {tstek_seg}
        skip_words = {'schedule', 'fixtures', 'results', 'standings', 'news', 'about',
                      'contact', 'privacy', 'home', 'live', 'stream', 'watch', tstek_seg}
        for m in _RE_TSTEK_EVENT.finditer(html):
            href  = m.group(1).strip()
            title = _clean(m.group(2))
            if not title or len(title) < 5 or href in seen:
                continue
            path_parts = href.replace(TSTEK_BASE, '').strip('/').split('/')
            if is_soccer:
                if path_parts[0].lower() in other_segs:
                    continue
            else:
                if not path_parts or path_parts[0].lower() != tstek_seg.lower():
                    continue
            if title.lower() in skip_words:
                continue
            seen.add(href)
            events.append({
                'id':       'tstek_' + re.sub(r'\W+', '_', href),
                'slug':     href.replace(TSTEK_BASE, '').strip('/'),
                'path':     'tstek:' + href,
                'title':    title,
                'datetime': '',
                'league':   sport_slug.upper(),
                'logo':     '',
                'is_live':  False,
                'start_ts': int(time.time()),
            })

    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] TotalSportek24 %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _tstek_streams(event_path):
    """Scrape stream links from a TotalSportek24 event page."""
    url = event_path.replace('tstek:', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, 'totalsportek24.is', 'TotalSportek')
    xbmc.log('[Starfleet/Sports] TotalSportek24 streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _tstek_streams_by_title(sport_slug, event_title):
    """Cross-reference: find best TotalSportek24 event by title and scrape its streams."""
    try:
        evs = _tstek_events(sport_slug)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tstek_x events error: %s' % e, xbmc.LOGWARNING)
        return []
    best_path, best_score, best_title = None, 0, ''
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
            best_title = ev['title']
    xbmc.log('[Starfleet/Sports] tstek_x "%s" vs %d events: best="%s" score=%d path=%s'
             % (event_title, len(evs), best_title, best_score, best_path), xbmc.LOGINFO)
    if not best_path or best_score < 1:
        return []
    try:
        return _tstek_streams(best_path)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] tstek_x streams error: %s' % e, xbmc.LOGWARNING)
        return []


# ── *24all.ir generic helpers ─────────────────────────────────────────────────

def _x24_events(domain, sport_label, path_prefix):
    """Generic scraper for *24all.ir sites (mlb24all.ir, nhl24all.ir, nfl24all.ir, nba24all.ir)."""
    base = 'https://' + domain
    pattern = re.compile(
        r'<a[^>]+href="(https?://' + re.escape(domain) + r'/[^"]+)"[^>]*>([^<]+)</a>',
        re.IGNORECASE
    )
    try:
        html = _sess().get(base + '/', timeout=12,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s fetch error: %s' % (domain, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()
    skip_words = ('home', 'schedule', 'about', 'contact', 'privacy', domain.split('.')[0])

    for m in pattern.finditer(html):
        path  = m.group(1).strip()
        title = _clean(m.group(2))
        if not title or len(title) < 4 or path in seen:
            continue
        if any(s in title.lower() for s in skip_words):
            continue
        seen.add(path)
        events.append({
            'id':       path_prefix + re.sub(r'\W+', '_', path),
            'slug':     re.sub(r'https?://' + re.escape(domain) + r'/', '', path).strip('/'),
            'path':     path_prefix + ':' + path,
            'title':    title,
            'datetime': '',
            'league':   sport_label,
            'logo':     '',
            'is_live':  True,
            'start_ts': 0,
        })

    xbmc.log('[Starfleet/Sports] %s: %d events' % (domain, len(events)), xbmc.LOGINFO)
    return events


def _x24_streams(event_path, path_prefix, domain, source_label):
    """Generic stream scraper for *24all.ir event pages."""
    url = event_path.replace(path_prefix + ':', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer='https://' + domain + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s stream page error (%s): %s' % (domain, event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, domain, source_label)

    # Also pick up any explicit watch/stream/live anchors not caught above
    extra_re = re.compile(
        r'<a[^>]+href="(https?://[^"]+)"[^>]*>(?:[^<]*(?:watch|stream|live)[^<]*)</a>',
        re.IGNORECASE
    )
    for m in extra_re.finditer(html):
        su = m.group(1).strip()
        if not su or domain in su:
            continue
        if not any(s['url'] == su for s in streams):
            streams.append({'label': source_label + ' Stream', 'url': su,
                            'quality': '', 'language': '', 'source': source_label})

    xbmc.log('[Starfleet/Sports] %s streams for %s: %d' % (domain, event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _x24_streams_by_title(event_title, domain, path_prefix, sport_label, source_label):
    """Cross-reference: find best matching event on *24all.ir and scrape its streams."""
    evs = _x24_events(domain, sport_label, path_prefix)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _x24_streams(best_path, path_prefix, domain, source_label)


# ── mlb24all.ir (MLB-specific) ────────────────────────────────────────────────

_RE_MLB24_EVENT = re.compile(
    r'<a[^>]+href="(https?://mlb24all\.ir/[^"]+)"[^>]*>([^<]+)</a>',
    re.IGNORECASE
)
# Sport-specific wrappers using the generic _x24_* helpers

def _mlb24_events():
    return _x24_events('mlb24all.ir', 'MLB', 'mlb24')

def _mlb24_streams(event_path):
    return _x24_streams(event_path, 'mlb24', 'mlb24all.ir', 'MLB24')

def _mlb24_streams_by_title_inner(event_title):
    return _x24_streams_by_title(event_title, 'mlb24all.ir', 'mlb24', 'MLB', 'MLB24')


def _nhl24_events():
    return _x24_events('nhl24all.ir', 'NHL', 'nhl24')

def _nhl24_streams(event_path):
    return _x24_streams(event_path, 'nhl24', 'nhl24all.ir', 'NHL24')

def _nhl24_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'nhl24all.ir', 'nhl24', 'NHL', 'NHL24')


def _nfl24_events():
    return _x24_events('nfl24all.ir', 'NFL', 'nfl24')

def _nfl24_streams(event_path):
    return _x24_streams(event_path, 'nfl24', 'nfl24all.ir', 'NFL24')

def _nfl24_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'nfl24all.ir', 'nfl24', 'NFL', 'NFL24')


def _nba24_events():
    return _x24_events('nba24all.ir', 'NBA', 'nba24')

def _nba24_streams(event_path):
    return _x24_streams(event_path, 'nba24', 'nba24all.ir', 'NBA24')

def _nba24_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'nba24all.ir', 'nba24', 'NBA', 'NBA24')



# ── JustWatch Sports (where-to-watch sports schedule) ───────────────────────

JUSTWATCH_SPORTS_URL = 'https://apis.justwatch.com/sports/schedule'
JUSTWATCH_GQL_URL    = 'https://gql.justwatch.com/graphql'

_JW_SPORT_MAP = {
    'nfl':    'american_football',
    'nba':    'basketball',
    'mlb':    'baseball',
    'nhl':    'hockey',
    'soccer': 'soccer',
    'ufc':    'mma',
    'boxing': 'boxing',
    'f1':     'formula_one',
    'cfb':    'american_football',
    'ncaab':  'basketball',
}

_RE_JW_NEXT = re.compile(r'<script[^>]+id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.IGNORECASE | re.DOTALL)


def _justwatch_sports_events(sport_slug):
    """Scrape sports.justwatch.com/us for upcoming events in a given sport."""
    jw_sport = _JW_SPORT_MAP.get(sport_slug)

    # Strategy 1: Try the REST schedule API
    try:
        params = 'country=US&language=en'
        if jw_sport:
            params += '&sport=%s' % jw_sport
        r = _sess().get('%s?%s' % (JUSTWATCH_SPORTS_URL, params), timeout=10,
                        headers=dict(_HEADERS, Accept='application/json', Referer='https://sports.justwatch.com/'))
        if r.status_code == 200:
            data = r.json()
            items = data if isinstance(data, list) else (
                data.get('items') or data.get('events') or data.get('data') or []
            )
            events = []
            now_ts = int(time.time())
            for item in items[:30]:
                title_str = (item.get('title') or item.get('name') or
                             '%s vs %s' % (item.get('home', {}).get('name', ''),
                                           item.get('away', {}).get('name', '')))
                title_str = title_str.strip(' vs ')
                if not title_str or len(title_str) < 3:
                    continue
                start_ts, dt_str = _ts_to_dt(item.get('startAt') or item.get('start_at', ''))
                sport_cat = item.get('sport') or item.get('sportSlug', sport_slug)
                cat_slug = next((k for k, v in _JW_SPORT_MAP.items() if v == sport_cat), sport_slug)
                if jw_sport and sport_cat and sport_cat != jw_sport:
                    continue
                events.append({
                    'id':       'jw_%s' % re.sub(r'\W+', '_', title_str.lower())[:40],
                    'slug':     re.sub(r'\W+', '-', title_str.lower())[:60],
                    'path':     '',
                    'title':    title_str,
                    'datetime': dt_str,
                    'league':   (item.get('leagueName') or sport_slug.upper()),
                    'logo':     '',
                    'is_live':  item.get('isLive', False),
                    'start_ts': start_ts or now_ts,
                })
            if events:
                xbmc.log('[Starfleet/Sports] JustWatch %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
                return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] JustWatch REST error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)

    # Strategy 2: Scrape the sports.justwatch.com/us page and extract __NEXT_DATA__
    try:
        page_slug = jw_sport.replace('_', '-') if jw_sport else sport_slug
        r = _sess().get('https://sports.justwatch.com/us/%s' % page_slug, timeout=12,
                        headers=dict(_HEADERS, Referer='https://sports.justwatch.com/'))
        html = r.text
        m_nd = _RE_JW_NEXT.search(html)
        if m_nd:
            import json as _json
            nd     = _json.loads(m_nd.group(1))
            events = []
            now_ts = int(time.time())

            def _walk_jw(obj, depth=0):
                if depth > 10:
                    return
                if isinstance(obj, dict):
                    title_str = (obj.get('title') or obj.get('name') or
                                 obj.get('eventTitle') or '')
                    start_raw = (obj.get('startAt') or obj.get('startTime') or
                                 obj.get('start') or '')
                    if title_str and len(title_str) > 3 and (start_raw or obj.get('isLive')):
                        start_ts, dt_str = _ts_to_dt(start_raw) if start_raw else (now_ts, '')
                        events.append({
                            'id':       'jw_%s' % re.sub(r'\W+', '_', title_str.lower())[:40],
                            'slug':     re.sub(r'\W+', '-', title_str.lower())[:60],
                            'path':     '',
                            'title':    title_str,
                            'datetime': dt_str,
                            'league':   sport_slug.upper(),
                            'logo':     '',
                            'is_live':  obj.get('isLive', False),
                            'start_ts': start_ts or now_ts,
                        })
                    for v in obj.values():
                        _walk_jw(v, depth + 1)
                elif isinstance(obj, list):
                    for v in obj:
                        _walk_jw(v, depth + 1)

            _walk_jw(nd)
            if events:
                seen_titles = set()
                deduped = []
                for e in events:
                    if e['title'] not in seen_titles:
                        seen_titles.add(e['title'])
                        deduped.append(e)
                xbmc.log('[Starfleet/Sports] JustWatch NEXT_DATA %s: %d events' % (sport_slug, len(deduped)), xbmc.LOGINFO)
                return deduped[:30]
    except Exception as e:
        xbmc.log('[Starfleet/Sports] JustWatch scrape error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)

    return []


# ── ppv.to (PPV sports — Cloudflare-protected, uses cfscrape) ────────────────

# Category keyword → our sport slug
_PPV_CAT_MAP = [
    ('boxing',    'boxing'),
    ('ufc',       'ufc'),
    ('mma',       'ufc'),
    ('wrestl',    'wwe'),
    ('wwe',       'wwe'),
    ('soccer',    'soccer'),
    ('football',  'soccer'),
    ('formula',   'f1'),
    ('f1',        'f1'),
    ('nfl',       'nfl'),
    ('nba',       'nba'),
    ('nhl',       'nhl'),
    ('mlb',       'mlb'),
    ('basket',    'nba'),
    ('hockey',    'nhl'),
    ('baseball',  'mlb'),
]

# Event cards: links to /live/{slug} or /watch/{slug}
_RE_PPV_CARD = re.compile(
    r'<a[^>]+href="(/(?:live|watch|event|stream)/([^"#\s/]{3,80}))"[^>]*>',
    re.IGNORECASE
)
# Title text following the card link open tag
_RE_PPV_TITLE = re.compile(r'<[^>]*class="[^"]*(?:title|name|event)[^"]*"[^>]*>([^<]{3,120})', re.IGNORECASE)
# Fallback: any internal link with visible text
_RE_PPV_FALLBACK = re.compile(
    r'<a[^>]+href="(/(?:live|watch|event|stream)/([^"#\s/]{3,80}))"[^>]*>\s*([^<\r\n]{3,100})\s*</a>',
    re.IGNORECASE
)


def _ppvto_detect_sport(text):
    """Return our sport slug for a given title/context string, or empty string."""
    t = text.lower()
    for keyword, slug in _PPV_CAT_MAP:
        if keyword in t:
            return slug
    return ''


def _ppvto_events(sport_slug):
    """Scrape ppv.to for upcoming / live events (Cloudflare — uses cfscrape)."""
    try:
        r = _cf_sess().get(PPV_BASE + '/', timeout=15,
                           headers=dict(_HEADERS, Referer='https://www.google.com/'))
        r.raise_for_status()
        html = r.text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ppv.to fetch error: %s' % e, xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()
    skip_nav = {'home', 'schedule', 'about', 'contact', 'login', 'register',
                'privacy', 'terms', 'faq', 'chat', 'discord', 'live', 'watch',
                'signup', 'sign-up', 'logout', 'account', 'profile', 'settings',
                'forum', 'support', 'help', 'streams', 'events', 'news'}

    def _add_event(path, slug, title, cat='', is_live=True, dt='', ts=0):
        if path in seen or not title or len(title) < 3:
            return
        seen.add(path)
        if title.lower().strip() in skip_nav:
            return
        det_cat = cat or _ppvto_detect_sport(title + ' ' + slug)
        if sport_slug and det_cat and det_cat != sport_slug:
            return
        events.append({
            'id':       'ppvto_' + slug,
            'slug':     slug,
            'path':     'ppvto:' + PPV_BASE + path,
            'title':    title,
            'datetime': dt,
            'league':   (det_cat or sport_slug or 'PPV').upper(),
            'logo':     '',
            'is_live':  is_live,
            'start_ts': ts,
        })

    # Strategy 1: structured card (original regex)
    for m in _RE_PPV_CARD.finditer(html):
        path, slug = m.group(1), m.group(2)
        block = html[m.end():m.end() + 600]
        mt    = _RE_PPV_TITLE.search(block)
        title = _clean(mt.group(1)) if mt else slug.replace('-', ' ').title()
        _add_event(path, slug, title)

    # Strategy 2: rewritten site — any <a> with event/live/watch/stream path + visible title
    if not events:
        _RE_PPV_GENERIC = re.compile(
            r'<a[^>]+href="(/(?:live|watch|event|stream|sports?|matches?|channels?)/([^"#\s/]{2,80}))"[^>]*>'
            r'(?:[^<]*<[^>]+>)*\s*([^<\r\n]{3,100}?)\s*(?:</[^>]+>)*\s*</a>',
            re.IGNORECASE | re.DOTALL
        )
        for m in _RE_PPV_GENERIC.finditer(html):
            path, slug, raw_title = m.group(1), m.group(2), m.group(3)
            title = _clean(re.sub(r'<[^>]+>', '', raw_title))
            if not title or title.lower().strip() in skip_nav:
                continue
            _add_event(path, slug, title)

    # Strategy 3: simpler inline anchor text (original fallback)
    if not events:
        for m in _RE_PPV_FALLBACK.finditer(html):
            path, slug, title = m.group(1), m.group(2), _clean(m.group(3))
            _add_event(path, slug, title)

    # Strategy 4: slug-based title extraction if still empty
    if not events:
        _RE_ANY_SLUG = re.compile(
            r'href="(/(?:live|watch|event|stream)/([a-z0-9][a-z0-9-]{4,60}))"',
            re.IGNORECASE
        )
        for m in _RE_ANY_SLUG.finditer(html):
            path, slug = m.group(1), m.group(2)
            title = slug.replace('-', ' ').title()
            _add_event(path, slug, title)

    xbmc.log('[Starfleet/Sports] ppv.to: %d events for %s' % (len(events), sport_slug), xbmc.LOGINFO)
    return events


def _ppvto_streams(event_path):
    """Scrape stream links from a ppv.to event page."""
    url = event_path.replace('ppvto:', '')
    try:
        html = _cf_sess().get(url, timeout=15,
                              headers=dict(_HEADERS, Referer=PPV_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ppv.to event page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []
    streams = _extract_stream_links(html, 'ppv.to', 'PPV.to')
    xbmc.log('[Starfleet/Sports] ppv.to streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _ppvto_streams_by_title(sport_slug, event_title):
    """Cross-reference: find ppv.to event by title match and scrape its streams."""
    evs = _ppvto_events(sport_slug)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _ppvto_streams(best_path)


# ── onhockey.tv (all hockey leagues) ─────────────────────────────────────────

# In-memory cache for inline stream links scraped from schedule_table.php
_ONHOCKEY_STREAM_CACHE = {}

_RE_ONHOCKEY_TBODY   = re.compile(r"<tbody[^>]*class=['\"]([^'\"]*)['\"][^>]*>(.*?)</tbody>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_LEAGUE  = re.compile(r'<b>([A-Z][A-Z0-9 /\-]{1,20})</b>', re.IGNORECASE)
_RE_ONHOCKEY_GAMEROW = re.compile(r"<tr class='game'[^>]*>(.*?)</tr>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_HOUR    = re.compile(r"class='game_hour'[^>]*>(\d+)</text>:(\d+)", re.IGNORECASE)
_RE_ONHOCKEY_TITLE   = re.compile(r"</td><td>([^<\n]{3,100})", re.IGNORECASE)
_RE_ONHOCKEY_GL      = re.compile(r"class='gamelinks'[^>]*>(.*?)</div>", re.DOTALL | re.IGNORECASE)
_RE_ONHOCKEY_CHAN    = re.compile(r"href='np_stream400\.php\?channel=([^'\"&]{5,200})'[^>]*(?:title='([^']*)')?", re.IGNORECASE)

_RE_ONHOCKEY_WATCH = re.compile(
    r'<a[^>]+href="(https?://(?!onhockey\.tv)[^"]{10,200})"[^>]*>([^<]*(?:Watch|Stream|Link|HD|Mirror|\d)[^<]*)</a>',
    re.IGNORECASE
)
_RE_ONHOCKEY_NUMBERED = re.compile(
    r'<a[^>]+href="(https?://(?!onhockey\.tv)[^"]{10,200})"[^>]*>\s*(?:(?:Stream|Link|Watch|HD)\s*)?\d+\s*</a>',
    re.IGNORECASE
)


_ONHOCKEY_LEAGUE_KEYWORDS = [
    ('AHL',   ('ahl',)),
    ('KHL',   ('khl',)),
    ('OHL',   ('ohl',)),
    ('WHL',   ('whl',)),
    ('QMJHL', ('qmjhl', 'lhjmq')),
    ('ECHL',  ('echl',)),
    ('SHL',   ('shl',)),
    ('DEL',   ('del ',)),
    ('NCAA',  ('ncaa', 'college hockey', 'university')),
    ('IIHF',  ('iihf', 'world championship', 'world cup of hockey')),
    ('PHF',   ('phf', 'premier hockey')),
    ('PWHL',  ('pwhl',)),
    ('NWHL',  ('nwhl',)),
]


def _onhockey_league(title):
    """Detect hockey league from event title; defaults to NHL."""
    t = title.lower()
    for league, keywords in _ONHOCKEY_LEAGUE_KEYWORDS:
        if any(k in t for k in keywords):
            return league
    return 'NHL'


def _onhockey_events():
    """Scrape onhockey.tv schedule via schedule_table.php (AJAX endpoint).
    Parses tbody/game-row structure, caches inline stream links per event.
    """
    import datetime as _dt
    import calendar as _cal

    global _ONHOCKEY_STREAM_CACHE

    try:
        r = _sess().get(
            ONHOCKEY_BASE + '/schedule_table.php',
            timeout=12,
            headers=dict(_HEADERS,
                         Referer=ONHOCKEY_BASE + '/',
                         **{'X-Requested-With': 'XMLHttpRequest'}),
        )
        r.raise_for_status()
        html = r.text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] onhockey.tv schedule error: %s' % e, xbmc.LOGWARNING)
        return []

    events = []
    _ONHOCKEY_STREAM_CACHE = {}
    current_league = 'NHL'
    # Default to today UTC; updated when we hit a Date row
    _now_utc = _dt.datetime.utcnow()
    current_date = _now_utc.date()
    current_year = _now_utc.year

    for tbody_m in _RE_ONHOCKEY_TBODY.finditer(html):
        tbody_class = tbody_m.group(1)
        tbody_html  = tbody_m.group(2)

        if 'Date' in tbody_class:
            # Parse date like "<b>July 3</b>"
            dm = re.search(r'<b>(\w+ \d+)</b>', tbody_html)
            if dm:
                try:
                    current_date = _dt.datetime.strptime(
                        '%s %d' % (dm.group(1), current_year), '%B %d %Y'
                    ).date()
                except Exception:
                    pass
            continue

        # League name from the bold header in this tbody
        lhdr = _RE_ONHOCKEY_LEAGUE.search(tbody_html)
        if lhdr:
            current_league = lhdr.group(1).strip()

        for game_m in _RE_ONHOCKEY_GAMEROW.finditer(tbody_html):
            row_html = game_m.group(1)

            title_m = _RE_ONHOCKEY_TITLE.search(row_html)
            if not title_m:
                continue
            title = title_m.group(1).strip()
            if not title or len(title) < 3:
                continue

            hour_m = _RE_ONHOCKEY_HOUR.search(row_html)
            start_ts = 0
            date_label = ''
            if hour_m:
                try:
                    hh = int(hour_m.group(1))
                    mm = int(hour_m.group(2))
                    dt_utc = _dt.datetime(
                        current_date.year, current_date.month, current_date.day, hh, mm, 0
                    )
                    start_ts = int(_cal.timegm(dt_utc.timetuple()))
                    # Human date label e.g. "Jul 3"
                    date_label = current_date.strftime('%b %-d') if hasattr(current_date, 'strftime') else str(current_date)
                except Exception:
                    pass

            # Extract inline stream links from gamelinks div
            links = []
            gl_m = _RE_ONHOCKEY_GL.search(row_html)
            if gl_m:
                for lm in _RE_ONHOCKEY_CHAN.finditer(gl_m.group(1)):
                    chan = lm.group(1).strip()
                    if chan.startswith('//'):
                        chan = 'https:' + chan
                    elif not chan.startswith('http'):
                        chan = ONHOCKEY_BASE + '/' + chan.lstrip('/')
                    lbl = lm.group(2) or title
                    links.append({
                        'label': '[OnHockey] %s' % lbl,
                        'url': chan,
                        'quality': '', 'language': '', 'source': 'OnHockey.tv',
                    })

            ev_id = 'onhockey_%s_%s_%s' % (
                re.sub(r'\W+', '_', current_league.lower()),
                str(current_date),
                re.sub(r'\W+', '_', title.lower())[:50],
            )

            if links:
                _ONHOCKEY_STREAM_CACHE[ev_id] = links

            events.append({
                'id':         ev_id,
                'slug':       ev_id,
                'path':       'onhockey:' + ev_id,
                'title':      title,
                'date_label': date_label,
                'league':     current_league,
                'logo':       '',
                'is_live':    bool(links),
                'start_ts':   start_ts,
            })

    xbmc.log('[Starfleet/Sports] onhockey.tv: %d events across %d leagues' % (
        len(events), len(set(e['league'] for e in events))), xbmc.LOGINFO)
    return events


def _onhockey_streams(event_path):
    """Return stream links for an onhockey.tv event.
    Checks the in-memory stream cache first (populated by _onhockey_events()).
    Falls back to fetching the game page URL if the path is a full URL.
    """
    ev_id = event_path.replace('onhockey:', '')

    # Try in-memory cache (schedule_table.php inline links)
    cached = _ONHOCKEY_STREAM_CACHE.get(ev_id)
    if cached:
        xbmc.log('[Starfleet/Sports] onhockey.tv cached streams for %s: %d' % (ev_id, len(cached)), xbmc.LOGINFO)
        return cached

    # Fallback: ev_id is a full URL (old-style path)
    if not ev_id.startswith('http'):
        xbmc.log('[Starfleet/Sports] onhockey.tv no streams cached for %s' % ev_id, xbmc.LOGINFO)
        return []

    try:
        html = _sess().get(ev_id, timeout=12,
                           headers=dict(_HEADERS, Referer=ONHOCKEY_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] onhockey.tv stream page error (%s): %s' % (ev_id, e), xbmc.LOGWARNING)
        return []

    streams = []
    seen_urls = set()

    for m in _RE_ONHOCKEY_WATCH.finditer(html):
        su    = m.group(1).strip()
        label = _clean(m.group(2)) or 'OnHockey Stream'
        if su and su not in seen_urls:
            streams.append({'label': label, 'url': su,
                            'quality': '', 'language': '', 'source': 'OnHockey.tv'})
            seen_urls.add(su)

    for m in _RE_ONHOCKEY_NUMBERED.finditer(html):
        su = m.group(1).strip()
        if su and su not in seen_urls:
            streams.append({'label': 'OnHockey Stream', 'url': su,
                            'quality': '', 'language': '', 'source': 'OnHockey.tv'})
            seen_urls.add(su)

    if not streams:
        streams = _extract_stream_links(html, 'onhockey.tv', 'OnHockey.tv')

    xbmc.log('[Starfleet/Sports] onhockey.tv streams for %s: %d' % (ev_id, len(streams)), xbmc.LOGINFO)
    return streams


def _onhockey_streams_by_title(event_title):
    """Cross-reference: find onhockey.tv game by title match and scrape its streams."""
    evs = _onhockey_events()
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _onhockey_streams(best_path)


# ── totalsportek (original — multi-sport, distinct from totalsportek24.is) ────

# Try several known mirrors in order; resolve once and cache
_TSPORTEK_HOSTS = [
    'https://www.totalsportek.to',
    'https://totalsportek.to',
    'https://www.totalsportek.com',
    'https://totalsportek.com',
    'https://totalsportek2.com',
    'https://www.totalsportek2.com',
]
_tsportek_base_url = [None]   # mutable list so inner funcs can write it

# Sport → list of path candidates to try in order
_TSPORTEK_SPORT_PATHS = {
    'nhl':     ['/nhl-streams/', '/nhl-live-stream/', '/ice-hockey-live-stream/'],
    'nfl':     ['/nfl-streams/', '/nfl-live-stream/'],
    'nba':     ['/nba-streams/', '/nba-live-stream/'],
    'mlb':     ['/mlb-streams/', '/mlb-live-stream/'],
    'soccer':  ['/football-live-streaming/', '/soccer-streams/', '/football-streams/'],
    'ufc':     ['/ufc-streams/', '/ufc-live-stream/', '/mma-live-stream/'],
    'boxing':  ['/boxing-live-stream/', '/boxing-streams/'],
    'f1':      ['/formula-1-live-stream/', '/f1-live-stream/'],
    'cfb':     ['/college-football-live-stream/'],
    'ncaab':   ['/college-basketball-live-stream/'],
    'wwe':     ['/wwe-streams/', '/wwe-live-stream/'],
    'tennis':  ['/tennis-live-stream/', '/tennis-streams/'],
    'rugby':   ['/rugby-live-stream/', '/rugby-streams/', '/rugby-union-live-stream/'],
    'cricket': ['/cricket-live-stream/', '/cricket-streams/'],
    'motogp':  ['/motogp-live-stream/', '/motogp-streams/'],
}

_RE_TSPORTEK_EVENT = re.compile(
    r'<a[^>]+href="(https?://[^"#\s]{10,200})"[^>]*>\s*([^<]{5,120}?)\s*</a>',
    re.IGNORECASE
)
_RE_TSPORTEK_LIVE = re.compile(
    r'class="[^"]*(?:live|badge-live|status-live|is-live)[^"]*"',
    re.IGNORECASE
)


def _tsportek_base():
    """Return the first working totalsportek domain (cached for the session)."""
    if _tsportek_base_url[0]:
        return _tsportek_base_url[0]
    ck = 'tsportek_base_v1'
    cached = _cache.get(ck)
    if cached:
        _tsportek_base_url[0] = cached
        return cached
    for host in _TSPORTEK_HOSTS:
        try:
            r = _sess().get(host + '/', timeout=10,
                            headers=dict(_HEADERS, Referer='https://www.google.com/'),
                            allow_redirects=True)
            if r.status_code < 400:
                from urllib.parse import urlparse
                p = urlparse(r.url)
                base = '%s://%s' % (p.scheme, p.netloc)
                _tsportek_base_url[0] = base
                _cache.set(ck, base, 60 * 60)
                xbmc.log('[Starfleet/Sports] TotalSportek base: %s' % base, xbmc.LOGINFO)
                return base
        except Exception:
            pass
    xbmc.log('[Starfleet/Sports] TotalSportek: all hosts unreachable', xbmc.LOGWARNING)
    return None


def _tsportek_events(sport_slug):
    """Scrape totalsportek (original) for events matching sport_slug."""
    base = _tsportek_base()
    if not base:
        return []
    paths = _TSPORTEK_SPORT_PATHS.get(sport_slug)
    if not paths:
        return []

    html = None
    for path in paths:
        try:
            r = _sess().get(base + path, timeout=12,
                            headers=dict(_HEADERS, Referer=base + '/'))
            if r.status_code < 400:
                html = r.text
                break
        except Exception:
            pass
    if not html:
        xbmc.log('[Starfleet/Sports] TotalSportek sport page not found for %s' % sport_slug, xbmc.LOGWARNING)
        return []

    events    = []
    seen      = set()
    now_ts    = int(time.time())
    base_host = base.split('//')[-1].split('/')[0]
    skip_words = ('home', 'schedule', 'fixtures', 'results', 'standings', 'news',
                  'about', 'contact', 'privacy', 'live', 'stream', 'watch',
                  'reddit', 'twitter', 'facebook', 'telegram', 'discord')

    for m in _RE_TSPORTEK_EVENT.finditer(html):
        href  = m.group(1).strip()
        title = _clean(m.group(2))
        if not title or len(title) < 5 or href in seen:
            continue
        # Only follow links on the same domain
        if base_host not in href:
            continue
        path_part = href.replace(base, '').strip('/')
        if not path_part:
            continue
        first_seg = path_part.split('/')[0].lower()
        if first_seg in skip_words:
            continue
        if any(s in title.lower() for s in skip_words):
            continue
        seen.add(href)

        ctx = html[max(0, m.start() - 200):m.start() + 200]
        is_live = bool(_RE_TSPORTEK_LIVE.search(ctx))

        events.append({
            'id':       'tsportek_' + re.sub(r'\W+', '_', path_part),
            'slug':     path_part,
            'path':     'tsportek:' + href,
            'title':    title,
            'datetime': '',
            'league':   sport_slug.upper(),
            'logo':     '',
            'is_live':  is_live,
            'start_ts': now_ts,
        })

    xbmc.log('[Starfleet/Sports] TotalSportek %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _tsportek_streams(event_path):
    """Scrape stream links from a totalsportek event page."""
    url  = event_path.replace('tsportek:', '')
    base = _tsportek_base() or ''
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer=base + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []
    from urllib.parse import urlparse
    domain  = urlparse(url).netloc
    streams = _extract_stream_links(html, domain, 'TotalSportek')
    xbmc.log('[Starfleet/Sports] TotalSportek streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _tsportek_streams_by_title(sport_slug, event_title):
    """Cross-reference: find best totalsportek event by title and scrape its streams."""
    evs = _tsportek_events(sport_slug)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _tsportek_streams(best_path)


# ── Public stream API ─────────────────────────────────────────────────────────

def get_event_streams(event_path, event_id='', sport_slug='', title=''):
    """
    Fetch stream links for a specific event.
    Merges ISE streams + Roxiestreams + StreamsEast + CrackStreams + Sportsurge
    + MLB24/NHL24/NFL24/NBA24 + TotalSportek24 + ppv.to + OnHockey.tv + TotalSportek.
    Returns list of: {'label', 'url', 'quality', 'language', 'source'}
    """
    ck = ('sports_streams_%s' % event_id) if event_id else None
    if ck:
        cached = _cache.get(ck)
        if cached is not None:
            return cached

    streams = []

    # Determine event path source by prefix
    is_seast_path    = event_path and event_path.startswith('streamseast:')
    is_mlb24_path    = event_path and event_path.startswith('mlb24:')
    is_nhl24_path    = event_path and event_path.startswith('nhl24:')
    is_nfl24_path    = event_path and event_path.startswith('nfl24:')
    is_nba24_path    = event_path and event_path.startswith('nba24:')
    is_tstek_path    = event_path and event_path.startswith('tstek:')
    is_ppvto_path    = event_path and event_path.startswith('ppvto:')
    is_onhockey_path = event_path and event_path.startswith('onhockey:')
    is_tsportek_path = event_path and event_path.startswith('tsportek:')
    is_ise_path      = (event_path and not is_seast_path and not is_mlb24_path
                        and not is_nhl24_path and not is_nfl24_path and not is_nba24_path
                        and not is_tstek_path and not is_ppvto_path
                        and not is_onhockey_path and not is_tsportek_path)

    # Build parallel fetch tasks
    futures = {}
    ex = ThreadPoolExecutor(max_workers=10)
    try:
        if is_ise_path:
            futures['ise']        = ex.submit(_ise_event_streams, event_path, event_id)
        if is_ppvto_path:
            futures['ppvto']      = ex.submit(_ppvto_streams, event_path)
        if is_seast_path:
            futures['seast']      = ex.submit(_seast_event_streams, event_path)
        if is_mlb24_path:
            futures['mlb24']      = ex.submit(_mlb24_streams, event_path)
        if is_nhl24_path:
            futures['nhl24']      = ex.submit(_nhl24_streams, event_path)
        if is_nfl24_path:
            futures['nfl24']      = ex.submit(_nfl24_streams, event_path)
        if is_nba24_path:
            futures['nba24']      = ex.submit(_nba24_streams, event_path)
        if is_tstek_path:
            futures['tstek']      = ex.submit(_tstek_streams, event_path)
        if is_onhockey_path:
            futures['onhockey']   = ex.submit(_onhockey_streams, event_path)
        if is_tsportek_path:
            futures['tsportek']   = ex.submit(_tsportek_streams, event_path)
        if sport_slug:
            futures['roxie']      = ex.submit(_roxie_streams, sport_slug, title)
            if not is_seast_path and sport_slug in _SEAST_SLUGS:
                futures['seast_slug'] = ex.submit(_seast_event_streams_by_slug, sport_slug, title)
            futures['crack']      = ex.submit(_crack_event_streams, sport_slug, title)
            futures['surge']      = ex.submit(_sportsurge_streams, sport_slug, title)
        if sport_slug == 'mlb' and not is_mlb24_path:
            futures['mlb24_x']    = ex.submit(_mlb24_streams_by_title_inner, title)
        if sport_slug == 'nhl' and not is_nhl24_path:
            futures['nhl24_x']    = ex.submit(_nhl24_streams_by_title, title)
        if sport_slug == 'nhl' and not is_onhockey_path:
            futures['onhockey_x'] = ex.submit(_onhockey_streams_by_title, title)
        if sport_slug == 'nfl' and not is_nfl24_path:
            futures['nfl24_x']    = ex.submit(_nfl24_streams_by_title, title)
        if sport_slug == 'nba' and not is_nba24_path:
            futures['nba24_x']    = ex.submit(_nba24_streams_by_title, title)
        if sport_slug in _TSTEK_SLUGS and not is_tstek_path:
            futures['tstek_x']    = ex.submit(_tstek_streams_by_title, sport_slug, title)
        if not is_ppvto_path:
            futures['ppvto_x']    = ex.submit(_ppvto_streams_by_title, sport_slug, title)
        if sport_slug in _TSPORTEK_SPORT_PATHS and not is_tsportek_path:
            futures['tsportek_x'] = ex.submit(_tsportek_streams_by_title, sport_slug, title)

        for name, fut in futures.items():
            try:
                result = fut.result(timeout=12)
                if result:
                    streams += result
            except Exception as e:
                xbmc.log('[Starfleet/Sports] stream source error (%s): %s' % (name, e), xbmc.LOGWARNING)
    finally:
        ex.shutdown(wait=False)

    if ck:
        ttl = 5 * 60 if streams else 2 * 60
        _cache.set(ck, streams, ttl)

    xbmc.log('[Starfleet/Sports] event streams (%s/%s): %d total' % (sport_slug, event_id, len(streams)), xbmc.LOGINFO)
    return streams


def _seast_event_streams_by_slug(sport_slug, event_title):
    """
    Supplementary: fetch StreamsEast schedule for the sport, find matching event, get streams.
    Used when the event did NOT come from StreamsEast.
    """
    try:
        seast_evs = _seast_events(sport_slug)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] seast_event_streams_by_slug error: %s' % e, xbmc.LOGWARNING)
        return []

    best_path  = None
    best_score = 0
    for ev in seast_evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']

    if not best_path or best_score < 2:
        return []

    return _seast_event_streams(best_path)


