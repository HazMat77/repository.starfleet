"""
Starfleet Home GUI launcher.
Reads pre-fetched home data from home_data.json (written by dispatcher.py
while it still had full addon context), then opens the WindowXML.
"""
import sys
import os
import json
import xbmc
import xbmcvfs
import xbmcaddon

def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)

    # Read pre-fetched data
    empty = [[], [], []]
    contexts = {'default': empty, 'movies': empty, 'tv': empty, 'sports': empty}
    try:
        data_dir  = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
        data_file = os.path.join(data_dir, 'home_data.json')
        with open(data_file, 'r', encoding='utf-8') as f:
            raw = json.load(f)
        # Support both old list format and new dict format
        if isinstance(raw, list):
            contexts['default'] = raw
            contexts['movies']  = raw
            contexts['tv']      = raw
        else:
            contexts = raw
        d = contexts.get('default', empty)
        xbmc.log('[Starfleet/Home] loaded %d/%d/%d films from home_data.json' % (
            len(d[0]), len(d[1]), len(d[2])), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/Home] could not read home_data.json: %s' % e, xbmc.LOGWARNING)

    try:
        from resources.lib.gui.home import HomeWindow
        win = HomeWindow('Starfleet-Home.xml', addon_path, 'Default', '1080i',
                         contexts=contexts)
        win.doModal()
        # After doModal returns, close any Videos window that may be open on top
        # so the user sees Kodi's home, not a stale plugin window
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        del win
    except Exception as e:
        xbmc.log('[Starfleet/Home] window error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

if __name__ == '__main__':
    main()
