# -*- coding: utf-8 -*-
"""
resources/lib/local_proxy.py — a tiny loopback-only HTTP relay built to
close the real, live-confirmed gap behind OK.ru replays failing to play:
Kodi's own inputstream.ffmpegdirect/cURL layer doesn't reliably send back
the exact header a signed OK.ru CDN URL needs (see sports_router.
_resolve_okru's own docstring for the live investigation) — instead of an
instant rejection, the connection just stalls for ~30s and then fails,
confirmed live on both Windows and Firestick alike, so it was never
device-specific the way it first looked.

v2.3.478 shipped this as a per-request server, started lazily inside
whatever short-lived `plugin://` invocation happened to be resolving a
stream — and immediately proved broken via a real kodi.log: this addon
declares <reuselanguageinvoker>false</reuselanguageinvoker>, so Kodi tears
down that entire Python process once the resolving call returns control,
killing the background thread serving the relay right as the player was
starting to stream from it. Same ~30s hang-then-fail as before, just one
layer further in.

Fixed properly here by moving the server into service.py (at the addon
root, registered via addon.xml's xbmc.python.service extension point), a
real Kodi background service (start="startup") that lives for the whole
Kodi session, independent of any single plugin:// call. Since the
resolving call and the service are separate OS processes, they can't
share Python objects directly — they agree on one FIXED port instead
(_PORT below). The resolving side does a fast loopback health-check before
building a relay URL and falls back to the pre-existing direct-URL
behavior if the service isn't up yet (e.g. right after this update, before
the next Kodi restart — services only start at Kodi startup, not
retroactively for an addon that just updated mid-session).

UPDATE 2026-09-05 — confirmed live via a real kodi.log this was built and
never actually finished: addon.xml never declared the xbmc.python.service
extension point at all (so this file's own run_service() never ran, ever
— no "[Starfleet/LocalProxy] service started" line has ever appeared in
any log), AND sports_router._resolve_okru() never called
build_relay_url() below, still handing Kodi's player the direct CDN URL
regardless. Both gaps are fixed alongside this update.

UPDATE 2026-09-05 (later same day) — with the relay actually running and
wired in, a fresh kodi.log (this file's own new per-request logging,
added the same update) showed something the direct-URL failures never
could: Kodi opened SIX separate connections to the relay for the exact
same target URL within about 2 seconds (the first couple with no Range
header at all, the rest with "Range: bytes=0-") — and every one of them
except the last got an upstream TCP reset from okcdn.ru after almost
exactly one 65536-byte chunk; the one connection that got further only
made it to ~8MB before the whole thing still gave up around 32s. That
shape — many near-simultaneous connections to the identical signed URL,
all but one cut short almost immediately — is consistent with okcdn.ru
enforcing (loosely) one live connection per signed URL and punishing the
others, and this relay was making that worse: each of Kodi's own
retry/probe connections got its own brand-new, fully independent upstream
fetch with zero coordination between them. Serializing same-target
requests through a per-URL lock (below) stops the relay from ever having
more than one connection open to okcdn.ru for a given URL at a time,
regardless of how many overlapping requests Kodi itself makes — closing
off that specific way of provoking the CDN's own connection limit,
whatever that limit's exact rule turns out to be.
"""
import threading
import xbmc

_PORT = 51621

# Per-target-URL locks so overlapping requests for the identical upstream
# URL (Kodi's own probe/retry connections landing on this relay at close
# to the same moment — see the docstring update above for why that
# happens and why it matters) are serialized into one upstream connection
# at a time instead of each opening its own independently. Plain dict of
# locks, never pruned — this addon only ever relays a small, short-lived
# number of distinct URLs per session (one active stream at a time in
# practice), so unbounded growth here isn't a real concern.
_target_locks = {}
_target_locks_guard = threading.Lock()


def _lock_for(target):
    with _target_locks_guard:
        lock = _target_locks.get(target)
        if lock is None:
            lock = threading.Lock()
            _target_locks[target] = lock
        return lock

_server = None
_lock = threading.Lock()


# ── HLS "unwrap" relay ───────────────────────────────────────────────────────
#
# Added 2026-10-02 after a real kodi.log of a Starfleet sports stream (MLB
# game, inputstream.adaptive): "Cannot detect container type from media url,
# fallback to TS" -> "Cannot get the stream sample reader" -> "Codec id 27
# require extradata" -> video stream disabled, audio only, then EOF. Cause:
# several live-sports CDNs serve every .ts segment disguised as a picture -
# 40-odd bytes of RIFF/WEBP (or similar) header, sometimes more, in front of
# the real MPEG-TS - and Kodi's demuxers need the segment to START on a
# transport-stream sync byte. Measured the same day: FlyEmbed and MethStreams
# streams return Content-Type image/webp segments whose first aligned TS sync
# byte sits 42 bytes in.
#
# /hls serves a rewritten copy of the real playlist (every segment/variant/key
# URI pointed back at this relay, with the headers the upstream needs carried
# along), /seg fetches a segment and drops everything before the first
# 0x47-aligned run, /raw passes keys and init segments through untouched. A
# stream whose segments are already plain TS never goes through it (see
# maybe_wrap_hls) - this is a repair path, not a default one.

_TS_PACKET = 188


def _find_ts_start(data):
    """Offset of the first byte that begins 5 consecutive 188-byte TS packets,
    -1 when the data isn't MPEG-TS at all (fMP4, encrypted, HTML error...)."""
    limit = min(4096, len(data) - 5 * _TS_PACKET)
    for off in range(max(limit, 0)):
        if data[off] == 0x47 and all(data[off + k * _TS_PACKET] == 0x47 for k in range(1, 5)):
            return off
    return -1


_TS_MARK_RAW = b'TIKTIKRAW'
_TS_MARK_GZ = b'TIKTIKTSGZ'
_TS_MARK_PIX = b'TIKTIKPX'


def _is_ts_at(data, off=0):
    return (len(data) > off + _TS_PACKET and data[off] == 0x47
            and data[off + _TS_PACKET] == 0x47)


def _webp_exif_ts(data):
    """WebP whose EXIF chunk carries the transport stream."""
    import struct
    if len(data) < 16 or data[:4] != b'RIFF' or data[8:12] != b'WEBP':
        return None
    off = 12
    while off + 8 <= len(data):
        tag = data[off:off + 4]
        size = struct.unpack_from('<I', data, off + 4)[0]
        off += 8
        if off + size > len(data):
            return None
        if tag == b'EXIF':
            chunk = data[off:off + size]
            return chunk if _is_ts_at(chunk) else None
        off += size + (size & 1)
    return None


def _png_chunks(data):
    import struct
    off = 8
    while off + 8 <= len(data):
        size = struct.unpack_from('>I', data, off)[0]
        if size > len(data) - off - 12:
            return
        yield data[off + 4:off + 8], data[off + 8:off + 8 + size], off + 12 + size
        off += 12 + size


def _png_trailer_ts(data):
    """Valid PNG with the transport stream appended after IEND."""
    for ctype, _body, end in _png_chunks(data):
        if ctype == b'IEND':
            return data[end:] if _is_ts_at(data, end) else None
    return None


def _png_pixel_ts(data):
    """PNG whose RGB pixel bytes hold  TIKTIKPX + u32 length + gzip(transport stream)."""
    import struct
    import zlib
    import gzip
    width = height = depth = ctype = interlace = 0
    idat = []
    for name, body, _end in _png_chunks(data):
        if name == b'IHDR':
            width, height, depth, ctype, _c, _f, interlace = struct.unpack('>IIBBBBB', body[:13])
        elif name == b'IDAT':
            idat.append(body)
        elif name == b'IEND':
            break
    if not width or not height or depth != 8 or interlace or ctype not in (2, 6):
        return None
    raw = zlib.decompress(b''.join(idat))
    bpp = 4 if ctype == 6 else 3
    stride = width * bpp
    prev = bytearray(stride)
    out = bytearray()
    src = 0
    for _ in range(height):
        if src + 1 + stride > len(raw):
            return None
        ft = raw[src]
        row = raw[src + 1:src + 1 + stride]
        src += 1 + stride
        if ft == 0:
            cur = bytearray(row)
        elif ft == 2:
            cur = bytearray((a + b) & 255 for a, b in zip(row, prev))
        elif ft in (1, 3, 4):
            cur = bytearray(stride)
            for i in range(stride):
                left = cur[i - bpp] if i >= bpp else 0
                if ft == 1:
                    v = row[i] + left
                elif ft == 3:
                    v = row[i] + ((left + prev[i]) >> 1)
                else:
                    ul = prev[i - bpp] if i >= bpp else 0
                    p = left + prev[i] - ul
                    pa, pb, pc = abs(p - left), abs(p - prev[i]), abs(p - ul)
                    v = row[i] + (left if pa <= pb and pa <= pc else (prev[i] if pb <= pc else ul))
                cur[i] = v & 255
        else:
            return None
        if ctype == 6:
            px = bytearray(cur)
            del px[3::4]
            out += px
        else:
            out += cur
        prev = cur
        if len(out) >= 8 and out[:8] != _TS_MARK_PIX:
            return None
    if len(out) < 12 or out[:8] != _TS_MARK_PIX:
        return None
    n = struct.unpack_from('>I', out, 8)[0]
    packed = bytes(out[12:12 + n])
    if n <= 0 or packed[:2] != b'\x1f\x8b':
        return None
    ts = gzip.decompress(packed)
    return ts if ts[:1] == b'G' else None


def _looks_disguised(head):
    """True when the first bytes of a segment say it is not plain TS."""
    return (head[:4] == b'RIFF' or head[:2] == b'\x89P' or b'TIKTIK' in head[:4096]
            or _find_ts_start(head) > 0)


def _unwrap_segment(data):
    """Return the transport stream hidden inside `data` (unchanged when it is plain)."""
    ts = _webp_exif_ts(data)
    if ts:
        return ts
    if data[:2] == b'\x89P':
        ts = _png_trailer_ts(data)
        if ts:
            return ts
        try:
            ts = _png_pixel_ts(data)
        except Exception:
            ts = None
        return ts or data
    off = data.find(_TS_MARK_RAW)
    while off >= 0:
        if data[off + len(_TS_MARK_RAW):off + len(_TS_MARK_RAW) + 1] == b'G':
            return data[off + len(_TS_MARK_RAW):]
        off = data.find(_TS_MARK_RAW, off + 1)
    off = data.find(_TS_MARK_GZ)
    if off >= 0:
        try:
            import gzip
            return gzip.decompress(data[off + len(_TS_MARK_GZ):])
        except Exception:
            pass
    off = _find_ts_start(data[:5200])
    return data[off:] if off > 0 else data


def _split_pipe_headers(url):
    """'https://x/y.m3u8|Referer=..&User-Agent=..' -> (url, {headers})."""
    from urllib.parse import unquote
    base, _, tail = url.partition('|')
    headers = {}
    for kv in tail.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            headers[k] = unquote(v)
    return base, headers


def _enc_headers(headers):
    import base64
    import json
    return base64.urlsafe_b64encode(json.dumps(headers or {}).encode('utf-8')).decode('ascii')


def _dec_headers(blob):
    import base64
    import json
    try:
        return json.loads(base64.urlsafe_b64decode((blob or '').encode('ascii') + b'=' * (-len(blob or '') % 4)))
    except Exception:
        return {}


_DEFAULT_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
               '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')


def _rewrite_playlist(text, base_url, headers):
    """Point every URI in an HLS playlist back at this relay."""
    import re
    from urllib.parse import urljoin, quote as _uq
    hb = _enc_headers(headers)

    def link(kind, target, suffix):
        return 'http://127.0.0.1:%d/%s/x%s?url=%s&h=%s' % (
            _PORT, kind, suffix, _uq(urljoin(base_url, target), safe=''), hb)

    out, prev_variant = [], False
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            out.append(line)
        elif stripped.startswith('#'):
            if stripped.startswith('#EXT-X-STREAM-INF'):
                prev_variant = True
            if 'URI="' in stripped:
                kind = 'hls' if stripped.startswith('#EXT-X-MEDIA') else 'raw'
                suffix = '.m3u8' if kind == 'hls' else '.bin'
                line = re.sub(r'URI="([^"]+)"', lambda m: 'URI="%s"' % link(kind, m.group(1), suffix), line)
            out.append(line)
        else:
            if prev_variant or '.m3u8' in stripped.split('?')[0].lower():
                out.append(link('hls', stripped, '.m3u8'))
            else:
                out.append(link('seg', stripped, '.ts'))
            prev_variant = False
    return '\n'.join(out) + '\n'


def _first_segment(playlist_text, base_url, headers, depth=0):
    """Resolve master -> media playlist -> absolute URL of its first segment."""
    import requests as _req
    from urllib.parse import urljoin
    lines = [l.strip() for l in playlist_text.splitlines() if l.strip() and not l.startswith('#')]
    if not lines:
        return None
    first = urljoin(base_url, lines[0])
    if 'EXT-X-STREAM-INF' in playlist_text and depth < 2:
        r = _req.get(first, headers=headers, timeout=8)
        return _first_segment(r.text, r.url, headers, depth + 1)
    return first


def maybe_wrap_hls(stream_url):
    """Return a relay URL for `stream_url` ('url|Header=..' form) when its media
    segments are disguised TS; otherwise return it unchanged. Never raises."""
    try:
        if '.m3u8' not in stream_url.lower() or not _service_reachable():
            return stream_url
        # Signed one-connection CDNs (the xameleon family behind DaddyLive, see
        # sports_sources._livetv902_resolve_dlstreams: "a signed/session-pinned CDN URL only
        # tolerates ONE real connection") would have that connection spent by this probe.
        # Those streams are known to play directly.
        if 'xameleon' in stream_url.lower():
            return stream_url
        import requests as _req
        base, headers = _split_pipe_headers(stream_url)
        headers.setdefault('User-Agent', _DEFAULT_UA)
        pl = _req.get(base, headers=headers, timeout=8)
        if '#EXTM3U' not in pl.text[:200]:
            return stream_url
        seg = _first_segment(pl.text, pl.url, headers)
        if not seg:
            return stream_url
        r = _req.get(seg, headers=headers, timeout=10, stream=True)
        try:
            head = b''
            for chunk in r.iter_content(2048):
                head += chunk
                if len(head) >= 5000:
                    break
        finally:
            r.close()
        if r.status_code != 200 or len(head) < 1000:
            return stream_url
        off = _find_ts_start(head)
        if not _looks_disguised(head):
            xbmc.log('[Starfleet/LocalProxy] segments already clean (ts offset %d) - direct' % off, xbmc.LOGINFO)
            return stream_url
        from urllib.parse import quote as _uq
        xbmc.log('[Starfleet/LocalProxy] segments disguised (ts offset %d, %s) - relaying' % (
            off, r.headers.get('Content-Type', '?')), xbmc.LOGINFO)
        return 'http://127.0.0.1:%d/hls/x.m3u8?url=%s&h=%s' % (_PORT, _uq(base, safe=''), _enc_headers(headers))
    except Exception as e:
        xbmc.log('[Starfleet/LocalProxy] maybe_wrap_hls skipped: %s' % e, xbmc.LOGINFO)
        return stream_url


def _serve_hls(handler, kind, target, headers):
    """GET handler for /hls, /seg, /raw."""
    import requests as _req
    last = None
    up = None
    for _attempt in range(3):
        try:
            up = _req.get(target, headers=headers, timeout=(5, 15))
            break
        except Exception as e:
            last = e
    if up is None:
        xbmc.log('[Starfleet/LocalProxy] %s upstream error: %s' % (kind, last), xbmc.LOGWARNING)
        handler.send_response(502)
        handler.end_headers()
        return
    if up.status_code >= 400:
        handler.send_response(up.status_code)
        handler.end_headers()
        return
    body = up.content
    ctype = 'application/octet-stream'
    if kind == 'hls':
        if not up.text.lstrip().startswith('#EXTM3U'):
            handler.send_response(502)
            handler.end_headers()
            return
        body = _rewrite_playlist(up.text, up.url, headers).encode('utf-8')
        ctype = 'application/vnd.apple.mpegurl'
    elif kind == 'seg':
        body = _unwrap_segment(body)
        ctype = 'video/mp2t'
    handler.send_response(200)
    handler.send_header('Content-Type', ctype)
    handler.send_header('Content-Length', str(len(body)))
    handler.end_headers()
    try:
        handler.wfile.write(body)
    except Exception:
        pass


def _serve_tsws(handler, path, q):
    """GET /tsws/master.m3u8 and /tsws/media.m3u8: playlists the site publishes over a websocket (see ws_playlist).
    Every request fetches the current playlist, so the player's normal live refresh keeps working."""
    from urllib.parse import quote as _uq
    from resources.lib import ws_playlist

    def arg(name):
        return q.get(name, [''])[0]

    hosts = [h for h in arg('hosts').split(',') if h]
    channel, origin = arg('c'), arg('o')
    wspath = arg('p') or '/websocket'
    body = None
    if path.endswith('/master.m3u8'):
        import base64
        import json
        try:
            inf = json.loads(base64.urlsafe_b64decode(arg('inf').encode('ascii') + b'=' * (-len(arg('inf')) % 4)))
        except Exception:
            inf = {}
        import re as _re
        lines = ['#EXTM3U', '#EXT-X-VERSION:3']
        for rend, line in sorted(inf.items(), key=lambda kv: -int((_re.search(r'BANDWIDTH=(\d+)', kv[1]) or [0, 0])[1])):
            lines.append(line)
            lines.append('http://127.0.0.1:%d/tsws/media.m3u8?c=%s&hosts=%s&o=%s&p=%s&r=%s' % (
                _PORT, _uq(channel, safe=''), _uq(','.join(hosts), safe=','), _uq(origin, safe=''), _uq(wspath, safe=''),
                _uq(rend, safe='')))
        body = '\n'.join(lines) + '\n'
    else:
        try:
            body = ws_playlist.media_playlist(hosts, channel, origin, arg('r'), wspath)
        except Exception as e:
            xbmc.log('[Starfleet/LocalProxy] tsws playlist error: %s' % e, xbmc.LOGWARNING)
            body = None
        if not body:
            handler.send_response(503)
            handler.end_headers()
            return
    data = body.encode('utf-8')
    handler.send_response(200)
    handler.send_header('Content-Type', 'application/vnd.apple.mpegurl')
    handler.send_header('Content-Length', str(len(data)))
    handler.send_header('Cache-Control', 'no-cache')
    handler.end_headers()
    try:
        handler.wfile.write(data)
    except Exception:
        pass


def build_tsws_url(channel, hosts, origin, inf, path='/websocket'):
    """Relay URL for a websocket-published live channel, or None when the relay service is not running.
    `inf` maps rendition name -> its '#EXT-X-STREAM-INF:...' line."""
    if not _service_reachable():
        return None
    import base64
    import json
    from urllib.parse import quote as _uq
    blob = base64.urlsafe_b64encode(json.dumps(inf).encode('utf-8')).decode('ascii')
    return 'http://127.0.0.1:%d/tsws/master.m3u8?c=%s&hosts=%s&o=%s&p=%s&inf=%s' % (
        _PORT, _uq(channel, safe=''), _uq(','.join(hosts), safe=','), _uq(origin, safe=''), _uq(path, safe=''), blob)


def _make_handler():
    import http.server
    import requests as _req

    class _Handler(http.server.BaseHTTPRequestHandler):
        # One response per connection — this only ever serves a whole
        # video or one Range chunk, so HTTP/1.1 keep-alive buys nothing on
        # loopback but does trip a noisy (harmless) ConnectionResetError in
        # socketserver's own next-request read whenever the player
        # disconnects mid-stream (pause/seek/stop) — confirmed live.
        protocol_version = 'HTTP/1.0'

        def log_message(self, fmt, *args):
            pass  # default logs every request to stderr — real errors already go through xbmc.log below

        def do_GET(self):
            from urllib.parse import urlparse, parse_qs, unquote
            parsed = urlparse(self.path)
            q = parse_qs(parsed.query)
            if parsed.path.startswith('/tsws/'):
                _serve_tsws(self, parsed.path, q)
                return
            for _kind in ('hls', 'seg', 'raw'):
                if parsed.path.startswith('/%s/' % _kind):
                    _t = q.get('url', [''])[0]
                    if not _t:
                        self.send_response(400)
                        self.end_headers()
                        return
                    _serve_hls(self, _kind, _t, _dec_headers(q.get('h', [''])[0]))
                    return
            target = unquote(q.get('url', [''])[0])
            ua = unquote(q.get('ua', [''])[0])
            if not target:
                self.send_response(400)
                self.end_headers()
                return

            headers = {}
            if ua:
                headers['User-Agent'] = ua
            rng = self.headers.get('Range')
            if rng:
                headers['Range'] = rng

            # Confirmed live 2026-09-05 this relay had NO visibility at all
            # into its own success path — only the upstream-connect
            # exception and the swallowed player-disconnect exception ever
            # logged anything, so a real kodi.log capture of an actual
            # failure (playback hanging ~32s then failing at the demuxer,
            # after the relay itself had already accepted the connection)
            # gave zero signal on whether the relay ever reached upstream,
            # what status it got, or how many bytes it actually served
            # before things went wrong. Logging the request in and the
            # outcome out closes that blind spot for next time.
            xbmc.log('[Starfleet/LocalProxy] GET %s (range=%s)' % (target, rng or '-'), xbmc.LOGINFO)

            # Serialize overlapping requests for the identical target URL —
            # see this module's own docstring (2026-09-05 update) for the
            # live evidence this matters: Kodi's own probe/retry behavior
            # opened up to 6 near-simultaneous connections to this relay
            # for the exact same URL, each spawning its own independent
            # upstream fetch with no coordination, and okcdn.ru cut all but
            # one of them short almost immediately. Only one thread at a
            # time gets to hold an upstream connection to a given target;
            # everyone else queues here first.
            lock = _lock_for(target)
            with lock:
                try:
                    upstream = _req.get(target, headers=headers, stream=True, timeout=20)
                except Exception as e:
                    xbmc.log('[Starfleet/LocalProxy] upstream connect error: %s' % e, xbmc.LOGWARNING)
                    self.send_response(502)
                    self.end_headers()
                    return

                xbmc.log('[Starfleet/LocalProxy] upstream status=%s content-type=%s content-length=%s '
                          'accept-ranges=%s content-range=%s'
                          % (upstream.status_code, upstream.headers.get('Content-Type'),
                             upstream.headers.get('Content-Length'), upstream.headers.get('Accept-Ranges'),
                             upstream.headers.get('Content-Range')), xbmc.LOGINFO)
                sent = 0
                try:
                    self.send_response(upstream.status_code)
                    for h in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges'):
                        v = upstream.headers.get(h)
                        if v:
                            self.send_header(h, v)
                    self.end_headers()
                    it = upstream.iter_content(chunk_size=65536)
                    while True:
                        # Split so the log can tell WHICH side actually
                        # dropped the connection — upstream (okcdn.ru
                        # itself resetting the fetch) vs downstream (Kodi
                        # closing its connection to this relay, e.g. a
                        # real seek/stop/exit) look identical as a bare
                        # exception otherwise, and that distinction is
                        # exactly what's still unresolved after the first
                        # round of logging added here.
                        try:
                            chunk = next(it)
                        except StopIteration:
                            break
                        except Exception as e:
                            xbmc.log('[Starfleet/LocalProxy] UPSTREAM dropped connection after %d bytes: %s'
                                      % (sent, e), xbmc.LOGWARNING)
                            return
                        if chunk:
                            try:
                                self.wfile.write(chunk)
                            except Exception as e:
                                xbmc.log('[Starfleet/LocalProxy] downstream (player) closed connection '
                                          'after %d bytes: %s' % (sent, e), xbmc.LOGINFO)
                                return
                            sent += len(chunk)
                    xbmc.log('[Starfleet/LocalProxy] relay complete, %d bytes served' % sent, xbmc.LOGINFO)
                finally:
                    upstream.close()

    return _Handler


def run_service(monitor):
    """Called once from resources/service.py's main thread at Kodi startup.
    Binds _PORT and serves until Kodi asks the service to stop. If the
    port's already taken (another instance already bound it — services
    only start once per Kodi session, but a same-machine multi-instance or
    unclean-restart edge case could still leave one behind), that's
    treated as "already being served, nothing more to do" rather than a
    fatal error."""
    import http.server
    global _server

    try:
        handler = _make_handler()
        _server = http.server.ThreadingHTTPServer(('127.0.0.1', _PORT), handler)
    except OSError as e:
        xbmc.log('[Starfleet/LocalProxy] port %d unavailable (%s) — assuming '
                  'another instance is already serving it' % (_PORT, e), xbmc.LOGINFO)
        _server = None
    else:
        t = threading.Thread(target=_server.serve_forever, daemon=True)
        t.start()
        xbmc.log('[Starfleet/LocalProxy] service started on 127.0.0.1:%d' % _PORT, xbmc.LOGINFO)

    while not monitor.abortRequested():
        if monitor.waitForAbort(5):
            break

    if _server is not None:
        _server.shutdown()
        xbmc.log('[Starfleet/LocalProxy] service stopped', xbmc.LOGINFO)


def _service_reachable():
    import socket
    try:
        with socket.create_connection(('127.0.0.1', _PORT), timeout=0.4):
            return True
    except OSError:
        return False


def build_relay_url(target_url, user_agent=''):
    """Returns a http://127.0.0.1:<_PORT>/relay?url=...&ua=... URL — see
    module docstring for why this is the real fix and not a workaround.
    Raises RuntimeError if the background service isn't reachable (not
    started yet, e.g. right after this update before a Kodi restart), so
    callers can fall back to their pre-existing direct-URL behavior."""
    if not _service_reachable():
        raise RuntimeError('local proxy service not reachable on port %d '
                            '(Kodi may need a restart after this update)' % _PORT)
    from urllib.parse import quote as _uq
    url = 'http://127.0.0.1:%d/relay?url=%s' % (_PORT, _uq(target_url, safe=''))
    if user_agent:
        url += '&ua=%s' % _uq(user_agent, safe='')
    return url
