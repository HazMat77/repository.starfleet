# -*- coding: utf-8 -*-
"""
resources/lib/sports_sources.py

Sports live-stream scraper.

Event sources (priority order):
  1. ESPN API          — NFL, NBA, MLB, NHL, CFB, NCAAB, CFL (official logos + scores)
  2. TheSportsDB       — UFC, Boxing, WWE (free tier, API key 3)
  3. istreameast.cx    — fallback / soccer / F1 / anything else
  4. streamseast.cx    — supplementary (merged, deduplicated)
  5. crackstreams.mx   — supplementary (merged, deduplicated)
  6. mlb24all.ir       — MLB-specific supplementary
  7. nhl24all.ir       — NHL-specific supplementary
  8. nfl24all.ir       — NFL-specific supplementary
  9. nba24all.ir       — NBA-specific supplementary
 10. totalsportek24.is — multi-sport (soccer/NFL/NBA/NHL/MLB/UFC/boxing/F1/CFB/NCAAB/WWE)

Stream sources (merged):
  1. istreameast.cx    — /links/{slug} stream table when live
  2. roxiestreams.info — sport-page links matched by event title
  3. streamseast.cx    — supplementary stream source
  4. crackstreams.mx   — supplementary stream source
  5. v2.sportsurge.net — Cloudflare-protected, via cfscrape
  6. mlb24all.ir       — MLB-specific stream source
  7. nhl24all.ir       — NHL-specific stream source
  8. nfl24all.ir       — NFL-specific stream source
  9. nba24all.ir       — NBA-specific stream source
 10. totalsportek24.is — multi-sport stream source

Cache: event list 10 min (live data), stream list 5 min
"""

import re
import datetime
import time
import xbmc
import xbmcaddon
import xbmcvfs
from concurrent.futures import ThreadPoolExecutor, as_completed

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

ISE_BASE        = 'https://istreameast.cx'
CRACK_BASE      = 'https://crackstreams.mx'
ROXIE_BASE      = 'https://roxiestreams.info'
SEAST_BASE      = 'https://streamseast.cx'
TSTEK_BASE      = 'https://totalsportek24.is'
SPORTSURGE_BASE = 'https://v2.sportsurge.net'

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5, redirect=False)
        )
        _session.mount('https://', a)
    return _session


_cf_session = None

def _cf_sess():
    global _cf_session
    if _cf_session is None:
        try:
            import sys as _sys
            _sys.path.insert(0, r'C:\Users\danlo\AppData\Roaming\Kodi\addons\script.module.thecrew\lib\resources\lib\modules')
            import cfscrape
            _cf_session = cfscrape.create_scraper()
            _cf_session.headers.update(_HEADERS)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] cfscrape unavailable: %s' % e, xbmc.LOGWARNING)
            _cf_session = _sess()
    return _cf_session


def _get(url, timeout=12):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _get_json(url, timeout=10):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()


def _ts_to_dt(date_str):
    """Parse ISO date string to (unix_timestamp, display_string). Returns (0, '') on failure."""
    try:
        dt = datetime.datetime.strptime(date_str[:19], '%Y-%m-%dT%H:%M')
        ts = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
        return ts, dt.strftime('%b %d %H:%M')
    except Exception:
        return 0, date_str


def _title_score(title_a, title_b):
    """Return number of significant words (len>3) from title_a that appear in title_b (case-insensitive)."""
    words_a = [w.lower() for w in re.split(r'\W+', title_a) if len(w) > 3]
    b_lower = title_b.lower()
    return sum(1 for w in words_a if w in b_lower)


def _titles_match(title_a, title_b, threshold=2):
    """Return True if at least `threshold` significant words from title_a appear in title_b."""
    return _title_score(title_a, title_b) >= threshold


# ── Sport categories ──────────────────────────────────────────────────────────

_CATEGORIES = [
    {'slug': 'nfl',    'label': 'NFL',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nfl.png'},
    {'slug': 'nba',    'label': 'NBA',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nba.png'},
    {'slug': 'mlb',    'label': 'MLB',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/mlb.png'},
    {'slug': 'nhl',    'label': 'NHL',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/nhl.png'},
    {'slug': 'ufc',    'label': 'UFC / MMA',              'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ufc.png'},
    {'slug': 'boxing', 'label': 'Boxing',                 'icon': 'https://iili.io/3aqk6js.webp'},
    {'slug': 'soccer', 'label': 'Soccer',                 'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/fifa.png'},
    {'slug': 'f1',     'label': 'Formula 1',              'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/f1.png'},
    {'slug': 'cfb',    'label': 'College Football (CFB)', 'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaaf.png'},
    {'slug': 'ncaab',  'label': 'College Basketball (NCAAB)', 'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/ncaab.png'},
    {'slug': 'cfl',    'label': 'CFL',                    'icon': 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/leagues/500/cfl.png'},
    {'slug': 'wwe',    'label': 'WWE / Wrestling',        'icon': 'https://r2.thesportsdb.com/images/media/league/badge/r43xns1461424282.png/tiny'},
]

def get_sport_categories():
    return _CATEGORIES


# ── ESPN API ──────────────────────────────────────────────────────────────────

_ESPN_SPORTS = {
    'nfl':   ('football',   'nfl'),
    'nba':   ('basketball', 'nba'),
    'mlb':   ('baseball',   'mlb'),
    'nhl':   ('hockey',     'nhl'),
    'cfb':   ('football',   'college-football'),
    'ncaab': ('basketball', 'mens-college-basketball'),
    'cfl':   ('football',   'cfl'),
}
_ESPN_API = 'https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard'


def _espn_events(sport_slug):
    if sport_slug not in _ESPN_SPORTS:
        return []
    sport, league = _ESPN_SPORTS[sport_slug]
    url = _ESPN_API.format(sport=sport, league=league)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ESPN API (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in data.get('events', []):
        state   = ev.get('status', {}).get('type', {}).get('state', 'pre')
        is_live = (state == 'in')

        comp        = (ev.get('competitions') or [{}])[0]
        competitors = comp.get('competitors', [])
        venue       = comp.get('venue', {}).get('fullName', '')

        if len(competitors) >= 2:
            teams  = [c.get('team', {}).get('displayName', '') for c in competitors]
            scores = [c.get('score', '') for c in competitors]
            title_str = ' vs '.join(teams)
            if is_live and all(scores):
                title_str = '%s %s - %s %s' % (teams[0], scores[0], scores[1], teams[1])
        else:
            title_str = ev.get('name', ev.get('shortName', ''))

        logo = ''
        if competitors:
            logo = competitors[0].get('team', {}).get('logo', '')

        start_ts, datetime_str = _ts_to_dt(ev.get('date', ''))

        events.append({
            'id':       ev.get('id', ''),
            'slug':     ev.get('id', ''),
            'path':     '',
            'title':    title_str,
            'datetime': datetime_str,
            'league':   sport_slug.upper(),
            'logo':     logo,
            'is_live':  is_live,
            'start_ts': start_ts,
            'venue':    venue,
        })

    return events


# ── TheSportsDB (UFC / Boxing / WWE) ─────────────────────────────────────────

_TSDB_LEAGUES = {
    'ufc':    '4407',
    'boxing': '4414',
    'wwe':    '4412',
}
_TSDB_NEXT = 'https://www.thesportsdb.com/api/v1/json/3/eventsnextleague.php'


def _tsdb_events(sport_slug):
    league_id = _TSDB_LEAGUES.get(sport_slug)
    if not league_id:
        return []
    url = '%s?id=%s' % (_TSDB_NEXT, league_id)
    try:
        data = _get_json(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TSDB (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    for ev in (data.get('events') or []):
        date_str = ev.get('dateEvent', '')
        time_str = (ev.get('strTime') or '00:00:00')[:8]
        try:
            dt = datetime.datetime.strptime('%s %s' % (date_str, time_str), '%Y-%m-%d %H:%M:%S')
            start_ts  = int((dt - datetime.datetime(1970, 1, 1)).total_seconds())
            datetime_str = dt.strftime('%b %d %H:%M')
        except Exception:
            start_ts, datetime_str = 0, date_str

        title_str = ev.get('strEvent', ev.get('strFilename', ''))
        logo = ev.get('strThumb', '') or ev.get('strBanner', '') or ''

        events.append({
            'id':       str(ev.get('idEvent', '')),
            'slug':     str(ev.get('idEvent', '')),
            'path':     '',
            'title':    title_str,
            'datetime': datetime_str,
            'league':   ev.get('strLeague', sport_slug.upper()),
            'logo':     logo,
            'is_live':  False,
            'start_ts': start_ts,
        })

    return events


# ── istreameast.cx events (fallback) ─────────────────────────────────────────

_RE_ISE_CARD = re.compile(
    r'class="event-card"[^>]*onclick="window\.location\.href=[^\']*\'(/links/([^\']+))\''
    r'[^>]*data-event-id="(\d+)"[^>]*data-start-ts="(\d+)"',
    re.IGNORECASE | re.DOTALL
)
_RE_ISE_LOGO = re.compile(
    r'<img[^>]+src="(https://[^"]+thesportsdb[^"]+|https://[^"]+espncdn[^"]+)"[^>]*alt="([^"]*)"',
    re.IGNORECASE
)
_RE_ISE_TITLE    = re.compile(r'class="event-title"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_DATETIME = re.compile(r'class="event-datetime"\s*>([^<]+)<', re.IGNORECASE)
_RE_ISE_LEAGUE   = re.compile(r'class="event-league"\s*>(.*?)</div>', re.IGNORECASE | re.DOTALL)
_RE_ISE_STATUS   = re.compile(r'class="event-status\s+([^"]+)"\s*>(.*?)</span>', re.IGNORECASE)


def _parse_ise_block(block):
    m_title = _RE_ISE_TITLE.search(block)
    m_dt    = _RE_ISE_DATETIME.search(block)
    m_lg    = _RE_ISE_LEAGUE.search(block)
    m_st    = _RE_ISE_STATUS.search(block)
    m_logo  = _RE_ISE_LOGO.search(block)

    title    = _clean(m_title.group(1)) if m_title else ''
    dt_str   = _clean(m_dt.group(1))   if m_dt    else ''
    league   = _clean(_RE_STRIP.sub(' ', m_lg.group(1))) if m_lg else ''
    league   = re.sub(r'\s+\d+\s+(?:hours?|minutes?)\s+from\s+now.*', '', league, flags=re.IGNORECASE).strip()
    status_class = m_st.group(1).strip() if m_st else 'upcoming'
    is_live  = 'live' in status_class.lower()
    logo_url = m_logo.group(1) if m_logo else ''
    return title, dt_str, league, logo_url, is_live


def _ise_events(sport_slug):
    url = ISE_BASE + '/schedule/%s' % sport_slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE schedule error (%s): %s' % (sport_slug, e), xbmc.LOGERROR)
        try:
            html = _get(ISE_BASE + '/')
        except Exception:
            return []

    events = []
    seen   = set()

    for m in _RE_ISE_CARD.finditer(html):
        path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
        if event_id in seen:
            continue
        seen.add(event_id)
        block = html[m.end():m.end() + 900]
        title, dt_str, league, logo_url, is_live = _parse_ise_block(block)

        if sport_slug != 'nfl' and league and sport_slug.lower() not in league.lower():
            continue

        events.append({
            'id':       event_id,
            'slug':     slug,
            'path':     path,
            'title':    title or slug.replace('-', ' ').title(),
            'datetime': dt_str,
            'league':   league,
            'logo':     logo_url,
            'is_live':  is_live,
            'start_ts': int(start_ts_str),
        })

    return events


# ── streamseast.cx events (supplementary) ────────────────────────────────────

_SEAST_SLUGS = {
    'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'nhl': 'nhl',
    'ufc': 'fighting', 'boxing': 'fighting', 'soccer': 'football',
    'f1': 'f1', 'cfb': 'ncaaf', 'ncaab': 'ncaab', 'cfl': 'cfl', 'wwe': 'wwe',
}

# streamseast.cx uses similar HTML structure to istreameast.cx
_RE_SEAST_CARD = re.compile(
    r'class="event-card"[^>]*onclick="window\.location\.href=[^\']*\'(/links/([^\']+))\''
    r'[^>]*data-event-id="(\d+)"[^>]*data-start-ts="(\d+)"',
    re.IGNORECASE | re.DOTALL
)


def _seast_events(sport_slug):
    slug = _SEAST_SLUGS.get(sport_slug)
    if not slug:
        return []
    url = SEAST_BASE + '/schedule/%s' % slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast schedule error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()

    for m in _RE_SEAST_CARD.finditer(html):
        path, ev_slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
        if event_id in seen:
            continue
        seen.add(event_id)
        block = html[m.end():m.end() + 900]
        title, dt_str, league, logo_url, is_live = _parse_ise_block(block)

        events.append({
            'id':       'seast_' + event_id,
            'slug':     ev_slug,
            'path':     'streamseast:' + path,  # prefix so stream fetcher knows source
            'title':    title or ev_slug.replace('-', ' ').title(),
            'datetime': dt_str,
            'league':   league,
            'logo':     logo_url,
            'is_live':  is_live,
            'start_ts': int(start_ts_str),
        })

    return events


def _seast_event_streams(event_path):
    """event_path may be 'streamseast:/links/...' or just '/links/...'"""
    path = event_path.replace('streamseast:', '')
    url  = SEAST_BASE + path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=SEAST_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] StreamsEast stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, 'streamseast.cx', 'StreamsEast')
    xbmc.log('[Starfleet/Sports] StreamsEast streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# ── Public event API ──────────────────────────────────────────────────────────

def _merge_events(primary, supplementary):
    """Merge supplementary events into primary, deduplicating by title similarity."""
    merged = list(primary)
    primary_titles = [e['title'] for e in primary]

    for ev in supplementary:
        # Check if a similar event already exists
        duplicate = False
        for pt in primary_titles:
            if _titles_match(ev['title'], pt, threshold=2):
                duplicate = True
                break
        if not duplicate:
            merged.append(ev)
            primary_titles.append(ev['title'])

    return merged


def get_sport_events(sport_slug='nfl'):
    ck = 'sports_events_%s' % sport_slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    events = []

    if sport_slug in _ESPN_SPORTS:
        events = _espn_events(sport_slug)

    if not events and sport_slug in _TSDB_LEAGUES:
        events = _tsdb_events(sport_slug)

    if not events:
        events = _ise_events(sport_slug)

    # Run supplementary sources in parallel
    supplementary_futures = {}
    with ThreadPoolExecutor(max_workers=5) as ex:
        supplementary_futures['seast'] = ex.submit(_seast_events, sport_slug)
        if sport_slug in _TSTEK_SLUGS:
            supplementary_futures['tstek'] = ex.submit(_tstek_events, sport_slug)
        if sport_slug == 'mlb':
            supplementary_futures['mlb24'] = ex.submit(_mlb24_events)
        if sport_slug == 'nhl':
            supplementary_futures['nhl24'] = ex.submit(_nhl24_events)
        if sport_slug == 'nfl':
            supplementary_futures['nfl24'] = ex.submit(_nfl24_events)
        if sport_slug == 'nba':
            supplementary_futures['nba24'] = ex.submit(_nba24_events)

        for name, fut in supplementary_futures.items():
            try:
                extra = fut.result(timeout=12)
                if extra:
                    events = _merge_events(events, extra)
                    xbmc.log('[Starfleet/Sports] %s merged %d events from %s' % (sport_slug, len(extra), name), xbmc.LOGINFO)
            except Exception as e:
                xbmc.log('[Starfleet/Sports] supplementary events error (%s/%s): %s' % (sport_slug, name, e), xbmc.LOGWARNING)

    events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
    _cache.set(ck, events, 10 * 60)
    xbmc.log('[Starfleet/Sports] %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def get_all_events():
    ck = 'sports_events_all'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(ISE_BASE + '/')
        events = []
        seen   = set()

        for m in _RE_ISE_CARD.finditer(html):
            path, slug, event_id, start_ts_str = m.group(1), m.group(2), m.group(3), m.group(4)
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[m.end():m.end() + 900]
            title, dt_str, league, logo_url, is_live = _parse_ise_block(block)
            events.append({
                'id':       event_id,
                'slug':     slug,
                'path':     path,
                'title':    title or slug.replace('-', ' ').title(),
                'datetime': dt_str,
                'league':   league,
                'logo':     logo_url,
                'is_live':  is_live,
                'start_ts': int(start_ts_str),
            })

        events.sort(key=lambda x: (0 if x['is_live'] else 1, x['start_ts']))
        _cache.set(ck, events, 10 * 60)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] all events error: %s' % e, xbmc.LOGERROR)
        return []


# ── Stream links ──────────────────────────────────────────────────────────────

# Known streaming embed/player domains — used as fallback link detection
_STREAM_EMBED_DOMAINS = (
    '720pstream', 'livetv', 'streamtape', 'cloudy.pk', 'stopstream',
    'nbaat', 'vecloud', 'embedstream', 'nlstreams', 'theflixer',
    'sportshdlive', 'daddylive', 'sportsurge', 'buffstream', 'atdhe',
    'firstrowsports', 'livesport', 'sportsbay', 'streameast',
    'crackstreams', 'volokit', 'acestream',
)

# istreameast.cx stream table row — flexible: 3 or more TDs, last with <a href>
_RE_ISE_STREAM_ROW = re.compile(
    r'<tr[^>]*>\s*'
    r'<td[^>]*>(.*?)</td>\s*'          # col 1: streamer/name
    r'<td[^>]*>(.*?)</td>\s*'          # col 2: channel/quality
    r'(?:<td[^>]*>.*?</td>\s*)*'       # optional extra cols
    r'<td[^>]*><a[^>]+href="([^"#][^"]*)"[^>]*>',
    re.IGNORECASE | re.DOTALL
)

# Fallback: any external <a> with href on a stream page
_RE_EXT_LINK = re.compile(
    r'<a[^>]+href="(https?://([^/"]+)[^"]*)"[^>]*>([^<]{1,80})</a>',
    re.IGNORECASE
)
# Fallback: iframes with external src
_RE_IFRAME_SRC = re.compile(r'<iframe[^>]+src="(https?://[^"]+)"', re.IGNORECASE)


def _extract_stream_links(html, base_domain, source_label):
    """
    Try structured table parse first, then fall back to link/iframe extraction.
    Returns list of stream dicts.
    """
    streams = []

    # 1. Try structured table rows
    for m in _RE_ISE_STREAM_ROW.finditer(html):
        col1 = _clean(m.group(1))
        col2 = _clean(m.group(2))
        url  = m.group(3).strip()
        if not url or url == '#':
            continue
        label = ('%s %s' % (col1, col2)).strip() or source_label
        streams.append({
            'label':    label,
            'url':      url,
            'quality':  col2,
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 2. Fallback: iframes
    for m in _RE_IFRAME_SRC.finditer(html):
        src = m.group(1).strip()
        if base_domain and base_domain in src:
            continue
        streams.append({
            'label':    source_label + ' Embedded',
            'url':      src,
            'quality':  '',
            'language': '',
            'source':   source_label,
        })

    if streams:
        return streams

    # 3. Fallback: known stream embed domain links
    for m in _RE_EXT_LINK.finditer(html):
        href   = m.group(1).strip()
        domain = m.group(2).lower()
        text   = _clean(m.group(3))
        if base_domain and base_domain in domain:
            continue
        if any(d in domain for d in _STREAM_EMBED_DOMAINS):
            streams.append({
                'label':    text or (source_label + ' Stream'),
                'url':      href,
                'quality':  '',
                'language': '',
                'source':   source_label,
            })

    return streams


def _ise_event_streams(event_path, event_id=''):
    url = ISE_BASE + event_path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=ISE_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] ISE stream page error (%s): %s' % (event_path, e), xbmc.LOGERROR)
        return []

    streams = _extract_stream_links(html, 'istreameast.cx', 'StreamEast')
    xbmc.log('[Starfleet/Sports] ISE streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


# Roxiestreams
_ROXIE_SLUGS = {
    'nfl':    'nfl',
    'nba':    'nba',
    'mlb':    'mlb',
    'nhl':    'nhl',
    'ufc':    'fighting',
    'boxing': 'fighting',
    'soccer': 'soccer',
    'wwe':    'wwe',
    'cfb':    'ncaaf',
    'ncaab':  'ncaab',
    'f1':     'f1',
    'cfl':    'cfl',
}

_RE_ROXIE_ROW = re.compile(
    r'<a[^>]+href="(/[^"#\s]{3,80})"[^>]*>\s*([^<]{3,120}?)\s*</a>',
    re.IGNORECASE
)


def _roxie_streams(sport_slug, event_title=''):
    slug = _ROXIE_SLUGS.get(sport_slug)
    if not slug:
        return []
    url = ROXIE_BASE + '/' + slug
    try:
        html = _get(url)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Roxie (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    streams = []
    title_words = [w.lower() for w in re.split(r'\W+', event_title) if len(w) > 3] if event_title else []

    for m in _RE_ROXIE_ROW.finditer(html):
        link_path = m.group(1)
        row_text  = _clean(m.group(2))

        # Skip nav/generic links
        if not row_text or len(row_text) < 4:
            continue
        skip_words = ('home', 'menu', 'schedule', 'login', 'register', 'about', 'contact')
        if row_text.lower() in skip_words:
            continue

        # If we have an event title, require at least one keyword match
        if title_words:
            row_lower = row_text.lower()
            if not any(w in row_lower for w in title_words):
                continue

        full_url = ROXIE_BASE + link_path if not link_path.startswith('http') else link_path
        streams.append({
            'label':    row_text,
            'url':      full_url,
            'quality':  '',
            'language': '',
            'source':   'RoxieStreams',
        })
        if len(streams) >= 8:
            break

    xbmc.log('[Starfleet/Sports] Roxie %s "%s": %d streams' % (sport_slug, event_title, len(streams)), xbmc.LOGINFO)
    return streams


# ── Crackstreams (supplementary) ─────────────────────────────────────────────

_CRACK_SLUGS = {
    'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'nhl': 'nhl',
    'ufc': 'mma', 'boxing': 'boxing', 'soccer': 'soccer', 'f1': 'f1', 'wwe': 'wwe',
}

# Primary card pattern: /watch-live/{sport}/{team1}/{team2}/{id}
_RE_CRACK_CARD = re.compile(
    r'<a[^>]+href="(/watch-live/([^/\"]+)/([^/\"]+)/([^/\"]+)/(\d+))"[^>]*>'
    r'(?:(?!</a>).)*?'
    r'<div[^>]*class="[^"]*event-title[^"]*"[^>]*>([^<]+)<',
    re.IGNORECASE | re.DOTALL
)
# Fallback card pattern: any internal /watch-* or /nfl|nba|mlb|nhl|mma|boxing/* link with title text
_RE_CRACK_CARD2 = re.compile(
    r'<a[^>]+href="(/(?:watch|nfl|nba|mlb|nhl|mma|boxing|soccer|f1|wwe|fighting)/[^"#\s]{3,80})"[^>]*>'
    r'([^<]{5,120})'
    r'(?:</a>|<)',
    re.IGNORECASE
)
_RE_CRACK_IMG = re.compile(
    r'<img[^>]+src="(https://[^"]+(?:espncdn|thesportsdb)[^"]+)"[^>]+alt="([^"]*)"',
    re.IGNORECASE
)
# Watch links on event page: "Watch", "Stream", "Link N", "HD" etc.
_RE_CRACK_WATCH_LINK = re.compile(
    r'<a[^>]+href="(https?://[^"]+)"[^>]*>[^<]*(?:[Ww]atch|[Ss]tream|[Ll]ink\s*\d|HD|Live)[^<]*</a>',
    re.IGNORECASE
)


def get_crack_events():
    ck = 'sports_crack_events'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _sess().get(CRACK_BASE + '/', timeout=12, headers=dict(_HEADERS, Referer='https://www.google.com/')).text
        events = []
        seen   = set()

        # Primary pattern: structured /watch-live/{sport}/{team1}/{team2}/{id}
        for m in _RE_CRACK_CARD.finditer(html):
            path, sport = m.group(1), m.group(2)
            event_id    = m.group(5)
            title       = _clean(m.group(6))
            if event_id in seen:
                continue
            seen.add(event_id)
            block = html[max(0, m.start() - 400):m.start()]
            im    = _RE_CRACK_IMG.search(block)
            logo  = im.group(1) if im else ''
            events.append({
                'id':    event_id,
                'title': title,
                'sport': sport,
                'path':  path,
                'logo':  logo,
            })

        # Fallback pattern: simpler /sport/... links
        if not events:
            xbmc.log('[Starfleet/Sports] CrackStreams primary regex matched nothing, trying fallback', xbmc.LOGINFO)
            for m in _RE_CRACK_CARD2.finditer(html):
                path  = m.group(1)
                title = _clean(m.group(2))
                if not title or len(title) < 4:
                    continue
                skip = ('home', 'schedule', 'about', 'contact', 'nfl', 'nba', 'mlb', 'nhl', 'login')
                if title.lower().strip() in skip:
                    continue
                uid = re.sub(r'\W+', '_', path)
                if uid in seen:
                    continue
                seen.add(uid)
                # Determine sport from path
                sport_part = path.strip('/').split('/')[0].lower()
                events.append({
                    'id':    uid,
                    'title': title,
                    'sport': sport_part,
                    'path':  path,
                    'logo':  '',
                })

        _cache.set(ck, events, 10 * 60)
        xbmc.log('[Starfleet/Sports] CrackStreams events found: %d' % len(events), xbmc.LOGINFO)
        return events
    except Exception as e:
        xbmc.log('[Starfleet/Sports] crackstreams events error: %s' % e, xbmc.LOGWARNING)
        return []


def _crack_event_streams(sport_slug, event_title):
    """Find matching crackstreams event and scrape its stream watch links."""
    slug = _CRACK_SLUGS.get(sport_slug)
    if not slug:
        return []

    try:
        crack_events = get_crack_events()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] crackstreams get_events error: %s' % e, xbmc.LOGWARNING)
        return []

    # Find best matching event
    best_path  = None
    best_score = 0
    for ev in crack_events:
        # Filter by sport slug if possible
        ev_sport = ev.get('sport', '')
        if slug and ev_sport and ev_sport.lower() != slug.lower():
            continue
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']

    if not best_path or best_score < 2:
        xbmc.log('[Starfleet/Sports] crackstreams no match for "%s" (best=%d)' % (event_title, best_score), xbmc.LOGINFO)
        return []

    url = CRACK_BASE + best_path if best_path.startswith('/') else best_path
    try:
        html = _sess().get(url, timeout=12, headers=dict(_HEADERS, Referer=CRACK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] crackstreams event page error (%s): %s' % (best_path, e), xbmc.LOGWARNING)
        return []

    # Try specific "Watch/Stream/Link" anchors first
    streams = []
    for m in _RE_CRACK_WATCH_LINK.finditer(html):
        watch_url = m.group(1).strip()
        if not watch_url or watch_url == '#':
            continue
        streams.append({
            'label':    'CrackStreams ' + _clean(m.group(0).split('>')[1].split('<')[0]) or 'Stream',
            'url':      watch_url,
            'quality':  '',
            'language': '',
            'source':   'CrackStreams',
        })

    # Fallback to general link/iframe extraction
    if not streams:
        streams = _extract_stream_links(html, 'crackstreams', 'CrackStreams')

    xbmc.log('[Starfleet/Sports] CrackStreams "%s": %d streams' % (event_title, len(streams)), xbmc.LOGINFO)
    return streams


# ── Sportsurge (supplementary, Cloudflare-protected) ─────────────────────────

_SPORTSURGE_SLUGS = {
    'nfl': 'nfl', 'nba': 'nba', 'mlb': 'mlb', 'nhl': 'nhl',
    'ufc': 'mma', 'boxing': 'boxing', 'soccer': 'soccer', 'f1': 'motorsports',
}

_RE_SPORTSURGE_LINK = re.compile(
    r'<a[^>]+href="(https?://[^"]+)"[^>]*>\s*([^<]+)\s*</a>',
    re.IGNORECASE
)


_RE_NEXT_DATA = re.compile(r'<script[^>]+id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.IGNORECASE | re.DOTALL)


def _sportsurge_streams(sport_slug, event_title=''):
    if sport_slug not in _SPORTSURGE_SLUGS:
        return []

    surge_slug = _SPORTSURGE_SLUGS[sport_slug]
    title_words = [w.lower() for w in re.split(r'\W+', event_title) if len(w) > 3] if event_title else []
    streams = []

    # Strategy 1: Try the REST API endpoints that Next.js sites commonly expose
    api_urls = [
        '%s/api/streams?sport=%s' % (SPORTSURGE_BASE, surge_slug),
        '%s/api/events?sport=%s' % (SPORTSURGE_BASE, surge_slug),
        '%s/api/%s' % (SPORTSURGE_BASE, surge_slug),
    ]
    for api_url in api_urls:
        try:
            r = _cf_sess().get(api_url, timeout=10, headers=dict(_HEADERS, Accept='application/json'))
            if r.status_code == 200 and 'json' in r.headers.get('content-type', ''):
                data = r.json()
                # Flatten any list structures and look for stream URLs
                items = data if isinstance(data, list) else data.get('streams', data.get('events', data.get('data', [])))
                for item in (items if isinstance(items, list) else []):
                    item_title = item.get('title', item.get('name', item.get('event', '')))
                    item_url   = item.get('url', item.get('stream', item.get('link', '')))
                    if not item_url:
                        continue
                    if title_words and not any(w in item_title.lower() for w in title_words):
                        continue
                    streams.append({
                        'label':    item_title or 'Sportsurge Stream',
                        'url':      item_url,
                        'quality':  item.get('quality', ''),
                        'language': '',
                        'source':   'Sportsurge',
                    })
                if streams:
                    xbmc.log('[Starfleet/Sports] Sportsurge API "%s": %d streams' % (event_title, len(streams)), xbmc.LOGINFO)
                    return streams
        except Exception:
            pass

    # Strategy 2: Fetch the page and parse __NEXT_DATA__ JSON (Next.js hydration data)
    try:
        r = _cf_sess().get(SPORTSURGE_BASE + '/' + surge_slug, timeout=15,
                           headers=dict(_HEADERS, Referer='https://www.google.com/'))
        r.raise_for_status()
        html = r.text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] Sportsurge page fetch error: %s' % e, xbmc.LOGWARNING)
        return []

    m_nd = _RE_NEXT_DATA.search(html)
    if m_nd:
        try:
            import json as _json
            nd = _json.loads(m_nd.group(1))
            # Walk the props tree looking for stream/event data
            def _walk(obj, depth=0):
                if depth > 8:
                    return
                if isinstance(obj, dict):
                    url = obj.get('url', obj.get('stream', obj.get('link', '')))
                    title = obj.get('title', obj.get('name', obj.get('event', '')))
                    if url and url.startswith('http'):
                        if not title_words or any(w in str(title).lower() for w in title_words):
                            streams.append({
                                'label':    str(title) or 'Sportsurge Stream',
                                'url':      url,
                                'quality':  str(obj.get('quality', '')),
                                'language': '',
                                'source':   'Sportsurge',
                            })
                    for v in obj.values():
                        _walk(v, depth + 1)
                elif isinstance(obj, list):
                    for v in obj:
                        _walk(v, depth + 1)
            _walk(nd)
        except Exception as e:
            xbmc.log('[Starfleet/Sports] Sportsurge __NEXT_DATA__ parse error: %s' % e, xbmc.LOGWARNING)

    if streams:
        xbmc.log('[Starfleet/Sports] Sportsurge NEXT_DATA "%s": %d streams' % (event_title, len(streams)), xbmc.LOGINFO)
        return streams[:10]

    # Strategy 3: Fall back to plain link extraction from HTML
    for m in _RE_SPORTSURGE_LINK.finditer(html):
        link_url  = m.group(1).strip()
        link_text = _clean(m.group(2))
        if not link_text or len(link_text) < 3:
            continue
        if title_words:
            if not any(w in link_text.lower() for w in title_words):
                continue
        streams.append({
            'label':    link_text,
            'url':      link_url,
            'quality':  '',
            'language': '',
            'source':   'Sportsurge',
        })
        if len(streams) >= 10:
            break

    xbmc.log('[Starfleet/Sports] Sportsurge HTML "%s": %d streams' % (event_title, len(streams)), xbmc.LOGINFO)
    return streams


# ── TotalSportek24 (multi-sport) ─────────────────────────────────────────────

# Maps our internal slugs to TotalSportek24 URL path segments
_TSTEK_SLUGS = {
    'soccer': 'football',
    'nfl':    'nfl',
    'nba':    'nba',
    'nhl':    'nhl',
    'mlb':    'mlb',
    'ufc':    'mma',
    'boxing': 'boxing',
    'f1':     'formula-1',
    'cfb':    'college-football',
    'ncaab':  'college-basketball',
    'wwe':    'wwe',
    'tennis': 'tennis',
    'rugby':  'rugby',
}

# Event card: an internal link whose path starts with a sport slug
_RE_TSTEK_EVENT = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^"#\s]{4,120})"[^>]*>'
    r'\s*([^<]{4,120}?)\s*</a>',
    re.IGNORECASE
)

# Nav links used to discover which sport sections actually exist on the site
_RE_TSTEK_NAV = re.compile(
    r'<a[^>]+href="(https?://totalsportek24\.is/[^/"]+/?)"[^>]*>'
    r'\s*([^<]{2,40}?)\s*</a>',
    re.IGNORECASE
)

# Cache the scraped nav/sport-section map across calls
_tstek_sport_urls = {}   # slug → full URL to that sport's schedule page


def _tstek_discover():
    """
    Fetch TotalSportek24 homepage and build a map of sport-slug → URL.
    Caches the result in _tstek_sport_urls for the session.
    """
    global _tstek_sport_urls
    if _tstek_sport_urls:
        return _tstek_sport_urls

    ck = 'tstek_sport_urls'
    cached = _cache.get(ck)
    if cached:
        _tstek_sport_urls = cached
        return _tstek_sport_urls

    try:
        html = _sess().get(TSTEK_BASE + '/', timeout=12,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 homepage error: %s' % e, xbmc.LOGWARNING)
        return {}

    # Build reverse map: url-path-segment → our slug
    reverse = {v: k for k, v in _TSTEK_SLUGS.items()}
    result  = {}

    for m in _RE_TSTEK_NAV.finditer(html):
        href    = m.group(1).rstrip('/')
        segment = href.rstrip('/').rsplit('/', 1)[-1].lower()
        if segment in reverse:
            our_slug = reverse[segment]
            result[our_slug] = href
            xbmc.log('[Starfleet/Sports] TotalSportek24 found sport: %s → %s' % (our_slug, href), xbmc.LOGINFO)

    # Fallback: construct URLs from the known slug map for any missing sports
    for our_slug, tstek_slug in _TSTEK_SLUGS.items():
        if our_slug not in result:
            result[our_slug] = '%s/%s/' % (TSTEK_BASE, tstek_slug)

    _tstek_sport_urls = result
    _cache.set(ck, result, 60 * 60)  # cache 1 hour
    return result


def _tstek_events(sport_slug):
    """Scrape TotalSportek24 for events matching the given sport slug."""
    sport_urls = _tstek_discover()
    sport_url  = sport_urls.get(sport_slug)
    if not sport_url:
        return []

    try:
        html = _sess().get(sport_url, timeout=12,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 sport page error (%s): %s' % (sport_slug, e), xbmc.LOGWARNING)
        return []

    tstek_seg = _TSTEK_SLUGS.get(sport_slug, sport_slug)
    events    = []
    seen      = set()
    now_ts    = int(time.time())
    skip_words = ('schedule', 'fixtures', 'results', 'standings', 'news', 'about',
                  'contact', 'privacy', 'home', 'live', 'stream', 'watch',  # generic nav
                  tstek_seg)

    for m in _RE_TSTEK_EVENT.finditer(html):
        href  = m.group(1).strip()
        title = _clean(m.group(2))

        if not title or len(title) < 5 or href in seen:
            continue
        # Must be an event under this sport's path segment (filters out sidebar
        # links to other sports, teams, leagues e.g. /team/liverpool/)
        path_parts = href.replace(TSTEK_BASE, '').strip('/').split('/')
        if len(path_parts) < 2:
            continue
        if path_parts[0].lower() != tstek_seg.lower():
            continue
        if title.lower() in skip_words or any(s == title.lower() for s in skip_words):
            continue
        seen.add(href)

        events.append({
            'id':       'tstek_' + re.sub(r'\W+', '_', href),
            'slug':     href.replace(TSTEK_BASE, '').strip('/'),
            'path':     'tstek:' + href,
            'title':    title,
            'datetime': '',
            'league':   sport_slug.upper(),
            'logo':     '',
            'is_live':  False,
            'start_ts': now_ts,
        })

    xbmc.log('[Starfleet/Sports] TotalSportek24 %s: %d events' % (sport_slug, len(events)), xbmc.LOGINFO)
    return events


def _tstek_streams(event_path):
    """Scrape stream links from a TotalSportek24 event page."""
    url = event_path.replace('tstek:', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer=TSTEK_BASE + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] TotalSportek24 stream page error (%s): %s' % (event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, 'totalsportek24.is', 'TotalSportek')
    xbmc.log('[Starfleet/Sports] TotalSportek24 streams for %s: %d' % (event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _tstek_streams_by_title(sport_slug, event_title):
    """Cross-reference: find best TotalSportek24 event by title and scrape its streams."""
    evs = _tstek_events(sport_slug)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _tstek_streams(best_path)


# ── *24all.ir generic helpers ─────────────────────────────────────────────────

def _x24_events(domain, sport_label, path_prefix):
    """Generic scraper for *24all.ir sites (mlb24all.ir, nhl24all.ir, nfl24all.ir, nba24all.ir)."""
    base = 'https://' + domain
    pattern = re.compile(
        r'<a[^>]+href="(https?://' + re.escape(domain) + r'/[^"]+)"[^>]*>([^<]+)</a>',
        re.IGNORECASE
    )
    try:
        html = _sess().get(base + '/', timeout=12,
                           headers=dict(_HEADERS, Referer='https://www.google.com/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s fetch error: %s' % (domain, e), xbmc.LOGWARNING)
        return []

    events = []
    seen   = set()
    now_ts = int(time.time())
    skip_words = ('home', 'schedule', 'about', 'contact', 'privacy', domain.split('.')[0])

    for m in pattern.finditer(html):
        path  = m.group(1).strip()
        title = _clean(m.group(2))
        if not title or len(title) < 4 or path in seen:
            continue
        if any(s in title.lower() for s in skip_words):
            continue
        seen.add(path)
        events.append({
            'id':       path_prefix + re.sub(r'\W+', '_', path),
            'slug':     re.sub(r'https?://' + re.escape(domain) + r'/', '', path).strip('/'),
            'path':     path_prefix + ':' + path,
            'title':    title,
            'datetime': '',
            'league':   sport_label,
            'logo':     '',
            'is_live':  True,
            'start_ts': now_ts,
        })

    xbmc.log('[Starfleet/Sports] %s: %d events' % (domain, len(events)), xbmc.LOGINFO)
    return events


def _x24_streams(event_path, path_prefix, domain, source_label):
    """Generic stream scraper for *24all.ir event pages."""
    url = event_path.replace(path_prefix + ':', '')
    try:
        html = _sess().get(url, timeout=12,
                           headers=dict(_HEADERS, Referer='https://' + domain + '/')).text
    except Exception as e:
        xbmc.log('[Starfleet/Sports] %s stream page error (%s): %s' % (domain, event_path, e), xbmc.LOGWARNING)
        return []

    streams = _extract_stream_links(html, domain, source_label)

    # Also pick up any explicit watch/stream/live anchors not caught above
    extra_re = re.compile(
        r'<a[^>]+href="(https?://[^"]+)"[^>]*>(?:[^<]*(?:watch|stream|live)[^<]*)</a>',
        re.IGNORECASE
    )
    for m in extra_re.finditer(html):
        su = m.group(1).strip()
        if not su or domain in su:
            continue
        if not any(s['url'] == su for s in streams):
            streams.append({'label': source_label + ' Stream', 'url': su,
                            'quality': '', 'language': '', 'source': source_label})

    xbmc.log('[Starfleet/Sports] %s streams for %s: %d' % (domain, event_path, len(streams)), xbmc.LOGINFO)
    return streams


def _x24_streams_by_title(event_title, domain, path_prefix, sport_label, source_label):
    """Cross-reference: find best matching event on *24all.ir and scrape its streams."""
    evs = _x24_events(domain, sport_label, path_prefix)
    best_path, best_score = None, 0
    for ev in evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']
    if not best_path or best_score < 2:
        return []
    return _x24_streams(best_path, path_prefix, domain, source_label)


# ── mlb24all.ir (MLB-specific) ────────────────────────────────────────────────

_RE_MLB24_EVENT = re.compile(
    r'<a[^>]+href="(https?://mlb24all\.ir/[^"]+)"[^>]*>([^<]+)</a>',
    re.IGNORECASE
)
# Sport-specific wrappers using the generic _x24_* helpers

def _mlb24_events():
    return _x24_events('mlb24all.ir', 'MLB', 'mlb24')

def _mlb24_streams(event_path):
    return _x24_streams(event_path, 'mlb24', 'mlb24all.ir', 'MLB24')

def _mlb24_streams_by_title_inner(event_title):
    return _x24_streams_by_title(event_title, 'mlb24all.ir', 'mlb24', 'MLB', 'MLB24')


def _nhl24_events():
    return _x24_events('nhl24all.ir', 'NHL', 'nhl24')

def _nhl24_streams(event_path):
    return _x24_streams(event_path, 'nhl24', 'nhl24all.ir', 'NHL24')

def _nhl24_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'nhl24all.ir', 'nhl24', 'NHL', 'NHL24')


def _nfl24_events():
    return _x24_events('nfl24all.ir', 'NFL', 'nfl24')

def _nfl24_streams(event_path):
    return _x24_streams(event_path, 'nfl24', 'nfl24all.ir', 'NFL24')

def _nfl24_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'nfl24all.ir', 'nfl24', 'NFL', 'NFL24')


def _nba24_events():
    return _x24_events('nba24all.ir', 'NBA', 'nba24')

def _nba24_streams(event_path):
    return _x24_streams(event_path, 'nba24', 'nba24all.ir', 'NBA24')

def _nba24_streams_by_title(event_title):
    return _x24_streams_by_title(event_title, 'nba24all.ir', 'nba24', 'NBA', 'NBA24')


# ── Public stream API ─────────────────────────────────────────────────────────

def get_event_streams(event_path, event_id='', sport_slug='', title=''):
    """
    Fetch stream links for a specific event.
    Merges ISE streams + Roxiestreams + StreamsEast + CrackStreams + Sportsurge (+ MLB24 for mlb, NHL24 for nhl).
    Returns list of: {'label', 'url', 'quality', 'language', 'source'}
    """
    ck = ('sports_streams_%s' % event_id) if event_id else None
    if ck:
        cached = _cache.get(ck)
        if cached is not None:
            return cached

    streams = []

    # Determine event path source by prefix
    is_seast_path = event_path and event_path.startswith('streamseast:')
    is_mlb24_path = event_path and event_path.startswith('mlb24:')
    is_nhl24_path = event_path and event_path.startswith('nhl24:')
    is_nfl24_path = event_path and event_path.startswith('nfl24:')
    is_nba24_path = event_path and event_path.startswith('nba24:')
    is_tstek_path = event_path and event_path.startswith('tstek:')
    is_ise_path   = (event_path and not is_seast_path and not is_mlb24_path
                     and not is_nhl24_path and not is_nfl24_path and not is_nba24_path
                     and not is_tstek_path)

    # Build parallel fetch tasks
    futures = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        if is_ise_path:
            futures['ise']      = ex.submit(_ise_event_streams, event_path, event_id)
        if is_seast_path:
            futures['seast']    = ex.submit(_seast_event_streams, event_path)
        if is_mlb24_path:
            futures['mlb24']    = ex.submit(_mlb24_streams, event_path)
        if is_nhl24_path:
            futures['nhl24']    = ex.submit(_nhl24_streams, event_path)
        if is_nfl24_path:
            futures['nfl24']    = ex.submit(_nfl24_streams, event_path)
        if is_nba24_path:
            futures['nba24']    = ex.submit(_nba24_streams, event_path)
        if is_tstek_path:
            futures['tstek']    = ex.submit(_tstek_streams, event_path)
        if sport_slug:
            futures['roxie']    = ex.submit(_roxie_streams, sport_slug, title)
            if not is_seast_path and sport_slug in _SEAST_SLUGS:
                futures['seast_slug'] = ex.submit(_seast_event_streams_by_slug, sport_slug, title)
            futures['crack']    = ex.submit(_crack_event_streams, sport_slug, title)
            futures['surge']    = ex.submit(_sportsurge_streams, sport_slug, title)
        if sport_slug == 'mlb' and not is_mlb24_path:
            futures['mlb24_x']  = ex.submit(_mlb24_streams_by_title_inner, title)
        if sport_slug == 'nhl' and not is_nhl24_path:
            futures['nhl24_x']  = ex.submit(_nhl24_streams_by_title, title)
        if sport_slug == 'nfl' and not is_nfl24_path:
            futures['nfl24_x']  = ex.submit(_nfl24_streams_by_title, title)
        if sport_slug == 'nba' and not is_nba24_path:
            futures['nba24_x']  = ex.submit(_nba24_streams_by_title, title)
        if sport_slug in _TSTEK_SLUGS and not is_tstek_path:
            futures['tstek_x']  = ex.submit(_tstek_streams_by_title, sport_slug, title)

        for name, fut in futures.items():
            try:
                result = fut.result(timeout=12)
                if result:
                    streams += result
            except Exception as e:
                xbmc.log('[Starfleet/Sports] stream source error (%s): %s' % (name, e), xbmc.LOGWARNING)

    if ck:
        ttl = 5 * 60 if streams else 2 * 60
        _cache.set(ck, streams, ttl)

    xbmc.log('[Starfleet/Sports] event streams (%s/%s): %d total' % (sport_slug, event_id, len(streams)), xbmc.LOGINFO)
    return streams


def _seast_event_streams_by_slug(sport_slug, event_title):
    """
    Supplementary: fetch StreamsEast schedule for the sport, find matching event, get streams.
    Used when the event did NOT come from StreamsEast.
    """
    try:
        seast_evs = _seast_events(sport_slug)
    except Exception as e:
        xbmc.log('[Starfleet/Sports] seast_event_streams_by_slug error: %s' % e, xbmc.LOGWARNING)
        return []

    best_path  = None
    best_score = 0
    for ev in seast_evs:
        score = _title_score(event_title, ev['title'])
        if score > best_score:
            best_score = score
            best_path  = ev['path']

    if not best_path or best_score < 2:
        return []

    return _seast_event_streams(best_path)


