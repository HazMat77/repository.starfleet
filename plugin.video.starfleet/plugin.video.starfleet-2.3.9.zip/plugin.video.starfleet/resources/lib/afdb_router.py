# -*- coding: utf-8 -*-
"""
resources/lib/afdb_router.py — Adult Film Database section

Menu structure:
  🔞 Adult
    ├── 🆕 New Releases
    ├── 🏆 Most Popular
    ├── 🎭 Browse by Category
    ├── 🎬 Browse by Studio  (A-Z)
    ├── 👤 Browse by Actor   (A-Z)
    └── 🔍 Search

Each film item opens a detail page with:
  - Full description / synopsis
  - Cast list (each actor is browsable)
  - Studio, Director, Year, Runtime, Rating
  - Front cover as thumbnail
  - Large front cover as fanart
  - Back cover as additional art
  - Categories as genre tags

Playback:
  - No stream URL yet → shows "Add stream source" dialog
  - When a stream URL is supplied (StreamTape, DoodStream, etc.)
    it is passed to ResolveURL/URLResolver for resolution
  - Falls back to direct play if ResolveURL not installed
"""

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import afdb
from resources.lib import cache as _cache
from concurrent.futures import ThreadPoolExecutor

ADDON     = xbmcaddon.Addon()
PAGE_SIZE = 30


# ── Helpers ───────────────────────────────────────────────────────────────────

def _add_dir(handle, build_url, label, params, thumb='', plot=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_film(handle, build_url, film):
    """Add a film as a directly playable item — clicking searches scrapers for streams.
    Uses cached full detail (from prewarm) when available for richer metadata."""
    # Merge slim card data with cached full detail if available
    full = _cache.get('afdb_film_%s' % film.get('id', ''))
    d = dict(film)
    if full:
        d.update({k: v for k, v in full.items() if v})

    li = xbmcgui.ListItem(label=d['title'])

    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(d['title'])
        tag.setPlot(d.get('description', ''))
        if str(d.get('year', '')).isdigit():
            tag.setYear(int(d['year']))
        if d.get('studio'):
            tag.setStudios([d['studio']])
        if d.get('categories'):
            tag.setGenres(d['categories'])
        if d.get('director'):
            tag.setDirectors([d['director']])
        if d.get('rating'):
            tag.setRating(float(d['rating']))
        if d.get('runtime'):
            tag.setDuration(int(d['runtime']) * 60)
        tag.setMpaa('Adults Only')
        # Cast
        if d.get('cast'):
            actors = []
            for c in d['cast']:
                actor_detail = _cache.get('afdb_actor_detail_%s' % c.get('id', ''))
                photo = (actor_detail or {}).get('photo', '')
                actors.append(xbmcgui.Actor(c['name'], '', 0, photo))
            tag.setCast(actors)
    except Exception:
        li.setInfo('video', {
            'title':  d['title'],
            'plot':   d.get('description', ''),
            'year':   int(d['year']) if str(d.get('year', '')).isdigit() else 0,
            'studio': d.get('studio', ''),
            'genre':  ', '.join(d.get('categories', [])),
            'director': d.get('director', ''),
            'rating': float(d.get('rating', 0) or 0),
            'duration': int(d.get('runtime', 0) or 0) * 60,
            'mpaa':   'Adults Only',
        })

    art = {
        'thumb':   d.get('thumb', film.get('thumb', '')),
        'poster':  d.get('thumb', film.get('thumb', '')),
        'fanart':  d.get('fanart', d.get('thumb', '')),
        'banner':  d.get('backcover', ''),
    }
    shots = d.get('screenshots', [])
    if shots:
        art['extrafanart'] = shots[0]
        art['extrathumbs'] = shots[0]
    li.setArt(art)

    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle, build_url({
        'action':     'afdb_play_search',
        'film_id':    film['id'],
        'film_slug':  film.get('slug', ''),
        'film_title': film['title'],
    }), li, False)


def _need_fetch(key):
    return _cache.get(key) is None


def _progress(msg):
    d = xbmcgui.DialogProgress()
    d.create('Starfleet', msg)
    return d


def _next_page(handle, build_url, action, page, extra=None):
    params = {'action': action, 'page': page + 1}
    if extra:
        params.update(extra)
    _add_dir(handle, build_url,
             label='~~ Next Page (%d) ~~' % (page + 1),
             params=params)


# ── Adult Main Menu ───────────────────────────────────────────────────────────

def _prewarm_film_details(films):
    """
    Fire-and-forget background pre-fetch of full AFDB film detail
    (description, cast, studio, director, rating, photos) for each
    slim result in a list view. User sees instant detail loads with
    no loading dialog on subsequent clicks.
    Only fetches films whose detail cache is cold.
    Max 5 concurrent requests to avoid hammering AFDB.
    """
    cold = [
        (f['id'], f['slug']) for f in films
        if f.get('id') and _need_fetch('afdb_film_%s' % f['id'])
    ]
    if not cold:
        return

    def _fetch(film_id, film_slug):
        try:
            afdb.get_film_detail(film_id, film_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for film_id, film_slug in cold:
        pool.submit(_fetch, film_id, film_slug)
    pool.shutdown(wait=False)   # never blocks the UI


def _prewarm_actor_details(films):
    """
    Pre-fetch actor photos and profiles for cast members found in
    a list of film results. Pulls actor detail for any actor whose
    photo cache is cold so browsing cast is instant.
    Capped at 10 actors to avoid excessive requests.
    """
    seen     = set()
    to_fetch = []

    for film in films:
        for actor in film.get('cast', [])[:5]:  # top 5 cast per film
            aid = actor.get('id', '')
            if aid and aid not in seen:
                seen.add(aid)
                if _need_fetch('afdb_actor_detail_%s' % aid):
                    to_fetch.append((aid, actor.get('slug', '')))
            if len(to_fetch) >= 10:
                break
        if len(to_fetch) >= 10:
            break

    if not to_fetch:
        return

    def _fetch(actor_id, actor_slug):
        try:
            afdb.get_actor_detail(actor_id, actor_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for actor_id, actor_slug in to_fetch:
        pool.submit(_fetch, actor_id, actor_slug)
    pool.shutdown(wait=False)


def _filter_films_with_sources(films):
    """
    Filter a film list to only those that have at least one cached stream source.
    Uses the adult_streams title-cache only — no new HTTP requests.
    Films not yet in any cache pass through (graceful degradation on first load).
    Background prewarm is launched for unchecked films so next load is filtered.
    """
    try:
        from resources.lib import adult_streams as _as
        _as.prewarm_title_index()   # ensure index is built from cached data

        checked = []
        unchecked = []
        for film in films:
            result = _as.has_cached_source(film.get('title', ''))
            if result is None:
                unchecked.append(film)   # not yet in any cache — show it this time
            elif result:
                checked.append(film)     # confirmed has a source
            # else: confirmed has NO source — drop it

        # Background: pre-check unchecked films so next load can filter them
        if unchecked:
            def _prewarm_check():
                for f in unchecked:
                    try:
                        _as.search_by_title(f['title'])
                    except Exception:
                        pass
            import threading
            threading.Thread(target=_prewarm_check, daemon=True).start()

        return checked + unchecked
    except Exception as e:
        xbmc.log('[AFDB] source filter error: %s' % e, xbmc.LOGWARNING)
        return films   # fail open


def adult_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Adult')
    xbmcplugin.setContent(handle, 'movies')

    _add_dir(handle, build_url, 'Movies',
             {'action': 'adult_streams', 'page': 1},
             plot='All movies from all sources')

    _add_dir(handle, build_url, 'Search',
             {'action': 'adult_search_unified'},
             plot='Search by movie title, performer name, or scene type (e.g. anal)')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── New Releases ──────────────────────────────────────────────────────────────

def afdb_new(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🆕 New Releases')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_new_%d' % page)
    dlg  = _progress('Loading new releases...') if cold else None
    films = afdb.get_new_releases(page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    _prewarm_film_details(films)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_new', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Most Popular ──────────────────────────────────────────────────────────────

def afdb_popular(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🏆 Most Popular')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_popular_%d' % page)
    dlg  = _progress('Loading popular films...') if cold else None
    films = afdb.get_popular(page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_popular', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Categories ────────────────────────────────────────────────────────────────

def afdb_categories(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎭 Categories')
    xbmcplugin.setContent(handle, 'files')

    for cat in sorted(afdb.CATEGORIES):
        _add_dir(handle, build_url, cat,
                 {'action': 'afdb_by_category', 'category': cat, 'page': 1},
                 plot='Browse %s films' % cat)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def afdb_by_category(handle, build_url, category, page=1):
    xbmcplugin.setPluginCategory(handle, '🎭 %s' % category)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_cat_%s_%d' % (category.replace(' ', '_'), page))
    dlg  = _progress('Loading %s...' % category) if cold else None
    films = afdb.get_by_category(category, page=page)
    if dlg: dlg.close()

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_category', page,
                   extra={'category': category})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Studios ───────────────────────────────────────────────────────────────────

def afdb_studios(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '🎬 Studios — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_studios', 'letter': l})

    cold = _need_fetch('afdb_studios_%s' % letter)
    dlg  = _progress('Loading studios...') if cold else None
    studios = afdb.get_studios(letter)
    if dlg: dlg.close()

    for s in studios:
        _add_dir(handle, build_url, s['name'],
                 {'action': 'afdb_by_studio', 'studio': s['slug'],
                  'studio_name': s['name'], 'page': 1},
                 plot='Films from %s' % s['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_by_studio(handle, build_url, studio, studio_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '🎬 %s' % (studio_name or studio))
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_studio_%s_%d' % (studio.replace(' ', '_'), page))
    dlg  = _progress('Loading studio films...') if cold else None
    films = afdb.get_by_studio(studio, page=page)
    if dlg: dlg.close()

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_studio', page,
                   extra={'studio': studio, 'studio_name': studio_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Actors ────────────────────────────────────────────────────────────────────

def afdb_actors(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '👤 Actors — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_actors', 'letter': l})

    cold = _need_fetch('afdb_actors_%s' % letter)
    dlg  = _progress('Loading actors...') if cold else None
    actors = afdb.get_actors(letter)
    if dlg: dlg.close()

    for actor in actors:
        li = xbmcgui.ListItem(label=actor['name'])
        li.setInfo('video', {'title': actor['name']})
        li.setArt({
            'thumb':  actor.get('photo', ''),
            'icon':   actor.get('photo', ''),
            'poster': actor.get('photo', ''),
            'fanart': actor.get('photo_large', actor.get('photo', '')),
        })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'afdb_actor_detail',
                       'actor_id': actor['id'],
                       'actor_slug': actor['slug'],
                       'actor_name': actor['name']}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_detail(handle, build_url, actor_id, actor_slug, actor_name=''):
    """
    Show actor profile page:
    - Photo as full-screen poster/fanart
    - Bio, measurements, nationality, hair, eyes, ethnicity
    - Filmography link
    """
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'files')

    cold = afdb._cache.get('afdb_actor_detail_%s' % actor_id) is None
    dlg  = _progress('Loading %s...' % actor_name) if cold else None
    actor = afdb.get_actor_detail(actor_id, actor_slug)
    if dlg: dlg.close()

    # Build rich plot string from all available fields
    plot_parts = []
    if actor.get('birthday'):
        plot_parts.append('Born: %s' % actor['birthday'])
    if actor.get('nationality'):
        plot_parts.append('Nationality: %s' % actor['nationality'])
    if actor.get('ethnicity'):
        plot_parts.append('Ethnicity: %s' % actor['ethnicity'])
    if actor.get('measurements'):
        plot_parts.append('Measurements: %s' % actor['measurements'])
    if actor.get('height'):
        plot_parts.append('Height: %s' % actor['height'])
    if actor.get('weight'):
        plot_parts.append('Weight: %s' % actor['weight'])
    if actor.get('hair'):
        plot_parts.append('Hair: %s' % actor['hair'])
    if actor.get('eyes'):
        plot_parts.append('Eyes: %s' % actor['eyes'])
    if actor.get('bio'):
        plot_parts.append('\n%s' % actor['bio'])
    plot = '\n'.join(plot_parts)

    # Profile card item
    li = xbmcgui.ListItem(label='ℹ️  %s — Profile' % actor['name'])
    li.setInfo('video', {
        'title': actor['name'],
        'plot':  plot,
    })
    li.setArt({
        'thumb':   actor.get('photo', ''),
        'poster':  actor.get('photo', ''),
        'fanart':  actor.get('photo_large', actor.get('photo', '')),
        'banner':  actor.get('photo_large', actor.get('photo', '')),
    })
    xbmcplugin.addDirectoryItem(handle, build_url({'action': 'afdb_actor_detail',
                                                    'actor_id': actor_id,
                                                    'actor_slug': actor_slug,
                                                    'actor_name': actor['name']}),
                                li, False)

    # Filmography link
    _add_dir(handle, build_url,
             label='🎬  Filmography (%s films)' % (actor.get('filmcount') or ''),
             params={'action': 'afdb_actor_films',
                     'actor_id': actor_id,
                     'actor_slug': actor_slug,
                     'actor_name': actor['name'],
                     'page': 1},
             thumb=actor.get('photo', ''),
             plot='Browse all films featuring %s' % actor['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_films(handle, build_url, actor_id, actor_slug,
                     actor_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_actor_films_%s_%d' % (actor_id, page))
    dlg  = _progress('Loading films...') if cold else None
    films = afdb.get_by_actor(actor_id, actor_slug, page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No films found for %s' % actor_name,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_actor_films', page,
                   extra={'actor_id': actor_id, 'actor_slug': actor_slug,
                          'actor_name': actor_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Search ────────────────────────────────────────────────────────────────────

def afdb_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search Adult Film Database')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '🔍 Search: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    dlg   = _progress('Searching...')
    films = afdb.search_films(query)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        _add_film(handle, build_url, film)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Unified Search ────────────────────────────────────────────────────────────

def adult_search_unified(handle, build_url):
    """
    Single search box for: movie title, performer name, or scene type/tag.
    - If query matches an AFDB category → show films for that category
    - If query matches performer names → show matching actor filmographies
    - Otherwise → search AFDB titles + free stream sites by title
    """
    kb = xbmc.Keyboard('', 'Search movies, performers, scenes...')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, 'Search: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    query_lower = query.lower()

    # Check if query matches an AFDB category (scene type / tag search)
    category_match = None
    try:
        for cat in afdb.CATEGORIES:
            if query_lower in cat.lower() or cat.lower() in query_lower:
                category_match = cat
                break
    except Exception:
        pass

    if category_match:
        dlg = _progress('Searching "%s"...' % category_match)
        films = afdb.get_by_category(category_match, page=1)
        dlg.close()
        films = _filter_films_with_sources(films)
        for film in films:
            _add_film(handle, build_url, film)
        if films:
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
            return

    # Performer / actor search — search AFDB actor pages by walking A-Z
    # (AFDB has no actor search API; we skip this for now and rely on title search)
    actor_films = []

    # Title search across AFDB + free stream sites
    dlg = _progress('Searching "%s"...' % query)
    afdb_films = []
    try:
        afdb_films = afdb.search_films(query)
    except Exception:
        pass

    # Merge: actor films + AFDB title results (deduplicated by id)
    seen_ids = set()
    all_films = []
    for film in (actor_films + afdb_films):
        fid = film.get('id', '')
        if fid and fid not in seen_ids:
            seen_ids.add(fid)
            all_films.append(film)
    dlg.close()

    # If no AFDB results, search XXXClub torrents + free stream sites directly
    if not all_films:
        from resources.lib import adult_streams as _as
        from resources.lib import torrent_sources as _ts
        dlg = _progress('Searching "%s"...' % query)
        torrent_results = _ts.search_xxxclub(query, limit=20, media_type='adult')
        stream_results = _as.search_by_title(query)
        dlg.close()

        # Show XXXClub torrent results as individual playable items
        for t in torrent_results:
            label = '[COLOR cyan][XC][/COLOR] %s  [COLOR grey][%s][/COLOR]' % (
                t['title'], t.get('size', ''))
            li = xbmcgui.ListItem(label=label)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(t['title'])
                tag.setPlot('[XXXClub] Seeds: %d' % t.get('seeds', 0))
                tag.setMpaa('Adults Only')
            except Exception:
                li.setInfo('video', {'title': t['title'], 'mpaa': 'Adults Only'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(
                handle,
                build_url({'action': 'play_xxxclub_magnet',
                           'magnet': t['magnet'],
                           'title': t['title']}),
                li, False
            )

        # Show free stream results as individual playable items
        for s in stream_results:
            lbl = s.get('label') or query
            li = xbmcgui.ListItem(label='[COLOR yellow][Stream][/COLOR] %s' % lbl)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(lbl)
                tag.setMpaa('Adults Only')
            except Exception:
                li.setInfo('video', {'title': lbl, 'mpaa': 'Adults Only'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, s['url'], li, False)

        if torrent_results or stream_results:
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
            return

        xbmcgui.Dialog().notification('Adult', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
        return

    all_films = _filter_films_with_sources(all_films)
    for film in all_films:
        _add_film(handle, build_url, film)

    _prewarm_film_details(all_films)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Film Detail / Play ────────────────────────────────────────────────────────

def afdb_detail(handle, build_url, film_id, film_slug, film_title=''):
    """Legacy detail view — redirects to afdb_play_search."""
    afdb_play_search(handle, film_id, film_slug, film_title)


def afdb_play_search(handle, film_id, film_slug, film_title=''):
    """
    Browse AFDB for metadata → search scrapers + debrid + personal sources in parallel
    → source picker dialog → play via ResolveURL.

    Source order: Trailer first, then personal (MixDrop/Streamtape),
    then debrid [yellow], then free streams.
    """
    from resources.lib import adult_streams as _as
    from resources.lib import ade as _ade

    # Resolve title
    title = film_title
    year  = None
    if not title:
        cold = _need_fetch('afdb_film_%s' % film_id)
        dlg  = _progress('Loading...') if cold else None
        film_detail = afdb.get_film_detail(film_id, film_slug)
        if dlg: dlg.close()
        title = film_detail.get('title', '')
        year  = film_detail.get('year') or None
        if not film_detail.get('description') and title:
            try:
                _ade.search_by_title(title)
            except Exception:
                pass

    if not title:
        xbmcgui.Dialog().notification('Starfleet', 'Film title not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet — Searching streams', 'Looking for: %s' % title)

    from concurrent.futures import ThreadPoolExecutor as _TPE

    def _free():
        return _as.search_by_title(title)

    def _personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(title, year=year, media_type='adult')
        except Exception:
            return []

    def _debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            raw = _dt.get_debrid_streams(title, year=year, media_type='adult')
            # Mark debrid streams with yellow colour tag
            for s in raw:
                s['label'] = '[COLOR yellow]%s[/COLOR]' % s['label']
                s['is_debrid'] = True
            return raw
        except Exception:
            return []

    def _trailer():
        try:
            url = _ade.get_trailer_url(title)
            if url:
                return [{'label': '[Trailer]', 'url': url, 'is_trailer': True}]
        except Exception:
            pass
        return []

    with _TPE(max_workers=4) as _pool:
        _f_trailer  = _pool.submit(_trailer)
        _f_personal = _pool.submit(_personal)
        _f_debrid   = _pool.submit(_debrid)
        _f_free     = _pool.submit(_free)
        trailers  = _f_trailer.result(timeout=15)
        personals = _f_personal.result(timeout=15)
        debrids   = _f_debrid.result(timeout=25)
        frees     = _f_free.result(timeout=25)

    dlg.close()

    # Order: trailer first, then personal, then debrid (yellow), then free streams
    streams = trailers + personals + debrids + frees

    if not streams:
        xbmcgui.Dialog().notification(
            'Starfleet', 'No streams found for: %s' % title,
            xbmcgui.NOTIFICATION_WARNING, 5000
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = ['%s — %s' % (s['label'], s.get('url', '')[:40]) if s.get('is_trailer')
                   else s['label']
                   for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    elif '.mkv' in _url_lc:
        li.setMimeType('video/x-matroska')
    xbmcplugin.setResolvedUrl(handle, True, li)


_THUMB_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
)

def _thumb_ref(thumb, film_url=''):
    """Append Referer + User-Agent headers so Kodi can fetch images from protected CDNs."""
    if not thumb or '|' in thumb:
        return thumb
    import re as _re
    m = _re.match(r'(https?://[^/]+)', film_url or thumb)
    ref = (m.group(1) + '/') if m else ''
    if ref:
        return '%s|Referer=%s&User-Agent=%s' % (thumb, ref, _THUMB_UA)
    return '%s|User-Agent=%s' % (thumb, _THUMB_UA)


def _ade_enrich_background(films):
    """
    Fire-and-forget: fetch ADE metadata for free-stream films that have
    no thumbnail or description, so the next page load shows enriched data.
    Capped at 10 films per call to avoid hammering ADE.
    """
    from resources.lib import ade as _ade
    from concurrent.futures import ThreadPoolExecutor

    cold = [f for f in films
            if not f.get('thumb') or not f.get('description')][:10]
    if not cold:
        return

    def _fetch(film):
        try:
            _ade.search_by_title(film['title'])
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=4)
    for f in cold:
        pool.submit(_fetch, f)
    pool.shutdown(wait=False)


def adult_streams(handle, build_url, page=1):
    """
    Browse adult movies. Shows XXXClub torrents (fast) plus a Free Streams folder.
    Stream sources are loaded on-demand to avoid blocking the UI.
    """
    xbmcplugin.setPluginCategory(handle, 'Adult Movies — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading movies...')
    from resources.lib import torrent_sources as _ts
    xxxclub_torrents = []
    try:
        xxxclub_torrents, _ = _ts.browse_xxxclub(cursor=str(page))
        xbmc.log('[Starfleet] XXXClub page=%d returned %d items' % (page, len(xxxclub_torrents)), xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] XXXClub failed: %s' % e, xbmc.LOGWARNING)
    if dlg:
        dlg.close()

    # ── Free Streams folder (loads on click, doesn't block browse) ────────────
    if page == 1:
        li = xbmcgui.ListItem(label='[COLOR yellow]🌐  Free Streams[/COLOR]')
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle('Free Streams')
            tag.setPlot('Browse free adult movies from streaming sites')
        except Exception:
            li.setInfo('video', {'title': 'Free Streams', 'plot': 'Browse free adult movies from streaming sites'})
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_free_streams', 'page': 1}),
            li, True
        )

    # ── XXXClub torrents ──────────────────────────────────────────────────────
    for t in xxxclub_torrents:
        label = '[COLOR cyan][XC][/COLOR] %s  [COLOR grey][%s][/COLOR]' % (t['title'], t['size'])
        li = xbmcgui.ListItem(label=label)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(t['title'])
            tag.setPlot('[XXXClub] %s' % t['size'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': t['title'], 'plot': '[XXXClub] %s' % t['size'], 'mpaa': 'Adults Only'})
        if t.get('thumb'):
            li.setArt({'thumb': t['thumb'], 'poster': t['thumb'], 'icon': t['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_xxxclub_magnet',
                       'magnet': t['magnet'],
                       'title':  t['title']}),
            li, False
        )

    _next_page(handle, build_url, 'adult_streams', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_free_streams(handle, build_url, page=1):
    """
    Browse free adult stream sources (loaded on-demand to avoid UI freeze).
    """
    from resources.lib import adult_streams as _as
    import re as _re

    xbmcplugin.setPluginCategory(handle, 'Free Streams — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading free streams...')
    films = _as.get_all_stream_stubs(page=page)
    dlg.close()

    for film in (films or []):
        ade_key = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', film['title'].lower())[:80]
        ade_meta = _cache.get(ade_key)
        if ade_meta and isinstance(ade_meta, dict):
            if not film.get('thumb') and ade_meta.get('thumb'):
                film['thumb'] = ade_meta['thumb']
            if not film.get('description') and ade_meta.get('description'):
                film['description'] = ade_meta['description']

        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setPlot(film.get('description', ''))
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'plot': film.get('description', ''), 'mpaa': 'Adults Only'})

        if film.get('thumb'):
            thumb = _thumb_ref(film['thumb'], film.get('url', ''))
            li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb, 'icon': thumb})

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_stream_sources',
                       'film_id': film['id'],
                       'film_url': film.get('url', ''),
                       'title': film['title']}),
            li, False
        )

    if films:
        _ade_enrich_background(films)

    _next_page(handle, build_url, 'adult_free_streams', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_stream_sources(handle, build_url, film_id, title='', film_url=''):
    """
    Show a dialog listing all stream sources for a film, then play the chosen one.
    Always searches debrid/torrents regardless of whether free streams are cached.
    Fetches the detail page on demand if not cached (stub-based listing).
    """
    from resources.lib import adult_streams as _as
    from concurrent.futures import ThreadPoolExecutor

    # 1. Try merged cache (set by get_all_streams legacy path)
    film = _cache.get('fstreams_merged_%s' % film_id)

    # 2. Try per-source detail cache
    if not film:
        _PREFIX_CACHE = {
            'freeo_':   'fstreams_freeo_detail_%s',
            'xxxms_':   'fstreams_xxxms_detail_%s',
            'wpw_':     'fstreams_wpw_detail_%s',
            'wpf_':     'fstreams_wpf_detail_%s',
            'spn_':     'fstreams_spn_detail_%s',
            'xmovix_':  'fstreams_xmovix_detail_%s',
        }
        for prefix, ck_tpl in _PREFIX_CACHE.items():
            if film_id.startswith(prefix):
                slug = film_id[len(prefix):]
                film = _cache.get(ck_tpl % slug)
                break

    # 3. Fetch detail page on demand (stub listing path — no detail cached yet)
    if not film or not film.get('streams'):
        try:
            fetched = _as.fetch_film_detail_on_demand(film_id, film_url)
            if fetched and fetched.get('streams'):
                film = fetched
        except Exception as e:
            xbmc.log('[Starfleet/Streams] on-demand detail fetch error: %s' % e, xbmc.LOGWARNING)

    film_title  = title or (film.get('title', '') if film else '')
    cached_streams = (film.get('streams') or []) if film else []

    if not film_title:
        xbmcgui.Dialog().notification('Starfleet', 'Film title not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    def _personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(film_title, media_type='adult')
        except Exception:
            return []

    def _debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            raw = _dt.get_debrid_streams(film_title, media_type='adult')
            for s in raw:
                s['label'] = '[COLOR yellow]%s[/COLOR]' % s['label']
            return raw
        except Exception as e:
            xbmc.log('[Starfleet/Streams] debrid error: %s' % e, xbmc.LOGWARNING)
            return []

    def _site_search():
        # Always search the free streaming sites by title so AFDB browse/search
        # results also get free scraper streams, not just debrid results.
        if cached_streams:
            return cached_streams  # already have them from scraper cache
        try:
            return _as.search_by_title(film_title)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] site search error: %s' % e, xbmc.LOGWARNING)
            return []

    with ThreadPoolExecutor(max_workers=3) as pool:
        f_personal = pool.submit(_personal)
        f_debrid   = pool.submit(_debrid)
        f_sites    = pool.submit(_site_search)
        try:
            personals = f_personal.result(timeout=15)
        except Exception:
            personals = []
        try:
            debrids = f_debrid.result(timeout=40)
        except Exception:
            debrids = []
        try:
            site_free = f_sites.result(timeout=40)
        except Exception:
            site_free = []

    streams = personals + debrids + site_free

    if not streams:
        xbmcgui.Dialog().notification('Starfleet', 'No streams found for: %s' % film_title,
                                       xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = xbmcgui.Dialog().select('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    elif '.mkv' in _url_lc:
        li.setMimeType('video/x-matroska')
    xbmcplugin.setResolvedUrl(handle, True, li)


def adult_stream_play(stream_url, title=''):
    """Resolve a stream URL and return the playable URL, or '' on failure.
    Callers pass the returned URL to setResolvedUrl(handle, True, ListItem(path=url))."""
    if not stream_url:
        return ''

    # Route magnet URIs through Elementum
    if stream_url.startswith('magnet:'):
        from urllib.parse import quote as _uq
        elementum_url = 'plugin://plugin.video.elementum/play?uri=%s' % _uq(stream_url)
        xbmc.log('[Starfleet/Streams] Routing magnet via Elementum: ' + elementum_url[:80], xbmc.LOGINFO)
        return elementum_url

    resolved_url = stream_url

    # Step 1: internal resolver for embed domains ResolveURL doesn't cover
    try:
        from resources.lib import embed_resolver as _er
        internal = _er.resolve(stream_url)
        if internal:
            xbmc.log('[Starfleet/Streams] InternalResolver: %s' % internal[:80], xbmc.LOGINFO)
            resolved_url = internal
    except Exception as e:
        xbmc.log('[Starfleet/Streams] InternalResolver error: %s' % e, xbmc.LOGWARNING)

    # Step 2: ResolveURL for hosters it supports (DoodStream, MixDrop, etc.)
    if resolved_url == stream_url:
        try:
            import resolveurl
            if resolveurl.HostedMediaFile(stream_url).valid_url():
                hmf = resolveurl.HostedMediaFile(stream_url)
                resolved_url = hmf.resolve()
                xbmc.log('[Starfleet/Streams] ResolveURL: %s' % (resolved_url or 'failed')[:80], xbmc.LOGINFO)
        except ImportError:
            xbmc.log('[Starfleet/Streams] ResolveURL not installed', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        return ''

    # JS embed with unresolved # fragment — Kodi can't play it
    if resolved_url == stream_url and '#' in resolved_url:
        return ''

    return resolved_url


def afdb_play(handle, stream_url, film_id=''):
    """
    Resolve and play a stream URL via ResolveURL if available,
    otherwise direct play.
    """
    if not stream_url:
        xbmcgui.Dialog().ok(
            'Starfleet — No Stream Source',
            'No stream URL has been assigned to this film yet.\n\n'
            'To add playback support:\n'
            '1. Find the film on a hoster (StreamTape, DoodStream, etc.)\n'
            '2. The stream URL will be passed here automatically\n'
            '   once a source plugin or scraper provides it.\n\n'
            'Metadata from Adult Film Database is ready and waiting.'
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    resolved_url = stream_url

    # Try ResolveURL addon first (supports 50+ hosters)
    try:
        import resolveurl
        if resolveurl.HostedMediaFile(stream_url).valid_url():
            hmf = resolveurl.HostedMediaFile(stream_url)
            resolved_url = hmf.resolve()
            xbmc.log('[AFDB] ResolveURL resolved: %s' % resolved_url[:80],
                     xbmc.LOGINFO)
    except ImportError:
        xbmc.log('[AFDB] ResolveURL not installed — playing directly',
                 xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[AFDB] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        xbmcgui.Dialog().notification('Adult', 'Could not resolve stream URL',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved_url)
    xbmcplugin.setResolvedUrl(handle, True, li)


# ── XXXClub Browse ────────────────────────────────────────────────────────────

def xxxclub_browse(handle, build_url, cursor=''):
    """
    Browse latest torrents from XXXClub.to.
    Each item is directly playable via debrid (magnet → debrid → stream).
    """
    from resources.lib import torrent_sources as _ts

    xbmcplugin.setPluginCategory(handle, '🔞 XXXClub — Latest')
    xbmcplugin.setContent(handle, 'movies')

    dlg = xbmcgui.DialogProgress()
    dlg.create('XXXClub', 'Fetching latest torrents...')

    torrents, next_cursor = _ts.browse_xxxclub(cursor=cursor)
    dlg.close()

    if not torrents:
        xbmcgui.Dialog().notification('XXXClub', 'No results found', xbmcgui.NOTIFICATION_INFO)
        return

    for t in torrents:
        li = xbmcgui.ListItem(label='%s  [COLOR grey][%s][/COLOR]' % (t['title'], t['size']))
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(t['title'])
            tag.setPlot('[COLOR grey]%s[/COLOR]' % t['size'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': t['title'], 'plot': t['size'], 'mpaa': 'Adults Only'})
        if t.get('thumb'):
            li.setArt({'thumb': t['thumb'], 'poster': t['thumb'], 'icon': t['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_xxxclub_magnet',
                       'magnet': t['magnet'],
                       'title':  t['title']}),
            li, False
        )

    if next_cursor:
        _add_dir(handle, build_url, '» Next Page',
                 {'action': 'xxxclub_browse', 'cursor': next_cursor},
                 plot='Load next page')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def play_xxxclub_magnet(handle, magnet, title=''):
    """Resolve a XXXClub magnet via debrid and play it."""
    from resources.lib import debrid_torrent as _dt

    dlg = xbmcgui.DialogProgress()
    dlg.create('XXXClub', 'Resolving via debrid...')

    try:
        import urllib.parse as _ul, re as _re
        qs = _ul.parse_qs(_ul.urlparse(magnet).query)
        info_hash = _re.search(r'btih:([a-fA-F0-9]{40})', magnet)
        info_hash = info_hash.group(1).lower() if info_hash else ''

        stream_url = None
        for fn in (_dt.rd_magnet_to_stream, _dt.ad_magnet_to_stream,
                   _dt.pm_magnet_to_stream, _dt.tb_magnet_to_stream):
            try:
                result = fn(magnet, info_hash)
                if result:
                    stream_url = result
                    break
            except Exception:
                continue
    finally:
        dlg.close()

    if not stream_url:
        # No debrid — route via Elementum by resolving directly to the plugin URL
        import urllib.parse as _ul2
        elem_url = 'plugin://plugin.video.elementum/play?uri=' + _ul2.quote(magnet, safe='')
        xbmc.log('[Starfleet] XXXClub no debrid, routing via Elementum: %s' % elem_url[:80], xbmc.LOGINFO)
        li = xbmcgui.ListItem(path=elem_url, label=title or 'XXXClub')
        xbmcplugin.setResolvedUrl(handle, True, li)
        return

    li = xbmcgui.ListItem(path=stream_url, label=title)
    xbmcplugin.setResolvedUrl(handle, True, li)
