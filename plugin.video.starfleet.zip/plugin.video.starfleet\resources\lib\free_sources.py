﻿# -*- coding: utf-8 -*-
"""
resources/lib/free_sources.py

Free streaming site catalog scrapers.

Sites:
  BounceTV      — bouncetv.com  — HTML scrapable. TV shows only.
  Popcornflix   — popcornflix.com — JS-rendered, use TMDB browse with site reference
  Fawesome       — fawesome.tv   — JS-rendered, use TMDB browse with site reference
  Filmzie        — filmzie.com   — JS-rendered, use TMDB browse with site reference
  Midnight Pulp  — midnightpulp.com — JS-rendered
  DistroTV       — distro.tv     — FAST channels, JS-rendered
  Radial Ent.    — radialentertainment.com — JS-rendered

For JS-rendered sites, we provide a catalogue of their known content categories
(comedy, horror, etc.) backed by TMDB discovery, with the site listed as a
free streaming reference source in the play dialog.

BounceTV returns actual show listings for TMDB lookup.
"""

import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

import requests as _req
from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
}

_RE_STRIP = re.compile(r'<[^>]+>')
_RE_WS    = re.compile(r'\s+')

def _clean(t):
    return _RE_WS.sub(' ', _RE_STRIP.sub(' ', t)).strip()

_session = None

def _sess():
    global _session
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
    return _session

def _get(url, timeout=10):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


# ── Free streaming service registry ──────────────────────────────────────────

# Each entry: id, label, icon_url, media_type ('movies'|'tv'|'both'), scrapable
FREE_SERVICES = [
    {
        'id':         'archive',
        'label':      'Internet Archive (Public Domain)',
        'icon':       'https://archive.org/images/glogo.png',
        'media_type': 'movies',
        'scrapable':  True,
        'url':        'https://archive.org/details/feature_films',
    },
    {
        'id':         'popcornflix',
        'label':      'Popcornflix',
        'icon':       'https://logo.clearbit.com/popcornflix.com',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://www.popcornflix.com',
    },
    {
        'id':         'fawesome',
        'label':      'Fawesome',
        'icon':       'https://logo.clearbit.com/fawesome.tv',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://fawesome.tv',
    },
    {
        'id':         'filmzie',
        'label':      'Filmzie',
        'icon':       'https://logo.clearbit.com/filmzie.com',
        'media_type': 'movies',
        'scrapable':  False,
        'url':        'https://filmzie.com',
    },
    {
        'id':         'midnightpulp',
        'label':      'Midnight Pulp',
        'icon':       'https://logo.clearbit.com/midnightpulp.com',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://www.midnightpulp.com',
    },
    {
        'id':         'distrotv',
        'label':      'DistroTV',
        'icon':       'https://logo.clearbit.com/distro.tv',
        'media_type': 'both',
        'scrapable':  False,
        'url':        'https://www.distro.tv',
    },
    {
        'id':         'bouncetv',
        'label':      'BounceTV',
        'icon':       'https://logo.clearbit.com/bouncetv.com',
        'media_type': 'tv',
        'scrapable':  True,
        'url':        'https://www.bouncetv.com',
    },
    {
        'id':         'radial',
        'label':      'Radial Entertainment',
        'icon':       'https://logo.clearbit.com/radialentertainment.com',
        'media_type': 'movies',
        'scrapable':  False,
        'url':        'https://www.radialentertainment.com',
    },
]


def get_free_services(media_type=None):
    """Return list of free service dicts, optionally filtered by media_type."""
    if media_type is None:
        return FREE_SERVICES
    return [s for s in FREE_SERVICES if s['media_type'] in (media_type, 'both')]


# ── BounceTV scraper ──────────────────────────────────────────────────────────

BOUNCE_BASE = 'https://www.bouncetv.com'

_RE_BOUNCE_SHOW = re.compile(
    r'href="(/show/([a-z0-9][a-z0-9-]+)/(\d+))"',
    re.IGNORECASE
)
_RE_BOUNCE_THUMB = re.compile(
    r'<img[^>]+(?:data-src|src)="(https://storage\.googleapis\.com/[^"]+)"[^>]+alt="([^"]+)"',
    re.IGNORECASE
)


def get_bouncetv_shows():
    """
    Scrape BounceTV show listings.
    Returns list of: {'id', 'slug', 'title', 'thumb', 'url'}
    """
    ck = 'free_bouncetv_shows'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html  = _get(BOUNCE_BASE + '/shows')
        shows = []
        seen  = set()

        # Match show links
        for m in _RE_BOUNCE_SHOW.finditer(html):
            path, slug, show_id = m.group(1), m.group(2), m.group(3)
            if show_id in seen:
                continue
            seen.add(show_id)

            # Find thumbnail near this link
            block = html[m.start():m.start() + 400]
            im    = _RE_BOUNCE_THUMB.search(block)
            thumb = im.group(1) if im else ''
            title = slug.replace('-', ' ').title()

            shows.append({
                'id':    show_id,
                'slug':  slug,
                'title': title,
                'thumb': thumb,
                'url':   BOUNCE_BASE + path,
            })

        _cache.set(ck, shows, 6 * 3600)
        xbmc.log('[Starfleet/Free] BounceTV: %d shows' % len(shows), xbmc.LOGINFO)
        return shows
    except Exception as e:
        xbmc.log('[Starfleet/Free] BounceTV error: %s' % e, xbmc.LOGERROR)
        return []


# ── TMDB-backed show/movie list for non-scrapable sites ──────────────────────

def get_free_movies_tmdb(genre_id=None, page=1):
    """
    Return popular free-tier friendly movies from TMDB.
    Used to populate Popcornflix, Fawesome, Filmzie etc.
    """
    from resources.lib import metadata as meta
    try:
        if genre_id:
            return meta.get_movies_by_genre(genre_id, page=page)
        return meta.get_movies_popular(page=page)
    except Exception as e:
        xbmc.log('[Starfleet/Free] TMDB movies error: %s' % e, xbmc.LOGWARNING)
        return []


def get_free_tv_tmdb(genre_id=None, page=1):
    """Return popular free-tier friendly TV shows from TMDB."""
    from resources.lib import metadata as meta
    try:
        if genre_id:
            return meta.get_tv_by_genre(genre_id, page=page)
        return meta.get_tv_popular(page=page)
    except Exception as e:
        xbmc.log('[Starfleet/Free] TMDB tv error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Popcornflix API ───────────────────────────────────────────────────────────
# Backend: rapi.ifood.tv (FutureToday shared backend)
# siteId=1518 = Popcornflix web; platform_id=1217575 = PLATFORM_WEBSITE

_PCF_RAPI   = 'http://rapi.ifood.tv'
_PCF_PARAMS = (
    'appId=9&siteId=1518&platform_id=1217575&deviceId=starfleet'
    '&apiEnv=production&session-id=0&auth-token=1217575'
    '&gridstyle=flat-movie&keys='
)


def get_popcornflix_movies(page=1):
    """
    Return movies from Popcornflix with direct HLS stream URLs.
    Uses the rapi.ifood.tv backend — stream URLs are in the listing response.
    """
    ck = 'free_pcf_movies_p%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    per_page = 20
    start    = (page - 1) * per_page
    url = (
        '%s/recipes.php?searchType=popular&%s'
        '&max-results=%d&start-index=%d&country=CA'
        % (_PCF_RAPI, _PCF_PARAMS, per_page, start)
    )

    try:
        r = _sess().get(url, timeout=12)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Free] Popcornflix list error: %s' % e, xbmc.LOGERROR)
        return []

    if data.get('status') != 'ok':
        xbmc.log('[Starfleet/Free] Popcornflix API: %s' % data.get('data', {}).get('description', ''), xbmc.LOGWARNING)
        return []

    items = []
    for m in (data.get('results') or []):
        title = m.get('title') or ''
        if not title:
            continue

        # Stream URL — HLS preferred, fallback to MP4
        hls = m.get('video_hls_url') or m.get('video_url') or ''

        items.append({
            'title':      title,
            'year':       str(m.get('year') or ''),
            'plot':       (m.get('description') or '')[:300],
            'thumb':      m.get('main_picture') or m.get('picture') or '',
            'fanart':     '',
            'rating':     str(m.get('rating_average') or ''),
            'tmdb_id':    '',
            'archive_id': '',
            'stream_url': hls,
            'pcf_id':     str(m.get('node_id') or ''),
        })

    _cache.set(ck, items, 1800)
    xbmc.log('[Starfleet/Free] Popcornflix: %d movies (page %d)' % (len(items), page), xbmc.LOGINFO)
    return items


# ── Internet Archive public domain movies ─────────────────────────────────────

_ARCHIVE_SEARCH = (
    'https://archive.org/advancedsearch.php'
    '?q=collection%%3Afeature_films+mediatype%%3Amovies'
    '&fl[]=identifier,title,description,year'
    '&output=json&rows=20&sort[]=downloads+desc&page=%d'
)

_ARCHIVE_META = 'https://archive.org/metadata/%s'
_ARCHIVE_IMG  = 'https://archive.org/services/img/%s'
_ARCHIVE_DL   = 'https://archive.org/download/%s/%s'


def get_archive_movies(page=1):
    """
    Return public domain feature films from archive.org with direct playback.
    Each item has 'archive_id' set so free_play can resolve the MP4 URL.
    """
    ck = 'free_archive_p%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        r = _sess().get(_ARCHIVE_SEARCH % page, timeout=12)
        r.raise_for_status()
        docs = r.json().get('response', {}).get('docs', [])
    except Exception as e:
        xbmc.log('[Starfleet/Free] Archive.org search error: %s' % e, xbmc.LOGERROR)
        return []

    items = []
    for doc in docs:
        ident = doc.get('identifier', '')
        if not ident:
            continue
        title = doc.get('title') or ident.replace('_', ' ').replace('-', ' ').title()
        year  = str(doc.get('year', '') or '')
        plot  = doc.get('description', '')
        if isinstance(plot, list):
            plot = ' '.join(plot)
        # Strip HTML tags from description
        plot = _RE_STRIP.sub(' ', plot or '').strip()

        items.append({
            'title':      title,
            'year':       year,
            'plot':       plot[:300] if plot else '',
            'thumb':      _ARCHIVE_IMG % ident,
            'fanart':     '',
            'rating':     '',
            'tmdb_id':    '',
            'archive_id': ident,
        })

    _cache.set(ck, items, 3600)
    xbmc.log('[Starfleet/Free] Archive.org: %d movies (page %d)' % (len(items), page), xbmc.LOGINFO)
    return items


def resolve_archive_stream(archive_id):
    """
    Fetch archive.org item metadata and return direct MP4 URL.
    Returns empty string on failure.
    """
    try:
        r = _sess().get(_ARCHIVE_META % archive_id, timeout=12)
        r.raise_for_status()
        files = r.json().get('files', [])
    except Exception as e:
        xbmc.log('[Starfleet/Free] Archive.org metadata error (%s): %s' % (archive_id, e), xbmc.LOGERROR)
        return ''

    # Prefer 512kb (smaller/faster) MP4, then any MP4, then any video
    mp4_files = [f for f in files if f.get('format', '').upper() in ('MPEG4', 'H.264')]
    if not mp4_files:
        mp4_files = [f for f in files if f.get('name', '').lower().endswith('.mp4')]

    if not mp4_files:
        return ''

    # Pick smallest/most compatible — prefer files ending in .mp4 that aren't .thumbs
    chosen = None
    for f in mp4_files:
        name = f.get('name', '')
        if '.thumbs' in name or name.endswith('.jpg'):
            continue
        if chosen is None:
            chosen = f
        # Prefer 512kb version
        elif '512' in name and '512' not in (chosen.get('name') or ''):
            chosen = f

    if not chosen:
        return ''

    return _ARCHIVE_DL % (archive_id, chosen['name'])
