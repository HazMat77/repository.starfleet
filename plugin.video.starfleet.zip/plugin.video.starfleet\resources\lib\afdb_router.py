# -*- coding: utf-8 -*-
"""
resources/lib/afdb_router.py — Adult Film Database section

Menu structure:
  🔞 Adult
    ├── 🆕 New Releases
    ├── 🏆 Most Popular
    ├── 🎭 Browse by Category
    ├── 🎬 Browse by Studio  (A-Z)
    ├── 👤 Browse by Actor   (A-Z)
    └── 🔍 Search

Each film item opens a detail page with:
  - Full description / synopsis
  - Cast list (each actor is browsable)
  - Studio, Director, Year, Runtime, Rating
  - Front cover as thumbnail
  - Large front cover as fanart
  - Back cover as additional art
  - Categories as genre tags

Playback:
  - No stream URL yet → shows "Add stream source" dialog
  - When a stream URL is supplied (StreamTape, DoodStream, etc.)
    it is passed to ResolveURL/URLResolver for resolution
  - Falls back to direct play if ResolveURL not installed
"""

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import afdb
from resources.lib import cache as _cache
from concurrent.futures import ThreadPoolExecutor

ADDON     = xbmcaddon.Addon()
PAGE_SIZE = 30


# ── Helpers ───────────────────────────────────────────────────────────────────

def _add_dir(handle, build_url, label, params, thumb='', plot=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_film(handle, build_url, film, action='afdb_detail'):
    """Add a film as a playable/detail item with full art."""
    li = xbmcgui.ListItem(label=film['title'])

    info = {
        'title':  film['title'],
        'plot':   film.get('description', ''),
        'year':   int(film['year']) if str(film.get('year', '')).isdigit() else 0,
        'studio': film.get('studio', ''),
        'genre':  ', '.join(film.get('categories', [])),
        'director': film.get('director', ''),
        'rating': float(film.get('rating', 0)),
        'duration': int(film.get('runtime', 0)) * 60,
        'cast':   [c['name'] for c in film.get('cast', [])],
        'mpaa':   'Adults Only',
    }
    li.setInfo('video', info)

    art = {
        'thumb':   film.get('thumb', ''),
        'poster':  film.get('thumb', ''),
        'fanart':  film.get('fanart', ''),
        'banner':  film.get('backcover', ''),
    }
    li.setArt(art)
    li.setProperty('IsPlayable', 'true')

    xbmcplugin.addDirectoryItem(handle, build_url({
        'action':     action,
        'film_id':    film['id'],
        'film_slug':  film['slug'],
        'film_title': film['title'],
    }), li, False)


def _need_fetch(key):
    return _cache.get(key) is None


def _progress(msg):
    d = xbmcgui.DialogProgress()
    d.create('Starfleet', msg)
    return d


def _next_page(handle, build_url, action, page, extra=None):
    params = {'action': action, 'page': page + 1}
    if extra:
        params.update(extra)
    _add_dir(handle, build_url,
             label='▶  Next page (%d)' % (page + 1),
             params=params)


# ── Adult Main Menu ───────────────────────────────────────────────────────────

def _prewarm_film_details(films):
    """
    Fire-and-forget background pre-fetch of full AFDB film detail
    (description, cast, studio, director, rating, photos) for each
    slim result in a list view. User sees instant detail loads with
    no loading dialog on subsequent clicks.
    Only fetches films whose detail cache is cold.
    Max 5 concurrent requests to avoid hammering AFDB.
    """
    cold = [
        (f['id'], f['slug']) for f in films
        if f.get('id') and _need_fetch('afdb_film_%s' % f['id'])
    ]
    if not cold:
        return

    def _fetch(film_id, film_slug):
        try:
            afdb.get_film_detail(film_id, film_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for film_id, film_slug in cold:
        pool.submit(_fetch, film_id, film_slug)
    pool.shutdown(wait=False)   # never blocks the UI


def _prewarm_actor_details(films):
    """
    Pre-fetch actor photos and profiles for cast members found in
    a list of film results. Pulls actor detail for any actor whose
    photo cache is cold so browsing cast is instant.
    Capped at 10 actors to avoid excessive requests.
    """
    seen     = set()
    to_fetch = []

    for film in films:
        for actor in film.get('cast', [])[:5]:  # top 5 cast per film
            aid = actor.get('id', '')
            if aid and aid not in seen:
                seen.add(aid)
                if _need_fetch('afdb_actor_detail_%s' % aid):
                    to_fetch.append((aid, actor.get('slug', '')))
            if len(to_fetch) >= 10:
                break
        if len(to_fetch) >= 10:
            break

    if not to_fetch:
        return

    def _fetch(actor_id, actor_slug):
        try:
            afdb.get_actor_detail(actor_id, actor_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for actor_id, actor_slug in to_fetch:
        pool.submit(_fetch, actor_id, actor_slug)
    pool.shutdown(wait=False)


def adult_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🔞 Adult')
    xbmcplugin.setContent(handle, 'movies')

    _add_dir(handle, build_url, '🆕  New Releases',
             {'action': 'afdb_new', 'page': 1},
             plot='Latest additions to the Adult Film Database')

    _add_dir(handle, build_url, '🏆  Most Popular',
             {'action': 'afdb_popular', 'page': 1},
             plot='Most viewed films in the database')

    _add_dir(handle, build_url, '🎭  Browse by Category',
             {'action': 'afdb_categories'},
             plot='Browse films by category / genre')

    _add_dir(handle, build_url, '🎬  Browse by Studio',
             {'action': 'afdb_studios', 'letter': 'A'},
             plot='Browse films by production studio')

    _add_dir(handle, build_url, '👤  Browse by Actor',
             {'action': 'afdb_actors', 'letter': 'A'},
             plot='Browse films by performer')

    _add_dir(handle, build_url, '🔍  Search',
             {'action': 'afdb_search'},
             plot='Search the Adult Film Database by title')

    _add_dir(handle, build_url, '▶  Stream — Browse Free Streams',
             {'action': 'adult_streams', 'page': 1},
             plot='Free streams from freeomovie.to, xxxmoviestream.org, pornwatch.ws, watchpornfree.info, speedporn.net — merged & deduplicated')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── New Releases ──────────────────────────────────────────────────────────────

def afdb_new(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🆕 New Releases')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_new_%d' % page)
    dlg  = _progress('Loading new releases...') if cold else None
    films = afdb.get_new_releases(page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        _add_film(handle, build_url, film)

    _prewarm_film_details(films)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_new', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Most Popular ──────────────────────────────────────────────────────────────

def afdb_popular(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🏆 Most Popular')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_popular_%d' % page)
    dlg  = _progress('Loading popular films...') if cold else None
    films = afdb.get_popular(page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_popular', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Categories ────────────────────────────────────────────────────────────────

def afdb_categories(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎭 Categories')
    xbmcplugin.setContent(handle, 'files')

    for cat in sorted(afdb.CATEGORIES):
        _add_dir(handle, build_url, cat,
                 {'action': 'afdb_by_category', 'category': cat, 'page': 1},
                 plot='Browse %s films' % cat)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def afdb_by_category(handle, build_url, category, page=1):
    xbmcplugin.setPluginCategory(handle, '🎭 %s' % category)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_cat_%s_%d' % (category.replace(' ', '_'), page))
    dlg  = _progress('Loading %s...' % category) if cold else None
    films = afdb.get_by_category(category, page=page)
    if dlg: dlg.close()

    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_category', page,
                   extra={'category': category})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Studios ───────────────────────────────────────────────────────────────────

def afdb_studios(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '🎬 Studios — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_studios', 'letter': l})

    cold = _need_fetch('afdb_studios_%s' % letter)
    dlg  = _progress('Loading studios...') if cold else None
    studios = afdb.get_studios(letter)
    if dlg: dlg.close()

    for s in studios:
        _add_dir(handle, build_url, s['name'],
                 {'action': 'afdb_by_studio', 'studio': s['slug'],
                  'studio_name': s['name'], 'page': 1},
                 plot='Films from %s' % s['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_by_studio(handle, build_url, studio, studio_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '🎬 %s' % (studio_name or studio))
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_studio_%s_%d' % (studio.replace(' ', '_'), page))
    dlg  = _progress('Loading studio films...') if cold else None
    films = afdb.get_by_studio(studio, page=page)
    if dlg: dlg.close()

    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_studio', page,
                   extra={'studio': studio, 'studio_name': studio_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Actors ────────────────────────────────────────────────────────────────────

def afdb_actors(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '👤 Actors — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_actors', 'letter': l})

    cold = _need_fetch('afdb_actors_%s' % letter)
    dlg  = _progress('Loading actors...') if cold else None
    actors = afdb.get_actors(letter)
    if dlg: dlg.close()

    for actor in actors:
        li = xbmcgui.ListItem(label=actor['name'])
        li.setInfo('video', {'title': actor['name']})
        li.setArt({
            'thumb':  actor.get('photo', ''),
            'icon':   actor.get('photo', ''),
            'poster': actor.get('photo', ''),
            'fanart': actor.get('photo_large', actor.get('photo', '')),
        })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'afdb_actor_detail',
                       'actor_id': actor['id'],
                       'actor_slug': actor['slug'],
                       'actor_name': actor['name']}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_detail(handle, build_url, actor_id, actor_slug, actor_name=''):
    """
    Show actor profile page:
    - Photo as full-screen poster/fanart
    - Bio, measurements, nationality, hair, eyes, ethnicity
    - Filmography link
    """
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'files')

    cold = afdb._cache.get('afdb_actor_detail_%s' % actor_id) is None
    dlg  = _progress('Loading %s...' % actor_name) if cold else None
    actor = afdb.get_actor_detail(actor_id, actor_slug)
    if dlg: dlg.close()

    # Build rich plot string from all available fields
    plot_parts = []
    if actor.get('birthday'):
        plot_parts.append('Born: %s' % actor['birthday'])
    if actor.get('nationality'):
        plot_parts.append('Nationality: %s' % actor['nationality'])
    if actor.get('ethnicity'):
        plot_parts.append('Ethnicity: %s' % actor['ethnicity'])
    if actor.get('measurements'):
        plot_parts.append('Measurements: %s' % actor['measurements'])
    if actor.get('height'):
        plot_parts.append('Height: %s' % actor['height'])
    if actor.get('weight'):
        plot_parts.append('Weight: %s' % actor['weight'])
    if actor.get('hair'):
        plot_parts.append('Hair: %s' % actor['hair'])
    if actor.get('eyes'):
        plot_parts.append('Eyes: %s' % actor['eyes'])
    if actor.get('bio'):
        plot_parts.append('\n%s' % actor['bio'])
    plot = '\n'.join(plot_parts)

    # Profile card item
    li = xbmcgui.ListItem(label='ℹ️  %s — Profile' % actor['name'])
    li.setInfo('video', {
        'title': actor['name'],
        'plot':  plot,
    })
    li.setArt({
        'thumb':   actor.get('photo', ''),
        'poster':  actor.get('photo', ''),
        'fanart':  actor.get('photo_large', actor.get('photo', '')),
        'banner':  actor.get('photo_large', actor.get('photo', '')),
    })
    xbmcplugin.addDirectoryItem(handle, build_url({'action': 'afdb_actor_detail',
                                                    'actor_id': actor_id,
                                                    'actor_slug': actor_slug,
                                                    'actor_name': actor['name']}),
                                li, False)

    # Filmography link
    _add_dir(handle, build_url,
             label='🎬  Filmography (%s films)' % (actor.get('filmcount') or ''),
             params={'action': 'afdb_actor_films',
                     'actor_id': actor_id,
                     'actor_slug': actor_slug,
                     'actor_name': actor['name'],
                     'page': 1},
             thumb=actor.get('photo', ''),
             plot='Browse all films featuring %s' % actor['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_films(handle, build_url, actor_id, actor_slug,
                     actor_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_actor_films_%s_%d' % (actor_id, page))
    dlg  = _progress('Loading films...') if cold else None
    films = afdb.get_by_actor(actor_id, actor_slug, page=page)
    if dlg: dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No films found for %s' % actor_name,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_actor_films', page,
                   extra={'actor_id': actor_id, 'actor_slug': actor_slug,
                          'actor_name': actor_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Search ────────────────────────────────────────────────────────────────────

def afdb_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search Adult Film Database')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '🔍 Search: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    dlg   = _progress('Searching...')
    films = afdb.search_films(query)
    dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        _add_film(handle, build_url, film)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


# ── Film Detail / Play ────────────────────────────────────────────────────────

def afdb_detail(handle, build_url, film_id, film_slug, film_title=''):
    """
    Load full metadata for the film and present it.
    Since there's no stream URL yet, show the detail as a playable item
    that informs the user how to add a stream source.
    """
    xbmcplugin.setPluginCategory(handle, film_title)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_film_%s' % film_id)
    dlg  = _progress('Loading metadata...') if cold else None
    film = afdb.get_film_detail(film_id, film_slug)
    if dlg: dlg.close()

    # Show cast as browsable sub-items with photos
    if film.get('cast'):
        for actor in film['cast']:
            photo       = afdb.actor_photo_url(actor['id'])
            photo_large = afdb.actor_photo_url_large(actor['id'])
            li = xbmcgui.ListItem(label='👤  %s' % actor['name'])
            li.setInfo('video', {'title': actor['name']})
            li.setArt({
                'thumb':  photo,
                'icon':   photo,
                'poster': photo,
                'fanart': photo_large,
            })
            xbmcplugin.addDirectoryItem(
                handle,
                build_url({'action': 'afdb_actor_detail',
                           'actor_id': actor['id'],
                           'actor_slug': actor['slug'],
                           'actor_name': actor['name']}),
                li, True
            )

    # Show a "Play" item (stream URL to be added later)
    li = xbmcgui.ListItem(label='▶  Play — Add stream source to play')
    li.setInfo('video', {
        'title':    film['title'],
        'plot':     film.get('description', ''),
        'year':     int(film['year']) if str(film.get('year','')).isdigit() else 0,
        'studio':   film.get('studio', ''),
        'genre':    ', '.join(film.get('categories', [])),
        'director': film.get('director', ''),
        'rating':   float(film.get('rating', 0)),
        'duration': int(film.get('runtime', 0)) * 60,
        'cast':     [c['name'] for c in film.get('cast', [])],
        'mpaa':     'Adults Only',
    })
    li.setArt({
        'thumb':  film['thumb'],
        'poster': film['thumb'],
        'fanart': film['fanart'],
        'banner': film['backcover'],
    })
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({'action': 'afdb_play',
                   'film_id': film_id,
                   'stream_url': ''}),
        li, False
    )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def _thumb_ref(thumb, film_url=''):
    """Append |Referer= to an image URL so Kodi sends the origin as Referer when fetching."""
    if not thumb or '|' in thumb:
        return thumb
    import re as _re
    m = _re.match(r'(https?://[^/]+)', film_url or thumb)
    if m:
        return thumb + '|Referer=' + m.group(1) + '/'
    return thumb


def adult_streams(handle, build_url, page=1):
    """
    Browse free streams from all 5 adult streaming sources.
    Every film entry is playable — clicking opens a source-picker dialog.
    """
    from resources.lib import adult_streams as _as

    xbmcplugin.setPluginCategory(handle, '▶ Free Streams — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    cold = _cache.get('fstreams_freeo_list_%d' % page) is None
    dlg = _progress('Loading streams...') if cold else None
    films = _as.get_all_streams(page=page)
    if dlg:
        dlg.close()

    if not films:
        xbmcgui.Dialog().notification('Starfleet', 'No streams found', xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        if not film.get('streams'):
            continue
        li = xbmcgui.ListItem(label=film['title'])

        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setPlot(film.get('description', ''))
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'plot': film.get('description', ''), 'mpaa': 'Adults Only'})

        if film.get('thumb'):
            thumb = _thumb_ref(film['thumb'], film.get('url', ''))
            li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb, 'icon': thumb})
        li.setProperty('IsPlayable', 'true')

        # All films use the dialog picker — single click → dialog → play
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_stream_sources',
                       'film_id': film['id'],
                       'title': film['title']}),
            li, False
        )

    _next_page(handle, build_url, 'adult_streams', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_stream_sources(handle, build_url, film_id, title=''):
    """
    Show a dialog listing all stream sources for a film, then play the chosen one.
    film_id prefix determines which cache key to look up:
      freeo_ / xxxms_ / wpw_ / wpf_ / spn_
    """
    from resources.lib import adult_streams as _as

    # Check merged cache first (set by get_all_streams), then per-source detail cache
    film = _cache.get('fstreams_merged_%s' % film_id)

    if not film:
        _PREFIX_CACHE = {
            'freeo_': 'fstreams_freeo_detail_%s',
            'xxxms_': 'fstreams_xxxms_detail_%s',
            'wpw_':   'fstreams_wpw_detail_%s',
            'wpf_':   'fstreams_wpf_detail_%s',
            'spn_':   'fstreams_spn_detail_%s',
        }
        for prefix, ck_tpl in _PREFIX_CACHE.items():
            if film_id.startswith(prefix):
                slug = film_id[len(prefix):]
                film = _cache.get(ck_tpl % slug)
                break

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification('Starfleet', 'No streams found', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = ['Link %d — %s' % (i + 1, s['label']) for i, s in enumerate(streams)]
        idx = xbmcgui.Dialog().select(
            '%s — Choose stream' % (title or film['title']), options
        )
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    adult_stream_play(handle, chosen['url'], title or film.get('title', ''))


def adult_stream_play(handle, stream_url, title=''):
    """
    Resolve and play a stream URL via ResolveURL if available.
    """
    if not stream_url:
        xbmcgui.Dialog().notification('Starfleet', 'No stream URL', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    resolved_url = stream_url

    try:
        import resolveurl
        if resolveurl.HostedMediaFile(stream_url).valid_url():
            hmf = resolveurl.HostedMediaFile(stream_url)
            resolved_url = hmf.resolve()
            xbmc.log('[Starfleet/Streams] ResolveURL: %s' % (resolved_url or 'failed')[:80], xbmc.LOGINFO)
    except ImportError:
        xbmc.log('[Starfleet/Streams] ResolveURL not installed', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/Streams] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(label=title, path=resolved_url)
    xbmcplugin.setResolvedUrl(handle, True, li)


def afdb_play(handle, stream_url, film_id=''):
    """
    Resolve and play a stream URL via ResolveURL if available,
    otherwise direct play.
    """
    if not stream_url:
        xbmcgui.Dialog().ok(
            'Starfleet — No Stream Source',
            'No stream URL has been assigned to this film yet.\n\n'
            'To add playback support:\n'
            '1. Find the film on a hoster (StreamTape, DoodStream, etc.)\n'
            '2. The stream URL will be passed here automatically\n'
            '   once a source plugin or scraper provides it.\n\n'
            'Metadata from Adult Film Database is ready and waiting.'
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    resolved_url = stream_url

    # Try ResolveURL addon first (supports 50+ hosters)
    try:
        import resolveurl
        if resolveurl.HostedMediaFile(stream_url).valid_url():
            hmf = resolveurl.HostedMediaFile(stream_url)
            resolved_url = hmf.resolve()
            xbmc.log('[AFDB] ResolveURL resolved: %s' % resolved_url[:80],
                     xbmc.LOGINFO)
    except ImportError:
        xbmc.log('[AFDB] ResolveURL not installed — playing directly',
                 xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[AFDB] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        xbmcgui.Dialog().notification('Adult', 'Could not resolve stream URL',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved_url)
    xbmcplugin.setResolvedUrl(handle, True, li)
