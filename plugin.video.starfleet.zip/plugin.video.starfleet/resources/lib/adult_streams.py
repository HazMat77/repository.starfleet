﻿# -*- coding: utf-8 -*-
"""
resources/lib/adult_streams.py — Adult streaming scrapers

Sources:
  freeomovie.to      — WordPress blog. Film list on homepage/pages.
                       Stream URLs in var TABS = [...] in page <script>.
  xxxmoviestream.org — DooPlay WordPress theme. Films under /movies/.
                       Stream URLs in data-fl-url="..." attributes.
  pornwatch.ws       — DooPlay theme. Film cards use data-movie-id + oldtitle.
                       Stream URLs in data-fl-url="..." on detail pages.
  watchpornfree.info — TPostMv theme. Film cards in <li class="TPostMv">.
                       Stream URLs in data-fl-url="..." on detail pages.
  speedporn.net      — Slug-number URLs. Stream URLs in data-fl-url="...".

Each scraper returns a list of film dicts:
  { 'id', 'title', 'title_norm', 'thumb', 'description', 'url',
    'source', 'streams': [{'label', 'url'}] }

get_all_streams() merges all sources and deduplicates by normalised title.
Merged films carry streams from all matching sources.
"""

import re
import unicodedata
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon()
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

import requests
from resources.lib import cache as _cache
_cache.init(_CACHE_DB)

FREEO_BASE = 'https://www.freeomovie.to'
XXXMS_BASE = 'https://xxxmoviestream.org'
WPW_BASE   = 'https://pornwatch.ws'
WPF_BASE   = 'https://watchpornfree.info'
SPN_BASE   = 'https://speedporn.net'

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE  = re.compile(r'\s+')

# ── HTTP session ──────────────────────────────────────────────────────────────

_session = None

def _sess():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        a = requests.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=6,
            max_retries=requests.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
    return _session


def _get(url, timeout=12):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _clean(text):
    text = _RE_STRIP_TAGS.sub(' ', text)
    return _RE_WHITESPACE.sub(' ', text).strip()


def _og(html, prop):
    """Extract og: meta property value."""
    m = re.search(
        r'<meta[^>]+property=["\']og:%s["\'][^>]+content=["\']([^"\']+)["\']' % re.escape(prop),
        html, re.IGNORECASE
    )
    if not m:
        m = re.search(
            r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:%s["\']' % re.escape(prop),
            html, re.IGNORECASE
        )
    return _clean(m.group(1)) if m else ''


# ── Title normalisation for deduplication ─────────────────────────────────────

_RE_NONALNUM = re.compile(r'[^a-z0-9 ]')

def _norm_title(title):
    """Lowercase, strip accents and punctuation, collapse spaces."""
    title = title.lower()
    # Remove accents
    title = ''.join(
        c for c in unicodedata.normalize('NFD', title)
        if unicodedata.category(c) != 'Mn'
    )
    title = _RE_NONALNUM.sub('', title)
    return _RE_WHITESPACE.sub(' ', title).strip()


# ── freeomovie.to ──────────────────────────────────────────────────────────────

_RE_FREEO_LINKS = re.compile(
    r'href="(https?://(?:www\.)?freeomovie\.to/([a-z0-9][a-z0-9-]+)/)"',
    re.IGNORECASE
)
_FREEO_SKIP = {
    'page', 'category', 'tag', 'author', 'feed', 'wp-json',
    'contact-us', 'legal-notice', 'privacy-policy', 'about',
    'wp-content', 'wp-includes', 'sitemap',
}
_RE_FREEO_TABS = re.compile(r'var\s+TABS\s*=\s*(\[.*?\]);', re.DOTALL)
_RE_FREEO_TITLE = re.compile(
    r'<h1[^>]*>Watch\s+(.*?)\s+(?:free\s+online\s+porn|porn\s+movie|watch\s+online)',
    re.IGNORECASE
)


def _freeo_film_list(page=1):
    ck = 'fstreams_freeo_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = FREEO_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html = _get(url)
        films = []
        seen  = set()
        for m in _RE_FREEO_LINKS.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in _FREEO_SKIP or slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] freeomovie page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] freeomovie list error: %s' % e, xbmc.LOGERROR)
        return []


def _freeo_film_detail(slug, film_url):
    ck = 'fstreams_freeo_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(film_url)

        # Title: try <h1> first, then og:title
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            raw = _clean(m.group(1))
            # Strip "Watch X free online porn" prefix/suffix
            raw = re.sub(r'^Watch\s+', '', raw, flags=re.IGNORECASE)
            raw = re.sub(r'\s+(?:free\s+online\s+porn|porn\s+movie.*|online\s+free.*)$', '',
                         raw, flags=re.IGNORECASE)
            title = raw.strip()
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()

        thumb = _og(html, 'image')
        desc  = _og(html, 'description')

        # Stream URLs from var TABS = [...]
        streams = []
        m = _RE_FREEO_TABS.search(html)
        if m:
            import json
            try:
                tabs = json.loads(m.group(1))
                for tab in tabs:
                    if tab.get('url') and tab.get('label'):
                        streams.append({'label': tab['label'], 'url': tab['url']})
            except (ValueError, KeyError):
                pass

        film = {
            'id':         'freeo_%s' % slug,
            'slug':       slug,
            'title':      title or slug.replace('-', ' ').title(),
            'title_norm': _norm_title(title or slug.replace('-', ' ')),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'freeomovie',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] freeomovie detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_freeo_films(page=1):
    """Return list of film dicts from freeomovie.to, page N."""
    stubs  = _freeo_film_list(page)
    films  = []
    for s in stubs:
        d = _freeo_film_detail(s['slug'], s['url'])
        if d:
            films.append(d)
    return films


# ── xxxmoviestream.org ────────────────────────────────────────────────────────

_RE_XXXMS_CARD = re.compile(
    r'href="(https?://xxxmoviestream\.org/movies/([a-z0-9][a-z0-9-]+)/)"\s*>\s*<img',
    re.IGNORECASE
)
_RE_XXXMS_STREAMS = re.compile(
    r'data-fl-url="(https?://[^"]+)"',
    re.IGNORECASE
)
# Filter out obviously non-player stream URLs
_XXXMS_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)',
    re.IGNORECASE
)


def _xxxms_film_list(page=1):
    ck = 'fstreams_xxxms_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = XXXMS_BASE + ('/movies/' if page == 1 else '/movies/page/%d/' % page)
    try:
        html = _get(url)
        films = []
        seen  = set()
        for m in _RE_XXXMS_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                films.append({'slug': slug, 'url': film_url})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] xxxmoviestream page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxmoviestream list error: %s' % e, xbmc.LOGERROR)
        return []


def _xxxms_film_detail(slug, film_url):
    ck = 'fstreams_xxxms_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html  = _get(film_url)

        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()

        thumb = _og(html, 'image')
        desc  = _og(html, 'description')

        # Stream URLs from data-fl-url="..." attributes
        seen_urls = set()
        streams   = []
        for m in _RE_XXXMS_STREAMS.finditer(html):
            stream_url = m.group(1)
            # Skip file hosters and duplicate/dynamic placeholder lines
            if _XXXMS_STREAM_SKIP.search(stream_url):
                continue
            if 'deadUrl' in stream_url:
                continue
            if stream_url in seen_urls:
                continue
            seen_urls.add(stream_url)
            # Derive a label from the domain
            domain = re.search(r'https?://(?:www\.)?([^./]+)', stream_url)
            label = domain.group(1).capitalize() if domain else 'Stream'
            streams.append({'label': label, 'url': stream_url})

        film = {
            'id':         'xxxms_%s' % slug,
            'slug':       slug,
            'title':      title or slug.replace('-', ' ').title(),
            'title_norm': _norm_title(title or slug.replace('-', ' ')),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'xxxmoviestream',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxmoviestream detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_xxxms_films(page=1):
    """Return list of film dicts from xxxmoviestream.org, page N."""
    stubs  = _xxxms_film_list(page)
    films  = []
    for s in stubs:
        d = _xxxms_film_detail(s['slug'], s['url'])
        if d:
            films.append(d)
    return films


# ── pornwatch.ws ──────────────────────────────────────────────────────────────
# DooPlay theme: film cards use data-movie-id="N" + oldtitle="TITLE" + <img src>
# Detail pages use data-fl-url="..." for stream URLs.

_RE_WPW_CARD = re.compile(
    r'data-movie-id="\d+"[^>]*>.*?'
    r'href="(https?://pornwatch\.ws/([a-z0-9][a-z0-9-]+)/)"[^>]*'
    r'oldtitle="([^"]+)"[^>]*>.*?'
    r'<img[^>]+src="([^"]+)"',
    re.IGNORECASE | re.DOTALL
)
_RE_WPW_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_WPW_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _wpw_film_list(page=1):
    ck = 'fstreams_wpw_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = WPW_BASE + ('/movies-2/' if page == 1 else '/movies-2/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_WPW_CARD.finditer(html):
            film_url, slug, title, thumb = m.group(1), m.group(2), m.group(3), m.group(4)
            if slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url, 'title': title, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] pornwatch page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] pornwatch list error: %s' % e, xbmc.LOGERROR)
        return []


def _wpw_film_detail(slug, film_url, title='', thumb=''):
    ck = 'fstreams_wpw_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        for m in _RE_WPW_STREAMS.finditer(html):
            su = m.group(1)
            if _WPW_STREAM_SKIP.search(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'wpw_%s' % slug,
            'slug':       slug,
            'title':      title,
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'pornwatch',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] pornwatch detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_wpw_films(page=1):
    """Return list of film dicts from pornwatch.ws, page N."""
    stubs = _wpw_film_list(page)
    films = []
    for s in stubs:
        d = _wpw_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', ''))
        if d:
            films.append(d)
    return films


# ── watchpornfree.info ────────────────────────────────────────────────────────
# TPostMv theme: film cards in <li class="TPostMv"> with href and img alt.
# Detail pages use data-fl-url="..." for stream URLs.

_RE_WPF_CARD = re.compile(
    r'<li[^>]+class="TPostMv"[^>]*>.*?'
    r'<a[^>]+href="(https?://watchpornfree\.info/([a-z0-9][a-z0-9-]+)[^"]*)"[^>]*>.*?'
    r'<img[^>]+src="([^"]+)"[^>]+alt="([^"]*)"',
    re.IGNORECASE | re.DOTALL
)
_RE_WPF_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_WPF_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _wpf_film_list(page=1):
    ck = 'fstreams_wpf_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = WPF_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_WPF_CARD.finditer(html):
            film_url, slug, thumb, alt = m.group(1), m.group(2), m.group(3), m.group(4)
            if slug in seen:
                continue
            seen.add(slug)
            # alt is "Watch TITLE Porn Online Free" — strip prefix/suffix
            title = re.sub(r'^Watch\s+', '', alt, flags=re.IGNORECASE)
            title = re.sub(r'\s+(?:Porn|Online|Free|Watch).*$', '', title, flags=re.IGNORECASE).strip()
            if not title:
                title = slug.replace('-', ' ').title()
            films.append({'slug': slug, 'url': film_url, 'title': title, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] watchpornfree page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] watchpornfree list error: %s' % e, xbmc.LOGERROR)
        return []


def _wpf_film_detail(slug, film_url, title='', thumb=''):
    ck = 'fstreams_wpf_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
            title = re.sub(r'^Watch\s+', '', title, flags=re.IGNORECASE)
            title = re.sub(r'\s+(?:Porn|Online|Free).*$', '', title, flags=re.IGNORECASE).strip()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        for m in _RE_WPF_STREAMS.finditer(html):
            su = m.group(1)
            if _WPF_STREAM_SKIP.search(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'wpf_%s' % slug,
            'slug':       slug,
            'title':      title,
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'watchpornfree',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] watchpornfree detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_wpf_films(page=1):
    """Return list of film dicts from watchpornfree.info, page N."""
    stubs = _wpf_film_list(page)
    films = []
    for s in stubs:
        d = _wpf_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', ''))
        if d:
            films.append(d)
    return films


# ── speedporn.net ─────────────────────────────────────────────────────────────
# Slug-number URLs: /slug-N/ pattern on homepage.
# Detail pages use data-fl-url="..." for stream URLs.

_RE_SPN_CARD = re.compile(
    r'href="(https?://speedporn\.net/([a-z0-9][a-z0-9-]+-\d+)/)"',
    re.IGNORECASE
)
_RE_SPN_IMG = re.compile(r'<img[^>]+src="([^"]+)"', re.IGNORECASE)
_RE_SPN_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_SPN_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _spn_film_list(page=1):
    ck = 'fstreams_spn_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = SPN_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_SPN_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in seen:
                continue
            seen.add(slug)
            # Thumbnail: look for img in the vicinity (next 300 chars)
            idx   = m.end()
            chunk = html[idx:idx + 300]
            im    = _RE_SPN_IMG.search(chunk)
            thumb = im.group(1) if im else ''
            films.append({'slug': slug, 'url': film_url, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] speedporn page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] speedporn list error: %s' % e, xbmc.LOGERROR)
        return []


def _spn_film_detail(slug, film_url, thumb=''):
    ck = 'fstreams_spn_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()
        if not title:
            # Derive from slug: strip trailing -number
            title = re.sub(r'-\d+$', '', slug).replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        for m in _RE_SPN_STREAMS.finditer(html):
            su = m.group(1)
            if _SPN_STREAM_SKIP.search(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'spn_%s' % slug,
            'slug':       slug,
            'title':      title,
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'speedporn',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] speedporn detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_spn_films(page=1):
    """Return list of film dicts from speedporn.net, page N."""
    stubs = _spn_film_list(page)
    films = []
    for s in stubs:
        d = _spn_film_detail(s['slug'], s['url'], s.get('thumb', ''))
        if d:
            films.append(d)
    return films


# ── Merged + deduplicated stream catalogue ────────────────────────────────────

def get_all_streams(page=1):
    """
    Return a merged, deduplicated list of films from all 5 sources.
    Films with the same normalised title are merged into one entry with
    streams combined from every matching source.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    sources = [
        get_freeo_films,
        get_xxxms_films,
        get_wpw_films,
        get_wpf_films,
        get_spn_films,
    ]

    all_films = []
    with ThreadPoolExecutor(max_workers=len(sources)) as pool:
        futures = {pool.submit(fn, page): fn.__name__ for fn in sources}
        try:
            for future in as_completed(futures, timeout=45):
                name = futures[future]
                try:
                    results = future.result()
                    all_films.extend(results)
                    xbmc.log('[Starfleet/Streams] %s: %d films on page %d' % (name, len(results), page), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log('[Starfleet/Streams] source error (%s): %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            # One source timed out — use what we have rather than crashing
            xbmc.log('[Starfleet/Streams] get_all_streams partial timeout: %s' % e, xbmc.LOGWARNING)

    # Deduplicate by normalised title — merge streams from duplicates
    by_norm = {}
    for film in all_films:
        nt = film['title_norm']
        if not nt:
            continue
        if nt not in by_norm:
            by_norm[nt] = dict(film)
            by_norm[nt]['streams'] = list(film['streams'])
        else:
            seen_urls = {s['url'] for s in by_norm[nt]['streams']}
            for s in film['streams']:
                if s['url'] not in seen_urls:
                    by_norm[nt]['streams'].append(s)
                    seen_urls.add(s['url'])
            # Prefer richer metadata (longer description, non-empty thumb)
            if not by_norm[nt].get('thumb') and film.get('thumb'):
                by_norm[nt]['thumb'] = film['thumb']
            if len(film.get('description', '')) > len(by_norm[nt].get('description', '')):
                by_norm[nt]['description'] = film['description']

    merged_list = list(by_norm.values())

    # Cache each merged film under its own id so adult_stream_sources can retrieve it
    for film in merged_list:
        film_id = film.get('id', '')
        if film_id:
            _cache.set('fstreams_merged_%s' % film_id, film, 24 * 3600)

    return merged_list


# ── Title-based stream search (AFDB → scrapers pipeline) ─────────────────────

def _title_matches(norm_query, norm_film):
    """True if the normalised AFDB title matches a scraper film title closely enough."""
    if not norm_query or not norm_film:
        return False
    if norm_query == norm_film:
        return True
    # All words from query present in film title (handles minor subtitle differences)
    words = norm_query.split()
    if len(words) >= 2 and all(w in norm_film for w in words):
        return True
    # Film title fully contained within query (e.g. scraper has shorter title)
    film_words = norm_film.split()
    if len(film_words) >= 2 and all(w in norm_query for w in film_words):
        return True
    return False


def search_by_title(title, page=1):
    """
    Search all 5 scrapers for streams matching `title`.
    Fetches page N of each scraper in parallel, compares normalised titles,
    and collects all stream links from matching films.
    Returns list of {'label': str, 'url': str} dicts (empty list if none found).
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    norm_query = _norm_title(title)
    if not norm_query:
        return []

    sources = [get_freeo_films, get_xxxms_films, get_wpw_films, get_wpf_films, get_spn_films]

    streams = []
    seen_urls = set()

    with ThreadPoolExecutor(max_workers=len(sources)) as pool:
        futures = {pool.submit(fn, page): fn.__name__ for fn in sources}
        try:
            for future in as_completed(futures, timeout=30):
                name = futures[future]
                try:
                    films = future.result()
                    for film in films:
                        if _title_matches(norm_query, film.get('title_norm', '')):
                            for s in film.get('streams', []):
                                if s.get('url') and s['url'] not in seen_urls:
                                    seen_urls.add(s['url'])
                                    streams.append({'label': s.get('label', name), 'url': s['url']})
                            xbmc.log('[Starfleet/Streams] title match "%s" in %s' % (film.get('title', ''), name), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log('[Starfleet/Streams] search error (%s): %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] search_by_title timeout: %s' % e, xbmc.LOGWARNING)

    xbmc.log('[Starfleet/Streams] search_by_title "%s" → %d streams' % (title, len(streams)), xbmc.LOGINFO)
    return streams
